import { base44 } from './base44Client';


export const Organization = base44.entities.Organization;

export const Document = base44.entities.Document;

export const Activity = base44.entities.Activity;

export const Notification = base44.entities.Notification;

export const EmailTemplate = base44.entities.EmailTemplate;

export const Patient = base44.entities.Patient;

export const Product = base44.entities.Product;

export const Prescription = base44.entities.Prescription;

export const Order = base44.entities.Order;

export const Production = base44.entities.Production;

export const LegalDocument = base44.entities.LegalDocument;

export const Newsletter = base44.entities.Newsletter;

export const MailingList = base44.entities.MailingList;

export const Plant = base44.entities.Plant;

export const Batch = base44.entities.Batch;

export const Strain = base44.entities.Strain;

export const Inventory = base44.entities.Inventory;

export const Transfer = base44.entities.Transfer;

export const LabTest = base44.entities.LabTest;

export const GrowRoom = base44.entities.GrowRoom;

export const ModuleSettings = base44.entities.ModuleSettings;

export const Transparency = base44.entities.Transparency;

export const AssociationMember = base44.entities.AssociationMember;

export const AssociationFinancial = base44.entities.AssociationFinancial;

export const DocumentActivity = base44.entities.DocumentActivity;

export const DocumentComment = base44.entities.DocumentComment;

export const DocumentCategory = base44.entities.DocumentCategory;

export const Associado = base44.entities.Associado;

export const Anuidade = base44.entities.Anuidade;

export const PagamentoAnuidade = base44.entities.PagamentoAnuidade;

export const Cliente = base44.entities.Cliente;

export const AutorizacaoAnvisa = base44.entities.AutorizacaoAnvisa;

export const AcaoJudicial = base44.entities.AcaoJudicial;

export const Material = base44.entities.Material;

export const LoteMaterial = base44.entities.LoteMaterial;

export const Amostragem = base44.entities.Amostragem;

export const AnaliseQualidade = base44.entities.AnaliseQualidade;

export const MovimentacaoEstoque = base44.entities.MovimentacaoEstoque;

export const DocumentoQualidade = base44.entities.DocumentoQualidade;

export const LiberacaoLote = base44.entities.LiberacaoLote;

export const DesvioQualidade = base44.entities.DesvioQualidade;

export const PedidoJuncao = base44.entities.PedidoJuncao;

export const ModuloCompras = base44.entities.ModuloCompras;

export const SolicitacaoCompra = base44.entities.SolicitacaoCompra;

export const Fornecedor = base44.entities.Fornecedor;

export const ItemEstoque = base44.entities.ItemEstoque;

export const MovimentacaoEstoqueCompras = base44.entities.MovimentacaoEstoqueCompras;

export const RequisicaoInterna = base44.entities.RequisicaoInterna;

export const EstoqueDistribuicao = base44.entities.EstoqueDistribuicao;

export const MovimentacaoDistribuicao = base44.entities.MovimentacaoDistribuicao;

export const AssistenciaBeneficiario = base44.entities.AssistenciaBeneficiario;

export const CalendarEvent = base44.entities.CalendarEvent;

export const PaymentMethod = base44.entities.PaymentMethod;

export const PaymentTransaction = base44.entities.PaymentTransaction;

export const Invoice = base44.entities.Invoice;

export const RecurringPayment = base44.entities.RecurringPayment;

export const PaymentIntegration = base44.entities.PaymentIntegration;

export const CentroCusto = base44.entities.CentroCusto;

export const ContaBancaria = base44.entities.ContaBancaria;

export const PlanoContas = base44.entities.PlanoContas;

export const FormaPagamento = base44.entities.FormaPagamento;

export const ModuloComunicacao = base44.entities.ModuloComunicacao;

export const EventoComunicacao = base44.entities.EventoComunicacao;

export const CredencialServico = base44.entities.CredencialServico;

export const CampanhaEmail = base44.entities.CampanhaEmail;

export const Medico = base44.entities.Medico;

export const ConsultaMedica = base44.entities.ConsultaMedica;

export const FinanceiroMedico = base44.entities.FinanceiroMedico;

export const NotificacaoMedica = base44.entities.NotificacaoMedica;

export const SecretariaMedica = base44.entities.SecretariaMedica;

export const AcompanhamentoTratamento = base44.entities.AcompanhamentoTratamento;

export const ConteudoEducativo = base44.entities.ConteudoEducativo;

export const FeedbackConteudo = base44.entities.FeedbackConteudo;

export const LembretesMedicacao = base44.entities.LembretesMedicacao;

export const FeedbackConsulta = base44.entities.FeedbackConsulta;

export const PrescricaoFarmaceutica = base44.entities.PrescricaoFarmaceutica;

export const PrescricaoNotificacao = base44.entities.PrescricaoNotificacao;

export const NotificationPreference = base44.entities.NotificationPreference;

export const Representante = base44.entities.Representante;

export const Comissao = base44.entities.Comissao;

export const ComissaoMedica = base44.entities.ComissaoMedica;

export const ModuloDispensario = base44.entities.ModuloDispensario;

export const Venda = base44.entities.Venda;

export const Caixa = base44.entities.Caixa;

export const MovimentacaoDispensario = base44.entities.MovimentacaoDispensario;

export const EstoqueDispensario = base44.entities.EstoqueDispensario;

export const ReceituarioDispensario = base44.entities.ReceituarioDispensario;

export const RelatorioSNGPC = base44.entities.RelatorioSNGPC;

export const Task = base44.entities.Task;

export const Message = base44.entities.Message;

export const OnboardingProgress = base44.entities.OnboardingProgress;

export const ModuloAI = base44.entities.ModuloAI;

export const CatalogoProduto = base44.entities.CatalogoProduto;

export const AlmoxarifadoMateriaPrima = base44.entities.AlmoxarifadoMateriaPrima;

export const AlmoxarifadoProdutoAcabado = base44.entities.AlmoxarifadoProdutoAcabado;

export const RastreabilidadeProducao = base44.entities.RastreabilidadeProducao;

export const DescarteProducao = base44.entities.DescarteProducao;

export const Estoque = base44.entities.Estoque;

export const Department = base44.entities.Department;

export const Sector = base44.entities.Sector;

export const Invitation = base44.entities.Invitation;

export const OrgUser = base44.entities.OrgUser;

export const Pesquisa = base44.entities.Pesquisa;

export const Doenca = base44.entities.Doenca;

export const GrupoPesquisa = base44.entities.GrupoPesquisa;

export const ProtocoloPesquisa = base44.entities.ProtocoloPesquisa;

export const ExportDefinition = base44.entities.ExportDefinition;

export const ExportConfig = base44.entities.ExportConfig;

export const ExportTemplate = base44.entities.ExportTemplate;

export const ExportLog = base44.entities.ExportLog;

export const ExportModule = base44.entities.ExportModule;

export const PlatformConfig = base44.entities.PlatformConfig;

export const ReplicationConfig = base44.entities.ReplicationConfig;



// auth sdk:
export const User = base44.auth;