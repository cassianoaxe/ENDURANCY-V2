import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, ArrowDownUp } from "lucide-react";

export default function KeyMetricCard({ title, value, change, period, trend, icon, color }) {
  const colorClasses = {
    blue: {
      bg: "bg-blue-50",
      text: "text-blue-600",
      icon: "text-blue-600"
    },
    green: {
      bg: "bg-green-50",
      text: "text-green-600",
      icon: "text-green-600"
    },
    purple: {
      bg: "bg-purple-50",
      text: "text-purple-600",
      icon: "text-purple-600"
    }
  };
  
  const classes = colorClasses[color] || colorClasses.blue;
  
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <h3 className="text-2xl font-bold mt-1">{value}</h3>
            <div className={`flex items-center mt-2 ${trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
              {trend === 'up' ? (
                <TrendingUp className="w-4 h-4 mr-1" />
              ) : (
                <ArrowDownUp className="w-4 h-4 mr-1" />
              )}
              <span className="text-sm font-medium">{change}</span>
              <span className="text-xs text-gray-500 ml-1">{period}</span>
            </div>
          </div>
          <div className={`p-3 rounded-lg ${classes.bg}`}>
            <div className={classes.icon}>
              {icon}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}