import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Leaf, CheckCircle2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import KeyMetricCard from './KeyMetricCard';

// Mock data for cultivation analytics
const cultivationYieldData = [
  { month: 'Jan', yield: 32.5, target: 30 },
  { month: 'Feb', yield: 35.2, target: 33 },
  { month: 'Mar', yield: 34.8, target: 35 },
  { month: 'Apr', yield: 37.5, target: 36 },
  { month: 'May', yield: 38.2, target: 37 },
  { month: 'Jun', yield: 40.1, target: 38 },
  { month: 'Jul', yield: 42.5, target: 39 },
  { month: 'Aug', yield: 41.8, target: 40 },
  { month: 'Sep', yield: 43.2, target: 41 },
  { month: 'Oct', yield: 45.5, target: 42 },
  { month: 'Nov', yield: 44.7, target: 43 },
  { month: 'Dec', yield: 47.1, target: 44 },
];

const cultivationEfficiencyData = [
  { month: 'Jan', electricity_kwh_per_kg: 256, water_l_per_kg: 124, labor_hours_per_kg: 8.2 },
  { month: 'Feb', electricity_kwh_per_kg: 249, water_l_per_kg: 119, labor_hours_per_kg: 7.9 },
  { month: 'Mar', electricity_kwh_per_kg: 242, water_l_per_kg: 118, labor_hours_per_kg: 7.8 },
  { month: 'Apr', electricity_kwh_per_kg: 238, water_l_per_kg: 115, labor_hours_per_kg: 7.6 },
  { month: 'May', electricity_kwh_per_kg: 232, water_l_per_kg: 112, labor_hours_per_kg: 7.3 },
  { month: 'Jun', electricity_kwh_per_kg: 228, water_l_per_kg: 109, labor_hours_per_kg: 7.1 },
  { month: 'Jul', electricity_kwh_per_kg: 225, water_l_per_kg: 108, labor_hours_per_kg: 7.0 },
  { month: 'Aug', electricity_kwh_per_kg: 223, water_l_per_kg: 106, labor_hours_per_kg: 6.9 },
  { month: 'Sep', electricity_kwh_per_kg: 220, water_l_per_kg: 105, labor_hours_per_kg: 6.8 },
  { month: 'Oct', electricity_kwh_per_kg: 218, water_l_per_kg: 103, labor_hours_per_kg: 6.7 },
  { month: 'Nov', electricity_kwh_per_kg: 215, water_l_per_kg: 102, labor_hours_per_kg: 6.6 },
  { month: 'Dec', electricity_kwh_per_kg: 212, water_l_per_kg: 100, labor_hours_per_kg: 6.5 },
];

const strainPerformanceData = [
  { name: "Charlotte's Web", yield_per_plant: 85, potency_cbd: 18, growth_days: 65, success_rate: 92 },
  { name: "Cannatonic", yield_per_plant: 78, potency_cbd: 12, growth_days: 70, success_rate: 88 },
  { name: "ACDC", yield_per_plant: 82, potency_cbd: 20, growth_days: 68, success_rate: 90 },
  { name: "Harlequin", yield_per_plant: 75, potency_cbd: 15, growth_days: 72, success_rate: 85 },
  { name: "Remedy", yield_per_plant: 80, potency_cbd: 14, growth_days: 67, success_rate: 89 },
];

const batchSuccessRateData = [
  { month: 'Q1', plants_started: 500, plants_harvested: 460, success_rate: 92 },
  { month: 'Q2', plants_started: 520, plants_harvested: 485, success_rate: 93.3 },
  { month: 'Q3', plants_started: 540, plants_harvested: 502, success_rate: 92.9 },
  { month: 'Q4', plants_started: 560, plants_harvested: 526, success_rate: 93.9 },
];

export default function CultivationAnalytics({ timeRange }) {
  // Filter data based on timeRange if needed
  const filteredYieldData = timeRange === 'month' 
    ? cultivationYieldData.slice(-1) 
    : timeRange === 'quarter' 
      ? cultivationYieldData.slice(-3) 
      : cultivationYieldData;
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <KeyMetricCard 
          title="Total Annual Yield" 
          value="452.5 kg" 
          change="+12.4%" 
          period="vs last year"
          trend="up"
          icon={<Leaf className="h-5 w-5" />}
          color="green"
        />
        <KeyMetricCard 
          title="Avg. Yield per Plant" 
          value="82g" 
          change="+5.1%" 
          period="vs last year"
          trend="up"
          icon={<TrendingUp className="h-5 w-5" />}
          color="green"
        />
        <KeyMetricCard 
          title="Batch Success Rate" 
          value="93.2%" 
          change="+1.8%" 
          period="vs last year"
          trend="up"
          icon={<CheckCircle2 className="h-5 w-5" />}
          color="green"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Yield</CardTitle>
            <CardDescription>Actual vs target (kg)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={filteredYieldData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="yield" name="Actual Yield (kg)" fill="#4ade80" />
                  <Line dataKey="target" name="Target Yield (kg)" stroke="#ef4444" strokeWidth={2} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Resource Efficiency</CardTitle>
            <CardDescription>Resource usage per kg produced</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={filteredYieldData.length <= 3 ? cultivationEfficiencyData.slice(-filteredYieldData.length) : cultivationEfficiencyData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" domain={[0, 150]} />
                  <Tooltip />
                  <Legend />
                  <Line 
                    yAxisId="left" 
                    dataKey="electricity_kwh_per_kg" 
                    name="Electricity (kWh/kg)" 
                    stroke="#3b82f6" 
                    strokeWidth={2} 
                  />
                  <Line 
                    yAxisId="right" 
                    dataKey="water_l_per_kg" 
                    name="Water (L/kg)" 
                    stroke="#10b981" 
                    strokeWidth={2} 
                  />
                  <Line 
                    yAxisId="left" 
                    dataKey="labor_hours_per_kg" 
                    name="Labor (hours/kg)" 
                    stroke="#f59e0b" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Strain Performance</CardTitle>
            <CardDescription>Yield and potency by strain</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={strainPerformanceData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" domain={[0, 25]} />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    yAxisId="left" 
                    dataKey="yield_per_plant" 
                    name="Yield per Plant (g)" 
                    fill="#4ade80" 
                  />
                  <Line 
                    yAxisId="right" 
                    dataKey="potency_cbd" 
                    name="CBD Potency (%)" 
                    stroke="#f59e0b" 
                    strokeWidth={2} 
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Batch Success Rate</CardTitle>
            <CardDescription>Plants started vs harvested</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={batchSuccessRateData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" domain={[80, 100]} />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    yAxisId="left" 
                    dataKey="plants_started" 
                    name="Plants Started" 
                    fill="#3b82f6" 
                  />
                  <Bar 
                    yAxisId="left" 
                    dataKey="plants_harvested" 
                    name="Plants Harvested" 
                    fill="#4ade80" 
                  />
                  <Line 
                    yAxisId="right" 
                    dataKey="success_rate" 
                    name="Success Rate (%)" 
                    stroke="#f59e0b" 
                    strokeWidth={2} 
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}