import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, Clock, Users } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import KeyMetricCard from './KeyMetricCard';

// Mock data for patient analytics
const patientRegistrationData = [
  { month: 'Jan', new_patients: 48, cumulative_patients: 1250 },
  { month: 'Feb', new_patients: 52, cumulative_patients: 1302 },
  { month: 'Mar', new_patients: 55, cumulative_patients: 1357 },
  { month: 'Apr', new_patients: 58, cumulative_patients: 1415 },
  { month: 'May', new_patients: 62, cumulative_patients: 1477 },
  { month: 'Jun', new_patients: 65, cumulative_patients: 1542 },
  { month: 'Jul', new_patients: 68, cumulative_patients: 1610 },
  { month: 'Aug', new_patients: 72, cumulative_patients: 1682 },
  { month: 'Sep', new_patients: 75, cumulative_patients: 1757 },
  { month: 'Oct', new_patients: 78, cumulative_patients: 1835 },
  { month: 'Nov', new_patients: 82, cumulative_patients: 1917 },
  { month: 'Dec', new_patients: 85, cumulative_patients: 2002 },
];

const patientRetentionData = [
  { month: 'Jan', active_patients: 950, retention_rate: 76 },
  { month: 'Feb', active_patients: 980, retention_rate: 75.3 },
  { month: 'Mar', active_patients: 1020, retention_rate: 75.2 },
  { month: 'Apr', active_patients: 1060, retention_rate: 74.9 },
  { month: 'May', active_patients: 1100, retention_rate: 74.5 },
  { month: 'Jun', active_patients: 1140, retention_rate: 73.9 },
  { month: 'Jul', active_patients: 1180, retention_rate: 73.3 },
  { month: 'Aug', active_patients: 1220, retention_rate: 72.5 },
  { month: 'Sep', active_patients: 1260, retention_rate: 71.7 },
  { month: 'Oct', active_patients: 1310, retention_rate: 71.4 },
  { month: 'Nov', active_patients: 1360, retention_rate: 70.9 },
  { month: 'Dec', active_patients: 1410, retention_rate: 70.4 },
];

const prescriptionData = [
  { month: 'Jan', prescriptions: 780, renewal_rate: 82 },
  { month: 'Feb', prescriptions: 810, renewal_rate: 82.5 },
  { month: 'Mar', prescriptions: 840, renewal_rate: 82.8 },
  { month: 'Apr', prescriptions: 870, renewal_rate: 83.2 },
  { month: 'May', prescriptions: 900, renewal_rate: 83.5 },
  { month: 'Jun', prescriptions: 930, renewal_rate: 83.7 },
  { month: 'Jul', prescriptions: 960, renewal_rate: 84.0 },
  { month: 'Aug', prescriptions: 990, renewal_rate: 84.2 },
  { month: 'Sep', prescriptions: 1020, renewal_rate: 84.5 },
  { month: 'Oct', prescriptions: 1050, renewal_rate: 84.7 },
  { month: 'Nov', prescriptions: 1080, renewal_rate: 85.0 },
  { month: 'Dec', prescriptions: 1110, renewal_rate: 85.2 },
];

const demographicsData = [
  { age_group: '18-24', percentage: 8 },
  { age_group: '25-34', percentage: 22 },
  { age_group: '35-44', percentage: 25 },
  { age_group: '45-54', percentage: 20 },
  { age_group: '55-64', percentage: 15 },
  { age_group: '65+', percentage: 10 },
];

const conditionsData = [
  { condition: 'Chronic Pain', patients: 620 },
  { condition: 'Anxiety', patients: 450 },
  { condition: 'Multiple Sclerosis', patients: 320 },
  { condition: 'Epilepsy', patients: 280 },
  { condition: 'Cancer', patients: 240 },
  { condition: 'Other', patients: 380 },
];

export default function PatientAnalytics({ timeRange }) {
  // Filter data based on timeRange if needed
  const getFilteredData = (data) => {
    if (timeRange === 'month') return data.slice(-1);
    if (timeRange === 'quarter') return data.slice(-3);
    return data;
  };
  
  const filteredRegistrationData = getFilteredData(patientRegistrationData);
  const filteredRetentionData = getFilteredData(patientRetentionData);
  const filteredPrescriptionData = getFilteredData(prescriptionData);
  
  // Get latest metrics
  const latestData = {
    totalPatients: patientRegistrationData[patientRegistrationData.length - 1].cumulative_patients,
    activePatients: patientRetentionData[patientRetentionData.length - 1].active_patients,
    prescriptionRenewal: prescriptionData[prescriptionData.length - 1].renewal_rate
  };
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <KeyMetricCard 
          title="Total Patients" 
          value={latestData.totalPatients.toLocaleString()} 
          change="+23.5%" 
          period="vs last year"
          trend="up"
          icon={<Users className="h-5 w-5" />}
          color="purple"
        />
        <KeyMetricCard 
          title="Active Patients" 
          value={latestData.activePatients.toLocaleString()} 
          change="-3.2%" 
          period="vs last year"
          trend="down"
          icon={<Heart className="h-5 w-5" />}
          color="purple"
        />
        <KeyMetricCard 
          title="Prescription Renewal" 
          value={`${latestData.prescriptionRenewal}%`} 
          change="+1.8%" 
          period="vs last year"
          trend="up"
          icon={<Clock className="h-5 w-5" />}
          color="purple"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Patient Registration</CardTitle>
            <CardDescription>New and cumulative patients</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={filteredRegistrationData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    yAxisId="left" 
                    dataKey="new_patients" 
                    name="New Patients" 
                    fill="#a855f7" 
                  />
                  <Line 
                    yAxisId="right" 
                    dataKey="cumulative_patients" 
                    name="Total Patients" 
                    stroke="#2563eb" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Patient Retention</CardTitle>
            <CardDescription>Active patients and retention rate</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={filteredRetentionData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" domain={[65, 80]} />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    yAxisId="left" 
                    dataKey="active_patients" 
                    name="Active Patients" 
                    fill="#a855f7" 
                  />
                  <Line 
                    yAxisId="right" 
                    dataKey="retention_rate" 
                    name="Retention Rate (%)" 
                    stroke="#f59e0b" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Age Distribution</CardTitle>
            <CardDescription>Patients by age group</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={demographicsData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="percentage"
                    label={({ age_group, percentage }) => `${age_group}: ${percentage}%`}
                  >
                    {demographicsData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={[
                          "#c084fc", "#a855f7", "#9333ea", 
                          "#7e22ce", "#6b21a8", "#581c87"
                        ][index % 6]} 
                      />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Medical Conditions</CardTitle>
            <CardDescription>Top conditions treated</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={conditionsData}
                  layout="vertical"
                  margin={{ top: 20, right: 30, left: 120, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis type="category" dataKey="condition" tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="patients" name="Patients" fill="#f87171" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Prescriptions</CardTitle>
            <CardDescription>Monthly prescriptions and renewal rate</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={filteredPrescriptionData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" domain={[80, 90]} />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    yAxisId="left" 
                    dataKey="prescriptions" 
                    name="Prescriptions" 
                    fill="#a855f7" 
                  />
                  <Line 
                    yAxisId="right" 
                    dataKey="renewal_rate" 
                    name="Renewal Rate (%)" 
                    stroke="#10b981" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}