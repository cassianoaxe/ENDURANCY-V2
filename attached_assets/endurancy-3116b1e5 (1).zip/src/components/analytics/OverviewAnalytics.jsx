import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Leaf, Factory, Users, TrendingUp } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import KeyMetricCard from './KeyMetricCard';

// Mock data for the overview analytics
const cultivationYieldData = [
  { month: 'Jan', yield: 32.5, target: 30 },
  { month: 'Feb', yield: 35.2, target: 33 },
  { month: 'Mar', yield: 34.8, target: 35 },
  { month: 'Apr', yield: 37.5, target: 36 },
  { month: 'May', yield: 38.2, target: 37 },
  { month: 'Jun', yield: 40.1, target: 38 },
  { month: 'Jul', yield: 42.5, target: 39 },
  { month: 'Aug', yield: 41.8, target: 40 },
  { month: 'Sep', yield: 43.2, target: 41 },
  { month: 'Oct', yield: 45.5, target: 42 },
  { month: 'Nov', yield: 44.7, target: 43 },
  { month: 'Dec', yield: 47.1, target: 44 },
];

const patientRegistrationData = [
  { month: 'Jan', new_patients: 48, cumulative_patients: 1250 },
  { month: 'Feb', new_patients: 52, cumulative_patients: 1302 },
  { month: 'Mar', new_patients: 55, cumulative_patients: 1357 },
  { month: 'Apr', new_patients: 58, cumulative_patients: 1415 },
  { month: 'May', new_patients: 62, cumulative_patients: 1477 },
  { month: 'Jun', new_patients: 65, cumulative_patients: 1542 },
  { month: 'Jul', new_patients: 68, cumulative_patients: 1610 },
  { month: 'Aug', new_patients: 72, cumulative_patients: 1682 },
  { month: 'Sep', new_patients: 75, cumulative_patients: 1757 },
  { month: 'Oct', new_patients: 78, cumulative_patients: 1835 },
  { month: 'Nov', new_patients: 82, cumulative_patients: 1917 },
  { month: 'Dec', new_patients: 85, cumulative_patients: 2002 },
];

const productMixData = [
  { name: 'Oils', value: 175 },
  { name: 'Capsules', value: 125 },
  { name: 'Tinctures', value: 75 },
  { name: 'Topicals', value: 58 }
];

const demographicsData = [
  { age_group: '18-24', percentage: 8 },
  { age_group: '25-34', percentage: 22 },
  { age_group: '35-44', percentage: 25 },
  { age_group: '45-54', percentage: 20 },
  { age_group: '55-64', percentage: 15 },
  { age_group: '65+', percentage: 10 },
];

const conditionsData = [
  { condition: 'Chronic Pain', patients: 620 },
  { condition: 'Anxiety', patients: 450 },
  { condition: 'Multiple Sclerosis', patients: 320 },
  { condition: 'Epilepsy', patients: 280 },
  { condition: 'Cancer', patients: 240 },
  { condition: 'Other', patients: 380 },
];

export default function OverviewAnalytics({ timeRange }) {
  // Filter data based on timeRange if needed
  const getFilteredData = (data) => {
    if (timeRange === 'month') return data.slice(-1);
    if (timeRange === 'quarter') return data.slice(-3);
    return data;
  };
  
  const filteredYieldData = getFilteredData(cultivationYieldData);
  const filteredPatientData = getFilteredData(patientRegistrationData);
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <KeyMetricCard 
          title="Total Yield" 
          value="452.5 kg" 
          change="+12.4%" 
          period="vs last year"
          trend="up"
          icon={<Leaf className="h-5 w-5" />}
          color="green"
        />
        <KeyMetricCard 
          title="Production Output" 
          value="3,184 units" 
          change="+8.7%" 
          period="vs last year"
          trend="up"
          icon={<Factory className="h-5 w-5" />}
          color="blue"
        />
        <KeyMetricCard 
          title="Active Patients" 
          value="1,410" 
          change="+23.5%" 
          period="vs last year"
          trend="up"
          icon={<Users className="h-5 w-5" />}
          color="purple"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Annual Performance</CardTitle>
            <CardDescription>Key metrics year-over-year growth</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={filteredYieldData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="yield" name="Monthly Yield (kg)" fill="#4ade80" />
                  <Line dataKey="target" name="Target" stroke="#ef4444" strokeWidth={2} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Patient Growth</CardTitle>
            <CardDescription>New and cumulative patients</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={filteredPatientData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    yAxisId="left" 
                    dataKey="new_patients" 
                    name="New Patients" 
                    fill="#a855f7" 
                  />
                  <Line 
                    yAxisId="right" 
                    dataKey="cumulative_patients" 
                    name="Total Patients" 
                    stroke="#2563eb" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Product Mix</CardTitle>
            <CardDescription>Distribution by product type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={productMixData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    <Cell fill="#3b82f6" />
                    <Cell fill="#10b981" />
                    <Cell fill="#f59e0b" />
                    <Cell fill="#8b5cf6" />
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Patient Demographics</CardTitle>
            <CardDescription>Age distribution</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={demographicsData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="percentage"
                    label={({ age_group, percentage }) => `${age_group}: ${percentage}%`}
                  >
                    {demographicsData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={[
                          "#c084fc", "#a855f7", "#9333ea", 
                          "#7e22ce", "#6b21a8", "#581c87"
                        ][index % 6]} 
                      />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Medical Conditions</CardTitle>
            <CardDescription>Top conditions treated</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={conditionsData}
                  layout="vertical"
                  margin={{ top: 20, right: 30, left: 120, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis type="category" dataKey="condition" tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="patients" name="Patients" fill="#f87171" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}