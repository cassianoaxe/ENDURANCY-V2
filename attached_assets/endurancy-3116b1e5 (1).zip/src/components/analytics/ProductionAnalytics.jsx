import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Zap, Factory, CheckCircle2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import KeyMetricCard from './KeyMetricCard';

// Mock data for production analytics
const productionOutputData = [
  { month: 'Jan', oils: 120, capsules: 80, tinctures: 50, topicals: 30 },
  { month: 'Feb', oils: 125, capsules: 85, tinctures: 48, topicals: 32 },
  { month: 'Mar', oils: 130, capsules: 88, tinctures: 52, topicals: 35 },
  { month: 'Apr', oils: 135, capsules: 92, tinctures: 55, topicals: 38 },
  { month: 'May', oils: 140, capsules: 95, tinctures: 58, topicals: 40 },
  { month: 'Jun', oils: 145, capsules: 98, tinctures: 60, topicals: 42 },
  { month: 'Jul', oils: 150, capsules: 100, tinctures: 62, topicals: 45 },
  { month: 'Aug', oils: 155, capsules: 105, tinctures: 65, topicals: 48 },
  { month: 'Sep', oils: 160, capsules: 110, tinctures: 68, topicals: 50 },
  { month: 'Oct', oils: 165, capsules: 115, tinctures: 70, topicals: 52 },
  { month: 'Nov', oils: 170, capsules: 120, tinctures: 72, topicals: 55 },
  { month: 'Dec', oils: 175, capsules: 125, tinctures: 75, topicals: 58 },
];

const productionQualityData = [
  { month: 'Jan', batches_produced: 45, batches_passed: 42, success_rate: 93.3 },
  { month: 'Feb', batches_produced: 48, batches_passed: 45, success_rate: 93.8 },
  { month: 'Mar', batches_produced: 50, batches_passed: 48, success_rate: 96.0 },
  { month: 'Apr', batches_produced: 52, batches_passed: 50, success_rate: 96.2 },
  { month: 'May', batches_produced: 55, batches_passed: 53, success_rate: 96.4 },
  { month: 'Jun', batches_produced: 58, batches_passed: 56, success_rate: 96.6 },
  { month: 'Jul', batches_produced: 60, batches_passed: 59, success_rate: 98.3 },
  { month: 'Aug', batches_produced: 62, batches_passed: 60, success_rate: 96.8 },
  { month: 'Sep', batches_produced: 65, batches_passed: 63, success_rate: 96.9 },
  { month: 'Oct', batches_produced: 68, batches_passed: 66, success_rate: 97.1 },
  { month: 'Nov', batches_produced: 70, batches_passed: 68, success_rate: 97.1 },
  { month: 'Dec', batches_produced: 72, batches_passed: 71, success_rate: 98.6 },
];

const productionEfficiencyData = [
  { month: 'Jan', units_per_labor_hour: 4.2, setup_time_minutes: 45, wastage_percent: 5.2 },
  { month: 'Feb', units_per_labor_hour: 4.3, setup_time_minutes: 44, wastage_percent: 5.0 },
  { month: 'Mar', units_per_labor_hour: 4.4, setup_time_minutes: 43, wastage_percent: 4.8 },
  { month: 'Apr', units_per_labor_hour: 4.5, setup_time_minutes: 42, wastage_percent: 4.7 },
  { month: 'May', units_per_labor_hour: 4.6, setup_time_minutes: 41, wastage_percent: 4.5 },
  { month: 'Jun', units_per_labor_hour: 4.7, setup_time_minutes: 40, wastage_percent: 4.4 },
  { month: 'Jul', units_per_labor_hour: 4.8, setup_time_minutes: 39, wastage_percent: 4.2 },
  { month: 'Aug', units_per_labor_hour: 4.9, setup_time_minutes: 38, wastage_percent: 4.1 },
  { month: 'Sep', units_per_labor_hour: 5.0, setup_time_minutes: 37, wastage_percent: 4.0 },
  { month: 'Oct', units_per_labor_hour: 5.1, setup_time_minutes: 36, wastage_percent: 3.9 },
  { month: 'Nov', units_per_labor_hour: 5.2, setup_time_minutes: 35, wastage_percent: 3.8 },
  { month: 'Dec', units_per_labor_hour: 5.3, setup_time_minutes: 34, wastage_percent: 3.7 },
];

export default function ProductionAnalytics({ timeRange }) {
  // Filter data based on timeRange if needed
  const getFilteredData = (data) => {
    if (timeRange === 'month') return data.slice(-1);
    if (timeRange === 'quarter') return data.slice(-3);
    return data;
  };
  
  const filteredOutputData = getFilteredData(productionOutputData);
  const filteredQualityData = getFilteredData(productionQualityData);
  const filteredEfficiencyData = getFilteredData(productionEfficiencyData);
  
  // Calculate total units for current period
  const totalUnits = filteredOutputData.reduce((sum, item) => {
    return sum + item.oils + item.capsules + item.tinctures + item.topicals;
  }, 0);
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <KeyMetricCard 
          title="Total Units Produced" 
          value={totalUnits.toLocaleString()} 
          change="+8.7%" 
          period="vs last year"
          trend="up"
          icon={<Factory className="h-5 w-5" />}
          color="blue"
        />
        <KeyMetricCard 
          title="Quality Pass Rate" 
          value="97.1%" 
          change="+1.2%" 
          period="vs last year"
          trend="up"
          icon={<CheckCircle2 className="h-5 w-5" />}
          color="blue"
        />
        <KeyMetricCard 
          title="Production Efficiency" 
          value="5.3 units/hr" 
          change="+12.8%" 
          period="vs last year"
          trend="up"
          icon={<Zap className="h-5 w-5" />}
          color="blue"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Production Output</CardTitle>
            <CardDescription>Units produced by product type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={filteredOutputData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="oils" name="Oils" stackId="a" fill="#3b82f6" />
                  <Bar dataKey="capsules" name="Capsules" stackId="a" fill="#10b981" />
                  <Bar dataKey="tinctures" name="Tinctures" stackId="a" fill="#f59e0b" />
                  <Bar dataKey="topicals" name="Topicals" stackId="a" fill="#8b5cf6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Quality Control</CardTitle>
            <CardDescription>Batches produced vs passed QC</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={filteredQualityData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" domain={[85, 100]} />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    yAxisId="left" 
                    dataKey="batches_produced" 
                    name="Batches Produced" 
                    fill="#3b82f6" 
                  />
                  <Bar 
                    yAxisId="left" 
                    dataKey="batches_passed" 
                    name="Batches Passed QC" 
                    fill="#4ade80" 
                  />
                  <Line 
                    yAxisId="right" 
                    dataKey="success_rate" 
                    name="Pass Rate (%)" 
                    stroke="#f59e0b" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Setup Time</CardTitle>
            <CardDescription>Minutes per batch</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={filteredEfficiencyData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis domain={[30, 50]} />
                  <Tooltip />
                  <Line 
                    dataKey="setup_time_minutes" 
                    name="Setup Time (min)" 
                    stroke="#3b82f6" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Production Efficiency</CardTitle>
            <CardDescription>Units per labor hour</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={filteredEfficiencyData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis domain={[4, 6]} />
                  <Tooltip />
                  <Line 
                    dataKey="units_per_labor_hour" 
                    name="Units per Hour" 
                    stroke="#10b981" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Wastage Rate</CardTitle>
            <CardDescription>Percentage of material wasted</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={filteredEfficiencyData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis domain={[3, 6]} />
                  <Tooltip />
                  <Line 
                    dataKey="wastage_percent" 
                    name="Wastage (%)" 
                    stroke="#ef4444" 
                    strokeWidth={2} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}