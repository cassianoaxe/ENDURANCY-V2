import React from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  Pill,
  Clock,
  Bell,
  MessageSquare,
  Mail,
  Phone,
  MessageCircle,
  Calendar
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';

export default function MedicationReminderCard({ reminder, onEdit, onDelete }) {
  // Format time for display
  const formatTime = (timeString) => {
    const [hours, minutes] = timeString.split(':');
    return `${hours.padStart(2, '0')}:${minutes.padStart(2, '0')}`;
  };

  // Format days of week for display
  const formatDaysOfWeek = (daysArray) => {
    const days = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    return daysArray.map(dayIndex => days[dayIndex]).join(', ');
  };

  // Format frequency for display
  const formatFrequency = () => {
    if (reminder.frequencia === 'diario') return 'Diariamente';
    if (reminder.frequencia === 'dias_especificos') return `${formatDaysOfWeek(reminder.dias_semana)}`;
    if (reminder.frequencia === 'intervalo_dias') return `A cada ${reminder.intervalo_dias} dias`;
    if (reminder.frequencia === 'conforme_necessario') return 'Conforme necessário';
    return '';
  };

  return (
    <Card className="overflow-hidden">
      {/* Color bar on top */}
      <div 
        className="h-2" 
        style={{ backgroundColor: reminder.cor || '#4f46e5' }}
      />
      
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Pill className="h-4 w-4" style={{ color: reminder.cor || '#4f46e5' }} />
              {reminder.medicamento}
            </CardTitle>
            <CardDescription>
              {reminder.dosagem && `${reminder.dosagem} - `}
              {formatFrequency()}
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-2">
          {/* Scheduled times */}
          <div className="flex items-start gap-2">
            <Clock className="h-4 w-4 text-gray-500 mt-0.5" />
            <div>
              <p className="text-sm font-medium">Horários:</p>
              <div className="flex flex-wrap gap-1 mt-1">
                {reminder.horarios.map((horario, idx) => (
                  <Badge key={idx} variant="outline">{formatTime(horario)}</Badge>
                ))}
              </div>
            </div>
          </div>
          
          {/* Instructions if available */}
          {reminder.instrucoes && (
            <div className="flex items-start gap-2">
              <MessageSquare className="h-4 w-4 text-gray-500 mt-0.5" />
              <div>
                <p className="text-sm font-medium">Instruções:</p>
                <p className="text-sm text-gray-600">{reminder.instrucoes}</p>
              </div>
            </div>
          )}
          
          {/* Date range if available */}
          {(reminder.data_inicio || reminder.data_fim) && (
            <div className="flex items-start gap-2">
              <Calendar className="h-4 w-4 text-gray-500 mt-0.5" />
              <div>
                <p className="text-sm font-medium">Período:</p>
                <p className="text-sm text-gray-600">
                  {reminder.data_inicio && format(new Date(reminder.data_inicio), 'dd/MM/yyyy')}
                  {reminder.data_fim && ` até ${format(new Date(reminder.data_fim), 'dd/MM/yyyy')}`}
                </p>
              </div>
            </div>
          )}
          
          {/* Notification types */}
          <div className="flex items-start gap-2">
            <Bell className="h-4 w-4 text-gray-500 mt-0.5" />
            <div>
              <p className="text-sm font-medium">Notificações:</p>
              <div className="flex flex-wrap gap-1 mt-1">
                {reminder.notificacoes.tipo.includes('app') && 
                  <Badge variant="secondary" className="bg-blue-100 text-blue-800">App</Badge>
                }
                {reminder.notificacoes.tipo.includes('email') && 
                  <Badge variant="secondary" className="bg-purple-100 text-purple-800">Email</Badge>
                }
                {reminder.notificacoes.tipo.includes('sms') && 
                  <Badge variant="secondary" className="bg-green-100 text-green-800">SMS</Badge>
                }
                {reminder.notificacoes.tipo.includes('whatsapp') && 
                  <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">WhatsApp</Badge>
                }
              </div>
              {reminder.notificacoes.mensagem_personalizada && (
                <p className="text-xs text-gray-600 mt-1 italic">
                  "{reminder.notificacoes.mensagem_personalizada}"
                </p>
              )}
            </div>
          </div>
        </div>
      </CardContent>
      
      {/* Adherence rate if available */}
      {reminder.estatisticas?.taxa_adesao !== undefined && (
        <CardFooter className="pt-0">
          <div className="w-full">
            <div className="flex justify-between items-center mb-1">
              <span className="text-xs text-gray-500">Taxa de adesão</span>
              <span className="text-xs font-medium">
                {reminder.estatisticas.taxa_adesao}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5">
              <div 
                className="h-1.5 rounded-full" 
                style={{ 
                  width: `${reminder.estatisticas.taxa_adesao}%`,
                  backgroundColor: reminder.cor || '#4f46e5'
                }}
              />
            </div>
          </div>
        </CardFooter>
      )}
    </Card>
  );
}