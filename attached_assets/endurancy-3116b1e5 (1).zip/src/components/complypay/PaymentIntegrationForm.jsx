import React, { useState, useEffect } from 'react';
import { PaymentIntegration } from '@/api/entities';
import {
  CreditCard,
  Shield,
  AlertTriangle,
  ExternalLink,
  Eye,
  EyeOff,
  Loader2,
  RefreshCw,
  Check,
  X,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from '@/components/ui/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function PaymentIntegrationForm({ integration, onSave, onCancel, isNew = false }) {
  const [formData, setFormData] = useState({
    name: '',
    provider: '',
    mode: 'sandbox',
    is_active: true,
    api_key: '',
    api_secret: '',
    merchant_id: '',
    client_id: '',
    client_secret: '',
    webhook_enabled: false,
    webhook_url: '',
    webhook_secret: '',
    supported_methods: [],
    default_currency: 'BRL'
  });
  
  const [isTesting, setIsTesting] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hideSecrets, setHideSecrets] = useState(true);
  const [activeTab, setActiveTab] = useState('credentials');

  useEffect(() => {
    if (integration) {
      setFormData({
        name: integration.name || '',
        provider: integration.provider || '',
        mode: integration.mode || 'sandbox',
        is_active: integration.is_active !== undefined ? integration.is_active : true,
        api_key: integration.api_key || '',
        api_secret: integration.api_secret || '',
        merchant_id: integration.merchant_id || '',
        client_id: integration.client_id || '',
        client_secret: integration.client_secret || '',
        webhook_enabled: integration.webhook_enabled || false,
        webhook_url: integration.webhook_url || '',
        webhook_secret: integration.webhook_secret || '',
        supported_methods: integration.supported_methods || [],
        default_currency: integration.default_currency || 'BRL'
      });
    }
  }, [integration]);

  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCheckboxChange = (method) => {
    setFormData(prev => {
      const methods = [...prev.supported_methods];
      if (methods.includes(method)) {
        return { ...prev, supported_methods: methods.filter(m => m !== method) };
      } else {
        return { ...prev, supported_methods: [...methods, method] };
      }
    });
  };

  const testConnection = async () => {
    setIsTesting(true);
    try {
      // In a real implementation, this would call the API to test the connection
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate API call
      
      // Simulate success for some providers and failure for others
      if (['stripe', 'paypal', 'mercadopago'].includes(formData.provider)) {
        toast({
          title: "Conexão estabelecida",
          description: `Conexão com ${getProviderName(formData.provider)} testada com sucesso.`,
        });
        return true;
      } else {
        toast({
          title: "Falha na conexão",
          description: "Não foi possível conectar com o provedor. Verifique suas credenciais.",
          variant: "destructive"
        });
        return false;
      }
    } catch (error) {
      toast({
        title: "Erro ao testar conexão",
        description: error.message || "Ocorreu um erro ao testar a conexão.",
        variant: "destructive"
      });
      return false;
    } finally {
      setIsTesting(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Optional connection test before saving
      // const connectionSuccess = await testConnection();
      // if (!connectionSuccess) {
      //   if (!confirm("A conexão falhou. Deseja salvar as configurações mesmo assim?")) {
      //     setIsSubmitting(false);
      //     return;
      //   }
      // }
      
      // In a real implementation, this would call the API to save the integration
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      
      // Call the parent component's onSave function
      onSave(formData);
      
      toast({
        title: isNew ? "Integração criada" : "Integração atualizada",
        description: `A integração com ${getProviderName(formData.provider)} foi ${isNew ? 'criada' : 'atualizada'} com sucesso.`
      });
    } catch (error) {
      toast({
        title: "Erro ao salvar integração",
        description: error.message || "Ocorreu um erro ao salvar a integração.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getProviderName = (provider) => {
    const providers = {
      'stripe': 'Stripe',
      'paypal': 'PayPal',
      'pagseguro': 'PagSeguro',
      'mercadopago': 'Mercado Pago',
      'cielo': 'Cielo',
      'rede': 'Rede',
      'stone': 'Stone',
      'custom': 'Personalizado'
    };
    return providers[provider] || provider;
  };

  const getProviderFields = () => {
    switch (formData.provider) {
      case 'stripe':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="api_key">Chave de API Publicável</Label>
              <div className="relative">
                <Input
                  id="api_key"
                  value={formData.api_key}
                  onChange={(e) => handleChange('api_key', e.target.value)}
                  placeholder="pk_test_..."
                />
              </div>
              <p className="text-sm text-gray-500">Encontre em Dashboard &gt; Developers &gt; API keys</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="api_secret">Chave Secreta</Label>
              <div className="relative">
                <Input
                  id="api_secret"
                  type={hideSecrets ? "password" : "text"}
                  value={formData.api_secret}
                  onChange={(e) => handleChange('api_secret', e.target.value)}
                  placeholder="sk_test_..."
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full"
                  onClick={() => setHideSecrets(!hideSecrets)}
                >
                  {hideSecrets ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </>
        );
      
      case 'paypal':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="client_id">Client ID</Label>
              <Input
                id="client_id"
                value={formData.client_id}
                onChange={(e) => handleChange('client_id', e.target.value)}
                placeholder="ATN5eC7n7..."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="client_secret">Client Secret</Label>
              <div className="relative">
                <Input
                  id="client_secret"
                  type={hideSecrets ? "password" : "text"}
                  value={formData.client_secret}
                  onChange={(e) => handleChange('client_secret', e.target.value)}
                  placeholder="ELJ4dAMp6..."
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full"
                  onClick={() => setHideSecrets(!hideSecrets)}
                >
                  {hideSecrets ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </>
        );
      
      case 'pagseguro':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="api_key">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.merchant_id}
                onChange={(e) => handleChange('merchant_id', e.target.value)}
                placeholder="email@seudominio.com.br"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="api_key">Token</Label>
              <div className="relative">
                <Input
                  id="api_key"
                  type={hideSecrets ? "password" : "text"}
                  value={formData.api_key}
                  onChange={(e) => handleChange('api_key', e.target.value)}
                  placeholder="3F0C958D94EC40B1B5F7D685D7EF..."
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full"
                  onClick={() => setHideSecrets(!hideSecrets)}
                >
                  {hideSecrets ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </Button>
              </div>
              <p className="text-sm text-gray-500">Encontre em PagSeguro &gt; Minha Conta &gt; Perfil de Integração</p>
            </div>
          </>
        );
      
      case 'mercadopago':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="client_id">Access Token</Label>
              <div className="relative">
                <Input
                  id="client_id"
                  type={hideSecrets ? "password" : "text"}
                  value={formData.client_id}
                  onChange={(e) => handleChange('client_id', e.target.value)}
                  placeholder="APP_USR-12345678-123456-123456-123456..."
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full"
                  onClick={() => setHideSecrets(!hideSecrets)}
                >
                  {hideSecrets ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </Button>
              </div>
              <p className="text-sm text-gray-500">Encontre em Mercado Pago &gt; Seu negócio &gt; Credenciais</p>
            </div>
          </>
        );
      
      case 'cielo':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="merchant_id">Merchant ID</Label>
              <Input
                id="merchant_id"
                value={formData.merchant_id}
                onChange={(e) => handleChange('merchant_id', e.target.value)}
                placeholder="1234567890123456"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="api_key">Merchant Key</Label>
              <div className="relative">
                <Input
                  id="api_key"
                  type={hideSecrets ? "password" : "text"}
                  value={formData.api_key}
                  onChange={(e) => handleChange('api_key', e.target.value)}
                  placeholder="1234567890ABCDEFGHIJKLMNOPQRSTUVXZ"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full"
                  onClick={() => setHideSecrets(!hideSecrets)}
                >
                  {hideSecrets ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </>
        );
      
      default:
        return (
          <div className="flex items-center justify-center p-6">
            <p className="text-gray-500">Selecione um provedor para ver as opções de configuração</p>
          </div>
        );
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-3">
          <TabsTrigger value="basic">Informações Básicas</TabsTrigger>
          <TabsTrigger value="credentials">Credenciais</TabsTrigger>
          <TabsTrigger value="webhooks">Webhooks e Métodos</TabsTrigger>
        </TabsList>
        
        <TabsContent value="basic" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações Básicas</CardTitle>
              <CardDescription>Configure as informações básicas da integração de pagamento</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Nome da Integração</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  placeholder="Pagamentos com Stripe"
                  required
                />
                <p className="text-sm text-gray-500">Um nome amigável para identificar esta integração</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="provider">Provedor de Pagamento</Label>
                <Select
                  value={formData.provider}
                  onValueChange={(value) => handleChange('provider', value)}
                  required
                >
                  <SelectTrigger id="provider">
                    <SelectValue placeholder="Selecione um provedor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="stripe">Stripe</SelectItem>
                    <SelectItem value="paypal">PayPal</SelectItem>
                    <SelectItem value="pagseguro">PagSeguro</SelectItem>
                    <SelectItem value="mercadopago">Mercado Pago</SelectItem>
                    <SelectItem value="cielo">Cielo</SelectItem>
                    <SelectItem value="rede">Rede</SelectItem>
                    <SelectItem value="stone">Stone</SelectItem>
                    <SelectItem value="custom">Personalizado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Ambiente</Label>
                <RadioGroup
                  value={formData.mode}
                  onValueChange={(value) => handleChange('mode', value)}
                  className="flex space-x-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="sandbox" id="sandbox" />
                    <Label htmlFor="sandbox" className="cursor-pointer">Sandbox (Testes)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="production" id="production" />
                    <Label htmlFor="production" className="cursor-pointer">Produção</Label>
                  </div>
                </RadioGroup>
                
                {formData.mode === 'production' && (
                  <Alert variant="warning" className="mt-4">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Aviso de Produção</AlertTitle>
                    <AlertDescription>
                      No ambiente de produção, as transações serão reais e os clientes serão cobrados. Certifique-se de que todas as configurações estão corretas.
                    </AlertDescription>
                  </Alert>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="default_currency">Moeda Padrão</Label>
                <Select
                  value={formData.default_currency}
                  onValueChange={(value) => handleChange('default_currency', value)}
                >
                  <SelectTrigger id="default_currency">
                    <SelectValue placeholder="Selecione a moeda padrão" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BRL">Real Brasileiro (BRL)</SelectItem>
                    <SelectItem value="USD">Dólar Americano (USD)</SelectItem>
                    <SelectItem value="EUR">Euro (EUR)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="is_active">Status da Integração</Label>
                  <p className="text-sm text-gray-500">Ativar ou desativar esta integração de pagamento</p>
                </div>
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => handleChange('is_active', checked)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="credentials" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Credenciais</CardTitle>
              <CardDescription>Configure as credenciais para autenticação com o provedor de pagamento</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {getProviderFields()}
              
              {formData.provider && (
                <div className="flex justify-end">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={testConnection}
                    disabled={isTesting}
                  >
                    {isTesting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Testando...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Testar Conexão
                      </>
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="webhooks" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Webhooks</CardTitle>
              <CardDescription>Configure webhooks para receber notificações do provedor de pagamento</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="webhook_enabled">Habilitar Webhooks</Label>
                  <p className="text-sm text-gray-500">Receba notificações de eventos de pagamento em tempo real</p>
                </div>
                <Switch
                  id="webhook_enabled"
                  checked={formData.webhook_enabled}
                  onCheckedChange={(checked) => handleChange('webhook_enabled', checked)}
                />
              </div>
              
              {formData.webhook_enabled && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="webhook_url">URL do Webhook</Label>
                    <Input
                      id="webhook_url"
                      value={formData.webhook_url}
                      onChange={(e) => handleChange('webhook_url', e.target.value)}
                      placeholder="https://api.suaorganizacao.com.br/webhooks/pagamentos"
                    />
                    <p className="text-sm text-gray-500">URL para onde o provedor enviará as notificações</p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="webhook_secret">Segredo do Webhook</Label>
                    <div className="relative">
                      <Input
                        id="webhook_secret"
                        type={hideSecrets ? "password" : "text"}
                        value={formData.webhook_secret}
                        onChange={(e) => handleChange('webhook_secret', e.target.value)}
                        placeholder="whsec_..."
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full"
                        onClick={() => setHideSecrets(!hideSecrets)}
                      >
                        {hideSecrets ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                      </Button>
                    </div>
                    <p className="text-sm text-gray-500">Usado para verificar a autenticidade das notificações</p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Métodos de Pagamento</CardTitle>
              <CardDescription>Selecione os métodos de pagamento que deseja habilitar</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="credit_card"
                    checked={formData.supported_methods.includes('credit_card')}
                    onCheckedChange={() => handleCheckboxChange('credit_card')}
                  />
                  <Label htmlFor="credit_card" className="cursor-pointer">Cartão de Crédito</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="debit_card"
                    checked={formData.supported_methods.includes('debit_card')}
                    onCheckedChange={() => handleCheckboxChange('debit_card')}
                  />
                  <Label htmlFor="debit_card" className="cursor-pointer">Cartão de Débito</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="boleto"
                    checked={formData.supported_methods.includes('boleto')}
                    onCheckedChange={() => handleCheckboxChange('boleto')}
                  />
                  <Label htmlFor="boleto" className="cursor-pointer">Boleto Bancário</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="pix"
                    checked={formData.supported_methods.includes('pix')}
                    onCheckedChange={() => handleCheckboxChange('pix')}
                  />
                  <Label htmlFor="pix" className="cursor-pointer">PIX</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="bank_transfer"
                    checked={formData.supported_methods.includes('bank_transfer')}
                    onCheckedChange={() => handleCheckboxChange('bank_transfer')}
                  />
                  <Label htmlFor="bank_transfer" className="cursor-pointer">Transferência Bancária</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="installments"
                    checked={formData.supported_methods.includes('installments')}
                    onCheckedChange={() => handleCheckboxChange('installments')}
                  />
                  <Label htmlFor="installments" className="cursor-pointer">Parcelamento</Label>
                </div>
              </div>
              
              {formData.supported_methods.length === 0 && (
                <Alert className="mt-4">
                  <Info className="h-4 w-4" />
                  <AlertTitle>Nenhum método selecionado</AlertTitle>
                  <AlertDescription>
                    Selecione pelo menos um método de pagamento para habilitar na sua integração.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="flex justify-end space-x-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={isSubmitting}
        >
          Cancelar
        </Button>
        <Button
          type="submit"
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {isNew ? 'Criando...' : 'Salvando...'}
            </>
          ) : (
            <>
              <Check className="mr-2 h-4 w-4" />
              {isNew ? 'Criar Integração' : 'Salvar Alterações'}
            </>
          )}
        </Button>
      </div>
    </form>
  );
}