import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Building2, 
  Users, 
  Mail, 
  Phone, 
  MapPin, 
  FileText, 
  Plus,
  Save,
  ArrowRight
} from "lucide-react";

export default function OrganizationForm({ onSubmit, onCancel, initialData = {} }) {
  const [formData, setFormData] = useState({
    name: initialData.name || '',
    type: initialData.type || 'Empresa',
    plan: initialData.plan || '',
    contactName: initialData.contactName || '',
    contactEmail: initialData.contactEmail || '',
    contactPhone: initialData.contactPhone || '',
    contactPosition: initialData.contactPosition || '',
    address: initialData.address || {
      street: '',
      city: '',
      state: '',
      zip: '',
      country: 'Brasil'
    },
    description: initialData.description || '',
    ...initialData
  });

  const [currentTab, setCurrentTab] = useState('basic');
  const [documents, setDocuments] = useState(initialData.documents || []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAddressChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      address: {
        ...prev.address,
        [name]: value
      }
    }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      documents
    });
  };

  const handleDocumentAdd = () => {
    setDocuments(prev => [
      ...prev,
      { type: '', number: '', file: null }
    ]);
  };

  const handleDocumentChange = (index, field, value) => {
    const updatedDocs = [...documents];
    updatedDocs[index] = {
      ...updatedDocs[index],
      [field]: value
    };
    setDocuments(updatedDocs);
  };

  const handleDocumentRemove = (index) => {
    setDocuments(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle className="text-xl">{initialData.id ? 'Editar Organização' : 'Nova Organização'}</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="basic">Informações Básicas</TabsTrigger>
              <TabsTrigger value="contact">Contato</TabsTrigger>
              <TabsTrigger value="address">Endereço</TabsTrigger>
              <TabsTrigger value="documents">Documentos</TabsTrigger>
            </TabsList>
            
            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome da Organização</Label>
                  <div className="flex">
                    <div className="bg-gray-100 p-2 rounded-l-md flex items-center">
                      <Building2 className="h-5 w-5 text-gray-500" />
                    </div>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Nome da organização"
                      className="rounded-l-none"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Tipo</Label>
                    <Select 
                      value={formData.type} 
                      onValueChange={(value) => handleSelectChange('type', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Empresa">Empresa</SelectItem>
                        <SelectItem value="Associação">Associação</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="plan">Plano</Label>
                    <Select 
                      value={formData.plan} 
                      onValueChange={(value) => handleSelectChange('plan', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o plano" />
                      </SelectTrigger>
                      <SelectContent>
                        {formData.type === 'Empresa' ? (
                          <>
                            <SelectItem value="Empresarial Básico">Empresarial Básico</SelectItem>
                            <SelectItem value="Empresarial Pro">Empresarial Pro</SelectItem>
                          </>
                        ) : (
                          <>
                            <SelectItem value="Associação Plus">Associação Plus</SelectItem>
                            <SelectItem value="Associação Premium">Associação Premium</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Descreva a organização"
                    rows={4}
                  />
                </div>
              </div>
              
              <div className="flex justify-end mt-4">
                <Button 
                  type="button" 
                  className="gap-2"
                  onClick={() => setCurrentTab('contact')}
                >
                  Próximo
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="contact" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="contactName">Nome do Contato</Label>
                <div className="flex">
                  <div className="bg-gray-100 p-2 rounded-l-md flex items-center">
                    <Users className="h-5 w-5 text-gray-500" />
                  </div>
                  <Input
                    id="contactName"
                    name="contactName"
                    value={formData.contactName}
                    onChange={handleInputChange}
                    placeholder="Nome completo"
                    className="rounded-l-none"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="contactPosition">Cargo</Label>
                <Input
                  id="contactPosition"
                  name="contactPosition"
                  value={formData.contactPosition}
                  onChange={handleInputChange}
                  placeholder="Cargo na organização"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="contactEmail">Email</Label>
                <div className="flex">
                  <div className="bg-gray-100 p-2 rounded-l-md flex items-center">
                    <Mail className="h-5 w-5 text-gray-500" />
                  </div>
                  <Input
                    id="contactEmail"
                    name="contactEmail"
                    type="email"
                    value={formData.contactEmail}
                    onChange={handleInputChange}
                    placeholder="email@exemplo.com"
                    className="rounded-l-none"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="contactPhone">Telefone</Label>
                <div className="flex">
                  <div className="bg-gray-100 p-2 rounded-l-md flex items-center">
                    <Phone className="h-5 w-5 text-gray-500" />
                  </div>
                  <Input
                    id="contactPhone"
                    name="contactPhone"
                    value={formData.contactPhone}
                    onChange={handleInputChange}
                    placeholder="+55 (11) 98765-4321"
                    className="rounded-l-none"
                  />
                </div>
              </div>
              
              <div className="flex justify-between mt-4">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setCurrentTab('basic')}
                >
                  Voltar
                </Button>
                <Button 
                  type="button" 
                  className="gap-2"
                  onClick={() => setCurrentTab('address')}
                >
                  Próximo
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="address" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="street">Rua/Avenida</Label>
                <div className="flex">
                  <div className="bg-gray-100 p-2 rounded-l-md flex items-center">
                    <MapPin className="h-5 w-5 text-gray-500" />
                  </div>
                  <Input
                    id="street"
                    name="street"
                    value={formData.address.street}
                    onChange={handleAddressChange}
                    placeholder="Rua, número, complemento"
                    className="rounded-l-none"
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">Cidade</Label>
                  <Input
                    id="city"
                    name="city"
                    value={formData.address.city}
                    onChange={handleAddressChange}
                    placeholder="Cidade"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="state">Estado</Label>
                  <Input
                    id="state"
                    name="state"
                    value={formData.address.state}
                    onChange={handleAddressChange}
                    placeholder="Estado"
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="zip">CEP</Label>
                  <Input
                    id="zip"
                    name="zip"
                    value={formData.address.zip}
                    onChange={handleAddressChange}
                    placeholder="00000-000"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="country">País</Label>
                  <Input
                    id="country"
                    name="country"
                    value={formData.address.country}
                    onChange={handleAddressChange}
                    placeholder="País"
                    required
                  />
                </div>
              </div>
              
              <div className="flex justify-between mt-4">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setCurrentTab('contact')}
                >
                  Voltar
                </Button>
                <Button 
                  type="button" 
                  className="gap-2"
                  onClick={() => setCurrentTab('documents')}
                >
                  Próximo
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="documents" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Documentos</h3>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  className="gap-2"
                  onClick={handleDocumentAdd}
                >
                  <Plus className="w-4 h-4" />
                  Adicionar Documento
                </Button>
              </div>
              
              {documents.length === 0 ? (
                <div className="text-center py-8 border rounded-md">
                  <FileText className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-500">Nenhum documento adicionado</p>
                  <p className="text-sm text-gray-400">Clique em "Adicionar Documento" para começar</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {documents.map((doc, index) => (
                    <div key={index} className="p-4 border rounded-md">
                      <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-gray-500" />
                          <h4 className="font-medium">Documento {index + 1}</h4>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="text-red-500 h-8"
                          onClick={() => handleDocumentRemove(index)}
                        >
                          Remover
                        </Button>
                      </div>
                      
                      <div className="grid gap-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Tipo de Documento</Label>
                            <Select
                              value={doc.type}
                              onValueChange={(value) => handleDocumentChange(index, 'type', value)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione o tipo" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="CNPJ">CNPJ</SelectItem>
                                <SelectItem value="Alvará de Funcionamento">Alvará de Funcionamento</SelectItem>
                                <SelectItem value="Licença Sanitária">Licença Sanitária</SelectItem>
                                <SelectItem value="Contrato Social">Contrato Social</SelectItem>
                                <SelectItem value="Outro">Outro</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div className="space-y-2">
                            <Label>Número do Documento</Label>
                            <Input
                              value={doc.number}
                              onChange={(e) => handleDocumentChange(index, 'number', e.target.value)}
                              placeholder="Número ou identificador"
                            />
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <Label>Arquivo</Label>
                          <Input
                            type="file"
                            onChange={(e) => handleDocumentChange(index, 'file', e.target.files[0])}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              <div className="flex justify-between mt-4">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setCurrentTab('address')}
                >
                  Voltar
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button 
            type="button"
            variant="outline"
            onClick={onCancel}
          >
            Cancelar
          </Button>
          <Button 
            type="submit"
            className="bg-green-600 hover:bg-green-700 gap-2"
          >
            <Save className="w-4 h-4" />
            {initialData.id ? 'Atualizar' : 'Criar'} Organização
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}