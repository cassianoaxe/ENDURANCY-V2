import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { format, parseISO, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  FileText,
  CheckCircle,
  XCircle,
  AlertCircle,
  MessageSquare,
  Bell
} from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';

export default function NotificacaoPrescricao({ notification, onMarkAsRead }) {
  const navigate = useNavigate();

  const formatRelativeTime = (dateString) => {
    try {
      const date = parseISO(dateString);
      return formatDistanceToNow(date, { addSuffix: true, locale: ptBR });
    } catch (e) {
      return dateString;
    }
  };

  const getNotificationIcon = () => {
    switch (notification.tipo) {
      case 'nova_prescricao':
        return <FileText className="h-4 w-4 text-blue-500" />;
      case 'aprovada':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'rejeitada':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'alteracao_solicitada':
        return <AlertCircle className="h-4 w-4 text-amber-500" />;
      case 'comentario_adicionado':
        return <MessageSquare className="h-4 w-4 text-indigo-500" />;
      default:
        return <Bell className="h-4 w-4 text-gray-500" />;
    }
  };

  const getIconBackgroundColor = () => {
    switch (notification.tipo) {
      case 'nova_prescricao':
        return 'bg-blue-100';
      case 'aprovada':
        return 'bg-green-100';
      case 'rejeitada':
        return 'bg-red-100';
      case 'alteracao_solicitada':
        return 'bg-amber-100';
      case 'comentario_adicionado':
        return 'bg-indigo-100';
      default:
        return 'bg-gray-100';
    }
  };

  const handleClick = () => {
    if (onMarkAsRead) {
      onMarkAsRead(notification.id);
    }
    if (notification.acao_url) {
      navigate(notification.acao_url);
    } else if (notification.prescricao_id) {
      navigate(createPageUrl(`StatusPrescricao/${notification.prescricao_id}`));
    }
  };

  return (
    <div 
      className={`p-4 border-b last:border-b-0 cursor-pointer hover:bg-gray-50 transition-colors ${!notification.lida ? 'bg-gray-50' : ''}`}
      onClick={handleClick}
    >
      <div className="flex items-start gap-3">
        <div className={`p-2 rounded-full flex-shrink-0 ${getIconBackgroundColor()}`}>
          {getNotificationIcon()}
        </div>
        
        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-sm">{notification.titulo}</h4>
          <p className="text-sm text-gray-600 line-clamp-2 mt-1">
            {notification.mensagem}
          </p>
          
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-gray-500">
              {formatRelativeTime(notification.data_envio)}
            </span>
            
            {!notification.lida && (
              <span className="inline-block w-2 h-2 bg-blue-500 rounded-full"></span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}