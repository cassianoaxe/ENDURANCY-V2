import React, { useState, useEffect } from 'react';
import { Associado } from '@/api/entities';
import { Cliente } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Spinner } from "@/components/ui/spinner";
import { AlertCircle, CheckCircle2, AlertTriangle, Search } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

/**
 * Componente para validar CPF antes de criar prescrição
 * Verifica se o paciente está cadastrado e tem CPF válido
 */
export default function ValidadorPrescricao({ 
  cpf, 
  tipoEntidade = "todos", 
  onValidationResult, 
  onSelectPaciente 
}) {
  const [isLoading, setIsLoading] = useState(false);
  const [resultado, setResultado] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  
  // Limpa resultados quando o CPF muda
  useEffect(() => {
    setResultado(null);
    setErrorMessage("");
  }, [cpf]);
  
  // Remove formatação (pontos e traços) do CPF
  const removeMask = (cpf) => {
    return cpf ? cpf.replace(/\D/g, '') : '';
  };
  
  const validarCPF = async () => {
    const cpfLimpo = removeMask(cpf);
    
    if (!cpfLimpo || cpfLimpo.length !== 11) {
      setErrorMessage("Por favor, informe um CPF válido com 11 dígitos");
      toast({
        title: "CPF Inválido",
        description: "O CPF deve conter 11 dígitos",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    setErrorMessage("");
    
    try {
      // Primeira verificação - Algoritmo de validação do CPF
      if (!isValidCPFAlgoritmo(cpfLimpo)) {
        setErrorMessage("CPF com formato inválido");
        if (onValidationResult) {
          onValidationResult({ 
            valid: false, 
            message: "CPF com formato inválido",
            cpfValido: false
          });
        }
        toast({
          title: "CPF Inválido",
          description: "O formato do CPF informado é inválido",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }
      
      // Simula validação na Receita Federal
      await simulateReceitaValidation(cpfLimpo);
      
      // Busca associado ou cliente com este CPF
      let pacienteEncontrado = null;
      
      if (tipoEntidade === "todos" || tipoEntidade === "associado") {
        try {
          const associados = await Associado.filter({ cpf: formatCPF(cpfLimpo) });
          if (associados && associados.length > 0) {
            pacienteEncontrado = {
              ...associados[0],
              tipo: "associado"
            };
          }
        } catch (error) {
          console.error("Erro ao buscar associado:", error);
        }
      }
      
      if (!pacienteEncontrado && (tipoEntidade === "todos" || tipoEntidade === "cliente")) {
        try {
          const clientes = await Cliente.filter({ cpf: formatCPF(cpfLimpo) });
          if (clientes && clientes.length > 0) {
            pacienteEncontrado = {
              ...clientes[0],
              tipo: "cliente"
            };
          }
        } catch (error) {
          console.error("Erro ao buscar cliente:", error);
        }
      }
      
      if (pacienteEncontrado) {
        setResultado({
          paciente: pacienteEncontrado,
          cpfValido: true
        });
        
        if (onValidationResult) {
          onValidationResult({ 
            valid: true, 
            message: "CPF válido e paciente encontrado",
            paciente: pacienteEncontrado,
            cpfValido: true
          });
        }
        
        if (onSelectPaciente) {
          onSelectPaciente(pacienteEncontrado);
        }
        
        toast({
          title: "Paciente encontrado",
          description: `Paciente ${pacienteEncontrado.nome_completo} encontrado com sucesso`,
        });
      } else {
        setResultado({
          paciente: null,
          cpfValido: true
        });
        
        if (onValidationResult) {
          onValidationResult({ 
            valid: false, 
            message: "CPF válido, mas paciente não encontrado",
            cpfValido: true
          });
        }
        
        toast({
          title: "Paciente não encontrado",
          description: "O CPF é válido, mas não foi encontrado paciente cadastrado com este CPF",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Erro na validação:", error);
      setErrorMessage(error.message || "Erro ao validar CPF");
      
      if (onValidationResult) {
        onValidationResult({ 
          valid: false, 
          message: error.message || "Erro ao validar CPF",
          cpfValido: false
        });
      }
      
      toast({
        title: "Erro na validação",
        description: error.message || "Não foi possível validar o CPF",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Formata o CPF com pontos e traço (123.456.789-00)
  const formatCPF = (cpf) => {
    cpf = removeMask(cpf);
    if (cpf.length <= 3) return cpf;
    if (cpf.length <= 6) return cpf.replace(/(\d{3})(\d{0,3})/, '$1.$2');
    if (cpf.length <= 9) return cpf.replace(/(\d{3})(\d{3})(\d{0,3})/, '$1.$2.$3');
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{0,2})/, '$1.$2.$3-$4');
  };
  
  // Verifica se o CPF é válido (algoritmo)
  const isValidCPFAlgoritmo = (cpf) => {
    // Verifica se tem 11 dígitos
    if (cpf.length !== 11) return false;
    
    // Verifica se todos os dígitos são iguais (CPFs inválidos conhecidos)
    if (/^(\d)\1+$/.test(cpf)) return false;
    
    // Validação do primeiro dígito verificador
    let soma = 0;
    for (let i = 0; i < 9; i++) {
      soma += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let resto = 11 - (soma % 11);
    let dv1 = resto >= 10 ? 0 : resto;
    
    if (dv1 !== parseInt(cpf.charAt(9))) return false;
    
    // Validação do segundo dígito verificador
    soma = 0;
    for (let i = 0; i < 10; i++) {
      soma += parseInt(cpf.charAt(i)) * (11 - i);
    }
    resto = 11 - (soma % 11);
    let dv2 = resto >= 10 ? 0 : resto;
    
    return dv2 === parseInt(cpf.charAt(10));
  };
  
  // Simula validação do CPF na Receita Federal
  const simulateReceitaValidation = async (cpf) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simula uma chance de 90% de sucesso
        const isValid = Math.random() < 0.9;
        
        if (isValid) {
          resolve({
            valid: true,
            message: "CPF validado com sucesso na Receita Federal"
          });
        } else {
          reject({
            message: "CPF não encontrado na base da Receita Federal"
          });
        }
      }, 1500);
    });
  };
  
  return (
    <div className="space-y-4">
      <Button 
        type="button" 
        variant="default" 
        onClick={validarCPF}
        disabled={isLoading || !cpf || removeMask(cpf).length !== 11}
        className="w-full md:w-auto flex items-center gap-2"
      >
        {isLoading ? (
          <Spinner size="small" className="mr-2" />
        ) : (
          <Search className="h-4 w-4 mr-2" />
        )}
        {isLoading ? "Validando CPF..." : "Validar CPF e Buscar Paciente"}
      </Button>
      
      {errorMessage && (
        <Card className="border-red-200 bg-red-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-red-800 flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              Erro na validação
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-red-700">{errorMessage}</p>
          </CardContent>
        </Card>
      )}
      
      {resultado && (
        <Card className={resultado.paciente ? "border-green-200 bg-green-50" : "border-yellow-200 bg-yellow-50"}>
          <CardHeader className="pb-2">
            <CardTitle className={`text-sm font-medium flex items-center gap-2 ${resultado.paciente ? "text-green-800" : "text-yellow-800"}`}>
              {resultado.paciente ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                <AlertTriangle className="h-4 w-4" />
              )}
              {resultado.paciente 
                ? "Paciente encontrado" 
                : "CPF válido, paciente não encontrado"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {resultado.paciente ? (
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs text-gray-500">Nome</Label>
                    <p className="text-sm font-medium">{resultado.paciente.nome_completo}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-gray-500">Tipo</Label>
                    <p className="text-sm font-medium capitalize">{resultado.paciente.tipo}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs text-gray-500">Email</Label>
                    <p className="text-sm">{resultado.paciente.email}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-gray-500">Telefone</Label>
                    <p className="text-sm">{resultado.paciente.telefone}</p>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-sm">
                O CPF é válido, mas não encontramos nenhum paciente cadastrado com este CPF.
                Cadastre o paciente antes de prosseguir com a prescrição.
              </p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}