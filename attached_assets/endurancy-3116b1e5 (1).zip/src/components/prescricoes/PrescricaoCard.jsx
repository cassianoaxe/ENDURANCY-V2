import React from 'react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  FileText,
  Calendar,
  User,
  ChevronRight,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import StatusTracking from './StatusTracking';

export default function PrescricaoCard({ prescricao }) {
  const navigate = useNavigate();

  const formatDate = (dateString) => {
    try {
      return format(parseISO(dateString), "dd/MM/yyyy", { locale: ptBR });
    } catch (e) {
      return dateString || "Data não disponível";
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pendente':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Pendente</Badge>;
      case 'aprovada':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Aprovada</Badge>;
      case 'rejeitada':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Rejeitada</Badge>;
      case 'solicitado_alteracao':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Alteração solicitada</Badge>;
      default:
        return <Badge variant="outline">Desconhecido</Badge>;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pendente':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'aprovada':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'rejeitada':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'solicitado_alteracao':
        return <AlertCircle className="h-5 w-5 text-blue-500" />;
      default:
        return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };

  const handleClick = () => {
    navigate(createPageUrl(`StatusPrescricao/${prescricao.id}`));
  };

  const hasNewActivity = prescricao.has_new_activity || false;

  return (
    <Card 
      className={`hover:shadow-md transition-shadow cursor-pointer ${hasNewActivity ? 'border-blue-300' : ''}`}
      onClick={handleClick}
    >
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div className="flex gap-3 items-start">
            <div className={`p-2 rounded-full ${
              prescricao.status === 'pendente' ? 'bg-yellow-100' : 
              prescricao.status === 'aprovada' ? 'bg-green-100' : 
              prescricao.status === 'rejeitada' ? 'bg-red-100' : 
              prescricao.status === 'solicitado_alteracao' ? 'bg-blue-100' : 'bg-gray-100'
            }`}>
              {getStatusIcon(prescricao.status)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-medium">Prescrição #{prescricao.id}</h3>
                {hasNewActivity && (
                  <Badge className="bg-blue-500 text-white px-2 py-0 text-xs">Nova</Badge>
                )}
              </div>
              <div className="flex items-center text-sm text-gray-500 mt-1">
                <Calendar className="h-3.5 w-3.5 mr-1" />
                <span>Enviada em {formatDate(prescricao.data_envio)}</span>
              </div>
            </div>
          </div>
          {getStatusBadge(prescricao.status)}
        </div>

        <div className="flex items-center text-sm text-gray-600 mb-4">
          <User className="h-3.5 w-3.5 mr-1" />
          <span>{prescricao.dados_medico?.nome || "Médico não especificado"}</span>
          {prescricao.dados_medico?.crm && (
            <span className="ml-1">({prescricao.dados_medico.crm})</span>
          )}
        </div>

        <StatusTracking 
          status={prescricao.status} 
          historico={prescricao.historico_status || []} 
          className="mb-4"
        />

        <div className="flex justify-between items-center pt-2">
          <div>
            <p className="text-xs text-gray-500">Validade</p>
            <p className="text-sm">{formatDate(prescricao.validade_prescricao)}</p>
          </div>
          <Button variant="ghost" size="sm" className="gap-1">
            <span className="text-sm">Ver detalhes</span>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}