import React from 'react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  CheckCircle,
  Clock,
  XCircle,
  AlertCircle,
  FileText
} from 'lucide-react';

export default function StatusTracking({ status, historico = [], className = "" }) {
  // Map status to step number
  const getStepFromStatus = (statusValue) => {
    switch (statusValue) {
      case 'pendente': return 1;
      case 'em_analise': return 2;
      case 'aprovada': return 3;
      case 'rejeitada': return 3;
      case 'solicitado_alteracao': return 2;
      default: return 0;
    }
  };

  const currentStep = getStepFromStatus(status);

  const formatDate = (dateString) => {
    if (!dateString) return "";
    try {
      return format(parseISO(dateString), "dd/MM/yyyy", { locale: ptBR });
    } catch (e) {
      return dateString;
    }
  };

  // Find dates for each step
  const getDateForStatus = (statusValue) => {
    const historyItem = historico.find(item => item.status === statusValue);
    return historyItem ? formatDate(historyItem.data) : null;
  };

  const envioDate = getDateForStatus('pendente');
  const analiseDate = getDateForStatus('em_analise');
  const finalizacaoDate = getDateForStatus('aprovada') || getDateForStatus('rejeitada');

  const getStatusIcon = (stepNumber) => {
    if (stepNumber < currentStep) {
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    }
    if (stepNumber === currentStep) {
      if (status === 'rejeitada') {
        return <XCircle className="h-5 w-5 text-red-500" />;
      }
      if (status === 'solicitado_alteracao') {
        return <AlertCircle className="h-5 w-5 text-blue-500" />;
      }
      return <Clock className="h-5 w-5 text-blue-500" />;
    }
    return <FileText className="h-5 w-5 text-gray-300" />;
  };

  return (
    <div className={`w-full ${className}`}>
      <div className="flex justify-between items-center mb-2">
        <div className="flex flex-col items-center">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
            currentStep >= 1 ? 'bg-green-100' : 'bg-gray-100'
          }`}>
            {getStatusIcon(1)}
          </div>
          <span className="text-xs font-medium">Enviada</span>
          {envioDate && <span className="text-xs text-gray-500">{envioDate}</span>}
        </div>
        
        <div className={`flex-1 h-1 mx-2 ${
          currentStep >= 2 ? 'bg-green-300' : 'bg-gray-200'
        }`}></div>
        
        <div className="flex flex-col items-center">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
            currentStep >= 2 ? status === 'solicitado_alteracao' ? 'bg-blue-100' : 'bg-green-100' : 'bg-gray-100'
          }`}>
            {getStatusIcon(2)}
          </div>
          <span className="text-xs font-medium">Em análise</span>
          {analiseDate && <span className="text-xs text-gray-500">{analiseDate}</span>}
        </div>
        
        <div className={`flex-1 h-1 mx-2 ${
          currentStep >= 3 ? status === 'rejeitada' ? 'bg-red-300' : 'bg-green-300' : 'bg-gray-200'
        }`}></div>
        
        <div className="flex flex-col items-center">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
            currentStep >= 3 ? status === 'rejeitada' ? 'bg-red-100' : 'bg-green-100' : 'bg-gray-100'
          }`}>
            {getStatusIcon(3)}
          </div>
          <span className="text-xs font-medium">
            {status === 'rejeitada' ? 'Rejeitada' : 'Aprovada'}
          </span>
          {finalizacaoDate && <span className="text-xs text-gray-500">{finalizacaoDate}</span>}
        </div>
      </div>
    </div>
  );
}