
import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { 
  LayoutDashboard, Video, Users, ClipboardList, Brain, DollarSign, 
  Settings, Calendar, FileText, LogOut
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/use-toast";

const doctorNavigationLinks = [
  {
    name: "Dashboard",
    path: "DoctorDashboard",
    icon: LayoutDashboard
  },
  {
    name: "Pacientes",
    path: "DoctorPatients",
    icon: Users
  },
  {
    name: "Consultas",
    path: "DoctorAppointments",
    icon: Calendar
  },
  {
    name: "Prescrições",
    path: "DoctorPrescriptions",
    icon: FileText
  },
  {
    name: "Telemedicina",
    path: "ConsultaVirtual",
    icon: Video
  },
  {
    name: "Financeiro",
    path: "DoctorFinancial",
    icon: DollarSign
  },
  {
    name: "Configurações",
    path: "DoctorSettings",
    icon: Settings
  }
];

export default function DoctorLayout({ children }) {
  const navigate = useNavigate();
  const location = useLocation();
  const currentPath = location.pathname.split('/').pop();

  const handleLogout = async () => {
    try {
      sessionStorage.setItem('isLoggingOut', 'true');

      try {
        localStorage.removeItem('mockUserType');
        localStorage.removeItem('mockUserEmail');
        localStorage.removeItem('mockUserName');
        localStorage.removeItem('mockOrgType');
      } catch (e) {
        console.error("Error clearing local storage:", e);
      }

      try {
        await User.logout();
      } catch (e) {
        console.log("Regular logout failed, but continuing with local logout");
      }

      window.location.replace('/Access');
    } catch (error) {
      console.error("Error during logout:", error);
      window.location.replace('/Access');
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <nav className="hidden md:block w-64 bg-white border-r border-gray-200 min-h-screen fixed">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center">
              <span className="text-pink-600 font-bold">EC</span>
            </div>
            <span className="ml-2 text-xl font-semibold">Portal Médico</span>
          </div>
        </div>

        <div className="p-4 flex flex-col h-[calc(100vh-80px)] justify-between">
          <div>
            {doctorNavigationLinks.map((link) => {
              const Icon = link.icon;
              const isActive = currentPath === link.path;
              
              return (
                <Link
                  key={link.path}
                  to={createPageUrl(link.path)}
                  className={`flex items-center px-4 py-2 rounded-lg mb-1 ${
                    isActive 
                      ? 'bg-pink-50 text-pink-600' 
                      : 'text-gray-700 hover:bg-pink-50 hover:text-pink-600'
                  }`}
                >
                  <Icon className="h-5 w-5 mr-3" />
                  <span>{link.name}</span>
                </Link>
              );
            })}
          </div>
          
          <div className="mt-auto pb-4">
            <Button 
              variant="ghost" 
              className="w-full flex items-center px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5 mr-3" />
              <span>Sair</span>
            </Button>
          </div>
        </div>
      </nav>

      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-10">
        <div className="flex justify-around items-center p-2">
          {doctorNavigationLinks.slice(0, 5).map((link) => {
            const Icon = link.icon;
            const isActive = currentPath === link.path;
            
            return (
              <Link
                key={link.path}
                to={createPageUrl(link.path)}
                className={`flex flex-col items-center p-2 ${
                  isActive 
                    ? 'text-pink-600' 
                    : 'text-gray-700'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="text-xs mt-1">{link.name}</span>
              </Link>
            );
          })}
          
          <Button 
            variant="ghost" 
            className="flex flex-col items-center p-2 text-red-600"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5" />
            <span className="text-xs mt-1">Sair</span>
          </Button>
        </div>
      </div>

      <main className="flex-1 md:ml-64 p-4 pb-16 md:pb-4">
        {children}
      </main>
    </div>
  );
}
