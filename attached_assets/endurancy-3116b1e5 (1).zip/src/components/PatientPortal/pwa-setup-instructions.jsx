
export default `# Guia de Configuração e Instalação do PWA - Portal do Paciente

Este guia fornece instruções detalhadas para pacientes e organizações sobre como configurar, instalar e utilizar o Portal do Paciente Endurancy como uma Progressive Web App (PWA).

## Para Pacientes

### Instalando o Portal do Paciente no seu Dispositivo

#### Em Smartphones e Tablets Android (Chrome)

1. Abra o navegador Chrome e acesse o Portal do Paciente da sua organização
2. Faça login com suas credenciais
3. Toque no ícone de menu (três pontos na parte superior direita)
4. Selecione "Adicionar à tela inicial" ou "Instalar aplicativo"
5. Confirme a instalação tocando em "Adicionar" ou "Instalar"
6. O ícone do Portal do Paciente aparecerá na sua tela inicial

#### Em iPhone e iPad (Safari)

1. Abra o navegador Safari e acesse o Portal do Paciente da sua organização
2. Faça login com suas credenciais
3. Toque no ícone de compartilhamento (quadrado com seta para cima)
4. Role para baixo e toque em "Adicionar à Tela de Início"
5. Personalize o nome se desejar e toque em "Adicionar"
6. O ícone do Portal do Paciente aparecerá na sua tela inicial

#### Em Computadores Windows (Chrome, Edge)

1. Abra o navegador Chrome ou Edge e acesse o Portal do Paciente
2. Faça login com suas credenciais
3. Clique no ícone de instalação na barra de endereço (ícone de computador com seta para baixo)
4. Clique em "Instalar"
5. O Portal do Paciente será instalado como um aplicativo em seu computador

#### Em Computadores Mac (Chrome, Safari)

1. No Chrome: Siga as mesmas instruções do Windows
2. No Safari: Atualmente o Safari para macOS não suporta instalação de PWAs

### Utilizando o Portal Offline

O Portal do Paciente funciona mesmo sem conexão à internet:

1. As informações que você já acessou estarão disponíveis offline
2. Você pode registrar sintomas, uso de medicamentos e notas offline
3. Assim que houver conexão, os dados serão sincronizados automaticamente
4. Uma indicação "Offline" aparecerá quando você estiver sem conexão

### Gerenciando Notificações

Para configurar as notificações do Portal:

1. Abra o Portal do Paciente
2. Acesse "Configurações" > "Notificações"
3. Escolha quais tipos de notificações deseja receber
4. Configure os horários de lembretes de medicação
5. Selecione os canais de notificação (push, e-mail, SMS)
6. Salve suas preferências

## Para Organizações

### Configurando o Portal para sua Organização

#### Requisitos do Servidor

Para oferecer o Portal do Paciente como um PWA, seu servidor deve:

1. Servir o site via HTTPS (obrigatório para PWAs)
2. Ter certificados SSL válidos e atualizados
3. Configurar cabeçalhos de segurança apropriados
4. Implementar redirecionamento de HTTP para HTTPS

#### Arquivos Necessários

Certifique-se de que os seguintes arquivos estão configurados corretamente:

1. **manifest.json**: Define como o aplicativo aparece quando instalado
   - Nome e descrição do aplicativo
   - Ícones em diferentes resoluções
   - Cores do tema e de fundo
   - URL de início e escopo

2. **service-worker.js**: Gerencia o comportamento offline
   - Cache de ativos estáticos
   - Estratégias de fallback offline
   - Sincronização em segundo plano

3. **robots.txt e sitemap.xml**: Para indexação apropriada

#### Personalização de Marca

Personalize o Portal do Paciente para sua organização:

1. Acesse o painel administrativo
2. Vá para "Configurações" > "Personalização"
3. Faça upload do logotipo de sua organização
4. Defina as cores primárias e secundárias
5. Personalize mensagens de boas-vindas e termos específicos
6. Adicione informações de contato de suporte

### Testes e Validação

Antes de disponibilizar para pacientes, execute estes testes:

1. **Teste de Instalação**: Verifique se o PWA pode ser instalado em diferentes dispositivos
2. **Teste Offline**: Desconecte a internet e verifique se as principais funcionalidades continuam operando
3. **Teste de Notificações**: Confirme se as notificações são entregues corretamente
4. **Auditorias de Desempenho**: Use o Lighthouse (Chrome DevTools) para verificar:
   - Performance
   - Acessibilidade
   - Melhores práticas
   - SEO
   - Conformidade PWA

## Solucionando Problemas Comuns

### O botão "Instalar" não aparece

- Verifique se o site está sendo servido via HTTPS
- Confirme se o manifest.json está configurado corretamente
- O usuário pode já ter recusado a instalação anteriormente
- Alguns navegadores exigem interação significativa antes de mostrar o botão

### Problemas de Sincronização Offline

- Verifique a configuração do service worker
- Confirme se o IndexedDB está sendo utilizado corretamente
- Implemente estratégias de resolução de conflitos
- Adicione indicadores visuais claros do estado offline

### Notificações não estão funcionando

- Verifique se o usuário concedeu permissão para notificações
- Confirme se o token de push está registrado corretamente
- Teste em diferentes navegadores e dispositivos
- Verifique os logs do servidor para erros de envio

## Recursos Adicionais

- [Documentação Completa do PWA](https://developers.google.com/web/progressive-web-apps/)
- [Lighthouse Auditing Tool](https://developers.google.com/web/tools/lighthouse)
- [Workbox: Biblioteca para Service Workers](https://developers.google.com/web/tools/workbox)
- [Canal de Suporte Técnico Endurancy](https://suporte.endurancy.com)
`;
