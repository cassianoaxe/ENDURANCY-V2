export default `# Contribuindo para o Portal do Paciente

Agradecemos seu interesse em contribuir para o desenvolvimento do Portal do Paciente! Este documento fornece diretrizes para ajudar você a contribuir de maneira eficaz.

## Como Contribuir

### Reportando Bugs

Se você encontrar um bug, por favor crie uma issue com as seguintes informações:

1. Um título claro e descritivo
2. Passos detalhados para reproduzir o problema
3. Comportamento esperado vs. comportamento atual
4. Capturas de tela (se aplicável)
5. Informações sobre seu ambiente (navegador, sistema operacional, dispositivo)

### Sugerindo Melhorias

Para sugerir melhorias ou novas funcionalidades:

1. Verifique se sua ideia já não foi sugerida
2. Forneça um título claro e descritivo
3. Explique por que esta melhoria seria útil para os usuários
4. Considere incluir mockups ou exemplos

### Pull Requests

1. Faça um fork do repositório
2. Crie um branch para sua feature (`git checkout -b feature/awesome-feature`)
3. Faça suas alterações
4. Certifique-se de que seu código segue as diretrizes de estilo
5. Teste suas alterações
6. Commit suas alterações (`git commit -m 'Add awesome feature'`)
7. Push para o branch (`git push origin feature/awesome-feature`)
8. Abra um Pull Request

## Diretrizes de Desenvolvimento

### Estrutura PWA

Ao trabalhar com o Portal do Paciente, lembre-se que ele é um Progressive Web App (PWA), então considere:

- Funcionalidade offline
- Responsividade para todos os tamanhos de tela
- Performance e tempo de carregamento

### Estilo de Código

- Use a formatação padrão do projeto
- Documente funções e componentes complexos
- Mantenha os componentes pequenos e reutilizáveis
- Use nomes descritivos para variáveis e funções

### Acessibilidade

- Garanta que todas as funcionalidades são acessíveis via teclado
- Use atributos ARIA apropriadamente
- Mantenha bom contraste de cores
- Forneça textos alternativos para imagens

### Segurança

- Nunca exponha dados sensíveis no frontend
- Valide todas as entradas do usuário
- Considere questões de privacidade ao implementar novas funcionalidades

## Processo de Revisão

O processo de revisão de código ajuda a manter a qualidade do código e compartilhar conhecimento. Aqui está o que esperamos:

1. Todos os PRs serão revisados por pelo menos um mantenedor
2. Os revisores podem solicitar mudanças antes de mesclar
3. As revisões focam em funcionalidade, segurança, acessibilidade e qualidade do código

## Configuração de Desenvolvimento

### Requisitos

- Node.js 16+
- npm ou yarn

### Configuração Local

1. Clone o repositório
2. Instale as dependências: \`npm install\`
3. Inicie o servidor de desenvolvimento: \`npm run dev\`

## Recursos de Aprendizado

- [Documentação do React](https://reactjs.org/docs/getting-started.html)
- [Guia de PWAs](https://web.dev/progressive-web-apps/)
- [Guia de Acessibilidade Web](https://www.w3.org/WAI/tips/)

## Comunidade

Junte-se à nossa comunidade para discussões, perguntas e colaboração:

- [Fórum da Comunidade](https://forum.endurancy.com)
- [Canal do Discord](https://discord.gg/endurancy)

---

Obrigado por dedicar seu tempo para contribuir!
`;