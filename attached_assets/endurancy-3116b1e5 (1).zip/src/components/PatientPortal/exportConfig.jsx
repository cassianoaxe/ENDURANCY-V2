
export default {
  name: "patient-portal-pwa",
  version: "1.0.0",
  description: "Portal do Paciente Progressive Web App para gestão de saúde e telemedicina",
  author: "Endurancy Health Technology",
  license: "MIT",
  repository: {
    type: "git",
    url: "https://github.com/endurancy/patient-portal"
  },
  scripts: {
    start: "react-scripts start",
    build: "react-scripts build",
    test: "react-scripts test",
    eject: "react-scripts eject"
  },
  dependencies: {
    react: "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.14.1",
    "lucide-react": "^0.252.0",
    "date-fns": "^2.30.0",
    "tailwindcss": "^3.3.2",
    "framer-motion": "^10.12.18"
  },
  devDependencies: {
    "workbox-webpack-plugin": "^7.0.0",
    eslint: "^8.44.0",
    prettier: "^2.8.8",
    jest: "^29.6.1"
  },
  browserslist: {
    production: [
      ">0.2%",
      "not dead",
      "not op_mini all"
    ],
    development: [
      "last 1 chrome version",
      "last 1 firefox version",
      "last 1 safari version"
    ]
  },
  exportFiles: [
    "README.md",
    "LICENSE.md",
    "CONTRIBUTING.md",
    "pwa-setup-instructions.md"
  ],
  keywords: [
    "pwa",
    "telemedicina",
    "saude-digital",
    "portal-paciente",
    "react",
    "cannabis-medicinal",
    "offline-first",
    "mobile-friendly"
  ]
};
