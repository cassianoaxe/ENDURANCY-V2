export default `# Portal do Paciente Endurancy - Aplicação PWA

O Portal do Paciente Endurancy é uma aplicação web progressiva (PWA) projetada para pacientes que utilizam cannabis medicinal, permitindo acompanhamento de tratamentos, comunicação com médicos, gerenciamento de prescrições e muito mais.

## Visão Geral

O Portal do Paciente Endurancy oferece uma experiência mobile-first, permitindo que pacientes acessem seus dados médicos e interajam com sua associação ou fornecedor a qualquer momento, em qualquer dispositivo, mesmo com conectividade limitada.

## Principais Funcionalidades

### Perfil do Paciente
- Dados pessoais e médicos
- Histórico de condições
- Preferências de comunicação
- Configurações de privacidade

### Prescrições
- Visualização de prescrições ativas
- Histórico de prescrições
- Download de documentos
- Solicitação de renovação

### Medicamentos
- Lembretes de medicação
- Registro de uso de medicamentos
- Acompanhamento de estoque
- Solicitação de recompra

### Consultas
- Agendamento de consultas
- Videoconsultas integradas
- Histórico de atendimentos
- Lembretes de compromissos

### Acompanhamento de Tratamento
- Diário de sintomas
- Registro de efeitos colaterais
- Gráficos de progresso
- Notas e observações

### Comunicação
- Chat seguro com equipe médica
- Notificações personalizadas
- Perguntas frequentes
- Conteúdo educativo

## Recursos Técnicos

### Progressive Web App
- Instalável em dispositivos móveis e desktop
- Funcionamento offline
- Sincronização em segundo plano
- Atualizações automáticas

### Segurança
- Autenticação de dois fatores
- Criptografia de dados sensíveis
- Conformidade com LGPD
- Sessões com tempo limitado

### Performance
- Carregamento rápido
- Interface responsiva
- Baixo consumo de dados
- Otimizado para dispositivos de baixo desempenho

### Acessibilidade
- Conformidade com WCAG 2.1
- Suporte a tecnologias assistivas
- Texto alternativo para imagens
- Navegação por teclado

## Especificações Técnicas

### Tecnologias Frontend
- React.js para desenvolvimento de UI
- Tailwind CSS para estilização
- Shadcn/UI para componentes
- Service Workers para funcionalidade offline

### Dados
- IndexedDB para armazenamento local
- API RESTful para comunicação com servidor
- Sincronização bidirectional
- Resolução de conflitos

### Notificações
- Push Notifications
- Notificações in-app
- SMS (para lembretes críticos)
- Email (para comunicações formais)

## Integrações

### Telemedicina
- Videochamadas integradas
- Compartilhamento de tela
- Chat durante consulta
- Gravação (opcional, com consentimento)

### Dispositivos
- Integração com calendários
- Sincronização com apps de saúde
- Suporte a wearables (opcional)
- Leitor de código QR para medicamentos

## Guia de Instalação

O Portal do Paciente pode ser instalado seguindo estes passos:

1. Acesse o portal através do navegador
2. No Chrome/Edge: clique nos três pontos > "Instalar aplicativo"
3. No Safari (iOS): toque em compartilhar > "Adicionar à Tela de Início"
4. Siga as instruções na tela

Para mais detalhes, consulte o guia completo de instalação PWA.

## Política de Privacidade

O Portal do Paciente segue rigorosas políticas de privacidade:

- Todos os dados de saúde são criptografados
- Nenhuma informação é compartilhada com terceiros sem consentimento
- Pacientes têm controle total sobre seus dados
- Direito ao esquecimento garantido por design

## Suporte e Feedback

Para suporte técnico ou dúvidas:
- Email: suporte@endurancy.com
- Chat in-app disponível em dias úteis (9h-18h)
- Telefone: 0800-123-4567 (horário comercial)

Valorizamos seu feedback para melhorar continuamente o Portal do Paciente.
`;