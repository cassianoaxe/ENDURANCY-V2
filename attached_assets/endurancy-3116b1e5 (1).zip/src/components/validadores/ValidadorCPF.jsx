import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Spinner } from "@/components/ui/spinner";
import { 
  AlertTriangle, 
  Check, 
  X, 
  Info, 
  RefreshCw,
  AlertCircle
} from "lucide-react";
import { toast } from "@/components/ui/use-toast";

/**
 * Componente para validação de CPF
 * Permite verificar a validade do CPF no formato e opcionalmente 
 * simula integração com a Receita Federal
 */
export const ValidadorCPF = ({ 
  value, 
  onChange, 
  onValidationResult, 
  required = true,
  label = "CPF",
  validarNaReceita = true,
  disabled = false,
  className = "",
  showValidationInfo = true
}) => {
  const [isChecking, setIsChecking] = useState(false);
  const [validationMessage, setValidationMessage] = useState("");
  const [validationStatus, setValidationStatus] = useState(null); // null, "error", "warning", "success"
  
  // Remove formatação (pontos e traços) do CPF
  const removeMask = (cpf) => {
    return cpf.replace(/\D/g, '');
  };
  
  // Formata o CPF com pontos e traço (123.456.789-00)
  const formatCPF = (cpf) => {
    cpf = removeMask(cpf);
    if (cpf.length <= 3) return cpf;
    if (cpf.length <= 6) return cpf.replace(/(\d{3})(\d{0,3})/, '$1.$2');
    if (cpf.length <= 9) return cpf.replace(/(\d{3})(\d{3})(\d{0,3})/, '$1.$2.$3');
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{0,2})/, '$1.$2.$3-$4');
  };
  
  // Verifica se o CPF é válido (algoritmo de validação de CPF)
  const isValidCPF = (cpf) => {
    cpf = removeMask(cpf);
    
    // Verificando se o CPF tem 11 dígitos
    if (cpf.length !== 11) return false;
    
    // Verificando números repetidos (CPFs inválidos conhecidos)
    if (/^(\d)\1{10}$/.test(cpf)) return false;
    
    // Validação do primeiro dígito verificador
    let soma = 0;
    for (let i = 0; i < 9; i++) {
      soma += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let resto = 11 - (soma % 11);
    let dv1 = (resto === 10 || resto === 11) ? 0 : resto;
    
    if (dv1 !== parseInt(cpf.charAt(9))) return false;
    
    // Validação do segundo dígito verificador
    soma = 0;
    for (let i = 0; i < 10; i++) {
      soma += parseInt(cpf.charAt(i)) * (11 - i);
    }
    resto = 11 - (soma % 11);
    let dv2 = (resto === 10 || resto === 11) ? 0 : resto;
    
    return dv2 === parseInt(cpf.charAt(10));
  };
  
  // Simula validação do CPF na Receita Federal
  const simulateReceitaValidation = async (cpf) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simula uma chance de 90% de sucesso na validação
        const isValid = Math.random() < 0.9;
        
        if (isValid) {
          resolve({
            status: "success",
            message: "CPF validado na Receita Federal"
          });
        } else {
          reject({
            status: "error",
            message: "CPF não encontrado na base da Receita Federal"
          });
        }
      }, 1500); // Simula um tempo de resposta da API
    });
  };
  
  const handleInputChange = (e) => {
    let cpf = e.target.value;
    let formattedCPF = formatCPF(cpf);
    
    // Reset validation state when input changes
    if (validationStatus) {
      setValidationStatus(null);
      setValidationMessage("");
      if (onValidationResult) {
        onValidationResult({ valid: false, checked: false });
      }
    }
    
    if (onChange) {
      onChange(formattedCPF);
    }
  };
  
  const validateCPF = async () => {
    const cpf = removeMask(value);
    
    if (!cpf || cpf.length === 0) {
      setValidationStatus("error");
      setValidationMessage("Por favor, informe o CPF");
      if (onValidationResult) {
        onValidationResult({ valid: false, checked: true });
      }
      return;
    }
    
    // Verifica se o CPF é válido pelo algoritmo
    if (!isValidCPF(cpf)) {
      setValidationStatus("error");
      setValidationMessage("CPF inválido. Verifique os números.");
      if (onValidationResult) {
        onValidationResult({ valid: false, checked: true });
      }
      return;
    }
    
    // Se a validação na Receita estiver desativada, considera válido pelo algoritmo
    if (!validarNaReceita) {
      setValidationStatus("success");
      setValidationMessage("CPF com formato válido");
      if (onValidationResult) {
        onValidationResult({ valid: true, checked: true });
      }
      return;
    }
    
    // Simula validação na Receita Federal
    setIsChecking(true);
    try {
      const result = await simulateReceitaValidation(cpf);
      setValidationStatus("success");
      setValidationMessage(result.message);
      if (onValidationResult) {
        onValidationResult({ valid: true, checked: true });
      }
      toast({
        title: "CPF Validado",
        description: "O CPF foi validado com sucesso na Receita Federal.",
        variant: "default",
      });
    } catch (error) {
      setValidationStatus("error");
      setValidationMessage(error.message);
      if (onValidationResult) {
        onValidationResult({ valid: false, checked: true });
      }
      toast({
        title: "Erro na Validação",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsChecking(false);
    }
  };
  
  return (
    <div className={`space-y-2 ${className}`}>
      <Label htmlFor="cpf" className="flex justify-between">
        <span>{label}{required && <span className="text-red-500">*</span>}</span>
        {validationStatus && (
          <span 
            className={`text-xs ${
              validationStatus === "success" ? "text-green-600" : 
              validationStatus === "error" ? "text-red-600" : 
              "text-yellow-600"
            }`}
          >
            {validationMessage}
          </span>
        )}
      </Label>
      
      <div className="flex gap-2">
        <div className="relative flex-grow">
          <Input
            id="cpf"
            type="text"
            placeholder="000.000.000-00"
            value={value || ""}
            onChange={handleInputChange}
            disabled={disabled || isChecking}
            maxLength={14}
            className={`pr-10 ${
              validationStatus === "success" ? "border-green-500 focus-visible:ring-green-500" : 
              validationStatus === "error" ? "border-red-500 focus-visible:ring-red-500" : ""
            }`}
          />
          
          {validationStatus && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              {validationStatus === "success" && <Check className="h-4 w-4 text-green-600" />}
              {validationStatus === "error" && <X className="h-4 w-4 text-red-600" />}
              {validationStatus === "warning" && <AlertTriangle className="h-4 w-4 text-yellow-600" />}
            </div>
          )}
        </div>
        
        <Button 
          type="button" 
          variant="outline" 
          onClick={validateCPF}
          disabled={disabled || isChecking || (value?.length < 11)}
        >
          {isChecking ? (
            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Check className="h-4 w-4 mr-2" />
          )}
          Validar
        </Button>
      </div>

      {showValidationInfo && !validationStatus && (
        <div className="flex items-start gap-2 text-xs text-gray-500 mt-1">
          <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
          <span>
            {validarNaReceita 
              ? "O CPF será validado na base da Receita Federal para garantir sua autenticidade."
              : "Apenas a validade do formato do CPF será verificada."}
          </span>
        </div>
      )}
    </div>
  );
};

export default ValidadorCPF;