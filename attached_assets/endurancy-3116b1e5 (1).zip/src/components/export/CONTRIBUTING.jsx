export default `# Contribuindo para a Plataforma Endurancy

Obrigado pelo seu interesse em contribuir para a plataforma Endurancy! Este documento fornece diretrizes sobre como participar do desenvolvimento e melhorar o projeto.

## Código de Conduta

Este projeto segue um código de conduta que esperamos que todos os contribuidores sigam. Por favor, leia o arquivo [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md) para entender as expectativas.

## Como Contribuir

### Reportando Bugs

Se você encontrar um bug, por favor crie uma issue com as seguintes informações:

1. Título claro descrevendo o problema
2. Descrição detalhada do bug e como ele foi descoberto
3. Passos para reproduzir o problema
4. Comportamento esperado vs comportamento atual
5. Capturas de tela (se aplicável)
6. Versão do navegador e sistema operacional
7. Contexto adicional relevante

### Sugerindo Melhorias

Para sugerir melhorias ou novas funcionalidades:

1. Crie uma issue com um título e descrição claros
2. Explique por que esta melhoria seria útil
3. Descreva como você imagina que isso funcionaria
4. Forneça exemplos, mockups ou referências, se possível

### Pull Requests

1. Faça um fork do repositório
2. Crie um branch para sua feature ou correção: \`git checkout -b feature/nome-da-feature\` ou \`git checkout -b fix/bug-description\`
3. Faça suas alterações seguindo as convenções de código
4. Adicione testes para suas alterações, quando aplicável
5. Execute os testes existentes
6. Commit suas alterações seguindo as convenções de mensagens de commit
7. Push para o seu branch: \`git push origin feature/nome-da-feature\`
8. Abra um Pull Request para o branch principal do projeto

## Convenções de Código

### Estilo de Código

- Use ESLint e Prettier configurados no projeto
- Siga a estrutura de componentes existente
- Utilize TypeScript quando possível
- Documente funções complexas
- Mantenha componentes pequenos e focados

### Organização do Código

- Páginas vão em \`/pages\`
- Componentes reutilizáveis vão em \`/components\`
- Entidades e schemas vão em \`/entities\`
- Integrações com sistemas externos em \`/integrations\`
- Utilitários e funções helpers vão em \`/utils\`

### Testes

- Escreva testes para novas funcionalidades
- Mantenha a cobertura de testes existente
- Execute \`npm test\` antes de enviar um PR

### Mensagens de Commit

Utilizamos o padrão de commits convencionais:

- \`feat:\` para novas funcionalidades
- \`fix:\` para correções de bugs
- \`docs:\` para alterações em documentação
- \`style:\` para mudanças de formatação que não afetam o código
- \`refactor:\` para refatorações de código sem alteração de funcionalidade
- \`test:\` para adição ou correção de testes
- \`chore:\` para alterações na configuração do projeto

### Pull Request

- Faça PRs pequenos e focados em uma única funcionalidade
- Descreva claramente o que o PR resolve ou implementa
- Referencie issues relacionadas usando #número-da-issue
- Responda a todos os comentários de revisão

## Desenvolvimento Local

### Configuração do Ambiente

1. Clone o repositório
2. Instale as dependências: \`npm install\`
3. Configure as variáveis de ambiente conforme o arquivo .env.example
4. Execute o projeto: \`npm run dev\`

### Módulos de Desenvolvimento

Para trabalhar em módulos específicos, consulte a documentação especializada:

- [Desenvolvimento do Módulo de Cultivo](./docs/cultivo-dev.md)
- [Desenvolvimento do Módulo de Produção](./docs/producao-dev.md)
- [Desenvolvimento do Portal do Paciente](./components/PatientPortal/CONTRIBUTING.js)

## Verificações e Revisão

Antes de enviar seu PR, verifique:

1. O código está de acordo com as diretrizes de estilo
2. Os testes existentes passam e novos testes foram adicionados quando necessário
3. A documentação foi atualizada, se aplicável
4. O build não apresenta erros

## Recursos Adicionais

- [Documentação da API](./API.md)
- [Guia de Arquitetura](./ARCHITECTURE.md)
- [Roadmap de Desenvolvimento](./ROADMAP.md)

## Perguntas?

Se você tiver dúvidas sobre como contribuir, sinta-se à vontade para abrir uma issue perguntando ou entrar em contato com a equipe através de contato@endurancy.com.

Agradecemos sua contribuição para tornar a plataforma Endurancy melhor!
`;