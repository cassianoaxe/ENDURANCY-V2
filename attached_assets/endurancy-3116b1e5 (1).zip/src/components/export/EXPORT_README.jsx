export default `# Documentação e Guias da Plataforma Endurancy

## Localização dos Documentos

Todos os documentos de documentação, guias e arquivos para exportação estão organizados da seguinte forma:

### Documentação Principal da Plataforma

Localizada na pasta: \`/components/export/\`

- **README.js** - Documentação principal do projeto
- **LICENSE.js** - Licença MIT do projeto
- **CONTRIBUTING.js** - Guia de contribuição
- **CODE_OF_CONDUCT.js** - Código de conduta para contribuidores
- **DEVELOPMENT_GUIDE.js** - Guia detalhado para desenvolvedores
- **ARCHITECTURE.js** - Visão geral da arquitetura da plataforma
- **API.js** - Documentação da API e integrações
- **MODULES.js** - Descrição dos módulos disponíveis
- **ROADMAP.js** - Planejamento futuro da plataforma

### Documentação do Portal do Paciente (PWA)

Localizada na pasta: \`/components/PatientPortal/\`

- **README.js** - Documentação específica do Portal do Paciente
- **license.js** - Licença do Portal do Paciente
- **pwa-setup-instructions.js** - Guia de configuração do PWA
- **CONTRIBUTING.js** - Guia de contribuição específico para o Portal
- **exportConfig.js** - Configurações para exportação do Portal

## Como Acessar e Exportar os Documentos

### Visualização na Base44

Enquanto estiver trabalhando na plataforma Base44, você pode visualizar os documentos diretamente no editor de código. Cada arquivo contém o conteúdo formatado em Markdown dentro de uma template string.

### Exportação para GitHub

Para exportar os documentos para um repositório GitHub:

1. **Exportação da Plataforma Completa**
   - Copie o conteúdo de cada arquivo .js em \`/components/export/\`
   - Remova a parte \`export default\` do início e as crases do final
   - Salve como arquivos Markdown (.md) no repositório GitHub

2. **Exportação do Portal do Paciente**
   - Copie o conteúdo de cada arquivo .js em \`/components/PatientPortal/\`
   - Remova a parte \`export default\` do início e as crases do final
   - Salve como arquivos Markdown (.md) na pasta do Portal do Paciente

### Script de Exportação Automatizada

Para facilitar o processo, você pode criar um script que extraia automaticamente o conteúdo dos arquivos .js e os salve como .md. Um exemplo básico:

\`\`\`javascript
const fs = require('fs');
const path = require('path');

// Diretórios de origem e destino
const sourceDirs = [
  { path: './components/export/', destDir: './docs/' },
  { path: './components/PatientPortal/', destDir: './docs/patient-portal/' }
];

// Função para extrair o conteúdo Markdown de um arquivo JS
function extractMarkdown(content) {
  // Remove "export default `" do início e a crase do final
  return content.replace(/^export default \`/, '').replace(/\`;$/, '');
}

// Para cada diretório de origem
sourceDirs.forEach(({ path: sourceDir, destDir }) => {
  // Criar o diretório de destino se não existir
  if (!fs.existsSync(destDir)) {
    fs.mkdirSync(destDir, { recursive: true });
  }
  
  // Ler todos os arquivos JS no diretório de origem
  fs.readdirSync(sourceDir)
    .filter(file => file.endsWith('.js'))
    .forEach(file => {
      const filePath = path.join(sourceDir, file);
      const content = fs.readFileSync(filePath, 'utf8');
      
      // Extrair o conteúdo Markdown
      const markdown = extractMarkdown(content);
      
      // Determinar o nome do arquivo de saída (substituir .js por .md)
      const outFileName = file.replace('.js', '.md');
      const outFilePath = path.join(destDir, outFileName);
      
      // Escrever o arquivo Markdown
      fs.writeFileSync(outFilePath, markdown);
      console.log(\`Extracted \${outFilePath}\`);
    });
});
\`\`\`

## Importância dos Documentos

Estes documentos são essenciais para:

1. **Onboarding de Novos Desenvolvedores** - Auxiliam novos membros da equipe a entender rapidamente a arquitetura e funcionamento da plataforma.

2. **Código Aberto** - Facilitam a contribuição da comunidade, caso decida-se liberar a plataforma como código aberto.

3. **Documentação para Clientes** - Fornecem material que pode ser adaptado para documentação técnica para clientes e parceiros.

4. **Continuidade do Projeto** - Garantem que o conhecimento sobre o sistema não fique restrito apenas aos desenvolvedores atuais.

5. **Conformidade** - Documentam aspectos importantes para conformidade regulatória no setor médico e de cannabis.

## Atualização da Documentação

A documentação deve ser atualizada sempre que houver:

- Adição de novas funcionalidades
- Alterações significativas na arquitetura
- Mudanças nos fluxos de trabalho ou processos

Mantenha os documentos sincronizados com o código para garantir que sempre reflitam o estado atual do sistema.
`;