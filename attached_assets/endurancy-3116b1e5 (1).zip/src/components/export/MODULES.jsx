
export default `# Módulos da Plataforma Endurancy

A plataforma Endurancy é composta por módulos especializados que atendem a diferentes aspectos da cadeia de cannabis medicinal. Cada organização pode habilitar ou desabilitar módulos conforme suas necessidades.

## Módulos Principais

### Módulo de Gestão de Organizações

**Funcionalidades:**
- Cadastro e gerenciamento de organizações (empresas e associações)
- Aprovação e verificação de documentação
- Gestão de perfis organizacionais
- Controle de planos e módulos habilitados

**Principais entidades:**
- Organization
- Document
- Activity
- Notification

**Ideal para:**
- Administradores da plataforma
- Organizações com múltiplas unidades

---

### Módulo de Cultivo

**Funcionalidades:**
- Controle completo de lotes e plantas
- Gestão de strains e genética
- Rastreabilidade seed-to-sale
- Controle de condições ambientais
- Testes laboratoriais e análises

**Principais entidades:**
- Batch
- Plant
- Strain
- GrowRoom
- Transfer
- LabTest

**Ideal para:**
- Associações que cultivam cannabis
- Produtores licenciados
- Operações de pesquisa e desenvolvimento

---

### Módulo de Produção

**Funcionalidades:**
- Controle de qualidade
- Gestão de matérias-primas
- Ordens de produção
- Gestão de lotes
- Garantia da qualidade
- Rastreabilidade

**Principais entidades:**
- Production
- Material
- LoteMaterial
- AnaliseQualidade
- DesvioQualidade
- LiberacaoLote

**Ideal para:**
- Fabricantes de produtos de cannabis medicinal
- Farmácias manipuladoras
- Laboratórios especializados

---

### Módulo Médico

**Funcionalidades:**
- Cadastro e gestão de médicos
- Agendamento de consultas
- Telemedicina
- Prescrição digital
- Acompanhamento de pacientes
- Comissões médicas

**Principais entidades:**
- Medico
- ConsultaMedica
- AcompanhamentoTratamento
- FinanceiroMedico
- ComissaoMedica

**Ideal para:**
- Clínicas especializadas
- Médicos prescritores
- Associações com equipe médica própria

---

### Módulo de Paciente

**Funcionalidades:**
- Portal do paciente (PWA)
- Cadastro e perfil do paciente
- Gestão de prescrições
- Agendamento de consultas
- Acompanhamento de tratamentos
- Lembretes de medicação

**Principais entidades:**
- Patient
- Prescription
- LembretesMedicacao
- FeedbackConsulta
- NotificationPreference

**Ideal para:**
- Todos os tipos de organizações
- Associações focadas em pacientes
- Empresas com atendimento direto ao paciente

---

### Módulo de Associados

**Funcionalidades:**
- Gestão de associados
- Documentação de associados
- Anuidades e contribuições
- Transparência associativa
- Assembleias e votações

**Principais entidades:**
- Associado
- Anuidade
- PagamentoAnuidade
- AssistenciaBeneficiario
- Transparency

**Ideal para:**
- Associações de cannabis medicinal
- Organizações sem fins lucrativos

---

### Módulo Financeiro

**Funcionalidades:**
- Gestão financeira completa
- Faturamento e cobranças
- Integração com gateways de pagamento
- Relatórios financeiros
- Fluxo de caixa
- Análise financeira com IA

**Principais entidades:**
- ContaBancaria
- PlanoContas
- CentroCusto
- FormaPagamento
- PaymentTransaction
- Invoice

**Ideal para:**
- Todas as organizações
- Especialmente útil para associações que precisam de transparência

---

### Módulo ComplyPay

**Funcionalidades:**
- Processamento de pagamentos
- Pagamentos recorrentes
- Gestão de assinaturas
- Integração com múltiplos gateways
- Emissão de faturas

**Principais entidades:**
- PaymentMethod
- PaymentTransaction
- Invoice
- RecurringPayment
- PaymentIntegration

**Ideal para:**
- Organizações que vendem produtos ou serviços
- Associações que cobram anuidades

---

### Módulo Jurídico

**Funcionalidades:**
- Gestão de ações judiciais
- Documentação legal
- Compliance regulatório
- Acompanhamento processual
- Relatórios de conformidade

**Principais entidades:**
- AcaoJudicial
- LegalDocument
- DocumentoQualidade
- JuridicoCompliance

**Ideal para:**
- Associações que auxiliam em ações judiciais
- Empresas que precisam de controle regulatório
- Organizações sujeitas a fiscalização rigorosa

---

### Módulo de Comunicação

**Funcionalidades:**
- Campanhas de email
- Gestão de conteúdo educativo
- Calendário de comunicação
- Notificações e alertas
- Gestão de SMS e WhatsApp

**Principais entidades:**
- CampanhaEmail
- ConteudoEducativo
- EventoComunicacao
- CredencialServico
- FeedbackConteudo

**Ideal para:**
- Organizações que fazem marketing de conteúdo
- Associações que educam pacientes
- Empresas com comunicação regular com clientes

---

### Módulo de Vendas

**Funcionalidades:**
- E-commerce integrado
- Gestão de pedidos
- Rastreamento de entregas
- Gestão de estoque
- Promoções e descontos

**Principais entidades:**
- Order
- Product
- EstoqueDistribuicao
- MovimentacaoDistribuicao
- PedidoJuncao

**Ideal para:**
- Empresas que vendem produtos
- Associações que distribuem medicamentos
- Farmácias especializadas

---

### Módulo de Compras

**Funcionalidades:**
- Gestão de fornecedores
- Solicitações de compra
- Cotações e orçamentos
- Controle de estoque
- Requisições internas

**Principais entidades:**
- Fornecedor
- SolicitacaoCompra
- ItemEstoque
- MovimentacaoEstoqueCompras
- RequisicaoInterna

**Ideal para:**
- Organizações que precisam de controle de estoque
- Produtores com compras de insumos frequentes
- Empresas com múltiplos fornecedores

---

### Módulo de Transparência

**Funcionalidades:**
- Portal de transparência pública
- Documentos de transparência
- Relatórios financeiros públicos
- Governança e membros
- Certificações e reconhecimentos

**Principais entidades:**
- Transparency
- AssociationMember
- AssociationFinancial
- TransparencyDocument
- TransparencyCertification

**Ideal para:**
- Associações sem fins lucrativos
- Organizações que precisam demonstrar conformidade
- Entidades que recebem recursos públicos

---

### Módulo de Representantes

**Funcionalidades:**
- Cadastro de representantes
- Gestão de territórios
- Cálculo de comissões
- Metas e acompanhamento
- Gestão de médicos relacionados

**Principais entidades:**
- Representante
- Comissao
- ComissaoMedica
- Medico

**Ideal para:**
- Empresas com equipe de vendas externa
- Organizações com representantes comerciais
- Fabricantes que trabalham com médicos prescritores

## Módulos Complementares

### Módulo de Recursos Humanos
- Gestão de colaboradores
- Recrutamento e seleção
- Documentação de funcionários
- Escalas e turnos

### Módulo de Patrimônio
- Gestão de instalações
- Controle de equipamentos
- Manutenções programadas
- Inventário físico

### Módulo de Expedição
- Preparação de pedidos
- Impressão de etiquetas
- Rastreamento de entregas
- Registro de malotes

### Módulo de Assistência Social
- Cadastro de beneficiários
- Gestão de subsídios
- Acompanhamento social
- Relatórios sociais

## Integrações Disponíveis

- Gateway de pagamentos
- Sistemas de contabilidade
- APIs governamentais
- Laboratórios de análise
- Transportadoras e rastreamento
- Sistemas de telemedicina
- Prontuários eletrônicos
`;
