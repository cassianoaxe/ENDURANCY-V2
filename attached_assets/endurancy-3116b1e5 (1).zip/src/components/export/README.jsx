export default `# Endurancy - Plataforma de Gestão para Cannabis Medicinal

Um sistema completo e modular para gestão de organizações no setor de cannabis medicinal no Brasil, integrando gerenciamento de associações, empresas, cultivo, produção, e relacionamento com pacientes e médicos.

## Visão Geral

A plataforma Endurancy é uma solução completa para todos os stakeholders do ecossistema de cannabis medicinal:

- **Super Administradores:** Gerenciam a plataforma, organizações e módulos
- **Organizações:** Associações e empresas que operam no setor
- **Médicos:** Prescritores que acompanham pacientes
- **Pacientes:** Usuários finais que recebem tratamentos

O sistema possui uma arquitetura modular que permite a customização de funcionalidades de acordo com as necessidades específicas de cada tipo de organização.

## Principais Módulos

### Gestão de Organizações
- Cadastro de associações e empresas
- Aprovação e verificação de documentos
- Gestão de planos e assinaturas

### Cultivo
- Acompanhamento de lotes e plantas
- Controle de strains e genética
- Rastreabilidade completa seed-to-sale
- Testes laboratoriais

### Produção
- Controle de qualidade
- Gestão de matérias-primas
- Ordens de produção
- Garantia da qualidade
- Rastreabilidade

### Médico
- Cadastro de médicos
- Agendamento de consultas
- Consultas virtuais (telemedicina)
- Gestão de prescrições
- Comissões médicas

### Paciente
- Portal do paciente (PWA)
- Agendamento de consultas
- Acompanhamento de tratamentos
- Comunicação segura
- Lembretes de medicação

### Financeiro
- Gestão financeira completa
- Faturamento e cobranças
- Integrações com gateways de pagamento
- Análise financeira com IA

### Jurídico
- Gestão de ações judiciais
- Documentação legal
- Compliance e regulatório

### Comunicação
- Campanhas de email
- Gestão de conteúdo educativo
- Calendário de comunicação

### Vendas e Expedição
- E-commerce integrado
- Gestão de pedidos
- Rastreamento de entregas
- Gestão de estoque

## Tecnologias Utilizadas

- **Frontend:** React.js, Tailwind CSS, Shadcn/UI
- **PWA:** Service Workers para funcionalidades offline
- **UI/UX:** Design responsivo e acessível
- **Telemedicina:** WebRTC para videochamadas
- **Dados:** Armazenamento em nuvem com sincronização

## Estrutura do Projeto

A estrutura do código está organizada da seguinte forma:

- \`/entities\` - Modelos de dados e schemas
- \`/pages\` - Interfaces e rotas da aplicação
- \`/components\` - Componentes reutilizáveis
- \`/integrations\` - Integração com sistemas externos
- \`/utils\` - Utilitários e helpers

## Instalação e Configuração

### Requisitos
- Node.js 16+
- NPM ou Yarn
- Serviço de banco de dados compatível

### Passos para Instalação
1. Clone o repositório
2. Instale as dependências: \`npm install\`
3. Configure as variáveis de ambiente
4. Execute o projeto em desenvolvimento: \`npm run dev\`
5. Build para produção: \`npm run build\`

## Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

## Documentação Adicional

- [Guia de Contribuição](./CONTRIBUTING.md)
- [Portal do Paciente PWA](./components/PatientPortal/README.js)
- [API Documentation](./API.md)
- [Módulos Disponíveis](./MODULES.md)

## Contato

Para mais informações sobre a plataforma Endurancy, entre em contato:
- Website: https://endurancy.com
- Email: contato@endurancy.com
`;