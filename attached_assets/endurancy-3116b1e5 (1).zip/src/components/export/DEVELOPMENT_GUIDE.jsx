export default `# Guia de Desenvolvimento da Plataforma Endurancy

Este guia fornece instruções detalhadas para desenvolvedores que desejam trabalhar no código da plataforma Endurancy, seja para contribuir com o projeto original ou para personalizar uma instalação própria.

## Requisitos de Ambiente

### Requisitos de Software
- Node.js 16+ LTS
- NPM 7+ ou Yarn 1.22+
- Git
- Editor de código (recomendamos VS Code)

### Extensões Recomendadas para VS Code
- ESLint
- Prettier
- Tailwind CSS IntelliSense
- React Developer Tools
- GitLens

## Configuração do Ambiente de Desenvolvimento

### 1. Clone do Repositório

\`\`\`bash
git clone https://github.com/endurancy/platform.git
cd platform
\`\`\`

### 2. Instalação de Dependências

\`\`\`bash
npm install
# ou
yarn install
\`\`\`

### 3. Configuração de Variáveis de Ambiente

Crie um arquivo \`.env.local\` na raiz do projeto:

\`\`\`
NEXT_PUBLIC_API_URL=https://api.endurancy.com
NEXT_PUBLIC_DEFAULT_LOCALE=pt-BR
NEXT_PUBLIC_DEPLOYMENT_ENV=development
\`\`\`

### 4. Iniciar o Servidor de Desenvolvimento

\`\`\`bash
npm run dev
# ou
yarn dev
\`\`\`

O aplicativo estará disponível em \`http://localhost:3000\`.

## Estrutura do Projeto

\`\`\`
/
├── entities/            # Definições de entidades (JSON schemas)
├── pages/               # Páginas da aplicação
├── components/          # Componentes reutilizáveis
│   ├── ui/              # Componentes UI básicos (shadcn/ui)
│   ├── forms/           # Componentes de formulários
│   ├── layouts/         # Layouts de página
│   ├── [module-name]/   # Componentes específicos de módulos
│   └── ...
├── integrations/        # Integrações com serviços externos
├── public/              # Arquivos estáticos
├── utils/               # Funções utilitárias
├── styles/              # Estilos globais
├── .eslintrc.js         # Configuração do ESLint
├── tailwind.config.js   # Configuração do Tailwind CSS
└── package.json         # Dependências e scripts
\`\`\`

## Padrões de Codificação

### Convenções de Nomenclatura

- **Arquivos e Pastas**: PascalCase para componentes React, camelCase para utilitários
- **Componentes**: PascalCase (ex: \`UserProfile.jsx\`)
- **Funções**: camelCase (ex: \`fetchUserData\`)
- **Constantes**: UPPER_SNAKE_CASE (ex: \`MAX_RETRY_ATTEMPTS\`)
- **Entidades**: PascalCase (ex: \`Organization.json\`)

### Estilo de Código

Seguimos um conjunto de convenções de estilo aplicadas pelo ESLint e Prettier:

- Indentação de 2 espaços
- Ponto e vírgula ao final das declarações
- Aspas simples para strings
- Limite de 100 caracteres por linha
- Uso de JSX para componentes React

### Componentes React

- Um componente por arquivo
- Prefira componentes funcionais com hooks
- Use destructuring para props
- Documente props complexas com comentários

Exemplo:

\`\`\`jsx
// UserCard.jsx
import React from 'react';
import { Avatar } from '@/components/ui/avatar';
import { formatDate } from '@/utils';

/**
 * Card que exibe informações de um usuário
 */
export function UserCard({ user, onClick }) {
  if (!user) return null;
  
  return (
    <div className="p-4 border rounded-lg" onClick={() => onClick(user.id)}>
      <Avatar user={user} />
      <h3 className="text-lg font-medium mt-2">{user.name}</h3>
      <p className="text-gray-500">{formatDate(user.createdAt)}</p>
    </div>
  );
}
\`\`\`

### Gestão de Estado

- Use hooks do React (\`useState\`, \`useReducer\`) para estado local
- Evite estado global quando possível
- Sempre inicialize estados com valores apropriados

### Entidades

As entidades são definidas como schemas JSON e devem seguir estas diretrizes:

- Propriedades claramente nomeadas
- Descrições detalhadas para cada propriedade
- Tipos de dados apropriados
- Valores padrão definidos quando aplicável

Exemplo:

\`\`\`json
{
  "name": "Product",
  "type": "object",
  "properties": {
    "name": {
      "type": "string",
      "description": "Nome do produto"
    },
    "description": {
      "type": "string",
      "description": "Descrição detalhada do produto"
    },
    "price": {
      "type": "number",
      "description": "Preço do produto em reais"
    },
    "status": {
      "type": "string",
      "enum": ["ativo", "inativo", "esgotado"],
      "description": "Status do produto",
      "default": "ativo"
    }
  },
  "required": ["name", "price"]
}
\`\`\`

## Criação de Novos Recursos

### Criando uma Nova Entidade

1. Crie um novo arquivo JSON em \`/entities/\` com o nome da entidade
2. Defina as propriedades, tipos e descrições
3. Especifique os campos obrigatórios

### Criando uma Nova Página

1. Crie um novo arquivo em \`/pages/\` com o nome da página
2. Importe os componentes e entidades necessários
3. Implemente a lógica da página
4. Adicione a rota ao sistema de navegação

Exemplo:

\`\`\`jsx
// pages/ProductList.js
import React, { useState, useEffect } from 'react';
import { Product } from '@/api/entities';
import { DataTable } from '@/components/ui/data-table';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function ProductList() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    async function loadProducts() {
      try {
        const data = await Product.list('-updated_date');
        setProducts(data);
      } catch (error) {
        console.error("Erro ao carregar produtos:", error);
      } finally {
        setLoading(false);
      }
    }
    
    loadProducts();
  }, []);
  
  // Resto do componente...
}
\`\`\`

### Criando um Novo Componente

1. Crie um novo arquivo na pasta \`/components/\` apropriada
2. Implemente o componente como uma função
3. Exporte o componente como default
4. Documente as props

## Testes

### Testes Unitários

Utilizamos Jest e React Testing Library para testes unitários:

\`\`\`bash
npm run test
# ou
yarn test
\`\`\`

### Testes de Integração

\`\`\`bash
npm run test:integration
# ou
yarn test:integration
\`\`\`

## Build e Deployment

### Build para Produção

\`\`\`bash
npm run build
# ou
yarn build
\`\`\`

### Verificação Pré-deployment

\`\`\`bash
npm run lint && npm run test
# ou
yarn lint && yarn test
\`\`\`

## Módulos e Personalização

### Criando um Novo Módulo

Os módulos são conjuntos de funcionalidades relacionadas. Para criar um novo módulo:

1. Crie as entidades relacionadas ao módulo em \`/entities/\`
2. Crie as páginas do módulo em \`/pages/\`
3. Crie os componentes específicos do módulo em \`/components/[module-name]/\`
4. Adicione as configurações do módulo em \`ModuleSettings.json\`

### Personalizando um Módulo Existente

Para personalizar um módulo existente:

1. Estenda as entidades conforme necessário
2. Sobreescreva componentes para adicionar funcionalidades
3. Modifique as páginas do módulo

## Boas Práticas

### Performance

- Use \`React.memo()\` para componentes que não mudam com frequência
- Implemente lazy loading para componentes grandes
- Otimize imagens e assets
- Evite re-renders desnecessários

### Acessibilidade

- Use elementos semânticos HTML
- Adicione atributos \`aria-*\` quando necessário
- Garanta contraste adequado de cores
- Teste com leitores de tela

### Segurança

- Valide todas as entradas de usuário
- Não exponha dados sensíveis no frontend
- Use tokens JWT com refresh tokens
- Implemente proteção contra XSS

## Recursos Adicionais

- [Documentação da API](./API.md)
- [Descrição dos Módulos](./MODULES.md)
- [Padrões de UI/UX](./UI_GUIDELINES.md)
- [Guia de Contribuição](./CONTRIBUTING.md)

## Suporte e Contato

Para questões técnicas ou suporte ao desenvolvimento, entre em contato:
- Email: dev@endurancy.com
- GitHub Issues: https://github.com/endurancy/platform/issues
`;