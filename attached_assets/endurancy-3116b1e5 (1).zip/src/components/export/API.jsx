
export default `# Documentação da API Endurancy

## Visão Geral

A API Endurancy permite que desenvolvedores integrem sistemas externos com a plataforma Endurancy, possibilitando a automação de processos, sincronização de dados e criação de extensões personalizadas.

## Autenticação

A API utiliza autenticação OAuth 2.0 para todas as requisições. Para obter acesso, você precisará:

1. Criar credenciais de API nas configurações da sua organização
2. Obter um token de acesso usando suas credenciais
3. Incluir o token em todas as requisições no cabeçalho Authorization

### Obtenção do Token

\`\`\`http
POST /api/v1/auth/token
Content-Type: application/json

{
  "client_id": "seu_client_id",
  "client_secret": "seu_client_secret",
  "grant_type": "client_credentials"
}
\`\`\`

### Uso do Token

\`\`\`http
GET /api/v1/organizations
Authorization: Bearer seu_token_de_acesso
\`\`\`

## Recursos Disponíveis

### Organizações

#### Listar Organizações

\`\`\`http
GET /api/v1/organizations
\`\`\`

#### Obter Organização Específica

\`\`\`http
GET /api/v1/organizations/{organization_id}
\`\`\`

#### Criar Organização

\`\`\`http
POST /api/v1/organizations
Content-Type: application/json

{
  "name": "Nome da Organização",
  "type": "Empresa",
  "contact_name": "Nome do Contato",
  "contact_email": "email@exemplo.com",
  // outros campos
}
\`\`\`

#### Atualizar Organização

\`\`\`http
PUT /api/v1/organizations/{organization_id}
Content-Type: application/json

{
  "name": "Novo Nome da Organização",
  // campos a serem atualizados
}
\`\`\`

### Pacientes

#### Listar Pacientes

\`\`\`http
GET /api/v1/patients?organization_id={organization_id}
\`\`\`

#### Obter Paciente Específico

\`\`\`http
GET /api/v1/patients/{patient_id}
\`\`\`

#### Criar Paciente

\`\`\`http
POST /api/v1/patients
Content-Type: application/json

{
  "organization_id": "id_da_organizacao",
  "full_name": "Nome Completo",
  "cpf": "123.456.789-00",
  // outros campos
}
\`\`\`

### Produtos

#### Listar Produtos

\`\`\`http
GET /api/v1/products?organization_id={organization_id}
\`\`\`

#### Obter Produto Específico

\`\`\`http
GET /api/v1/products/{product_id}
\`\`\`

### Prescrições

#### Listar Prescrições

\`\`\`http
GET /api/v1/prescriptions?organization_id={organization_id}
\`\`\`

#### Criar Prescrição

\`\`\`http
POST /api/v1/prescriptions
Content-Type: application/json

{
  "organization_id": "id_da_organizacao",
  "patient_id": "id_do_paciente",
  "doctor_name": "Nome do Médico",
  "doctor_crm": "CRM do Médico",
  "products": [
    {
      "product_id": "id_do_produto",
      "product_name": "Nome do Produto",
      "dosage": "Dosagem indicada",
      "frequency": "Frequência de uso",
      "quantity": 1
    }
  ],
  // outros campos
}
\`\`\`

### Pedidos

#### Listar Pedidos

\`\`\`http
GET /api/v1/orders?organization_id={organization_id}
\`\`\`

#### Criar Pedido

\`\`\`http
POST /api/v1/orders
Content-Type: application/json

{
  "organization_id": "id_da_organizacao",
  "patient_id": "id_do_paciente",
  "items": [
    {
      "product_id": "id_do_produto",
      "product_name": "Nome do Produto",
      "quantity": 1,
      "unit_price": 99.90,
      "subtotal": 99.90
    }
  ],
  "subtotal": 99.90,
  "shipping_fee": 10.00,
  "total": 109.90,
  // outros campos
}
\`\`\`

### Consultas Médicas

#### Listar Consultas

\`\`\`http
GET /api/v1/consultations?organization_id={organization_id}
\`\`\`

#### Agendar Consulta

\`\`\`http
POST /api/v1/consultations
Content-Type: application/json

{
  "organization_id": "id_da_organizacao",
  "medico_id": "id_do_medico",
  "paciente_id": "id_do_paciente",
  "data_hora": "2023-12-15T14:30:00Z",
  "tipo_consulta": "telemedicina",
  // outros campos
}
\`\`\`

## Webhooks

A plataforma Endurancy oferece webhooks para notificar sistemas externos sobre eventos importantes:

### Configuração de Webhooks

Para configurar webhooks, acesse as configurações de integrações da sua organização e adicione URLs para cada tipo de evento desejado.

### Eventos Disponíveis

- \`organization.created\` - Nova organização criada
- \`organization.updated\` - Organização atualizada
- \`organization.approved\` - Organização aprovada
- \`patient.created\` - Novo paciente cadastrado
- \`prescription.created\` - Nova prescrição criada
- \`prescription.approved\` - Prescrição aprovada
- \`order.created\` - Novo pedido criado
- \`order.status_changed\` - Status do pedido alterado
- \`consultation.scheduled\` - Nova consulta agendada
- \`consultation.completed\` - Consulta realizada

### Formato do Payload

\`\`\`json
{
  "event": "prescription.approved",
  "timestamp": "2023-07-21T14:30:45Z",
  "organization_id": "org123",
  "data": {
    "id": "presc456",
    "patient_id": "pat789",
    "doctor_name": "Dr. João Silva",
    // dados específicos do evento
  }
}
\`\`\`

## Limitações e Throttling

- Limite de 100 requisições por minuto por cliente
- Tamanho máximo de payload: 10MB
- Timeout de requisição: 30 segundos

## Códigos de Status

- 200 OK - Requisição bem-sucedida
- 201 Created - Recurso criado com sucesso
- 400 Bad Request - Parâmetros inválidos
- 401 Unauthorized - Autenticação necessária
- 403 Forbidden - Sem permissão para o recurso
- 404 Not Found - Recurso não encontrado
- 429 Too Many Requests - Limite de rate excedido
- 500 Internal Server Error - Erro no servidor

## SDKs Disponíveis

- JavaScript/Node.js
- Python
- PHP
- Java
- .NET

Para baixar os SDKs e ver exemplos de código, acesse [https://developers.endurancy.com](https://developers.endurancy.com)

## Suporte e Contato

Para dúvidas sobre a API, entre em contato:
- Email: api@endurancy.com
- Portal do Desenvolvedor: [https://developers.endurancy.com](https://developers.endurancy.com)
`;
