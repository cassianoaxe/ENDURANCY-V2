export default {
  "name": "endurancy-platform",
  "version": "1.0.0",
  "description": "Plataforma completa para gestão de organizações no setor de cannabis medicinal",
  "author": "Endurancy Health Technology",
  "license": "MIT",
  "repository": {
    "type": "git",
    "url": "https://github.com/endurancy/platform"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "lint": "eslint .",
    "format": "prettier --write \"**/*.{js,jsx,json,md}\""
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.14.1",
    "lucide-react": "^0.252.0",
    "date-fns": "^2.30.0",
    "recharts": "^2.7.2",
    "tailwindcss": "^3.3.2",
    "framer-motion": "^10.12.18",
    "react-hook-form": "^7.45.1"
  },
  "devDependencies": {
    "eslint": "^8.44.0",
    "prettier": "^2.8.8",
    "jest": "^29.6.1",
    "typescript": "^5.1.6"
  },
  "exportFiles": [
    "README.md",
    "LICENSE.md",
    "CONTRIBUTING.md",
    "MODULES.md",
    "API.md",
    "ARCHITECTURE.md",
    "DEVELOPMENT_GUIDE.md",
    "ROADMAP.md",
    "CODE_OF_CONDUCT.md"
  ],
  "modules": [
    {
      "name": "Dashboard",
      "description": "Visão geral da plataforma",
      "files": ["pages/Dashboard.js", "components/dashboard/*"]
    },
    {
      "name": "Organizations",
      "description": "Gestão de organizações",
      "files": ["pages/Organizations.js", "pages/Organization.js", "entities/Organization.json"]
    },
    {
      "name": "Cultivo",
      "description": "Módulo de cultivo de cannabis",
      "files": ["pages/CultivoDashboard.js", "pages/CultivoLotes.js", "pages/CultivoPlantas.js"]
    },
    {
      "name": "Produção",
      "description": "Módulo de produção de medicamentos",
      "files": ["pages/ProducaoDashboard.js", "pages/ProducaoQualidade.js"]
    },
    {
      "name": "CRM",
      "description": "Relacionamento com pacientes",
      "files": ["pages/CrmDashboard.js", "pages/CrmPacientes.js"]
    },
    {
      "name": "PatientPortal",
      "description": "Portal do Paciente PWA",
      "files": ["pages/PatientPortal.js", "components/PatientPortal/*"]
    },
    {
      "name": "Financeiro",
      "description": "Gestão financeira",
      "files": ["pages/FinanceiroDashboard.js", "pages/ContasPagar.js", "pages/ContasReceber.js"]
    }
  ],
  "keywords": [
    "cannabis-medicinal",
    "gestao-associacoes",
    "telemedicina",
    "pwa",
    "react",
    "tailwind",
    "saude",
    "compliance",
    "cultivo",
    "producao",
    "rastreabilidade"
  ]
};