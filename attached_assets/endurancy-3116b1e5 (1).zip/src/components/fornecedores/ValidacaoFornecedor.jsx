import React, { useState } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  FileCheck, 
  Shield, 
  Calendar, 
  Info, 
  Clock, 
  UploadCloud, 
  Save 
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/components/ui/use-toast";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Progress } from "@/components/ui/progress";
import { UploadFile } from "@/api/integrations";

export default function ValidacaoFornecedor({ fornecedor, onSave, onClose }) {
  const [isUploading, setIsUploading] = useState(false);
  const [validacaoStatus, setValidacaoStatus] = useState({
    documentos_fiscais: fornecedor?.validacao?.documentos_fiscais || false,
    capacidade_tecnica: fornecedor?.validacao?.capacidade_tecnica || false,
    documentos_regulatorios: fornecedor?.validacao?.documentos_regulatorios || false,
    sustentabilidade: fornecedor?.validacao?.sustentabilidade || false,
    qualidade: fornecedor?.validacao?.qualidade || false,
    financeiro: fornecedor?.validacao?.financeiro || false
  });

  const [comentarios, setComentarios] = useState(
    fornecedor?.validacao?.comentarios || {
      documentos_fiscais: "",
      capacidade_tecnica: "",
      documentos_regulatorios: "",
      sustentabilidade: "",
      qualidade: "",
      financeiro: "",
      conclusao: ""
    }
  );

  const [documentos, setDocumentos] = useState(
    fornecedor?.validacao?.documentos || [
      { tipo: "cnpj", nome: "Comprovante CNPJ", status: "pendente", url: "" },
      { tipo: "alvara", nome: "Alvará de Funcionamento", status: "pendente", url: "" },
      { tipo: "regulatorio", nome: "Autorização ANVISA", status: "pendente", url: "" },
      { tipo: "qualidade", nome: "Certificações de Qualidade", status: "pendente", url: "" },
      { tipo: "financeiro", nome: "Certidões Negativas", status: "pendente", url: "" }
    ]
  );

  const [statusFinal, setStatusFinal] = useState(fornecedor?.validacao?.status_final || "em_analise");
  const [validoAte, setValidoAte] = useState(fornecedor?.validacao?.valido_ate || "");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const calcularProgresso = () => {
    const camposValidados = Object.values(validacaoStatus).filter(Boolean).length;
    return (camposValidados / Object.keys(validacaoStatus).length) * 100;
  };

  const getStatusLabel = (status) => {
    switch(status) {
      case "aprovado": return <Badge className="bg-green-100 text-green-800">Aprovado</Badge>;
      case "reprovado": return <Badge className="bg-red-100 text-red-800">Reprovado</Badge>;
      case "pendente": return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case "em_analise": return <Badge className="bg-blue-100 text-blue-800">Em Análise</Badge>;
      default: return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  const handleStatusChange = (key, value) => {
    setValidacaoStatus(prev => ({ ...prev, [key]: value }));
  };

  const handleComentarioChange = (key, value) => {
    setComentarios(prev => ({ ...prev, [key]: value }));
  };

  const handleDocumentoStatusChange = (index, status) => {
    const newDocumentos = [...documentos];
    newDocumentos[index].status = status;
    setDocumentos(newDocumentos);
  };

  const handleUploadDocumento = async (index, file) => {
    if (!file) return;
    
    setIsUploading(true);
    
    try {
      const result = await UploadFile({ file });
      
      const newDocumentos = [...documentos];
      newDocumentos[index].url = result.file_url;
      newDocumentos[index].nome_arquivo = file.name;
      newDocumentos[index].status = "enviado";
      setDocumentos(newDocumentos);
      
      toast({
        title: "Documento enviado",
        description: "O documento foi enviado com sucesso",
      });
    } catch (error) {
      console.error("Erro ao fazer upload:", error);
      toast({
        title: "Erro ao enviar documento",
        description: "Ocorreu um erro ao enviar o documento. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleSaveValidacao = async () => {
    setIsSubmitting(true);
    
    try {
      // Se todos os critérios foram avaliados e o status final é "aprovado" mas não há data de validade
      if (calcularProgresso() === 100 && statusFinal === "aprovado" && !validoAte) {
        // Definir data de validade padrão para um ano à frente
        const hoje = new Date();
        const umAnoDepois = new Date(hoje.setFullYear(hoje.getFullYear() + 1));
        setValidoAte(umAnoDepois.toISOString().split('T')[0]);
      }
      
      const validacaoData = {
        status_final: statusFinal,
        documentos_fiscais: validacaoStatus.documentos_fiscais,
        capacidade_tecnica: validacaoStatus.capacidade_tecnica,
        documentos_regulatorios: validacaoStatus.documentos_regulatorios,
        sustentabilidade: validacaoStatus.sustentabilidade,
        qualidade: validacaoStatus.qualidade,
        financeiro: validacaoStatus.financeiro,
        comentarios: comentarios,
        documentos: documentos,
        valido_ate: validoAte,
        data_validacao: new Date().toISOString(),
        validador: "Admin" // Em um ambiente real, seria o usuário atual
      };
      
      // Em um ambiente real, isso seria uma chamada de API
      // await Fornecedor.updateValidacao(fornecedor.id, validacaoData);
      
      // Para demonstração, apenas simulamos o sucesso
      setTimeout(() => {
        toast({
          title: "Validação salva",
          description: "A validação do fornecedor foi salva com sucesso.",
        });
        
        onSave && onSave({
          ...fornecedor,
          validacao: validacaoData,
          status: statusFinal === "aprovado" ? "ativo" : 
                   statusFinal === "reprovado" ? "inativo" : "pendente"
        });
        
        setIsSubmitting(false);
      }, 1000);
      
    } catch (error) {
      console.error("Erro ao salvar validação:", error);
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar a validação. Tente novamente.",
        variant: "destructive",
      });
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Shield className="h-8 w-8 text-blue-600" />
          <div>
            <h2 className="text-2xl font-bold">Validação de Fornecedor</h2>
            <p className="text-gray-500">{fornecedor?.nome}</p>
          </div>
        </div>
        
        <Badge className="text-sm">
          {getStatusLabel(statusFinal)}
        </Badge>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex justify-between items-center">
            <span>Progresso da Validação</span>
            <span className="text-sm font-normal">{Math.round(calcularProgresso())}% Completo</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Progress value={calcularProgresso()} className="h-2 mb-6" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label>Status Final da Validação</Label>
              <Select 
                value={statusFinal} 
                onValueChange={setStatusFinal}
                className="mt-1"
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="em_analise">Em Análise</SelectItem>
                  <SelectItem value="aprovado">Aprovado</SelectItem>
                  <SelectItem value="reprovado">Reprovado</SelectItem>
                  <SelectItem value="pendente">Pendente de Informações</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {statusFinal === "aprovado" && (
              <div>
                <Label>Válido Até</Label>
                <Input 
                  type="date" 
                  value={validoAte} 
                  onChange={(e) => setValidoAte(e.target.value)}
                  className="mt-1"
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 gap-6">
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="documentos">
            <AccordionTrigger className="text-lg font-medium">
              <div className="flex items-center gap-2">
                <FileCheck className="h-5 w-5 text-blue-600" />
                <span>Documentos Requeridos</span>
              </div>
            </AccordionTrigger>
            <AccordionContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Documento</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {documentos.map((doc, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <div className="font-medium">{doc.nome}</div>
                        {doc.nome_arquivo && (
                          <div className="text-sm text-gray-500">{doc.nome_arquivo}</div>
                        )}
                      </TableCell>
                      <TableCell>
                        {doc.status === "aprovado" && (
                          <Badge className="bg-green-100 text-green-800">Aprovado</Badge>
                        )}
                        {doc.status === "reprovado" && (
                          <Badge className="bg-red-100 text-red-800">Reprovado</Badge>
                        )}
                        {doc.status === "pendente" && (
                          <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>
                        )}
                        {doc.status === "enviado" && (
                          <Badge className="bg-blue-100 text-blue-800">Enviado</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {doc.url ? (
                            <>
                              <Button variant="outline" size="sm" asChild>
                                <a href={doc.url} target="_blank" rel="noopener noreferrer">
                                  Visualizar
                                </a>
                              </Button>
                              <Select
                                value={doc.status}
                                onValueChange={(value) => handleDocumentoStatusChange(index, value)}
                              >
                                <SelectTrigger className="w-[140px] h-8">
                                  <SelectValue placeholder="Status" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="enviado">Enviado</SelectItem>
                                  <SelectItem value="aprovado">Aprovado</SelectItem>
                                  <SelectItem value="reprovado">Reprovado</SelectItem>
                                </SelectContent>
                              </Select>
                            </>
                          ) : (
                            <>
                              <input
                                type="file"
                                id={`file-${index}`}
                                className="hidden"
                                onChange={(e) => handleUploadDocumento(index, e.target.files[0])}
                              />
                              <Button variant="outline" size="sm" asChild>
                                <label htmlFor={`file-${index}`} className="cursor-pointer">
                                  <UploadCloud className="h-4 w-4 mr-1" />
                                  Upload
                                </label>
                              </Button>
                              <Select
                                value={doc.status}
                                onValueChange={(value) => handleDocumentoStatusChange(index, value)}
                              >
                                <SelectTrigger className="w-[140px] h-8">
                                  <SelectValue placeholder="Status" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="pendente">Pendente</SelectItem>
                                  <SelectItem value="aprovado">Aprovado</SelectItem>
                                  <SelectItem value="reprovado">Reprovado</SelectItem>
                                </SelectContent>
                              </Select>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="criterios">
            <AccordionTrigger className="text-lg font-medium">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-blue-600" />
                <span>Critérios de Validação</span>
              </div>
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <Label className="text-base">Documentos Fiscais e Legais</Label>
                        <p className="text-sm text-gray-500">CNPJ ativo, certidões negativas, etc.</p>
                      </div>
                      <Switch 
                        checked={validacaoStatus.documentos_fiscais}
                        onCheckedChange={(value) => handleStatusChange("documentos_fiscais", value)}
                      />
                    </div>
                    <Textarea 
                      placeholder="Observações sobre documentos fiscais..."
                      value={comentarios.documentos_fiscais}
                      onChange={(e) => handleComentarioChange("documentos_fiscais", e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <Label className="text-base">Capacidade Técnica</Label>
                        <p className="text-sm text-gray-500">Infraestrutura, equipe técnica, etc.</p>
                      </div>
                      <Switch 
                        checked={validacaoStatus.capacidade_tecnica}
                        onCheckedChange={(value) => handleStatusChange("capacidade_tecnica", value)}
                      />
                    </div>
                    <Textarea 
                      placeholder="Observações sobre capacidade técnica..."
                      value={comentarios.capacidade_tecnica}
                      onChange={(e) => handleComentarioChange("capacidade_tecnica", e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <Label className="text-base">Documentos Regulatórios</Label>
                        <p className="text-sm text-gray-500">Licenças, autorizações ANVISA, etc.</p>
                      </div>
                      <Switch 
                        checked={validacaoStatus.documentos_regulatorios}
                        onCheckedChange={(value) => handleStatusChange("documentos_regulatorios", value)}
                      />
                    </div>
                    <Textarea 
                      placeholder="Observações sobre documentos regulatórios..."
                      value={comentarios.documentos_regulatorios}
                      onChange={(e) => handleComentarioChange("documentos_regulatorios", e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <Label className="text-base">Sustentabilidade</Label>
                        <p className="text-sm text-gray-500">Práticas ambientais, certificações, etc.</p>
                      </div>
                      <Switch 
                        checked={validacaoStatus.sustentabilidade}
                        onCheckedChange={(value) => handleStatusChange("sustentabilidade", value)}
                      />
                    </div>
                    <Textarea 
                      placeholder="Observações sobre sustentabilidade..."
                      value={comentarios.sustentabilidade}
                      onChange={(e) => handleComentarioChange("sustentabilidade", e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <Label className="text-base">Sistema de Qualidade</Label>
                        <p className="text-sm text-gray-500">ISO 9001, BPF/GMP, etc.</p>
                      </div>
                      <Switch 
                        checked={validacaoStatus.qualidade}
                        onCheckedChange={(value) => handleStatusChange("qualidade", value)}
                      />
                    </div>
                    <Textarea 
                      placeholder="Observações sobre sistema de qualidade..."
                      value={comentarios.qualidade}
                      onChange={(e) => handleComentarioChange("qualidade", e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <Label className="text-base">Análise Financeira</Label>
                        <p className="text-sm text-gray-500">Saúde financeira, demonstrativos, etc.</p>
                      </div>
                      <Switch 
                        checked={validacaoStatus.financeiro}
                        onCheckedChange={(value) => handleStatusChange("financeiro", value)}
                      />
                    </div>
                    <Textarea 
                      placeholder="Observações sobre análise financeira..."
                      value={comentarios.financeiro}
                      onChange={(e) => handleComentarioChange("financeiro", e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="pt-4">
                  <Label className="text-base">Conclusão Final</Label>
                  <Textarea 
                    placeholder="Conclusão e recomendações finais sobre o fornecedor..."
                    className="mt-2"
                    value={comentarios.conclusao}
                    onChange={(e) => handleComentarioChange("conclusao", e.target.value)}
                  />
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
      
      <div className="flex justify-end gap-3">
        <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
          Cancelar
        </Button>
        <Button 
          onClick={handleSaveValidacao} 
          disabled={isSubmitting}
          className="gap-2"
        >
          {isSubmitting ? <Clock className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Salvar Validação
        </Button>
      </div>
    </div>
  );
}