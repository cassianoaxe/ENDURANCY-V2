import React from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Search,
  Edit,
  Eye,
  AlertTriangle,
  Package,
  CheckCircle,
  XCircle,
  AlertCircle
} from "lucide-react";

export default function EstoqueBaseView({
  title,
  description,
  tipoEstoque,
  data,
  loading,
  onAddItem,
  onEditItem,
  onViewDetails,
  customFilters
}) {
  const getStatusBadge = (status) => {
    const statusConfig = {
      disponivel: { color: "bg-green-100 text-green-800", icon: <CheckCircle className="w-4 h-4" /> },
      em_quarentena: { color: "bg-yellow-100 text-yellow-800", icon: <AlertCircle className="w-4 h-4" /> },
      em_analise: { color: "bg-blue-100 text-blue-800", icon: <Package className="w-4 h-4" /> },
      reprovado: { color: "bg-red-100 text-red-800", icon: <XCircle className="w-4 h-4" /> },
      descartado: { color: "bg-gray-100 text-gray-800", icon: <AlertTriangle className="w-4 h-4" /> }
    };

    const config = statusConfig[status] || statusConfig.em_analise;
    
    return (
      <Badge className={config.color}>
        <span className="flex items-center gap-1">
          {config.icon}
          {status.replace('_', ' ').charAt(0).toUpperCase() + status.slice(1)}
        </span>
      </Badge>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">{title}</h2>
          <p className="text-gray-500">{description}</p>
        </div>
        <Button onClick={onAddItem}>
          <Plus className="w-4 h-4 mr-2" />
          Adicionar Item
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Buscar..."
                className="pl-10"
              />
            </div>
            {customFilters}
          </div>

          {loading ? (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Código</TableHead>
                  <TableHead>Nome</TableHead>
                  <TableHead>Lote</TableHead>
                  <TableHead>Quantidade</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Validade</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.codigo}</TableCell>
                    <TableCell>{item.nome}</TableCell>
                    <TableCell>{item.lote}</TableCell>
                    <TableCell>
                      {item.quantidade_atual} {item.unidade_medida}
                      {item.quantidade_atual <= item.quantidade_minima && (
                        <Badge variant="destructive" className="ml-2">
                          Estoque Baixo
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>{getStatusBadge(item.status)}</TableCell>
                    <TableCell>{new Date(item.data_validade).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="sm" onClick={() => onViewDetails(item)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => onEditItem(item)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}