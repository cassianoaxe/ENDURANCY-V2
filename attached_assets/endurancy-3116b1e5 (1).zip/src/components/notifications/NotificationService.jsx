import { Notification } from "@/api/entities";
import { User } from "@/api/entities";

/**
 * Serviço de notificações da plataforma
 */
export class NotificationService {
  /**
   * Cria uma nova notificação
   * @param {string} recipientId - ID do usuário destinatário
   * @param {string} type - Tipo de notificação (alert, request, info, success, message)
   * @param {string} title - Título da notificação
   * @param {string} message - Mensagem da notificação
   * @param {object} options - Opções adicionais
   * @returns {Promise<object>} - A notificação criada
   */
  static async createNotification(recipientId, type, title, message, options = {}) {
    try {
      const notificationData = {
        recipient_id: recipientId,
        type,
        title,
        message,
        priority: options.priority || 'medium',
        is_read: false,
        related_type: options.relatedType || null,
        related_id: options.relatedId || null,
        action_url: options.actionUrl || null
      };
      
      const notification = await Notification.create(notificationData);
      return notification;
    } catch (error) {
      console.error("Erro ao criar notificação:", error);
      throw error;
    }
  }
  
  /**
   * Marca uma notificação como lida
   * @param {string} notificationId - ID da notificação
   * @returns {Promise<object>} - A notificação atualizada
   */
  static async markAsRead(notificationId) {
    try {
      const notification = await Notification.update(notificationId, { is_read: true });
      return notification;
    } catch (error) {
      console.error("Erro ao marcar notificação como lida:", error);
      throw error;
    }
  }
  
  /**
   * Marca todas as notificações do usuário como lidas
   * @param {string} userId - ID do usuário
   * @returns {Promise<number>} - Número de notificações atualizadas
   */
  static async markAllAsRead(userId) {
    try {
      const notifications = await Notification.filter({ recipient_id: userId, is_read: false });
      
      const updatePromises = notifications.map(notification => 
        Notification.update(notification.id, { is_read: true })
      );
      
      await Promise.all(updatePromises);
      return notifications.length;
    } catch (error) {
      console.error("Erro ao marcar todas notificações como lidas:", error);
      throw error;
    }
  }
  
  /**
   * Exclui uma notificação
   * @param {string} notificationId - ID da notificação
   * @returns {Promise<boolean>} - True se excluída com sucesso
   */
  static async deleteNotification(notificationId) {
    try {
      await Notification.delete(notificationId);
      return true;
    } catch (error) {
      console.error("Erro ao excluir notificação:", error);
      throw error;
    }
  }
  
  /**
   * Busca as notificações de um usuário
   * @param {string} userId - ID do usuário
   * @param {object} options - Opções de filtro
   * @returns {Promise<Array>} - Lista de notificações
   */
  static async getUserNotifications(userId, options = {}) {
    try {
      const filter = { recipient_id: userId };
      
      if (options.type && options.type !== 'all') {
        filter.type = options.type;
      }
      
      if (options.isRead !== undefined) {
        filter.is_read = options.isRead;
      }
      
      if (options.priority) {
        filter.priority = options.priority;
      }
      
      return await Notification.filter(filter, '-created_date', options.limit || 50);
    } catch (error) {
      console.error("Erro ao buscar notificações do usuário:", error);
      throw error;
    }
  }
  
  /**
   * Conta notificações não lidas do usuário
   * @param {string} userId - ID do usuário
   * @returns {Promise<number>} - Número de notificações não lidas
   */
  static async countUnreadNotifications(userId) {
    try {
      const unreadNotifications = await Notification.filter({ 
        recipient_id: userId,
        is_read: false
      });
      
      return unreadNotifications.length;
    } catch (error) {
      console.error("Erro ao contar notificações não lidas:", error);
      throw error;
    }
  }
  
  /**
   * Notifica sobre uma nova organização
   * @param {string} adminId - ID do administrador para notificar
   * @param {string} organizationName - Nome da organização
   * @param {string} organizationId - ID da organização
   * @returns {Promise<object>} - A notificação criada
   */
  static async notifyNewOrganization(adminId, organizationName, organizationId) {
    return this.createNotification(
      adminId,
      'request',
      'Nova solicitação de organização',
      `A organização '${organizationName}' solicitou acesso à plataforma.`,
      {
        priority: 'medium',
        relatedType: 'organization',
        relatedId: organizationId,
        actionUrl: `/admin/request?id=${organizationId}`
      }
    );
  }
  
  /**
   * Notifica sobre uma organização aprovada
   * @param {string} userId - ID do usuário para notificar
   * @param {string} organizationName - Nome da organização
   * @param {string} organizationId - ID da organização
   * @param {string} approverName - Nome de quem aprovou
   * @returns {Promise<object>} - A notificação criada
   */
  static async notifyOrganizationApproved(userId, organizationName, organizationId, approverName) {
    return this.createNotification(
      userId,
      'success',
      'Organização aprovada',
      `A organização '${organizationName}' foi aprovada por ${approverName}.`,
      {
        priority: 'high',
        relatedType: 'organization',
        relatedId: organizationId,
        actionUrl: `/organization/${organizationId}`
      }
    );
  }
  
  /**
   * Notifica sobre uma organização rejeitada
   * @param {string} userId - ID do usuário para notificar
   * @param {string} organizationName - Nome da organização
   * @param {string} organizationId - ID da organização
   * @param {string} rejectionReason - Motivo da rejeição
   * @returns {Promise<object>} - A notificação criada
   */
  static async notifyOrganizationRejected(userId, organizationName, organizationId, rejectionReason) {
    return this.createNotification(
      userId,
      'alert',
      'Organização rejeitada',
      `A organização '${organizationName}' foi rejeitada. Motivo: ${rejectionReason}`,
      {
        priority: 'high',
        relatedType: 'organization',
        relatedId: organizationId,
        actionUrl: `/organization/${organizationId}`
      }
    );
  }
  
  /**
   * Notifica sobre um documento rejeitado
   * @param {string} userId - ID do usuário para notificar
   * @param {string} documentName - Nome do documento
   * @param {string} documentId - ID do documento
   * @param {string} rejectionReason - Motivo da rejeição
   * @returns {Promise<object>} - A notificação criada
   */
  static async notifyDocumentRejected(userId, documentName, documentId, rejectionReason) {
    return this.createNotification(
      userId,
      'alert',
      'Documento rejeitado',
      `O documento '${documentName}' foi rejeitado. Motivo: ${rejectionReason}`,
      {
        priority: 'medium',
        relatedType: 'document',
        relatedId: documentId,
        actionUrl: `/documents?id=${documentId}`
      }
    );
  }
  
  /**
   * Notifica sobre um alerta de segurança
   * @param {string} userId - ID do usuário para notificar
   * @param {string} title - Título do alerta
   * @param {string} message - Mensagem do alerta
   * @returns {Promise<object>} - A notificação criada
   */
  static async notifySecurityAlert(userId, title, message) {
    return this.createNotification(
      userId,
      'alert',
      title,
      message,
      {
        priority: 'high',
        relatedType: 'security',
        actionUrl: `/settings?tab=security`
      }
    );
  }
}

export default NotificationService;