import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Spinner } from "@/components/ui/spinner";
import { toast } from "@/components/ui/use-toast";
import ValidadorCPF from '@/components/validadores/ValidadorCPF';
import { 
  User, 
  MapPin,
  Phone,
  Mail,
  Calendar,
  Save,
  AlertTriangle,
  Upload,
  FileText,
  Heart,
  Clock,
  Check,
  AlertCircle
} from 'lucide-react';

export default function FormularioAssociado({ 
  associado = null, 
  isLoading = false, 
  onSubmit 
}) {
  const isEditMode = !!associado?.id;
  
  const [formData, setFormData] = useState({
    nome_completo: '',
    cpf: '',
    rg: '',
    data_nascimento: '',
    email: '',
    telefone: '',
    telefone_alternativo: '',
    cep: '',
    endereco: '',
    bairro: '',
    cidade: '',
    estado: '',
    status: 'pendente',
    tipo_associado: 'regular',
    situacao_financeira: 'em_dia',
    observacoes: '',
    condicoes_medicas: '',
    medicamentos_atuais: '',
    como_conheceu: '',
    cpf_valido: false, // Status de validação do CPF
    cpf_validado: false // Se o CPF já foi validado
  });
  
  const [validando, setValidando] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState('dados_pessoais');
  
  useEffect(() => {
    if (associado) {
      setFormData({
        ...associado,
        cpf_valido: true, // Assume que o CPF é válido para registros existentes
        cpf_validado: true
      });
    }
  }, [associado]);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Reset CPF validation if the CPF changes
    if (name === 'cpf') {
      setFormData(prev => ({ 
        ...prev, 
        cpf_valido: false,
        cpf_validado: false
      }));
    }
  };
  
  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleCPFChange = (value) => {
    setFormData(prev => ({ ...prev, cpf: value }));
  };
  
  const handleCPFValidation = (result) => {
    setFormData(prev => ({ 
      ...prev, 
      cpf_valido: result.valid,
      cpf_validado: result.checked
    }));
    
    // Se o CPF foi verificado mas é inválido, mostra alerta
    if (result.checked && !result.valid) {
      toast({
        title: "Atenção",
        description: "O CPF informado não é válido. Verifique as informações.",
        variant: "destructive",
      });
    }
  };
  
  const buscarCEP = async (cep) => {
    if (!cep || cep.length < 8) return;
    
    setValidando(true);
    
    try {
      const formattedCEP = cep.replace(/\D/g, '');
      const response = await fetch(`https://viacep.com.br/ws/${formattedCEP}/json/`);
      const data = await response.json();
      
      if (!data.erro) {
        setFormData(prev => ({
          ...prev,
          endereco: `${data.logradouro}`,
          bairro: data.bairro,
          cidade: data.localidade,
          estado: data.uf
        }));
        
        toast({
          title: "CEP encontrado",
          description: "Endereço preenchido automaticamente."
        });
      } else {
        toast({
          title: "CEP não encontrado",
          description: "Verifique o CEP informado ou preencha o endereço manualmente.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro ao buscar CEP",
        description: "Não foi possível consultar o CEP. Preencha o endereço manualmente.",
        variant: "destructive",
      });
    } finally {
      setValidando(false);
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Verificar CPF
    if (!formData.cpf_valido) {
      setActiveTab('dados_pessoais');
      toast({
        title: "CPF não validado",
        description: "É necessário validar o CPF antes de prosseguir.",
        variant: "destructive",
      });
      return;
    }
    
    // Validar campos obrigatórios
    const requiredFields = [
      'nome_completo', 'cpf', 'email', 'telefone',
      'cep', 'endereco', 'cidade', 'estado'
    ];
    
    const missingFields = requiredFields.filter(field => !formData[field]);
    
    if (missingFields.length > 0) {
      // Set active tab to the one containing the first missing field
      if (missingFields.some(field => ['nome_completo', 'cpf', 'email', 'telefone'].includes(field))) {
        setActiveTab('dados_pessoais');
      } else if (missingFields.some(field => ['cep', 'endereco', 'cidade', 'estado'].includes(field))) {
        setActiveTab('endereco');
      }
      
      toast({
        title: "Dados incompletos",
        description: "Preencha todos os campos obrigatórios antes de salvar.",
        variant: "destructive",
      });
      return;
    }
    
    setSubmitting(true);
    
    try {
      // Adiciona organization_id se for um novo registro
      const dataToSubmit = {
        ...formData,
        organization_id: formData.organization_id || "org-default-id"
      };
      
      await onSubmit(dataToSubmit);
      
      toast({
        title: isEditMode ? "Associado atualizado" : "Associado cadastrado",
        description: isEditMode 
          ? "Os dados do associado foram atualizados com sucesso."
          : "O novo associado foi cadastrado com sucesso."
      });
    } catch (error) {
      console.error('Erro ao salvar:', error);
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar os dados. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3">
          <TabsTrigger value="dados_pessoais" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span>Dados Pessoais</span>
          </TabsTrigger>
          <TabsTrigger value="endereco" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span>Endereço</span>
          </TabsTrigger>
          <TabsTrigger value="complementar" className="flex items-center gap-2">
            <Heart className="h-4 w-4" />
            <span>Informações Complementares</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Tab Dados Pessoais */}
        <TabsContent value="dados_pessoais" className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nome_completo">
                  Nome completo<span className="text-red-500">*</span>
                </Label>
                <Input
                  id="nome_completo"
                  name="nome_completo"
                  placeholder="Nome completo do associado"
                  value={formData.nome_completo}
                  onChange={handleInputChange}
                  disabled={isLoading || submitting}
                />
              </div>
              
              <ValidadorCPF 
                value={formData.cpf}
                onChange={handleCPFChange}
                onValidationResult={handleCPFValidation}
                validarNaReceita={true}
                disabled={isLoading || submitting}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="rg">RG</Label>
                  <Input
                    id="rg"
                    name="rg"
                    placeholder="Número do RG"
                    value={formData.rg}
                    onChange={handleInputChange}
                    disabled={isLoading || submitting}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="data_nascimento">
                    Data de Nascimento<span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="data_nascimento"
                    name="data_nascimento"
                    type="date"
                    value={formData.data_nascimento}
                    onChange={handleInputChange}
                    disabled={isLoading || submitting}
                  />
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">
                  Email<span className="text-red-500">*</span>
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="email@exemplo.com.br"
                  value={formData.email}
                  onChange={handleInputChange}
                  disabled={isLoading || submitting}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefone">
                    Telefone<span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="telefone"
                    name="telefone"
                    placeholder="(00) 00000-0000"
                    value={formData.telefone}
                    onChange={handleInputChange}
                    disabled={isLoading || submitting}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="telefone_alternativo">Telefone Alternativo</Label>
                  <Input
                    id="telefone_alternativo"
                    name="telefone_alternativo"
                    placeholder="(00) 00000-0000"
                    value={formData.telefone_alternativo}
                    onChange={handleInputChange}
                    disabled={isLoading || submitting}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => handleSelectChange('status', value)}
                    disabled={isLoading || submitting}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="pendente">Pendente</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                      <SelectItem value="suspenso">Suspenso</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tipo_associado">Tipo de Associado</Label>
                  <Select
                    value={formData.tipo_associado}
                    onValueChange={(value) => handleSelectChange('tipo_associado', value)}
                    disabled={isLoading || submitting}
                  >
                    <SelectTrigger id="tipo_associado">
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="regular">Regular</SelectItem>
                      <SelectItem value="fundador">Fundador</SelectItem>
                      <SelectItem value="honorario">Honorário</SelectItem>
                      <SelectItem value="colaborador">Colaborador</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
          
          {!formData.cpf_valido && formData.cpf && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 text-yellow-800 text-sm flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Atenção: CPF não validado</p>
                <p>É necessário validar o CPF antes de prosseguir com o cadastro.</p>
              </div>
            </div>
          )}
          
          <div className="flex justify-end">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setActiveTab('endereco')}
              className="flex items-center gap-2"
            >
              Próximo
              <MapPin className="h-4 w-4" />
            </Button>
          </div>
        </TabsContent>
        
        {/* Tab Endereço */}
        <TabsContent value="endereco" className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex gap-2 items-end">
                <div className="flex-grow space-y-2">
                  <Label htmlFor="cep">
                    CEP<span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="cep"
                    name="cep"
                    placeholder="00000-000"
                    value={formData.cep}
                    onChange={handleInputChange}
                    disabled={isLoading || validando || submitting}
                  />
                </div>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => buscarCEP(formData.cep)}
                  disabled={isLoading || !formData.cep || formData.cep.length < 8 || validando || submitting}
                >
                  {validando ? <Spinner size="small" className="mr-2" /> : null}
                  Buscar CEP
                </Button>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="endereco">
                  Endereço<span className="text-red-500">*</span>
                </Label>
                <Input
                  id="endereco"
                  name="endereco"
                  placeholder="Rua, número e complemento"
                  value={formData.endereco}
                  onChange={handleInputChange}
                  disabled={isLoading || validando || submitting}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bairro">Bairro</Label>
                <Input
                  id="bairro"
                  name="bairro"
                  placeholder="Bairro"
                  value={formData.bairro}
                  onChange={handleInputChange}
                  disabled={isLoading || validando || submitting}
                />
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="cidade">
                  Cidade<span className="text-red-500">*</span>
                </Label>
                <Input
                  id="cidade"
                  name="cidade"
                  placeholder="Cidade"
                  value={formData.cidade}
                  onChange={handleInputChange}
                  disabled={isLoading || validando || submitting}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="estado">
                  Estado<span className="text-red-500">*</span>
                </Label>
                <Select
                  value={formData.estado}
                  onValueChange={(value) => handleSelectChange('estado', value)}
                  disabled={isLoading || validando || submitting}
                >
                  <SelectTrigger id="estado">
                    <SelectValue placeholder="Selecione o estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AC">Acre</SelectItem>
                    <SelectItem value="AL">Alagoas</SelectItem>
                    <SelectItem value="AP">Amapá</SelectItem>
                    <SelectItem value="AM">Amazonas</SelectItem>
                    <SelectItem value="BA">Bahia</SelectItem>
                    <SelectItem value="CE">Ceará</SelectItem>
                    <SelectItem value="DF">Distrito Federal</SelectItem>
                    <SelectItem value="ES">Espírito Santo</SelectItem>
                    <SelectItem value="GO">Goiás</SelectItem>
                    <SelectItem value="MA">Maranhão</SelectItem>
                    <SelectItem value="MT">Mato Grosso</SelectItem>
                    <SelectItem value="MS">Mato Grosso do Sul</SelectItem>
                    <SelectItem value="MG">Minas Gerais</SelectItem>
                    <SelectItem value="PA">Pará</SelectItem>
                    <SelectItem value="PB">Paraíba</SelectItem>
                    <SelectItem value="PR">Paraná</SelectItem>
                    <SelectItem value="PE">Pernambuco</SelectItem>
                    <SelectItem value="PI">Piauí</SelectItem>
                    <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                    <SelectItem value="RN">Rio Grande do Norte</SelectItem>
                    <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                    <SelectItem value="RO">Rondônia</SelectItem>
                    <SelectItem value="RR">Roraima</SelectItem>
                    <SelectItem value="SC">Santa Catarina</SelectItem>
                    <SelectItem value="SP">São Paulo</SelectItem>
                    <SelectItem value="SE">Sergipe</SelectItem>
                    <SelectItem value="TO">Tocantins</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          <div className="flex justify-between">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setActiveTab('dados_pessoais')}
              className="flex items-center gap-2"
            >
              <User className="h-4 w-4" />
              Voltar
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setActiveTab('complementar')}
              className="flex items-center gap-2"
            >
              Próximo
              <Heart className="h-4 w-4" />
            </Button>
          </div>
        </TabsContent>
        
        {/* Tab Informações Complementares */}
        <TabsContent value="complementar" className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="condicoes_medicas">Condições Médicas</Label>
                <Textarea
                  id="condicoes_medicas"
                  name="condicoes_medicas"
                  placeholder="Liste as condições médicas do associado"
                  value={formData.condicoes_medicas}
                  onChange={handleInputChange}
                  disabled={isLoading || submitting}
                  className="min-h-24"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="medicamentos_atuais">Medicamentos em Uso</Label>
                <Textarea
                  id="medicamentos_atuais"
                  name="medicamentos_atuais"
                  placeholder="Liste os medicamentos que o associado utiliza atualmente"
                  value={formData.medicamentos_atuais}
                  onChange={handleInputChange}
                  disabled={isLoading || submitting}
                  className="min-h-24"
                />
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="como_conheceu">Como Conheceu a Associação</Label>
                <Select
                  value={formData.como_conheceu}
                  onValueChange={(value) => handleSelectChange('como_conheceu', value)}
                  disabled={isLoading || submitting}
                >
                  <SelectTrigger id="como_conheceu">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="indicacao">Indicação</SelectItem>
                    <SelectItem value="redes_sociais">Redes Sociais</SelectItem>
                    <SelectItem value="site">Site</SelectItem>
                    <SelectItem value="eventos">Eventos</SelectItem>
                    <SelectItem value="midia">Mídia</SelectItem>
                    <SelectItem value="outros">Outros</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="situacao_financeira">Situação Financeira</Label>
                <Select
                  value={formData.situacao_financeira}
                  onValueChange={(value) => handleSelectChange('situacao_financeira', value)}
                  disabled={isLoading || submitting}
                >
                  <SelectTrigger id="situacao_financeira">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="em_dia">Em dia</SelectItem>
                    <SelectItem value="inadimplente">Inadimplente</SelectItem>
                    <SelectItem value="isento">Isento</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações Gerais</Label>
                <Textarea
                  id="observacoes"
                  name="observacoes"
                  placeholder="Observações adicionais sobre o associado"
                  value={formData.observacoes}
                  onChange={handleInputChange}
                  disabled={isLoading || submitting}
                  className="min-h-24"
                />
              </div>
            </div>
          </div>
          
          <div className="flex justify-between">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setActiveTab('endereco')}
              className="flex items-center gap-2"
            >
              <MapPin className="h-4 w-4" />
              Voltar
            </Button>
            
            <Button 
              type="submit" 
              variant="default" 
              className="flex items-center gap-2"
              disabled={isLoading || submitting || (!formData.cpf_valido && formData.cpf)}
            >
              {submitting ? (
                <>
                  <Spinner size="small" className="mr-2" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  {isEditMode ? 'Atualizar Associado' : 'Cadastrar Associado'}
                </>
              )}
            </Button>
          </div>
        </TabsContent>
      </Tabs>
      
      {!formData.cpf_valido && formData.cpf && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 text-yellow-800 text-sm flex items-start gap-2">
          <AlertCircle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium">Validação de CPF pendente</p>
            <p>O CPF informado precisa ser validado antes de salvar o cadastro. Volte para a aba "Dados Pessoais" e clique em "Validar".</p>
          </div>
        </div>
      )}
    </form>
  );
}