import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  PlayCircle, 
  FileText, 
  MousePointerClick,
  CheckCircle,
  Clock
} from 'lucide-react';

const ModuleContent = ({ module }) => {
  // Function to get the appropriate icon based on tutorial type
  const getTypeIcon = (type) => {
    switch (type) {
      case 'video':
        return <PlayCircle className="w-4 h-4 text-blue-500" />;
      case 'text':
        return <FileText className="w-4 h-4 text-emerald-500" />;
      case 'interactive':
        return <MousePointerClick className="w-4 h-4 text-amber-500" />;
      default:
        return <FileText className="w-4 h-4 text-gray-500" />;
    }
  };

  // Calculate module progress
  const completedTutorials = module.tutorials.filter(tutorial => tutorial.completed).length;
  const progressPercentage = Math.round((completedTutorials / module.tutorials.length) * 100);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">{module.title}</h3>
        <Badge variant="outline">
          {completedTutorials}/{module.tutorials.length}
        </Badge>
      </div>
      
      <Progress value={progressPercentage} className="h-2" />
      
      <div className="space-y-2">
        {module.tutorials.map((tutorial) => (
          <div 
            key={tutorial.id}
            className={`p-3 border rounded-lg flex justify-between items-center hover:bg-gray-50 transition-colors cursor-pointer ${
              tutorial.completed ? 'border-green-200 bg-green-50 hover:bg-green-50/80' : 'border-gray-200'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0">
                {getTypeIcon(tutorial.type)}
              </div>
              <div>
                <p className="font-medium">{tutorial.title}</p>
                <p className="text-xs text-gray-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {tutorial.duration}
                </p>
              </div>
            </div>
            
            {tutorial.completed && (
              <CheckCircle className="w-5 h-5 text-green-500" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ModuleContent;