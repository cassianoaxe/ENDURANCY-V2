import React, { useState, useEffect } from 'react';
import { Badge } from "@/components/ui/badge";
import { Building2 } from 'lucide-react';
import { User } from '@/api/entities';
import { Organization } from '@/api/entities';

export default function OrganizationHeader() {
  const [userInfo, setUserInfo] = useState({ name: '', organization: '', type: '' });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Load current user and organization
    const fetchUserInfo = async () => {
      try {
        setIsLoading(true);
        
        // Try to get user data from localStorage (for mock purposes)
        const mockUserName = localStorage.getItem('mockUserName');
        const mockOrgType = localStorage.getItem('mockOrgType');
        
        if (mockUserName) {
          // For demo, use mock data
          setUserInfo({
            name: mockUserName || 'Usuário',
            organization: 'Organização Demo',
            type: mockOrgType || 'Associação'
          });
        } else {
          // In production, would fetch from API
          try {
            const user = await User.me();
            const org = await Organization.filter({ id: user.organization_id });
            
            if (org && org.length > 0) {
              setUserInfo({
                name: user.full_name,
                organization: org[0].name,
                type: org[0].type || 'Associação'
              });
            } else {
              setUserInfo({
                name: user.full_name,
                organization: 'Organização',
                type: 'Associação'
              });
            }
          } catch (error) {
            console.error("Error fetching user/org data:", error);
            // Fallback to demo data
            setUserInfo({
              name: 'Usuário',
              organization: 'Organização Demo',
              type: 'Associação'
            });
          }
        }
      } catch (error) {
        console.error("Error in user info fetch:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserInfo();
  }, []);

  if (isLoading) {
    return <div className="text-sm text-gray-400">Carregando informações...</div>;
  }

  return (
    <div className="flex items-center gap-2 mt-1 text-gray-600 dark:text-gray-300">
      <span className="font-medium">{userInfo.name}</span>
      <span>•</span>
      <div className="flex items-center gap-1">
        <Building2 className="w-4 h-4" />
        <span>{userInfo.organization}</span>
      </div>
      <span>•</span>
      <Badge variant="outline" className="text-xs font-normal py-0">
        {userInfo.type}
      </Badge>
    </div>
  );
}