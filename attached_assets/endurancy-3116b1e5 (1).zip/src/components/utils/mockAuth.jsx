// Create a new utility for mock authentication
export const checkMockAuth = () => {
  try {
    const userType = localStorage.getItem('mockUserType');
    const userEmail = localStorage.getItem('mockUserEmail');
    
    if (!userType || !userEmail) {
      return false;
    }
    
    return {
      userType,
      userEmail,
      userName: localStorage.getItem('mockUserName') || 'Usuário Demo'
    };
  } catch (error) {
    console.error("Error checking auth:", error);
    return false;
  }
};

export const getMockOrganization = () => {
  return {
    id: "mock-org-1",
    name: "Organização Demo",
    type: "Empresa",
    status: "active"
  };
};