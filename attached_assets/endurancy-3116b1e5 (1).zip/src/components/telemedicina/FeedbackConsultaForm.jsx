import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import {
  Star,
  ThumbsUp,
  ThumbsDown,
  MessageSquare,
  LightbulbIcon,
  SendIcon,
  ChevronRight,
  Check,
  X,
  HeartHandshake
} from "lucide-react";
import { toast } from "@/components/ui/use-toast";

const StarRating = ({ rating, setRating, size = "md", disabled = false }) => {
  const sizeClass = {
    sm: "w-4 h-4",
    md: "w-6 h-6",
    lg: "w-8 h-8"
  }[size];

  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          onClick={() => !disabled && setRating(star)}
          className={`text-gray-300 ${disabled ? 'cursor-default' : 'hover:text-yellow-400'} ${
            star <= rating ? 'text-yellow-400' : ''
          }`}
          disabled={disabled}
        >
          <Star className={`fill-current ${sizeClass}`} />
        </button>
      ))}
    </div>
  );
};

export default function FeedbackConsultaForm({ consulta, onSubmit, onCancel }) {
  const [loading, setLoading] = useState(false);
  const [generalRating, setGeneralRating] = useState(0);
  const [detailedRatings, setDetailedRatings] = useState({
    qualidade_conexao: 0,
    facilidade_uso: 0,
    comunicacao: 0,
    atendimento_expectativas: 0,
    resolucao_problemas: 0
  });
  const [comments, setComments] = useState('');
  const [suggestions, setSuggestions] = useState('');
  const [positivePoints, setPositivePoints] = useState([]);
  const [problems, setProblems] = useState([]);
  const [wouldRecommend, setWouldRecommend] = useState(true);
  const [wouldUseAgain, setWouldUseAgain] = useState(true);
  const [allowPublish, setAllowPublish] = useState(false);
  const [step, setStep] = useState(1);
  
  const commonPositivePoints = [
    "Atendimento pontual",
    "Médico atencioso",
    "Explicações claras",
    "Plataforma fácil de usar",
    "Boa qualidade de vídeo e áudio",
    "Economia de tempo e deslocamento",
    "Prescrição clara e detalhada"
  ];
  
  const commonProblems = [
    "Dificuldades com a tecnologia",
    "Problemas de conexão",
    "Atraso no atendimento",
    "Dificuldade para anexar documentos",
    "Explicações insuficientes",
    "Interrupções durante a consulta"
  ];
  
  const isFormValid = () => {
    if (step === 1) {
      return generalRating > 0;
    }
    
    if (step === 2) {
      return Object.values(detailedRatings).every(rating => rating > 0);
    }
    
    // Step 3 doesn't have required fields
    return true;
  };
  
  const handleDetailedRatingChange = (key, value) => {
    setDetailedRatings({
      ...detailedRatings,
      [key]: value
    });
  };
  
  const handlePositivePointToggle = (point) => {
    setPositivePoints(
      positivePoints.includes(point)
        ? positivePoints.filter(p => p !== point)
        : [...positivePoints, point]
    );
  };
  
  const handleProblemToggle = (problem) => {
    setProblems(
      problems.includes(problem)
        ? problems.filter(p => p !== problem)
        : [...problems, problem]
    );
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!isFormValid()) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios antes de continuar.",
        variant: "destructive"
      });
      return;
    }
    
    if (step < 3) {
      setStep(step + 1);
      return;
    }
    
    setLoading(true);
    
    try {
      const feedbackData = {
        consulta_id: consulta.id,
        tipo_consulta: consulta.tipo_consulta,
        avaliacao_geral: generalRating,
        avaliacoes_detalhadas: detailedRatings,
        comentarios: comments,
        sugestoes_melhorias: suggestions,
        pontos_positivos: positivePoints,
        problemas_relatos: problems,
        recomendaria: wouldRecommend,
        usaria_novamente: wouldUseAgain,
        permitir_publicar: allowPublish,
        data_feedback: new Date().toISOString()
      };
      
      // Simular atraso
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (onSubmit) {
        onSubmit(feedbackData);
      }
      
      toast({
        title: "Feedback enviado",
        description: "Obrigado por compartilhar sua avaliação! Isso nos ajuda a melhorar continuamente o atendimento.",
      });
      
    } catch (error) {
      console.error("Erro ao enviar feedback:", error);
      toast({
        title: "Erro ao enviar feedback",
        description: "Ocorreu um erro ao enviar sua avaliação. Por favor, tente novamente.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="text-xl">Avaliação da sua consulta</CardTitle>
        <CardDescription>
          {consulta.medico_nome && <span>com {consulta.medico_nome} em {new Date(consulta.data_hora).toLocaleDateString()}</span>}
        </CardDescription>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          {step === 1 && (
            <div className="space-y-6">
              <div className="space-y-2 text-center">
                <h3 className="text-lg font-medium">Como você avalia sua experiência geral?</h3>
                <p className="text-sm text-gray-500">
                  Sua avaliação sincera nos ajuda a melhorar o atendimento.
                </p>
                <div className="flex justify-center pt-4">
                  <StarRating rating={generalRating} setRating={setGeneralRating} size="lg" />
                </div>
                <div className="flex justify-between mt-2 text-sm text-gray-500 px-2">
                  <span>Insatisfeito</span>
                  <span>Excelente</span>
                </div>
              </div>
              
              <div>
                <Label htmlFor="comments">Comentários</Label>
                <Textarea
                  id="comments"
                  placeholder="Compartilhe sua experiência com a consulta..."
                  className="mt-1"
                  rows={4}
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                />
              </div>
            </div>
          )}
          
          {step === 2 && (
            <div className="space-y-6">
              <div className="text-center mb-4">
                <h3 className="text-lg font-medium">Avaliação detalhada</h3>
                <p className="text-sm text-gray-500">
                  Ajude-nos a entender melhor diferentes aspectos da sua consulta.
                </p>
              </div>
            
              <div className="grid gap-6">
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <Label>Qualidade da conexão e vídeo</Label>
                    <StarRating 
                      rating={detailedRatings.qualidade_conexao} 
                      setRating={(value) => handleDetailedRatingChange('qualidade_conexao', value)}
                    />
                  </div>
                  <p className="text-xs text-gray-500">Como foi a qualidade do áudio e vídeo durante a consulta</p>
                </div>
                
                <Separator />
                
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <Label>Facilidade de uso da plataforma</Label>
                    <StarRating 
                      rating={detailedRatings.facilidade_uso} 
                      setRating={(value) => handleDetailedRatingChange('facilidade_uso', value)}
                    />
                  </div>
                  <p className="text-xs text-gray-500">Quão fácil foi usar a plataforma de telemedicina</p>
                </div>
                
                <Separator />
                
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <Label>Comunicação com o médico</Label>
                    <StarRating 
                      rating={detailedRatings.comunicacao} 
                      setRating={(value) => handleDetailedRatingChange('comunicacao', value)}
                    />
                  </div>
                  <p className="text-xs text-gray-500">Qualidade da comunicação e interação com o profissional</p>
                </div>
                
                <Separator />
                
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <Label>Atendimento às expectativas</Label>
                    <StarRating 
                      rating={detailedRatings.atendimento_expectativas} 
                      setRating={(value) => handleDetailedRatingChange('atendimento_expectativas', value)}
                    />
                  </div>
                  <p className="text-xs text-gray-500">Se a consulta atendeu ao que você esperava</p>
                </div>
                
                <Separator />
                
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <Label>Resolução do problema</Label>
                    <StarRating 
                      rating={detailedRatings.resolucao_problemas} 
                      setRating={(value) => handleDetailedRatingChange('resolucao_problemas', value)}
                    />
                  </div>
                  <p className="text-xs text-gray-500">Se a consulta ajudou a resolver suas questões de saúde</p>
                </div>
              </div>
            </div>
          )}
          
          {step === 3 && (
            <div className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">O que você mais gostou?</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {commonPositivePoints.map((point) => (
                    <div key={point} className="flex items-center space-x-2">
                      <Checkbox
                        id={`positive-${point}`}
                        checked={positivePoints.includes(point)}
                        onCheckedChange={() => handlePositivePointToggle(point)}
                      />
                      <label
                        htmlFor={`positive-${point}`}
                        className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {point}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Você enfrentou algum destes problemas?</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {commonProblems.map((problem) => (
                    <div key={problem} className="flex items-center space-x-2">
                      <Checkbox
                        id={`problem-${problem}`}
                        checked={problems.includes(problem)}
                        onCheckedChange={() => handleProblemToggle(problem)}
                      />
                      <label
                        htmlFor={`problem-${problem}`}
                        className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {problem}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <Label htmlFor="suggestions">Sugestões para melhorias</Label>
                <Textarea
                  id="suggestions"
                  placeholder="O que podemos fazer para melhorar sua experiência?"
                  className="mt-1"
                  rows={3}
                  value={suggestions}
                  onChange={(e) => setSuggestions(e.target.value)}
                />
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <RadioGroup defaultValue={wouldRecommend ? "yes" : "no"} onValueChange={(v) => setWouldRecommend(v === "yes")}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="yes" id="recommend-yes" />
                      <Label htmlFor="recommend-yes">Eu recomendaria este serviço</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="no" id="recommend-no" />
                      <Label htmlFor="recommend-no">Eu não recomendaria este serviço</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="flex items-center space-x-2">
                  <RadioGroup defaultValue={wouldUseAgain ? "yes" : "no"} onValueChange={(v) => setWouldUseAgain(v === "yes")}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="yes" id="use-again-yes" />
                      <Label htmlFor="use-again-yes">Eu usaria este serviço novamente</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="no" id="use-again-no" />
                      <Label htmlFor="use-again-no">Eu não usaria este serviço novamente</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="allow-publish" 
                  checked={allowPublish} 
                  onCheckedChange={setAllowPublish}
                />
                <Label htmlFor="allow-publish" className="text-sm">
                  Permito que meu feedback seja publicado anonimamente para ajudar outros pacientes
                </Label>
              </div>
            </div>
          )}
        </CardContent>
        
        <CardFooter className="flex justify-between">
          {step > 1 ? (
            <Button type="button" variant="outline" onClick={() => setStep(step - 1)}>
              Voltar
            </Button>
          ) : (
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancelar
            </Button>
          )}
          
          <Button type="submit" disabled={!isFormValid() || loading}>
            {loading ? (
              <span className="flex items-center gap-1">
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Enviando...
              </span>
            ) : step < 3 ? (
              <span className="flex items-center gap-1">
                Continuar <ChevronRight className="h-4 w-4" />
              </span>
            ) : (
              <span className="flex items-center gap-1">
                Enviar feedback <SendIcon className="h-4 w-4" />
              </span>
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}