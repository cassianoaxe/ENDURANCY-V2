import { Activity } from "@/api/entities";
import { User } from "@/api/entities";

/**
 * Serviço para registro de atividades no sistema
 */
export class ActivityLogger {
  /**
   * Registra uma nova atividade no sistema
   * @param {string} type - Tipo de atividade
   * @param {string} entityType - Tipo de entidade relacionada
   * @param {string} entityId - ID da entidade relacionada
   * @param {string} details - Detalhes da atividade
   * @param {object} options - Opções adicionais
   * @returns {Promise<object>} - A atividade registrada
   */
  static async log(type, entityType, entityId, details, options = {}) {
    try {
      // Tenta obter o usuário atual
      let currentUser = null;
      try {
        currentUser = await User.me();
      } catch (e) {
        // Usuário não está autenticado, prossegue sem dados de usuário
      }
      
      const activityData = {
        type,
        entity_type: entityType,
        entity_id: entityId,
        details,
        notes: options.notes || null,
        ip_address: options.ipAddress || null,
        user_agent: options.userAgent || navigator.userAgent,
        created_by: currentUser ? currentUser.email : null
      };
      
      const activity = await Activity.create(activityData);
      return activity;
    } catch (error) {
      console.error("Erro ao registrar atividade:", error);
      // Não lança erro para não interromper o fluxo principal da aplicação
      return null;
    }
  }
  
  /**
   * Registra atividade de criação de organização
   * @param {string} organizationId - ID da organização
   * @param {string} organizationName - Nome da organização
   * @returns {Promise<object>} - A atividade registrada
   */
  static async logOrganizationCreated(organizationId, organizationName) {
    return this.log(
      'organization_create',
      'organization',
      organizationId,
      `Criação da organização "${organizationName}"`
    );
  }
  
  /**
   * Registra atividade de atualização de organização
   * @param {string} organizationId - ID da organização
   * @param {string} organizationName - Nome da organização
   * @param {string} details - Detalhes da atualização
   * @returns {Promise<object>} - A atividade registrada
   */
  static async logOrganizationUpdated(organizationId, organizationName, details) {
    return this.log(
      'organization_update',
      'organization',
      organizationId,
      `Atualização da organização "${organizationName}"`,
      { notes: details }
    );
  }
  
  /**
   * Registra atividade de aprovação de organização
   * @param {string} organizationId - ID da organização
   * @param {string} organizationName - Nome da organização
   * @param {string} notes - Notas de aprovação
   * @returns {Promise<object>} - A atividade registrada
   */
  static async logOrganizationApproved(organizationId, organizationName, notes) {
    return this.log(
      'organization_approve',
      'organization',
      organizationId,
      `Aprovação da organização "${organizationName}"`,
      { notes }
    );
  }
  
  /**
   * Registra atividade de rejeição de organização
   * @param {string} organizationId - ID da organização
   * @param {string} organizationName - Nome da organização
   * @param {string} rejectionReason - Motivo da rejeição
   * @returns {Promise<object>} - A atividade registrada
   */
  static async logOrganizationRejected(organizationId, organizationName, rejectionReason) {
    return this.log(
      'organization_reject',
      'organization',
      organizationId,
      `Rejeição da organização "${organizationName}"`,
      { notes: rejectionReason }
    );
  }
  
  /**
   * Registra atividade de upload de documento
   * @param {string} documentId - ID do documento
   * @param {string} documentName - Nome do documento
   * @param {string} organizationId - ID da organização
   * @returns {Promise<object>} -  A atividade registrada
   */
  static async logDocumentUploaded(documentId, documentName, organizationId) {
    return this.log(
      'document_upload',
      'document',
      documentId,
      `Upload do documento "${documentName}"`,
      { notes: `Relacionado à organização ID: ${organizationId}` }
    );
  }
  
  /**
   * Registra atividade de verificação de documento
   * @param {string} documentId - ID do documento
   * @param {string} documentName - Nome do documento
   * @returns {Promise<object>} - A atividade registrada
   */
  static async logDocumentVerified(documentId, documentName) {
    return this.log(
      'document_verify',
      'document',
      documentId,
      `Verificação do documento "${documentName}"`
    );
  }
  
  /**
   * Registra atividade de rejeição de documento
   * @param {string} documentId - ID do documento
   * @param {string} documentName - Nome do documento
   * @param {string} rejectionReason - Motivo da rejeição
   * @returns {Promise<object>} - A atividade registrada
   */
  static async logDocumentRejected(documentId, documentName, rejectionReason) {
    return this.log(
      'document_reject',
      'document',
      documentId,
      `Rejeição do documento "${documentName}"`,
      { notes: rejectionReason }
    );
  }
  
  /**
   * Registra atividade de convite de usuário
   * @param {string} invitedEmail - Email do usuário convidado
   * @param {string} organizationId - ID da organização
   * @param {string} role - Papel do usuário convidado
   * @returns {Promise<object>} - A atividade registrada
   */
  static async logUserInvited(invitedEmail, organizationId, role) {
    return this.log(
      'user_invite',
      'user',
      invitedEmail,
      `Convite enviado para o usuário ${invitedEmail}`,
      { notes: `Papel: ${role}, Organização ID: ${organizationId}` }
    );
  }
  
  /**
   * Registra atividade de login de usuário
   * @param {string} userId - ID do usuário
   * @param {string} userEmail - Email do usuário
   * @returns {Promise<object>} - A atividade registrada
   */
  static async logUserLogin(userId, userEmail) {
    return this.log(
      'user_login',
      'user',
      userId,
      `Login do usuário ${userEmail}`,
      { 
        ipAddress: await this.getIpAddress(),
        userAgent: navigator.userAgent
      }
    );
  }
  
  /**
   * Obtem o endereço IP do usuário (método auxiliar)
   * @returns {Promise<string>} - Endereço IP ou null
   */
  static async getIpAddress() {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (error) {
      console.error("Erro ao obter endereço IP:", error);
      return null;
    }
  }
}

export default ActivityLogger;