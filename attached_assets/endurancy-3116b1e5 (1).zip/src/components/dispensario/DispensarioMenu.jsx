import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ShoppingBag,
  Package,
  BarChart,
  FileText,
  DollarSign,
  ChevronRight,
  Settings
} from 'lucide-react';

export default function DispensarioMenu() {
  const navigate = useNavigate();

  const menuItems = [
    { 
      title: "Ponto de Venda (PDV)", 
      description: "Realizar vendas e dispensação de medicamentos",
      icon: ShoppingBag,
      url: "PDV",
      color: "bg-green-100 text-green-800"
    },
    { 
      title: "Estoque", 
      description: "Gerenciar produtos, lotes e movimentações",
      icon: Package,
      url: "EstoqueDispensario",
      color: "bg-blue-100 text-blue-800"
    },
    { 
      title: "Receituário", 
      description: "Gerenciar receitas médicas",
      icon: FileText,
      url: "GerenciarReceituario",
      color: "bg-purple-100 text-purple-800"
    },
    { 
      title: "Caixa", 
      description: "Gerenciar operações de caixa",
      icon: DollarSign,
      url: "DispensarioCaixa",
      color: "bg-yellow-100 text-yellow-800"
    },
    { 
      title: "Relatórios", 
      description: "Relatórios de vendas e operações",
      icon: BarChart,
      url: "RelatorioDispensario",
      color: "bg-indigo-100 text-indigo-800"
    },
    { 
      title: "SNGPC", 
      description: "Relatórios para o Sistema Nacional de Gerenciamento de Produtos Controlados",
      icon: FileText,
      url: "RelatorioSNGPC",
      color: "bg-red-100 text-red-800"
    },
    { 
      title: "Configurações", 
      description: "Configurações do módulo de dispensário",
      icon: Settings,
      url: "DispensarioConfig",
      color: "bg-gray-100 text-gray-800"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {menuItems.map((item, index) => (
        <Card 
          key={index}
          className="hover:shadow-md transition-shadow cursor-pointer"
          onClick={() => navigate(createPageUrl(item.url))}
        >
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className={`p-3 rounded-lg ${item.color}`}>
                <item.icon className="h-6 w-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium">{item.title}</h3>
                <p className="text-sm text-gray-500 mt-1">{item.description}</p>
              </div>
              <ChevronRight className="h-5 w-5 text-gray-400" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}