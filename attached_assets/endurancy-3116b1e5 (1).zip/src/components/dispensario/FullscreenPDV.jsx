import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Maximize, Minimize, ArrowLeft } from 'lucide-react';

export default function FullscreenPDV({ children, title = "PDV - Dispensário" }) {
  const navigate = useNavigate();
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const handleFullscreenChange = () => {
    setIsFullscreen(!!document.fullscreenElement);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      // Enter fullscreen
      const elem = document.documentElement;
      if (elem.requestFullscreen) {
        elem.requestFullscreen();
      } else if (elem.webkitRequestFullscreen) { /* Safari */
        elem.webkitRequestFullscreen();
      } else if (elem.msRequestFullscreen) { /* IE11 */
        elem.msRequestFullscreen();
      }
    } else {
      // Exit fullscreen
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) { /* Safari */
        document.webkitExitFullscreen();
      } else if (document.msExitFullscreen) { /* IE11 */
        document.msExitFullscreen();
      }
    }
  };

  return (
    <div className={`flex flex-col h-screen overflow-hidden ${isFullscreen ? 'bg-gray-900' : 'bg-gray-50'}`}>
      {/* Header with fullscreen toggle */}
      <div className={`flex justify-between items-center p-4 ${isFullscreen ? 'bg-gray-800 text-white' : 'bg-white border-b'}`}>
        <h1 className="text-xl font-bold">{title}</h1>
        <div className="flex gap-2">
          <Button 
            variant={isFullscreen ? "outline" : "default"} 
            size="sm" 
            onClick={toggleFullscreen}
            className={isFullscreen ? "border-white text-white hover:bg-gray-700" : ""}
          >
            {isFullscreen ? (
              <>
                <Minimize className="h-4 w-4 mr-2" />
                Sair da Tela Cheia
              </>
            ) : (
              <>
                <Maximize className="h-4 w-4 mr-2" />
                Tela Cheia
              </>
            )}
          </Button>
          {isFullscreen && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate(createPageUrl("DispensarioDashboard"))}
              className="border-white text-white hover:bg-gray-700"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
          )}
        </div>
      </div>

      <div className={`flex-1 ${isFullscreen ? 'bg-gray-800 text-white' : ''}`}>
        {children}
      </div>
    </div>
  );
}