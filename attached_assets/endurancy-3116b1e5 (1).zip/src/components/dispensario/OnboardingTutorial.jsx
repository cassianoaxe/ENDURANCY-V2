
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ShoppingBag,
  Package,
  FileText,
  PlayCircle,
  CheckCircle,
  ChevronRight,
  ChevronLeft,
  PlusCircle,
  X,
  Download,
  HelpCircle,
  Settings,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function OnboardingTutorial({ isOpen, onClose, onComplete }) {
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 6;
  
  const handleNextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    } else {
      if (onComplete) onComplete();
      onClose();
    }
  };
  
  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };
  
  const steps = [
    {
      title: "Bem-vindo ao Dispensário",
      description: "Conheça as principais funcionalidades do módulo Dispensário e como transformar sua organização em um ponto de venda eficiente.",
      content: (
        <div className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-blue-800">
              O módulo Dispensário permite que sua organização dispense medicamentos como uma farmácia, com controle total sobre vendas, estoque, receituário e relatórios para o SNGPC.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <Card className="bg-white">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center">
                  <ShoppingBag className="w-4 h-4 mr-2 text-green-600" />
                  PDV
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-gray-600">
                  Realize vendas no balcão com interface intuitiva e emissão de cupom fiscal.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-white">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center">
                  <Package className="w-4 h-4 mr-2 text-blue-600" />
                  Estoque
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-gray-600">
                  Controle de estoque, lotes, validades e movimentações.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-white">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center">
                  <FileText className="w-4 h-4 mr-2 text-purple-600" />
                  Receituário
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-gray-600">
                  Gestão de receitas e integração com SNGPC da ANVISA.
                </p>
              </CardContent>
            </Card>
          </div>
          
          <div className="flex justify-center mt-4">
            <Button 
              variant="outline"
              className="flex items-center"
              onClick={() => window.open("https://www.youtube.com/watch?v=dispensarioModulo", "_blank")}
            >
              <PlayCircle className="w-4 h-4 mr-2" />
              Assistir vídeo de introdução
            </Button>
          </div>
        </div>
      )
    },
    {
      title: "Configuração Inicial",
      description: "Vamos configurar o básico para começar a utilizar o módulo Dispensário.",
      content: (
        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <h4 className="font-medium mb-2">Checklist de Configuração</h4>
            <div className="space-y-2">
              <div className="flex items-start">
                <CheckCircle className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                <div>
                  <p className="font-medium">Cadastrar Informações Fiscais</p>
                  <p className="text-sm text-gray-600">Configure os dados da empresa para emissão de cupom fiscal.</p>
                </div>
              </div>
              <div className="flex items-start">
                <CheckCircle className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                <div>
                  <p className="font-medium">Configurar SNGPC</p>
                  <p className="text-sm text-gray-600">Informe os dados do farmacêutico responsável e CRF.</p>
                </div>
              </div>
              <div className="flex items-start">
                <CheckCircle className="w-5 h-5 text-green-500 mr-2 flex-shrink-0" />
                <div>
                  <p className="font-medium">Cadastrar Produtos</p>
                  <p className="text-sm text-gray-600">Adicione os produtos ao estoque antes de iniciar as vendas.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex justify-center gap-2 mt-4">
            <Button
              variant="outline"
              onClick={() => window.open(createPageUrl("DispensarioConfig"), "_blank")}
              className="flex items-center"
            >
              <Settings className="w-4 h-4 mr-2" />
              Ir para Configurações
            </Button>
            <Button
              variant="outline"
              onClick={() => window.open(createPageUrl("EstoqueDispensario"), "_blank")}
              className="flex items-center"
            >
              <Package className="w-4 h-4 mr-2" />
              Gerenciar Estoque
            </Button>
          </div>
        </div>
      )
    },
    {
      title: "Utilizando o PDV",
      description: "Aprenda a realizar vendas balcão com o PDV do Dispensário.",
      content: (
        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <h4 className="font-medium mb-2">Realizando uma Venda</h4>
            <ol className="space-y-3 list-decimal pl-5">
              <li>
                <span className="font-medium">Acesse o PDV</span>
                <p className="text-sm text-gray-600">Clique no botão "Abrir PDV" na dashboard ou no menu lateral.</p>
              </li>
              <li>
                <span className="font-medium">Abra o Caixa</span>
                <p className="text-sm text-gray-600">Inicie um novo caixa informando o valor inicial em dinheiro.</p>
              </li>
              <li>
                <span className="font-medium">Adicione Produtos</span>
                <p className="text-sm text-gray-600">Busque por nome, código ou leia o código de barras do produto.</p>
              </li>
              <li>
                <span className="font-medium">Adicione o Cliente</span>
                <p className="text-sm text-gray-600">Vincule a venda a um cliente cadastrado ou crie um novo.</p>
              </li>
              <li>
                <span className="font-medium">Finalize a Venda</span>
                <p className="text-sm text-gray-600">Escolha a forma de pagamento e emita o cupom fiscal.</p>
              </li>
            </ol>
          </div>
          
          <div className="flex justify-center gap-2 mt-4">
            <Button
              variant="outline"
              onClick={() => window.open("https://www.youtube.com/watch?v=pdvTutorial", "_blank")}
              className="flex items-center"
            >
              <PlayCircle className="w-4 h-4 mr-2" />
              Ver Tutorial em Vídeo
            </Button>
            <Button
              className="flex items-center bg-green-600 hover:bg-green-700"
              onClick={() => window.open(createPageUrl("PDV"), "_blank")}
            >
              <ShoppingBag className="w-4 h-4 mr-2" />
              Acesse o PDV
            </Button>
          </div>
        </div>
      )
    },
    {
      title: "Gestão de Estoque",
      description: "Controle seu estoque, faça entrada de produtos e gerencie suas movimentações.",
      content: (
        <div className="space-y-4">
          <Tabs defaultValue="produtos" className="w-full">
            <TabsList className="w-full grid grid-cols-3">
              <TabsTrigger value="produtos">Produtos</TabsTrigger>
              <TabsTrigger value="entradas">Entradas</TabsTrigger>
              <TabsTrigger value="saidas">Saídas</TabsTrigger>
            </TabsList>
            <TabsContent value="produtos">
              <div className="bg-white p-4 rounded-lg border border-gray-200">
                <h4 className="font-medium mb-2">Cadastro de Produtos</h4>
                <ol className="space-y-2 list-decimal pl-5">
                  <li>
                    <span className="font-medium">Acesse o Estoque</span>
                    <p className="text-sm text-gray-600">Navegue até a seção de estoque no menu.</p>
                  </li>
                  <li>
                    <span className="font-medium">Clique em "Novo Produto"</span>
                    <p className="text-sm text-gray-600">Preencha todos os dados do produto, incluindo código, nome, preços e categoria.</p>
                  </li>
                  <li>
                    <span className="font-medium">Indique se é Controlado</span>
                    <p className="text-sm text-gray-600">Marque a opção "Controlado" para produtos que exigem receita e reporte ao SNGPC.</p>
                  </li>
                </ol>
              </div>
            </TabsContent>
            <TabsContent value="entradas">
              <div className="bg-white p-4 rounded-lg border border-gray-200">
                <h4 className="font-medium mb-2">Entrada de Produtos</h4>
                <ol className="space-y-2 list-decimal pl-5">
                  <li>
                    <span className="font-medium">Nova Entrada</span>
                    <p className="text-sm text-gray-600">Clique em "Nova Entrada" e selecione o produto.</p>
                  </li>
                  <li>
                    <span className="font-medium">Informe o Lote</span>
                    <p className="text-sm text-gray-600">Cadastre as informações do lote, incluindo validade e quantidade.</p>
                  </li>
                  <li>
                    <span className="font-medium">Nota Fiscal</span>
                    <p className="text-sm text-gray-600">Vincule a nota fiscal de entrada para rastreabilidade.</p>
                  </li>
                </ol>
              </div>
            </TabsContent>
            <TabsContent value="saidas">
              <div className="bg-white p-4 rounded-lg border border-gray-200">
                <h4 className="font-medium mb-2">Saídas e Ajustes</h4>
                <ol className="space-y-2 list-decimal pl-5">
                  <li>
                    <span className="font-medium">Registrar Saída</span>
                    <p className="text-sm text-gray-600">Registre saídas por perda, vencimento ou transferência.</p>
                  </li>
                  <li>
                    <span className="font-medium">Ajuste de Estoque</span>
                    <p className="text-sm text-gray-600">Faça ajustes de inventário quando necessário.</p>
                  </li>
                  <li>
                    <span className="font-medium">Documentação</span>
                    <p className="text-sm text-gray-600">Mantenha a documentação de todas as movimentações.</p>
                  </li>
                </ol>
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="flex justify-center gap-2 mt-4">
            <Button
              variant="outline"
              onClick={() => window.open("https://www.youtube.com/watch?v=estoqueTutorial", "_blank")}
              className="flex items-center"
            >
              <PlayCircle className="w-4 h-4 mr-2" />
              Ver Tutorial em Vídeo
            </Button>
            <Button
              className="flex items-center"
              onClick={() => window.open(createPageUrl("EstoqueDispensario"), "_blank")}
            >
              <Package className="w-4 h-4 mr-2" />
              Ir para Estoque
            </Button>
          </div>
        </div>
      )
    },
    {
      title: "Receituário e SNGPC",
      description: "Aprenda a gerenciar receitas e enviar dados ao SNGPC.",
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Gerenciamento de Receitas</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="space-y-2 list-decimal pl-5 text-sm">
                  <li>
                    <span className="font-medium">Digitalize a Receita</span>
                    <p className="text-gray-600">Use um scanner ou câmera para digitalizar a receita.</p>
                  </li>
                  <li>
                    <span className="font-medium">Cadastre os Dados</span>
                    <p className="text-gray-600">Informe dados do médico, paciente e medicamentos.</p>
                  </li>
                  <li>
                    <span className="font-medium">Vincule à Venda</span>
                    <p className="text-gray-600">Associe a receita à venda no PDV.</p>
                  </li>
                </ol>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Envio ao SNGPC</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="space-y-2 list-decimal pl-5 text-sm">
                  <li>
                    <span className="font-medium">Prepare os Dados</span>
                    <p className="text-gray-600">Verifique se todas as vendas estão corretas.</p>
                  </li>
                  <li>
                    <span className="font-medium">Gere o Arquivo</span>
                    <p className="text-gray-600">Gere o arquivo XML no formato SNGPC.</p>
                  </li>
                  <li>
                    <span className="font-medium">Envie o Relatório</span>
                    <p className="text-gray-600">Envie através do portal da ANVISA.</p>
                  </li>
                </ol>
              </CardContent>
            </Card>
          </div>
          
          <div className="flex flex-col gap-4 mt-4">
            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <h4 className="font-medium flex items-center text-yellow-800">
                <AlertTriangle className="w-4 h-4 mr-2" />
                Dicas Importantes
              </h4>
              <ul className="mt-2 space-y-2 text-yellow-800">
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 mr-2 mt-1" />
                  Mantenha as receitas físicas arquivadas pelo período exigido pela legislação.
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 mr-2 mt-1" />
                  Faça backup regular das receitas digitalizadas.
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-4 h-4 mr-2 mt-1" />
                  Envie os dados ao SNGPC dentro do prazo estabelecido.
                </li>
              </ul>
            </div>
            
            <div className="flex justify-center gap-2">
              <Button
                variant="outline"
                onClick={() => window.open("https://www.youtube.com/watch?v=sngpcTutorial", "_blank")}
                className="flex items-center"
              >
                <PlayCircle className="w-4 h-4 mr-2" />
                Tutorial SNGPC
              </Button>
              <Button
                onClick={() => window.open(createPageUrl("RelatorioSNGPC"), "_blank")}
                className="flex items-center"
              >
                <FileText className="w-4 h-4 mr-2" />
                Relatório SNGPC
              </Button>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Pronto para Começar!",
      description: "Você está pronto para começar a usar o módulo Dispensário.",
      content: (
        <div className="space-y-6 text-center">
          <div className="bg-green-50 p-6 rounded-lg border border-green-200">
            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-green-800 mb-2">
              Parabéns! Você completou o tutorial inicial.
            </h3>
            <p className="text-green-600">
              Agora você está pronto para começar a usar o módulo Dispensário.
              Lembre-se que nossa equipe de suporte está sempre disponível para ajudar.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center">
                  <HelpCircle className="w-4 h-4 mr-2 text-blue-500" />
                  Central de Ajuda
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-gray-600">
                  Acesse nossa base de conhecimento com tutoriais e dicas.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" className="w-full text-blue-500">
                  Acessar Help Center
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center">
                  <PlayCircle className="w-4 h-4 mr-2 text-purple-500" />
                  Vídeos Tutoriais
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-gray-600">
                  Assista nossos vídeos tutoriais detalhados.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" className="w-full text-purple-500">
                  Ver Tutoriais
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center">
                  <RefreshCw className="w-4 h-4 mr-2 text-green-500" />
                  Próximos Passos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-gray-600">
                  Veja o que mais você pode fazer com o módulo.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" className="w-full text-green-500">
                  Ver Sugestões
                </Button>
              </CardFooter>
            </Card>
          </div>
          
          <div className="flex justify-center gap-4">
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={() => window.open(createPageUrl("DispensarioDashboard"), "_blank")}
            >
              Ir para Dashboard
            </Button>
            <Button
              variant="outline"
              onClick={() => window.open(createPageUrl("PDV"), "_blank")}
            >
              Abrir PDV
            </Button>
          </div>
        </div>
      )
    }
  ];
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            {steps[currentStep - 1].title}
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
          <DialogDescription>
            {steps[currentStep - 1].description}
          </DialogDescription>
        </DialogHeader>

        <div className="mt-4">
          <div className="mb-6">
            <Progress value={(currentStep / totalSteps) * 100} className="h-2" />
            <p className="text-sm text-gray-500 mt-2">
              Passo {currentStep} de {totalSteps}
            </p>
          </div>
          
          {steps[currentStep - 1].content}
        </div>

        <DialogFooter className="flex justify-between mt-6">
          <Button
            variant="outline"
            onClick={handlePrevStep}
            disabled={currentStep === 1}
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Anterior
          </Button>
          
          <Button onClick={handleNextStep}>
            {currentStep === totalSteps ? (
              "Concluir Tutorial"
            ) : (
              <>
                Próximo
                <ChevronRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
