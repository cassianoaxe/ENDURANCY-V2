import React, { useState, useEffect } from 'react';
import { Task } from '@/api/entities';
import { User } from '@/api/entities';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { CornerDownLeft, Calendar, Clock, Tag, Edit, Trash2, AlertCircle, MessageSquare, CheckCircle, Users } from 'lucide-react';
import TaskForm from './TaskForm';

const STATUS_LABELS = {
  backlog: "Backlog",
  todo: "A Fazer",
  in_progress: "Em Progresso",
  review: "Revisão",
  done: "Concluído"
};

const STATUS_COLORS = {
  backlog: "bg-slate-200 text-slate-800",
  todo: "bg-indigo-100 text-indigo-800",
  in_progress: "bg-purple-100 text-purple-800",
  review: "bg-amber-100 text-amber-800",
  done: "bg-green-100 text-green-800"
};

const PRIORITY_COLORS = {
  low: "bg-blue-100 text-blue-800",
  medium: "bg-yellow-100 text-yellow-800",
  high: "bg-orange-100 text-orange-800",
  urgent: "bg-red-100 text-red-800"
};

const PRIORITY_LABELS = {
  low: "Baixa",
  medium: "Média",
  high: "Alta",
  urgent: "Urgente"
};

export default function TaskDetail({ taskId, open, onOpenChange, onTaskUpdate, onTaskDelete }) {
  const [task, setTask] = useState(null);
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [comment, setComment] = useState('');
  const [showEditForm, setShowEditForm] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (open && taskId) {
      loadTaskAndUsers();
    }
  }, [open, taskId]);

  const loadTaskAndUsers = async () => {
    try {
      setIsLoading(true);
      
      // Load task details
      const taskData = await Task.get(taskId);
      setTask(taskData);
      
      // Load users for displaying names
      const usersList = await User.list();
      setUsers(usersList);
      
      // Get current user
      const userData = await User.me();
      setCurrentUser(userData);
    } catch (error) {
      console.error("Error loading task details:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddComment = async () => {
    if (!comment.trim()) return;
    
    try {
      // Create new comment object
      const newComment = {
        user_id: currentUser.id,
        content: comment,
        created_at: new Date().toISOString()
      };
      
      // Update task with new comment
      const updatedComments = [...(task.comments || []), newComment];
      await Task.update(taskId, { comments: updatedComments });
      
      // Refresh task data
      const updatedTask = await Task.get(taskId);
      setTask(updatedTask);
      setComment('');
      
      // Notify parent component
      if (onTaskUpdate) onTaskUpdate(updatedTask);
    } catch (error) {
      console.error("Error adding comment:", error);
    }
  };

  const handleStatusChange = async (newStatus) => {
    try {
      await Task.update(taskId, { status: newStatus });
      
      // Refresh task data
      const updatedTask = await Task.get(taskId);
      setTask(updatedTask);
      
      // Notify parent component
      if (onTaskUpdate) onTaskUpdate(updatedTask);
    } catch (error) {
      console.error("Error updating task status:", error);
    }
  };

  const handleDeleteTask = async () => {
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    
    try {
      await Task.delete(taskId);
      onOpenChange(false);
      
      // Notify parent component
      if (onTaskDelete) onTaskDelete(taskId);
    } catch (error) {
      console.error("Error deleting task:", error);
    }
  };

  const handleEditSave = async (formData) => {
    try {
      await Task.update(taskId, formData);
      
      // Refresh task data
      const updatedTask = await Task.get(taskId);
      setTask(updatedTask);
      setShowEditForm(false);
      
      // Notify parent component
      if (onTaskUpdate) onTaskUpdate(updatedTask);
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  const getUserName = (userId) => {
    const user = users.find(u => u.id === userId);
    return user ? user.full_name : 'Usuário';
  };

  const getUserInitials = (userId) => {
    const user = users.find(u => u.id === userId);
    if (!user || !user.full_name) return 'UN';
    
    const nameParts = user.full_name.split(' ');
    if (nameParts.length === 1) return nameParts[0].substring(0, 2).toUpperCase();
    return (nameParts[0][0] + nameParts[nameParts.length - 1][0]).toUpperCase();
  };

  const isOverdue = () => {
    if (!task?.due_date) return false;
    const dueDate = new Date(task.due_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return dueDate < today && task.status !== 'done';
  };

  if (isLoading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <div className="flex justify-center p-8">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (showEditForm) {
    return <TaskForm 
      open={true} 
      onOpenChange={() => setShowEditForm(false)} 
      initialData={task} 
      onSubmit={handleEditSave} 
    />;
  }

  if (!task) return null;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex justify-between items-start">
              <DialogTitle className="mr-8 text-xl">{task.title}</DialogTitle>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={() => setShowEditForm(true)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button 
                  variant={confirmDelete ? "destructive" : "outline"} 
                  size="icon"
                  onClick={handleDeleteTask}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Task metadata */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Status</h3>
                <div className="mt-1">
                  <Badge className={STATUS_COLORS[task.status]}>
                    {STATUS_LABELS[task.status]}
                  </Badge>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Prioridade</h3>
                <div className="mt-1">
                  <Badge className={PRIORITY_COLORS[task.priority]}>
                    {PRIORITY_LABELS[task.priority]}
                  </Badge>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Responsável</h3>
                <div className="mt-1 flex items-center gap-2">
                  <Avatar className="h-6 w-6">
                    <AvatarFallback>{getUserInitials(task.assigned_to)}</AvatarFallback>
                  </Avatar>
                  <span>{getUserName(task.assigned_to)}</span>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Criado por</h3>
                <div className="mt-1 flex items-center gap-2">
                  <Avatar className="h-6 w-6">
                    <AvatarFallback>{getUserInitials(task.assigned_by)}</AvatarFallback>
                  </Avatar>
                  <span>{getUserName(task.assigned_by)}</span>
                </div>
              </div>
              
              {task.due_date && (
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Data de Vencimento</h3>
                  <div className="mt-1 flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span>
                      {format(new Date(task.due_date), 'd MMMM yyyy', { locale: ptBR })}
                      {isOverdue() && (
                        <Badge variant="destructive" className="ml-2">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Atrasada
                        </Badge>
                      )}
                    </span>
                  </div>
                </div>
              )}
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Módulo / Setor</h3>
                <div className="mt-1">
                  <span className="capitalize">{task.module}</span>
                  {task.sector && <span> / {task.sector}</span>}
                </div>
              </div>
            </div>
            
            {/* Description */}
            <div>
              <h3 className="text-sm font-medium text-gray-500">Descrição</h3>
              <div className="mt-2 prose prose-sm">
                <p>{task.description || "Sem descrição."}</p>
              </div>
            </div>
            
            {/* Tags */}
            {task.tags && task.tags.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-gray-500">Tags</h3>
                <div className="flex flex-wrap gap-2 mt-2">
                  {task.tags.map(tag => (
                    <Badge key={tag} variant="secondary" className="gap-1">
                      <Tag className="h-3 w-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            
            {/* Watchers */}
            {task.watchers && task.watchers.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-gray-500">Observadores</h3>
                <div className="flex flex-wrap gap-2 mt-2">
                  <div className="flex -space-x-2">
                    {task.watchers.map(watcherId => (
                      <Avatar key={watcherId} className="border-2 border-background">
                        <AvatarFallback>{getUserInitials(watcherId)}</AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                  <span className="text-sm text-gray-500 ml-2">
                    {task.watchers.map(watcherId => getUserName(watcherId)).join(', ')}
                  </span>
                </div>
              </div>
            )}
            
            {/* Change Status */}
            <div>
              <h3 className="text-sm font-medium text-gray-500">Alterar Status</h3>
              <div className="flex flex-wrap gap-2 mt-2">
                {Object.entries(STATUS_LABELS).map(([key, label]) => (
                  <Button
                    key={key}
                    variant={task.status === key ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleStatusChange(key)}
                    className={task.status === key ? "opacity-100" : "opacity-70"}
                  >
                    {label}
                  </Button>
                ))}
              </div>
            </div>
            
            <Separator />
            
            {/* Comments */}
            <div>
              <h3 className="text-sm font-medium text-gray-500 flex items-center">
                <MessageSquare className="h-4 w-4 mr-1" />
                Comentários
              </h3>
              
              <div className="space-y-4 mt-4">
                {task.comments && task.comments.length > 0 ? (
                  task.comments.map((comment, index) => (
                    <div key={index} className="flex gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback>{getUserInitials(comment.user_id)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{getUserName(comment.user_id)}</span>
                          <span className="text-xs text-gray-500">
                            {format(new Date(comment.created_at), "d MMM, HH:mm", { locale: ptBR })}
                          </span>
                        </div>
                        <p className="text-sm mt-1">{comment.content}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-gray-500">Nenhum comentário ainda.</p>
                )}
                
                {/* Add comment */}
                <div className="flex gap-3 mt-4">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{getUserInitials(currentUser?.id)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <Textarea
                      placeholder="Adicione um comentário..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      className="resize-none"
                    />
                    <Button 
                      onClick={handleAddComment} 
                      size="sm" 
                      className="mt-2"
                      disabled={!comment.trim()}
                    >
                      <CornerDownLeft className="h-4 w-4 mr-1" />
                      Comentar
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <div className="text-xs text-gray-500 flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              Criado em: {format(new Date(task.created_date), "d MMMM yyyy, HH:mm", { locale: ptBR })}
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}