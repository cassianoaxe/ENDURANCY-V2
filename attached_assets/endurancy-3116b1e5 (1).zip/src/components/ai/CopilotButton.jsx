import React from 'react';
import { Button } from "@/components/ui/button";
import { Sparkles, X } from 'lucide-react';

/**
 * Floating button to toggle the AI Copilot sidebar
 */
export default function CopilotButton({ onClick, isOpen }) {
  return (
    <Button
      className="fixed bottom-6 right-6 h-12 w-12 rounded-full shadow-lg z-40 flex items-center justify-center"
      onClick={onClick}
    >
      {isOpen ? (
        <X className="h-5 w-5" />
      ) : (
        <Sparkles className="h-5 w-5" />
      )}
    </Button>
  );
}