import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Organization } from '@/api/entities';

// Create context for AI-related data
const AIContext = createContext();

export function useAIContext() {
  return useContext(AIContext);
}

export function AIContextProvider({ children }) {
  const [userContext, setUserContext] = useState({
    user: null,
    organization: null,
    modules: [],
    recentActivity: [],
    loaded: false
  });
  
  const [aiSettings, setAISettings] = useState({
    enabled: true,
    proactiveMode: true,
    dataAccess: true,
    actionPermissions: {
      read: true,
      write: true,
      delete: false
    },
    model: 'claude-mcp'
  });

  useEffect(() => {
    async function loadUserContext() {
      try {
        // Try to get mock user data first
        const mockUserName = localStorage.getItem('mockUserName');
        const mockUserEmail = localStorage.getItem('mockUserEmail');
        const mockOrgType = localStorage.getItem('mockOrgType');
        
        let userData, orgData;
        
        if (mockUserName && mockUserEmail) {
          // Use mock data
          userData = {
            id: "mock-user-1",
            full_name: mockUserName,
            email: mockUserEmail,
            role: "admin",
            user_type: localStorage.getItem('mockUserType') || "orgadmin"
          };
          
          orgData = {
            id: "mock-org-1",
            name: "Organização Demonstração",
            type: mockOrgType || "Associação",
            modules: ["cultivo", "producao", "dispensario", "pacientes", "financeiro"]
          };
        } else {
          // In a real implementation, fetch actual user and org data
          try {
            userData = await User.me();
            const orgs = await Organization.filter({ id: userData.organization_id });
            orgData = orgs && orgs.length > 0 ? orgs[0] : null;
          } catch (error) {
            console.error('Error fetching real user data:', error);
            // Fallback to default values
            userData = {
              id: "default-user",
              full_name: "Usuário Padrão",
              email: "usuario@exemplo.com",
              role: "admin",
              user_type: "orgadmin"
            };
            
            orgData = {
              id: "default-org",
              name: "Organização Padrão",
              type: "Associação",
              modules: ["cultivo", "producao", "dispensario", "pacientes", "financeiro"]
            };
          }
        }
        
        // Mock recent activity
        const recentActivity = [
          { type: 'view', entity: 'Product', entityId: 'prod-123', timestamp: new Date().toISOString() },
          { type: 'edit', entity: 'Patient', entityId: 'pat-456', timestamp: new Date(Date.now() - 3600000).toISOString() },
          { type: 'create', entity: 'Order', entityId: 'ord-789', timestamp: new Date(Date.now() - 7200000).toISOString() }
        ];
        
        setUserContext({
          user: userData,
          organization: orgData,
          modules: orgData?.modules || [],
          recentActivity,
          loaded: true
        });
      } catch (error) {
        console.error('Error loading user context for AI:', error);
        setUserContext(prev => ({ ...prev, loaded: true }));
      }
    }
    
    // Load settings from local storage if available
    try {
      const savedSettings = localStorage.getItem('aiSettings');
      if (savedSettings) {
        setAISettings(JSON.parse(savedSettings));
      }
    } catch (error) {
      console.error('Error loading AI settings:', error);
    }
    
    loadUserContext();
  }, []);
  
  // Save settings to local storage when they change
  useEffect(() => {
    try {
      localStorage.setItem('aiSettings', JSON.stringify(aiSettings));
    } catch (error) {
      console.error('Error saving AI settings:', error);
    }
  }, [aiSettings]);
  
  const updateAISettings = (newSettings) => {
    setAISettings(prev => ({ ...prev, ...newSettings }));
  };
  
  const value = {
    ...userContext,
    aiSettings,
    updateAISettings
  };
  
  return <AIContext.Provider value={value}>{children}</AIContext.Provider>;
}