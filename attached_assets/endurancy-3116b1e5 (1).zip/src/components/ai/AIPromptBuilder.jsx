/**
 * AI Prompt Builder - Constructs well-formatted prompts for different AI tasks
 */

export const buildSystemPrompt = (context) => {
  const { user, organization } = context;
  
  return `
You are Endurancy Copilot, an AI assistant integrated with the Endurancy platform for cannabis businesses.

CURRENT USER CONTEXT:
- User: ${user?.full_name || 'Unknown'} (${user?.email || 'No email'})
- Role: ${user?.role || 'Unknown'}
- Organization: ${organization?.name || 'Unknown'} 
- Organization Type: ${organization?.type || 'Unknown'}

IMPORTANT GUIDELINES:
1. You are a helpful, respectful assistant focused on Endurancy platform support.
2. Provide accurate, concise information about platform features.
3. Your capabilities include:
   - Explaining platform features and workflows
   - Providing step-by-step guides
   - Analyzing data and generating reports
   - Creating and editing records when requested
   - Answering questions about cannabis industry regulations (focus on Brazil)
   - Formatting responses for clarity with markdown when helpful

4. RESPONSE TONE:
   - Professional but conversational
   - Clear and direct
   - Helpful and solution-oriented
   - Respectful of user's expertise level

5. RESPONSE FORMAT:
   - Be concise but thorough
   - Use lists and sections for complex explanations
   - Include next steps when appropriate
   - Avoid unnecessary technical jargon

PLATFORM MODULES:
- Cultivo: Gerenciamento de plantas, lotes e processos de cultivo
- Produção: Controle de produção, qualidade e rastreabilidade
- Dispensário: Gestão de estoque, vendas e controle de receituário
- Pacientes/Associados: Cadastro e gestão de relacionamento
- Financeiro: Controle financeiro, relatórios e gestão de pagamentos
- Jurídico: Gestão de documentos legais e compliance
- Administrativo: Configurações da plataforma e gestão de usuários

Your responses should be in the same language as the user's question (Portuguese or English).
  `;
};

// Builds a prompt for analyzing data
export const buildAnalysisPrompt = (query, data, context) => {
  return `
${buildSystemPrompt(context)}

USER REQUEST:
The user has asked for the following analysis: "${query}"

RELEVANT DATA:
${JSON.stringify(data, null, 2)}

Provide a thoughtful analysis based on this data. Include:
1. Key insights
2. Notable trends or patterns
3. Actionable recommendations when appropriate
4. Visual representation suggestions if relevant
`;
};

// Builds a prompt for entity creation
export const buildEntityCreatePrompt = (entityType, userInput, context) => {
  return `
${buildSystemPrompt(context)}

USER REQUEST:
The user wants to create a new ${entityType} with the following information:
"${userInput}"

Create a structured JSON object for this new ${entityType} with appropriate fields.
Extract all relevant information from the user's request and fill in reasonable defaults for any missing required fields.
If critical information is missing, indicate what fields need more information.

Format your response as follows:
1. A JSON object that can be directly used to create the entity
2. A brief explanation of any assumptions made or additional information needed
`;
};

// Builds a prompt for help/tutorials
export const buildHelpPrompt = (query, context) => {
  return `
${buildSystemPrompt(context)}

USER REQUEST:
The user has asked for help with: "${query}"

Provide a helpful response that:
1. Clearly explains the relevant feature or process
2. Includes step-by-step instructions if applicable
3. Mentions related features they might find useful
4. Is formatted for easy reading with headings and bullet points where appropriate
`;
};

// Extract user intent from a general query
export const analyzeUserIntent = (userInput) => {
  const patterns = [
    { intent: 'create', regex: /criar|adicionar|novo|cadastrar|inserir/i },
    { intent: 'analyze', regex: /analis[ae]r|report|relat[oó]rio|estatística|dados|gr[aá]fico/i },
    { intent: 'help', regex: /ajuda|como|tutorial|explicar|instrução|guia/i },
    { intent: 'search', regex: /buscar|procurar|encontrar|localizar|pesquisar/i }
  ];
  
  for (const pattern of patterns) {
    if (pattern.regex.test(userInput)) {
      return pattern.intent;
    }
  }
  
  return 'general';
};