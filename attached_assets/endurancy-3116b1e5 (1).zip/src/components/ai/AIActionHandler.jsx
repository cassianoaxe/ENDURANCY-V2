/**
 * AI Action Handler - Handles data interactions from the AI assistant
 */

import { toast } from "@/components/ui/use-toast";

/**
 * Read entities from the database based on user permissions
 * @param {string} entityType - Type of entity to read
 * @param {Object} filters - Filters to apply
 * @param {Object} userContext - Current user context with permissions
 * @returns {Promise<Array>} - Array of entity objects
 */
export const readEntities = async (entityType, filters = {}, userContext) => {
  try {
    // Check if entity exists in the system
    let EntityClass;
    try {
      // Use dynamic import instead of require
      const EntityModule = await import(`@/api/entities/${entityType}`);
      EntityClass = EntityModule[entityType];
      
      if (!EntityClass) {
        throw new Error(`Entity ${entityType} not found in module`);
      }
    } catch (error) {
      console.error(`Entity type not found: ${entityType}`, error);
      return {
        success: false,
        error: `Entity type not found: ${entityType}`
      };
    }
    
    // Check user permissions
    if (!userContext.aiSettings.actionPermissions.read) {
      return {
        success: false,
        error: "User does not have read permissions"
      };
    }
    
    // Apply organization filter for organization users
    if (userContext.user?.user_type === 'orgadmin' && userContext.organization?.id) {
      filters.organization_id = userContext.organization.id;
    }
    
    // For doctors, only allow access to their patients
    if (userContext.user?.user_type === 'doctor' && entityType === 'Patient') {
      filters.doctor_id = userContext.user.id;
    }
    
    // For patients, only allow access to their own data
    if (userContext.user?.user_type === 'patient') {
      if (entityType === 'Patient' || entityType === 'Prescription') {
        filters.id = userContext.user.id;
      } else {
        return {
          success: false,
          error: "Patients can only access their own data"
        };
      }
    }
    
    // Execute the query
    const results = await EntityClass.filter(filters);
    
    return {
      success: true,
      data: results
    };
  } catch (error) {
    console.error('Error reading entities:', error);
    return {
      success: false,
      error: error.message || 'Unknown error occurred'
    };
  }
};

/**
 * Create a new entity
 * @param {string} entityType - Type of entity to create
 * @param {Object} data - Entity data
 * @param {Object} userContext - Current user context with permissions
 * @returns {Promise<Object>} - Created entity object
 */
export const createEntity = async (entityType, data, userContext) => {
  try {
    // Check if entity exists in the system
    let EntityClass;
    try {
      // Use dynamic import instead of require
      const EntityModule = await import(`@/api/entities/${entityType}`);
      EntityClass = EntityModule[entityType];
      
      if (!EntityClass) {
        throw new Error(`Entity ${entityType} not found in module`);
      }
    } catch (error) {
      console.error(`Entity type not found: ${entityType}`, error);
      return {
        success: false,
        error: `Entity type not found: ${entityType}`
      };
    }
    
    // Check user permissions
    if (!userContext.aiSettings.actionPermissions.write) {
      return {
        success: false,
        error: "User does not have write permissions"
      };
    }
    
    // Set organization ID for organization users
    if (userContext.user?.user_type === 'orgadmin' && userContext.organization?.id) {
      data.organization_id = userContext.organization.id;
    }
    
    // For doctors, only allow creating patients associated with them
    if (userContext.user?.user_type === 'doctor' && entityType === 'Patient') {
      data.doctor_id = userContext.user.id;
    }
    
    // Patients cannot create entities
    if (userContext.user?.user_type === 'patient') {
      return {
        success: false,
        error: "Patients cannot create entities"
      };
    }
    
    // Create the entity
    const result = await EntityClass.create(data);
    
    toast({
      title: "Entidade criada",
      description: `${entityType} criado com sucesso`,
    });
    
    return {
      success: true,
      data: result
    };
  } catch (error) {
    console.error('Error creating entity:', error);
    
    toast({
      title: "Erro ao criar entidade",
      description: error.message || 'Ocorreu um erro desconhecido',
      variant: "destructive"
    });
    
    return {
      success: false,
      error: error.message || 'Unknown error occurred'
    };
  }
};

/**
 * Analyze data from entities
 * @param {Array} data - Data to analyze
 * @param {string} analysisType - Type of analysis to perform
 * @param {Object} userContext - Current user context with permissions
 * @returns {Promise<Object>} - Analysis results
 */
export const analyzeData = async (data, analysisType, userContext) => {
  try {
    // Simple analysis functions
    switch (analysisType) {
      case 'count':
        return {
          success: true,
          data: { count: data.length }
        };
        
      case 'sum':
        if (!data.length || !data[0].value) {
          return {
            success: false,
            error: "Data must have a value property for sum analysis"
          };
        }
        const sum = data.reduce((acc, item) => acc + (item.value || 0), 0);
        return {
          success: true,
          data: { sum }
        };
        
      case 'average':
        if (!data.length || !data[0].value) {
          return {
            success: false,
            error: "Data must have a value property for average analysis"
          };
        }
        const avg = data.reduce((acc, item) => acc + (item.value || 0), 0) / data.length;
        return {
          success: true,
          data: { average: avg }
        };
        
      default:
        return {
          success: false,
          error: `Unknown analysis type: ${analysisType}`
        };
    }
  } catch (error) {
    console.error('Error analyzing data:', error);
    return {
      success: false,
      error: error.message || 'Unknown error occurred'
    };
  }
};