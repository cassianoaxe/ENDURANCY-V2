
import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { InvokeLLM } from "@/api/integrations";
import {
  Bot,
  User,
  Send,
  Loader2,
  BrainCircuit,
  X,
  PlusCircle,
  Database,
  Search,
  Settings,
  Sparkles,
  ChartBar,
  FileText,
  BarChart,
  Clock,
  Sliders,
  HelpCircle,
  AlertTriangle,
  Users
} from 'lucide-react';
import { analyzeUserIntent, buildSystemPrompt, buildAnalysisPrompt, buildEntityCreatePrompt, buildHelpPrompt } from './AIPromptBuilder';
import { readEntities, createEntity, analyzeData } from './AIActionHandler';
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function AICopilot({ isOpen, onClose }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Olá! Sou o Copilot da Endurancy. Como posso ajudar você hoje?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [settings, setSettings] = useState({
    enabled: true,
    proactiveMode: true,
    dataAccess: true,
    actionPermissions: {
      read: true,
      write: true,
      delete: false
    },
    model: 'claude-mcp'
  });
  const [activeTab, setActiveTab] = useState('chat');
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  const userContext = {
    user: {
      full_name: localStorage.getItem('mockUserName') || 'Usuário Demo',
      email: localStorage.getItem('mockUserEmail') || 'usuario@demo.com',
      role: 'admin'
    },
    organization: {
      name: 'Organização Demonstração',
      type: localStorage.getItem('mockOrgType') || 'Associação'
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
    if (isOpen) {
      inputRef.current?.focus();
    }
  }, [messages, isOpen]);

  useEffect(() => {
    try {
      const savedSettings = localStorage.getItem('aiCopilotSettings');
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings));
      }
    } catch (error) {
      console.error('Error loading AI settings:', error);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('aiCopilotSettings', JSON.stringify(settings));
    } catch (error) {
      console.error('Error saving AI settings:', error);
    }
  }, [settings]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      setMessages(prev => [...prev, { role: 'assistant', content: '...', loading: true }]);

      let response;
      const intent = analyzeUserIntent(userMessage);
      
      switch (intent) {
        case 'analyze':
          response = await handleAnalysisRequest(userMessage);
          break;
          
        case 'create':
          response = await handleEntityCreation(userMessage);
          break;
          
        case 'search':
          response = await handleEntitySearch(userMessage);
          break;
          
        case 'help':
          response = await InvokeLLM({
            prompt: buildHelpPrompt(userMessage, userContext)
          });
          break;
          
        default:
          response = await InvokeLLM({
            prompt: `${buildSystemPrompt(userContext)}\n\nUSER: ${userMessage}\n\nASSISTANT:`
          });
          break;
      }

      setMessages(prev => prev.filter(msg => !msg.loading));
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);

    } catch (error) {
      console.error('Error calling AI:', error);
      setMessages(prev => prev.filter(msg => !msg.loading));
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Desculpe, ocorreu um erro ao processar sua solicitação. Por favor, tente novamente.',
        error: true
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnalysisRequest = async (userMessage) => {
    try {
      const entityTypes = ['sales', 'patients', 'inventory'];
      const mentionedEntities = entityTypes.filter(type => 
        userMessage.toLowerCase().includes(type) ||
        userMessage.toLowerCase().includes(type.slice(0, -1))
      );
      
      const entityType = mentionedEntities.length > 0 ? mentionedEntities[0] : 'sales';
      const analysisResult = await analyzeData(entityType, {}, 'month', settings);
      
      const analysis = await InvokeLLM({
        prompt: buildAnalysisPrompt(userMessage, analysisResult.data, userContext)
      });
      
      return analysis;
    } catch (error) {
      console.error('Analysis error:', error);
      return `Desculpe, não consegui realizar a análise solicitada. ${error.message}`;
    }
  };

  const handleEntityCreation = async (userMessage) => {
    try {
      const entityTypes = ['patient', 'product', 'prescription', 'order'];
      const mentionedEntities = entityTypes.filter(type => 
        userMessage.toLowerCase().includes(type) || 
        userMessage.toLowerCase().includes(type + 's')
      );
      
      const entityType = mentionedEntities.length > 0 ? mentionedEntities[0] : null;
      
      if (!entityType) {
        return "Não consegui identificar que tipo de registro você deseja criar. Por favor, especifique se deseja criar um paciente, produto, prescrição ou pedido.";
      }
      
      const formattedEntity = await InvokeLLM({
        prompt: buildEntityCreatePrompt(entityType, userMessage, userContext),
        response_json_schema: {
          "type": "object", 
          "properties": {
            "data": { "type": "object" },
            "explanation": { "type": "string" }
          }
        }
      });
      
      if (settings.actionPermissions.write) {
        const result = await createEntity(entityType, formattedEntity.data, settings);
        
        if (result.success) {
          return `✅ ${entityType} criado com sucesso!\n\nDetalhes:\n${formattedEntity.explanation}\n\nID: ${result.data.id}`;
        } else {
          return `❌ Erro ao criar ${entityType}: ${result.message}\n\nDetalhes do que tentei criar:\n${formattedEntity.explanation}`;
        }
      } else {
        return `📋 Aqui está como seria o ${entityType} com base nas suas informações:\n\n\`\`\`json\n${JSON.stringify(formattedEntity.data, null, 2)}\n\`\`\`\n\n${formattedEntity.explanation}\n\n> Nota: Não criei este registro pois as permissões de escrita estão desativadas nas configurações.`;
      }
    } catch (error) {
      console.error('Entity creation error:', error);
      return `Desculpe, não consegui criar o registro solicitado. ${error.message}`;
    }
  };

  const handleEntitySearch = async (userMessage) => {
    try {
      const entityTypes = ['patient', 'product', 'prescription', 'order'];
      const mentionedEntities = entityTypes.filter(type => 
        userMessage.toLowerCase().includes(type) || 
        userMessage.toLowerCase().includes(type + 's')
      );
      
      const entityType = mentionedEntities.length > 0 ? mentionedEntities[0] : null;
      
      if (!entityType) {
        return "Não consegui identificar que tipo de registro você deseja buscar. Por favor, especifique se deseja buscar pacientes, produtos, prescrições ou pedidos.";
      }
      
      let searchQuery = {};
      const nameMatch = userMessage.match(/nome[:\s]+["']?([^"']+)["']?/i);
      if (nameMatch && nameMatch[1]) {
        if (entityType === 'patient') {
          searchQuery.full_name = nameMatch[1].trim();
        } else if (entityType === 'product') {
          searchQuery.name = nameMatch[1].trim();
        }
      }
      
      if (settings.actionPermissions.read) {
        const result = await readEntities(entityType, searchQuery, '-created_date', 5, settings);
        
        if (result.success && result.data.length > 0) {
          const searchSummary = await InvokeLLM({
            prompt: `
${buildSystemPrompt(userContext)}

USER REQUEST:
O usuário buscou por ${entityType}s com os seguintes parâmetros: ${JSON.stringify(searchQuery)}

RESULTADO DA BUSCA:
${JSON.stringify(result.data, null, 2)}

Forneça um resumo claro e organizado dos resultados da busca. Inclua informações relevantes de cada item encontrado.
Se forem muitos resultados, destaque apenas os mais importantes ou recentes.
Se não houver resultados, sugira outros termos de busca ou parâmetros que poderiam ajudar.
            `
          });
          
          return searchSummary;
        } else if (result.success && result.data.length === 0) {
          return `Não encontrei nenhum ${entityType} com os parâmetros de busca fornecidos. Tente utilizar critérios diferentes ou verificar se o registro já existe no sistema.`;
        } else {
          return `❌ Erro ao buscar ${entityType}: ${result.message}`;
        }
      } else {
        return `⚠️ Não posso realizar buscas porque as permissões de leitura estão desativadas nas configurações do Copilot.`;
      }
    } catch (error) {
      console.error('Entity search error:', error);
      return `Desculpe, não consegui realizar a busca solicitada. ${error.message}`;
    }
  };

  const handleTabChange = (value) => {
    setActiveTab(value);
  };

  const handleSettingChange = (key, value) => {
    setSettings(prev => {
      if (key.includes('.')) {
        const [parent, child] = key.split('.');
        return {
          ...prev,
          [parent]: {
            ...prev[parent],
            [child]: value
          }
        };
      }
      return {
        ...prev,
        [key]: value
      };
    });
  };

  const handleQuickActionClick = (message) => {
    setInput(message);
    setTimeout(() => {
      inputRef.current.form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
    }, 300);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed right-0 top-0 h-screen w-[400px] bg-white dark:bg-gray-900 border-l border-gray-200 dark:border-gray-800 shadow-lg flex flex-col z-50">
      <div className="p-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BrainCircuit className="h-5 w-5 text-primary" />
          <div>
            <h3 className="font-semibold">Endurancy Copilot</h3>
            <p className="text-sm text-gray-500">Powered by Claude MCP</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon">
                <Settings className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <div className="space-y-4">
                <h4 className="font-medium">Configurações do Copilot</h4>
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-enabled">Copilot Ativado</Label>
                    <p className="text-xs text-muted-foreground">Habilitar ou desabilitar o Copilot</p>
                  </div>
                  <Switch 
                    id="ai-enabled" 
                    checked={settings.enabled} 
                    onCheckedChange={(value) => handleSettingChange('enabled', value)} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-proactive">Modo Proativo</Label>
                    <p className="text-xs text-muted-foreground">Sugerir ações baseadas na sua atividade</p>
                  </div>
                  <Switch 
                    id="ai-proactive" 
                    checked={settings.proactiveMode} 
                    onCheckedChange={(value) => handleSettingChange('proactiveMode', value)} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-data-access">Acesso a Dados</Label>
                    <p className="text-xs text-muted-foreground">Permitir acesso a dados da plataforma</p>
                  </div>
                  <Switch 
                    id="ai-data-access" 
                    checked={settings.dataAccess} 
                    onCheckedChange={(value) => handleSettingChange('dataAccess', value)} 
                  />
                </div>
                
                <Separator />
                <h4 className="font-medium">Permissões de Ações</h4>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-read">Leitura de Dados</Label>
                    <p className="text-xs text-muted-foreground">Pesquisar e ler informações</p>
                  </div>
                  <Switch 
                    id="ai-read" 
                    checked={settings.actionPermissions.read} 
                    onCheckedChange={(value) => handleSettingChange('actionPermissions.read', value)} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-write">Escrita de Dados</Label>
                    <p className="text-xs text-muted-foreground">Criar e modificar registros</p>
                  </div>
                  <Switch 
                    id="ai-write" 
                    checked={settings.actionPermissions.write} 
                    onCheckedChange={(value) => handleSettingChange('actionPermissions.write', value)} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-delete">Exclusão de Dados</Label>
                    <p className="text-xs text-muted-foreground">Excluir registros (cuidado)</p>
                  </div>
                  <Switch 
                    id="ai-delete" 
                    checked={settings.actionPermissions.delete} 
                    onCheckedChange={(value) => handleSettingChange('actionPermissions.delete', value)} 
                  />
                </div>
              </div>
            </PopoverContent>
          </Popover>
          
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full px-4 pt-2">
        <TabsList className="w-full">
          <TabsTrigger value="chat" className="flex-1">Chat</TabsTrigger>
          <TabsTrigger value="insights" className="flex-1">Insights</TabsTrigger>
          <TabsTrigger value="help" className="flex-1">Ajuda</TabsTrigger>
        </TabsList>
      </Tabs>

      {activeTab === 'chat' && (
        <>
          <div className="p-4 border-b border-gray-200 dark:border-gray-800">
            <div className="flex gap-2 flex-wrap">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => handleQuickActionClick("Crie um novo paciente chamado Maria Silva com CPF 123.456.789-00 e data de nascimento 15/05/1980")}
              >
                <PlusCircle className="h-4 w-4 mr-1" />
                Criar Paciente
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => handleQuickActionClick("Mostre a análise de vendas do último mês")}
              >
                <ChartBar className="h-4 w-4 mr-1" />
                Análise de Vendas
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => handleQuickActionClick("Busque pacientes com nome Maria")}
              >
                <Search className="h-4 w-4 mr-1" />
                Buscar Paciente
              </Button>
            </div>
          </div>

          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {message.role === 'assistant' && (
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Bot className="h-4 w-4 text-primary" />
                    </div>
                  )}
                  <div
                    className={`
                      rounded-lg p-3 max-w-[80%]
                      ${message.role === 'user' 
                        ? 'bg-primary text-primary-foreground ml-4' 
                        : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100'
                      }
                      ${message.error ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-200' : ''}
                    `}
                  >
                    {message.loading ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Pensando...</span>
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap">{message.content}</p>
                    )}
                  </div>
                  {message.role === 'user' && (
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <User className="h-4 w-4 text-primary" />
                    </div>
                  )}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          <form onSubmit={handleSubmit} className="p-4 border-t border-gray-200 dark:border-gray-800">
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Digite sua mensagem..."
                disabled={isLoading}
                className="flex-1"
              />
              <Button type="submit" disabled={isLoading || !input.trim()}>
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
          </form>
        </>
      )}

      {activeTab === 'insights' && (
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-6">
            <h3 className="text-lg font-medium">Insights da Plataforma</h3>
            
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">Vendas Recentes</CardTitle>
                  <BarChart className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">R$ 42.580</div>
                <p className="text-xs text-muted-foreground">
                  +12% comparado ao mês anterior
                </p>
                <Button variant="ghost" size="sm" className="mt-4" onClick={() => {
                  setActiveTab('chat');
                  handleQuickActionClick("Analisar tendências de vendas dos últimos 3 meses");
                }}>
                  <Search className="h-3 w-3 mr-2" />
                  Analisar tendências
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">Pacientes Ativos</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">128</div>
                <p className="text-xs text-muted-foreground">
                  8 novos pacientes este mês
                </p>
                <Button variant="ghost" size="sm" className="mt-4" onClick={() => {
                  setActiveTab('chat');
                  handleQuickActionClick("Mostrar análise demográfica dos pacientes");
                }}>
                  <Search className="h-3 w-3 mr-2" />
                  Ver demografias
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">Produtos com Estoque Baixo</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-amber-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">5</div>
                <p className="text-xs text-muted-foreground">
                  Produtos com estoque abaixo do mínimo
                </p>
                <Button variant="ghost" size="sm" className="mt-4" onClick={() => {
                  setActiveTab('chat');
                  handleQuickActionClick("Listar produtos com estoque crítico");
                }}>
                  <Search className="h-3 w-3 mr-2" />
                  Ver detalhes
                </Button>
              </CardContent>
            </Card>
            
            <Button className="w-full" onClick={() => {
              setActiveTab('chat');
              handleQuickActionClick("Gerar relatório completo de desempenho mensal");
            }}>
              <FileText className="h-4 w-4 mr-2" />
              Gerar Relatório Completo
            </Button>
          </div>
        </ScrollArea>
      )}

      {activeTab === 'help' && (
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-6">
            <h3 className="text-lg font-medium">Ajuda do Copilot</h3>
            
            <div className="bg-primary/5 rounded-lg p-4">
              <h4 className="font-medium flex items-center gap-2 mb-2">
                <HelpCircle className="h-4 w-4 text-primary" />
                O que o Copilot pode fazer?
              </h4>
              <p className="text-sm text-muted-foreground mb-2">
                O Endurancy Copilot pode ajudar você a:
              </p>
              <ul className="text-sm text-muted-foreground space-y-2 ml-6 list-disc">
                <li>Responder perguntas sobre a plataforma</li>
                <li>Criar e buscar registros (pacientes, produtos, etc.)</li>
                <li>Gerar análises e relatórios</li>
                <li>Fornecer tutoriais e dicas</li>
                <li>Automatizar tarefas comuns</li>
              </ul>
            </div>
            
            <h4 className="font-medium mt-6">Perguntas Frequentes</h4>
            <Separator className="my-2" />
            
            <div className="space-y-4">
              {[
                "Como adicionar um novo paciente?",
                "Como verificar o estoque de produtos?",
                "Como gerar uma análise de vendas?",
                "Como usar o módulo de cultivo?",
                "Como configurar o sistema de dispensário?",
                "Como criar uma prescrição médica?"
              ].map((question, i) => (
                <Button 
                  key={i} 
                  variant="ghost" 
                  className="w-full justify-start text-left h-auto py-2"
                  onClick={() => {
                    setActiveTab('chat');
                    handleQuickActionClick(question);
                  }}
                >
                  <div className="mr-3 h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
                    <HelpCircle className="h-3 w-3 text-primary" />
                  </div>
                  {question}
                </Button>
              ))}
            </div>
            
            <Card className="mt-6">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Configurações do Copilot</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Ajuste as permissões e comportamento do seu assistente de IA.
                </p>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => {
                    const settingsButton = document.querySelector('[aria-label="Settings"]');
                    if (settingsButton) settingsButton.click();
                  }}
                >
                  <Sliders className="h-4 w-4 mr-2" />
                  Abrir Configurações
                </Button>
              </CardContent>
            </Card>
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
