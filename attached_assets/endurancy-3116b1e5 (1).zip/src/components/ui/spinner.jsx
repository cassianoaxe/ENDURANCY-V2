import React from "react";

export const Spinner = ({ className = "", size = "default" }) => {
  const sizeClass = 
    size === "small" ? "h-4 w-4" : 
    size === "large" ? "h-8 w-8" : 
    "h-6 w-6";
  
  return (
    <div className={`animate-spin rounded-full border-2 border-current border-t-transparent ${sizeClass} ${className}`} />
  );
};