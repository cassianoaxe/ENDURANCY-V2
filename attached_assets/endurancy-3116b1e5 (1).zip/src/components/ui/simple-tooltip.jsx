import * as React from "react"

const SimpleTooltipProvider = ({ children }) => {
  return (
    <div className="tooltip-provider">
      {children}
    </div>
  )
}

const SimpleTooltip = ({ children }) => {
  return (
    <div className="simple-tooltip">
      {children}
    </div>
  )
}

const SimpleTooltipTrigger = React.forwardRef(({ children, className, ...props }, ref) => (
  <div ref={ref} className={`simple-tooltip-trigger ${className || ''}`} {...props}>
    {children}
  </div>
))
SimpleTooltipTrigger.displayName = "SimpleTooltipTrigger"

const SimpleTooltipContent = React.forwardRef(({ className, children, ...props }, ref) => (
  <div 
    ref={ref} 
    className={`z-50 overflow-hidden rounded-md border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md ${className || ''}`}
    {...props}
  >
    {children}
  </div>
))
SimpleTooltipContent.displayName = "SimpleTooltipContent"

// Create a combined component as default export
const SimpleTooltipComponent = {
  Provider: SimpleTooltipProvider,
  Root: SimpleTooltip,
  Trigger: SimpleTooltipTrigger,
  Content: SimpleTooltipContent
}

export { SimpleTooltip, SimpleTooltipTrigger, SimpleTooltipContent, SimpleTooltipProvider }
export default SimpleTooltipComponent