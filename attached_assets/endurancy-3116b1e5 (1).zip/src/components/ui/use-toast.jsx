
export const toast = (props) => {
  // Direct implementation approach
  if (typeof window !== 'undefined') {
    const toastFn = window.__SHADCN_TOAST;
    if (typeof toastFn === 'function') {
      return toastFn(props);
    }

    console.warn('No toast function found, logging to console instead');
    console.log('Toast:', props.title, props.description);
  }

  return { id: Date.now() };
};
