import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Building2, User, ExternalLink, Copy, Check } from "lucide-react";

export default function HelpAccess() {
  const [copied, setCopied] = React.useState({
    admin: false,
    org: false,
    patient: false
  });
  
  const accessLinks = [
    {
      type: 'admin',
      title: 'CPLY (Admin)',
      icon: <Shield className="w-5 h-5 text-purple-600" />,
      description: 'Acesso para superadministradores do sistema Endurancy',
      link: createPageUrl('Dashboard'),
      credentials: {
        email: 'admin@cply.com',
        password: 'senha de exemplo'
      }
    },
    {
      type: 'org',
      title: 'Organização',
      icon: <Building2 className="w-5 h-5 text-green-600" />,
      description: 'Acesso para organizações (empresas e associações)',
      link: createPageUrl('OrgDashboard'),
      credentials: {
        email: 'joao.silva@medicannabisfarma.com.br',
        password: 'senha de exemplo'
      }
    },
    {
      type: 'patient',
      title: 'Paciente',
      icon: <User className="w-5 h-5 text-blue-600" />,
      description: 'Acesso para pacientes (portal de compras)',
      link: createPageUrl('PatientPortal'),
      credentials: {
        email: 'mariana.silva@gmail.com',
        password: 'senha de exemplo'
      }
    }
  ];

  const copyCredentials = (type, credentials) => {
    const text = `Email: ${credentials.email}\nSenha: ${credentials.password}`;
    navigator.clipboard.writeText(text).then(() => {
      setCopied({ ...copied, [type]: true });
      setTimeout(() => {
        setCopied({ ...copied, [type]: false });
      }, 2000);
    });
  };

  return (
    <div className="p-6 bg-gray-50 rounded-lg">
      <div className="mb-6">
        <h2 className="text-xl font-bold">Links de Acesso ao Endurancy</h2>
        <p className="text-gray-500 mt-1">
          Utilize os links abaixo para acessar as diferentes áreas do sistema.
        </p>
      </div>
      
      <div className="grid gap-4 md:grid-cols-3">
        {accessLinks.map((access) => (
          <Card key={access.type} className="overflow-hidden">
            <CardHeader className="bg-gray-50 flex flex-row items-center gap-3 pb-4">
              <div className="p-2 bg-white rounded-lg shadow-sm">
                {access.icon}
              </div>
              <div>
                <CardTitle>{access.title}</CardTitle>
                <CardDescription>{access.description}</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="space-y-2">
                <div className="text-sm">
                  <span className="font-medium block">Email:</span>
                  <code className="bg-gray-100 px-2 py-1 rounded-md">{access.credentials.email}</code>
                </div>
                <div className="text-sm">
                  <span className="font-medium block">Senha:</span>
                  <code className="bg-gray-100 px-2 py-1 rounded-md">senha de exemplo</code>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-3">
              <Button 
                onClick={() => copyCredentials(access.type, access.credentials)} 
                variant="outline" 
                className="w-full justify-center"
              >
                {copied[access.type] ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copiar credenciais
                  </>
                )}
              </Button>
              <Link to={access.link} className="w-full">
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Acessar {access.title}
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="mt-6 text-sm text-gray-500 bg-blue-50 p-4 rounded-lg">
        <p className="font-medium text-blue-600 mb-1">Observação</p>
        <p>Em um ambiente real, você usaria o sistema de autenticação integrado. Para esta demonstração, as senhas não são validadas.</p>
      </div>
      
      <div className="mt-6 text-center">
        <Link to={createPageUrl("Access")}>
          <Button className="bg-green-600 hover:bg-green-700">
            Ir para a página de login personalizada
            <ExternalLink className="w-4 h-4 ml-2" />
          </Button>
        </Link>
      </div>
    </div>
  );
}