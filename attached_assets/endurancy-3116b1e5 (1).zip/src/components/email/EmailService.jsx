import { SendEmail } from "@/api/integrations";
import { EmailTemplate } from "@/api/entities";
import { User } from "@/api/entities";

/**
 * Serviço de emails da plataforma
 */
export class EmailService {
  /**
   * Envia um email usando um template
   * @param {string} templateCode - Código do template a ser usado
   * @param {string} recipientEmail - Email do destinatário
   * @param {object} variables - Variáveis para substituir no template
   * @param {string} senderName - Nome personalizado do remetente (opcional)
   * @returns {Promise<object>} - Resultado do envio
   */
  static async sendTemplateEmail(templateCode, recipientEmail, variables = {}, senderName = null) {
    try {
      // Busca o template
      const templates = await EmailTemplate.filter({ code: templateCode, is_active: true });
      
      if (templates.length === 0) {
        throw new Error(`Template de email com código '${templateCode}' não encontrado ou inativo`);
      }
      
      const template = templates[0];
      
      // Processa o template substituindo as variáveis
      let subject = template.subject;
      let content = template.html_content;
      
      // Substitui as variáveis no assunto e conteúdo
      Object.entries(variables).forEach(([key, value]) => {
        const regex = new RegExp(`{{\\s*${key}\\s*}}`, 'g');
        subject = subject.replace(regex, value);
        content = content.replace(regex, value);
      });
      
      // Envia o email usando a integração Core
      const result = await SendEmail({
        from_name: senderName || "Plataforma Endurancy",
        to: recipientEmail,
        subject: subject,
        body: content
      });
      
      return { success: true, ...result };
    } catch (error) {
      console.error("Erro ao enviar email:", error);
      return { 
        success: false, 
        error: error.message || "Erro desconhecido ao enviar email" 
      };
    }
  }
  
  /**
   * Envia email de boas-vindas para novo usuário
   * @param {string} email - Email do usuário
   * @param {string} name - Nome do usuário
   * @param {string} organizationName - Nome da organização
   * @returns {Promise<object>} - Resultado do envio
   */
  static async sendWelcomeEmail(email, name, organizationName) {
    return this.sendTemplateEmail('welcome_user', email, {
      name: name,
      organization: organizationName,
      login_url: `${window.location.origin}/login`,
      current_date: new Date().toLocaleDateString('pt-BR')
    });
  }
  
  /**
   * Envia email de aprovação de organização
   * @param {string} email - Email do contato
   * @param {string} contactName - Nome do contato
   * @param {string} organizationName - Nome da organização
   * @returns {Promise<object>} - Resultado do envio
   */
  static async sendOrganizationApprovalEmail(email, contactName, organizationName) {
    return this.sendTemplateEmail('organization_approved', email, {
      contact_name: contactName,
      organization_name: organizationName,
      login_url: `${window.location.origin}/login`,
      current_date: new Date().toLocaleDateString('pt-BR')
    });
  }
  
  /**
   * Envia email de rejeição de organização
   * @param {string} email - Email do contato
   * @param {string} contactName - Nome do contato
   * @param {string} organizationName - Nome da organização
   * @param {string} rejectionReason - Motivo da rejeição
   * @returns {Promise<object>} - Resultado do envio
   */
  static async sendOrganizationRejectionEmail(email, contactName, organizationName, rejectionReason) {
    return this.sendTemplateEmail('organization_rejected', email, {
      contact_name: contactName,
      organization_name: organizationName,
      rejection_reason: rejectionReason,
      support_email: 'suporte@endurancy.com',
      current_date: new Date().toLocaleDateString('pt-BR')
    });
  }
  
  /**
   * Envia email de convite para novo usuário
   * @param {string} email - Email do usuário convidado
   * @param {string} inviterName - Nome de quem convidou
   * @param {string} organizationName - Nome da organização
   * @param {string} role - Função do usuário na organização
   * @returns {Promise<object>} - Resultado do envio
   */
  static async sendInvitationEmail(email, inviterName, organizationName, role) {
    return this.sendTemplateEmail('user_invitation', email, {
      inviter_name: inviterName,
      organization_name: organizationName,
      role: role,
      invitation_link: `${window.location.origin}/accept-invite?email=${encodeURIComponent(email)}`,
      expire_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR')
    });
  }
  
  /**
   * Envia email de notificação de senha redefinida
   * @param {string} email - Email do usuário
   * @param {string} name - Nome do usuário
   * @returns {Promise<object>} - Resultado do envio
   */
  static async sendPasswordResetNotification(email, name) {
    return this.sendTemplateEmail('password_reset_notification', email, {
      name: name,
      reset_time: new Date().toLocaleString('pt-BR'),
      support_email: 'suporte@endurancy.com'
    });
  }
  
  /**
   * Envia email de alerta de segurança
   * @param {string} email - Email do usuário
   * @param {string} name - Nome do usuário
   * @param {string} alertType - Tipo de alerta
   * @param {string} details - Detalhes do alerta
   * @returns {Promise<object>} - Resultado do envio
   */
  static async sendSecurityAlert(email, name, alertType, details) {
    return this.sendTemplateEmail('security_alert', email, {
      name: name,
      alert_type: alertType,
      details: details,
      time: new Date().toLocaleString('pt-BR'),
      support_email: 'suporte@endurancy.com'
    });
  }
}

export default EmailService;