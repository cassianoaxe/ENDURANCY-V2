import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  MoreHorizontal, 
  Building2, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Mail, 
  Calendar, 
  Edit, 
  Trash2 
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Dados simulados para evitar problemas de timeout com a API
const mockOrganizations = [
  {
    id: "org1",
    name: "MediCannabis Farma",
    type: "Empresa",
    plan: "Empresarial Pro",
    contact_name: "João Silva",
    contact_email: "joao@medicannabis.com.br",
    contact_phone: "+55 11 98765-4321",
    status: "Ativo",
    created_date: "2023-07-15T14:30:00Z"
  },
  {
    id: "org2",
    name: "Associação Médica Verde",
    type: "Associação",
    plan: "Associação Premium",
    contact_name: "Maria Oliveira",
    contact_email: "maria@amv.org.br",
    contact_phone: "+55 21 99876-5432",
    status: "Ativo",
    created_date: "2023-07-12T10:15:00Z"
  },
  {
    id: "org3",
    name: "CannaPesquisa Instituto",
    type: "Associação",
    plan: "Associação Plus",
    contact_name: "Pedro Almeida",
    contact_email: "pedro@cannapesquisa.org",
    contact_phone: "+55 31 98887-6655",
    status: "Pendente",
    created_date: "2023-07-21T09:45:00Z"
  },
  {
    id: "org4",
    name: "Green Medical Brasil",
    type: "Empresa",
    plan: "Empresarial Básico",
    contact_name: "Ana Sousa",
    contact_email: "ana@greenmedical.com.br",
    contact_phone: "+55 41 99998-7766",
    status: "Pendente",
    created_date: "2023-07-20T16:20:00Z"
  }
];

export default function OrganizationsTable({ limit = null, statusFilter = null, showActions = true }) {
  const [organizations, setOrganizations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    loadOrganizations();
  }, []);
  
  const loadOrganizations = async () => {
    try {
      setIsLoading(true);
      
      // Simular carregamento de dados
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Usar dados simulados
      let filteredOrgs = [...mockOrganizations];
      
      if (statusFilter) {
        filteredOrgs = filteredOrgs.filter(org => org.status === statusFilter);
      }
      
      if (limit) {
        filteredOrgs = filteredOrgs.slice(0, limit);
      }
      
      setOrganizations(filteredOrgs);
    } catch (error) {
      console.error("Error loading organizations", error);
      setOrganizations([]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  const statusStyles = {
    "Ativo": "bg-green-100 text-green-800",
    "Pendente": "bg-yellow-100 text-yellow-800",
    "Rejeitado": "bg-red-100 text-red-800"
  };
  
  const typeStyles = {
    "Empresa": "bg-blue-100 text-blue-800",
    "Associação": "bg-purple-100 text-purple-800"
  };
  
  const statusIcons = {
    "Ativo": <CheckCircle2 className="w-3 h-3 mr-1" />,
    "Pendente": <Clock className="w-3 h-3 mr-1" />,
    "Rejeitado": <XCircle className="w-3 h-3 mr-1" />
  };

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Tipo</TableHead>
            <TableHead>Contato</TableHead>
            <TableHead>Criado em</TableHead>
            <TableHead>Status</TableHead>
            {showActions && <TableHead className="text-right">Ações</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            Array(3).fill(0).map((_, i) => (
              <TableRow key={i} className="animate-pulse">
                <TableCell>
                  <div className="h-5 bg-gray-200 rounded w-32"></div>
                </TableCell>
                <TableCell>
                  <div className="h-5 bg-gray-200 rounded w-24"></div>
                </TableCell>
                <TableCell>
                  <div className="h-5 bg-gray-200 rounded w-36"></div>
                </TableCell>
                <TableCell>
                  <div className="h-5 bg-gray-200 rounded w-24"></div>
                </TableCell>
                <TableCell>
                  <div className="h-5 bg-gray-200 rounded w-20"></div>
                </TableCell>
                {showActions && (
                  <TableCell>
                    <div className="flex justify-end">
                      <div className="h-8 bg-gray-200 rounded w-8"></div>
                    </div>
                  </TableCell>
                )}
              </TableRow>
            ))
          ) : organizations.length === 0 ? (
            <TableRow>
              <TableCell colSpan={showActions ? 6 : 5} className="text-center py-8">
                <Building2 className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                <h3 className="text-lg font-medium">Nenhuma organização encontrada</h3>
                <p className="text-gray-500 mt-1">
                  {statusFilter ? "Não há organizações com o status selecionado" : "Adicione sua primeira organização"}
                </p>
              </TableCell>
            </TableRow>
          ) : (
            organizations.map((org) => (
              <TableRow key={org.id}>
                <TableCell className="font-medium">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-gray-400" />
                    <span>{org.name}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className={typeStyles[org.type]}>
                    {org.type}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="text-sm">
                    <div className="flex items-center gap-1 text-gray-700">
                      <span className="font-medium">{org.contact_name}</span>
                    </div>
                    <div className="flex items-center gap-1 text-gray-500">
                      <Mail className="w-3 h-3" />
                      <span>{org.contact_email}</span>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1 text-sm">
                    <Calendar className="w-3 h-3 text-gray-400" />
                    {formatDate(org.created_date)}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className={statusStyles[org.status]}>
                    {statusIcons[org.status]}
                    {org.status}
                  </Badge>
                </TableCell>
                {showActions && (
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Ações</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <Link to={`${createPageUrl("Request")}?id=${org.id}`}>
                          <DropdownMenuItem>
                            <Building2 className="w-4 h-4 mr-2" />
                            Ver Detalhes
                          </DropdownMenuItem>
                        </Link>
                        <DropdownMenuItem>
                          <Edit className="w-4 h-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="w-4 h-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                )}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}