import React from 'react';
import { Card } from "@/components/ui/card";
import { ArrowUp } from "lucide-react";

export default function StatsCard({ title, value, subtitle, icon: Icon, trend }) {
  return (
    <Card className="p-6">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-sm font-medium text-gray-500">{title}</h3>
          <p className="text-2xl font-bold mt-2">{value}</p>
          <p className="text-sm text-gray-500 mt-1">{subtitle}</p>
        </div>
        <div className="p-3 bg-green-50 rounded-xl">
          <Icon className="w-5 h-5 text-green-600" />
        </div>
      </div>
      {trend && (
        <div className="flex items-center gap-1 mt-4 text-green-600 text-sm">
          <ArrowUp className="w-4 h-4" />
          <span>{trend}</span>
        </div>
      )}
    </Card>
  );
}