import React, { useState, useEffect } from 'react';
import EstoqueBaseView from '../components/estoque/EstoqueBaseView';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function EstoqueAtivos() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [tipoFilter, setTipoFilter] = useState("all");

  useEffect(() => {
    // Simular carregamento de dados
    setTimeout(() => {
      const mockData = [
        {
          id: "1",
          codigo: "CBD-ISO-001",
          nome: "CBD Isolado 99,9%",
          lote: "L202301",
          quantidade_atual: 500,
          quantidade_minima: 1000,
          unidade_medida: "g",
          status: "disponivel",
          data_validade: "2024-12-31"
        },
        // Add more mock data...
      ];
      setData(mockData);
      setLoading(false);
    }, 1000);
  }, []);

  const customFilters = (
    <Select value={tipoFilter} onValueChange={setTipoFilter}>
      <SelectTrigger className="w-40">
        <SelectValue placeholder="Tipo" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">Todos Tipos</SelectItem>
        <SelectItem value="isolado">Isolado</SelectItem>
        <SelectItem value="full_spectrum">Full Spectrum</SelectItem>
        <SelectItem value="broad_spectrum">Broad Spectrum</SelectItem>
      </SelectContent>
    </Select>
  );

  return (
    <EstoqueBaseView
      title="Estoque de Ativos"
      description="Gestão de estoque de princípios ativos"
      tipoEstoque="materia_prima_ativo"
      data={data}
      loading={loading}
      onAddItem={() => console.log("Adicionar item")}
      onEditItem={(item) => console.log("Editar item", item)}
      onViewDetails={(item) => console.log("Ver detalhes", item)}
      customFilters={customFilters}
    />
  );
}