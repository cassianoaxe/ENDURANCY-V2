import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ArrowLeftRight, 
  Search, 
  Filter, 
  Clock, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  MoreHorizontal, 
  AlertTriangle, 
  Download, 
  Package, 
  FileSearch, 
  RefreshCw,
  Plus,
  Eye
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import { Progress } from "@/components/ui/progress";

export default function CrmRecolhimento() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [tipoFilter, setTipoFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [recolhimentos, setRecolhimentos] = useState([]);
  const [loteSearch, setLoteSearch] = useState("");

  // Mock data para recolhimentos
  const mockRecolhimentos = [
    {
      id: "REC-2023-001",
      tipo: "preventivo",
      status: "planejamento",
      data_inicio: "2023-11-15T09:30:00Z",
      produto: "Óleo de CBD 5%",
      lote: "LOT-2023-005",
      motivo: "Problema identificado na análise de estabilidade acelerada",
      classe_risco: "II",
      quantidade_fabricada: 500,
      quantidade_distribuida: 320,
      quantidade_recolhida: 0,
      responsavel: "Ana Costa"
    },
    {
      id: "REC-2022-005",
      tipo: "corretivo",
      status: "concluido",
      data_inicio: "2022-06-10T14:30:00Z",
      data_conclusao: "2022-07-15T16:45:00Z",
      produto: "Cápsulas de CBD 25mg",
      lote: "LOT-2022-008",
      motivo: "Resultado fora de especificação para teor de CBD",
      classe_risco: "III",
      quantidade_fabricada: 1000,
      quantidade_distribuida: 850,
      quantidade_recolhida: 820,
      responsavel: "Carlos Santos"
    }
  ];

  useEffect(() => {
    // Simula carregamento de dados
    setIsLoading(true);
    setTimeout(() => {
      setRecolhimentos(mockRecolhimentos);
      setIsLoading(false);
    }, 1000);
  }, []);

  const handleSearchRastreabilidade = () => {
    if (!loteSearch.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, informe o número do lote",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    // Simula pesquisa de lote
    setTimeout(() => {
      toast({
        title: "Lote encontrado",
        description: "Detalhes do lote foram carregados com sucesso",
      });
      setIsLoading(false);
    }, 1500);
  };

  const getTipoBadge = (tipo) => {
    switch (tipo) {
      case "preventivo":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Preventivo</Badge>;
      case "corretivo":
        return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">Corretivo</Badge>;
      default:
        return <Badge variant="outline">{tipo}</Badge>;
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "planejamento":
        return <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">Planejamento</Badge>;
      case "em_andamento":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Em andamento</Badge>;
      case "concluido":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Concluído</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const filteredRecolhimentos = recolhimentos.filter(item => {
    const matchesSearch = 
      item.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.produto.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.lote.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.motivo?.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesTipo = tipoFilter === "all" || item.tipo === tipoFilter;
    const matchesStatus = statusFilter === "all" || item.status === statusFilter;
    
    return matchesSearch && matchesTipo && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Recolhimento de Produtos</h1>
          <p className="text-gray-500 mt-1">
            Gestão, rastreabilidade e recolhimento (recall) de produtos comercializados
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button variant="outline" className="gap-2">
            <FileSearch className="h-4 w-4" />
            Rastrear Lote
          </Button>
          <Button variant="outline" className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Recall Simulado
          </Button>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Novo Recolhimento
          </Button>
        </div>
      </div>

      {/* Cards informativos no topo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              Legislação ANVISA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600">
              A RDC 430/2020 determina que as empresas devem ser capazes de rastrear e recolher 100% 
              dos lotes distribuídos e realizar pelo menos um exercício simulado anual de recolhimento.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <FileSearch className="h-4 w-4 text-blue-500" />
              Rastreabilidade
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600">
              A rastreabilidade permite identificar o destino de todas as unidades de um lote específico, 
              desde a produção até o recebimento pelos pacientes.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <ArrowLeftRight className="h-4 w-4 text-green-500" />
              Recall Simulado
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600">
              O exercício simulado testa a eficácia dos procedimentos de recolhimento sem necessidade de 
              contato com pacientes, avaliando a capacidade de rastreamento.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Card Busca Rastreabilidade */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Busca de Lote</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 space-y-2">
              <Label htmlFor="lote">Número do Lote</Label>
              <div className="flex gap-2">
                <Input 
                  id="lote"
                  placeholder="Ex: LOT-2023-001" 
                  value={loteSearch}
                  onChange={(e) => setLoteSearch(e.target.value)}
                />
                <Button 
                  onClick={handleSearchRastreabilidade}
                  disabled={isLoading}
                >
                  {isLoading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Search className="h-4 w-4 mr-2" />}
                  Buscar
                </Button>
              </div>
              <p className="text-sm text-gray-500">
                Informe o número do lote para rastrear toda a distribuição e pacientes que receberam produtos deste lote.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Card Filtros */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Recolhimentos</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <Label htmlFor="search" className="mb-2 block">Buscar</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="search"
                  placeholder="Buscar por ID, produto, lote..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="tipo" className="mb-2 block">Tipo</Label>
              <Select
                id="tipo"
                value={tipoFilter}
                onValueChange={setTipoFilter}
              >
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Todos os tipos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="preventivo">Preventivo</SelectItem>
                  <SelectItem value="corretivo">Corretivo</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="status" className="mb-2 block">Status</Label>
              <Select
                id="status"
                value={statusFilter}
                onValueChange={setStatusFilter}
              >
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Todos os status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="planejamento">Planejamento</SelectItem>
                  <SelectItem value="em_andamento">Em andamento</SelectItem>
                  <SelectItem value="concluido">Concluído</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Tabela de Recolhimentos */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Produto/Lote</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Eficácia</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  [1, 2, 3].map((index) => (
                    <TableRow key={index} className="animate-pulse">
                      <TableCell><div className="h-4 w-20 bg-gray-200 rounded"></div></TableCell>
                      <TableCell><div className="h-4 w-32 bg-gray-200 rounded"></div></TableCell>
                      <TableCell><div className="h-4 w-20 bg-gray-200 rounded"></div></TableCell>
                      <TableCell><div className="h-4 w-24 bg-gray-200 rounded"></div></TableCell>
                      <TableCell><div className="h-4 w-20 bg-gray-200 rounded"></div></TableCell>
                      <TableCell><div className="h-4 w-16 bg-gray-200 rounded"></div></TableCell>
                      <TableCell className="text-right"><div className="h-8 w-20 bg-gray-200 rounded ml-auto"></div></TableCell>
                    </TableRow>
                  ))
                ) : filteredRecolhimentos.length > 0 ? (
                  filteredRecolhimentos.map((recolhimento) => (
                    <TableRow key={recolhimento.id}>
                      <TableCell className="font-medium">{recolhimento.id}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{recolhimento.produto}</div>
                          <div className="text-sm text-gray-500">Lote: {recolhimento.lote}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {getTipoBadge(recolhimento.tipo)}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">{formatDate(recolhimento.data_inicio)}</div>
                        {recolhimento.data_conclusao && (
                          <div className="text-xs text-gray-500">
                            Concluído: {formatDate(recolhimento.data_conclusao)}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(recolhimento.status)}
                      </TableCell>
                      <TableCell>
                        {recolhimento.status === "concluido" ? (
                          <div>
                            <div className="flex items-center gap-2">
                              <Progress 
                                value={(recolhimento.quantidade_recolhida / recolhimento.quantidade_distribuida) * 100} 
                                className="h-2 w-16" 
                              />
                              <span className="text-sm">
                                {Math.round((recolhimento.quantidade_recolhida / recolhimento.quantidade_distribuida) * 100)}%
                              </span>
                            </div>
                            <div className="text-xs text-gray-500">
                              {recolhimento.quantidade_recolhida}/{recolhimento.quantidade_distribuida} un.
                            </div>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-500">Em progresso</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button 
                          variant="ghost" 
                          size="sm"
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          Detalhes
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      Nenhum recolhimento encontrado
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Histórico de Recalls Simulados */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Exercícios de Recall Simulado</CardTitle>
              <CardDescription>
                Histórico de exercícios simulados de recolhimento para avaliação da capacidade de rastreabilidade
              </CardDescription>
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Novo Exercício
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Produto/Lote</TableHead>
                  <TableHead>Responsável</TableHead>
                  <TableHead>Eficácia</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">SIM-2023-001</TableCell>
                  <TableCell>15/08/2023</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span>Cápsulas de CBD 25mg</span>
                      <span className="text-xs text-muted-foreground">Lote: LOT-2023-002</span>
                    </div>
                  </TableCell>
                  <TableCell>Carlos Santos</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <Progress value={98} className="h-2 w-16" />
                        <span className="text-sm">98%</span>
                      </div>
                      <span className="text-xs text-muted-foreground">Rastreab. 98% / Recolh. 92%</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      Concluído
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="ghost" 
                      size="sm"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Detalhes
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}