
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Eye, EyeOff, ArrowRight, UserRound, Lock, Info } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Access() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState("admin");
  const [formData, setFormData] = useState({
    email: "",
    password: ""
  });
  const [loginError, setLoginError] = useState("");
  const [loginSuccess, setLoginSuccess] = useState("");

  useEffect(() => {
    try {
      if (typeof localStorage !== 'undefined' && localStorage) {
        localStorage.removeItem('mockUserType');
        localStorage.removeItem('mockUserEmail');
        localStorage.removeItem('mockUserName');
        localStorage.removeItem('mockOrgType');
      }
      
      if (typeof sessionStorage !== 'undefined' && sessionStorage) {
        sessionStorage.removeItem('isLoggingOut');
      }
    } catch (error) {
      console.error("Error clearing storage:", error);
    }

    const credentials = getCredentialsInfo("admin");
    setFormData({
      email: credentials.email,
      password: credentials.password
    });
  }, []);

  useEffect(() => {
    const credentials = getCredentialsInfo(activeTab);
    setFormData({
      email: credentials.email,
      password: credentials.password
    });
    setLoginError("");
    setLoginSuccess("");
  }, [activeTab]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setLoginError("");
    setLoginSuccess("");

    try {
      console.log("Login attempt:", activeTab, formData);
      
      let targetRoute = "";
      let successMessage = "";
      
      if (activeTab === "admin") {
        console.log("Setting admin credentials");
        try {
          localStorage.setItem('mockUserType', 'superadmin');
          localStorage.setItem('mockUserEmail', 'admin@comply.com');
          localStorage.setItem('mockUserName', 'Comply');
        } catch (error) {
          console.error("Error setting localStorage:", error);
        }
        targetRoute = "Dashboard";
        successMessage = "Bem-vindo ao painel de administração da Endurancy.";
      } 
      else if (activeTab === "organization") {
        console.log("Setting organization credentials");
        try {
          localStorage.setItem('mockUserType', 'orgadmin');
          localStorage.setItem('mockUserEmail', 'org@endurancy.com');
          localStorage.setItem('mockUserName', 'Administrador da Organização');
          localStorage.setItem('mockOrgType', 'Associação');
        } catch (error) {
          console.error("Error setting localStorage:", error);
        }
        targetRoute = "OrgDashboard";
        successMessage = "Bem-vindo ao painel da sua organização.";
      } 
      else if (activeTab === "doctor") {
        try {
          localStorage.setItem('mockUserType', 'doctor');
          localStorage.setItem('mockUserEmail', 'doctor@endurancy.com');
          localStorage.setItem('mockUserName', 'Dr. João Silva');
        } catch (error) {
          console.error("Error setting localStorage:", error);
        }
        targetRoute = "DoctorDashboard";
        successMessage = "Bem-vindo ao portal médico.";
      } 
      else if (activeTab === "patient") {
        try {
          localStorage.setItem('mockUserType', 'patient');
          localStorage.setItem('mockUserEmail', 'patient@email.com');
          localStorage.setItem('mockUserName', 'Maria Oliveira');
        } catch (error) {
          console.error("Error setting localStorage:", error);
        }
        targetRoute = "PatientDashboard";
        successMessage = "Bem-vindo ao portal do paciente.";
      }
      
      setLoginSuccess(successMessage);
      setIsLoading(false);
      
      setTimeout(() => {
        console.log(`Redirecting to ${targetRoute}`);
        
        const targetUrl = createPageUrl(targetRoute);
        console.log("Target URL:", targetUrl);
        window.location.href = targetUrl;
      }, 1500);
      
    } catch (error) {
      console.error("Error during login:", error);
      setLoginError("Erro ao processar o login. Por favor tente novamente.");
      setIsLoading(false);
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const getCredentialsInfo = (tab) => {
    const tabToUse = tab || activeTab;
    
    switch (tabToUse) {
      case "admin":
        return {
          email: "admin@comply.com",
          password: "admin123"
        };
      case "organization":
        return {
          email: "org@endurancy.com",
          password: "org123"
        };
      case "doctor":
        return {
          email: "doctor@endurancy.com",
          password: "doctor123"
        };
      case "patient":
        return {
          email: "patient@email.com",
          password: "patient123"
        };
      default:
        return {
          email: "",
          password: ""
        };
    }
  };

  const credentials = getCredentialsInfo();

  const fillCredentials = () => {
    setFormData({
      email: credentials.email,
      password: credentials.password
    });
    setLoginError("");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-2">
            <div className="h-12 w-12 bg-green-100 rounded-xl flex items-center justify-center">
              <span className="text-green-600 text-2xl font-bold">E</span>
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Endurancy</h1>
          <p className="text-gray-500 mt-1">Plataforma de Controle e Regulação</p>
        </div>

        <Card className="border-0 shadow-lg">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl text-center">Acesso ao Sistema</CardTitle>
            <CardDescription className="text-center">
              Faça login para acessar a plataforma
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="admin" value={activeTab} onValueChange={setActiveTab} className="mb-6">
              <TabsList className="grid grid-cols-4 mb-6">
                <TabsTrigger value="admin">Comply</TabsTrigger>
                <TabsTrigger value="organization">Organização</TabsTrigger>
                <TabsTrigger value="doctor">Médico</TabsTrigger>
                <TabsTrigger value="patient">Paciente</TabsTrigger>
              </TabsList>

              <form onSubmit={handleSubmit}>
                <div className="space-y-4">
                  {loginSuccess && (
                    <Alert className="bg-green-50 border-green-200 text-green-800">
                      <AlertDescription>{loginSuccess}</AlertDescription>
                    </Alert>
                  )}
                  
                  {loginError && (
                    <Alert variant="destructive" className="bg-red-50 border-red-200 text-red-800">
                      <AlertDescription>{loginError}</AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <div className="relative">
                      <UserRound className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        className="pl-10"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password">Senha</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <Input
                        id="password"
                        name="password"
                        type={showPassword ? "text" : "password"}
                        className="pl-10"
                        value={formData.password}
                        onChange={handleInputChange}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0"
                        onClick={togglePasswordVisibility}
                      >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </Button>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full gap-2 bg-green-600 hover:bg-green-700"
                    disabled={isLoading}
                  >
                    {isLoading ? "Entrando..." : "Entrar"}
                    {!isLoading && <ArrowRight size={18} />}
                  </Button>
                </div>
              </form>
              
              <Alert className="mt-6 bg-blue-50 border-blue-200">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-800 text-sm">
                  <span className="font-medium">Credenciais de demonstração:</span><br />
                  Email: <span className="font-medium">{credentials.email}</span><br />
                  Senha: <span className="font-medium">{credentials.password}</span>
                  <div className="mt-2">
                    <Button 
                      onClick={fillCredentials} 
                      size="sm" 
                      variant="outline" 
                      className="w-full text-blue-600 border-blue-200 hover:bg-blue-50"
                    >
                      Preencher automaticamente
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            </Tabs>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4 pt-0">
            <div className="text-center text-sm">
              <a 
                href={createPageUrl("ForgotPassword")} 
                className="text-green-600 hover:text-green-800 underline-offset-4 hover:underline"
              >
                Esqueceu sua senha?
              </a>
            </div>
            
            <div className="text-center text-xs text-gray-500">
              <p>© 2024 Endurancy. Todos os direitos reservados.</p>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
