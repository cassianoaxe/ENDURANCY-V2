import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  FileCheck, 
  ArrowLeft, 
  Save, 
  Plus, 
  Minus, 
  User, 
  Calendar, 
  FileText, 
  Pill, 
  Clock, 
  Info, 
  Search,
  Upload,
  AlertCircle,
  UserCheck,
  CircleCheck,
  X
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Command,
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { toast } from "@/components/ui/use-toast";
import { UploadFile } from "@/api/integrations";

// Dados simulados
const mockPatients = [
  {
    id: "pac001",
    nome_completo: "Maria Silva Oliveira",
    cpf: "123.456.789-00",
    data_nascimento: "1975-05-15",
    genero: "feminino",
    telefone: "(11) 98765-4321",
    email: "maria.silva@email.com",
    status: "ativo",
    condicoes_medicas: ["Epilepsia Refratária", "Ansiedade"]
  },
  {
    id: "pac002",
    nome_completo: "José Pereira Souza",
    cpf: "987.654.321-00",
    data_nascimento: "1968-08-22",
    genero: "masculino",
    telefone: "(11) 97654-3210",
    email: "jose.pereira@email.com",
    status: "ativo",
    condicoes_medicas: ["Dor Crônica", "Insônia"]
  },
  {
    id: "pac003",
    nome_completo: "Antônio Carlos Ferreira",
    cpf: "456.789.123-00",
    data_nascimento: "1950-02-10",
    genero: "masculino",
    telefone: "(11) 96543-2109",
    email: "antonio.ferreira@email.com",
    status: "ativo",
    condicoes_medicas: ["Parkinson", "Artrite"]
  }
];

const mockDoctors = [
  {
    id: "doc001",
    nome: "Dr. João Carlos Santos",
    crm: "12345-SP",
    especialidade: "Neurologia"
  },
  {
    id: "doc002",
    nome: "Dra. Ana Paula Mendes",
    crm: "54321-SP",
    especialidade: "Medicina da Dor"
  },
  {
    id: "doc003",
    nome: "Dr. Roberto Almeida",
    crm: "23456-SP",
    especialidade: "Geriatria"
  },
  {
    id: "doc004",
    nome: "Dra. Cristina Martins",
    crm: "45678-SP",
    especialidade: "Psiquiatria"
  }
];

const mockProducts = [
  {
    id: "prod001",
    nome: "Óleo CBD 5% 30ml",
    descricao: "Óleo de CBD com 5% de concentração",
    categoria: "óleo",
    controlled_substance: true,
    thc_content: 0.1,
    cbd_content: 5.0
  },
  {
    id: "prod002",
    nome: "Óleo CBD 10% 30ml",
    descricao: "Óleo de CBD com 10% de concentração",
    categoria: "óleo",
    controlled_substance: true,
    thc_content: 0.2,
    cbd_content: 10.0
  },
  {
    id: "prod003",
    nome: "Tinturas CBD 3% 50ml",
    descricao: "Tintura de CBD para uso sublingual",
    categoria: "tintura",
    controlled_substance: true,
    thc_content: 0.05,
    cbd_content: 3.0
  },
  {
    id: "prod004",
    nome: "Cápsulas CBD 20mg",
    descricao: "Cápsulas de CBD com 20mg por unidade",
    categoria: "cápsula",
    controlled_substance: true,
    thc_content: 0.1,
    cbd_content: 4.0
  },
  {
    id: "prod005",
    nome: "Creme CBD tópico 50g",
    descricao: "Creme para aplicação tópica com CBD",
    categoria: "tópico",
    controlled_substance: true,
    thc_content: 0.0,
    cbd_content: 2.0
  }
];

export default function NovaPrescricao() {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [showPatientDialog, setShowPatientDialog] = useState(false);
  const [showDoctorDialog, setShowDoctorDialog] = useState(false);
  const [searchPatientTerm, setSearchPatientTerm] = useState("");
  const [searchDoctorTerm, setSearchDoctorTerm] = useState("");

  // Estado do formulário
  const [form, setForm] = useState({
    numero: `P-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`,
    paciente: null,
    medico: null,
    data_emissao: new Date(),
    data_validade: (() => {
      const date = new Date();
      date.setMonth(date.getMonth() + 6);
      return date;
    })(),
    produtos: [
      { produto: null, dosagem: "", quantidade: 1, duracao: "30 dias" }
    ],
    diagnostico: "",
    observacoes: "",
    file_url: ""
  });

  // Filtros para pacientes e médicos
  const filteredPatients = searchPatientTerm 
    ? mockPatients.filter(patient => 
        patient.nome_completo.toLowerCase().includes(searchPatientTerm.toLowerCase()) ||
        patient.cpf.includes(searchPatientTerm)
      )
    : mockPatients;

  const filteredDoctors = searchDoctorTerm
    ? mockDoctors.filter(doctor => 
        doctor.nome.toLowerCase().includes(searchDoctorTerm.toLowerCase()) ||
        doctor.crm.includes(searchDoctorTerm)
      )
    : mockDoctors;

  // Funções auxiliares
  const handleSelectPatient = (patient) => {
    setForm(prev => ({ ...prev, paciente: patient }));
    setShowPatientDialog(false);
  };

  const handleSelectDoctor = (doctor) => {
    setForm(prev => ({ ...prev, medico: doctor }));
    setShowDoctorDialog(false);
  };

  const handleAddProduct = () => {
    setForm(prev => ({
      ...prev,
      produtos: [...prev.produtos, { produto: null, dosagem: "", quantidade: 1, duracao: "30 dias" }]
    }));
  };

  const handleRemoveProduct = (index) => {
    setForm(prev => ({
      ...prev,
      produtos: prev.produtos.filter((_, i) => i !== index)
    }));
  };

  const handleProductChange = (index, field, value) => {
    const newProdutos = [...form.produtos];
    newProdutos[index] = { ...newProdutos[index], [field]: value };
    setForm(prev => ({ ...prev, produtos: newProdutos }));
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const result = await UploadFile({ file });
      setForm(prev => ({ ...prev, file_url: result.file_url }));
      toast({
        title: "Arquivo enviado com sucesso",
        description: "O documento da prescrição foi anexado"
      });
    } catch (error) {
      console.error("Erro ao fazer upload:", error);
      toast({
        title: "Erro ao enviar arquivo",
        description: "Não foi possível enviar o documento. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validação
    if (!form.paciente) {
      toast({
        title: "Dados incompletos",
        description: "Selecione um paciente para continuar",
        variant: "destructive"
      });
      return;
    }
    
    if (!form.medico) {
      toast({
        title: "Dados incompletos",
        description: "Selecione um médico para continuar",
        variant: "destructive"
      });
      return;
    }
    
    const invalidProduct = form.produtos.find(p => !p.produto);
    if (invalidProduct) {
      toast({
        title: "Dados incompletos",
        description: "Selecione todos os produtos da prescrição",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Aqui você faria o envio para a API
      console.log("Dados da prescrição:", form);
      
      // Simulação de envio
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast({
        title: "Prescrição criada com sucesso",
        description: "A prescrição foi registrada e está pendente de revisão"
      });
      
      navigate(createPageUrl("PrescricoesClientes"));
    } catch (error) {
      console.error("Erro ao criar prescrição:", error);
      toast({
        title: "Erro ao criar prescrição",
        description: "Não foi possível salvar a prescrição. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatDate = (date) => {
    return format(date, "dd/MM/yyyy", { locale: pt });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate(createPageUrl("PrescricoesClientes"))}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Nova Prescrição</h1>
            <p className="text-gray-500">Registre uma nova prescrição médica</p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Informações Gerais</CardTitle>
            <CardDescription>Dados básicos da prescrição</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="numero">Número da Prescrição</Label>
                <Input 
                  id="numero" 
                  value={form.numero} 
                  readOnly 
                  className="bg-gray-50"
                />
                <p className="text-sm text-gray-500 mt-1">Número gerado automaticamente</p>
              </div>
              
              <div className="flex flex-col gap-1">
                <Label>Status</Label>
                <Badge className="w-fit bg-yellow-100 text-yellow-800">Pendente</Badge>
                <p className="text-sm text-gray-500 mt-1">A prescrição será criada com status pendente</p>
              </div>
              
              <div>
                <Label>Data de Emissão</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <Calendar className="mr-2 h-4 w-4" />
                      {form.data_emissao ? formatDate(form.data_emissao) : "Selecione uma data"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <CalendarComponent
                      mode="single"
                      selected={form.data_emissao}
                      onSelect={(date) => setForm(prev => ({ ...prev, data_emissao: date }))}
                      locale={pt}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div>
                <Label>Data de Validade</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <Calendar className="mr-2 h-4 w-4" />
                      {form.data_validade ? formatDate(form.data_validade) : "Selecione uma data"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <CalendarComponent
                      mode="single"
                      selected={form.data_validade}
                      onSelect={(date) => setForm(prev => ({ ...prev, data_validade: date }))}
                      locale={pt}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Paciente</CardTitle>
              <CardDescription>Selecione o paciente para esta prescrição</CardDescription>
            </CardHeader>
            <CardContent>
              {form.paciente ? (
                <div className="border rounded-lg p-4 flex justify-between items-start">
                  <div className="flex items-start gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary/10">
                        {form.paciente.nome_completo.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">{form.paciente.nome_completo}</h3>
                      <p className="text-sm text-gray-500">{form.paciente.cpf}</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {form.paciente.condicoes_medicas.map((condition, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {condition}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setShowPatientDialog(true)}
                  >
                    Trocar
                  </Button>
                </div>
              ) : (
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full h-20 border-dashed"
                  onClick={() => setShowPatientDialog(true)}
                >
                  <User className="mr-2 h-5 w-5" />
                  Selecionar Paciente
                </Button>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Médico</CardTitle>
              <CardDescription>Selecione o médico responsável pela prescrição</CardDescription>
            </CardHeader>
            <CardContent>
              {form.medico ? (
                <div className="border rounded-lg p-4 flex justify-between items-start">
                  <div className="flex items-start gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary/10">
                        {form.medico.nome.charAt(3)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">{form.medico.nome}</h3>
                      <p className="text-sm text-gray-500">{form.medico.crm}</p>
                      <Badge variant="outline" className="mt-1">
                        {form.medico.especialidade}
                      </Badge>
                    </div>
                  </div>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setShowDoctorDialog(true)}
                  >
                    Trocar
                  </Button>
                </div>
              ) : (
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full h-20 border-dashed"
                  onClick={() => setShowDoctorDialog(true)}
                >
                  <UserCheck className="mr-2 h-5 w-5" />
                  Selecionar Médico
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Produtos Prescritos</CardTitle>
                <CardDescription>Adicione os produtos e suas dosagens</CardDescription>
              </div>
              <Button 
                type="button" 
                onClick={handleAddProduct}
                className="gap-1"
              >
                <Plus className="h-4 w-4" />
                Adicionar Produto
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {form.produtos.map((produto, index) => (
                <div 
                  key={index} 
                  className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 border rounded-lg relative"
                >
                  {form.produtos.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 right-2 h-6 w-6 text-gray-400 hover:text-red-500"
                      onClick={() => handleRemoveProduct(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                  
                  <div className="md:col-span-2">
                    <Label>Produto</Label>
                    <Select
                      value={produto.produto?.id || ""}
                      onValueChange={(value) => {
                        const selectedProduct = mockProducts.find(p => p.id === value);
                        handleProductChange(index, 'produto', selectedProduct);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um produto" />
                      </SelectTrigger>
                      <SelectContent>
                        {mockProducts.map((prod) => (
                          <SelectItem key={prod.id} value={prod.id}>
                            {prod.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    {produto.produto && (
                      <div className="mt-2 flex flex-wrap gap-2">
                        <Badge variant="outline" className="text-xs">
                          CBD: {produto.produto.cbd_content}%
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          THC: {produto.produto.thc_content}%
                        </Badge>
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <Label>Dosagem</Label>
                    <Input
                      placeholder="Ex: 5 gotas, 2x ao dia"
                      value={produto.dosagem}
                      onChange={(e) => handleProductChange(index, 'dosagem', e.target.value)}
                    />
                  </div>
                  
                  <div>
                    <Label>Quantidade</Label>
                    <div className="flex items-center">
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="rounded-r-none"
                        onClick={() => handleProductChange(
                          index, 
                          'quantidade', 
                          Math.max(1, produto.quantidade - 1)
                        )}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <Input
                        type="number"
                        min="1"
                        className="rounded-none text-center"
                        value={produto.quantidade}
                        onChange={(e) => handleProductChange(
                          index,
                          'quantidade',
                          parseInt(e.target.value) || 1
                        )}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="rounded-l-none"
                        onClick={() => handleProductChange(
                          index,
                          'quantidade',
                          produto.quantidade + 1
                        )}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="md:col-span-3">
                    <Label>Duração do Tratamento</Label>
                    <Select
                      value={produto.duracao}
                      onValueChange={(value) => handleProductChange(index, 'duracao', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a duração" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30 dias">30 dias</SelectItem>
                        <SelectItem value="60 dias">60 dias</SelectItem>
                        <SelectItem value="90 dias">90 dias</SelectItem>
                        <SelectItem value="180 dias">180 dias (6 meses)</SelectItem>
                        <SelectItem value="365 dias">365 dias (1 ano)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Diagnóstico e Observações</CardTitle>
            <CardDescription>Informações clínicas adicionais</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="diagnostico">Diagnóstico</Label>
                <Input
                  id="diagnostico"
                  placeholder="Ex: Epilepsia Refratária, Dor Crônica"
                  value={form.diagnostico}
                  onChange={(e) => setForm(prev => ({ ...prev, diagnostico: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  placeholder="Observações adicionais sobre o tratamento"
                  rows={4}
                  value={form.observacoes}
                  onChange={(e) => setForm(prev => ({ ...prev, observacoes: e.target.value }))}
                />
              </div>
              
              <div>
                <Label>Documento da Prescrição</Label>
                <div className="mt-2">
                  <div className="flex items-center gap-2">
                    <Input
                      type="file"
                      id="prescription-file"
                      className="hidden"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={handleFileUpload}
                      disabled={isUploading}
                    />
                    <Label
                      htmlFor="prescription-file"
                      className="cursor-pointer inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2"
                    >
                      {isUploading ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-900 mr-2"></div>
                          Enviando...
                        </>
                      ) : (
                        <>
                          <Upload className="h-4 w-4 mr-2" />
                          Anexar Documento
                        </>
                      )}
                    </Label>
                    {form.file_url && (
                      <span className="text-green-600 text-sm flex items-center">
                        <CircleCheck className="h-4 w-4 mr-1" />
                        Documento anexado
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-500 mt-2">
                    <Info className="h-4 w-4 inline mr-1" />
                    Anexe a prescrição digitalizada ou escaneada (PDF, JPG, PNG)
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="flex justify-between items-center">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate(createPageUrl("PrescricoesClientes"))}
          >
            Cancelar
          </Button>
          
          <Button 
            type="submit" 
            className="gap-2"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                Salvando...
              </>
            ) : (
              <>
                <Save className="h-4 w-4" />
                Salvar Prescrição
              </>
            )}
          </Button>
        </div>
      </form>
      
      {/* Dialog para seleção de paciente */}
      <Dialog open={showPatientDialog} onOpenChange={setShowPatientDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Selecionar Paciente</DialogTitle>
            <DialogDescription>
              Busque e selecione um paciente para a prescrição
            </DialogDescription>
          </DialogHeader>
          
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar por nome ou CPF..."
              className="pl-10"
              value={searchPatientTerm}
              onChange={(e) => setSearchPatientTerm(e.target.value)}
            />
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {filteredPatients.length > 0 ? (
              <div className="space-y-2">
                {filteredPatients.map((patient) => (
                  <div
                    key={patient.id}
                    className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-gray-50"
                    onClick={() => handleSelectPatient(patient)}
                  >
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback className="bg-primary/10">
                          {patient.nome_completo.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{patient.nome_completo}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <span>{patient.cpf}</span>
                          <span>•</span>
                          <span>{patient.email}</span>
                        </div>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">Selecionar</Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <User className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                <p className="text-gray-500">Nenhum paciente encontrado</p>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPatientDialog(false)}>
              Cancelar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para seleção de médico */}
      <Dialog open={showDoctorDialog} onOpenChange={setShowDoctorDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Selecionar Médico</DialogTitle>
            <DialogDescription>
              Busque e selecione um médico para a prescrição
            </DialogDescription>
          </DialogHeader>
          
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar por nome ou CRM..."
              className="pl-10"
              value={searchDoctorTerm}
              onChange={(e) => setSearchDoctorTerm(e.target.value)}
            />
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {filteredDoctors.length > 0 ? (
              <div className="space-y-2">
                {filteredDoctors.map((doctor) => (
                  <div
                    key={doctor.id}
                    className="flex items-center justify-between p-3 border rounded-lg cursor-pointer hover:bg-gray-50"
                    onClick={() => handleSelectDoctor(doctor)}
                  >
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback className="bg-primary/10">
                          {doctor.nome.charAt(3)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{doctor.nome}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <span>{doctor.crm}</span>
                          <span>•</span>
                          <Badge variant="outline">{doctor.especialidade}</Badge>
                        </div>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">Selecionar</Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <User className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                <p className="text-gray-500">Nenhum médico encontrado</p>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDoctorDialog(false)}>
              Cancelar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}