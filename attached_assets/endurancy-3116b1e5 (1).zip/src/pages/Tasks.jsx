import React, { useState, useEffect } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Task } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import TaskForm from '../components/tasks/TaskForm';
import TaskDetail from '../components/tasks/TaskDetail';
import { User } from '@/api/entities';
import { Plus, Search, Filter, Calendar, Clock, AlertCircle, ListFilter } from 'lucide-react';

const COLUMN_COLORS = {
  backlog: {
    bg: 'bg-slate-100',
    border: 'border-slate-200',
    header: 'bg-slate-800 text-white',
    card: 'hover:border-slate-400'
  },
  todo: {
    bg: 'bg-indigo-50',
    border: 'border-indigo-100',
    header: 'bg-indigo-500 text-white',
    card: 'hover:border-indigo-400'
  },
  in_progress: {
    bg: 'bg-purple-50',
    border: 'border-purple-100',
    header: 'bg-purple-500 text-white',
    card: 'hover:border-purple-400'
  },
  review: {
    bg: 'bg-amber-50',
    border: 'border-amber-100',
    header: 'bg-amber-500 text-white',
    card: 'hover:border-amber-400'
  },
  done: {
    bg: 'bg-green-50',
    border: 'border-green-100',
    header: 'bg-green-500 text-white',
    card: 'hover:border-green-400'
  }
};

const PRIORITY_COLORS = {
  low: 'bg-blue-100 text-blue-800',
  medium: 'bg-yellow-100 text-yellow-800',
  high: 'bg-orange-100 text-orange-800',
  urgent: 'bg-red-100 text-red-800'
};

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedTask, setSelectedTask] = useState(null);
  const [showTaskDetail, setShowTaskDetail] = useState(false);
  const [filterPriority, setFilterPriority] = useState('all');
  const [filterAssignee, setFilterAssignee] = useState('all');
  const [users, setUsers] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load user data
      const userData = await User.me();
      setCurrentUser(userData);
      
      // Load tasks
      const tasksData = await Task.list();
      setTasks(tasksData);
      
      // Load users for filtering
      const usersData = await User.list();
      setUsers(usersData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTask = async (taskData) => {
    try {
      await Task.create(taskData);
      // Refresh tasks
      loadData();
    } catch (error) {
      console.error('Error creating task:', error);
    }
  };

  const handleTaskUpdate = async (updatedTask) => {
    // Update local state
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === updatedTask.id ? updatedTask : task
      )
    );
  };

  const handleTaskDelete = async (taskId) => {
    // Update local state
    setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
  };

  const onDragEnd = async (result) => {
    if (!result.destination) return;

    const { source, destination, draggableId } = result;

    if (source.droppableId === destination.droppableId && 
        source.index === destination.index) {
      return;
    }

    // Create updated task array with new status
    const tasksList = Array.from(tasks);
    const taskIndex = tasksList.findIndex(task => task.id === draggableId);
    
    if (taskIndex !== -1) {
      // Update task status
      const updatedTask = { ...tasksList[taskIndex], status: destination.droppableId };
      
      // Update local state immediately for responsive UI
      tasksList[taskIndex] = updatedTask;
      setTasks(tasksList);
      
      // Update in database
      try {
        await Task.update(draggableId, { status: destination.droppableId });
      } catch (error) {
        console.error('Error updating task status:', error);
        // Revert to original state if update fails
        loadData();
      }
    }
  };

  const getColumnTasks = (status) => {
    return tasks.filter(task => {
      // Base filter by status
      const statusMatch = task.status === status;
      
      // Filter by search term
      const searchMatch = searchTerm === '' || 
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.description?.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Filter by priority
      const priorityMatch = filterPriority === 'all' || task.priority === filterPriority;
      
      // Filter by assignee
      const assigneeMatch = filterAssignee === 'all' || 
                            (filterAssignee === 'me' && task.assigned_to === currentUser?.id) ||
                            task.assigned_to === filterAssignee;
      
      return statusMatch && searchMatch && priorityMatch && assigneeMatch;
    });
  };

  const handleTaskClick = (task) => {
    setSelectedTask(task);
    setShowTaskDetail(true);
  };

  const renderColumn = (title, status) => {
    const columnTasks = getColumnTasks(status);
    const colors = COLUMN_COLORS[status];

    return (
      <div className={`flex flex-col rounded-lg ${colors.bg} ${colors.border} border shadow-sm w-80 min-h-[500px]`}>
        <div className={`p-3 ${colors.header} rounded-t-lg flex justify-between items-center`}>
          <h3 className="font-semibold">{title}</h3>
          <Badge variant="outline" className="bg-white/20">
            {columnTasks.length}
          </Badge>
        </div>

        <Droppable droppableId={status}>
          {(provided) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className="flex-1 p-2 space-y-2 overflow-y-auto max-h-[calc(100vh-250px)]"
            >
              {columnTasks.map((task, index) => (
                <Draggable key={task.id} draggableId={task.id} index={index}>
                  {(provided, snapshot) => (
                    <Card
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      className={`p-3 ${colors.card} shadow-sm ${
                        snapshot.isDragging ? 'shadow-lg' : ''
                      } border-2 transition-all duration-200 cursor-pointer`}
                      onClick={() => handleTaskClick(task)}
                    >
                      <div className="space-y-2">
                        <div className="flex justify-between items-start">
                          <h4 className="font-medium text-sm">{task.title}</h4>
                          <Badge className={PRIORITY_COLORS[task.priority]}>
                            {task.priority}
                          </Badge>
                        </div>
                        
                        <p className="text-sm text-gray-600 line-clamp-2">
                          {task.description}
                        </p>

                        <div className="flex justify-between items-center pt-2">
                          {task.assigned_to && (
                            <Avatar className="w-6 h-6 border-2 border-white">
                              <AvatarFallback>
                                {users.find(u => u.id === task.assigned_to)?.full_name?.substring(0, 2).toUpperCase() || '??'}
                              </AvatarFallback>
                            </Avatar>
                          )}
                          
                          {task.due_date && (
                            <div className="flex items-center text-xs text-gray-500">
                              <Calendar className="w-3 h-3 mr-1" />
                              {new Date(task.due_date).toLocaleDateString()}
                              {new Date(task.due_date) < new Date() && task.status !== 'done' && (
                                <AlertCircle className="w-3 h-3 ml-1 text-red-500" />
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </Card>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-200px)]">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <h1 className="text-2xl font-bold">Quadro de Tarefas</h1>
        
        <div className="flex flex-col md:flex-row items-start md:items-center gap-3 w-full md:w-auto">
          <div className="flex items-center bg-white rounded-lg border px-3 py-1 w-full md:w-auto">
            <Search className="w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Buscar tarefas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="border-0 focus-visible:ring-0"
            />
          </div>
          
          <div className="flex gap-2 w-full md:w-auto">
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-full md:w-32">
                <SelectValue placeholder="Prioridade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="low">Baixa</SelectItem>
                <SelectItem value="medium">Média</SelectItem>
                <SelectItem value="high">Alta</SelectItem>
                <SelectItem value="urgent">Urgente</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={filterAssignee} onValueChange={setFilterAssignee}>
              <SelectTrigger className="w-full md:w-32">
                <SelectValue placeholder="Responsável" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="me">Minhas Tarefas</SelectItem>
                {users.map(user => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.full_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button onClick={() => setShowTaskForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Nova Tarefa
            </Button>
          </div>
        </div>
      </div>

      <DragDropContext onDragEnd={onDragEnd}>
        <div className="flex gap-4 overflow-x-auto pb-4">
          {renderColumn('Backlog', 'backlog')}
          {renderColumn('A Fazer', 'todo')}
          {renderColumn('Em Progresso', 'in_progress')}
          {renderColumn('Revisão', 'review')}
          {renderColumn('Concluído', 'done')}
        </div>
      </DragDropContext>

      {/* Task Form Dialog */}
      <TaskForm 
        open={showTaskForm} 
        onOpenChange={setShowTaskForm}
        onSubmit={handleCreateTask}
      />

      {/* Task Detail Dialog */}
      {selectedTask && (
        <TaskDetail
          taskId={selectedTask.id}
          open={showTaskDetail}
          onOpenChange={setShowTaskDetail}
          onTaskUpdate={handleTaskUpdate}
          onTaskDelete={handleTaskDelete}
        />
      )}
    </div>
  );
}