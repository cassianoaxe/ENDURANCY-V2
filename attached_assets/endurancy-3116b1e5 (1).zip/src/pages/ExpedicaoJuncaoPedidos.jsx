
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Box,
  BoxSelect,
  Search,
  Filter,
  ArrowRight,
  ArrowLeftRight,
  ArrowLeft,
  Plus,
  Check,
  X,
  MoreHorizontal,
  PackageCheck,
  Package,
  Clock,
  PackageOpen,
  Truck,
  CalendarCheck,
  Calendar,
  FileText,
  User,
  MapPin,
  ChevronDown,
  ChevronRight,
  Info,
  RefreshCw,
  AlertTriangle,
  Undo,
  ClipboardList,
  Eye
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from "@/components/ui/dropdown-menu";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Dados simulados para junção de pedidos
const mockOrders = [
  {
    id: "1",
    orderNumber: "PED-12345",
    customer: {
      name: "João Silva",
      id: "C0001",
      email: "joao@exemplo.com",
      phone: "(11) 99999-1234",
      address: "Rua das Flores, 123 - São Paulo, SP"
    },
    status: "em_preparacao",
    items: [
      { id: "1-1", name: "Óleo CBD 10%", code: "PROD001", quantity: 1, price: 150.00 },
      { id: "1-2", name: "Cápsulas CBD 20mg", code: "PROD004", quantity: 1, price: 120.00 }
    ],
    shipping_method: "SEDEX",
    shipping_cost: 25.00,
    total: 295.00,
    created_date: "2023-11-15T09:45:00",
    delivery_date: "2023-11-20",
    payment_method: "Cartão de Crédito",
    payment_status: "pago",
    notes: "Cliente solicitou embalagem discreta",
    eligible_for_merge: true
  },
  {
    id: "2",
    orderNumber: "PED-12346",
    customer: {
      name: "João Silva",
      id: "C0001",
      email: "joao@exemplo.com",
      phone: "(11) 99999-1234",
      address: "Rua das Flores, 123 - São Paulo, SP"
    },
    status: "em_preparacao",
    items: [
      { id: "2-1", name: "Pomada CBD", code: "PROD005", quantity: 1, price: 80.00 }
    ],
    shipping_method: "SEDEX",
    shipping_cost: 25.00,
    total: 105.00,
    created_date: "2023-11-15T10:30:00",
    delivery_date: "2023-11-20",
    payment_method: "Cartão de Crédito",
    payment_status: "pago",
    notes: "",
    eligible_for_merge: true
  },
  {
    id: "3",
    orderNumber: "PED-12347",
    customer: {
      name: "Maria Oliveira",
      id: "C0002",
      email: "maria@exemplo.com",
      phone: "(11) 99999-5678",
      address: "Av. Paulista, 1000 - São Paulo, SP"
    },
    status: "em_preparacao",
    items: [
      { id: "3-1", name: "Óleo CBD 20%", code: "PROD002", quantity: 1, price: 220.00 },
      { id: "3-2", name: "Óleo CBD 5%", code: "PROD003", quantity: 1, price: 120.00 }
    ],
    shipping_method: "PAC",
    shipping_cost: 20.00,
    total: 360.00,
    created_date: "2023-11-15T11:15:00",
    delivery_date: "2023-11-24",
    payment_method: "Boleto",
    payment_status: "pago",
    notes: "",
    eligible_for_merge: true
  },
  {
    id: "4",
    orderNumber: "PED-12348",
    customer: {
      name: "Maria Oliveira",
      id: "C0002",
      email: "maria@exemplo.com",
      phone: "(11) 99999-5678",
      address: "Av. Paulista, 1000 - São Paulo, SP"
    },
    status: "aguardando_separacao",
    items: [
      { id: "4-1", name: "Camiseta Associação", code: "PROD006", quantity: 1, price: 60.00 }
    ],
    shipping_method: "PAC",
    shipping_cost: 20.00,
    total: 80.00,
    created_date: "2023-11-15T14:20:00",
    delivery_date: "2023-11-24",
    payment_method: "Boleto",
    payment_status: "pago",
    notes: "",
    eligible_for_merge: true
  },
  {
    id: "5",
    orderNumber: "PED-12349",
    customer: {
      name: "Carlos Santos",
      id: "C0003",
      email: "carlos@exemplo.com",
      phone: "(21) 99999-9876",
      address: "Rua dos Pinheiros, 500 - Rio de Janeiro, RJ"
    },
    status: "separado",
    items: [
      { id: "5-1", name: "Óleo CBD 30%", code: "PROD007", quantity: 1, price: 290.00 }
    ],
    shipping_method: "SEDEX",
    shipping_cost: 30.00,
    total: 320.00,
    created_date: "2023-11-15T08:30:00",
    delivery_date: "2023-11-19",
    payment_method: "PIX",
    payment_status: "pago",
    notes: "Enviar documentação junto",
    eligible_for_merge: false
  }
];

// Dados simulados de junções já realizadas
const mockMergedOrders = [
  {
    id: "M001",
    mergeNumber: "JUN-0001",
    status: "em_processamento",
    created_date: "2023-11-15T15:30:00",
    orders: [
      {
        id: "6",
        orderNumber: "PED-12330",
        customer: "Ana Costa",
        status: "em_preparacao",
        items_count: 2,
        shipping_method: "SEDEX"
      },
      {
        id: "7",
        orderNumber: "PED-12331",
        customer: "Ana Costa",
        status: "em_preparacao",
        items_count: 1,
        shipping_method: "SEDEX"
      }
    ],
    shipping_method: "SEDEX",
    created_by: "Ana Silva",
    notes: "Junção para mesma cliente em mesmo endereço",
    shipping_cost_saved: 25.00
  },
  {
    id: "M002",
    mergeNumber: "JUN-0002",
    status: "concluido",
    created_date: "2023-11-14T16:45:00",
    orders: [
      {
        id: "8",
        orderNumber: "PED-12325",
        customer: "Roberto Oliveira",
        status: "enviado",
        items_count: 3,
        shipping_method: "PAC"
      },
      {
        id: "9",
        orderNumber: "PED-12326",
        customer: "Roberto Oliveira",
        status: "enviado",
        items_count: 1,
        shipping_method: "PAC"
      }
    ],
    shipping_method: "PAC",
    created_by: "Carlos Mendes",
    notes: "Junção para mesmo cliente",
    shipping_cost_saved: 20.00
  }
];

export default function ExpedicaoJuncaoPedidos() {
  const [mergeCandidates, setMergeCandidates] = useState([]);
  const [mergedOrders, setMergedOrders] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [customerFilter, setCustomerFilter] = useState("");
  const [selectedOrders, setSelectedOrders] = useState([]);
  const [showMergeDialog, setShowMergeDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [selectedMerge, setSelectedMerge] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("candidates");
  const [newMergeNotes, setNewMergeNotes] = useState("");

  // Carregar dados
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        // Simulando chamada à API
        setTimeout(() => {
          // Filtrando pedidos elegíveis para junção
          const eligible = mockOrders.filter(order => 
            order.eligible_for_merge && 
            ['em_preparacao', 'aguardando_separacao'].includes(order.status)
          );
          
          setMergeCandidates(eligible);
          setMergedOrders(mockMergedOrders);
          setIsLoading(false);
        }, 500);
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  // Filtrar os candidatos à junção com base na busca e filtro de cliente
  const filteredCandidates = mergeCandidates.filter(order => {
    const matchesSearch = searchTerm === "" || 
      order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCustomer = customerFilter === "" || 
      order.customer.id === customerFilter;
    
    return matchesSearch && matchesCustomer;
  });

  // Agrupar pedidos por cliente
  const ordersByCustomer = filteredCandidates.reduce((acc, order) => {
    if (!acc[order.customer.id]) {
      acc[order.customer.id] = {
        customer: order.customer,
        orders: []
      };
    }
    acc[order.customer.id].orders.push(order);
    return acc;
  }, {});

  // Verificar se há mais de um pedido para o mesmo cliente (candidatos à junção)
  const customersWithMultipleOrders = Object.values(ordersByCustomer)
    .filter(group => group.orders.length > 1);

  // Verificar se os pedidos selecionados são do mesmo cliente
  const areSelectedOrdersFromSameCustomer = () => {
    if (selectedOrders.length < 2) return false;
    
    const firstCustomerId = selectedOrders[0].customer.id;
    return selectedOrders.every(order => order.customer.id === firstCustomerId);
  };

  // Verificar se os pedidos selecionados têm o mesmo método de envio
  const doSelectedOrdersHaveSameShippingMethod = () => {
    if (selectedOrders.length < 2) return false;
    
    const firstMethod = selectedOrders[0].shipping_method;
    return selectedOrders.every(order => order.shipping_method === firstMethod);
  };

  // Calcular economia em frete
  const calculateShippingSavings = () => {
    if (selectedOrders.length < 2) return 0;
    
    // Somamos o frete de todos os pedidos exceto um (que será mantido)
    return selectedOrders.slice(1).reduce((total, order) => {
      return total + order.shipping_cost;
    }, 0);
  };

  // Toggle seleção de pedido
  const toggleOrderSelection = (order) => {
    if (selectedOrders.some(selected => selected.id === order.id)) {
      setSelectedOrders(selectedOrders.filter(selected => selected.id !== order.id));
    } else {
      setSelectedOrders([...selectedOrders, order]);
    }
  };

  // Limpar seleção de pedidos
  const clearSelection = () => {
    setSelectedOrders([]);
  };

  // Criar junção de pedidos
  const createMerge = () => {
    if (selectedOrders.length < 2) return;
    
    const newMerge = {
      id: `M${Math.floor(Math.random() * 1000)}`,
      mergeNumber: `JUN-${String(mergedOrders.length + 1).padStart(4, '0')}`,
      status: "em_processamento",
      created_date: new Date().toISOString(),
      orders: selectedOrders.map(order => ({
        id: order.id,
        orderNumber: order.orderNumber,
        customer: order.customer.name,
        status: order.status,
        items_count: order.items.length,
        shipping_method: order.shipping_method
      })),
      shipping_method: selectedOrders[0].shipping_method,
      created_by: "Usuário Atual",
      notes: newMergeNotes,
      shipping_cost_saved: calculateShippingSavings()
    };
    
    setMergedOrders([newMerge, ...mergedOrders]);
    
    // Atualizar status dos pedidos originais
    const updatedCandidates = mergeCandidates.map(order => {
      if (selectedOrders.some(selected => selected.id === order.id)) {
        return { ...order, status: "em_juncao", eligible_for_merge: false };
      }
      return order;
    });
    
    setMergeCandidates(updatedCandidates);
    setSelectedOrders([]);
    setNewMergeNotes("");
    setShowMergeDialog(false);
    setActiveTab("history");
  };

  // Formatar data
  const formatDate = (dateString) => {
    const options = { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' };
    return new Date(dateString).toLocaleString('pt-BR', options);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Junção de Pedidos</h1>
          <p className="text-gray-500 mt-1">
            Junte pedidos do mesmo cliente para economizar em frete e otimizar a expedição
          </p>
        </div>
        <Button
          onClick={() => setActiveTab("candidates")}
          disabled={activeTab === "candidates" || selectedOrders.length === 0}
          className="bg-green-600 hover:bg-green-700 text-white"
        >
          <BoxSelect className="mr-2 h-4 w-4" />
          {selectedOrders.length > 0 ? `Juntar ${selectedOrders.length} Pedidos` : "Nova Junção"}
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="candidates">Candidatos à Junção</TabsTrigger>
          <TabsTrigger value="history">Histórico de Junções</TabsTrigger>
        </TabsList>
        
        <TabsContent value="candidates" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <CardTitle>Pedidos Elegíveis para Junção</CardTitle>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Buscar por pedido ou cliente..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-full sm:w-[300px]"
                    />
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="icon">
                        <Filter className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <DropdownMenuLabel>Filtrar por Cliente</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => setCustomerFilter("")}>
                        Todos os Clientes
                      </DropdownMenuItem>
                      {Object.values(ordersByCustomer).map(group => (
                        <DropdownMenuItem 
                          key={group.customer.id}
                          onClick={() => setCustomerFilter(group.customer.id)}
                        >
                          {group.customer.name} ({group.orders.length} pedidos)
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : customersWithMultipleOrders.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <BoxSelect className="h-12 w-12 text-gray-400 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">Nenhum pedido elegível para junção</h3>
                  <p className="text-gray-500 mt-1 max-w-md">
                    {searchTerm || customerFilter 
                      ? "Nenhum resultado encontrado para os filtros aplicados." 
                      : "Não há pedidos do mesmo cliente que possam ser juntados no momento."}
                  </p>
                  {(searchTerm || customerFilter) && (
                    <Button
                      variant="outline"
                      className="mt-4"
                      onClick={() => {
                        setSearchTerm("");
                        setCustomerFilter("");
                      }}
                    >
                      Limpar filtros
                    </Button>
                  )}
                </div>
              ) : (
                <div className="space-y-6">
                  {customersWithMultipleOrders.map(group => (
                    <Card key={group.customer.id} className="overflow-hidden">
                      <CardHeader className="bg-gray-50 dark:bg-gray-800 py-3">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <User className="h-5 w-5 text-gray-500" />
                            <div>
                              <h3 className="text-md font-semibold">{group.customer.name}</h3>
                              <p className="text-sm text-gray-500">{group.customer.email} • {group.customer.phone}</p>
                            </div>
                          </div>
                          <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
                            {group.orders.length} pedidos disponíveis
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="p-0">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-[50px]"></TableHead>
                              <TableHead>Número</TableHead>
                              <TableHead>Data</TableHead>
                              <TableHead>Itens</TableHead>
                              <TableHead>Frete</TableHead>
                              <TableHead>Total</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead className="text-right">Ações</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {group.orders.map((order) => (
                              <TableRow key={order.id} className={selectedOrders.some(selected => selected.id === order.id) ? "bg-green-50" : ""}>
                                <TableCell>
                                  <Checkbox
                                    checked={selectedOrders.some(selected => selected.id === order.id)}
                                    onCheckedChange={() => toggleOrderSelection(order)}
                                  />
                                </TableCell>
                                <TableCell className="font-medium">{order.orderNumber}</TableCell>
                                <TableCell>{formatDate(order.created_date)}</TableCell>
                                <TableCell>{order.items.length} {order.items.length === 1 ? 'item' : 'itens'}</TableCell>
                                <TableCell>{order.shipping_method} (R$ {order.shipping_cost.toFixed(2)})</TableCell>
                                <TableCell>R$ {order.total.toFixed(2)}</TableCell>
                                <TableCell>
                                  <Badge variant="outline" className="capitalize">
                                    {order.status.replace(/_/g, ' ')}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {selectedOrders.length > 0 && (
                    <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-4 shadow-md z-10">
                      <div className="max-w-7xl mx-auto flex justify-between items-center">
                        <div className="flex items-center gap-4">
                          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                            {selectedOrders.length} {selectedOrders.length === 1 ? 'pedido selecionado' : 'pedidos selecionados'}
                          </Badge>
                          
                          {!areSelectedOrdersFromSameCustomer() && (
                            <Alert variant="destructive" className="p-2 max-w-lg">
                              <AlertTriangle className="h-4 w-4" />
                              <AlertDescription>
                                Somente pedidos do mesmo cliente podem ser juntados.
                              </AlertDescription>
                            </Alert>
                          )}
                          
                          {areSelectedOrdersFromSameCustomer() && !doSelectedOrdersHaveSameShippingMethod() && (
                            <Alert variant="destructive" className="p-2 max-w-lg">
                              <AlertTriangle className="h-4 w-4" />
                              <AlertDescription>
                                Os pedidos precisam ter o mesmo método de envio.
                              </AlertDescription>
                            </Alert>
                          )}
                          
                          {areSelectedOrdersFromSameCustomer() && doSelectedOrdersHaveSameShippingMethod() && (
                            <Alert className="p-2 bg-green-50 text-green-800 border-green-200">
                              <Info className="h-4 w-4" />
                              <AlertDescription>
                                Economia estimada: R$ {calculateShippingSavings().toFixed(2)} em frete
                              </AlertDescription>
                            </Alert>
                          )}
                        </div>
                        
                        <div className="flex gap-2">
                          <Button variant="outline" onClick={clearSelection}>
                            Cancelar
                          </Button>
                          <Button 
                            className="bg-green-600 hover:bg-green-700 text-white"
                            disabled={selectedOrders.length < 2 || !areSelectedOrdersFromSameCustomer() || !doSelectedOrdersHaveSameShippingMethod()}
                            onClick={() => setShowMergeDialog(true)}
                          >
                            <BoxSelect className="mr-2 h-4 w-4" />
                            Juntar Pedidos
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <CardTitle>Histórico de Junções</CardTitle>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Buscar junções..."
                    className="pl-10 w-full sm:w-[300px]"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : mergedOrders.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <BoxSelect className="h-12 w-12 text-gray-400 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">Nenhuma junção encontrada</h3>
                  <p className="text-gray-500 mt-1 max-w-md">
                    Não há histórico de junções de pedidos.
                  </p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Número</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead>Pedidos</TableHead>
                        <TableHead>Cliente</TableHead>
                        <TableHead>Frete</TableHead>
                        <TableHead>Economia</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mergedOrders.map((merge) => (
                        <TableRow key={merge.id}>
                          <TableCell className="font-medium">{merge.mergeNumber}</TableCell>
                          <TableCell>{formatDate(merge.created_date)}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              {merge.orders.length}
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-6 w-6">
                                    <Info className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                  <DropdownMenuLabel>Pedidos Incluídos</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  {merge.orders.map((order) => (
                                    <DropdownMenuItem key={order.id}>
                                      {order.orderNumber}
                                    </DropdownMenuItem>
                                  ))}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </TableCell>
                          <TableCell>{merge.orders[0].customer}</TableCell>
                          <TableCell>{merge.shipping_method}</TableCell>
                          <TableCell className="text-green-600">R$ {merge.shipping_cost_saved.toFixed(2)}</TableCell>
                          <TableCell>
                            <Badge 
                              className={
                                merge.status === "em_processamento" ? "bg-blue-100 text-blue-800" : 
                                merge.status === "concluido" ? "bg-green-100 text-green-800" : 
                                "bg-gray-100 text-gray-800"
                              }
                            >
                              {merge.status.replace(/_/g, ' ')}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem 
                                  onClick={() => {
                                    setSelectedMerge(merge);
                                    setShowDetailsDialog(true);
                                  }}
                                >
                                  <Eye className="h-4 w-4 mr-2" />
                                  Ver detalhes
                                </DropdownMenuItem>
                                {merge.status === "em_processamento" && (
                                  <DropdownMenuItem>
                                    <ArrowRight className="h-4 w-4 mr-2" />
                                    Finalizar junção
                                  </DropdownMenuItem>
                                )}
                                {merge.status === "em_processamento" && (
                                  <>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem className="text-red-600">
                                      <Undo className="h-4 w-4 mr-2" />
                                      Reverter junção
                                    </DropdownMenuItem>
                                  </>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modal de confirmação de junção */}
      <Dialog open={showMergeDialog} onOpenChange={setShowMergeDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Confirmar Junção de Pedidos</DialogTitle>
            <DialogDescription>
              Você está prestes a juntar {selectedOrders.length} pedidos do cliente {selectedOrders[0]?.customer.name}.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Pedido</TableHead>
                    <TableHead>Itens</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Frete</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedOrders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium">{order.orderNumber}</TableCell>
                      <TableCell>{order.items.length} {order.items.length === 1 ? 'item' : 'itens'}</TableCell>
                      <TableCell>R$ {(order.total - order.shipping_cost).toFixed(2)}</TableCell>
                      <TableCell>R$ {order.shipping_cost.toFixed(2)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            
            <Alert className="bg-green-50 text-green-800 border-green-200">
              <Info className="h-4 w-4" />
              <AlertDescription>
                A junção destes pedidos resultará em uma economia de R$ {calculateShippingSavings().toFixed(2)} em frete.
              </AlertDescription>
            </Alert>
            
            <div className="space-y-2">
              <Label htmlFor="notes">Observações sobre a junção</Label>
              <Textarea
                id="notes"
                placeholder="Adicione observações sobre esta junção..."
                value={newMergeNotes}
                onChange={(e) => setNewMergeNotes(e.target.value)}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMergeDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={createMerge} className="bg-green-600 hover:bg-green-700 text-white">
              <BoxSelect className="mr-2 h-4 w-4" />
              Confirmar Junção
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de detalhes da junção */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="sm:max-w-[600px]">
          {selectedMerge && (
            <>
              <DialogHeader>
                <DialogTitle>Detalhes da Junção {selectedMerge.mergeNumber}</DialogTitle>
                <DialogDescription>
                  Criada em {formatDate(selectedMerge.created_date)} por {selectedMerge.created_by}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Status</p>
                    <Badge 
                      className={
                        selectedMerge.status === "em_processamento" ? "bg-blue-100 text-blue-800 mt-1" : 
                        selectedMerge.status === "concluido" ? "bg-green-100 text-green-800 mt-1" : 
                        "bg-gray-100 text-gray-800 mt-1"
                      }
                    >
                      {selectedMerge.status.replace(/_/g, ' ')}
                    </Badge>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500">Cliente</p>
                    <p className="mt-1 font-medium">{selectedMerge.orders[0].customer}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500">Método de Envio</p>
                    <p className="mt-1">{selectedMerge.shipping_method}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500">Economia em Frete</p>
                    <p className="mt-1 text-green-600">R$ {selectedMerge.shipping_cost_saved.toFixed(2)}</p>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Observações</p>
                  <p className="mt-1">{selectedMerge.notes || "Nenhuma observação adicionada."}</p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500 mb-2">Pedidos Incluídos</p>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Número</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Itens</TableHead>
                          <TableHead className="text-right">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedMerge.orders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-medium">{order.orderNumber}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className="capitalize">
                                {order.status.replace(/_/g, ' ')}
                              </Badge>
                            </TableCell>
                            <TableCell>{order.items_count} {order.items_count === 1 ? 'item' : 'itens'}</TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="icon">
                                <Eye className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowDetailsDialog(false)}>
                  Fechar
                </Button>
                {selectedMerge.status === "em_processamento" && (
                  <Button variant="destructive">
                    <Undo className="mr-2 h-4 w-4" />
                    Reverter Junção
                  </Button>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
