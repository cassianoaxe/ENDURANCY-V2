
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Video,
  Mic,
  MicOff,
  VideoOff,
  Phone,
  MessageSquare,
  Share2,
  FileText,
  Settings,
  Clock,
  Calendar,
  AlertTriangle,
  FilePlus,
  User,
  HelpCircle,
  Loader,
  Camera,
  MoreVertical,
  Clipboard,
  FileUp,
  Save,
  Trash2,
  Plus,
  BrainCircuit
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Spinner } from '@/components/ui/spinner';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { 
  Alert, 
  AlertDescription, 
  AlertTitle 
} from '@/components/ui/alert';
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from '@/components/ui/tooltip';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { toast } from '@/components/ui/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { format, parseISO, isAfter, isBefore, addMinutes } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { InvokeLLM } from '@/api/integrations';

export default function TelemedicinaMedico() {
  const navigate = useNavigate();
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);
  const consultaId = urlParams.get('id');
  
  const [loading, setLoading] = useState(true);
  const [consulta, setConsulta] = useState(null);
  const [paciente, setPaciente] = useState(null);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [activeTab, setActiveTab] = useState('resumo');
  const [notas, setNotas] = useState('');
  const [showPrescriptionDialog, setShowPrescriptionDialog] = useState(false);
  const [prescription, setPrescription] = useState({
    produtos: [{ id: '', nome: '', dosagem: '', frequencia: '', duracao: '', quantidade: '' }],
    observacoes: ''
  });
  const [showEndDialog, setShowEndDialog] = useState(false);
  const [meetingTime, setMeetingTime] = useState(0);
  const [iaAssistente, setIaAssistente] = useState(null);
  const [iaIsLoading, setIaIsLoading] = useState(false);
  const [iaActive, setIaActive] = useState(false);

  useEffect(() => {
    loadConsultaData();
    
    const timer = setInterval(() => {
      setMeetingTime(prev => prev + 1);
    }, 1000);
    
    return () => clearInterval(timer);
  }, [consultaId]);

  const loadConsultaData = async () => {
    setLoading(true);
    try {
      setTimeout(() => {
        const mockConsulta = {
          id: consultaId,
          paciente_id: 'pac1',
          data_hora: new Date().toISOString(),
          tipo_consulta: 'telemedicina',
          status: 'em_andamento',
          duracao: 30,
          motivo: 'Controle de dosagem - Cannabis medicinal',
          valor: 250,
          link_telemedicina: 'https://meet.example.com/abc123'
        };
        
        const mockPaciente = {
          id: 'pac1',
          nome_completo: 'Maria Silva',
          foto_url: '',
          idade: 45,
          diagnostico: 'Dor crônica, ansiedade',
          data_nascimento: '1978-05-10',
          telefone: '(11) 98765-4321',
          email: 'maria.silva@exemplo.com',
          ultima_consulta: '2023-09-15T14:30:00Z',
          medicacoes_atuais: [
            {
              nome: 'Óleo de CBD 5%',
              dosagem: '0.5ml',
              frequencia: '2x ao dia',
              data_inicio: '2023-08-01'
            }
          ],
          historico: {
            diagnosticos_anteriores: ['Transtorno de ansiedade generalizada', 'Enxaqueca crônica'],
            alergias: ['Penicilina'],
            cirurgias: ['Apendicectomia (2010)'],
            condicoes_cronicas: ['Fibromialgia', 'Insônia']
          },
          historico_consultas: [
            {
              data: '2023-09-15T14:30:00Z',
              medico: 'Dr. Roberto Oliveira',
              tipo: 'telemedicina',
              notas: 'Paciente relatou melhora na qualidade do sono. Mantida dosagem atual.',
              prescricoes: ['Óleo de CBD 5% - 0.5ml, 2x ao dia']
            },
            {
              data: '2023-08-01T10:15:00Z',
              medico: 'Dra. Ana Silva',
              tipo: 'presencial',
              notas: 'Início do tratamento com cannabis medicinal. Paciente bem orientada quanto aos efeitos.',
              prescricoes: ['Óleo de CBD 5% - 0.3ml, 2x ao dia']
            }
          ]
        };
        
        setConsulta(mockConsulta);
        setPaciente(mockPaciente);
        setLoading(false);
        
        setChatMessages([
          {
            sender: 'system',
            message: 'Consulta iniciada. Você pode usar o chat para comunicação durante a sessão.',
            time: new Date()
          }
        ]);
      }, 2000);
    } catch (error) {
      console.error("Erro ao carregar dados da consulta:", error);
      toast({
        title: "Erro ao carregar consulta",
        description: "Não foi possível carregar os dados da consulta. Tente novamente.",
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  const sendMessage = () => {
    if (!newMessage.trim()) return;
    
    const message = {
      sender: 'doctor',
      message: newMessage,
      time: new Date()
    };
    
    setChatMessages([...chatMessages, message]);
    setNewMessage('');
    
    setTimeout(() => {
      const reply = {
        sender: 'patient',
        message: 'Entendi, obrigado pela explicação.',
        time: new Date()
      };
      setChatMessages(prev => [...prev, reply]);
    }, 3000);
  };

  const endConsultation = () => {
    toast({
      title: "Consulta finalizada",
      description: "A consulta foi finalizada com sucesso."
    });
    navigate(createPageUrl("ConsultaVirtual"));
  };

  const toggleVideo = () => {
    setIsVideoOn(!isVideoOn);
  };

  const toggleMic = () => {
    setIsMicOn(!isMicOn);
  };

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  const addProductField = () => {
    setPrescription({
      ...prescription,
      produtos: [...prescription.produtos, { id: '', nome: '', dosagem: '', frequencia: '', duracao: '', quantidade: '' }]
    });
  };

  const removeProductField = (index) => {
    const updatedProducts = [...prescription.produtos];
    updatedProducts.splice(index, 1);
    setPrescription({
      ...prescription,
      produtos: updatedProducts
    });
  };

  const handleProductChange = (index, field, value) => {
    const updatedProducts = [...prescription.produtos];
    updatedProducts[index][field] = value;
    setPrescription({
      ...prescription,
      produtos: updatedProducts
    });
  };

  const savePrescription = () => {
    toast({
      title: "Prescrição salva",
      description: "A prescrição foi salva com sucesso."
    });
    setShowPrescriptionDialog(false);
  };

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const askIA = async () => {
    setIaIsLoading(true);
    setIaActive(true);
    
    try {
      setTimeout(async () => {
        try {
          const simulatedResponse = {
            sugestoes: [
              "Baseado no histórico da paciente, considere aumentar dosagem noturna do óleo CBD para melhorar qualidade do sono",
              "A paciente tem apresentado melhora gradual dos sintomas de ansiedade, mas os episódios de dor crônica persistem",
              "Recomendo avaliar a inclusão de um produto com proporção equilibrada de CBD/THC para potencializar o efeito analgésico",
              "É importante verificar a interação do tratamento atual com outros medicamentos para ansiedade que a paciente possa estar tomando"
            ],
            analise: "A paciente Maria Silva apresenta quadro de dor crônica e ansiedade, com histórico de fibromialgia e insônia. O tratamento atual com Óleo de CBD 5% demonstrou melhora no quadro de sono, mas os sintomas de dor possivelmente requerem ajuste terapêutico. A evolução do tratamento mostra resposta positiva, com aumento gradual da dosagem (de 0.3ml para 0.5ml 2x ao dia) em um período de aproximadamente 1,5 mês."
          };
          
          setIaAssistente(simulatedResponse);
          setIaIsLoading(false);
        } catch (error) {
          console.error("Erro ao processar IA:", error);
          toast({
            title: "Erro na assistência de IA",
            description: "Não foi possível processar a solicitação de IA.",
            variant: "destructive"
          });
          setIaIsLoading(false);
        }
      }, 3000);
    } catch (error) {
      console.error("Erro na IA:", error);
      setIaIsLoading(false);
      toast({
        title: "Erro na assistência de IA",
        description: "Não foi possível processar a solicitação de IA.",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[80vh]">
        <Spinner size="large" />
        <p className="mt-4 text-gray-500 dark:text-gray-400">Carregando consulta...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-130px)]">
      <div className="bg-green-600 dark:bg-green-700 text-white p-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-white hover:bg-green-700 dark:hover:bg-green-800"
            onClick={() => navigate(createPageUrl("ConsultaVirtual"))}
          >
            <HelpCircle className="h-5 w-5" />
          </Button>
          <h1 className="font-medium">Consulta Virtual | {paciente?.nome_completo}</h1>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-white text-green-700">
            <Clock className="h-3 w-3 mr-1" />
            {formatTime(meetingTime)}
          </Badge>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-white hover:bg-green-700 dark:hover:bg-green-800"
            onClick={() => setShowEndDialog(true)}
          >
            Finalizar
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <div className={`flex-1 bg-gray-900 ${isChatOpen ? 'hidden md:block md:flex-1' : 'flex-[3]'} relative`}>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white">
              <Camera className="h-16 w-16 mx-auto text-gray-500 mb-4" />
              <p className="text-lg font-medium mb-2">Câmera do paciente desativada</p>
              <p className="text-sm text-gray-400">Aguardando conexão com o paciente...</p>
            </div>
          </div>
          
          <div className="absolute bottom-4 right-4 w-48 h-36 bg-gray-800 border border-gray-700 rounded-lg overflow-hidden shadow-lg">
            <div className="h-full flex items-center justify-center">
              <div className="text-center text-white">
                <Camera className="h-8 w-8 mx-auto text-gray-600 mb-2" />
                <p className="text-xs text-gray-400">Minha câmera {isVideoOn ? 'ativada' : 'desativada'}</p>
              </div>
            </div>
          </div>
          
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2 bg-gray-800/70 p-2 rounded-full">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={`rounded-full ${!isMicOn ? 'bg-red-600 text-white' : 'text-white'}`}
                    onClick={toggleMic}
                  >
                    {isMicOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{isMicOn ? 'Desativar microfone' : 'Ativar microfone'}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={`rounded-full ${!isVideoOn ? 'bg-red-600 text-white' : 'text-white'}`}
                    onClick={toggleVideo}
                  >
                    {isVideoOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{isVideoOn ? 'Desativar câmera' : 'Ativar câmera'}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="rounded-full text-white"
                    onClick={() => setShowPrescriptionDialog(true)}
                  >
                    <FileText className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Nova prescrição</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={`rounded-full text-white ${isChatOpen ? 'bg-green-600' : ''}`}
                    onClick={toggleChat}
                  >
                    <MessageSquare className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{isChatOpen ? 'Fechar chat' : 'Abrir chat'}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="rounded-full text-white"
                    onClick={() => setShowEndDialog(true)}
                  >
                    <Phone className="h-5 w-5 rotate-135" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Encerrar consulta</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>

        <div className={`bg-white dark:bg-gray-800 ${isChatOpen ? 'flex-1' : 'hidden md:block md:w-96'} border-l border-gray-200 dark:border-gray-700 flex flex-col`}>
          <Tabs defaultValue="resumo" value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <div className="border-b border-gray-200 dark:border-gray-700">
              <TabsList className="w-full justify-start p-0">
                <TabsTrigger value="resumo" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-green-600 dark:data-[state=active]:border-green-500">
                  Resumo
                </TabsTrigger>
                <TabsTrigger value="chat" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-green-600 dark:data-[state=active]:border-green-500">
                  Chat
                </TabsTrigger>
                <TabsTrigger value="notas" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-green-600 dark:data-[state=active]:border-green-500">
                  Notas
                </TabsTrigger>
                <TabsTrigger value="ia" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-green-600 dark:data-[state=active]:border-green-500">
                  IA
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="resumo" className="flex-1 overflow-auto p-4 space-y-6 mt-0">
              <div className="flex items-center gap-3">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100 text-lg">
                    {paciente?.nome_completo.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="text-xl font-bold">{paciente?.nome_completo}</h2>
                  <p className="text-gray-500 dark:text-gray-400">{paciente?.idade} anos • {format(parseISO(paciente?.data_nascimento), "dd/MM/yyyy", {locale: ptBR})}</p>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-2">Diagnóstico</h3>
                <p>{paciente?.diagnostico}</p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-2">Medicação atual</h3>
                <div className="space-y-2">
                  {paciente?.medicacoes_atuais.map((med, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <p className="font-medium">{med.nome}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {med.dosagem}, {med.frequencia} • Início: {format(parseISO(med.data_inicio), "dd/MM/yyyy", {locale: ptBR})}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-2">Histórico médico</h3>
                <div className="space-y-3">
                  <div>
                    <p className="font-medium text-sm text-gray-500 dark:text-gray-400">DIAGNÓSTICOS ANTERIORES</p>
                    <ul className="list-disc list-inside">
                      {paciente?.historico.diagnosticos_anteriores.map((diag, index) => (
                        <li key={index}>{diag}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <p className="font-medium text-sm text-gray-500 dark:text-gray-400">ALERGIAS</p>
                    <ul className="list-disc list-inside">
                      {paciente?.historico.alergias.map((alergia, index) => (
                        <li key={index}>{alergia}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <p className="font-medium text-sm text-gray-500 dark:text-gray-400">CONDIÇÕES CRÔNICAS</p>
                    <ul className="list-disc list-inside">
                      {paciente?.historico.condicoes_cronicas.map((cond, index) => (
                        <li key={index}>{cond}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-2">Última consulta</h3>
                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-medium">
                      {format(parseISO(paciente?.historico_consultas[0].data), "dd/MM/yyyy", {locale: ptBR})}
                    </p>
                    <Badge variant="outline">
                      {paciente?.historico_consultas[0].tipo === 'telemedicina' ? 'Telemedicina' : 'Presencial'}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                    {paciente?.historico_consultas[0].medico}
                  </p>
                  <p className="text-sm mb-2">{paciente?.historico_consultas[0].notas}</p>
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">PRESCRIÇÕES:</p>
                    <ul className="list-disc list-inside text-sm">
                      {paciente?.historico_consultas[0].prescricoes.map((presc, index) => (
                        <li key={index}>{presc}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="chat" className="flex-1 flex flex-col overflow-hidden mt-0 pt-0">
              <div className="flex-1 overflow-auto p-4 space-y-4">
                {chatMessages.map((msg, index) => (
                  <div 
                    key={index} 
                    className={`flex ${msg.sender === 'doctor' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div 
                      className={`max-w-[80%] p-3 rounded-lg ${
                        msg.sender === 'doctor' 
                          ? 'bg-green-100 dark:bg-green-900' 
                          : msg.sender === 'system'
                            ? 'bg-gray-100 dark:bg-gray-700 text-center w-full'
                            : 'bg-blue-100 dark:bg-blue-900'
                      }`}
                    >
                      <p>{msg.message}</p>
                      <p className="text-xs text-right mt-1 text-gray-500 dark:text-gray-400">
                        {format(msg.time, "HH:mm", {locale: ptBR})}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="border-t border-gray-200 dark:border-gray-700 p-3">
                <div className="flex gap-2">
                  <Input 
                    placeholder="Digite sua mensagem..." 
                    value={newMessage} 
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                    className="flex-1"
                  />
                  <Button onClick={sendMessage}>Enviar</Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="notas" className="flex-1 flex flex-col overflow-hidden mt-0 pt-0">
              <div className="p-4 flex-1">
                <Label htmlFor="notas">Notas da consulta</Label>
                <Textarea 
                  id="notas"
                  placeholder="Registre suas observações sobre a consulta..."
                  value={notas}
                  onChange={(e) => setNotas(e.target.value)}
                  className="mt-2 h-[calc(100%-50px)]"
                />
              </div>
              
              <div className="border-t border-gray-200 dark:border-gray-700 p-3 flex justify-end">
                <Button 
                  onClick={() => {
                    toast({
                      title: "Notas salvas",
                      description: "Suas anotações foram salvas com sucesso."
                    });
                  }}
                >
                  Salvar Notas
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="ia" className="flex-1 flex flex-col overflow-hidden mt-0 pt-0">
              <div className="p-4 flex-1 overflow-auto">
                {!iaActive ? (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <BrainCircuit className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
                    <h3 className="text-xl font-medium mb-2">Assistente de IA</h3>
                    <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md">
                      O assistente de IA pode analisar o histórico e sintomas do paciente para fornecer sugestões durante a consulta.
                    </p>
                    <Button onClick={askIA}>
                      Ativar Assistente de IA
                    </Button>
                  </div>
                ) : iaIsLoading ? (
                  <div className="flex flex-col items-center justify-center h-full">
                    <Spinner size="large" />
                    <p className="mt-4 text-gray-500 dark:text-gray-400">
                      Analisando dados do paciente...
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-3">Análise do Assistente IA</h3>
                      <div className="p-4 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-900 rounded-lg">
                        <p>{iaAssistente?.analise}</p>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-3">Sugestões</h3>
                      <div className="space-y-3">
                        {iaAssistente?.sugestoes.map((sugestao, index) => (
                          <div key={index} className="p-3 border rounded-lg flex items-start gap-3">
                            <div className="bg-green-100 dark:bg-green-900/30 p-2 rounded-full">
                              <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                            </div>
                            <p>{sugestao}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="pt-4">
                      <Alert className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-900">
                        <AlertTitle className="flex items-center gap-2">
                          <HelpCircle className="h-4 w-4" />
                          Lembrete importante
                        </AlertTitle>
                        <AlertDescription>
                          As sugestões da IA são apenas recomendações. Sempre use seu julgamento clínico para a tomada de decisões finais.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <Dialog open={showPrescriptionDialog} onOpenChange={setShowPrescriptionDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Nova Prescrição</DialogTitle>
            <DialogDescription>
              Prescrição para {paciente?.nome_completo} - {format(new Date(), "dd/MM/yyyy", {locale: ptBR})}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {prescription.produtos.map((produto, index) => (
              <div key={index} className="space-y-4 p-4 border rounded-lg relative">
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 text-gray-400 hover:text-red-500"
                  onClick={() => removeProductField(index)}
                  disabled={prescription.produtos.length === 1}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor={`nome-${index}`}>Nome do produto</Label>
                    <Input
                      id={`nome-${index}`}
                      value={produto.nome}
                      onChange={(e) => handleProductChange(index, 'nome', e.target.value)}
                      placeholder="Ex: Óleo de CBD 5%"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor={`dosagem-${index}`}>Dosagem</Label>
                    <Input
                      id={`dosagem-${index}`}
                      value={produto.dosagem}
                      onChange={(e) => handleProductChange(index, 'dosagem', e.target.value)}
                      placeholder="Ex: 0.5ml"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor={`frequencia-${index}`}>Frequência</Label>
                    <Input
                      id={`frequencia-${index}`}
                      value={produto.frequencia}
                      onChange={(e) => handleProductChange(index, 'frequencia', e.target.value)}
                      placeholder="Ex: 2x ao dia"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor={`duracao-${index}`}>Duração</Label>
                    <Input
                      id={`duracao-${index}`}
                      value={produto.duracao}
                      onChange={(e) => handleProductChange(index, 'duracao', e.target.value)}
                      placeholder="Ex: 30 dias"
                    />
                  </div>
                </div>
              </div>
            ))}
            
            <Button 
              variant="outline" 
              className="w-full flex items-center gap-2"
              onClick={addProductField}
            >
              <Plus className="h-4 w-4" />
              Adicionar Produto
            </Button>
            
            <div>
              <Label htmlFor="observacoes">Observações e instruções especiais</Label>
              <Textarea
                id="observacoes"
                value={prescription.observacoes}
                onChange={(e) => setPrescription({...prescription, observacoes: e.target.value})}
                placeholder="Informações adicionais sobre a prescrição..."
                className="mt-2"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPrescriptionDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={savePrescription}>
              Salvar Prescrição
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showEndDialog} onOpenChange={setShowEndDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Finalizar Consulta</DialogTitle>
            <DialogDescription>
              Deseja realmente finalizar a consulta com {paciente?.nome_completo}?
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <p className="mb-4">Tempo de consulta: {formatTime(meetingTime)}</p>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="prescription-done" className="rounded" />
                <label htmlFor="prescription-done">Prescrição realizada</label>
              </div>
              
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="notes-done" className="rounded" />
                <label htmlFor="notes-done">Notas da consulta registradas</label>
              </div>
              
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="followup-done" className="rounded" />
                <label htmlFor="followup-done">Agendamento de retorno discutido</label>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEndDialog(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={endConsultation}>
              Finalizar Consulta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
