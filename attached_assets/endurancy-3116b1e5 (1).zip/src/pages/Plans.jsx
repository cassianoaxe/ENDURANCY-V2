
import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  Leaf, 
  Factory, 
  Heart, 
  Briefcase, 
  Glasses, 
  Plus, 
  Edit, 
  Trash,
  Check,
  X,
  Info,
  CreditCard,
  Tag,
  ArrowRight,
  AlertTriangle,
  Users,
  BrainCircuit  
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

const defaultPlanTypes = {
  'empresarial': {
    icon: Factory,
    name: 'Empresarial',
    description: 'Para empresas comerciais',
    colorClass: 'bg-blue-100 text-blue-800'
  },
  'associacao': {
    icon: Users,
    name: 'Associação',
    description: 'Para associações sem fins lucrativos',
    colorClass: 'bg-green-100 text-green-800'
  }
};

const moduleTypes = {
  'cultivo': {
    icon: Leaf,
    name: 'Cultivo',
    description: 'Gerenciamento completo de cultivo',
    colorClass: 'bg-green-100 text-green-800',
    features: [
      'Gestão de plantas e lotes',
      'Rastreamento de crescimento',
      'Controle de estoque de plantas',
      'Gestão de strains',
      'Transferências internas'
    ]
  },
  'producao': {
    icon: Factory,
    name: 'Produção',
    description: 'Controle de produção e qualidade',
    colorClass: 'bg-yellow-100 text-yellow-800',
    features: [
      'Controle de qualidade',
      'Gestão de fornecedores',
      'Controle de matérias-primas',
      'Ordens de produção',
      'Rastreabilidade'
    ]
  },
  'crm': {
    icon: Heart,
    name: 'CRM',
    description: 'Gestão de pacientes e prescrições',
    colorClass: 'bg-purple-100 text-purple-800',
    features: [
      'Cadastro e gestão de pacientes',
      'Controle de prescrições',
      'Gestão de atendimentos',
      'Campanhas',
      'Histórico médico'
    ]
  },
  'rh': {
    icon: Briefcase,
    name: 'RH',
    description: 'Gestão de recursos humanos',
    colorClass: 'bg-indigo-100 text-indigo-800',
    features: [
      'Recrutamento',
      'Gestão de colaboradores',
      'Documentos',
      'Escalas',
      'Treinamentos'
    ]
  },
  'transparencia': {
    icon: Glasses,
    name: 'Transparência',
    description: 'Portal de transparência para associações',
    colorClass: 'bg-blue-100 text-blue-800',
    features: [
      'Portal público',
      'Documentos públicos',
      'Certificações',
      'Relatórios financeiros',
      'Membros e governança'
    ]
  },
  'inteligencia_artificial': {
    icon: BrainCircuit,
    name: 'Inteligência Artificial',
    description: 'Assistente de IA especializado em cannabis medicinal',
    colorClass: 'bg-purple-100 text-purple-800',
    features: [
      'Copilot especializado',
      'Acessibilidade a diferentes usuários',
      'Base de conhecimento para RAG',
      'Análises de dados via IA',
      'Integração com módulos'
    ]
  },
  'research_module': {
    icon: Info,
    name: 'Módulo de Pesquisa Científica',
    description: 'Gerenciamento completo de pesquisas, pacientes e protocolos',
    colorClass: 'bg-orange-100 text-orange-800',
    features: [
      'Dashboard de pesquisas',
      'Catálogo de pesquisas',
      'Banco de dados de pacientes',
      'Gestão de doenças e condições',
      'Estatísticas e relatórios',
      'Grupos de pesquisa',
      'Protocolos de pesquisa',
      'Gestão de colaborações',
      'Exportação de dados',
      'Suporte prioritário'
    ]
  }
};

const initialPlans = [
  {
    id: 'plan1',
    name: 'Empresarial Básico',
    price: 499,
    type: 'empresarial',
    description: 'Ideal para empresas em estágio inicial',
    is_popular: false,
    billing_cycle: 'monthly',
    is_active: true,
    modules: ['crm'],
    features: [
      { name: 'Até 50 pacientes', included: true },
      { name: 'Controle de prescrições', included: true },
      { name: 'Atendimento básico', included: true },
      { name: 'Relatórios simples', included: true },
      { name: 'Suporte por email', included: true },
      { name: 'API de integração', included: false },
      { name: 'Whitelabel', included: false }
    ]
  },
  {
    id: 'plan2',
    name: 'Empresarial Pro',
    price: 999,
    type: 'empresarial',
    description: 'Para empresas em crescimento',
    is_popular: true,
    billing_cycle: 'monthly',
    is_active: true,
    modules: ['crm', 'producao'],
    features: [
      { name: 'Até 200 pacientes', included: true },
      { name: 'Controle de prescrições', included: true },
      { name: 'Atendimento avançado', included: true },
      { name: 'Relatórios avançados', included: true },
      { name: 'Suporte prioritário', included: true },
      { name: 'API de integração', included: true },
      { name: 'Whitelabel', included: false }
    ]
  },
  {
    id: 'plan3',
    name: 'Empresarial Enterprise',
    price: 1999,
    type: 'empresarial',
    description: 'Solução completa para grandes empresas',
    is_popular: false,
    billing_cycle: 'monthly',
    is_active: true,
    modules: ['crm', 'producao', 'cultivo', 'rh'],
    features: [
      { name: 'Pacientes ilimitados', included: true },
      { name: 'Controle de prescrições', included: true },
      { name: 'Atendimento premium', included: true },
      { name: 'Relatórios personalizados', included: true },
      { name: 'Suporte 24/7', included: true },
      { name: 'API de integração', included: true },
      { name: 'Whitelabel', included: true }
    ]
  },
  {
    id: 'plan4',
    name: 'Associação Plus',
    price: 399,
    type: 'associacao',
    description: 'Ideal para associações pequenas',
    is_popular: false,
    billing_cycle: 'monthly',
    is_active: true,
    modules: ['crm', 'transparencia'],
    features: [
      { name: 'Até 100 membros', included: true },
      { name: 'Portal de transparência', included: true },
      { name: 'Gestão de documentos', included: true },
      { name: 'Relatórios básicos', included: true },
      { name: 'Suporte por email', included: true },
      { name: 'Gestão de assembléias', included: false },
      { name: 'API de integração', included: false }
    ]
  },
  {
    id: 'plan5',
    name: 'Associação Premium',
    price: 799,
    type: 'associacao',
    description: 'Solução completa para associações',
    is_popular: true,
    billing_cycle: 'monthly',
    is_active: true,
    modules: ['crm', 'transparencia', 'cultivo'],
    features: [
      { name: 'Membros ilimitados', included: true },
      { name: 'Portal de transparência', included: true },
      { name: 'Gestão de documentos', included: true },
      { name: 'Relatórios avançados', included: true },
      { name: 'Suporte prioritário', included: true },
      { name: 'Gestão de assembléias', included: true },
      { name: 'API de integração', included: true }
    ]
  },
  {
    id: 'plan6',
    name: 'Pesquisa Científica',
    price: 299.00,
    type: 'associacao',
    description: 'Gerenciamento completo de pesquisas, pacientes e protocolos',
    is_popular: true,
    billing_cycle: 'monthly',
    is_active: true,
    modules: ['research_module'],
    features: [
      { name: 'Dashboard de pesquisas', included: true },
      { name: 'Catálogo de pesquisas', included: true },
      { name: 'Banco de dados de pacientes', included: true },
      { name: 'Gestão de doenças e condições', included: true },
      { name: 'Estatísticas e relatórios', included: true },
      { name: 'Grupos de pesquisa', included: true },
      { name: 'Protocolos de pesquisa', included: true },
      { name: 'Gestão de colaborações', included: true },
      { name: 'Exportação de dados', included: true },
      { name: 'Suporte prioritário', included: true }
    ]
  }
];

const aiModulePlan = {
  id: 'module-ia',
  module: 'inteligencia_artificial',
  name: 'Módulo Inteligência Artificial',
  base_price: 299,
  description: 'Assistente IA especializado em cannabis medicinal e gestão',
  billing_cycle: 'monthly',
  is_active: true,
  tiers: [
    { 
      name: 'Trial', 
      price: 0, 
      limit: '7 dias',
      features: [
        { name: 'Assistente IA Básico', included: true },
        { name: 'RAG com conhecimento geral', included: true },
        { name: 'Limite de 50 consultas/dia', included: true },
        { name: 'Personalização', included: false },
        { name: 'Análises avançadas', included: false }
      ]
    },
    { 
      name: 'Basic', 
      price: 299, 
      limit: '500 consultas/dia',
      features: [
        { name: 'Assistente IA Avançado', included: true },
        { name: 'RAG personalizado (até 100 docs)', included: true },
        { name: 'Limite de 500 consultas/dia', included: true },
        { name: 'Análises básicas', included: true },
        { name: 'APIs especializadas', included: false }
      ]
    },
    { 
      name: 'Professional', 
      price: 599, 
      limit: 'Ilimitado',
      features: [
        { name: 'Assistente IA Avançado', included: true },
        { name: 'RAG personalizado ilimitado', included: true },
        { name: 'Consultas ilimitadas', included: true },
        { name: 'Análises avançadas', included: true },
        { name: 'APIs especializadas', included: true }
      ]
    }
  ]
};

const initialModulePlans = [
  {
    id: 'module-cultivo',
    module: 'cultivo',
    name: 'Módulo Cultivo',
    base_price: 499,
    description: 'Gerenciamento completo de cultivo de cannabis medicinal',
    billing_cycle: 'monthly',
    is_active: true,
    tiers: [
      { 
        name: 'Básico', 
        price: 499, 
        limit: '10 plantas',
        features: [
          { name: 'Gestão de plantas', included: true },
          { name: 'Rastreamento básico', included: true },
          { name: 'Controle de estoque', included: true },
          { name: 'Relatórios básicos', included: true },
          { name: 'Gestão de strains', included: false }
        ]
      },
      { 
        name: 'Intermediário', 
        price: 899, 
        limit: '50 plantas',
        features: [
          { name: 'Gestão de plantas', included: true },
          { name: 'Rastreamento avançado', included: true },
          { name: 'Controle de estoque', included: true },
          { name: 'Relatórios detalhados', included: true },
          { name: 'Gestão de strains', included: true }
        ]
      },
      { 
        name: 'Avançado', 
        price: 1499, 
        limit: 'Ilimitado',
        features: [
          { name: 'Gestão de plantas', included: true },
          { name: 'Rastreamento avançado', included: true },
          { name: 'Controle de estoque', included: true },
          { name: 'Relatórios personalizados', included: true },
          { name: 'Gestão de strains', included: true }
        ]
      }
    ]
  },
  {
    id: 'module-producao',
    module: 'producao',
    name: 'Módulo Produção',
    base_price: 599,
    description: 'Controle de produção e qualidade de produtos de cannabis',
    billing_cycle: 'monthly',
    is_active: true,
    tiers: [
      { 
        name: 'Básico', 
        price: 599, 
        limit: '5 produtos',
        features: [
          { name: 'Controle de qualidade', included: true },
          { name: 'Gestão de fornecedores', included: true },
          { name: 'Controle básico de matérias-primas', included: true },
          { name: 'Ordens de produção', included: true },
          { name: 'Rastreabilidade avançada', included: false }
        ]
      },
      { 
        name: 'Intermediário', 
        price: 999, 
        limit: '20 produtos',
        features: [
          { name: 'Controle de qualidade', included: true },
          { name: 'Gestão de fornecedores', included: true },
          { name: 'Controle avançado de matérias-primas', included: true },
          { name: 'Ordens de produção', included: true },
          { name: 'Rastreabilidade avançada', included: true }
        ]
      },
      { 
        name: 'Avançado', 
        price: 1699, 
        limit: 'Ilimitado',
        features: [
          { name: 'Controle de qualidade', included: true },
          { name: 'Gestão de fornecedores', included: true },
          { name: 'Controle avançado de matérias-primas', included: true },
          { name: 'Ordens de produção', included: true },
          { name: 'Rastreabilidade avançada', included: true }
        ]
      }
    ]
  },
  {
    id: 'module-crm',
    module: 'crm',
    name: 'Módulo CRM',
    base_price: 399,
    description: 'Gestão de pacientes e prescrições de cannabis medicinal',
    billing_cycle: 'monthly',
    is_active: true,
    tiers: [
      { 
        name: 'Básico', 
        price: 399, 
        limit: '50 pacientes',
        features: [
          { name: 'Cadastro de pacientes', included: true },
          { name: 'Controle de prescrições', included: true },
          { name: 'Gestão básica de atendimentos', included: true },
          { name: 'Histórico médico', included: true },
          { name: 'Campanhas marketing', included: false }
        ]
      },
      { 
        name: 'Intermediário', 
        price: 799, 
        limit: '200 pacientes',
        features: [
          { name: 'Cadastro de pacientes', included: true },
          { name: 'Controle de prescrições', included: true },
          { name: 'Gestão avançada de atendimentos', included: true },
          { name: 'Histórico médico', included: true },
          { name: 'Campanhas marketing', included: true }
        ]
      },
      { 
        name: 'Avançado', 
        price: 1299, 
        limit: 'Ilimitado',
        features: [
          { name: 'Cadastro de pacientes', included: true },
          { name: 'Controle de prescrições', included: true },
          { name: 'Gestão avançada de atendimentos', included: true },
          { name: 'Histórico médico', included: true },
          { name: 'Campanhas marketing', included: true }
        ]
      }
    ]
  },
  {
    id: 'module-rh',
    module: 'rh',
    name: 'Módulo RH',
    base_price: 349,
    description: 'Gestão de recursos humanos para empresas de cannabis',
    billing_cycle: 'monthly',
    is_active: true,
    tiers: [
      { 
        name: 'Básico', 
        price: 349, 
        limit: '15 colaboradores',
        features: [
          { name: 'Recrutamento', included: true },
          { name: 'Gestão de colaboradores', included: true },
          { name: 'Documentos', included: true },
          { name: 'Escalas simples', included: true },
          { name: 'Treinamentos avançados', included: false }
        ]
      },
      { 
        name: 'Intermediário', 
        price: 649, 
        limit: '50 colaboradores',
        features: [
          { name: 'Recrutamento', included: true },
          { name: 'Gestão de colaboradores', included: true },
          { name: 'Documentos', included: true },
          { name: 'Escalas avançadas', included: true },
          { name: 'Treinamentos básicos', included: true }
        ]
      },
      { 
        name: 'Avançado', 
        price: 999, 
        limit: 'Ilimitado',
        features: [
          { name: 'Recrutamento', included: true },
          { name: 'Gestão de colaboradores', included: true },
          { name: 'Documentos', included: true },
          { name: 'Escalas avançadas', included: true },
          { name: 'Treinamentos avançados', included: true }
        ]
      }
    ]
  },
  {
    id: 'module-transparencia',
    module: 'transparencia',
    name: 'Módulo Transparência',
    base_price: 299,
    description: 'Portal de transparência para associações de cannabis',
    billing_cycle: 'monthly',
    is_active: true,
    tiers: [
      { 
        name: 'Básico', 
        price: 299, 
        limit: 'Funcionalidades básicas',
        features: [
          { name: 'Portal público', included: true },
          { name: 'Documentos públicos', included: true },
          { name: 'Certificações', included: false },
          { name: 'Relatórios financeiros', included: false },
          { name: 'Membros e governança', included: false }
        ]
      },
      { 
        name: 'Intermediário', 
        price: 499, 
        limit: 'Funcionalidades avançadas',
        features: [
          { name: 'Portal público', included: true },
          { name: 'Documentos públicos', included: true },
          { name: 'Certificações', included: true },
          { name: 'Relatórios financeiros', included: true },
          { name: 'Membros e governança', included: false }
        ]
      },
      { 
        name: 'Avançado', 
        price: 799, 
        limit: 'Funcionalidades completas',
        features: [
          { name: 'Portal público', included: true },
          { name: 'Documentos públicos', included: true },
          { name: 'Certificações', included: true },
          { name: 'Relatórios financeiros', included: true },
          { name: 'Membros e governança', included: true }
        ]
      }
    ]
  },
  aiModulePlan
];

export default function Plans() {
  const [plans, setPlans] = useState([]);
  const [modulePlans, setModulePlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("packages");
  const [editingPlan, setEditingPlan] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [planToDelete, setPlanToDelete] = useState(null);

  useEffect(() => {
    setTimeout(() => {
      setPlans(initialPlans);
      setModulePlans(initialModulePlans); 
      setLoading(false);
    }, 1000);
  }, []);

  const handleSavePlan = (plan) => {
    if (plan.id) {
      setPlans(plans.map(p => p.id === plan.id ? plan : p));
    } else {
      setPlans([...plans, {...plan, id: `plan${plans.length + 1}`}]);
    }
    
    toast({
      title: "Plano salvo",
      description: `O plano foi salvo com sucesso.`,
    });
    
    setEditingPlan(null);
  };

  const handleDeletePlan = (id) => {
    setPlans(plans.filter(p => p.id !== id));
    setPlanToDelete(null);
    setShowDeleteDialog(false);
    
    toast({
      title: "Plano excluído",
      description: `O plano foi excluído com sucesso.`,
    });
  };

  const confirmDelete = (plan) => {
    setPlanToDelete(plan);
    setShowDeleteDialog(true);
  };

  const renderPlanCards = () => {
    if (loading) {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="h-10 bg-gray-200 rounded w-1/3 mb-4"></div>
                <div className="space-y-2">
                  {[1, 2, 3, 4].map(j => (
                    <div key={j} className="h-4 bg-gray-200 rounded w-full"></div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <div className="h-10 bg-gray-200 rounded w-full"></div>
              </CardFooter>
            </Card>
          ))}
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {plans.map(plan => {
          const planType = defaultPlanTypes[plan.type];
          const PlanIcon = planType?.icon || Factory;
          
          return (
            <Card key={plan.id} className={plan.is_popular ? "border-blue-300 shadow-md" : ""}>
              {plan.is_popular && (
                <div className="absolute top-0 right-0 -mt-2 -mr-2">
                  <Badge className="bg-blue-500">Popular</Badge>
                </div>
              )}
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <Badge 
                      variant="outline" 
                      className={planType?.colorClass || "bg-gray-100"}
                    >
                      {planType?.name || 'Plano'}
                    </Badge>
                    <CardTitle className="mt-2">{plan.name}</CardTitle>
                    <CardDescription>{plan.description}</CardDescription>
                  </div>
                  <div className={`p-2 rounded-full ${planType?.colorClass || "bg-gray-100"}`}>
                    <PlanIcon className="w-5 h-5" />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <span className="text-3xl font-bold">R$ {plan.price}</span>
                  <span className="text-gray-500">/mês</span>
                </div>
                
                <div className="space-y-2">
                  <p className="font-medium text-sm text-gray-700">Módulos incluídos:</p>
                  <div className="flex flex-wrap gap-2">
                    {plan.modules.map(moduleId => {
                      const module = moduleTypes[moduleId];
                      const ModuleIcon = module?.icon || Info;
                      
                      return (
                        <Badge 
                          key={moduleId}
                          variant="outline" 
                          className={`flex gap-1 ${module?.colorClass || 'bg-gray-100'}`}
                        >
                          <ModuleIcon className="w-3 h-3" />
                          {module?.name || moduleId}
                        </Badge>
                      );
                    })}
                  </div>
                </div>
                
                <div>
                  <p className="font-medium text-sm text-gray-700 mb-2">Recursos incluídos:</p>
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm">
                        {feature.included ? (
                          <Check className="w-4 h-4 text-green-500" />
                        ) : (
                          <X className="w-4 h-4 text-gray-300" />
                        )}
                        <span className={feature.included ? "" : "text-gray-400"}>
                          {feature.name}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <div className="flex items-center gap-3">
                  <Badge 
                    variant="outline" 
                    className={plan.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
                  >
                    {plan.is_active ? "Ativo" : "Inativo"}
                  </Badge>
                </div>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <span className="sr-only">Abrir menu</span>
                      <svg
                        width="15"
                        height="15"
                        viewBox="0 0 15 15"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                      >
                        <path
                          d="M8.625 2.5C8.625 3.12132 8.12132 3.625 7.5 3.625C6.87868 3.625 6.375 3.12132 6.375 2.5C6.375 1.87868 6.87868 1.375 7.5 1.375C8.12132 1.375 8.625 1.87868 8.625 2.5ZM8.625 7.5C8.625 8.12132 8.12132 8.625 7.5 8.625C6.87868 8.625 6.375 8.12132 6.375 7.5C6.375 6.87868 6.87868 6.375 7.5 6.375C8.12132 6.375 8.625 6.87868 8.625 7.5ZM7.5 13.625C8.12132 13.625 8.625 13.1213 8.625 12.5C8.625 11.8787 8.12132 11.375 7.5 11.375C6.87868 11.375 6.375 11.8787 6.375 12.5C6.375 13.1213 6.87868 13.625 7.5 13.625Z"
                          fill="currentColor"
                          fillRule="evenodd"
                          clipRule="evenodd"
                        ></path>
                      </svg>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setEditingPlan(plan)}>
                      <Edit className="w-4 h-4 mr-2" />
                      Editar
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => confirmDelete(plan)}>
                      <Trash className="w-4 h-4 mr-2" />
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </CardFooter>
            </Card>
          );
        })}
        
        <Card className="flex flex-col items-center justify-center p-6 border-dashed cursor-pointer hover:bg-gray-50 transition-colors"
              onClick={() => setEditingPlan({
                name: '',
                price: 0,
                type: 'empresarial',
                description: '',
                is_popular: false,
                billing_cycle: 'monthly',
                is_active: true,
                modules: [],
                features: []
              })}>
          <div className="rounded-full bg-gray-100 p-4 mb-4">
            <Plus className="w-6 h-6 text-gray-500" />
          </div>
          <p className="font-medium text-gray-700">Adicionar Novo Plano</p>
          <p className="text-sm text-gray-500 text-center mt-2">
            Crie um novo pacote de assinatura
          </p>
        </Card>
      </div>
    );
  };

  const renderModulePlans = () => {
    if (loading) {
      return (
        <div className="space-y-8 animate-pulse">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardHeader>
                <div className="h-6 bg-gray-200 rounded w-1/2 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="h-10 bg-gray-200 rounded w-1/4 mb-4"></div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[1, 2, 3].map(j => (
                    <div key={j} className="p-4 border rounded-lg">
                      <div className="h-5 bg-gray-200 rounded w-1/2 mb-3"></div>
                      <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
                      <div className="space-y-2">
                        {[1, 2, 3].map(k => (
                          <div key={k} className="h-4 bg-gray-200 rounded w-full"></div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      );
    }

    return (
      <div className="space-y-8">
        {modulePlans.map(modulePlan => {
          const module = moduleTypes[modulePlan.module];
          const ModuleIcon = module?.icon || Info;
          
          return (
            <Card key={modulePlan.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge 
                        variant="outline" 
                        className={module?.colorClass || "bg-gray-100"}
                      >
                        <ModuleIcon className="w-3 h-3 mr-1" />
                        {module?.name || modulePlan.module}
                      </Badge>
                      {!modulePlan.is_active && (
                        <Badge variant="outline" className="bg-red-100 text-red-800">
                          Inativo
                        </Badge>
                      )}
                    </div>
                    <CardTitle>{modulePlan.name}</CardTitle>
                    <CardDescription>{modulePlan.description}</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="gap-1">
                      <Edit className="w-4 h-4" />
                      Editar
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <p className="text-sm font-medium text-gray-500">Preço base</p>
                  <p className="text-xl font-bold">R$ {modulePlan.base_price}/mês</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {modulePlan.tiers.map((tier, index) => (
                    <div key={index} className={`p-4 border rounded-lg ${index === 1 ? 'border-blue-200 bg-blue-50/30' : ''}`}>
                      {index === 1 && (
                        <Badge className="bg-blue-500 mb-2">Recomendado</Badge>
                      )}
                      <h3 className="font-medium">{tier.name}</h3>
                      <div className="my-2">
                        <span className="text-2xl font-bold">R$ {tier.price}</span>
                        <span className="text-gray-500">/mês</span>
                      </div>
                      <p className="text-sm text-gray-500 mb-4">Limite: {tier.limit}</p>
                      
                      <ul className="space-y-2">
                        {tier.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center gap-2 text-sm">
                            {feature.included ? (
                              <Check className="w-4 h-4 text-green-500" />
                            ) : (
                              <X className="w-4 h-4 text-gray-300" />
                            )}
                            <span className={feature.included ? "" : "text-gray-400"}>
                              {feature.name}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    );
  };

  const PlanEditForm = ({ plan, onSave, onCancel }) => {
    const [formData, setFormData] = useState({...plan});
    
    const handleModuleToggle = (moduleId) => {
      if (formData.modules.includes(moduleId)) {
        setFormData({
          ...formData,
          modules: formData.modules.filter(id => id !== moduleId)
        });
      } else {
        setFormData({
          ...formData,
          modules: [...formData.modules, moduleId]
        });
      }
    };
    
    const handleFeatureToggle = (index) => {
      const updatedFeatures = [...formData.features];
      updatedFeatures[index] = {
        ...updatedFeatures[index],
        included: !updatedFeatures[index].included
      };
      setFormData({...formData, features: updatedFeatures});
    };
    
    const addFeature = () => {
      setFormData({
        ...formData,
        features: [...formData.features, { name: '', included: true }]
      });
    };
    
    const updateFeatureName = (index, name) => {
      const updatedFeatures = [...formData.features];
      updatedFeatures[index] = {
        ...updatedFeatures[index],
        name
      };
      setFormData({...formData, features: updatedFeatures});
    };
    
    const removeFeature = (index) => {
      setFormData({
        ...formData,
        features: formData.features.filter((_, i) => i !== index)
      });
    };
    
    return (
      <Dialog open={true} onOpenChange={onCancel}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{plan.id ? 'Editar Plano' : 'Novo Plano'}</DialogTitle>
            <DialogDescription>
              {plan.id 
                ? 'Edite as informações do plano existente' 
                : 'Configure um novo plano de assinatura'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 max-h-[70vh] overflow-y-auto p-1">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome do Plano</Label>
                <Input 
                  id="name" 
                  value={formData.name} 
                  onChange={e => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="price">Preço (R$/mês)</Label>
                <Input 
                  id="price" 
                  type="number" 
                  value={formData.price} 
                  onChange={e => setFormData({...formData, price: Number(e.target.value)})}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Input 
                id="description" 
                value={formData.description} 
                onChange={e => setFormData({...formData, description: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="type">Tipo de Plano</Label>
                <Select 
                  value={formData.type} 
                  onValueChange={value => setFormData({...formData, type: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="empresarial">Empresarial</SelectItem>
                    <SelectItem value="associacao">Associação</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="billing_cycle">Ciclo de Cobrança</Label>
                <Select 
                  value={formData.billing_cycle} 
                  onValueChange={value => setFormData({...formData, billing_cycle: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o ciclo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Mensal</SelectItem>
                    <SelectItem value="quarterly">Trimestral</SelectItem>
                    <SelectItem value="yearly">Anual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="modules">Módulos Incluídos</Label>
                <p className="text-sm text-gray-500">Selecione os módulos incluídos neste plano</p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {Object.entries(moduleTypes).map(([moduleId, module]) => {
                  const ModuleIcon = module.icon;
                  const isSelected = formData.modules.includes(moduleId);
                  
                  return (
                    <div 
                      key={moduleId}
                      className={`flex items-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors ${
                        isSelected 
                          ? `${module.colorClass} border-green-300` 
                          : 'hover:bg-gray-50'
                      }`}
                      onClick={() => handleModuleToggle(moduleId)}
                    >
                      <div className={`p-2 rounded-full ${module.colorClass}`}>
                        <ModuleIcon className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{module.name}</p>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-green-600" />}
                    </div>
                  );
                })}
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Recursos Incluídos</Label>
                <Button variant="outline" size="sm" onClick={addFeature} type="button">
                  <Plus className="w-4 h-4 mr-1" />
                  Adicionar Recurso
                </Button>
              </div>
              <div className="space-y-3">
                {formData.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <Switch
                      checked={feature.included}
                      onCheckedChange={() => handleFeatureToggle(index)}
                    />
                    <Input
                      value={feature.name}
                      onChange={e => updateFeatureName(index, e.target.value)}
                      placeholder="Nome do recurso"
                      className="flex-1"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeFeature(index)}
                      type="button"
                    >
                      <Trash className="w-4 h-4 text-gray-500" />
                    </Button>
                  </div>
                ))}
                
                {formData.features.length === 0 && (
                  <div className="text-center py-4 text-gray-500">
                    Nenhum recurso adicionado. Clique no botão acima para adicionar.
                  </div>
                )}
              </div>
            </div>
            
            <div className="space-y-4">
              <Label>Configurações Adicionais</Label>
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Plano em Destaque</p>
                    <p className="text-sm text-gray-500">Marcar este plano como popular/recomendado</p>
                  </div>
                  <Switch
                    checked={formData.is_popular}
                    onCheckedChange={checked => setFormData({...formData, is_popular: checked})}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Plano Ativo</p>
                    <p className="text-sm text-gray-500">Determina se o plano está disponível para assinatura</p>
                  </div>
                  <Switch
                    checked={formData.is_active}
                    onCheckedChange={checked => setFormData({...formData, is_active: checked})}
                  />
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={onCancel}>Cancelar</Button>
            <Button onClick={() => onSave(formData)}>Salvar Plano</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Planos e Preços</h1>
          <p className="text-gray-500 mt-1">
            Gerencie os planos de assinatura e módulos disponíveis
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="packages">Pacotes</TabsTrigger>
          <TabsTrigger value="modules">Módulos</TabsTrigger>
          <TabsTrigger value="billing">Faturamento</TabsTrigger>
        </TabsList>
        
        <TabsContent value="packages" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Pacotes de Assinatura</CardTitle>
              <CardDescription>
                Pacotes completos que incluem diferentes módulos e funcionalidades
              </CardDescription>
            </CardHeader>
            <CardContent>
              {renderPlanCards()}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="modules" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Módulos e Preços</CardTitle>
              <CardDescription>
                Configure os preços e opções para cada módulo individual do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              {renderModulePlans()}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="billing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Faturamento</CardTitle>
              <CardDescription>
                Configure as opções de faturamento, pagamento e cobrança
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <div className="flex gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-amber-900">Integração de Pagamento</h3>
                    <p className="mt-2 text-amber-700 text-sm">
                      Você ainda não configurou uma integração de pagamento. Recomendamos configurar
                      integração com ao menos um gateway de pagamento antes de ativar os planos.
                    </p>
                    <Button className="mt-3" variant="outline">
                      <CreditCard className="w-4 h-4 mr-2" />
                      Configurar Gateway de Pagamento
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Métodos de Pagamento Aceitos</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <CreditCard className="w-5 h-5 text-gray-500" />
                      <div>
                        <p className="font-medium">Cartão de Crédito</p>
                        <p className="text-sm text-gray-500">Visa, Mastercard, Amex, Elo</p>
                      </div>
                    </div>
                    <Switch checked={true} />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <svg
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        className="text-gray-500"
                      >
                        <path
                          d="M8.5 12H8V11.5V8.5V8H8.5H11.5H12V8.5V11.5V12H11.5H8.5Z"
                          stroke="currentColor"
                        />
                        <path
                          d="M12 15.5V15H12.5H15.5H16V15.5V18.5V19H15.5H12.5H12V18.5V15.5Z"
                          stroke="currentColor"
                        />
                        <path
                          d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z"
                          stroke="currentColor"
                        />
                      </svg>
                      <div>
                        <p className="font-medium">Pix</p>
                        <p className="text-sm text-gray-500">Pagamento instantâneo</p>
                      </div>
                    </div>
                    <Switch checked={true} />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <svg
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        className="text-gray-500"
                      >
                        <path
                          d="M4 9V7C4 5.89543 4.89543 5 6 5H19C19.5523 5 20 5.44772 20 6V14C20 15.1046 19.1046 16 18 16H16"
                          stroke="currentColor"
                        />
                        <rect x="3" y="9" width="13" height="10" rx="1" stroke="currentColor" />
                      </svg>
                      <div>
                        <p className="font-medium">Boleto Bancário</p>
                        <p className="text-sm text-gray-500">Prazo de 3 dias úteis para compensação</p>
                      </div>
                    </div>
                    <Switch />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Opções de Cobrança</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Período de Teste</p>
                      <p className="text-sm text-gray-500">Oferecer período de teste para novos clientes</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Select defaultValue="7">
                        <SelectTrigger className="w-24">
                          <SelectValue placeholder="Dias" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">Nenhum</SelectItem>
                          <SelectItem value="7">7 dias</SelectItem>
                          <SelectItem value="14">14 dias</SelectItem>
                          <SelectItem value="30">30 dias</SelectItem>
                        </SelectContent>
                      </Select>
                      <Switch checked={true} />
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Cobrança Automática</p>
                      <p className="text-sm text-gray-500">Cobrar automaticamente na renovação</p>
                    </div>
                    <Switch checked={true} />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Notificações de Fatura</p>
                      <p className="text-sm text-gray-500">Enviar notificações antes do vencimento</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Select defaultValue="3">
                        <SelectTrigger className="w-24">
                          <SelectValue placeholder="Dias" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 dia</SelectItem>
                          <SelectItem value="3">3 dias</SelectItem>
                          <SelectItem value="5">5 dias</SelectItem>
                          <SelectItem value="7">7 dias</SelectItem>
                        </SelectContent>
                      </Select>
                      <Switch checked={true} />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button>Salvar Configurações</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {editingPlan && (
        <PlanEditForm 
          plan={editingPlan} 
          onSave={handleSavePlan}
          onCancel={() => setEditingPlan(null)}
        />
      )}
      
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
            <DialogDescription>
              Você tem certeza que deseja excluir o plano "{planToDelete?.name}"? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={() => handleDeletePlan(planToDelete?.id)}>
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
