
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Users, 
  UserPlus, 
  Search, 
  Filter, 
  FileText, 
  Calendar,
  ShoppingBag,
  CreditCard,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileCheck,
  Eye,
  MapPin,
  Mail,
  Phone,
  Edit,
  Download,
  UserCog,
  ClipboardList,
  FileWarning,
  MoreHorizontal
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Dados mockados de associados para demonstração
const associadosMock = [
  {
    id: "a001",
    nome_completo: "Maria Silva",
    cpf: "123.456.789-00",
    data_nascimento: "1985-05-15",
    email: "maria.silva@email.com",
    telefone: "(11) 98765-4321",
    endereco: "Rua das Flores, 123 - São Paulo, SP",
    status: "ativo",
    data_associacao: "2022-01-10",
    tipo_associado: "regular",
    situacao_financeira: "em_dia",
    condicoes_medicas: ["Epilepsia", "Ansiedade"],
    documentos: [
      { tipo: "rg", url: "#", data_upload: "2022-01-05" },
      { tipo: "laudo_medico", url: "#", data_upload: "2022-01-05" },
      { tipo: "receita", url: "#", data_upload: "2023-03-12" }
    ],
    prescricoes_ativas: ["PR-1234", "PR-5678"]
  },
  {
    id: "a002",
    nome_completo: "João Pereira",
    cpf: "987.654.321-00",
    data_nascimento: "1975-08-20",
    email: "joao.pereira@email.com",
    telefone: "(11) 91234-5678",
    endereco: "Av. Paulista, 1000 - São Paulo, SP",
    status: "ativo",
    data_associacao: "2022-02-15",
    tipo_associado: "fundador",
    situacao_financeira: "em_dia",
    condicoes_medicas: ["Dor crônica", "Insônia"],
    documentos: [
      { tipo: "rg", url: "#", data_upload: "2022-02-10" },
      { tipo: "laudo_medico", url: "#", data_upload: "2022-02-10" },
      { tipo: "receita", url: "#", data_upload: "2023-04-05" }
    ],
    prescricoes_ativas: ["PR-2345"]
  },
  {
    id: "a003",
    nome_completo: "Ana Costa",
    cpf: "456.789.123-00",
    data_nascimento: "1990-03-25",
    email: "ana.costa@email.com",
    telefone: "(11) 95555-9999",
    endereco: "Rua Augusta, 500 - São Paulo, SP",
    status: "ativo",
    data_associacao: "2022-03-20",
    tipo_associado: "regular",
    situacao_financeira: "inadimplente",
    condicoes_medicas: ["Fibromialgia", "Ansiedade"],
    documentos: [
      { tipo: "rg", url: "#", data_upload: "2022-03-15" },
      { tipo: "laudo_medico", url: "#", data_upload: "2022-03-15" }
    ],
    prescricoes_ativas: ["PR-3456"]
  },
  {
    id: "a004",
    nome_completo: "Carlos Santos",
    cpf: "789.123.456-00",
    data_nascimento: "1982-11-10",
    email: "carlos.santos@email.com",
    telefone: "(11) 94444-8888",
    endereco: "Rua Direita, 100 - São Paulo, SP",
    status: "inativo",
    data_associacao: "2022-04-05",
    tipo_associado: "regular",
    situacao_financeira: "inadimplente",
    condicoes_medicas: ["Alzheimer", "Parkinson"],
    documentos: [
      { tipo: "rg", url: "#", data_upload: "2022-04-01" },
      { tipo: "laudo_medico", url: "#", data_upload: "2022-04-01" }
    ],
    prescricoes_ativas: []
  },
  {
    id: "a005",
    nome_completo: "Fernanda Lima",
    cpf: "321.654.987-00",
    data_nascimento: "1988-07-30",
    email: "fernanda.lima@email.com",
    telefone: "(11) 93333-7777",
    endereco: "Av. Brigadeiro Faria Lima, 2000 - São Paulo, SP",
    status: "ativo",
    data_associacao: "2022-05-12",
    tipo_associado: "regular",
    situacao_financeira: "em_dia",
    condicoes_medicas: ["Esclerose múltipla"],
    documentos: [
      { tipo: "rg", url: "#", data_upload: "2022-05-10" },
      { tipo: "laudo_medico", url: "#", data_upload: "2022-05-10" },
      { tipo: "receita", url: "#", data_upload: "2023-02-15" }
    ],
    prescricoes_ativas: ["PR-4567"]
  }
];

// Dados de anuidades mockados
const anuidadesMock = [
  {
    id: "an2023",
    associado_id: "a001",
    ano_referencia: "2023",
    valor_original: 240.00,
    valor_pago: 240.00,
    data_vencimento: "2023-01-31",
    data_pagamento: "2023-01-15",
    status: "pago",
    metodo_pagamento: "pix"
  },
  {
    id: "an2022",
    associado_id: "a001",
    ano_referencia: "2022",
    valor_original: 220.00,
    valor_pago: 220.00,
    data_vencimento: "2022-01-31",
    data_pagamento: "2022-01-20",
    status: "pago",
    metodo_pagamento: "transferencia"
  },
  {
    id: "an2023b",
    associado_id: "a003",
    ano_referencia: "2023",
    valor_original: 240.00,
    valor_pago: null,
    data_vencimento: "2023-01-31",
    data_pagamento: null,
    status: "atrasado",
    metodo_pagamento: null
  }
];

export default function Associados() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [situacaoFinanceiraFilter, setSituacaoFinanceiraFilter] = useState("todos");
  const [associados, setAssociados] = useState([]);
  const [selectedAssociado, setSelectedAssociado] = useState(null);
  const [activeTab, setActiveTab] = useState("dados");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulando carregamento de dados
    setTimeout(() => {
      setAssociados(associadosMock);
      setIsLoading(false);
    }, 1000);
  }, []);

  const filteredAssociados = associados.filter(associado => {
    const matchesSearch = searchTerm === "" || 
      associado.nome_completo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      associado.cpf.includes(searchTerm) ||
      associado.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "todos" || associado.status === statusFilter;
    
    const matchesSituacaoFinanceira = situacaoFinanceiraFilter === "todos" || 
      associado.situacao_financeira === situacaoFinanceiraFilter;
    
    return matchesSearch && matchesStatus && matchesSituacaoFinanceira;
  });
  
  const getStatusBadge = (status) => {
    switch (status) {
      case "ativo":
        return <Badge className="bg-green-100 text-green-800">Ativo</Badge>;
      case "inativo":
        return <Badge className="bg-gray-100 text-gray-800">Inativo</Badge>;
      case "suspenso":
        return <Badge className="bg-red-100 text-red-800">Suspenso</Badge>;
      case "pendente":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  const getSituacaoFinanceiraBadge = (situacao) => {
    switch (situacao) {
      case "em_dia":
        return <Badge className="bg-green-100 text-green-800">Em dia</Badge>;
      case "inadimplente":
        return <Badge className="bg-red-100 text-red-800">Inadimplente</Badge>;
      case "isento":
        return <Badge className="bg-blue-100 text-blue-800">Isento</Badge>;
      default:
        return <Badge>{situacao}</Badge>;
    }
  };
  
  const getTipoAssociadoBadge = (tipo) => {
    switch (tipo) {
      case "regular":
        return <Badge variant="outline">Regular</Badge>;
      case "fundador":
        return <Badge variant="outline" className="border-amber-500 text-amber-800">Fundador</Badge>;
      case "honorario":
        return <Badge variant="outline" className="border-purple-500 text-purple-800">Honorário</Badge>;
      case "colaborador":
        return <Badge variant="outline" className="border-blue-500 text-blue-800">Colaborador</Badge>;
      default:
        return <Badge variant="outline">{tipo}</Badge>;
    }
  };

  // Encontrar as anuidades do associado selecionado
  const getAnuidadesAssociado = (associadoId) => {
    return anuidadesMock.filter(anuidade => anuidade.associado_id === associadoId);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Quadro de Associados</h1>
          <p className="text-gray-500 mt-1">Gerencie os associados da sua organização</p>
        </div>
        
        <Link to={createPageUrl("NovoAssociado")}>
          <Button className="gap-2">
            <UserPlus className="w-4 h-4" />
            Novo Associado
          </Button>
        </Link>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar por nome, CPF ou email..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <Select
          value={statusFilter}
          onValueChange={setStatusFilter}
        >
          <SelectTrigger className="w-full md:w-40">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="ativo">Ativos</SelectItem>
            <SelectItem value="inativo">Inativos</SelectItem>
            <SelectItem value="suspenso">Suspensos</SelectItem>
            <SelectItem value="pendente">Pendentes</SelectItem>
          </SelectContent>
        </Select>
        
        <Select
          value={situacaoFinanceiraFilter}
          onValueChange={setSituacaoFinanceiraFilter}
        >
          <SelectTrigger className="w-full md:w-40">
            <SelectValue placeholder="Situação Financeira" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="em_dia">Em dia</SelectItem>
            <SelectItem value="inadimplente">Inadimplentes</SelectItem>
            <SelectItem value="isento">Isentos</SelectItem>
          </SelectContent>
        </Select>
        
        <Button variant="outline" className="gap-2">
          <Filter className="w-4 h-4" />
          Mais Filtros
        </Button>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-pulse">Carregando associados...</div>
        </div>
      ) : (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>CPF</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Data Associação</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Situação Financeira</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAssociados.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    Nenhum associado encontrado com os filtros selecionados.
                  </TableCell>
                </TableRow>
              ) : (
                filteredAssociados.map(associado => (
                  <TableRow key={associado.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center">
                        <Avatar className="h-8 w-8 mr-2">
                          <AvatarFallback>{associado.nome_completo.substring(0, 2).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        {associado.nome_completo}
                      </div>
                    </TableCell>
                    <TableCell>{associado.cpf}</TableCell>
                    <TableCell>{getTipoAssociadoBadge(associado.tipo_associado)}</TableCell>
                    <TableCell>{new Date(associado.data_associacao).toLocaleDateString()}</TableCell>
                    <TableCell>{getStatusBadge(associado.status)}</TableCell>
                    <TableCell>{getSituacaoFinanceiraBadge(associado.situacao_financeira)}</TableCell>
                    <TableCell>
                      <Dialog>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Ações</DropdownMenuLabel>
                            <DialogTrigger asChild onClick={() => setSelectedAssociado(associado)}>
                              <DropdownMenuItem>
                                <Eye className="mr-2 h-4 w-4" />
                                Visualizar Detalhes
                              </DropdownMenuItem>
                            </DialogTrigger>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <FileCheck className="mr-2 h-4 w-4" />
                              Prescrições
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <ShoppingBag className="mr-2 h-4 w-4" />
                              Pedidos
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <ClipboardList className="mr-2 h-4 w-4" />
                              Documentos
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600">
                              <XCircle className="mr-2 h-4 w-4" />
                              {associado.status === "ativo" ? "Desativar" : "Ativar"}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        
                        <DialogContent className="max-w-3xl">
                          {selectedAssociado && (
                            <>
                              <DialogHeader>
                                <DialogTitle className="flex items-center gap-2">
                                  <Avatar className="h-8 w-8">
                                    <AvatarFallback>{selectedAssociado.nome_completo.substring(0, 2).toUpperCase()}</AvatarFallback>
                                  </Avatar>
                                  {selectedAssociado.nome_completo}
                                </DialogTitle>
                                <div className="flex gap-2 mt-2">
                                  {getStatusBadge(selectedAssociado.status)}
                                  {getSituacaoFinanceiraBadge(selectedAssociado.situacao_financeira)}
                                  {getTipoAssociadoBadge(selectedAssociado.tipo_associado)}
                                </div>
                              </DialogHeader>
                              
                              <Tabs value={activeTab} onValueChange={setActiveTab}>
                                <TabsList className="mb-4">
                                  <TabsTrigger value="dados">Dados Pessoais</TabsTrigger>
                                  <TabsTrigger value="docs">Documentos</TabsTrigger>
                                  <TabsTrigger value="anuidades">Anuidades</TabsTrigger>
                                  <TabsTrigger value="prescricoes">Prescrições</TabsTrigger>
                                  <TabsTrigger value="pedidos">Pedidos</TabsTrigger>
                                </TabsList>
                                
                                <TabsContent value="dados" className="space-y-4">
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="flex items-center gap-2">
                                      <Mail className="w-4 h-4 text-gray-500" />
                                      <span className="text-sm text-gray-500">Email:</span>
                                      <span>{selectedAssociado.email}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <Phone className="w-4 h-4 text-gray-500" />
                                      <span className="text-sm text-gray-500">Telefone:</span>
                                      <span>{selectedAssociado.telefone}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <Calendar className="w-4 h-4 text-gray-500" />
                                      <span className="text-sm text-gray-500">Data de Nascimento:</span>
                                      <span>{new Date(selectedAssociado.data_nascimento).toLocaleDateString()}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <Calendar className="w-4 h-4 text-gray-500" />
                                      <span className="text-sm text-gray-500">Data de Associação:</span>
                                      <span>{new Date(selectedAssociado.data_associacao).toLocaleDateString()}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <MapPin className="w-4 h-4 text-gray-500" />
                                      <span className="text-sm text-gray-500">Endereço:</span>
                                      <span>{selectedAssociado.endereco}</span>
                                    </div>
                                  </div>
                                  
                                  <div>
                                    <h3 className="text-sm font-medium text-gray-500 mb-2">Condições Médicas:</h3>
                                    <div className="flex flex-wrap gap-2">
                                      {selectedAssociado.condicoes_medicas.map((condicao, index) => (
                                        <Badge key={index} variant="outline">{condicao}</Badge>
                                      ))}
                                    </div>
                                  </div>
                                </TabsContent>
                                
                                <TabsContent value="docs">
                                  <div className="space-y-4">
                                    <div className="flex justify-between items-center">
                                      <h3 className="font-medium">Documentos do Associado</h3>
                                      <Button variant="outline" size="sm" className="gap-2">
                                        <FileText className="w-4 h-4" />
                                        Adicionar Documento
                                      </Button>
                                    </div>
                                    
                                    <Table>
                                      <TableHeader>
                                        <TableRow>
                                          <TableHead>Tipo</TableHead>
                                          <TableHead>Data de Upload</TableHead>
                                          <TableHead>Ações</TableHead>
                                        </TableRow>
                                      </TableHeader>
                                      <TableBody>
                                        {selectedAssociado.documentos.map((doc, index) => (
                                          <TableRow key={index}>
                                            <TableCell>
                                              {doc.tipo === "rg" && "RG/Documento de Identidade"}
                                              {doc.tipo === "cpf" && "CPF"}
                                              {doc.tipo === "laudo_medico" && "Laudo Médico"}
                                              {doc.tipo === "receita" && "Receita/Prescrição"}
                                              {doc.tipo === "comprovante_residencia" && "Comprovante de Residência"}
                                              {doc.tipo === "outros" && "Outro Documento"}
                                            </TableCell>
                                            <TableCell>{new Date(doc.data_upload).toLocaleDateString()}</TableCell>
                                            <TableCell>
                                              <div className="flex gap-2">
                                                <Button variant="ghost" size="icon">
                                                  <Download className="w-4 h-4" />
                                                </Button>
                                                <Button variant="ghost" size="icon">
                                                  <Eye className="w-4 h-4" />
                                                </Button>
                                              </div>
                                            </TableCell>
                                          </TableRow>
                                        ))}
                                      </TableBody>
                                    </Table>
                                  </div>
                                </TabsContent>
                                
                                <TabsContent value="anuidades">
                                  <div className="space-y-4">
                                    <div className="flex justify-between items-center">
                                      <h3 className="font-medium">Pagamentos de Anuidades</h3>
                                      <Button variant="outline" size="sm" className="gap-2">
                                        <CreditCard className="w-4 h-4" />
                                        Registrar Pagamento
                                      </Button>
                                    </div>
                                    
                                    <Table>
                                      <TableHeader>
                                        <TableRow>
                                          <TableHead>Ano</TableHead>
                                          <TableHead>Valor</TableHead>
                                          <TableHead>Data de Vencimento</TableHead>
                                          <TableHead>Data de Pagamento</TableHead>
                                          <TableHead>Status</TableHead>
                                          <TableHead>Método</TableHead>
                                        </TableRow>
                                      </TableHeader>
                                      <TableBody>
                                        {getAnuidadesAssociado(selectedAssociado.id).length > 0 ? (
                                          getAnuidadesAssociado(selectedAssociado.id).map((anuidade) => (
                                            <TableRow key={anuidade.id}>
                                              <TableCell>{anuidade.ano_referencia}</TableCell>
                                              <TableCell>R$ {anuidade.valor_original.toFixed(2)}</TableCell>
                                              <TableCell>{new Date(anuidade.data_vencimento).toLocaleDateString()}</TableCell>
                                              <TableCell>
                                                {anuidade.data_pagamento ? new Date(anuidade.data_pagamento).toLocaleDateString() : '-'}
                                              </TableCell>
                                              <TableCell>
                                                {anuidade.status === "pago" && <Badge className="bg-green-100 text-green-800">Pago</Badge>}
                                                {anuidade.status === "pendente" && <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>}
                                                {anuidade.status === "atrasado" && <Badge className="bg-red-100 text-red-800">Atrasado</Badge>}
                                                {anuidade.status === "isento" && <Badge className="bg-blue-100 text-blue-800">Isento</Badge>}
                                              </TableCell>
                                              <TableCell>{anuidade.metodo_pagamento || '-'}</TableCell>
                                            </TableRow>
                                          ))
                                        ) : (
                                          <TableRow>
                                            <TableCell colSpan={6} className="text-center py-4 text-gray-500">
                                              Nenhum registro de anuidade encontrado.
                                            </TableCell>
                                          </TableRow>
                                        )}
                                      </TableBody>
                                    </Table>
                                  </div>
                                </TabsContent>
                                
                                <TabsContent value="prescricoes">
                                  <div className="space-y-4">
                                    <div className="flex justify-between items-center">
                                      <h3 className="font-medium">Prescrições</h3>
                                      <Button variant="outline" size="sm" className="gap-2">
                                        <FileCheck className="w-4 h-4" />
                                        Nova Prescrição
                                      </Button>
                                    </div>
                                    
                                    {selectedAssociado.prescricoes_ativas.length > 0 ? (
                                      <div className="bg-gray-50 p-6 rounded-lg space-y-4">
                                        <h4 className="text-sm font-medium">Prescrições Ativas:</h4>
                                        <div className="flex flex-wrap gap-3">
                                          {selectedAssociado.prescricoes_ativas.map((prescricao, index) => (
                                            <div key={index} className="flex items-center p-2 bg-white rounded-md border border-gray-200">
                                              <FileCheck className="w-4 h-4 text-green-600 mr-2" />
                                              <span>{prescricao}</span>
                                              <Button variant="ghost" size="icon" className="ml-2">
                                                <Eye className="w-4 h-4" />
                                              </Button>
                                            </div>
                                          ))}
                                        </div>
                                      </div>
                                    ) : (
                                      <div className="text-center py-8 text-gray-500">
                                        <FileWarning className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                                        <p>Nenhuma prescrição ativa encontrada para este associado.</p>
                                      </div>
                                    )}
                                  </div>
                                </TabsContent>
                                
                                <TabsContent value="pedidos">
                                  <div className="space-y-4">
                                    <div className="flex justify-between items-center">
                                      <h3 className="font-medium">Histórico de Pedidos</h3>
                                      <Link to={createPageUrl("Pedidos")}>
                                        <Button variant="outline" size="sm" className="gap-2">
                                          <ShoppingBag className="w-4 h-4" />
                                          Ver Todos os Pedidos
                                        </Button>
                                      </Link>
                                    </div>
                                    
                                    <div className="text-center py-8 text-gray-500">
                                      <ShoppingBag className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                                      <p>Histórico de pedidos não disponível neste momento.</p>
                                      <p className="text-sm mt-2">Acesse a seção de pedidos para mais detalhes.</p>
                                    </div>
                                  </div>
                                </TabsContent>
                              </Tabs>
                            </>
                          )}
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
          
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-500">
              Mostrando {filteredAssociados.length} de {associados.length} associados
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled>Anterior</Button>
              <Button variant="outline" size="sm" disabled>Próximo</Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
