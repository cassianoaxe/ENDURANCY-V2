import React, { useState } from 'react';
import { 
  CheckSquare, 
  ArrowLeft, 
  Save, 
  Plus, 
  Trash2, 
  Calendar,
  FileCheck,
  Upload,
  HelpCircle
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export default function ProducaoQualidadeNovaAnalise() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("info");
  const [formData, setFormData] = useState({
    produto: "",
    lote: "",
    tipoAnalise: "",
    dataSolicitacao: "",
    prioridade: "normal",
    observacoes: "",
    amostras: [{ id: 1, descricao: "", quantidade: "", unidade: "" }],
    testes: [{ id: 1, nome: "", metodo: "", especificacao: "", resultado: "" }]
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleAmostraChange = (id, field, value) => {
    const updatedAmostras = formData.amostras.map(amostra => 
      amostra.id === id ? { ...amostra, [field]: value } : amostra
    );
    setFormData({
      ...formData,
      amostras: updatedAmostras
    });
  };

  const handleTesteChange = (id, field, value) => {
    const updatedTestes = formData.testes.map(teste => 
      teste.id === id ? { ...teste, [field]: value } : teste
    );
    setFormData({
      ...formData,
      testes: updatedTestes
    });
  };

  const addAmostra = () => {
    const newId = formData.amostras.length > 0 
      ? Math.max(...formData.amostras.map(a => a.id)) + 1 
      : 1;
    setFormData({
      ...formData,
      amostras: [...formData.amostras, { id: newId, descricao: "", quantidade: "", unidade: "" }]
    });
  };

  const removeAmostra = (id) => {
    if (formData.amostras.length > 1) {
      setFormData({
        ...formData,
        amostras: formData.amostras.filter(amostra => amostra.id !== id)
      });
    }
  };

  const addTeste = () => {
    const newId = formData.testes.length > 0 
      ? Math.max(...formData.testes.map(t => t.id)) + 1 
      : 1;
    setFormData({
      ...formData,
      testes: [...formData.testes, { id: newId, nome: "", metodo: "", especificacao: "", resultado: "" }]
    });
  };

  const removeTeste = (id) => {
    if (formData.testes.length > 1) {
      setFormData({
        ...formData,
        testes: formData.testes.filter(teste => teste.id !== id)
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Dados da análise:", formData);
    
    // Simulando submissão bem-sucedida
    setTimeout(() => {
      navigate(createPageUrl("ProducaoQualidade"));
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Link to={createPageUrl("ProducaoQualidade")}>
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Nova Análise de Qualidade</h1>
            <p className="text-muted-foreground">
              Registre uma nova solicitação de análise para o controle de qualidade
            </p>
          </div>
        </div>

        <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
          <Save className="w-4 h-4 mr-2" />
          Salvar Análise
        </Button>
      </div>

      <Card>
        <CardHeader>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="info">Informações Gerais</TabsTrigger>
              <TabsTrigger value="amostras">Amostras</TabsTrigger>
              <TabsTrigger value="testes">Testes</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit}>
            <TabsContent value="info" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="produto">Produto/Material</Label>
                  <Select 
                    name="produto" 
                    value={formData.produto} 
                    onValueChange={(value) => handleSelectChange("produto", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o produto ou material" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PCBD-10">Óleo CBD 10%</SelectItem>
                      <SelectItem value="PCBD-20">Óleo CBD 20%</SelectItem>
                      <SelectItem value="CAPS-CBD">Cápsulas CBD</SelectItem>
                      <SelectItem value="MP-CBD">Matéria-Prima: CBD Isolado</SelectItem>
                      <SelectItem value="MP-THC">Matéria-Prima: THC</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="lote">Número do Lote</Label>
                  <Input 
                    name="lote" 
                    value={formData.lote} 
                    onChange={handleChange} 
                    placeholder="Informe o número do lote"
                  />
                </div>

                <div>
                  <Label htmlFor="tipoAnalise">Tipo de Análise</Label>
                  <Select 
                    name="tipoAnalise" 
                    value={formData.tipoAnalise} 
                    onValueChange={(value) => handleSelectChange("tipoAnalise", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo de análise" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="completa">Análise Completa</SelectItem>
                      <SelectItem value="microbiologica">Análise Microbiológica</SelectItem>
                      <SelectItem value="fisico-quimica">Análise Físico-Química</SelectItem>
                      <SelectItem value="potencia">Análise de Potência</SelectItem>
                      <SelectItem value="residuos">Análise de Resíduos</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="dataSolicitacao">Data de Solicitação</Label>
                  <div className="relative">
                    <Input 
                      type="date" 
                      name="dataSolicitacao" 
                      value={formData.dataSolicitacao} 
                      onChange={handleChange} 
                    />
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="prioridade">Prioridade</Label>
                  <Select 
                    name="prioridade" 
                    value={formData.prioridade} 
                    onValueChange={(value) => handleSelectChange("prioridade", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a prioridade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="baixa">Baixa</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="alta">Alta</SelectItem>
                      <SelectItem value="urgente">Urgente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea 
                    name="observacoes" 
                    value={formData.observacoes} 
                    onChange={handleChange} 
                    placeholder="Informações adicionais sobre a análise"
                    className="min-h-[100px]"
                  />
                </div>

                <div className="md:col-span-2 flex gap-4 mt-4">
                  <Button variant="outline" type="button" className="gap-2">
                    <Upload className="w-4 h-4" />
                    Anexar Documentos
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="amostras" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Amostras para Análise</h3>
                <Button 
                  type="button" 
                  onClick={addAmostra} 
                  variant="outline" 
                  size="sm" 
                  className="gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Adicionar Amostra
                </Button>
              </div>

              {formData.amostras.map((amostra, index) => (
                <Card key={amostra.id} className="border border-gray-200 dark:border-gray-700">
                  <CardHeader className="py-4 flex flex-row items-center justify-between">
                    <CardTitle className="text-base">Amostra {index + 1}</CardTitle>
                    <Button 
                      type="button" 
                      onClick={() => removeAmostra(amostra.id)} 
                      variant="ghost" 
                      size="sm" 
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </CardHeader>
                  <CardContent className="py-2 grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="col-span-full sm:col-span-2">
                      <Label htmlFor={`amostra-descricao-${amostra.id}`}>Descrição da Amostra</Label>
                      <Input 
                        id={`amostra-descricao-${amostra.id}`}
                        value={amostra.descricao} 
                        onChange={(e) => handleAmostraChange(amostra.id, "descricao", e.target.value)} 
                        placeholder="Descreva a amostra"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label htmlFor={`amostra-quantidade-${amostra.id}`}>Quantidade</Label>
                        <Input 
                          id={`amostra-quantidade-${amostra.id}`}
                          type="number" 
                          value={amostra.quantidade} 
                          onChange={(e) => handleAmostraChange(amostra.id, "quantidade", e.target.value)} 
                          placeholder="Qtd."
                        />
                      </div>
                      <div>
                        <Label htmlFor={`amostra-unidade-${amostra.id}`}>Unidade</Label>
                        <Select 
                          value={amostra.unidade} 
                          onValueChange={(value) => handleAmostraChange(amostra.id, "unidade", value)}
                        >
                          <SelectTrigger id={`amostra-unidade-${amostra.id}`}>
                            <SelectValue placeholder="Un." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="g">g</SelectItem>
                            <SelectItem value="ml">ml</SelectItem>
                            <SelectItem value="un">un</SelectItem>
                            <SelectItem value="L">L</SelectItem>
                            <SelectItem value="kg">kg</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="testes" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Testes a Realizar</h3>
                <Button 
                  type="button" 
                  onClick={addTeste} 
                  variant="outline" 
                  size="sm" 
                  className="gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Adicionar Teste
                </Button>
              </div>

              {formData.testes.map((teste, index) => (
                <Card key={teste.id} className="border border-gray-200 dark:border-gray-700">
                  <CardHeader className="py-4 flex flex-row items-center justify-between">
                    <CardTitle className="text-base">Teste {index + 1}</CardTitle>
                    <Button 
                      type="button" 
                      onClick={() => removeTeste(teste.id)} 
                      variant="ghost" 
                      size="sm" 
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </CardHeader>
                  <CardContent className="py-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor={`teste-nome-${teste.id}`}>Nome do Teste</Label>
                      <Input 
                        id={`teste-nome-${teste.id}`}
                        value={teste.nome} 
                        onChange={(e) => handleTesteChange(teste.id, "nome", e.target.value)} 
                        placeholder="Nome do teste"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`teste-metodo-${teste.id}`}>Método</Label>
                      <Input 
                        id={`teste-metodo-${teste.id}`}
                        value={teste.metodo} 
                        onChange={(e) => handleTesteChange(teste.id, "metodo", e.target.value)} 
                        placeholder="Método utilizado"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`teste-especificacao-${teste.id}`}>Especificação</Label>
                      <Input 
                        id={`teste-especificacao-${teste.id}`}
                        value={teste.especificacao} 
                        onChange={(e) => handleTesteChange(teste.id, "especificacao", e.target.value)} 
                        placeholder="Especificação de referência"
                      />
                      <div className="text-xs text-gray-500 mt-1 flex items-center">
                        <HelpCircle className="w-3 h-3 mr-1" />
                        Ex: 18% - 22% ou "Ausente"
                      </div>
                    </div>
                    <div>
                      <Label htmlFor={`teste-resultado-${teste.id}`}>Resultado Esperado</Label>
                      <Select 
                        value={teste.resultado} 
                        onValueChange={(value) => handleTesteChange(teste.id, "resultado", value)}
                      >
                        <SelectTrigger id={`teste-resultado-${teste.id}`}>
                          <SelectValue placeholder="Resultado esperado" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="conforme">Conforme</SelectItem>
                          <SelectItem value="nao_aplicavel">Não Aplicável</SelectItem>
                          <SelectItem value="valor_numerico">Valor Numérico</SelectItem>
                          <SelectItem value="presente_ausente">Presente/Ausente</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </form>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => navigate(createPageUrl("ProducaoQualidade"))}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
            <Save className="w-4 h-4 mr-2" />
            Salvar Análise
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}