import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Separator } from "@/components/ui/separator";
import { 
  ChevronLeft, 
  Plus, 
  Trash,
  Save,
  FileText,
  Pencil,
  AlertTriangle,
  Check
} from "lucide-react";

export default function CatalogoNovoProduto() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("geral");
  const [materiasPrimas, setMateriasPrimas] = useState([]);
  const [salvoConcluido, setSalvoConcluido] = useState(false);

  const [formData, setFormData] = useState({
    codigo: "",
    nome: "",
    descricao: "",
    categoria: "",
    status: "em_desenvolvimento",
    especificacoes_tecnicas: {
      concentracao_cbd: "",
      concentracao_thc: "",
      volume_final: ""
    },
    componentes: [],
    processo_produtivo: [
      { etapa: "Preparação", descricao: "", tempo_estimado: 0, controles_necessarios: [] },
      { etapa: "Mistura", descricao: "", tempo_estimado: 0, controles_necessarios: [] },
      { etapa: "Envase", descricao: "", tempo_estimado: 0, controles_necessarios: [] },
      { etapa: "Rotulagem", descricao: "", tempo_estimado: 0, controles_necessarios: [] },
      { etapa: "Embalagem", descricao: "", tempo_estimado: 0, controles_necessarios: [] }
    ],
    documentos_relacionados: []
  });

  useEffect(() => {
    // Simular carregamento de matérias-primas
    const timer = setTimeout(() => {
      const mockMateriasPrimas = [
        { id: "MP001", nome: "Extrato CBD Full Spectrum", tipo: "principio_ativo", unidade_medida: "ml" },
        { id: "MP002", nome: "Extrato CBD Isolado", tipo: "principio_ativo", unidade_medida: "g" },
        { id: "MP003", nome: "Óleo MCT", tipo: "excipiente", unidade_medida: "ml" },
        { id: "MP004", nome: "Óleo de Coco", tipo: "excipiente", unidade_medida: "ml" },
        { id: "MP005", nome: "Óleo de Semente de Cânhamo", tipo: "excipiente", unidade_medida: "ml" },
        { id: "MP006", nome: "Frasco Âmbar 30ml", tipo: "embalagem_primaria", unidade_medida: "unidade" },
        { id: "MP007", nome: "Frasco Âmbar 50ml", tipo: "embalagem_primaria", unidade_medida: "unidade" },
        { id: "MP008", nome: "Conta-gotas Standard", tipo: "embalagem_primaria", unidade_medida: "unidade" },
        { id: "MP009", nome: "Rótulo Óleo 10%", tipo: "rotulo", unidade_medida: "unidade" },
        { id: "MP010", nome: "Rótulo Óleo 5%", tipo: "rotulo", unidade_medida: "unidade" },
        { id: "MP011", nome: "Caixa Individual Pequena", tipo: "embalagem_secundaria", unidade_medida: "unidade" },
        { id: "MP012", nome: "Caixa Individual Grande", tipo: "embalagem_secundaria", unidade_medida: "unidade" },
        { id: "MP013", nome: "Bula Standard", tipo: "embalagem_secundaria", unidade_medida: "unidade" }
      ];
      setMateriasPrimas(mockMateriasPrimas);
    }, 500);
    
    return () => clearTimeout(timer);
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleEspecificacoesChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      especificacoes_tecnicas: {
        ...formData.especificacoes_tecnicas,
        [name]: value
      }
    });
  };

  const handleAdicionarComponente = () => {
    const novoComponente = {
      material_id: "",
      nome: "",
      tipo: "",
      quantidade: "",
      unidade_medida: "",
      especificacoes: ""
    };
    
    setFormData({
      ...formData,
      componentes: [...formData.componentes, novoComponente]
    });
  };

  const handleRemoverComponente = (index) => {
    const novosComponentes = [...formData.componentes];
    novosComponentes.splice(index, 1);
    setFormData({
      ...formData,
      componentes: novosComponentes
    });
  };

  const handleComponenteChange = (index, campo, valor) => {
    const novosComponentes = [...formData.componentes];
    
    if (campo === 'material_id') {
      const materiaPrima = materiasPrimas.find(mp => mp.id === valor);
      if (materiaPrima) {
        novosComponentes[index] = {
          ...novosComponentes[index],
          material_id: valor,
          nome: materiaPrima.nome,
          tipo: materiaPrima.tipo,
          unidade_medida: materiaPrima.unidade_medida
        };
      }
    } else {
      novosComponentes[index] = {
        ...novosComponentes[index],
        [campo]: valor
      };
    }
    
    setFormData({
      ...formData,
      componentes: novosComponentes
    });
  };

  const handleEtapaChange = (index, campo, valor) => {
    const novasEtapas = [...formData.processo_produtivo];
    novasEtapas[index] = {
      ...novasEtapas[index],
      [campo]: valor
    };
    
    setFormData({
      ...formData,
      processo_produtivo: novasEtapas
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSaving(true);
    
    // Simulando salvamento
    setTimeout(() => {
      console.log("Produto salvo:", formData);
      setSaving(false);
      setSalvoConcluido(true);
      
      // Resetar mensagem após 3 segundos
      setTimeout(() => {
        setSalvoConcluido(false);
      }, 3000);
    }, 1500);
  };

  return (
    <div className="space-y-6 pb-10">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" onClick={() => navigate(createPageUrl("CatalogoProdutos"))}>
            <ChevronLeft className="h-4 w-4 mr-1" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold">Novo Produto</h1>
        </div>
        <div className="flex items-center gap-2">
          {salvoConcluido && (
            <div className="flex items-center text-green-600 bg-green-50 px-3 py-1 rounded-md">
              <Check className="h-4 w-4 mr-1" />
              <span>Produto salvo com sucesso!</span>
            </div>
          )}
          <Button 
            onClick={handleSubmit} 
            disabled={saving}
            className="bg-green-600 hover:bg-green-700"
          >
            <Save className="h-4 w-4 mr-2" />
            {saving ? "Salvando..." : "Salvar Produto"}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="geral" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="geral">Informações Gerais</TabsTrigger>
          <TabsTrigger value="componentes">Componentes</TabsTrigger>
          <TabsTrigger value="processo">Processo Produtivo</TabsTrigger>
          <TabsTrigger value="documentos">Documentos</TabsTrigger>
        </TabsList>
        
        <TabsContent value="geral">
          <Card>
            <CardHeader>
              <CardTitle>Informações Gerais</CardTitle>
              <CardDescription>Dados básicos do produto</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="codigo">Código do Produto *</Label>
                  <Input 
                    id="codigo" 
                    name="codigo" 
                    value={formData.codigo}
                    onChange={handleInputChange}
                    placeholder="Ex: OCBD10-FS"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome do Produto *</Label>
                  <Input 
                    id="nome" 
                    name="nome" 
                    value={formData.nome}
                    onChange={handleInputChange}
                    placeholder="Ex: Óleo CBD 10% Full Spectrum"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="categoria">Categoria *</Label>
                  <Select 
                    value={formData.categoria} 
                    onValueChange={(value) => setFormData({...formData, categoria: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="oleo">Óleo</SelectItem>
                      <SelectItem value="capsula">Cápsula</SelectItem>
                      <SelectItem value="topico">Tópico</SelectItem>
                      <SelectItem value="spray">Spray</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(value) => setFormData({...formData, status: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="em_desenvolvimento">Em Desenvolvimento</SelectItem>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                      <SelectItem value="descontinuado">Descontinuado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição</Label>
                <Textarea 
                  id="descricao" 
                  name="descricao" 
                  value={formData.descricao}
                  onChange={handleInputChange}
                  placeholder="Descrição detalhada do produto"
                  rows={4}
                />
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Especificações Técnicas</h3>
                <div className="grid grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="concentracao_cbd">Concentração de CBD (%)</Label>
                    <Input 
                      id="concentracao_cbd" 
                      name="concentracao_cbd" 
                      value={formData.especificacoes_tecnicas.concentracao_cbd}
                      onChange={handleEspecificacoesChange}
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="concentracao_thc">Concentração de THC (%)</Label>
                    <Input 
                      id="concentracao_thc" 
                      name="concentracao_thc" 
                      value={formData.especificacoes_tecnicas.concentracao_thc}
                      onChange={handleEspecificacoesChange}
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="volume_final">Volume/Quantidade Final</Label>
                    <Input 
                      id="volume_final" 
                      name="volume_final" 
                      value={formData.especificacoes_tecnicas.volume_final}
                      onChange={handleEspecificacoesChange}
                      type="number"
                      step="0.1"
                      min="0"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="componentes">
          <Card>
            <CardHeader>
              <CardTitle>Componentes do Produto</CardTitle>
              <CardDescription>Lista de matérias-primas e materiais necessários</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {formData.componentes.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    Nenhum componente adicionado ainda.
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Material</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Unidade</TableHead>
                        <TableHead>Especificações</TableHead>
                        <TableHead>Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {formData.componentes.map((componente, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <Select 
                              value={componente.material_id} 
                              onValueChange={(value) => handleComponenteChange(index, 'material_id', value)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione o material" />
                              </SelectTrigger>
                              <SelectContent>
                                {materiasPrimas.map((mp) => (
                                  <SelectItem key={mp.id} value={mp.id}>{mp.nome}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            {componente.tipo.replace('_', ' ').charAt(0).toUpperCase() + componente.tipo.replace('_', ' ').slice(1)}
                          </TableCell>
                          <TableCell>
                            <Input 
                              type="number" 
                              step="0.01" 
                              min="0"
                              value={componente.quantidade}
                              onChange={(e) => handleComponenteChange(index, 'quantidade', e.target.value)}
                            />
                          </TableCell>
                          <TableCell>
                            {componente.unidade_medida}
                          </TableCell>
                          <TableCell>
                            <Input 
                              placeholder="Especificações..."
                              value={componente.especificacoes}
                              onChange={(e) => handleComponenteChange(index, 'especificacoes', e.target.value)}
                            />
                          </TableCell>
                          <TableCell>
                            <Button 
                              variant="destructive" 
                              size="sm" 
                              onClick={() => handleRemoverComponente(index)}
                            >
                              <Trash className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
                
                <Button onClick={handleAdicionarComponente}>
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Componente
                </Button>
                
                <div className="mt-4">
                  <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-md">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="h-5 w-5 mt-0.5 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium mb-1">Importante:</h4>
                        <p className="text-sm">Os componentes adicionados aqui serão utilizados durante a produção para cálculo automático de consumo de estoque e reserva de materiais.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="processo">
          <Card>
            <CardHeader>
              <CardTitle>Processo Produtivo</CardTitle>
              <CardDescription>Etapas do processo de produção</CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="multiple" className="w-full">
                {formData.processo_produtivo.map((etapa, index) => (
                  <AccordionItem key={index} value={`etapa-${index}`}>
                    <AccordionTrigger>
                      <span className="font-medium">{etapa.etapa}</span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 p-2">
                        <div className="space-y-2">
                          <Label>Descrição da Etapa</Label>
                          <Textarea 
                            value={etapa.descricao}
                            onChange={(e) => handleEtapaChange(index, 'descricao', e.target.value)}
                            placeholder="Descreva detalhadamente esta etapa do processo..."
                            rows={3}
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label>Tempo Estimado (minutos)</Label>
                          <Input 
                            type="number"
                            min="0"
                            value={etapa.tempo_estimado}
                            onChange={(e) => handleEtapaChange(index, 'tempo_estimado', e.target.value)}
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label>Controles Necessários</Label>
                          <Textarea 
                            value={etapa.controles_necessarios.join(', ')}
                            onChange={(e) => handleEtapaChange(index, 'controles_necessarios', e.target.value.split(', '))}
                            placeholder="Listar controles necessários separados por vírgula"
                            rows={2}
                          />
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="documentos">
          <Card>
            <CardHeader>
              <CardTitle>Documentos Relacionados</CardTitle>
              <CardDescription>Procedimentos, especificações e outros documentos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12 text-gray-500">
                <FileText className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                <h3 className="text-lg font-medium mb-2">Nenhum documento anexado</h3>
                <p className="text-sm mb-4">
                  Anexe documentos relacionados ao produto como fórmulas padrão, procedimentos de produção, etc.
                </p>
                <Button variant="outline">
                  <Plus className="h-4 w-4 mr-2" />
                  Anexar Documento
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}