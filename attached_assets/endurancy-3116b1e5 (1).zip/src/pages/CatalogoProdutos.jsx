import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Plus, 
  Search, 
  Filter,
  MoreHorizontal,
  Eye,
  Edit,
  Trash,
  FileText,
  Package,
  Beaker,
  AlertTriangle
} from "lucide-react";

export default function CatalogoProdutos() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [produtos, setProdutos] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategoria, setFilterCategoria] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  useEffect(() => {
    // Simular carregamento de dados
    const timer = setTimeout(() => {
      const mockProdutos = [
        {
          id: "PROD001",
          codigo: "OCBD10-FS",
          nome: "Óleo CBD 10% Full Spectrum",
          categoria: "oleo",
          status: "ativo",
          especificacoes_tecnicas: {
            concentracao_cbd: 10,
            concentracao_thc: 0.2,
            volume_final: 30
          },
          componentes: [
            {
              nome: "Extrato CBD Full Spectrum",
              tipo: "principio_ativo",
              quantidade: 3,
              unidade_medida: "ml"
            },
            {
              nome: "Óleo MCT",
              tipo: "excipiente",
              quantidade: 27,
              unidade_medida: "ml"
            },
            {
              nome: "Frasco Âmbar 30ml",
              tipo: "embalagem_primaria",
              quantidade: 1,
              unidade_medida: "unidade"
            },
            {
              nome: "Conta-gotas",
              tipo: "embalagem_primaria",
              quantidade: 1,
              unidade_medida: "unidade"
            },
            {
              nome: "Rótulo OCBD10-FS",
              tipo: "rotulo",
              quantidade: 1,
              unidade_medida: "unidade"
            },
            {
              nome: "Caixa Individual",
              tipo: "embalagem_secundaria",
              quantidade: 1,
              unidade_medida: "unidade"
            }
          ]
        },
        {
          id: "PROD002",
          codigo: "CCBD25",
          nome: "Cápsulas CBD 25mg",
          categoria: "capsula",
          status: "ativo",
          especificacoes_tecnicas: {
            concentracao_cbd: 25,
            concentracao_thc: 0.1,
            volume_final: 30
          },
          componentes: []
        },
        {
          id: "PROD003",
          codigo: "SCBD5",
          nome: "Spray CBD 5%",
          categoria: "spray",
          status: "em_desenvolvimento",
          especificacoes_tecnicas: {
            concentracao_cbd: 5,
            concentracao_thc: 0.1,
            volume_final: 20
          },
          componentes: []
        },
        {
          id: "PROD004",
          codigo: "PCBD2",
          nome: "Pomada CBD 2%",
          categoria: "topico",
          status: "ativo",
          especificacoes_tecnicas: {
            concentracao_cbd: 2,
            concentracao_thc: 0.05,
            volume_final: 50
          },
          componentes: []
        }
      ];

      setProdutos(mockProdutos);
      setLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const handleNovoProduto = () => {
    navigate(createPageUrl("CatalogoNovoProduto"));
  };

  const handleVerProduto = (id) => {
    navigate(createPageUrl(`CatalogoDetalhesProduto?id=${id}`));
  };

  const filteredProdutos = produtos.filter(produto => {
    const matchesSearch = produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         produto.codigo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategoria = filterCategoria === "all" || produto.categoria === filterCategoria;
    const matchesStatus = filterStatus === "all" || produto.status === filterStatus;

    return matchesSearch && matchesCategoria && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Catálogo de Produtos</h1>
          <p className="text-gray-500 mt-1">
            Gerenciamento de especificações e componentes dos produtos
          </p>
        </div>
        <Button onClick={handleNovoProduto}>
          <Plus className="mr-2 h-4 w-4" />
          Novo Produto
        </Button>
      </div>

      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar produtos..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <Select value={filterCategoria} onValueChange={setFilterCategoria}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as categorias</SelectItem>
            <SelectItem value="oleo">Óleos</SelectItem>
            <SelectItem value="capsula">Cápsulas</SelectItem>
            <SelectItem value="topico">Tópicos</SelectItem>
            <SelectItem value="spray">Sprays</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os status</SelectItem>
            <SelectItem value="ativo">Ativos</SelectItem>
            <SelectItem value="inativo">Inativos</SelectItem>
            <SelectItem value="em_desenvolvimento">Em Desenvolvimento</SelectItem>
            <SelectItem value="descontinuado">Descontinuados</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      ) : filteredProdutos.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center h-64">
            <Package className="h-12 w-12 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum produto encontrado</h3>
            <p className="text-sm text-gray-500 mb-4">
              {searchTerm || filterCategoria !== "all" || filterStatus !== "all"
                ? "Tente ajustar os filtros para ver mais resultados"
                : "Comece adicionando um novo produto ao catálogo"}
            </p>
            <Button onClick={handleNovoProduto}>
              <Plus className="mr-2 h-4 w-4" />
              Novo Produto
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6">
          {filteredProdutos.map((produto) => (
            <Card key={produto.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-medium">
                  {produto.nome}
                </CardTitle>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleVerProduto(produto.id)}>
                      <Eye className="mr-2 h-4 w-4" />
                      Ver detalhes
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Edit className="mr-2 h-4 w-4" />
                      Editar
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-red-600">
                      <Trash className="mr-2 h-4 w-4" />
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline">{produto.codigo}</Badge>
                      <Badge 
                        className={
                          produto.status === 'ativo' ? 'bg-green-100 text-green-800' :
                          produto.status === 'inativo' ? 'bg-gray-100 text-gray-800' :
                          produto.status === 'em_desenvolvimento' ? 'bg-blue-100 text-blue-800' :
                          'bg-red-100 text-red-800'
                        }
                      >
                        {produto.status.replace('_', ' ').charAt(0).toUpperCase() + produto.status.slice(1)}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <Beaker className="h-4 w-4" />
                      <span>{produto.especificacoes_tecnicas.concentracao_cbd}% CBD</span>
                      <span>|</span>
                      <span>{produto.especificacoes_tecnicas.volume_final}ml</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-gray-500">Componentes principais</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {produto.componentes && produto.componentes.length > 0 ? (
                        produto.componentes.map((componente, index) => (
                          <div key={index} className="text-sm">
                            {componente.nome} ({componente.quantidade} {componente.unidade_medida})
                          </div>
                        ))
                      ) : (
                        <div className="text-sm text-gray-400 col-span-2">
                          Componentes não definidos
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}