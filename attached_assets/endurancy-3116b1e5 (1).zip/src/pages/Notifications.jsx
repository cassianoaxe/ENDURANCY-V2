
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  Bell,
  AlertTriangle,
  MessageSquare,
  InfoIcon,
  CheckCircle2,
  Shield,
  X,
  Filter,
  Search,
  MoreHorizontal,
  Calendar,
  User,
  Building2,
  Trash2,
  Check,
  Clock,
  Settings,
  EyeOff
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Sample notifications data
const notificationsData = [
  {
    id: 1,
    type: "alert",
    title: "Tentativa de login suspeita",
    message: "Detectamos uma tentativa de login em sua conta a partir de um local desconhecido.",
    timestamp: "2023-07-22T09:30:00Z",
    isRead: false,
    priority: "high",
    related: {
      type: "security",
      id: "auth_123"
    }
  },
  {
    id: 2,
    type: "request",
    title: "Nova solicitação de organização",
    message: "A organização 'CannaPesquisa Instituto' solicitou acesso à plataforma.",
    timestamp: "2023-07-22T08:15:00Z",
    isRead: false,
    priority: "medium",
    related: {
      type: "organization",
      id: "org_456"
    }
  },
  {
    id: 3,
    type: "info",
    title: "Novos recursos disponíveis",
    message: "Novos recursos de relatório foram adicionados à plataforma.",
    timestamp: "2023-07-21T16:45:00Z",
    isRead: false,
    priority: "low",
    related: {
      type: "system",
      id: "update_789"
    }
  },
  {
    id: 4,
    type: "success",
    title: "Backup concluído com sucesso",
    message: "O backup automático diário do sistema foi concluído com sucesso.",
    timestamp: "2023-07-21T03:00:00Z",
    isRead: true,
    priority: "low",
    related: {
      type: "system",
      id: "backup_234"
    }
  },
  {
    id: 5,
    type: "message",
    title: "Nova mensagem de suporte",
    message: "A organização 'MediCannabis Farma' enviou uma nova mensagem de suporte.",
    timestamp: "2023-07-20T14:20:00Z",
    isRead: true,
    priority: "medium",
    related: {
      type: "support",
      id: "ticket_567"
    }
  },
  {
    id: 6,
    type: "alert",
    title: "Certificado SSL expirando",
    message: "O certificado SSL da plataforma irá expirar em 7 dias.",
    timestamp: "2023-07-20T10:15:00Z",
    isRead: true,
    priority: "high",
    related: {
      type: "security",
      id: "ssl_890"
    }
  },
  {
    id: 7,
    type: "request",
    title: "Nova solicitação de organização",
    message: "A organização 'Green Medical Brasil' solicitou acesso à plataforma.",
    timestamp: "2023-07-19T09:30:00Z",
    isRead: true,
    priority: "medium",
    related: {
      type: "organization",
      id: "org_123"
    }
  },
  {
    id: 8,
    type: "info",
    title: "Manutenção programada",
    message: "Uma manutenção está programada para 25/07/2023 às 02:00.",
    timestamp: "2023-07-18T16:00:00Z",
    isRead: true,
    priority: "medium",
    related: {
      type: "system",
      id: "maintenance_456"
    }
  },
  {
    id: 9,
    type: "success",
    title: "Solicitação aprovada",
    message: "Você aprovou a solicitação de 'Cannabis Brasil Medicinal'.",
    timestamp: "2023-07-17T11:45:00Z",
    isRead: true,
    priority: "low",
    related: {
      type: "organization",
      id: "org_789"
    }
  },
  {
    id: 10,
    type: "message",
    title: "Resposta de suporte enviada",
    message: "Sua resposta ao ticket de suporte #1234 foi enviada com sucesso.",
    timestamp: "2023-07-16T14:30:00Z",
    isRead: true,
    priority: "low",
    related: {
      type: "support",
      id: "ticket_123"
    }
  }
];

export default function Notifications() {
  const [notifications, setNotifications] = useState(notificationsData);
  const [filter, setFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [showSettingsDialog, setShowSettingsDialog] = useState(false);
  const [notificationsSettings, setNotificationsSettings] = useState({
    pushNotifications: true,
    emailNotifications: true,
    smsNotifications: false,
    browserNotifications: true,
    soundAlerts: true,
    securityAlerts: true,
    systemUpdates: true,
    supportTickets: true,
    organizationRequests: true,
    dailySummary: false,
    weeklySummary: true
  });
  
  const markAsRead = (id) => {
    setNotifications(notifications.map(notification => 
      notification.id === id ? { ...notification, isRead: true } : notification
    ));
  };
  
  const markAllAsRead = () => {
    setNotifications(notifications.map(notification => ({ ...notification, isRead: true })));
  };
  
  const deleteNotification = (id) => {
    setNotifications(notifications.filter(notification => notification.id !== id));
  };
  
  const clearAllNotifications = () => {
    setNotifications([]);
  };
  
  const filteredNotifications = notifications.filter(notification => {
    if (filter !== "all" && notification.type !== filter) {
      return false;
    }
    
    if (searchTerm && 
        !notification.title.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !notification.message.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    return true;
  });
  
  const unreadCount = notifications.filter(notification => !notification.isRead).length;
  
  const getNotificationIcon = (type) => {
    switch(type) {
      case "alert": return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case "request": return <User className="w-5 h-5 text-blue-500" />;
      case "info": return <InfoIcon className="w-5 h-5 text-indigo-500" />;
      case "success": return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case "message": return <MessageSquare className="w-5 h-5 text-purple-500" />;
      default: return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 60) {
      return `${diffMins} ${diffMins === 1 ? 'minuto' : 'minutos'} atrás`;
    } else if (diffHours < 24) {
      return `${diffHours} ${diffHours === 1 ? 'hora' : 'horas'} atrás`;
    } else if (diffDays < 7) {
      return `${diffDays} ${diffDays === 1 ? 'dia' : 'dias'} atrás`;
    } else {
      return new Intl.DateTimeFormat('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      }).format(date);
    }
  };
  
  const getRelatedIcon = (related) => {
    switch(related.type) {
      case "security": return <Shield className="w-4 h-4 text-red-500" />;
      case "organization": return <Building2 className="w-4 h-4 text-blue-500" />;
      case "system": return <Settings className="w-4 h-4 text-gray-500" />;
      case "support": return <MessageSquare className="w-4 h-4 text-purple-500" />;
      default: return <InfoIcon className="w-4 h-4 text-gray-500" />;
    }
  };
  
  const updateNotificationSetting = (key, value) => {
    setNotificationsSettings({
      ...notificationsSettings,
      [key]: value
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Notificações</h1>
          <p className="text-gray-500 mt-1">
            Gerencie suas notificações e alertas do sistema
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline"
            className="gap-2"
            onClick={() => setShowSettingsDialog(true)}
          >
            <Settings className="w-4 h-4" />
            Configurações
          </Button>
          {unreadCount > 0 && (
            <Button
              variant="outline"
              className="gap-2"
              onClick={markAllAsRead}
            >
              <Check className="w-4 h-4" />
              Marcar todas como lidas
            </Button>
          )}
        </div>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4">
        <div className="w-full md:w-60 space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar notificações..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="py-4 px-4">
              <CardTitle className="text-sm font-medium">Filtros</CardTitle>
            </CardHeader>
            <CardContent className="px-2 py-0">
              <div className="space-y-1">
                <Button
                  variant={filter === "all" ? "default" : "ghost"}
                  className="w-full justify-start gap-2"
                  onClick={() => setFilter("all")}
                >
                  <Bell className="w-4 h-4" />
                  Todas
                  {unreadCount > 0 && (
                    <span className="ml-auto bg-red-100 text-red-600 text-xs rounded-full px-2 py-0.5">
                      {unreadCount}
                    </span>
                  )}
                </Button>
                <Button
                  variant={filter === "alert" ? "default" : "ghost"}
                  className="w-full justify-start gap-2"
                  onClick={() => setFilter("alert")}
                >
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                  Alertas
                </Button>
                <Button
                  variant={filter === "request" ? "default" : "ghost"}
                  className="w-full justify-start gap-2"
                  onClick={() => setFilter("request")}
                >
                  <User className="w-4 h-4 text-blue-500" />
                  Solicitações
                </Button>
                <Button
                  variant={filter === "message" ? "default" : "ghost"}
                  className="w-full justify-start gap-2"
                  onClick={() => setFilter("message")}
                >
                  <MessageSquare className="w-4 h-4 text-purple-500" />
                  Mensagens
                </Button>
                <Button
                  variant={filter === "info" ? "default" : "ghost"}
                  className="w-full justify-start gap-2"
                  onClick={() => setFilter("info")}
                >
                  <InfoIcon className="w-4 h-4 text-indigo-500" />
                  Informações
                </Button>
                <Button
                  variant={filter === "success" ? "default" : "ghost"}
                  className="w-full justify-start gap-2"
                  onClick={() => setFilter("success")}
                >
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  Sucessos
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="flex-1">
          <Card>
            <CardHeader className="py-4 px-6 flex flex-row items-center justify-between">
              <CardTitle>
                {filter === "all" ? "Todas as Notificações" : 
                 filter === "alert" ? "Alertas" :
                 filter === "request" ? "Solicitações" :
                 filter === "message" ? "Mensagens" :
                 filter === "info" ? "Informações" : "Sucessos"}
              </CardTitle>
              {notifications.length > 0 && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="w-5 h-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={markAllAsRead}>
                      <Check className="w-4 h-4 mr-2" />
                      Marcar todas como lidas
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={clearAllNotifications} className="text-red-600">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Limpar todas notificações
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </CardHeader>
            
            <ScrollArea className="h-[calc(100vh-300px)]">
              <CardContent className="p-0">
                {filteredNotifications.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
                    <Bell className="w-12 h-12 text-gray-300 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-1">Sem notificações</h3>
                    <p className="text-gray-500 max-w-md">
                      {searchTerm 
                        ? `Não há notificações correspondentes ao termo "${searchTerm}"`
                        : "Você não tem notificações nesta categoria no momento."}
                    </p>
                  </div>
                ) : (
                  <div>
                    {filteredNotifications.map((notification) => (
                      <div 
                        key={notification.id} 
                        className={`border-b last:border-b-0 px-6 py-4 ${notification.isRead ? '' : 'bg-blue-50'}`}
                      >
                        <div className="flex gap-4">
                          <div className="shrink-0 bg-white p-2 rounded-full shadow-sm mt-1">
                            {getNotificationIcon(notification.type)}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-start justify-between gap-4">
                              <div>
                                <h3 className="font-medium text-gray-900">{notification.title}</h3>
                                <p className="text-gray-600 mt-1">{notification.message}</p>
                              </div>
                              
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-gray-500 whitespace-nowrap">
                                  {formatDate(notification.timestamp)}
                                </span>
                                
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="icon" className="h-8 w-8">
                                      <MoreHorizontal className="w-4 h-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    {!notification.isRead && (
                                      <DropdownMenuItem onClick={() => markAsRead(notification.id)}>
                                        <Check className="w-4 h-4 mr-2" />
                                        Marcar como lida
                                      </DropdownMenuItem>
                                    )}
                                    <DropdownMenuItem>
                                      <EyeOff className="w-4 h-4 mr-2" />
                                      Desativar este tipo
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem 
                                      onClick={() => deleteNotification(notification.id)}
                                      className="text-red-600"
                                    >
                                      <Trash2 className="w-4 h-4 mr-2" />
                                      Remover
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-4 mt-2">
                              <div className="flex items-center gap-1 text-xs text-gray-500">
                                {getRelatedIcon(notification.related)}
                                <span>
                                  {notification.related.type === 'security' ? 'Segurança' : 
                                   notification.related.type === 'organization' ? 'Organização' :
                                   notification.related.type === 'system' ? 'Sistema' : 'Suporte'}
                                </span>
                              </div>
                              
                              <div className="flex items-center gap-1 text-xs">
                                <Clock className="w-3 h-3 text-gray-400" />
                                <span className="text-gray-500">
                                  {new Date(notification.timestamp).toLocaleTimeString('pt-BR', {
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })}
                                </span>
                              </div>
                              
                              {notification.priority === 'high' && (
                                <span className="text-xs px-2 py-0.5 bg-red-100 text-red-800 rounded-full">
                                  Alta prioridade
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </ScrollArea>
          </Card>
        </div>
      </div>
      
      {/* Notification Settings Dialog */}
      <Dialog open={showSettingsDialog} onOpenChange={setShowSettingsDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Configurações de Notificações</DialogTitle>
          </DialogHeader>
          
          <div className="py-4 space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-900">Canais de Notificação</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="push-notifications" className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-gray-500" />
                    Notificações no aplicativo
                  </Label>
                  <Switch 
                    id="push-notifications" 
                    checked={notificationsSettings.pushNotifications}
                    onCheckedChange={(checked) => updateNotificationSetting('pushNotifications', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="email-notifications" className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-gray-500" />
                    Notificações por email
                  </Label>
                  <Switch 
                    id="email-notifications" 
                    checked={notificationsSettings.emailNotifications}
                    onCheckedChange={(checked) => updateNotificationSetting('emailNotifications', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="sms-notifications" className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-gray-500" />
                    Notificações por SMS
                  </Label>
                  <Switch 
                    id="sms-notifications" 
                    checked={notificationsSettings.smsNotifications}
                    onCheckedChange={(checked) => updateNotificationSetting('smsNotifications', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="browser-notifications" className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-gray-500" />
                    Notificações do navegador
                  </Label>
                  <Switch 
                    id="browser-notifications" 
                    checked={notificationsSettings.browserNotifications}
                    onCheckedChange={(checked) => updateNotificationSetting('browserNotifications', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="sound-alerts" className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-gray-500" />
                    Alertas sonoros
                  </Label>
                  <Switch 
                    id="sound-alerts" 
                    checked={notificationsSettings.soundAlerts}
                    onCheckedChange={(checked) => updateNotificationSetting('soundAlerts', checked)}
                  />
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-900">Tipos de Notificação</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="security-alerts" className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-red-500" />
                    Alertas de segurança
                  </Label>
                  <Switch 
                    id="security-alerts" 
                    checked={notificationsSettings.securityAlerts}
                    onCheckedChange={(checked) => updateNotificationSetting('securityAlerts', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="system-updates" className="flex items-center gap-2">
                    <Settings className="w-4 h-4 text-gray-500" />
                    Atualizações do sistema
                  </Label>
                  <Switch 
                    id="system-updates" 
                    checked={notificationsSettings.systemUpdates}
                    onCheckedChange={(checked) => updateNotificationSetting('systemUpdates', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="support-tickets" className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-purple-500" />
                    Tickets de suporte
                  </Label>
                  <Switch 
                    id="support-tickets" 
                    checked={notificationsSettings.supportTickets}
                    onCheckedChange={(checked) => updateNotificationSetting('supportTickets', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="organization-requests" className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-blue-500" />
                    Solicitações de organizações
                  </Label>
                  <Switch 
                    id="organization-requests" 
                    checked={notificationsSettings.organizationRequests}
                    onCheckedChange={(checked) => updateNotificationSetting('organizationRequests', checked)}
                  />
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-900">Resumos</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="daily-summary" className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    Resumo diário
                  </Label>
                  <Switch 
                    id="daily-summary" 
                    checked={notificationsSettings.dailySummary}
                    onCheckedChange={(checked) => updateNotificationSetting('dailySummary', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="weekly-summary" className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    Resumo semanal
                  </Label>
                  <Switch 
                    id="weekly-summary" 
                    checked={notificationsSettings.weeklySummary}
                    onCheckedChange={(checked) => updateNotificationSetting('weeklySummary', checked)}
                  />
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button onClick={() => setShowSettingsDialog(false)}>Salvar Configurações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
