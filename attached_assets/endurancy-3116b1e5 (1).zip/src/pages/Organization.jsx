import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Building2, 
  Mail, 
  User, 
  Calendar, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ArrowLeft, 
  Edit, 
  Trash2, 
  UserPlus,
  Settings,
  Layers,
  FileText,
  Lock,
  Users,
  Leaf,
  Factory,
  Heart,
  Briefcase,
  Scale,
  Glasses,
  Plus,
  Check,
  X,
  MoreHorizontal
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

export default function Organization() {
  const [searchParams] = useSearchParams();
  const id = searchParams.get('id');
  
  const [organization, setOrganization] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('details');
  const [addModuleDialog, setAddModuleDialog] = useState(false);
  const [moduleToAdd, setModuleToAdd] = useState(null);
  const [selectedModulePlan, setSelectedModulePlan] = useState('basic');

  useEffect(() => {
    // Simular carregamento de dados da organização
    setTimeout(() => {
      setOrganization({
        id: id || "1",
        name: "Associação CannaVida",
        type: "Associação",
        contact_name: "Maria Silva",
        contact_email: "contato@cannavida.org.br",
        contact_phone: "(11) 98765-4321",
        address: "Rua das Flores, 123 - São Paulo, SP",
        plan: "Associação Premium",
        status: "Ativo",
        created_date: "2023-01-15",
        modules: [
          { id: "cultivo", name: "Cultivo", icon: "Leaf", active: true },
          { id: "crm", name: "CRM", icon: "Heart", active: true },
          { id: "transparencia", name: "Transparência", icon: "Glasses", active: true }
        ],
        users: [
          { id: "user1", name: "Maria Silva", email: "maria@cannavida.org.br", role: "Admin" },
          { id: "user2", name: "João Pereira", email: "joao@cannavida.org.br", role: "Gestor" },
          { id: "user3", name: "Ana Santos", email: "ana@cannavida.org.br", role: "Usuário" }
        ],
        associates: 128,
        patients: 342,
        products: 15
      });
      setLoading(false);
    }, 1000);
  }, [id]);

  const handleAddModule = () => {
    setAddModuleDialog(false);
    if (moduleToAdd) {
      setOrganization(prev => ({
        ...prev,
        modules: [
          ...prev.modules,
          { 
            id: moduleToAdd, 
            name: getModuleName(moduleToAdd), 
            icon: moduleToAdd, 
            active: true,
            plan: selectedModulePlan
          }
        ]
      }));
      setModuleToAdd(null);
      setSelectedModulePlan('basic');
    }
  };

  const getModuleName = (moduleId) => {
    const moduleNames = {
      "cultivo": "Cultivo",
      "producao": "Produção",
      "crm": "CRM",
      "rh": "RH",
      "juridico": "Jurídico",
      "transparencia": "Transparência"
    };
    return moduleNames[moduleId] || moduleId;
  }

  const toggleModuleStatus = (moduleId) => {
    setOrganization(prev => ({
      ...prev,
      modules: prev.modules.map(module => 
        module.id === moduleId 
          ? { ...module, active: !module.active } 
          : module
      )
    }));
  };

  const removeModule = (moduleId) => {
    setOrganization(prev => ({
      ...prev,
      modules: prev.modules.filter(module => module.id !== moduleId)
    }));
  };

  const getAvailableModules = () => {
    const currentModuleIds = organization?.modules.map(m => m.id) || [];
    
    const allModules = [
      { id: "cultivo", name: "Cultivo" },
      { id: "producao", name: "Produção" },
      { id: "crm", name: "CRM" },
      { id: "rh", name: "RH" },
      { id: "juridico", name: "Jurídico" },
      { id: "transparencia", name: "Transparência" }
    ];
    
    return allModules.filter(module => !currentModuleIds.includes(module.id));
  };

  const getModuleIcon = (iconName) => {
    switch(iconName) {
      case 'Leaf':
      case 'cultivo':
        return <Leaf className="w-5 h-5" />;
      case 'Factory':
      case 'producao':
        return <Factory className="w-5 h-5" />;
      case 'Heart':
      case 'crm':
        return <Heart className="w-5 h-5" />;
      case 'Briefcase':
      case 'rh':
        return <Briefcase className="w-5 h-5" />;
      case 'Scale':
      case 'juridico':
        return <Scale className="w-5 h-5" />;
      case 'Glasses':
      case 'transparencia':
        return <Glasses className="w-5 h-5" />;
      default:
        return <Building2 className="w-5 h-5" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[500px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">Carregando informações da organização...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link to={createPageUrl("Organizations")}>
              <ArrowLeft className="w-4 h-4 mr-1" />
              Voltar
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">{organization.name}</h1>
          <Badge className={
            organization.status === 'Ativo' ? 'bg-green-100 text-green-800' : 
            organization.status === 'Pendente' ? 'bg-yellow-100 text-yellow-800' : 
            'bg-red-100 text-red-800'
          }>
            {organization.status}
          </Badge>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Edit className="w-4 h-4 mr-1" />
            Editar
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                Ações
                <MoreHorizontal className="w-4 h-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <UserPlus className="w-4 h-4 mr-2" />
                Convidar usuário
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="w-4 h-4 mr-2" />
                Configurações
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600">
                <Trash2 className="w-4 h-4 mr-2" />
                Desativar organização
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="details">Detalhes</TabsTrigger>
          <TabsTrigger value="modules">Módulos</TabsTrigger>
          <TabsTrigger value="users">Usuários</TabsTrigger>
          <TabsTrigger value="billing">Faturamento</TabsTrigger>
        </TabsList>

        <TabsContent value="details">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Informações Gerais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Tipo</p>
                    <p className="font-medium">{organization.type}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Plano</p>
                    <p className="font-medium">{organization.plan}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Data de Cadastro</p>
                    <p className="font-medium">{new Date(organization.created_date).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Status</p>
                    <Badge className={
                      organization.status === 'Ativo' ? 'bg-green-100 text-green-800' : 
                      organization.status === 'Pendente' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-red-100 text-red-800'
                    }>
                      {organization.status}
                    </Badge>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-medium mb-2">Contato</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">Nome</p>
                        <p className="font-medium">{organization.contact_name}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">Email</p>
                        <p className="font-medium">{organization.contact_email}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-medium mb-2">Endereço</h3>
                  <div className="flex items-start gap-2">
                    <Building2 className="w-4 h-4 text-gray-400 mt-0.5" />
                    <p>{organization.address}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Estatísticas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-gray-400" />
                    <p className="text-sm text-gray-500">Associados</p>
                  </div>
                  <p className="font-medium">{organization.associates}</p>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Heart className="w-4 h-4 text-gray-400" />
                    <p className="text-sm text-gray-500">Pacientes</p>
                  </div>
                  <p className="font-medium">{organization.patients}</p>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Leaf className="w-4 h-4 text-gray-400" />
                    <p className="text-sm text-gray-500">Produtos</p>
                  </div>
                  <p className="font-medium">{organization.products}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="modules">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Módulos</CardTitle>
                <CardDescription>
                  Gerencie os módulos disponíveis para esta organização
                </CardDescription>
              </div>
              <Button onClick={() => setAddModuleDialog(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Módulo
              </Button>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {organization.modules.map((module) => (
                  <Card key={module.id} className="border">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          <div className="p-2 bg-blue-50 rounded-lg">
                            {getModuleIcon(module.icon)}
                          </div>
                          <CardTitle className="text-base">{module.name}</CardTitle>
                        </div>
                        <Switch 
                          checked={module.active} 
                          onCheckedChange={() => toggleModuleStatus(module.id)}
                        />
                      </div>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <Badge className={module.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                        {module.active ? 'Ativo' : 'Inativo'}
                      </Badge>
                      {module.plan && (
                        <Badge variant="outline" className="ml-2">
                          Plano {module.plan}
                        </Badge>
                      )}
                    </CardContent>
                    <CardFooter className="pt-0">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4 mr-1" />
                            Ações
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>Configurar módulo</DropdownMenuItem>
                          <DropdownMenuItem>Alterar plano</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600" onClick={() => removeModule(module.id)}>
                            Remover módulo
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Usuários</CardTitle>
                <CardDescription>
                  Gerencie os usuários desta organização
                </CardDescription>
              </div>
              <Button>
                <UserPlus className="w-4 h-4 mr-2" />
                Convidar Usuário
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {organization.users.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback>
                          {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-sm text-gray-500">{user.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{user.role}</Badge>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>Editar permissões</DropdownMenuItem>
                          <DropdownMenuItem>Ver atividade</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600">
                            Remover acesso
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing">
          <Card>
            <CardHeader>
              <CardTitle>Faturamento</CardTitle>
              <CardDescription>
                Histórico de faturamento e informações de pagamento
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500">Informações de faturamento não disponíveis no momento.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={addModuleDialog} onOpenChange={setAddModuleDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Módulo</DialogTitle>
            <DialogDescription>
              Selecione o módulo que deseja adicionar a esta organização
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="module-select">Módulo</Label>
              <Select value={moduleToAdd} onValueChange={setModuleToAdd}>
                <SelectTrigger id="module-select">
                  <SelectValue placeholder="Selecione um módulo" />
                </SelectTrigger>
                <SelectContent>
                  {getAvailableModules().map((module) => (
                    <SelectItem key={module.id} value={module.id}>
                      <div className="flex items-center gap-2">
                        {getModuleIcon(module.id)}
                        <span>{module.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {moduleToAdd && (
              <div className="space-y-2">
                <Label htmlFor="plan-select">Plano</Label>
                <Select value={selectedModulePlan} onValueChange={setSelectedModulePlan}>
                  <SelectTrigger id="plan-select">
                    <SelectValue placeholder="Selecione um plano" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="basic">Básico</SelectItem>
                    <SelectItem value="standard">Padrão</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddModuleDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddModule} disabled={!moduleToAdd}>
              Adicionar Módulo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}