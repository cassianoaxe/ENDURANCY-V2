import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Separator } from "@/components/ui/separator";
import { 
  ChevronLeft, 
  Edit, 
  FileText, 
  Clock, 
  Trash, 
  Package, 
  Download,
  List,
  Layers,
  BookOpen,
  Beaker,
  AlertTriangle,
  ArrowRight,
  Timer
} from "lucide-react";

export default function CatalogoDetalhesProduto() {
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const produtoId = queryParams.get('id');
  
  const [loading, setLoading] = useState(true);
  const [produto, setProduto] = useState(null);
  const [activeTab, setActiveTab] = useState("geral");
  
  useEffect(() => {
    if (!produtoId) {
      navigate(createPageUrl('CatalogoProdutos'));
      return;
    }
    
    // Simular carregamento de dados do produto
    const timer = setTimeout(() => {
      const mockProduto = {
        id: "PROD001",
        codigo: "OCBD10-FS",
        nome: "Óleo CBD 10% Full Spectrum",
        descricao: "Óleo de CBD full spectrum com concentração de 10%, em frasco âmbar de 30ml com conta-gotas para dosagem precisa. Produzido com extratos de alta qualidade e óleo carreador MCT.",
        categoria: "oleo",
        status: "ativo",
        especificacoes_tecnicas: {
          concentracao_cbd: 10,
          concentracao_thc: 0.2,
          volume_final: 30
        },
        componentes: [
          {
            nome: "Extrato CBD Full Spectrum",
            tipo: "principio_ativo",
            quantidade: 3,
            unidade_medida: "ml",
            especificacoes: "Lote aprovado em CQ"
          },
          {
            nome: "Óleo MCT",
            tipo: "excipiente",
            quantidade: 27,
            unidade_medida: "ml",
            especificacoes: "Farmacêutico grau USP"
          },
          {
            nome: "Frasco Âmbar 30ml",
            tipo: "embalagem_primaria",
            quantidade: 1,
            unidade_medida: "unidade",
            especificacoes: "Vidro âmbar tipo III"
          },
          {
            nome: "Conta-gotas",
            tipo: "embalagem_primaria",
            quantidade: 1,
            unidade_medida: "unidade",
            especificacoes: "1ml graduado"
          },
          {
            nome: "Rótulo OCBD10-FS",
            tipo: "rotulo",
            quantidade: 1,
            unidade_medida: "unidade",
            especificacoes: "Autocolante resistente à água"
          },
          {
            nome: "Caixa Individual",
            tipo: "embalagem_secundaria",
            quantidade: 1,
            unidade_medida: "unidade",
            especificacoes: "Cartonada com instruções"
          }
        ],
        processo_produtivo: [
          { 
            etapa: "Preparação", 
            descricao: "Separação e verificação de todos os componentes necessários. Limpeza da área de trabalho e equipamentos de acordo com POP-001.", 
            tempo_estimado: 30, 
            controles_necessarios: ["Verificação de lotes", "Inspeção visual dos materiais", "Limpeza documentada"] 
          },
          { 
            etapa: "Mistura", 
            descricao: "Adicionar o extrato ao óleo carreador na proporção correta e misturar com agitador magnético por 20 minutos a 35°C.", 
            tempo_estimado: 40, 
            controles_necessarios: ["Controle de temperatura", "Tempo de agitação", "Homogeneidade"] 
          },
          { 
            etapa: "Envase", 
            descricao: "Transferir a mistura para os frascos utilizando bomba peristáltica calibrada para volume exato de 30ml.", 
            tempo_estimado: 60, 
            controles_necessarios: ["Verificação de volume", "Inspeção de vazamentos", "Amostragem para CQ"] 
          },
          { 
            etapa: "Rotulagem", 
            descricao: "Aplicação de rótulos nos frascos seguindo padrão de alinhamento. Cada rótulo deve conter lote e validade.", 
            tempo_estimado: 45, 
            controles_necessarios: ["Verificação de informações", "Alinhamento", "Ausência de bolhas"] 
          },
          { 
            etapa: "Embalagem", 
            descricao: "Inserção do frasco rotulado na caixa individual junto com a bula. Fechamento da caixa.", 
            tempo_estimado: 30, 
            controles_necessarios: ["Verificação de componentes", "Integridade da embalagem", "Selagem adequada"] 
          }
        ],
        documentos_relacionados: [
          { tipo: "formula_padrao", nome: "Fórmula Padrão OCBD10-FS", url: "#" },
          { tipo: "procedimento_produtivo", nome: "POP-001 - Produção de Óleos CBD", url: "#" },
          { tipo: "especificacao_tecnica", nome: "Especificação de Produto Final - Óleo 10%", url: "#" },
          { tipo: "controle_qualidade", nome: "Protocolo de Análise - Óleos CBD", url: "#" }
        ],
        historico_revisoes: [
          { 
            versao: "1.0", 
            data: "2023-01-15T10:30:00Z", 
            responsavel: "João Silva", 
            alteracoes: "Criação inicial do produto" 
          },
          { 
            versao: "1.1", 
            data: "2023-05-20T14:45:00Z", 
            responsavel: "Maria Oliveira", 
            alteracoes: "Atualização da especificação do conta-gotas" 
          },
          { 
            versao: "1.2", 
            data: "2023-07-10T09:15:00Z", 
            responsavel: "João Silva", 
            alteracoes: "Adição de novo rótulo e caixa com design atualizado" 
          }
        ]
      };
      
      setProduto(mockProduto);
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [produtoId, navigate]);
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    );
  }
  
  if (!produto) {
    return (
      <div className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <Button variant="ghost" onClick={() => navigate(createPageUrl("CatalogoProdutos"))}>
            <ChevronLeft className="h-4 w-4 mr-1" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold">Produto não encontrado</h1>
        </div>
        
        <Card>
          <CardContent className="flex flex-col items-center justify-center h-64">
            <AlertTriangle className="h-12 w-12 text-amber-500 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Produto não encontrado</h3>
            <p className="text-sm text-gray-500 mb-4">
              O produto com o ID especificado não foi encontrado no catálogo.
            </p>
            <Button onClick={() => navigate(createPageUrl("CatalogoProdutos"))}>
              Voltar para o Catálogo
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-10">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" onClick={() => navigate(createPageUrl("CatalogoProdutos"))}>
            <ChevronLeft className="h-4 w-4 mr-1" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold">{produto.nome}</h1>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => navigate(createPageUrl(`ProducaoNovaOrdem?produto=${produto.id}`))}>
            <Package className="h-4 w-4 mr-2" />
            Nova Ordem de Produção
          </Button>
          <Button variant="default">
            <Edit className="h-4 w-4 mr-2" />
            Editar Produto
          </Button>
        </div>
      </div>

      <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow-sm border">
        <div className="flex items-center gap-4">
          <Badge variant="outline">{produto.codigo}</Badge>
          <Badge 
            className={
              produto.status === 'ativo' ? 'bg-green-100 text-green-800' :
              produto.status === 'inativo' ? 'bg-gray-100 text-gray-800' :
              produto.status === 'em_desenvolvimento' ? 'bg-blue-100 text-blue-800' :
              'bg-red-100 text-red-800'
            }
          >
            {produto.status.replace('_', ' ').charAt(0).toUpperCase() + produto.status.replace('_', ' ').slice(1)}
          </Badge>
          <span className="text-gray-500">|</span>
          <div className="text-sm text-gray-600">
            <span className="font-medium">{produto.especificacoes_tecnicas.concentracao_cbd}% CBD</span>
            <span className="mx-1">•</span>
            <span>{produto.especificacoes_tecnicas.volume_final}ml</span>
          </div>
        </div>
        <div className="text-sm text-gray-500">
          Categoria: <span className="font-medium">{produto.categoria.charAt(0).toUpperCase() + produto.categoria.slice(1)}</span>
        </div>
      </div>

      <Tabs defaultValue="geral" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-5 mb-6">
          <TabsTrigger value="geral">Visão Geral</TabsTrigger>
          <TabsTrigger value="componentes">Componentes</TabsTrigger>
          <TabsTrigger value="processo">Processo Produtivo</TabsTrigger>
          <TabsTrigger value="documentos">Documentos</TabsTrigger>
          <TabsTrigger value="historico">Histórico</TabsTrigger>
        </TabsList>
        
        <TabsContent value="geral">
          <Card>
            <CardHeader>
              <CardTitle>Visão Geral do Produto</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-medium text-lg mb-2">Descrição</h3>
                <p className="text-gray-700">{produto.descricao}</p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-medium text-lg mb-2">Especificações Técnicas</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 bg-gray-50 rounded-md">
                    <div className="text-sm text-gray-500 mb-1">Concentração de CBD</div>
                    <div className="text-xl font-medium">{produto.especificacoes_tecnicas.concentracao_cbd}%</div>
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-md">
                    <div className="text-sm text-gray-500 mb-1">Concentração de THC</div>
                    <div className="text-xl font-medium">{produto.especificacoes_tecnicas.concentracao_thc}%</div>
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-md">
                    <div className="text-sm text-gray-500 mb-1">Volume/Quantidade Final</div>
                    <div className="text-xl font-medium">{produto.especificacoes_tecnicas.volume_final} ml</div>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-medium text-lg mb-2">Resumo de Produção</h3>
                <div className="grid grid-cols-4 gap-4">
                  <div className="p-4 bg-blue-50 text-blue-800 rounded-md">
                    <div className="flex items-center gap-2 mb-2">
                      <Layers className="h-5 w-5" />
                      <div className="font-medium">Componentes</div>
                    </div>
                    <div className="text-2xl font-semibold">{produto.componentes.length}</div>
                  </div>
                  
                  <div className="p-4 bg-indigo-50 text-indigo-800 rounded-md">
                    <div className="flex items-center gap-2 mb-2">
                      <List className="h-5 w-5" />
                      <div className="font-medium">Etapas</div>
                    </div>
                    <div className="text-2xl font-semibold">{produto.processo_produtivo.length}</div>
                  </div>
                  
                  <div className="p-4 bg-emerald-50 text-emerald-800 rounded-md">
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="h-5 w-5" />
                      <div className="font-medium">Documentos</div>
                    </div>
                    <div className="text-2xl font-semibold">{produto.documentos_relacionados.length}</div>
                  </div>
                  
                  <div className="p-4 bg-amber-50 text-amber-800 rounded-md">
                    <div className="flex items-center gap-2 mb-2">
                      <Timer className="h-5 w-5" />
                      <div className="font-medium">Tempo Estimado</div>
                    </div>
                    <div className="text-2xl font-semibold">
                      {produto.processo_produtivo.reduce((acc, curr) => acc + parseInt(curr.tempo_estimado), 0)} min
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="componentes">
          <Card>
            <CardHeader>
              <CardTitle>Componentes do Produto</CardTitle>
              <CardDescription>Lista de matérias-primas e materiais necessários</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Componente</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Quantidade</TableHead>
                    <TableHead>Unidade</TableHead>
                    <TableHead>Especificações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {produto.componentes.map((componente, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{componente.nome}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {componente.tipo.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>{componente.quantidade}</TableCell>
                      <TableCell>{componente.unidade_medida}</TableCell>
                      <TableCell>{componente.especificacoes}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              <div className="mt-6">
                <div className="bg-blue-50 border border-blue-200 text-blue-800 p-4 rounded-md">
                  <div className="flex items-start gap-2">
                    <Beaker className="h-5 w-5 mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium mb-1">Informação:</h4>
                      <p className="text-sm">Os componentes listados acima são consumidos automaticamente do estoque durante a produção deste produto. Certifique-se de manter o estoque atualizado para evitar atrasos na produção.</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="processo">
          <Card>
            <CardHeader>
              <CardTitle>Processo Produtivo</CardTitle>
              <CardDescription>Etapas do processo de produção</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {produto.processo_produtivo.map((etapa, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="bg-gray-200 text-gray-700 w-6 h-6 rounded-full flex items-center justify-center text-sm font-medium">
                          {index + 1}
                        </div>
                        <h3 className="text-lg font-medium">{etapa.etapa}</h3>
                      </div>
                      <div className="flex items-center gap-1 text-gray-500 text-sm">
                        <Clock className="h-4 w-4" />
                        <span>{etapa.tempo_estimado} minutos</span>
                      </div>
                    </div>
                    
                    <p className="text-gray-700 text-sm mb-3 ml-8">{etapa.descricao}</p>
                    
                    <div className="ml-8 bg-gray-50 p-3 rounded-md">
                      <div className="text-sm font-medium mb-1">Controles Necessários:</div>
                      <ul className="text-sm text-gray-600 space-y-1">
                        {etapa.controles_necessarios.map((controle, i) => (
                          <li key={i} className="flex items-center gap-2">
                            <ArrowRight className="h-3 w-3 text-gray-400" />
                            {controle}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="documentos">
          <Card>
            <CardHeader>
              <CardTitle>Documentos Relacionados</CardTitle>
              <CardDescription>Procedimentos, especificações e outros documentos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {produto.documentos_relacionados.map((documento, index) => (
                  <div key={index} className="p-4 border rounded-lg flex items-start justify-between hover:bg-gray-50 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="rounded-lg bg-blue-100 p-2 mt-1">
                        <FileText className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">{documento.nome}</h4>
                        <Badge className="mt-1 text-xs" variant="outline">
                          {documento.tipo.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4 mr-1" />
                      Baixar
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="historico">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Revisões</CardTitle>
              <CardDescription>Registro de alterações do produto</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                {produto.historico_revisoes.map((revisao, index) => (
                  <div key={index} className="flex flex-col border-l-2 border-gray-200 pl-4 pb-8 relative">
                    <div className="absolute -left-1.5 top-1 w-3 h-3 rounded-full bg-blue-600"></div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">Versão {revisao.versao}</h3>
                        {index === 0 && (
                          <Badge className="bg-blue-100 text-blue-800">
                            Atual
                          </Badge>
                        )}
                      </div>
                      <div className="text-sm text-gray-500">
                        {new Date(revisao.data).toLocaleString()}
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      Responsável: {revisao.responsavel}
                    </div>
                    <p className="text-sm mt-1">{revisao.alteracoes}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}