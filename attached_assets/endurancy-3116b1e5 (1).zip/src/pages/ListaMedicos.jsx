import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Search,
  Filter,
  Plus,
  Settings,
  Eye,
  Edit,
  MoreHorizontal,
  Building2,
  Calendar,
  FileText,
  Mail,
  Phone,
  DollarSign,
  Users
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Spinner } from "@/components/ui/spinner";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";

export default function ListaMedicos() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [medicos, setMedicos] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [especialidadeFilter, setEspecialidadeFilter] = useState("todas");
  const [statusFilter, setStatusFilter] = useState("todos");
  
  // Simulação de carregamento de dados
  useEffect(() => {
    setTimeout(() => {
      const mockMedicos = [
        {
          id: "1",
          nome_completo: "Dr. Ricardo Santos",
          crm: "12345",
          uf_crm: "SP",
          especialidade: "Neurologia",
          email: "ricardo.santos@exemplo.com",
          telefone: "(11) 98765-4321",
          status: "ativo",
          total_pacientes: 28,
          total_consultas_mes: 42,
          total_prescricoes: 36,
          organizations: ["1", "3"],
          especialista_cannabis: true,
          valor_consulta: 350,
          permite_telemedicina: true
        },
        {
          id: "2",
          nome_completo: "Dra. Carla Oliveira",
          crm: "45678",
          uf_crm: "SP",
          especialidade: "Psiquiatria",
          email: "carla.oliveira@exemplo.com",
          telefone: "(11) 91234-5678",
          status: "ativo",
          total_pacientes: 42,
          total_consultas_mes: 56,
          total_prescricoes: 51,
          organizations: ["1"],
          especialista_cannabis: true,
          valor_consulta: 400,
          permite_telemedicina: true
        },
        {
          id: "3",
          nome_completo: "Dr. André Mendes",
          crm: "78912",
          uf_crm: "RJ",
          especialidade: "Ortopedia",
          email: "andre.mendes@exemplo.com",
          telefone: "(21) 98765-4321",
          status: "ativo",
          total_pacientes: 15,
          total_consultas_mes: 24,
          total_prescricoes: 18,
          organizations: ["1", "2"],
          especialista_cannabis: true,
          valor_consulta: 300,
          permite_telemedicina: false
        },
        {
          id: "4",
          nome_completo: "Dra. Mariana Costa",
          crm: "54321",
          uf_crm: "MG",
          especialidade: "Neurologia",
          email: "mariana.costa@exemplo.com",
          telefone: "(31) 98765-4321",
          status: "inativo",
          total_pacientes: 0,
          total_consultas_mes: 0,
          total_prescricoes: 12,
          organizations: ["1"],
          especialista_cannabis: true,
          valor_consulta: 350,
          permite_telemedicina: true
        },
        {
          id: "5",
          nome_completo: "Dr. Paulo Ferreira",
          crm: "65432",
          uf_crm: "SP",
          especialidade: "Clínica Geral",
          email: "paulo.ferreira@exemplo.com",
          telefone: "(11) 97654-3210",
          status: "pendente",
          total_pacientes: 0,
          total_consultas_mes: 0,
          total_prescricoes: 0,
          organizations: ["1"],
          especialista_cannabis: false,
          valor_consulta: 250,
          permite_telemedicina: true
        }
      ];
      
      setMedicos(mockMedicos);
      setLoading(false);
    }, 800);
  }, []);
  
  // Filtragem dos médicos
  const medicosFiltrados = medicos.filter(medico => {
    const matchSearch = medico.nome_completo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        medico.crm.includes(searchTerm) ||
                        medico.especialidade.toLowerCase().includes(searchTerm.toLowerCase());
                        
    const matchEspecialidade = especialidadeFilter === "todas" || medico.especialidade.toLowerCase() === especialidadeFilter.toLowerCase();
    
    const matchStatus = statusFilter === "todos" || medico.status === statusFilter;
    
    return matchSearch && matchEspecialidade && matchStatus;
  });
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Spinner className="mx-auto" />
          <p className="mt-4 text-muted-foreground">Carregando lista de médicos...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Médicos Associados</h1>
          <p className="text-muted-foreground">
            Gerencie os médicos associados à sua organização
          </p>
        </div>
        <Button onClick={() => navigate(createPageUrl("CadastroMedico"))}>
          <Plus className="mr-2 h-4 w-4" />
          Novo Médico
        </Button>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar por nome, CRM ou especialidade..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2">
          <Select value={especialidadeFilter} onValueChange={setEspecialidadeFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Especialidade" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas as especialidades</SelectItem>
              <SelectItem value="neurologia">Neurologia</SelectItem>
              <SelectItem value="psiquiatria">Psiquiatria</SelectItem>
              <SelectItem value="ortopedia">Ortopedia</SelectItem>
              <SelectItem value="clínica geral">Clínica Geral</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos</SelectItem>
              <SelectItem value="ativo">Ativos</SelectItem>
              <SelectItem value="inativo">Inativos</SelectItem>
              <SelectItem value="pendente">Pendentes</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {medicosFiltrados.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center h-64">
            <Users className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">Nenhum médico encontrado</h3>
            <p className="text-muted-foreground mt-2">
              Não foram encontrados médicos com os filtros aplicados.
            </p>
            <Button 
              variant="link" 
              onClick={() => {
                setSearchTerm("");
                setEspecialidadeFilter("todas");
                setStatusFilter("todos");
              }}
            >
              Limpar filtros
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {medicosFiltrados.map((medico) => (
            <Card 
              key={medico.id} 
              className="hover:shadow-md transition-shadow"
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className="bg-blue-100 text-blue-700">{medico.nome_completo.split(' ').map(n => n[0]).join('').slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">{medico.nome_completo}</h3>
                      <p className="text-sm text-muted-foreground">{medico.especialidade}</p>
                      <p className="text-sm">CRM {medico.crm} {medico.uf_crm}</p>
                    </div>
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => navigate(createPageUrl(`DetalhesMedico?id=${medico.id}`))}>
                        <Eye className="mr-2 h-4 w-4" />
                        Ver detalhes
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigate(createPageUrl(`EditarMedico?id=${medico.id}`))}>
                        <Edit className="mr-2 h-4 w-4" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigate(createPageUrl(`AgendaMedico?id=${medico.id}`))}>
                        <Calendar className="mr-2 h-4 w-4" />
                        Ver agenda
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigate(createPageUrl(`PrescricoesMedico?id=${medico.id}`))}>
                        <FileText className="mr-2 h-4 w-4" />
                        Prescrições
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigate(createPageUrl(`FinanceiroMedico?id=${medico.id}`))}>
                        <DollarSign className="mr-2 h-4 w-4" />
                        Financeiro
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                
                <div className="mt-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{medico.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{medico.telefone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{medico.organizations.length} organizações</span>
                  </div>
                </div>
                
                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Pacientes</span>
                    <span className="font-medium">{medico.total_pacientes}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Consultas (mês)</span>
                    <span className="font-medium">{medico.total_consultas_mes}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Prescrições</span>
                    <span className="font-medium">{medico.total_prescricoes}</span>
                  </div>
                </div>
                
                <div className="mt-4 flex flex-wrap gap-2">
                  <Badge variant={medico.status === 'ativo' ? 'success' : medico.status === 'pendente' ? 'warning' : 'secondary'}>
                    {medico.status === 'ativo' ? 'Ativo' : medico.status === 'pendente' ? 'Pendente' : 'Inativo'}
                  </Badge>
                  
                  {medico.especialista_cannabis && (
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      Especialista em Cannabis
                    </Badge>
                  )}
                  
                  {medico.permite_telemedicina && (
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                      Telemedicina
                    </Badge>
                  )}
                </div>
                
                <div className="mt-4 pt-4 border-t">
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => navigate(createPageUrl(`DetalhesMedico?id=${medico.id}`))}
                  >
                    Ver Perfil Completo
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}