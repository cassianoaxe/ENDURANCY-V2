import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { 
  ArrowLeft, 
  Building2, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  Download, 
  FileText, 
  Mail, 
  MapPin, 
  Phone, 
  User,
  XCircle,
  AlertTriangle,
  AlertCircle
} from "lucide-react";

// Dados simulados para organização
const mockOrganizations = [
  {
    id: "org1",
    name: "MediCannabis Farma",
    type: "Empresa",
    plan: "Empresarial Pro",
    description: "Produtora de medicamentos à base de cannabis medicinal com foco em óleos e extratos de alta qualidade.",
    contact_name: "João Silva",
    contact_email: "joao@medicannabis.com.br",
    contact_phone: "+55 11 98765-4321",
    address: JSON.stringify({
      street: "Av. Paulista, 1000",
      city: "São Paulo",
      state: "SP",
      zip: "01310-100",
      country: "Brasil"
    }),
    license_number: "ANVISA-12345678",
    license_expiry: "2025-12-31T00:00:00Z",
    modules: ["patients", "products", "prescriptions", "production", "financial"],
    status: "Ativo",
    created_date: "2023-07-15T14:30:00Z"
  },
  {
    id: "org2",
    name: "Associação Médica Verde",
    type: "Associação",
    plan: "Associação Premium",
    description: "Associação de pacientes de cannabis medicinal que busca facilitar o acesso a tratamentos e medicamentos.",
    contact_name: "Maria Oliveira",
    contact_email: "maria@amv.org.br",
    contact_phone: "+55 21 99876-5432",
    address: JSON.stringify({
      street: "Rua das Flores, 123",
      city: "Rio de Janeiro",
      state: "RJ",
      zip: "22021-040",
      country: "Brasil"
    }),
    license_number: "ANVISA-87654321",
    license_expiry: "2025-06-30T00:00:00Z",
    modules: ["patients", "products", "prescriptions"],
    status: "Ativo",
    created_date: "2023-07-12T10:15:00Z"
  },
  {
    id: "org3",
    name: "CannaPesquisa Instituto",
    type: "Associação",
    plan: "Associação Plus",
    description: "Instituto de pesquisa focado no desenvolvimento e aprimoramento de tratamentos com cannabis medicinal.",
    contact_name: "Pedro Almeida",
    contact_email: "pedro@cannapesquisa.org",
    contact_phone: "+55 31 98887-6655",
    address: JSON.stringify({
      street: "Av. do Contorno, 456",
      city: "Belo Horizonte",
      state: "MG",
      zip: "30110-017",
      country: "Brasil"
    }),
    license_number: "ANVISA-23456789",
    license_expiry: "2024-09-15T00:00:00Z",
    modules: ["patients", "products", "prescriptions", "production"],
    status: "Pendente",
    created_date: "2023-07-21T09:45:00Z"
  },
  {
    id: "org4",
    name: "Green Medical Brasil",
    type: "Empresa",
    plan: "Empresarial Básico",
    description: "Empresa focada na importação e distribuição de produtos de cannabis medicinal internacionais.",
    contact_name: "Ana Sousa",
    contact_email: "ana@greenmedical.com.br",
    contact_phone: "+55 41 99998-7766",
    address: JSON.stringify({
      street: "Rua Castro Alves, 789",
      city: "Curitiba",
      state: "PR",
      zip: "80240-270",
      country: "Brasil"
    }),
    license_number: "Em análise",
    license_expiry: null,
    modules: ["patients", "products", "prescriptions"],
    status: "Pendente",
    created_date: "2023-07-20T16:20:00Z"
  }
];

// Dados simulados para documentos
const documentsData = [
  {
    id: 1,
    name: "Contrato Social.pdf",
    type: "application/pdf",
    size: "2.5 MB",
    uploaded: "2023-07-15T14:30:00Z",
    status: "verified",
    category: "legal"
  },
  {
    id: 2,
    name: "Alvará de Funcionamento.pdf",
    type: "application/pdf",
    size: "1.2 MB",
    uploaded: "2023-07-15T14:32:00Z",
    status: "verified",
    category: "license"
  },
  {
    id: 3,
    name: "Certidão Negativa de Débitos.pdf",
    type: "application/pdf",
    size: "980 KB",
    uploaded: "2023-07-15T14:35:00Z",
    status: "pending",
    category: "financial"
  },
  {
    id: 4,
    name: "Comprovante de Endereço.pdf",
    type: "application/pdf",
    size: "1.1 MB",
    uploaded: "2023-07-15T14:38:00Z",
    status: "pending",
    category: "address"
  },
  {
    id: 5,
    name: "Documento de Identidade do Responsável.jpg",
    type: "image/jpeg",
    size: "3.2 MB",
    uploaded: "2023-07-15T14:40:00Z",
    status: "rejected",
    category: "identity",
    reject_reason: "Documento ilegível. Por favor, envie uma versão mais clara."
  }
];

// Dados simulados para atividades
const activitiesData = [
  {
    id: 1,
    type: "created",
    timestamp: "2023-07-15T14:30:00Z",
    user: {
      name: "Fernanda Costa",
      avatar: "FC"
    },
    details: "Criou a solicitação de organização"
  },
  {
    id: 2,
    type: "document_uploaded",
    timestamp: "2023-07-15T14:35:00Z",
    user: {
      name: "Fernanda Costa",
      avatar: "FC"
    },
    details: "Enviou 5 documentos"
  },
  {
    id: 3,
    type: "document_rejected",
    timestamp: "2023-07-16T09:20:00Z",
    user: {
      name: "João Silva",
      avatar: "JS"
    },
    details: "Rejeitou o documento 'Documento de Identidade do Responsável.jpg'",
    notes: "Documento ilegível. Por favor, envie uma versão mais clara."
  },
  {
    id: 4,
    type: "review_started",
    timestamp: "2023-07-16T09:25:00Z",
    user: {
      name: "João Silva",
      avatar: "JS"
    },
    details: "Iniciou a revisão da solicitação"
  }
];

export default function Request() {
  const navigate = useNavigate();
  const [organization, setOrganization] = useState(null);
  const [loading, setLoading] = useState(true);
  const [documents, setDocuments] = useState([]);
  const [activities, setActivities] = useState([]);
  const [activeTab, setActiveTab] = useState("overview");
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");
  const [approvalNotes, setApprovalNotes] = useState("");
  const [processingAction, setProcessingAction] = useState(false);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    const action = urlParams.get('action');
    
    if (id) {
      loadOrganization(id);
      loadDocuments();
      loadActivities();
    }
    
    if (action === 'approve') {
      setShowApproveDialog(true);
    } else if (action === 'reject') {
      setShowRejectDialog(true);
    }
  }, []);
  
  const loadOrganization = async (id) => {
    try {
      setLoading(true);
      setError(null);
      
      // Simular carregamento de dados
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Usar dados simulados
      const foundOrg = mockOrganizations.find(org => org.id === id);
      if (foundOrg) {
        setOrganization(foundOrg);
      } else {
        setError("Organização não encontrada");
      }
    } catch (error) {
      console.error("Error loading organization", error);
      setError("Erro ao carregar dados da organização");
    } finally {
      setLoading(false);
    }
  };
  
  const loadDocuments = async () => {
    try {
      // Simular carregamento de documentos
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Usar dados simulados
      setDocuments(documentsData);
    } catch (error) {
      console.error("Error loading documents", error);
    }
  };
  
  const loadActivities = async () => {
    try {
      // Simular carregamento de atividades
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Usar dados simulados
      setActivities(activitiesData);
    } catch (error) {
      console.error("Error loading activities", error);
    }
  };
  
  const handleApprove = async () => {
    setProcessingAction(true);
    
    try {
      // Simular processamento
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Em um ambiente real, você atualizaria o status da organização
      // const updatedOrg = await Organization.update(organization.id, { 
      //   status: "Ativo", 
      //   last_review_date: new Date().toISOString(),
      //   last_review_by: "admin@endurancy.com" // Idealmente o email do usuário atual
      // });
      
      // Simular sucesso
      setShowApproveDialog(false);
      navigate(createPageUrl("Organizations"));
    } catch (error) {
      console.error("Error approving organization", error);
      setError("Erro ao aprovar organização");
    } finally {
      setProcessingAction(false);
    }
  };
  
  const handleReject = async () => {
    if (!rejectionReason.trim()) {
      setError("Por favor, informe o motivo da rejeição");
      return;
    }
    
    setProcessingAction(true);
    
    try {
      // Simular processamento
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Em um ambiente real, você atualizaria o status da organização
      // const updatedOrg = await Organization.update(organization.id, { 
      //   status: "Rejeitado", 
      //   rejection_reason: rejectionReason,
      //   last_review_date: new Date().toISOString(),
      //   last_review_by: "admin@endurancy.com" // Idealmente o email do usuário atual
      // });
      
      // Simular sucesso
      setShowRejectDialog(false);
      navigate(createPageUrl("Organizations"));
    } catch (error) {
      console.error("Error rejecting organization", error);
      setError("Erro ao rejeitar organização");
    } finally {
      setProcessingAction(false);
    }
  };
  
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-t-green-600 border-b-green-600 border-l-green-600 border-r-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-gray-500">Carregando informações da organização...</p>
      </div>
    );
  }
  
  if (error && !organization) {
    return (
      <div className="py-8">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Erro</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <div className="flex justify-center mt-8">
          <Button 
            variant="outline" 
            className="gap-2"
            onClick={() => navigate(createPageUrl("Organizations"))}
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar para Organizações
          </Button>
        </div>
      </div>
    );
  }
  
  // Parse address if it's a string
  const address = organization?.address ? 
    (typeof organization.address === 'string' ? JSON.parse(organization.address) : organization.address) : 
    null;
  
  const getStatusBadge = (status) => {
    switch (status) {
      case "Ativo":
        return <Badge className="bg-green-100 text-green-800 gap-1"><CheckCircle2 className="w-3 h-3" /> Ativo</Badge>;
      case "Pendente":
        return <Badge className="bg-yellow-100 text-yellow-800 gap-1"><Clock className="w-3 h-3" /> Pendente</Badge>;
      case "Rejeitado":
        return <Badge className="bg-red-100 text-red-800 gap-1"><XCircle className="w-3 h-3" /> Rejeitado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  const getDocumentStatusBadge = (status) => {
    switch (status) {
      case "verified":
        return <Badge className="bg-green-100 text-green-800 gap-1"><CheckCircle2 className="w-3 h-3" /> Verificado</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800 gap-1"><Clock className="w-3 h-3" /> Pendente</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 gap-1"><XCircle className="w-3 h-3" /> Rejeitado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  const formatDateTime = (dateString) => {
    if (!dateString) return "N/A";
    
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => navigate(createPageUrl("Organizations"))}
            className="h-8 w-8"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">{organization.name}</h1>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline">{organization.type}</Badge>
              {getStatusBadge(organization.status)}
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          {organization.status === "Pendente" && (
            <>
              <Button 
                className="gap-2 bg-red-600 hover:bg-red-700"
                onClick={() => setShowRejectDialog(true)}
              >
                <XCircle className="w-4 h-4" />
                Rejeitar
              </Button>
              <Button 
                className="gap-2 bg-green-600 hover:bg-green-700"
                onClick={() => setShowApproveDialog(true)}
              >
                <CheckCircle2 className="w-4 h-4" />
                Aprovar
              </Button>
            </>
          )}
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="documents">Documentos</TabsTrigger>
          <TabsTrigger value="activities">Atividades</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          {organization.status === "Rejeitado" && organization.rejection_reason && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Motivo da Rejeição</AlertTitle>
              <AlertDescription>{organization.rejection_reason}</AlertDescription>
            </Alert>
          )}
          
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-gray-500" />
                  Informações da Organização
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm text-gray-500">Tipo de Organização</Label>
                  <p className="font-medium">{organization.type}</p>
                </div>
                <div>
                  <Label className="text-sm text-gray-500">Plano</Label>
                  <p className="font-medium">{organization.plan}</p>
                </div>
                <div>
                  <Label className="text-sm text-gray-500">Descrição</Label>
                  <p>{organization.description || "Sem descrição"}</p>
                </div>
                <div>
                  <Label className="text-sm text-gray-500">Número da Licença</Label>
                  <p className="font-medium">{organization.license_number || "Não informado"}</p>
                </div>
                <div>
                  <Label className="text-sm text-gray-500">Validade da Licença</Label>
                  <p className="font-medium">{organization.license_expiry ? formatDate(organization.license_expiry) : "Não informado"}</p>
                </div>
                <div>
                  <Label className="text-sm text-gray-500">Data de Criação</Label>
                  <p className="font-medium">{formatDateTime(organization.created_date)}</p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5 text-gray-500" />
                  Informações de Contato
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm text-gray-500">Nome do Contato</Label>
                  <p className="font-medium">{organization.contact_name}</p>
                </div>
                <div>
                  <Label className="text-sm text-gray-500">Email</Label>
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-gray-500" />
                    <a href={`mailto:${organization.contact_email}`} className="text-blue-600 hover:underline">
                      {organization.contact_email}
                    </a>
                  </div>
                </div>
                <div>
                  <Label className="text-sm text-gray-500">Telefone</Label>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-gray-500" />
                    <a href={`tel:${organization.contact_phone}`} className="text-blue-600 hover:underline">
                      {organization.contact_phone}
                    </a>
                  </div>
                </div>
                {address && (
                  <div>
                    <Label className="text-sm text-gray-500">Endereço</Label>
                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-gray-500 mt-1 flex-shrink-0" />
                      <p>
                        {address.street}<br />
                        {address.city}, {address.state} - {address.zip}<br />
                        {address.country}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-gray-500" />
                Módulos Contratados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {organization.modules?.map((module) => {
                  const moduleLabels = {
                    "patients": "Gestão de Pacientes",
                    "products": "Gestão de Produtos",
                    "orders": "Gestão de Pedidos",
                    "prescriptions": "Gestão de Prescrições",
                    "production": "Gestão de Produção",
                    "financial": "Gestão Financeira",
                    "reports": "Relatórios Avançados"
                  };
                  
                  return (
                    <Badge key={module} variant="outline" className="px-3 py-1">
                      {moduleLabels[module] || module}
                    </Badge>
                  );
                })}
                
                {(!organization.modules || organization.modules.length === 0) && (
                  <p className="text-gray-500">Nenhum módulo contratado</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="documents" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Documentos Enviados</CardTitle>
              <CardDescription>
                Documentos enviados pela organização para verificação
              </CardDescription>
            </CardHeader>
            <CardContent>
              {documents.length === 0 ? (
                <div className="py-8 text-center">
                  <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <h3 className="text-lg font-medium">Nenhum documento enviado</h3>
                  <p className="text-gray-500 mt-1">
                    Esta organização ainda não enviou nenhum documento para verificação
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {documents.map((doc) => (
                    <div 
                      key={doc.id} 
                      className={`border rounded-lg p-4 ${
                        doc.status === 'rejected' ? 'border-red-200 bg-red-50' : 
                        doc.status === 'verified' ? 'border-green-200 bg-green-50' : 
                        'border-gray-200'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex items-start gap-3">
                          <div className="p-2 bg-white rounded-lg shadow-sm">
                            <FileText className="w-5 h-5 text-gray-600" />
                          </div>
                          <div>
                            <h4 className="font-medium">{doc.name}</h4>
                            <div className="flex flex-wrap gap-2 mt-1">
                              <p className="text-xs text-gray-500">
                                Enviado em {formatDate(doc.uploaded)}
                              </p>
                              <p className="text-xs text-gray-500">
                                {doc.size}
                              </p>
                              {getDocumentStatusBadge(doc.status)}
                            </div>
                            
                            {doc.status === 'rejected' && doc.reject_reason && (
                              <div className="mt-2 text-sm text-red-700">
                                <p className="font-medium">Motivo da rejeição:</p>
                                <p>{doc.reject_reason}</p>
                              </div>
                            )}
                          </div>
                        </div>
                        <Button variant="ghost" size="icon">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="activities" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Atividades</CardTitle>
              <CardDescription>
                Registro de todas as atividades relacionadas a esta organização
              </CardDescription>
            </CardHeader>
            <CardContent>
              {activities.length === 0 ? (
                <div className="py-8 text-center">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <h3 className="text-lg font-medium">Nenhuma atividade registrada</h3>
                  <p className="text-gray-500 mt-1">
                    Não há registro de atividades para esta organização
                  </p>
                </div>
              ) : (
                <div className="relative">
                  <div className="absolute top-0 bottom-0 left-5 w-0.5 bg-gray-200"></div>
                  <div className="space-y-6">
                    {activities.map((activity) => (
                      <div key={activity.id} className="relative pl-12">
                        <div className="absolute left-0 p-2 bg-white rounded-full border border-gray-200 z-10">
                          <Avatar className="h-6 w-6">
                            <AvatarFallback className="text-xs">
                              {activity.user.avatar}
                            </AvatarFallback>
                          </Avatar>
                        </div>
                        <div>
                          <div className="flex items-start gap-2">
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <p className="font-medium">{activity.user.name}</p>
                                <p className="text-sm text-gray-500">
                                  {formatDateTime(activity.timestamp)}
                                </p>
                              </div>
                              
                              <p className="text-gray-700 mt-1">{activity.details}</p>
                              
                              {activity.notes && (
                                <div className="mt-2 p-3 bg-gray-50 border rounded-md text-sm">
                                  {activity.notes}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Approve Organization Dialog */}
      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              Aprovar Organização
            </DialogTitle>
            <DialogDescription>
              Você está prestes a aprovar {organization.name}. Isso permitirá que a organização acesse a plataforma.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Label htmlFor="approvalNotes">Observações (opcional)</Label>
            <Textarea
              id="approvalNotes"
              placeholder="Adicione qualquer observação sobre esta aprovação"
              value={approvalNotes}
              onChange={(e) => setApprovalNotes(e.target.value)}
              className="mt-2"
            />
          </div>
          
          <DialogFooter className="flex space-x-2">
            <Button 
              variant="outline" 
              onClick={() => setShowApproveDialog(false)}
              disabled={processingAction}
            >
              Cancelar
            </Button>
            <Button 
              className="bg-green-600 hover:bg-green-700"
              onClick={handleApprove}
              disabled={processingAction}
            >
              {processingAction ? (
                <>
                  <div className="w-4 h-4 border-2 border-t-transparent border-white rounded-full animate-spin mr-2"></div>
                  Aprovando...
                </>
              ) : 'Aprovar Organização'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Reject Organization Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <XCircle className="w-5 h-5 text-red-500" />
              Rejeitar Organização
            </DialogTitle>
            <DialogDescription>
              Você está prestes a rejeitar {organization.name}. Por favor, forneça um motivo para a rejeição.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Label htmlFor="rejectionReason" className="text-red-500 font-medium">Motivo da Rejeição*</Label>
            <Textarea
              id="rejectionReason"
              placeholder="Descreva o motivo da rejeição"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              className="mt-2"
            />
            <p className="text-sm text-gray-500 mt-2">
              *Este motivo será visível para o solicitante
            </p>
          </div>
          
          <DialogFooter className="flex space-x-2">
            <Button 
              variant="outline" 
              onClick={() => setShowRejectDialog(false)}
              disabled={processingAction}
            >
              Cancelar
            </Button>
            <Button 
              variant="destructive"
              onClick={handleReject}
              disabled={processingAction || !rejectionReason.trim()}
            >
              {processingAction ? (
                <>
                  <div className="w-4 h-4 border-2 border-t-transparent border-white rounded-full animate-spin mr-2"></div>
                  Rejeitando...
                </>
              ) : 'Rejeitar Organização'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}