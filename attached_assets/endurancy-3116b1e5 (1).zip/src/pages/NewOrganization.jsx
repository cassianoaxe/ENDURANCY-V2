
import React, { useState } from 'react';
import { Organization } from "@/api/entities";
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { 
  ArrowLeft, 
  Building2, 
  Check, 
  CircleDashed, 
  MapPin, 
  Phone, 
  UserPlus, 
  Mail, 
  Upload, 
  Clock, 
  FileText,
  Info,
  AlertTriangle,
  ChevronRight,
  Building,
  User
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function NewOrganization() {
  const navigate = useNavigate();
  
  const [step, setStep] = useState(1);
  const [formType, setFormType] = useState('empresa');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  
  const [organizationData, setOrganizationData] = useState({
    name: '',
    type: 'Empresa',
    description: '',
    contact_name: '',
    contact_email: '',
    contact_phone: '',
    address: JSON.stringify({
      street: '',
      number: '',
      complement: '',
      neighborhood: '',
      city: '',
      state: '',
      zip: '',
      country: 'Brasil'
    }),
    plan: 'Empresarial Básico',
    status: 'Pendente'
  });
  
  const handleInputChange = (field, value) => {
    setOrganizationData({
      ...organizationData,
      [field]: value
    });
    
    if (errors[field]) {
      setErrors({
        ...errors,
        [field]: null
      });
    }
  };
  
  const handleAddressChange = (field, value) => {
    try {
      const addressObj = JSON.parse(organizationData.address);
      addressObj[field] = value;
      
      setOrganizationData({
        ...organizationData,
        address: JSON.stringify(addressObj)
      });
      
      if (errors[`address.${field}`]) {
        setErrors({
          ...errors,
          [`address.${field}`]: null
        });
      }
    } catch (error) {
      console.error("Error updating address:", error);
    }
  };
  
  const getAddressValue = (field) => {
    try {
      const addressObj = JSON.parse(organizationData.address);
      return addressObj[field] || '';
    } catch (error) {
      console.error("Error getting address value:", error);
      return '';
    }
  };
  
  const validateStep = (currentStep) => {
    const newErrors = {};
    
    if (currentStep === 1) {
      if (!organizationData.name.trim()) {
        newErrors.name = 'Nome da organização é obrigatório';
      }
      
      if (!organizationData.description.trim()) {
        newErrors.description = 'Descrição da organização é obrigatória';
      }
    }
    
    if (currentStep === 2) {
      if (!organizationData.contact_name.trim()) {
        newErrors['contact_name'] = 'Nome do contato é obrigatório';
      }
      
      if (!organizationData.contact_email.trim()) {
        newErrors['contact_email'] = 'Email do contato é obrigatório';
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(organizationData.contact_email)) {
        newErrors['contact_email'] = 'Email inválido';
      }
      
      if (!organizationData.contact_phone.trim()) {
        newErrors['contact_phone'] = 'Telefone do contato é obrigatório';
      }
    }
    
    if (currentStep === 3) {
      const addressFields = ['street', 'number', 'city', 'state', 'zip'];
      const addressObj = JSON.parse(organizationData.address);
      
      addressFields.forEach(field => {
        if (!addressObj[field]?.trim()) {
          newErrors[`address.${field}`] = `${field === 'zip' ? 'CEP' : field === 'number' ? 'Número' : field === 'street' ? 'Rua' : field === 'city' ? 'Cidade' : 'Estado'} é obrigatório`;
        }
      });
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleNextStep = () => {
    if (validateStep(step)) {
      setStep(step + 1);
      window.scrollTo(0, 0);
    }
  };
  
  const handlePreviousStep = () => {
    setStep(step - 1);
    window.scrollTo(0, 0);
  };
  
  const handleSubmit = async () => {
    try {
      setIsSubmitting(true);
      await Organization.create(organizationData);
      navigate(createPageUrl("Organizations"));
    } catch (error) {
      console.error("Error creating organization:", error);
      setErrors({
        submit: 'Ocorreu um erro ao criar a organização. Por favor, tente novamente.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const getInitials = (name) => {
    if (!name) return 'O';
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };
  
  const renderStepIndicator = () => {
    return (
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-500'}`}>
            {step > 1 ? <Check className="w-5 h-5" /> : 1}
          </div>
          <div className={`w-10 h-1 ${step >= 2 ? 'bg-green-500' : 'bg-gray-200'}`}></div>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-500'}`}>
            {step > 2 ? <Check className="w-5 h-5" /> : 2}
          </div>
          <div className={`w-10 h-1 ${step >= 3 ? 'bg-green-500' : 'bg-gray-200'}`}></div>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-500'}`}>
            {step > 3 ? <Check className="w-5 h-5" /> : 3}
          </div>
          <div className={`w-10 h-1 ${step >= 4 ? 'bg-green-500' : 'bg-gray-200'}`}></div>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 4 ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-500'}`}>
            {step > 4 ? <Check className="w-5 h-5" /> : 4}
          </div>
        </div>
      </div>
    );
  };
  
  const renderStepTitle = () => {
    switch (step) {
      case 1:
        return 'Informações Básicas';
      case 2:
        return 'Dados de Contato';
      case 3:
        return 'Endereço';
      case 4:
        return 'Plano e Revisão';
      default:
        return '';
    }
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate(createPageUrl("Organizations"))}
          className="mr-4"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">Nova Organização</h1>
          <p className="text-gray-500 mt-1">
            Cadastre uma nova organização na plataforma
          </p>
        </div>
      </div>
      
      {renderStepIndicator()}
      
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>{renderStepTitle()}</CardTitle>
          <CardDescription>
            {step === 1 && 'Informe os dados básicos da organização'}
            {step === 2 && 'Informe os dados do contato principal'}
            {step === 3 && 'Informe o endereço da organização'}
            {step === 4 && 'Revise os dados e escolha o plano'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {step === 1 && (
            <>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="org-type">Tipo de Organização</Label>
                  <RadioGroup 
                    defaultValue={formType}
                    onValueChange={(value) => {
                      setFormType(value);
                      handleInputChange('type', value === 'empresa' ? 'Empresa' : 'Associação');
                    }}
                    className="flex flex-col space-y-1"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="empresa" id="empresa" />
                      <Label htmlFor="empresa" className="cursor-pointer">Empresa</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="associacao" id="associacao" />
                      <Label htmlFor="associacao" className="cursor-pointer">Associação</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="name">Nome da Organização*</Label>
                  <Input 
                    id="name" 
                    value={organizationData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder={formType === 'empresa' ? "Ex: Cannabis Brasil Medicinal" : "Ex: Associação Médica Verde"}
                    className={errors.name ? 'border-red-500' : ''}
                  />
                  {errors.name && (
                    <p className="text-sm text-red-500">{errors.name}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Descrição*</Label>
                  <Textarea 
                    id="description" 
                    value={organizationData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    placeholder="Descreva a organização, sua atuação e objetivos"
                    rows={4}
                    className={errors.description ? 'border-red-500' : ''}
                  />
                  {errors.description && (
                    <p className="text-sm text-red-500">{errors.description}</p>
                  )}
                </div>
                
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    As informações básicas são importantes para identificar corretamente a organização na plataforma.
                  </AlertDescription>
                </Alert>
              </div>
            </>
          )}
          
          {step === 2 && (
            <>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="contact_name">Nome do Contato*</Label>
                  <Input 
                    id="contact_name" 
                    value={organizationData.contact_name}
                    onChange={(e) => handleInputChange('contact_name', e.target.value)}
                    placeholder="Nome completo do responsável"
                    className={errors.contact_name ? 'border-red-500' : ''}
                  />
                  {errors.contact_name && (
                    <p className="text-sm text-red-500">{errors.contact_name}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="contact_email">Email do Contato*</Label>
                  <Input 
                    id="contact_email" 
                    type="email"
                    value={organizationData.contact_email}
                    onChange={(e) => handleInputChange('contact_email', e.target.value)}
                    placeholder="email@exemplo.com"
                    className={errors.contact_email ? 'border-red-500' : ''}
                  />
                  {errors.contact_email && (
                    <p className="text-sm text-red-500">{errors.contact_email}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="contact_phone">Telefone do Contato*</Label>
                  <Input 
                    id="contact_phone" 
                    value={organizationData.contact_phone}
                    onChange={(e) => handleInputChange('contact_phone', e.target.value)}
                    placeholder="+55 (XX) XXXXX-XXXX"
                    className={errors.contact_phone ? 'border-red-500' : ''}
                  />
                  {errors.contact_phone && (
                    <p className="text-sm text-red-500">{errors.contact_phone}</p>
                  )}
                </div>
                
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    O contato informado receberá notificações importantes sobre a organização e será o administrador inicial.
                  </AlertDescription>
                </Alert>
              </div>
            </>
          )}
          
          {step === 3 && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="street">Rua/Avenida*</Label>
                  <Input 
                    id="street" 
                    value={getAddressValue('street')}
                    onChange={(e) => handleAddressChange('street', e.target.value)}
                    placeholder="Nome da rua ou avenida"
                    className={errors['address.street'] ? 'border-red-500' : ''}
                  />
                  {errors['address.street'] && (
                    <p className="text-sm text-red-500">{errors['address.street']}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="number">Número*</Label>
                  <Input 
                    id="number" 
                    value={getAddressValue('number')}
                    onChange={(e) => handleAddressChange('number', e.target.value)}
                    placeholder="123"
                    className={errors['address.number'] ? 'border-red-500' : ''}
                  />
                  {errors['address.number'] && (
                    <p className="text-sm text-red-500">{errors['address.number']}</p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="complement">Complemento</Label>
                  <Input 
                    id="complement" 
                    value={getAddressValue('complement')}
                    onChange={(e) => handleAddressChange('complement', e.target.value)}
                    placeholder="Sala, andar, etc."
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="neighborhood">Bairro</Label>
                  <Input 
                    id="neighborhood" 
                    value={getAddressValue('neighborhood')}
                    onChange={(e) => handleAddressChange('neighborhood', e.target.value)}
                    placeholder="Nome do bairro"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">Cidade*</Label>
                  <Input 
                    id="city" 
                    value={getAddressValue('city')}
                    onChange={(e) => handleAddressChange('city', e.target.value)}
                    placeholder="Nome da cidade"
                    className={errors['address.city'] ? 'border-red-500' : ''}
                  />
                  {errors['address.city'] && (
                    <p className="text-sm text-red-500">{errors['address.city']}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="state">Estado*</Label>
                  <Select 
                    value={getAddressValue('state')}
                    onValueChange={(value) => handleAddressChange('state', value)}
                  >
                    <SelectTrigger id="state" className={errors['address.state'] ? 'border-red-500' : ''}>
                      <SelectValue placeholder="Selecione o estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="AC">Acre</SelectItem>
                      <SelectItem value="AL">Alagoas</SelectItem>
                      <SelectItem value="AP">Amapá</SelectItem>
                      <SelectItem value="AM">Amazonas</SelectItem>
                      <SelectItem value="BA">Bahia</SelectItem>
                      <SelectItem value="CE">Ceará</SelectItem>
                      <SelectItem value="DF">Distrito Federal</SelectItem>
                      <SelectItem value="ES">Espírito Santo</SelectItem>
                      <SelectItem value="GO">Goiás</SelectItem>
                      <SelectItem value="MA">Maranhão</SelectItem>
                      <SelectItem value="MT">Mato Grosso</SelectItem>
                      <SelectItem value="MS">Mato Grosso do Sul</SelectItem>
                      <SelectItem value="MG">Minas Gerais</SelectItem>
                      <SelectItem value="PA">Pará</SelectItem>
                      <SelectItem value="PB">Paraíba</SelectItem>
                      <SelectItem value="PR">Paraná</SelectItem>
                      <SelectItem value="PE">Pernambuco</SelectItem>
                      <SelectItem value="PI">Piauí</SelectItem>
                      <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                      <SelectItem value="RN">Rio Grande do Norte</SelectItem>
                      <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                      <SelectItem value="RO">Rondônia</SelectItem>
                      <SelectItem value="RR">Roraima</SelectItem>
                      <SelectItem value="SC">Santa Catarina</SelectItem>
                      <SelectItem value="SP">São Paulo</SelectItem>
                      <SelectItem value="SE">Sergipe</SelectItem>
                      <SelectItem value="TO">Tocantins</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors['address.state'] && (
                    <p className="text-sm text-red-500">{errors['address.state']}</p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="zip">CEP*</Label>
                  <Input 
                    id="zip" 
                    value={getAddressValue('zip')}
                    onChange={(e) => handleAddressChange('zip', e.target.value)}
                    placeholder="00000-000"
                    className={errors['address.zip'] ? 'border-red-500' : ''}
                  />
                  {errors['address.zip'] && (
                    <p className="text-sm text-red-500">{errors['address.zip']}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="country">País</Label>
                  <Input 
                    id="country" 
                    value={getAddressValue('country')}
                    onChange={(e) => handleAddressChange('country', e.target.value)}
                    disabled
                  />
                </div>
              </div>
            </>
          )}
          
          {step === 4 && (
            <>
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Selecione o Plano</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {formType === 'empresa' ? (
                      <>
                        <div 
                          className={`border rounded-lg p-4 cursor-pointer ${organizationData.plan === 'Empresarial Básico' ? 'border-green-500 bg-green-50' : 'hover:border-gray-400'}`}
                          onClick={() => handleInputChange('plan', 'Empresarial Básico')}
                        >
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h4 className="font-medium">Empresarial Básico</h4>
                              <p className="text-sm text-gray-500">Para empresas iniciantes</p>
                            </div>
                            <div className="w-6 h-6 rounded-full border border-gray-300 flex items-center justify-center">
                              {organizationData.plan === 'Empresarial Básico' && (
                                <Check className="w-4 h-4 text-green-500" />
                              )}
                            </div>
                          </div>
                          <div className="mb-4">
                            <p className="text-2xl font-bold">R$299<span className="text-sm font-normal text-gray-500">/mês</span></p>
                          </div>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Até 5 usuários</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Gestão básica de pacientes</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Controle de estoque simples</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Suporte por email</span>
                            </li>
                          </ul>
                        </div>
                        
                        <div 
                          className={`border rounded-lg p-4 cursor-pointer ${organizationData.plan === 'Empresarial Pro' ? 'border-green-500 bg-green-50' : 'hover:border-gray-400'}`}
                          onClick={() => handleInputChange('plan', 'Empresarial Pro')}
                        >
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <Badge className="mb-2 bg-blue-100 text-blue-800 hover:bg-blue-100">Recomendado</Badge>
                              <h4 className="font-medium">Empresarial Pro</h4>
                              <p className="text-sm text-gray-500">Para empresas em crescimento</p>
                            </div>
                            <div className="w-6 h-6 rounded-full border border-gray-300 flex items-center justify-center">
                              {organizationData.plan === 'Empresarial Pro' && (
                                <Check className="w-4 h-4 text-green-500" />
                              )}
                            </div>
                          </div>
                          <div className="mb-4">
                            <p className="text-2xl font-bold">R$599<span className="text-sm font-normal text-gray-500">/mês</span></p>
                          </div>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Até 20 usuários</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Gestão avançada de pacientes</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Controle de estoque completo</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Suporte prioritário</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>API de integração</span>
                            </li>
                          </ul>
                        </div>
                      </>
                    ) : (
                      <>
                        <div 
                          className={`border rounded-lg p-4 cursor-pointer ${organizationData.plan === 'Associação Plus' ? 'border-green-500 bg-green-50' : 'hover:border-gray-400'}`}
                          onClick={() => handleInputChange('plan', 'Associação Plus')}
                        >
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h4 className="font-medium">Associação Plus</h4>
                              <p className="text-sm text-gray-500">Para associações iniciantes</p>
                            </div>
                            <div className="w-6 h-6 rounded-full border border-gray-300 flex items-center justify-center">
                              {organizationData.plan === 'Associação Plus' && (
                                <Check className="w-4 h-4 text-green-500" />
                              )}
                            </div>
                          </div>
                          <div className="mb-4">
                            <p className="text-2xl font-bold">R$399<span className="text-sm font-normal text-gray-500">/mês</span></p>
                          </div>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Até 10 usuários</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Gestão de associados</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Controle de cultivo básico</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Portal de associados</span>
                            </li>
                          </ul>
                        </div>
                        
                        <div 
                          className={`border rounded-lg p-4 cursor-pointer ${organizationData.plan === 'Associação Premium' ? 'border-green-500 bg-green-50' : 'hover:border-gray-400'}`}
                          onClick={() => handleInputChange('plan', 'Associação Premium')}
                        >
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <Badge className="mb-2 bg-blue-100 text-blue-800 hover:bg-blue-100">Recomendado</Badge>
                              <h4 className="font-medium">Associação Premium</h4>
                              <p className="text-sm text-gray-500">Para associações estabelecidas</p>
                            </div>
                            <div className="w-6 h-6 rounded-full border border-gray-300 flex items-center justify-center">
                              {organizationData.plan === 'Associação Premium' && (
                                <Check className="w-4 h-4 text-green-500" />
                              )}
                            </div>
                          </div>
                          <div className="mb-4">
                            <p className="text-2xl font-bold">R$799<span className="text-sm font-normal text-gray-500">/mês</span></p>
                          </div>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Usuários ilimitados</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Gestão avançada de associados</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Controle de cultivo avançado</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Portal premium para associados</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Módulo de eventos e financeiro</span>
                            </li>
                          </ul>
                        </div>
                      </>
                    )}
                  </div>
                </div>
                
                <div className="border-t pt-6 space-y-4">
                  <h3 className="text-lg font-medium">Revisão dos Dados</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-gray-500" />
                          Dados da Organização
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Nome:</span>
                          <span className="font-medium">{organizationData.name}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Tipo:</span>
                          <span className="font-medium">{organizationData.type}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500">Plano:</span>
                          <span className="font-medium">{organizationData.plan}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Descrição:</span>
                          <p className="mt-1">{organizationData.description}</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base flex items-center gap-2">
                          <User className="w-4 h-4 text-gray-500" />
                          Contato Principal
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="text-sm space-y-2">
                        <div className="flex items-center gap-3 mb-2">
                          <Avatar>
                            <AvatarFallback>{getInitials(organizationData.contact_name)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{organizationData.contact_name}</p>
                            <p className="text-gray-500">{organizationData.contact_email}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-gray-500" />
                          <span>{organizationData.contact_phone}</span>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="md:col-span-2">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-gray-500" />
                          Endereço
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="text-sm">
                        <p>
                          {getAddressValue('street')}, {getAddressValue('number')}
                          {getAddressValue('complement') && `, ${getAddressValue('complement')}`}
                          {getAddressValue('neighborhood') && `, ${getAddressValue('neighborhood')}`}
                        </p>
                        <p>
                          {getAddressValue('city')} - {getAddressValue('state')}, {getAddressValue('zip')}
                        </p>
                        <p>{getAddressValue('country')}</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
                
                <Alert className="bg-yellow-50 border-yellow-200">
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                  <AlertTitle className="text-yellow-700">Atenção</AlertTitle>
                  <AlertDescription className="text-yellow-700">
                    Após criar a organização, ela passará por um processo de revisão antes de ser aprovada.
                    Você receberá uma notificação por email quando o processo for concluído.
                  </AlertDescription>
                </Alert>
                
                {errors.submit && (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      {errors.submit}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </>
          )}
        </CardContent>
        <CardFooter className="border-t pt-6 flex justify-between">
          {step > 1 ? (
            <Button variant="outline" onClick={handlePreviousStep}>
              Voltar
            </Button>
          ) : (
            <Button variant="outline" onClick={() => navigate(createPageUrl("Organizations"))}>
              Cancelar
            </Button>
          )}
          
          {step < 4 ? (
            <Button onClick={handleNextStep}>
              Próximo
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          ) : (
            <Button 
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="bg-green-600 hover:bg-green-700 gap-2"
            >
              {isSubmitting ? (
                <>
                  <CircleDashed className="w-4 h-4 animate-spin" />
                  Processando...
                </>
              ) : (
                <>
                  <Building className="w-4 h-4" />
                  Criar Organização
                </>
              )}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}
