import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Box, 
  PackageCheck, 
  Printer, 
  Archive, 
  BoxSelect, 
  Truck, 
  ScanLine, 
  PackageOpen,
  TrendingUp,
  Clock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  PackageX,
  ChevronRight,
  Eye,
  ScanBarcode
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';

// Dados simulados para o dashboard
const pendingOrdersData = [
  { id: 1, orderNumber: "PED-12345", customer: "João Silva", status: "Em preparação", priority: "Urgente", items: 3, date: "2023-11-15" },
  { id: 2, orderNumber: "PED-12346", customer: "Maria Oliveira", status: "Aguardando", priority: "Normal", items: 2, date: "2023-11-15" },
  { id: 3, orderNumber: "PED-12347", customer: "Carlos Santos", status: "Em revisão", priority: "Urgente", items: 1, date: "2023-11-15" },
  { id: 4, orderNumber: "PED-12348", customer: "Ana Costa", status: "Aguardando", priority: "Normal", items: 5, date: "2023-11-15" },
];

const shipmentData = [
  { id: 1, shipmentCode: "MALOTE-001", trackingCount: 12, shippingDate: "2023-11-15", status: "Entregue" },
  { id: 2, shipmentCode: "MALOTE-002", trackingCount: 8, shippingDate: "2023-11-15", status: "Em trânsito" },
  { id: 3, shipmentCode: "MALOTE-003", trackingCount: 15, shippingDate: "2023-11-14", status: "Em trânsito" },
  { id: 4, shipmentCode: "MALOTE-004", trackingCount: 10, shippingDate: "2023-11-14", status: "Entregue" },
];

const dailyStats = [
  { day: 'Seg', pedidos: 24, entregas: 20 },
  { day: 'Ter', pedidos: 28, entregas: 22 },
  { day: 'Qua', pedidos: 30, entregas: 25 },
  { day: 'Qui', pedidos: 35, entregas: 30 },
  { day: 'Sex', pedidos: 25, entregas: 18 },
  { day: 'Sáb', pedidos: 15, entregas: 12 },
  { day: 'Dom', pedidos: 8, entregas: 5 },
];

export default function ExpedicaoDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [pendingOrders, setPendingOrders] = useState(pendingOrdersData);
  const [shipments, setShipments] = useState(shipmentData);
  const [isLoading, setIsLoading] = useState(false);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard de Expedição</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1">
          Acompanhe o status de pedidos, malotes e entregas
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Pedidos Hoje</CardTitle>
            <div className="text-2xl font-bold">24</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-green-600 flex items-center mt-2">
              <TrendingUp className="w-3 h-3 mr-1" />
              <span>+12% em relação a ontem</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Pedidos Aguardando</CardTitle>
            <div className="text-2xl font-bold">18</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-yellow-600 flex items-center mt-2">
              <Clock className="w-3 h-3 mr-1" />
              <span>5 pedidos urgentes</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Malotes Enviados</CardTitle>
            <div className="text-2xl font-bold">4</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-blue-600 flex items-center mt-2">
              <Truck className="w-3 h-3 mr-1" />
              <span>45 pedidos processados</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Taxa de Entrega</CardTitle>
            <div className="text-2xl font-bold">97%</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-green-600 flex items-center mt-2">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              <span>+2% em relação ao mês anterior</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="orders">Pedidos</TabsTrigger>
          <TabsTrigger value="shipments">Malotes</TabsTrigger>
          <TabsTrigger value="tracking">Rastreamento</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Desempenho Semanal</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={dailyStats}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="pedidos" name="Pedidos" fill="#4F46E5" />
                      <Bar dataKey="entregas" name="Entregas" fill="#10B981" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Status de Pedidos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm font-medium">Em preparação</div>
                      <div className="text-sm text-gray-500">8 pedidos</div>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 rounded-full" style={{ width: '30%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm font-medium">Em revisão</div>
                      <div className="text-sm text-gray-500">4 pedidos</div>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: '15%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm font-medium">Documentação</div>
                      <div className="text-sm text-gray-500">6 pedidos</div>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-purple-500 rounded-full" style={{ width: '22%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm font-medium">Aguardando despacho</div>
                      <div className="text-sm text-gray-500">9 pedidos</div>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 rounded-full" style={{ width: '33%' }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Pedidos Prioritários</CardTitle>
                  <Link to={createPageUrl("ExpedicaoPreparacao")}>
                    <Button variant="outline" size="sm">Ver todos</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingOrders.filter(order => order.priority === "Urgente").map(order => (
                    <div key={order.id} className="flex items-center justify-between p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-md">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Urgente</Badge>
                        <div>
                          <p className="font-medium">{order.orderNumber}</p>
                          <p className="text-sm text-gray-500">{order.customer}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Eye className="w-4 h-4 mr-2" />
                        Detalhes
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Rastreios Recentes</CardTitle>
                  <Link to={createPageUrl("ExpedicaoRastreios")}>
                    <Button variant="outline" size="sm">Atualizar rastreios</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-md">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Entregue</Badge>
                      <div>
                        <p className="font-medium">LE123456789BR</p>
                        <p className="text-sm text-gray-500">João Silva - 15/11/2023</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </div>

                  <div className="flex items-center justify-between p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-md">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Em trânsito</Badge>
                      <div>
                        <p className="font-medium">LE123456790BR</p>
                        <p className="text-sm text-gray-500">Maria Oliveira - 15/11/2023</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </div>

                  <div className="flex items-center justify-between p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-md">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Em fiscalização</Badge>
                      <div>
                        <p className="font-medium">LE123456791BR</p>
                        <p className="text-sm text-gray-500">Carlos Santos - 14/11/2023</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="orders" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Pedidos Aguardando Preparação</CardTitle>
                <Link to={createPageUrl("ExpedicaoPreparacao")}>
                  <Button>Preparar Pedidos</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Pedido</TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Prioridade</TableHead>
                      <TableHead>Itens</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingOrders.map(order => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">{order.orderNumber}</TableCell>
                        <TableCell>{order.customer}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={
                            order.status === 'Em preparação' ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                            order.status === 'Em revisão' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                            'bg-gray-50 text-gray-700 border-gray-200'
                          }>
                            {order.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={
                            order.priority === 'Urgente' ? 'bg-red-50 text-red-700 border-red-200' :
                            'bg-gray-50 text-gray-700 border-gray-200'
                          }>
                            {order.priority}
                          </Badge>
                        </TableCell>
                        <TableCell>{order.items}</TableCell>
                        <TableCell>{order.date}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shipments" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Registro de Malotes</CardTitle>
                <Link to={createPageUrl("ExpedicaoMalotes")}>
                  <Button>Novo Malote</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Código</TableHead>
                      <TableHead>Rastreios</TableHead>
                      <TableHead>Data de Envio</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {shipments.map(shipment => (
                      <TableRow key={shipment.id}>
                        <TableCell className="font-medium">{shipment.shipmentCode}</TableCell>
                        <TableCell>{shipment.trackingCount} rastreios</TableCell>
                        <TableCell>{shipment.shippingDate}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={
                            shipment.status === 'Entregue' ? 'bg-green-50 text-green-700 border-green-200' :
                            shipment.status === 'Em trânsito' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                            'bg-gray-50 text-gray-700 border-gray-200'
                          }>
                            {shipment.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tracking" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Monitoramento de Rastreios</CardTitle>
                <Link to={createPageUrl("ExpedicaoRastreios")}>
                  <Button>Gerenciar Rastreios</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-green-600">45</div>
                      <p className="text-sm text-gray-500 mt-2">Entregas Confirmadas</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-blue-600">23</div>
                      <p className="text-sm text-gray-500 mt-2">Em Trânsito</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-red-600">3</div>
                      <p className="text-sm text-gray-500 mt-2">Entregas Atrasadas</p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 border rounded-md">
                  <div className="flex items-center gap-3">
                    <Badge className="bg-red-100 text-red-800">Atrasado</Badge>
                    <div>
                      <p className="font-medium">LE123456792BR</p>
                      <p className="text-sm text-gray-500">Ana Costa - 3 dias em atraso</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">Verificar</Button>
                </div>

                <div className="flex justify-between items-center p-3 border rounded-md">
                  <div className="flex items-center gap-3">
                    <Badge className="bg-yellow-100 text-yellow-800">Em Fiscalização</Badge>
                    <div>
                      <p className="font-medium">LE123456791BR</p>
                      <p className="text-sm text-gray-500">Carlos Santos - 2 dias em fiscalização</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">Verificar</Button>
                </div>

                <div className="flex justify-between items-center p-3 border rounded-md">
                  <div className="flex items-center gap-3">
                    <Badge className="bg-blue-100 text-blue-800">Em Trânsito</Badge>
                    <div>
                      <p className="font-medium">LE123456795BR</p>
                      <p className="text-sm text-gray-500">Paulo Rocha - Previsão: 18/11/2023</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">Verificar</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}