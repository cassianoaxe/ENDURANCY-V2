import React from 'react';
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function TasksSettings() {
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold">Configurações de Tarefas</h1>
      
      {/* Task settings configuration would go here */}
    </div>
  );
}