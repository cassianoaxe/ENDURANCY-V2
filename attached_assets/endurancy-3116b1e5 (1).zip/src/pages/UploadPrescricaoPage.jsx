import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { PrescricaoFarmaceutica } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { User } from '@/api/entities';
import { toast } from '@/components/ui/use-toast';
import {
  ArrowLeft,
  Upload,
  FileUp,
  FileText,
  Trash2,
  CheckCircle,
  AlertCircle,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Spinner } from '@/components/ui/spinner';

export default function UploadPrescricaoPage() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [file, setFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [validadeStr, setValidadeStr] = useState('');
  const [medicoNome, setMedicoNome] = useState('');
  const [medicoCrm, setMedicoCrm] = useState('');
  const [medicoEspecialidade, setMedicoEspecialidade] = useState('');

  // Get current user on component mount
  useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error loading user", error);
      toast({
        title: "Erro de autenticação",
        description: "Você precisa estar logado para enviar prescrições.",
        variant: "destructive",
      });
      navigate(createPageUrl("Access"));
    }
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      if (selectedFile.type !== 'application/pdf' && 
          !selectedFile.type.startsWith('image/')) {
        setErrorMessage('Por favor, envie um arquivo PDF ou uma imagem.');
        setFile(null);
        setFilePreview(null);
        return;
      }

      setFile(selectedFile);
      setErrorMessage('');

      // Create file preview URL if it's an image
      if (selectedFile.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setFilePreview(e.target.result);
        };
        reader.readAsDataURL(selectedFile);
      } else {
        setFilePreview(null);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!file) {
      setErrorMessage('Por favor, selecione um arquivo de prescrição para enviar.');
      return;
    }

    if (!validadeStr) {
      setErrorMessage('Por favor, informe a data de validade da prescrição.');
      return;
    }

    if (!medicoNome || !medicoCrm) {
      setErrorMessage('Por favor, preencha os dados do médico prescritor.');
      return;
    }

    try {
      setUploading(true);
      setErrorMessage('');

      // Upload file
      const uploadedFile = await UploadFile({ file });
      
      // Create prescription record
      const prescricaoData = {
        organization_id: currentUser?.organization_id || 'default_org',
        paciente_id: currentUser?.id,
        arquivo_url: uploadedFile.file_url,
        data_envio: new Date().toISOString(),
        validade_prescricao: validadeStr,
        dados_medico: {
          nome: medicoNome,
          crm: medicoCrm,
          especialidade: medicoEspecialidade
        },
        status: 'pendente'
      };
      
      // Save to database
      await PrescricaoFarmaceutica.create(prescricaoData);
      
      setSubmitSuccess(true);
      toast({
        title: "Prescrição enviada com sucesso",
        description: "Sua prescrição foi enviada e será analisada por um farmacêutico.",
      });
      
      // Redirect after a short delay
      setTimeout(() => {
        navigate(createPageUrl("PrescricoesAssociados"));
      }, 3000);
      
    } catch (error) {
      console.error("Error uploading prescription", error);
      setErrorMessage('Ocorreu um erro ao enviar sua prescrição. Por favor, tente novamente.');
    } finally {
      setUploading(false);
    }
  };

  const handleCancel = () => {
    navigate(createPageUrl("PrescricoesAssociados"));
  };

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={handleCancel}
          className="mr-4"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">Enviar Nova Prescrição</h1>
          <p className="text-gray-500 mt-1">
            Envie sua prescrição médica para análise e aprovação
          </p>
        </div>
      </div>

      {submitSuccess ? (
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center justify-center py-10">
              <div className="bg-green-100 p-3 rounded-full">
                <CheckCircle className="h-12 w-12 text-green-600" />
              </div>
              <h2 className="text-xl font-semibold mt-4">Prescrição Enviada com Sucesso!</h2>
              <p className="text-gray-500 text-center max-w-md mt-2">
                Sua prescrição foi enviada e está aguardando análise. 
                Você receberá uma notificação quando for aprovada.
              </p>
              <Button 
                className="mt-6" 
                onClick={() => navigate(createPageUrl("PrescricoesAssociados"))}
              >
                Voltar para Minhas Prescrições
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Informações da Prescrição</CardTitle>
            <CardDescription>
              Envie uma imagem ou PDF da sua prescrição médica para análise
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              {errorMessage && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Erro</AlertTitle>
                  <AlertDescription>{errorMessage}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-4">
                <div className="grid gap-6">
                  <div className="grid gap-3">
                    <Label htmlFor="prescription-file">Arquivo da Prescrição</Label>
                    <div className="grid gap-1">
                      {file ? (
                        <div className="flex items-center justify-between border rounded-lg p-3">
                          <div className="flex items-center">
                            <FileText className="h-10 w-10 text-blue-500 mr-3" />
                            <div>
                              <p className="font-medium">{file.name}</p>
                              <p className="text-xs text-gray-500">
                                {(file.size / 1024 / 1024).toFixed(2)} MB - {file.type}
                              </p>
                            </div>
                          </div>
                          <Button 
                            type="button" 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => {
                              setFile(null);
                              setFilePreview(null);
                            }}
                          >
                            <Trash2 className="h-5 w-5 text-gray-500" />
                          </Button>
                        </div>
                      ) : (
                        <div 
                          className="border-2 border-dashed rounded-lg p-8 text-center hover:bg-gray-50 transition-colors cursor-pointer"
                          onClick={() => document.getElementById('prescription-file').click()}
                        >
                          <Upload className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                          <p className="text-sm font-medium mb-1">Arraste e solte o arquivo aqui ou clique para selecionar</p>
                          <p className="text-xs text-gray-500">Suporta PDF, JPG ou PNG (até 10MB)</p>
                        </div>
                      )}
                      <input
                        id="prescription-file"
                        type="file"
                        accept=".pdf,image/*"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                    </div>
                    <p className="text-sm text-gray-500">
                      Certifique-se de que a prescrição está legível e contém o nome do médico, CRM e data.
                    </p>
                  </div>

                  {filePreview && (
                    <div className="mt-3">
                      <Label>Pré-visualização</Label>
                      <div className="mt-1 border rounded-lg overflow-hidden">
                        <img 
                          src={filePreview} 
                          alt="Preview da prescrição" 
                          className="max-h-60 mx-auto object-contain"
                        />
                      </div>
                    </div>
                  )}

                  <Separator />

                  <div className="grid gap-4">
                    <h3 className="text-lg font-medium">Dados do Médico</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="medico-nome">Nome do Médico</Label>
                        <Input 
                          id="medico-nome" 
                          value={medicoNome}
                          onChange={(e) => setMedicoNome(e.target.value)}
                          placeholder="Dr. Nome Completo"
                          required
                        />
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="medico-crm">CRM do Médico</Label>
                        <Input 
                          id="medico-crm" 
                          value={medicoCrm}
                          onChange={(e) => setMedicoCrm(e.target.value)}
                          placeholder="12345-UF"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="grid gap-2">
                      <Label htmlFor="medico-especialidade">Especialidade (opcional)</Label>
                      <Input 
                        id="medico-especialidade" 
                        value={medicoEspecialidade}
                        onChange={(e) => setMedicoEspecialidade(e.target.value)}
                        placeholder="Ex: Neurologia, Psiquiatria"
                      />
                    </div>
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="validade">Validade da Prescrição</Label>
                    <Input 
                      id="validade" 
                      type="date"
                      value={validadeStr}
                      onChange={(e) => setValidadeStr(e.target.value)}
                      required
                    />
                    <p className="text-sm text-gray-500">
                      A data até quando esta prescrição é válida.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end mt-6 space-x-2">
                <Button type="button" variant="outline" onClick={handleCancel}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={uploading}>
                  {uploading ? (
                    <>
                      <Spinner className="mr-2" />
                      Enviando...
                    </>
                  ) : (
                    <>
                      <FileUp className="mr-2 h-4 w-4" />
                      Enviar Prescrição
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
          <CardFooter className="bg-gray-50 flex flex-col items-start">
            <div className="flex items-start">
              <Info className="h-5 w-5 text-blue-500 mr-2 mt-0.5" />
              <div>
                <h4 className="font-medium">Processo de Análise</h4>
                <p className="text-sm text-gray-500 mt-1">
                  Após o envio, sua prescrição será analisada por um farmacêutico. 
                  Este processo geralmente leva até 24 horas úteis. 
                  Você receberá uma notificação quando sua prescrição for aprovada ou se forem necessárias alterações.
                </p>
              </div>
            </div>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}