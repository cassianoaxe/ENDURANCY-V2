import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Calendar,
  ArrowDownCircle,
  ArrowUpCircle,
  BarChart4,
  Download,
  ChevronLeft,
  ChevronRight,
  Plus,
  Filter,
  FileText,
  DollarSign,
  Search
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "@/components/ui/use-toast";

// Componente para criar células do calendário de fluxo
const FluxoCaixaDay = ({ day, month, saldo, entradas, saidas, isToday, isPast, isWeekend }) => {
  const formattedDay = day.toString().padStart(2, '0');
  
  return (
    <div className={`border rounded-md p-2 h-28 flex flex-col 
      ${isToday ? 'border-blue-500 bg-blue-50' : ''} 
      ${isPast && !isToday ? 'bg-gray-50' : ''} 
      ${isWeekend && !isToday ? 'bg-gray-50/50' : ''}`}>
      <div className="flex justify-between items-center mb-1">
        <span className={`text-sm font-medium ${isToday ? 'text-blue-600' : ''}`}>
          {formattedDay}/{month}
        </span>
        <span className={`text-xs font-medium 
          ${saldo > 0 ? 'text-green-600' : saldo < 0 ? 'text-red-600' : 'text-gray-500'}`}>
          {saldo !== undefined ? `R$ ${saldo.toFixed(2)}` : ''}
        </span>
      </div>
      
      {entradas > 0 && (
        <div className="flex items-center gap-1 text-xs text-green-600">
          <ArrowDownCircle className="w-3 h-3" />
          <span>R$ {entradas.toFixed(2)}</span>
        </div>
      )}
      
      {saidas > 0 && (
        <div className="flex items-center gap-1 text-xs text-red-600">
          <ArrowUpCircle className="w-3 h-3" />
          <span>R$ {saidas.toFixed(2)}</span>
        </div>
      )}
    </div>
  );
};

export default function FluxoCaixa() {
  const navigate = useNavigate();
  const [dataSelecionada, setDataSelecionada] = useState(new Date());
  const [visualizacao, setVisualizacao] = useState("calendar");
  const [periodoSelecionado, setPeriodoSelecionado] = useState("month");
  const [filtroCategoria, setFiltroCategoria] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  
  // Formatar data
  const formatDate = (date) => {
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  // Obter nome do mês atual
  const getNomeMes = (date = dataSelecionada) => {
    return new Intl.DateTimeFormat('pt-BR', { month: 'long' }).format(date);
  };
  
  // Obter ano atual
  const getAno = (date = dataSelecionada) => {
    return date.getFullYear();
  };
  
  // Navegar para o mês anterior
  const mesAnterior = () => {
    const novaData = new Date(dataSelecionada);
    novaData.setMonth(novaData.getMonth() - 1);
    setDataSelecionada(novaData);
  };
  
  // Navegar para o próximo mês
  const proximoMes = () => {
    const novaData = new Date(dataSelecionada);
    novaData.setMonth(novaData.getMonth() + 1);
    setDataSelecionada(novaData);
  };
  
  // Gerar dias do mês atual
  const getDiasDoMes = () => {
    const dias = [];
    const ano = dataSelecionada.getFullYear();
    const mes = dataSelecionada.getMonth();
    const hoje = new Date();
    
    // Data do primeiro dia do mês
    const primeiroDia = new Date(ano, mes, 1);
    // Dia da semana do primeiro dia (0 = Domingo, 1 = Segunda, ...)
    const diaSemanaInicial = primeiroDia.getDay();
    
    // Calcular quantos dias do mês anterior precisamos mostrar
    const diasMesAnterior = diaSemanaInicial === 0 ? 0 : diaSemanaInicial;
    
    // Adicionar dias do mês anterior
    if (diasMesAnterior > 0) {
      const ultimoDiaMesAnterior = new Date(ano, mes, 0).getDate();
      for (let i = diasMesAnterior - 1; i >= 0; i--) {
        const dia = ultimoDiaMesAnterior - i;
        const data = new Date(ano, mes - 1, dia);
        dias.push({
          dia,
          mes: mes === 0 ? 12 : mes,
          data,
          ehMesAtual: false,
          ehHoje: false,
          ehPassado: data < hoje,
          ehFimDeSemana: data.getDay() === 0 || data.getDay() === 6
        });
      }
    }
    
    // Adicionar dias do mês atual
    const ultimoDia = new Date(ano, mes + 1, 0).getDate();
    for (let dia = 1; dia <= ultimoDia; dia++) {
      const data = new Date(ano, mes, dia);
      dias.push({
        dia,
        mes: mes + 1,
        data,
        ehMesAtual: true,
        ehHoje: 
          data.getDate() === hoje.getDate() && 
          data.getMonth() === hoje.getMonth() && 
          data.getFullYear() === hoje.getFullYear(),
        ehPassado: data < hoje,
        ehFimDeSemana: data.getDay() === 0 || data.getDay() === 6
      });
    }
    
    // Completar com dias do próximo mês para ter 42 dias (6 semanas)
    const diasAdicionais = 42 - dias.length;
    if (diasAdicionais > 0) {
      for (let dia = 1; dia <= diasAdicionais; dia++) {
        const data = new Date(ano, mes + 1, dia);
        dias.push({
          dia,
          mes: mes + 2 > 12 ? 1 : mes + 2,
          data,
          ehMesAtual: false,
          ehHoje: false,
          ehPassado: false, // Dias do próximo mês nunca são passados
          ehFimDeSemana: data.getDay() === 0 || data.getDay() === 6
        });
      }
    }
    
    return dias;
  };
  
  // Dados simulados para fluxo de caixa
  const dadosFluxo = [
    { data: '2023-08-01', descricao: 'Vendas Produto A', valor: 4500.00, tipo: 'receita', categoria: 'vendas' },
    { data: '2023-08-01', descricao: 'Pagamento Fornecedor X', valor: 2300.00, tipo: 'despesa', categoria: 'fornecedores' },
    { data: '2023-08-02', descricao: 'Serviços Prestados', valor: 1800.00, tipo: 'receita', categoria: 'servicos' },
    { data: '2023-08-03', descricao: 'Pagamento Funcionário', valor: 3500.00, tipo: 'despesa', categoria: 'pessoal' },
    { data: '2023-08-05', descricao: 'Venda Produto B', valor: 2700.00, tipo: 'receita', categoria: 'vendas' },
    { data: '2023-08-05', descricao: 'Aluguel', valor: 5000.00, tipo: 'despesa', categoria: 'ocupacao' },
    { data: '2023-08-08', descricao: 'Anuidade Associado', valor: 1200.00, tipo: 'receita', categoria: 'anuidades' },
    { data: '2023-08-10', descricao: 'Energia Elétrica', valor: 980.00, tipo: 'despesa', categoria: 'utilidades' },
    { data: '2023-08-12', descricao: 'Vendas Online', valor: 3450.00, tipo: 'receita', categoria: 'vendas' },
    { data: '2023-08-15', descricao: 'Impostos', valor: 4200.00, tipo: 'despesa', categoria: 'tributos' },
    { data: '2023-08-15', descricao: 'Consultoria', valor: 2800.00, tipo: 'receita', categoria: 'servicos' },
    { data: '2023-08-18', descricao: 'Marketing Digital', valor: 1500.00, tipo: 'despesa', categoria: 'marketing' },
    { data: '2023-08-20', descricao: 'Venda Produto C', valor: 5800.00, tipo: 'receita', categoria: 'vendas' },
    { data: '2023-08-22', descricao: 'Manutenção', valor: 780.00, tipo: 'despesa', categoria: 'manutencao' },
    { data: '2023-08-25', descricao: 'Venda Produto A', valor: 3900.00, tipo: 'receita', categoria: 'vendas' },
    { data: '2023-08-28', descricao: 'Serviço de TI', valor: 1350.00, tipo: 'despesa', categoria: 'tecnologia' },
    { data: '2023-08-30', descricao: 'Anuidades (5 membros)', valor: 6000.00, tipo: 'receita', categoria: 'anuidades' }
  ];
  
  // Filtragem dos dados conforme a pesquisa e categoria
  const dadosFiltrados = dadosFluxo.filter(item => {
    // Filtro de pesquisa
    if (searchTerm && !item.descricao.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    // Filtro de categoria
    if (filtroCategoria !== 'all' && item.categoria !== filtroCategoria) {
      return false;
    }
    
    return true;
  });
  
  // Calcular entradas e saídas para cada dia do calendário
  const calcularFluxoPorDia = () => {
    const fluxoPorDia = {};
    
    dadosFluxo.forEach(item => {
      const data = item.data;
      
      if (!fluxoPorDia[data]) {
        fluxoPorDia[data] = {
          entradas: 0,
          saidas: 0,
          saldo: 0
        };
      }
      
      if (item.tipo === 'receita') {
        fluxoPorDia[data].entradas += item.valor;
        fluxoPorDia[data].saldo += item.valor;
      } else {
        fluxoPorDia[data].saidas += item.valor;
        fluxoPorDia[data].saldo -= item.valor;
      }
    });
    
    return fluxoPorDia;
  };
  
  // Dados processados para o calendário
  const fluxoPorDia = calcularFluxoPorDia();
  
  // Calcular totais
  const calcularTotais = () => {
    let totalEntradas = 0;
    let totalSaidas = 0;
    
    dadosFiltrados.forEach(item => {
      if (item.tipo === 'receita') {
        totalEntradas += item.valor;
      } else {
        totalSaidas += item.valor;
      }
    });
    
    return {
      totalEntradas,
      totalSaidas,
      saldoLiquido: totalEntradas - totalSaidas
    };
  };
  
  const totais = calcularTotais();
  
  // Exportar dados
  const exportarDados = () => {
    toast({
      title: "Exportando fluxo de caixa",
      description: "Os dados serão baixados em breve."
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Fluxo de Caixa</h1>
          <p className="text-gray-500 mt-1">
            Acompanhe receitas e despesas ao longo do tempo
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" className="gap-2" onClick={exportarDados}>
            <Download className="w-4 h-4" />
            Exportar
          </Button>
          <Button onClick={() => navigate(createPageUrl("NovoLancamento"))}>
            <Plus className="w-4 h-4 mr-2" />
            Novo Lançamento
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle>Resumo do Período</CardTitle>
              <CardDescription>
                Visão geral das receitas e despesas
              </CardDescription>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Select value={periodoSelecionado} onValueChange={setPeriodoSelecionado}>
                <SelectTrigger className="w-full sm:w-40">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <SelectValue placeholder="Período" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="month">Mês Atual</SelectItem>
                  <SelectItem value="previous-month">Mês Anterior</SelectItem>
                  <SelectItem value="quarter">Trimestre Atual</SelectItem>
                  <SelectItem value="year">Ano Atual</SelectItem>
                  <SelectItem value="custom">Personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <p className="text-sm text-gray-500">Total de Entradas</p>
              <p className="text-2xl font-bold text-green-600">R$ {totais.totalEntradas.toFixed(2)}</p>
              <div className="text-xs text-gray-500">
                Todas as receitas do período selecionado
              </div>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm text-gray-500">Total de Saídas</p>
              <p className="text-2xl font-bold text-red-600">R$ {totais.totalSaidas.toFixed(2)}</p>
              <div className="text-xs text-gray-500">
                Todas as despesas do período selecionado
              </div>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm text-gray-500">Saldo Líquido</p>
              <p className={`text-2xl font-bold ${totais.saldoLiquido >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                R$ {totais.saldoLiquido.toFixed(2)}
              </p>
              <div className="text-xs text-gray-500">
                Diferença entre entradas e saídas
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="calendar" value={visualizacao} onValueChange={setVisualizacao}>
        <TabsList>
          <TabsTrigger value="calendar" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span>Calendário</span>
          </TabsTrigger>
          <TabsTrigger value="list" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            <span>Lista</span>
          </TabsTrigger>
          <TabsTrigger value="summary" className="flex items-center gap-2">
            <BarChart4 className="w-4 h-4" />
            <span>Resumo</span>
          </TabsTrigger>
        </TabsList>

        {/* Visualização de Calendário */}
        <TabsContent value="calendar">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <Button variant="outline" size="icon" onClick={mesAnterior}>
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <h3 className="text-xl font-medium capitalize">
                    {getNomeMes()} de {getAno()}
                  </h3>
                  <Button variant="outline" size="icon" onClick={proximoMes}>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
                <Button variant="outline" onClick={() => setDataSelecionada(new Date())}>
                  Hoje
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1 mb-1">
                {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((dia, index) => (
                  <div key={index} className="text-center font-medium text-sm text-gray-500">
                    {dia}
                  </div>
                ))}
              </div>
              
              <div className="grid grid-cols-7 gap-1">
                {getDiasDoMes().map((info, index) => {
                  const dataFormatada = `${info.data.getFullYear()}-${String(info.data.getMonth() + 1).padStart(2, '0')}-${String(info.dia).padStart(2, '0')}`;
                  const fluxoDia = fluxoPorDia[dataFormatada] || { entradas: 0, saidas: 0, saldo: 0 };
                  
                  return (
                    <FluxoCaixaDay
                      key={index}
                      day={info.dia}
                      month={String(info.mes).padStart(2, '0')}
                      saldo={fluxoDia.saldo}
                      entradas={fluxoDia.entradas}
                      saidas={fluxoDia.saidas}
                      isToday={info.ehHoje}
                      isPast={info.ehPassado}
                      isWeekend={info.ehFimDeSemana}
                    />
                  );
                })}
              </div>
              
              <div className="mt-4 flex flex-wrap gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span className="text-sm">Entrada</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <span className="text-sm">Saída</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                  <span className="text-sm">Saldo do dia</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Visualização de Lista */}
        <TabsContent value="list">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Lançamentos</CardTitle>
                  <CardDescription>
                    Lista detalhada de entradas e saídas
                  </CardDescription>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Buscar..."
                      className="pl-10 w-full sm:w-60"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  
                  <Select value={filtroCategoria} onValueChange={setFiltroCategoria}>
                    <SelectTrigger className="w-full sm:w-40">
                      <div className="flex items-center gap-2">
                        <Filter className="w-4 h-4" />
                        <SelectValue placeholder="Categoria" />
                      </div>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas</SelectItem>
                      <SelectItem value="vendas">Vendas</SelectItem>
                      <SelectItem value="servicos">Serviços</SelectItem>
                      <SelectItem value="anuidades">Anuidades</SelectItem>
                      <SelectItem value="pessoal">Pessoal</SelectItem>
                      <SelectItem value="ocupacao">Ocupação</SelectItem>
                      <SelectItem value="utilidades">Utilidades</SelectItem>
                      <SelectItem value="fornecedores">Fornecedores</SelectItem>
                      <SelectItem value="tributos">Tributos</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead className="text-right">Entradas</TableHead>
                      <TableHead className="text-right">Saídas</TableHead>
                      <TableHead className="text-right">Saldo</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dadosFiltrados.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          {formatDate(new Date(item.data))}
                        </TableCell>
                        <TableCell className="font-medium">{item.descricao}</TableCell>
                        <TableCell>
                          <Badge className={
                            item.tipo === "receita" 
                              ? "bg-green-100 text-green-800" 
                              : "bg-red-100 text-red-800"
                          }>
                            {item.categoria.charAt(0).toUpperCase() + item.categoria.slice(1)}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          {item.tipo === "receita" ? `R$ ${item.valor.toFixed(2)}` : "-"}
                        </TableCell>
                        <TableCell className="text-right">
                          {item.tipo === "despesa" ? `R$ ${item.valor.toFixed(2)}` : "-"}
                        </TableCell>
                        <TableCell className={`text-right font-medium ${item.tipo === "receita" ? "text-green-600" : "text-red-600"}`}>
                          {item.tipo === "receita" 
                            ? `+R$ ${item.valor.toFixed(2)}` 
                            : `-R$ ${item.valor.toFixed(2)}`}
                        </TableCell>
                      </TableRow>
                    ))}
                    
                    {dadosFiltrados.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="h-24 text-center">
                          Nenhum lançamento encontrado.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-gray-500">
                {dadosFiltrados.length} lançamentos encontrados
              </div>
              <div className="space-x-4">
                <span className="font-medium">Total de Entradas: <span className="text-green-600">R$ {totais.totalEntradas.toFixed(2)}</span></span>
                <span className="font-medium">Total de Saídas: <span className="text-red-600">R$ {totais.totalSaidas.toFixed(2)}</span></span>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Visualização de Resumo */}
        <TabsContent value="summary">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Resumo por Categoria</CardTitle>
                <CardDescription>
                  Agrupamento de receitas e despesas por categoria
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-medium text-green-600 mb-3">Receitas por Categoria</h3>
                  <div className="space-y-2">
                    {(() => {
                      // Agrupar e somar receitas por categoria
                      const categorias = {};
                      dadosFiltrados
                        .filter(item => item.tipo === 'receita')
                        .forEach(item => {
                          if (!categorias[item.categoria]) {
                            categorias[item.categoria] = 0;
                          }
                          categorias[item.categoria] += item.valor;
                        });
                      
                      // Converter para array e ordenar
                      return Object.entries(categorias)
                        .sort((a, b) => b[1] - a[1])
                        .map(([categoria, valor], idx) => (
                          <div key={idx} className="flex justify-between items-center">
                            <span className="capitalize">{categoria}</span>
                            <div className="flex items-center gap-2">
                              <span className="text-green-600 font-medium">R$ {valor.toFixed(2)}</span>
                              <Badge className="bg-green-100 text-green-800">
                                {(valor / totais.totalEntradas * 100).toFixed(1)}%
                              </Badge>
                            </div>
                          </div>
                        ));
                    })()}
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium text-red-600 mb-3">Despesas por Categoria</h3>
                  <div className="space-y-2">
                    {(() => {
                      // Agrupar e somar despesas por categoria
                      const categorias = {};
                      dadosFiltrados
                        .filter(item => item.tipo === 'despesa')
                        .forEach(item => {
                          if (!categorias[item.categoria]) {
                            categorias[item.categoria] = 0;
                          }
                          categorias[item.categoria] += item.valor;
                        });
                      
                      // Converter para array e ordenar
                      return Object.entries(categorias)
                        .sort((a, b) => b[1] - a[1])
                        .map(([categoria, valor], idx) => (
                          <div key={idx} className="flex justify-between items-center">
                            <span className="capitalize">{categoria}</span>
                            <div className="flex items-center gap-2">
                              <span className="text-red-600 font-medium">R$ {valor.toFixed(2)}</span>
                              <Badge className="bg-red-100 text-red-800">
                                {(valor / totais.totalSaidas * 100).toFixed(1)}%
                              </Badge>
                            </div>
                          </div>
                        ));
                    })()}
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Tendências de Fluxo</CardTitle>
                <CardDescription>
                  Evolução temporal de receitas e despesas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-3">Saldo Acumulado</h3>
                    <div className="h-60 flex flex-col justify-center">
                      {/* Gráfico simplificado */}
                      <div className="w-full h-full bg-gray-50 rounded-md border flex flex-col justify-center items-center">
                        <div className="text-sm text-gray-500">Gráfico simplificado de saldo acumulado</div>
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-3">
                    <h3 className="font-medium mb-2">Estatísticas</h3>
                    
                    <div className="flex justify-between items-center">
                      <span>Dia com maior receita:</span>
                      <div className="text-right">
                        <div className="font-medium">R$ 6.000,00</div>
                        <div className="text-xs text-gray-500">30/08/2023</div>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span>Dia com maior despesa:</span>
                      <div className="text-right">
                        <div className="font-medium">R$ 5.000,00</div>
                        <div className="text-xs text-gray-500">05/08/2023</div>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span>Média diária de receitas:</span>
                      <div className="font-medium">R$ 1.912,86</div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span>Média diária de despesas:</span>
                      <div className="font-medium">R$ 1.626,43</div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span>Saldo médio diário:</span>
                      <div className="font-medium text-blue-600">R$ 286,43</div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  <BarChart4 className="w-4 h-4 mr-2" />
                  Relatório Analítico Completo
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}