
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Leaf, 
  Calendar, 
  Clipboard, 
  TrendingUp, 
  Users, 
  AlertTriangle,
  BarChart,
  FlaskConical,
  Sprout,
  SunMedium,
  Droplets,
  Clock,
  Plus,
  Scissors,
  Scale,
  Server,
  PieChart,
  Database,
  ArrowDownUp,
  Search,
  Filter,
  CheckCircle2,
  MoreHorizontal,
  Box
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Batch } from "@/api/entities";
import { Plant } from "@/api/entities";
import { Strain } from "@/api/entities";
import { GrowRoom } from "@/api/entities";
import { Inventory } from "@/api/entities";
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RechartsPieChart, Pie, Cell, LineChart, Line } from 'recharts';

// Dados mockados para o dashboard
const mockStats = {
  totalPlants: 324,
  totalMothers: 18,
  plantsInVeg: 156,
  plantsInFlower: 150,
  activeGrowRooms: 5,
  totalYieldMonth: 42.5,
  harvestedPlants: 65,
  pendingTests: 3
};

const mockBatches = [
  { id: 'batch1', name: 'LOTE-2023-0142', strain: 'Charlotte\'s Web', phase: 'vegetativo', plants: 48, age: 32, health: 98 },
  { id: 'batch2', name: 'LOTE-2023-0143', strain: 'CBD Skunk', phase: 'floração', plants: 36, age: 58, health: 95 },
  { id: 'batch3', name: 'LOTE-2023-0144', strain: 'Cannatonic', phase: 'floração', plants: 42, age: 65, health: 92 },
  { id: 'batch4', name: 'LOTE-2023-0145', strain: 'Harlequin', phase: 'propagação', plants: 60, age: 12, health: 100 }
];

const mockStrainData = [
  { name: 'Charlotte\'s Web', count: 84, ratio: 26 },
  { name: 'CBD Skunk', count: 78, ratio: 24 },
  { name: 'Cannatonic', count: 72, ratio: 22 },
  { name: 'Harlequin', count: 60, ratio: 19 },
  { name: 'ACDC', count: 30, ratio: 9 }
];

const mockPhaseData = [
  { name: 'Propagação', value: 60 },
  { name: 'Vegetativo', value: 156 },
  { name: 'Floração', value: 90 },
  { name: 'Colheita', value: 0 },
  { name: 'Secagem', value: 0 }
];

const mockGrowRooms = [
  { 
    id: 'room1', 
    name: 'Sala de Mães', 
    type: 'mães', 
    status: 'ativa',
    capacity: { total: 25, used: 18 },
    environment: { 
      temperature: 24.5, 
      humidity: 65, 
      co2: 800 
    }
  },
  { 
    id: 'room2', 
    name: 'Propagação', 
    type: 'propagação', 
    status: 'ativa',
    capacity: { total: 100, used: 60 },
    environment: { 
      temperature: 25.2, 
      humidity: 80, 
      co2: 600 
    }
  },
  { 
    id: 'room3', 
    name: 'Vegetativo 1', 
    type: 'vegetativo', 
    status: 'ativa',
    capacity: { total: 80, used: 78 },
    environment: { 
      temperature: 26.1, 
      humidity: 65, 
      co2: 1000 
    }
  },
  { 
    id: 'room4', 
    name: 'Vegetativo 2', 
    type: 'vegetativo', 
    status: 'ativa',
    capacity: { total: 80, used: 78 },
    environment: { 
      temperature: 25.8, 
      humidity: 60, 
      co2: 1000 
    }
  },
  { 
    id: 'room5', 
    name: 'Floração 1', 
    type: 'floração', 
    status: 'ativa',
    capacity: { total: 50, used: 48 },
    environment: { 
      temperature: 24.3, 
      humidity: 40, 
      co2: 1200 
    }
  },
  { 
    id: 'room6', 
    name: 'Floração 2', 
    type: 'floração', 
    status: 'ativa',
    capacity: { total: 50, used: 42 },
    environment: { 
      temperature: 24.5, 
      humidity: 45, 
      co2: 1200 
    }
  }
];

const mockYieldData = [
  { month: 'Jan', yield: 35.2 },
  { month: 'Fev', yield: 32.8 },
  { month: 'Mar', yield: 38.4 },
  { month: 'Abr', yield: 40.1 },
  { month: 'Mai', yield: 36.5 },
  { month: 'Jun', yield: 39.8 },
  { month: 'Jul', yield: 42.5 }
];

const mockAlerts = [
  { id: 'alert1', type: 'humidity', room: 'Propagação', message: 'Umidade abaixo do ideal (60%)', severity: 'medium' },
  { id: 'alert2', type: 'temperature', room: 'Vegetativo 1', message: 'Temperatura acima do ideal (27°C)', severity: 'high' },
  { id: 'alert3', type: 'health', batch: 'LOTE-2023-0143', message: '2 plantas com suspeita de infestação', severity: 'high' }
];

const mockInventory = [
  { id: 'inv1', type: 'flor', strain: 'Charlotte\'s Web', quantity: 2.5, unit: 'kg' },
  { id: 'inv2', type: 'óleo', strain: 'Cannatonic', quantity: 1.25, unit: 'L' },
  { id: 'inv3', type: 'extrato', strain: 'ACDC', quantity: 0.5, unit: 'L' }
];

// Componente de Estatísticas
const StatsSection = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-500">Total de Plantas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{stats.totalPlants}</div>
          <div className="flex mt-2 text-sm">
            <div className="flex items-center">
              <Badge variant="outline" className="mr-2">Madres: {stats.totalMothers}</Badge>
              <Badge variant="outline" className="mr-2">Veg: {stats.plantsInVeg}</Badge>
              <Badge variant="outline">Flor: {stats.plantsInFlower}</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-500">Produtividade Mensal</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{stats.totalYieldMonth} kg</div>
          <div className="flex items-center text-sm text-green-600 mt-2">
            <TrendingUp className="w-4 h-4 mr-1" />
            <span>+8% em relação ao mês anterior</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-500">Plantas Colhidas (Mês)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{stats.harvestedPlants}</div>
          <div className="flex items-center text-sm text-amber-600 mt-2">
            <Scissors className="w-4 h-4 mr-1" />
            <span>Taxa de conversão: 65.3%</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-gray-500">Testes Laboratoriais</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{stats.pendingTests} <span className="text-base font-normal text-gray-500">pendentes</span></div>
          <div className="flex items-center text-sm text-blue-600 mt-2">
            <FlaskConical className="w-4 h-4 mr-1" />
            <span>12 testes realizados este mês</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Gráfico de Barras por Strain
const StrainBarChart = ({ data }) => {
  const COLORS = ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#E91E63'];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Distribuição por Strain</CardTitle>
        <CardDescription>Número de plantas por variedade</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <RechartsBarChart
              data={data}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis />
              <Tooltip 
                formatter={(value, name, props) => [`${value} plantas`, 'Quantidade']}
                labelFormatter={(label) => `Strain: ${label}`}
              />
              <Bar dataKey="count" name="Plantas" fill="#4CAF50" />
            </RechartsBarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Gráfico de Pizza por Fase
const PhasePieChart = ({ data }) => {
  const COLORS = ['#2196F3', '#4CAF50', '#FF9800', '#E91E63', '#9C27B0'];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Distribuição por Fase</CardTitle>
        <CardDescription>Plantas em cada fase de desenvolvimento</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <RechartsPieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value} plantas`, 'Quantidade']} />
              <Legend />
            </RechartsPieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Gráfico de Linhas de Produtividade
const YieldLineChart = ({ data }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Produtividade Mensal</CardTitle>
        <CardDescription>Rendimento em kg por mês</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip formatter={(value) => [`${value} kg`, 'Rendimento']} />
              <Legend />
              <Line
                type="monotone"
                dataKey="yield"
                name="Rendimento"
                stroke="#4CAF50"
                activeDot={{ r: 8 }}
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Componente para Salas de Cultivo
const GrowRoomsSection = ({ rooms }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Salas de Cultivo</CardTitle>
            <CardDescription>Status das salas e condições ambientais</CardDescription>
          </div>
          <Link to={createPageUrl("CultivoSalas")}>
            <Button variant="outline" size="sm">Gerenciar</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {rooms.slice(0, 4).map((room, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <div className={`p-2 rounded-full mr-3 ${
                    room.type === "mães" ? "bg-amber-100 text-amber-600" :
                    room.type === "propagação" ? "bg-blue-100 text-blue-600" :
                    room.type === "vegetativo" ? "bg-green-100 text-green-600" :
                    room.type === "floração" ? "bg-purple-100 text-purple-600" :
                    "bg-gray-100 text-gray-600"
                  }`}>
                    {room.type === "mães" ? <Leaf className="w-5 h-5" /> :
                     room.type === "propagação" ? <Sprout className="w-5 h-5" /> :
                     room.type === "vegetativo" ? <Leaf className="w-5 h-5" /> :
                     room.type === "floração" ? <SunMedium className="w-5 h-5" /> :
                     <Droplets className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="font-medium">{room.name}</div>
                    <div className="text-sm text-gray-500 capitalize">{room.type}</div>
                  </div>
                </div>
                <Badge className={
                  room.status === "ativa" ? "bg-green-100 text-green-800" :
                  room.status === "manutenção" ? "bg-amber-100 text-amber-800" :
                  "bg-red-100 text-red-800"
                }>
                  {room.status}
                </Badge>
              </div>
              
              <div className="grid grid-cols-3 gap-2 mt-3">
                <div className="p-2 bg-gray-50 rounded text-center">
                  <div className="text-xs text-gray-500">Temperatura</div>
                  <div className="font-medium">{room.environment.temperature}°C</div>
                </div>
                <div className="p-2 bg-gray-50 rounded text-center">
                  <div className="text-xs text-gray-500">Umidade</div>
                  <div className="font-medium">{room.environment.humidity}%</div>
                </div>
                <div className="p-2 bg-gray-50 rounded text-center">
                  <div className="text-xs text-gray-500">CO₂</div>
                  <div className="font-medium">{room.environment.co2} ppm</div>
                </div>
              </div>
              
              <div className="mt-3">
                <div className="flex justify-between text-xs mb-1">
                  <span>Ocupação</span>
                  <span>{room.capacity.used}/{room.capacity.total} plantas</span>
                </div>
                <Progress value={(room.capacity.used / room.capacity.total) * 100} />
              </div>
            </div>
          ))}
          
          {rooms.length > 4 && (
            <Link to={createPageUrl("CultivoSalas")} className="block text-center text-blue-600 hover:text-blue-800 text-sm mt-2">
              Ver todas as {rooms.length} salas
            </Link>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente para Alertas
const AlertsSection = ({ alerts }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Alertas</CardTitle>
            <CardDescription>Condições que precisam de atenção</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {alerts.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-6 text-green-600">
              <CheckCircle2 className="w-12 h-12 mb-2 text-green-500" />
              <p className="text-center">Nenhum alerta ativo no momento</p>
            </div>
          ) : (
            alerts.map((alert, index) => (
              <div key={index} className={`p-3 rounded-lg flex items-start gap-3 ${
                alert.severity === 'high' ? 'bg-red-50 border border-red-200' : 
                alert.severity === 'medium' ? 'bg-amber-50 border border-amber-200' : 
                'bg-blue-50 border border-blue-200'
              }`}>
                <div className={`p-1 rounded-full ${
                  alert.severity === 'high' ? 'bg-red-100 text-red-600' : 
                  alert.severity === 'medium' ? 'bg-amber-100 text-amber-600' : 
                  'bg-blue-100 text-blue-600'
                }`}>
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="font-medium mb-1">
                    {alert.type === 'humidity' && 'Alerta de Umidade'}
                    {alert.type === 'temperature' && 'Alerta de Temperatura'}
                    {alert.type === 'health' && 'Alerta de Saúde'}
                  </div>
                  <div className="text-sm">
                    {alert.message}
                    {alert.room && <div className="mt-1 text-xs font-medium">Sala: {alert.room}</div>}
                    {alert.batch && <div className="mt-1 text-xs font-medium">Lote: {alert.batch}</div>}
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <span className="sr-only">Ações</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>Ver detalhes</DropdownMenuItem>
                    <DropdownMenuItem>Marcar como resolvido</DropdownMenuItem>
                    <DropdownMenuItem>Ignorar</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente para Lotes Ativos
const ActiveBatchesSection = ({ batches }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Lotes Ativos</CardTitle>
            <CardDescription>Status dos lotes em andamento</CardDescription>
          </div>
          <Link to={createPageUrl("CultivoLotes")}>
            <Button variant="outline" size="sm">Ver Todos</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {batches.map((batch, index) => (
            <Link key={index} to={`${createPageUrl("CultivoLoteDetalhes")}?id=${batch.id}`}>
              <div className="border rounded-lg p-4 hover:bg-gray-50 transition cursor-pointer">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium">{batch.name}</div>
                    <div className="text-sm text-gray-500">{batch.strain}</div>
                  </div>
                  <Badge className={
                    batch.phase === "propagação" ? "bg-blue-100 text-blue-800" :
                    batch.phase === "vegetativo" ? "bg-green-100 text-green-800" :
                    batch.phase === "floração" ? "bg-purple-100 text-purple-800" :
                    "bg-gray-100 text-gray-800"
                  }>
                    {batch.phase}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-3 gap-4 mt-3 text-sm">
                  <div>
                    <div className="text-gray-500">Plantas</div>
                    <div className="font-medium">{batch.plants}</div>
                  </div>
                  <div>
                    <div className="text-gray-500">Idade</div>
                    <div className="font-medium">{batch.age} dias</div>
                  </div>
                  <div>
                    <div className="text-gray-500">Saúde</div>
                    <div className="font-medium">{batch.health}%</div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente para Inventário
const InventorySection = ({ inventory }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Estoque Atual</CardTitle>
            <CardDescription>Materiais disponíveis</CardDescription>
          </div>
          <Link to={createPageUrl("CultivoEstoque")}>
            <Button variant="outline" size="sm">Ver Estoque</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {inventory.map((item, index) => (
            <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${
                  item.type === "flor" ? "bg-green-100 text-green-600" :
                  item.type === "óleo" ? "bg-amber-100 text-amber-600" :
                  item.type === "extrato" ? "bg-purple-100 text-purple-600" :
                  "bg-gray-100 text-gray-600"
                }`}>
                  {item.type === "flor" ? <Leaf className="w-4 h-4" /> :
                   item.type === "óleo" ? <FlaskConical className="w-4 h-4" /> :
                   item.type === "extrato" ? <FlaskConical className="w-4 h-4" /> :
                   <Box className="w-4 h-4" />}
                </div>
                <div>
                  <div className="font-medium capitalize">{item.type}</div>
                  <div className="text-sm text-gray-500">{item.strain}</div>
                </div>
              </div>
              <div className="font-medium">
                {item.quantity} {item.unit}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente principal do Dashboard
export default function CultivoDashboard() {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({});
  const [strainData, setStrainData] = useState([]);
  const [phaseData, setPhaseData] = useState([]);
  const [yieldData, setYieldData] = useState([]);
  const [batches, setBatches] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [periodFilter, setPeriodFilter] = useState('month');
  
  useEffect(() => {
    loadDashboardData();
  }, [periodFilter]);
  
  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      
      // Em produção, aqui seriam chamadas para as APIs reais
      // Simulando carregamento
      setTimeout(() => {
        setStats(mockStats);
        setStrainData(mockStrainData);
        setPhaseData(mockPhaseData);
        setYieldData(mockYieldData);
        setBatches(mockBatches);
        setRooms(mockGrowRooms);
        setAlerts(mockAlerts);
        setInventory(mockInventory);
        setIsLoading(false);
      }, 800);
      
    } catch (error) {
      console.error("Erro ao carregar dados do dashboard:", error);
      setIsLoading(false);
    }
  };
  
  const handleRefresh = () => {
    loadDashboardData();
  };
  
  const handlePeriodChange = (value) => {
    setPeriodFilter(value);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Dashboard de Cultivo</h1>
          <p className="text-gray-500 mt-1">
            Visão geral do cultivo, estatísticas e indicadores
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <Select value={periodFilter} onValueChange={handlePeriodChange}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Última Semana</SelectItem>
              <SelectItem value="month">Último Mês</SelectItem>
              <SelectItem value="quarter">Último Trimestre</SelectItem>
              <SelectItem value="year">Último Ano</SelectItem>
            </SelectContent>
          </Select>
          
          <Button onClick={handleRefresh} variant="outline" className="gap-2">
            <ArrowDownUp className="w-4 h-4" />
            Atualizar
          </Button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
          <p className="ml-2">Carregando dados do dashboard...</p>
        </div>
      ) : (
        <>
          <StatsSection stats={stats} />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <StrainBarChart data={strainData} />
            <PhasePieChart data={phaseData} />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <YieldLineChart data={yieldData} />
            <InventorySection inventory={inventory} />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <ActiveBatchesSection batches={batches} />
            </div>
            <AlertsSection alerts={alerts} />
          </div>
          
          <GrowRoomsSection rooms={rooms} />
        </>
      )}
    </div>
  );
}
