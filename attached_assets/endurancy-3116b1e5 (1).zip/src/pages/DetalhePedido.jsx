
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, 
  Truck, 
  Package, 
  Calendar, 
  Clock, 
  MapPin, 
  CreditCard, 
  FileText, 
  CheckSquare, 
  XCircle, 
  AlertTriangle, 
  Edit, 
  Printer, 
  Download, 
  Mail, 
  Phone, 
  User, 
  Tag,
  ShoppingBag,
  RefreshCw,
  Layers,
  ArrowRightLeft,
  ChevronDown,
  CheckCircle2
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function DetalhePedido() {
  const navigate = useNavigate();
  const [pedido, setPedido] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("detalhes");
  const [juncaoDialogOpen, setJuncaoDialogOpen] = useState(false);
  const [pedidosSelecionadosParaJuncao, setPedidosSelecionadosParaJuncao] = useState([]);
  const [pedidosDisponiveis, setPedidosDisponiveis] = useState([]);

  // Simulação de dados para a página de detalhes
  const mockPedidos = [
    {
      id: "ped-001",
      numero: "P23050001",
      cliente: {
        id: "cli-001",
        nome: "Maria Silva",
        email: "maria.silva@email.com",
        telefone: "(11) 98765-4321",
        avatar: "MS"
      },
      data: "2023-05-10T14:30:00Z",
      status: "entregue",
      total: 350.90,
      subtotal: 330.90,
      frete: 20.00,
      desconto: 0,
      itens: [
        {
          id: "item-001",
          produto: "Óleo CBD Full Spectrum 30ml",
          quantidade: 1,
          preco: 250.90,
          subtotal: 250.90
        },
        {
          id: "item-002",
          produto: "Cápsulas CBD 15mg - 30 unidades",
          quantidade: 1,
          preco: 80.00,
          subtotal: 80.00
        }
      ],
      endereco: {
        logradouro: "Rua das Flores",
        numero: "123",
        complemento: "Apto 45",
        bairro: "Jardins",
        cidade: "São Paulo",
        estado: "SP",
        cep: "01234-567"
      },
      observacao: "Entregar no período da tarde",
      formaPagamento: "cartão de crédito",
      statusPagamento: "pago",
      ultimaAtualizacao: "2023-05-15T10:20:00Z",
      historico: [
        {
          data: "2023-05-10T14:30:00Z",
          status: "criado",
          descricao: "Pedido criado pelo cliente"
        },
        {
          data: "2023-05-10T14:45:00Z",
          status: "aprovado",
          descricao: "Pagamento aprovado"
        },
        {
          data: "2023-05-11T09:15:00Z",
          status: "em_preparacao",
          descricao: "Pedido em preparação"
        },
        {
          data: "2023-05-12T11:30:00Z",
          status: "enviado",
          descricao: "Pedido enviado via transportadora"
        },
        {
          data: "2023-05-15T10:20:00Z",
          status: "entregue",
          descricao: "Pedido entregue ao cliente"
        }
      ],
      rastreamento: {
        codigo: "BR1234567890",
        transportadora: "Transportadora Rápida",
        status: "Entregue",
        atualizacao: "2023-05-15T10:20:00Z"
      },
      juntoComPedido: null,
      disponivelParaJuncao: true
    },
    {
      id: "ped-002",
      numero: "P23050002",
      cliente: {
        id: "cli-002",
        nome: "João Santos",
        email: "joao.santos@email.com",
        telefone: "(11) 98765-5432",
        avatar: "JS"
      },
      data: "2023-05-12T11:45:00Z",
      status: "processando",
      total: 125.50,
      subtotal: 115.50,
      frete: 10.00,
      desconto: 0,
      itens: [
        {
          id: "item-003",
          produto: "Pomada CBD para dores musculares 60g",
          quantidade: 1,
          preco: 115.50,
          subtotal: 115.50
        }
      ],
      endereco: {
        logradouro: "Av. Paulista",
        numero: "1000",
        complemento: "Sala 1010",
        bairro: "Bela Vista",
        cidade: "São Paulo",
        estado: "SP",
        cep: "01310-100"
      },
      observacao: "Juntar com pedido P23050005 do mesmo cliente",
      formaPagamento: "pix",
      statusPagamento: "pago",
      ultimaAtualizacao: "2023-05-12T15:30:00Z",
      historico: [
        {
          data: "2023-05-12T11:45:00Z",
          status: "criado",
          descricao: "Pedido criado pelo cliente"
        },
        {
          data: "2023-05-12T12:00:00Z",
          status: "aprovado",
          descricao: "Pagamento aprovado"
        },
        {
          data: "2023-05-12T15:30:00Z",
          status: "processando",
          descricao: "Pedido em processamento"
        }
      ],
      juntoComPedido: null,
      disponivelParaJuncao: true
    }
  ];

  const mockPedidosRelacionados = [
    {
      id: "ped-005",
      numero: "P23050005",
      cliente: {
        id: "cli-002",
        nome: "João Santos",
        avatar: "JS"
      },
      data: "2023-05-18T10:30:00Z",
      status: "pendente",
      total: 420.80,
      itens: 3,
      endereco: "Av. Paulista, 1000 - São Paulo, SP",
      observacao: "Cliente solicitou juntar com pedido anterior P23050002",
      formaPagamento: "pix",
      ultimaAtualizacao: "2023-05-18T10:30:00Z",
      juntoComPedido: null,
      disponivelParaJuncao: true
    }
  ];

  useEffect(() => {
    carregarPedido();
  }, []);

  const carregarPedido = async () => {
    try {
      setLoading(true);
      setTimeout(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const pedidoId = urlParams.get('id');
        
        const pedidoEncontrado = mockPedidos.find(p => p.id === pedidoId);
        
        if (pedidoEncontrado) {
          setPedido(pedidoEncontrado);
          
          const pedidosDisponiveisParaJuncao = mockPedidosRelacionados.filter(p => 
            p.cliente.id === pedidoEncontrado.cliente.id && 
            p.status !== "cancelado" && 
            p.status !== "entregue" &&
            !p.juntoComPedido &&
            p.disponivelParaJuncao
          );
          
          setPedidosDisponiveis(pedidosDisponiveisParaJuncao);
        }
        
        setLoading(false);
      }, 800);
    } catch (error) {
      console.error("Erro ao carregar pedido", error);
      setLoading(false);
    }
  };

  const pedidoContemTermoJuncao = (observacao) => {
    if (!observacao) return false;
    
    const termosJuncao = ["juntar", "mesclar", "unir", "combinar", "agrupar"];
    const observacaoLower = observacao.toLowerCase();
    
    return termosJuncao.some(termo => observacaoLower.includes(termo));
  };

  const formatarDataSegura = (dataString) => {
    if (!dataString) return "Data não disponível";
    
    try {
      const data = new Date(dataString);
      if (isNaN(data.getTime())) {
        return "Data inválida";
      }
      
      return new Intl.DateTimeFormat('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }).format(data);
    } catch (error) {
      console.error("Erro ao formatar data:", error);
      return "Erro na data";
    }
  };

  const formatarApenasData = (dataString) => {
    if (!dataString) return "Data não disponível";
    
    try {
      const data = new Date(dataString);
      if (isNaN(data.getTime())) {
        return "Data inválida";
      }
      
      return new Intl.DateTimeFormat('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      }).format(data);
    } catch (error) {
      console.error("Erro ao formatar data:", error);
      return "Erro na data";
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      "pendente": { color: "bg-yellow-100 text-yellow-800", label: "Pendente" },
      "aprovado": { color: "bg-blue-100 text-blue-800", label: "Aprovado" },
      "processando": { color: "bg-purple-100 text-purple-800", label: "Processando" },
      "em_preparacao": { color: "bg-indigo-100 text-indigo-800", label: "Em Preparação" },
      "enviado": { color: "bg-indigo-100 text-indigo-800", label: "Enviado" },
      "entregue": { color: "bg-green-100 text-green-800", label: "Entregue" },
      "cancelado": { color: "bg-red-100 text-red-800", label: "Cancelado" },
      "criado": { color: "bg-blue-100 text-blue-800", label: "Criado" },
      "aguardando_pagamento": { color: "bg-orange-100 text-orange-800", label: "Aguardando Pagamento" }
    };

    const config = statusConfig[status] || { color: "bg-gray-100 text-gray-800", label: "Desconhecido" };

    return (
      <Badge className={config.color}>
        {config.label}
      </Badge>
    );
  };

  const abrirDialogJuncao = () => {
    setPedidosSelecionadosParaJuncao([]);
    setJuncaoDialogOpen(true);
  };

  const toggleSelecionarPedidoParaJuncao = (pedidoId) => {
    if (pedidosSelecionadosParaJuncao.includes(pedidoId)) {
      setPedidosSelecionadosParaJuncao(
        pedidosSelecionadosParaJuncao.filter(id => id !== pedidoId)
      );
    } else {
      setPedidosSelecionadosParaJuncao([...pedidosSelecionadosParaJuncao, pedidoId]);
    }
  };

  const realizarJuncaoPedidos = async () => {
    if (!pedido || pedidosSelecionadosParaJuncao.length === 0) {
      return;
    }

    try {
      const pedidosPorId = Object.fromEntries([...mockPedidos, ...mockPedidosRelacionados].map(p => [p.id, p]));
      
      const todosIdsJuncao = [pedido.id, ...pedidosSelecionadosParaJuncao];
      const pedidosJuntados = todosIdsJuncao.map(id => pedidosPorId[id]);
      
      const totalConsolidado = pedidosJuntados.reduce((sum, p) => sum + p.total, 0);
      const totalItens = pedidosJuntados.reduce((sum, p) => sum + p.itens.length, 0);
      
      const novoPedidoConsolidado = {
        id: `ped-cons-${Date.now()}`,
        numero: `PC${Date.now().toString().slice(-6)}`,
        cliente: pedido.cliente,
        data: new Date().toISOString(),
        status: "processando",
        total: totalConsolidado,
        itens: totalItens,
        endereco: pedido.endereco,
        observacao: `Pedido consolidado dos pedidos: ${todosIdsJuncao.map(id => pedidosPorId[id].numero).join(", ")}`,
        formaPagamento: pedido.formaPagamento,
        ultimaAtualizacao: new Date().toISOString(),
        juntoComPedido: null,
        disponivelParaJuncao: false,
        pedidosOriginais: todosIdsJuncao
      };
      
      alert(`Pedidos consolidados com sucesso no novo pedido ${novoPedidoConsolidado.numero}`);
      
      setJuncaoDialogOpen(false);
      navigate(createPageUrl('Pedidos'));
      
    } catch (error) {
      console.error("Erro ao juntar pedidos", error);
      alert("Ocorreu um erro ao tentar juntar os pedidos. Tente novamente.");
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!pedido) {
    return (
      <div className="p-6 text-center">
        <AlertTriangle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
        <h1 className="text-2xl font-bold mb-2">Pedido não encontrado</h1>
        <p className="text-gray-500 mb-4">O pedido que você está procurando não foi encontrado.</p>
        <Button onClick={() => navigate(createPageUrl('Pedidos'))}>
          Voltar para Lista de Pedidos
        </Button>
      </div>
    );
  }

  const elegívelParaJuncao = pedidoContemTermoJuncao(pedido.observacao) && 
                              pedido.disponivelParaJuncao &&
                              pedido.status !== "cancelado" && 
                              pedido.status !== "entregue" &&
                              !pedido.juntoComPedido;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => navigate(createPageUrl('Pedidos'))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Detalhes do Pedido {pedido.numero}</h1>
            <p className="text-gray-500">
              Criado em {formatarApenasData(pedido.data)}
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                Ações
                <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => navigate(`${createPageUrl('EditarPedido')}?id=${pedido.id}`)}>
                <Edit className="w-4 h-4 mr-2" />
                Editar Pedido
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Printer className="w-4 h-4 mr-2" />
                Imprimir
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Mail className="w-4 h-4 mr-2" />
                Enviar ao Cliente
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              
              {elegívelParaJuncao && pedidosDisponiveis.length > 0 && (
                <>
                  <DropdownMenuItem onClick={abrirDialogJuncao}>
                    <ArrowRightLeft className="w-4 h-4 mr-2" />
                    Juntar Pedidos
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                </>
              )}
              
              {pedido.status !== "cancelado" && (
                <DropdownMenuItem className="text-red-600">
                  <XCircle className="w-4 h-4 mr-2" />
                  Cancelar Pedido
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button 
            variant="outline"
            onClick={() => navigate(`${createPageUrl('EditarPedido')}?id=${pedido.id}`)}
          >
            <Edit className="w-4 h-4 mr-2" />
            Editar
          </Button>
          
          {pedido.status !== "entregue" && pedido.status !== "cancelado" && (
            <Button>
              <Truck className="w-4 h-4 mr-2" />
              Atualizar Status
            </Button>
          )}
        </div>
      </div>

      {elegívelParaJuncao && pedidosDisponiveis.length > 0 && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <ArrowRightLeft className="h-6 w-6 text-blue-700" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-blue-800">Junção de pedidos sugerida</h3>
                <p className="text-blue-700 mb-2">
                  A observação deste pedido sugere que ele deve ser juntado com outros pedidos do mesmo cliente.
                </p>
                <p className="text-sm text-blue-600 italic">
                  Observação: "{pedido.observacao}"
                </p>
                <div className="mt-4">
                  <Button 
                    onClick={abrirDialogJuncao}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Layers className="w-4 h-4 mr-2" />
                    Juntar Pedidos
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Status do Pedido</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 justify-between">
            <div className="bg-gray-50 p-4 rounded-lg flex-1">
              <div className="text-gray-500 text-sm mb-1">Status Atual</div>
              <div className="flex items-center gap-2">
                {getStatusBadge(pedido.status)}
                <span className="text-sm text-gray-600">
                  Atualizado em {formatarDataSegura(pedido.ultimaAtualizacao)}
                </span>
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg flex-1">
              <div className="text-gray-500 text-sm mb-1">Forma de Pagamento</div>
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-gray-500" />
                <span>{pedido.formaPagamento}</span>
                <Badge className="bg-green-100 text-green-800">
                  {pedido.statusPagamento}
                </Badge>
              </div>
            </div>

            {pedido.rastreamento && (
              <div className="bg-gray-50 p-4 rounded-lg flex-1">
                <div className="text-gray-500 text-sm mb-1">Rastreamento</div>
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-gray-500" />
                    <span className="font-medium">{pedido.rastreamento.transportadora}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                    <span>Código: {pedido.rastreamento.codigo}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="detalhes">Detalhes</TabsTrigger>
          <TabsTrigger value="historico">Histórico</TabsTrigger>
          {pedido.rastreamento && (
            <TabsTrigger value="rastreamento">Rastreamento</TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value="detalhes" className="space-y-6 mt-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Dados do Cliente</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Avatar className="h-10 w-10">
                  <AvatarFallback>{pedido.cliente.avatar}</AvatarFallback>
                </Avatar>
                
                <div>
                  <div className="font-medium">{pedido.cliente.nome}</div>
                  <div className="text-sm text-gray-500 flex flex-col sm:flex-row sm:gap-4">
                    <span className="flex items-center gap-1">
                      <Mail className="w-3 h-3" /> {pedido.cliente.email}
                    </span>
                    <span className="flex items-center gap-1">
                      <Phone className="w-3 h-3" /> {pedido.cliente.telefone}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Itens do Pedido</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Produto</TableHead>
                    <TableHead className="text-right">Qtd</TableHead>
                    <TableHead className="text-right">Preço</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pedido.itens.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.produto}</TableCell>
                      <TableCell className="text-right">{item.quantidade}</TableCell>
                      <TableCell className="text-right">{formatCurrency(item.preco)}</TableCell>
                      <TableCell className="text-right">{formatCurrency(item.subtotal)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              <div className="mt-6 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Subtotal</span>
                  <span>{formatCurrency(pedido.subtotal)}</span>
                </div>
                {pedido.desconto > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Desconto</span>
                    <span>-{formatCurrency(pedido.desconto)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Frete</span>
                  <span>{formatCurrency(pedido.frete)}</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between font-medium">
                  <span>Total</span>
                  <span>{formatCurrency(pedido.total)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Endereço de Entrega</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="font-medium">{pedido.cliente.nome}</p>
                    <p className="text-gray-700">
                      {pedido.endereco.logradouro}, {pedido.endereco.numero} {pedido.endereco.complemento && `- ${pedido.endereco.complemento}`}
                    </p>
                    <p className="text-gray-700">
                      {pedido.endereco.bairro}, {pedido.endereco.cidade} - {pedido.endereco.estado}
                    </p>
                    <p className="text-gray-700">CEP: {pedido.endereco.cep}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {pedido.observacao && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle>Observações</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-gray-700">{pedido.observacao}</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="historico" className="space-y-6 mt-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Histórico do Pedido</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {pedido.historico.map((evento, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="relative">
                      <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center z-10 relative">
                        {evento.status === "criado" && <Package className="w-5 h-5 text-blue-500" />}
                        {evento.status === "aprovado" && <CheckSquare className="w-5 h-5 text-green-500" />}
                        {evento.status === "em_preparacao" && <Package className="w-5 h-5 text-yellow-500" />}
                        {evento.status === "enviado" && <Truck className="w-5 h-5 text-purple-500" />}
                        {evento.status === "entregue" && <CheckCircle2 className="w-5 h-5 text-green-500" />}
                        {evento.status === "cancelado" && <XCircle className="w-5 h-5 text-red-500" />}
                        {evento.status === "processando" && <Clock className="w-5 h-5 text-blue-500" />}
                      </div>
                      {index < pedido.historico.length - 1 && (
                        <div className="absolute top-10 bottom-0 left-1/2 w-0.5 -ml-0.5 bg-gray-200 z-0" />
                      )}
                    </div>
                    
                    <div className="flex-1 pb-6">
                      <div className="flex items-center gap-2">
                        {getStatusBadge(evento.status)}
                        <span className="text-sm text-gray-500">
                          {formatarDataSegura(evento.data)}
                        </span>
                      </div>
                      <p className="mt-1 text-gray-700">{evento.descricao}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {pedido.rastreamento && (
          <TabsContent value="rastreamento" className="space-y-6 mt-6">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-center">
                  <CardTitle>Informações de Rastreamento</CardTitle>
                  <Button variant="outline" size="sm">
                    Atualizar Status
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-gray-50 rounded-lg mb-6">
                  <div className="flex flex-col sm:flex-row sm:justify-between gap-4">
                    <div>
                      <div className="text-sm text-gray-500 mb-1">Transportadora</div>
                      <div className="font-medium">{pedido.rastreamento.transportadora}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500 mb-1">Código de Rastreamento</div>
                      <div className="font-medium">{pedido.rastreamento.codigo}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500 mb-1">Status Atual</div>
                      <Badge className="bg-green-100 text-green-800">
                        {pedido.rastreamento.status}
                      </Badge>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500 mb-1">Última Atualização</div>
                      <div className="font-medium">{formatarDataSegura(pedido.rastreamento.atualizacao)}</div>
                    </div>
                  </div>
                </div>
                
                <div className="text-center p-8">
                  <Package className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">Detalhes do rastreamento não disponíveis.</p>
                  <p className="text-sm text-gray-400 mt-1">
                    Por favor, verifique diretamente no site da transportadora usando o código de rastreamento.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>

      <Dialog open={juncaoDialogOpen} onOpenChange={setJuncaoDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Juntar Pedidos</DialogTitle>
            <DialogDescription>
              Selecione os pedidos que deseja juntar com o pedido {pedido?.numero}
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="p-4 mb-4 bg-blue-50 rounded-lg border border-blue-100">
              <h3 className="font-semibold text-blue-800 mb-2">Pedido Base</h3>
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium">
                    <span className="text-gray-600">Pedido:</span> {pedido?.numero}
                  </p>
                  <p className="text-sm">
                    <span className="text-gray-600">Cliente:</span> {pedido?.cliente.nome}
                  </p>
                  <p className="text-sm">
                    <span className="text-gray-600">Total:</span> {formatCurrency(pedido?.total || 0)}
                  </p>
                </div>
                <div>
                  <p className="text-sm">
                    <span className="text-gray-600">Data:</span> {formatarApenasData(pedido?.data)}
                  </p>
                  <p className="text-sm">
                    <span className="text-gray-600">Status:</span> {pedido?.status}
                  </p>
                  <p className="text-sm">
                    <span className="text-gray-600">Itens:</span> {pedido?.itens?.length}
                  </p>
                </div>
                <div>
                  <p className="text-xs italic max-w-md truncate">
                    <span className="text-gray-600">Observação:</span> {pedido?.observacao}
                  </p>
                </div>
              </div>
            </div>

            <h3 className="font-semibold mb-2">Pedidos disponíveis para junção</h3>
            <div className="border rounded-md overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12 text-center">Selecionar</TableHead>
                    <TableHead>Número</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Itens</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pedidosDisponiveis.length > 0 ? (
                    pedidosDisponiveis.map((pedidoDisp) => (
                      <TableRow key={pedidoDisp.id}>
                        <TableCell className="text-center">
                          <Checkbox 
                            checked={pedidosSelecionadosParaJuncao.includes(pedidoDisp.id)}
                            onCheckedChange={() => toggleSelecionarPedidoParaJuncao(pedidoDisp.id)}
                          />
                        </TableCell>
                        <TableCell>{pedidoDisp.numero}</TableCell>
                        <TableCell>{formatarDataSegura(pedidoDisp.data)}</TableCell>
                        <TableCell>{getStatusBadge(pedidoDisp.status)}</TableCell>
                        <TableCell>{formatCurrency(pedidoDisp.total)}</TableCell>
                        <TableCell>{pedidoDisp.itens}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-4 text-gray-500">
                        Não há pedidos disponíveis para junção com este pedido.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
            
            {pedidosSelecionadosParaJuncao.length > 0 && (
              <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
                <h3 className="font-semibold text-blue-800 mb-2">Resumo da Junção</h3>
                <p className="mb-2">
                  <span className="text-gray-600">Pedidos a serem juntados:</span> {pedidosSelecionadosParaJuncao.length + 1}
                </p>
                <p className="mb-2">
                  <span className="text-gray-600">Total de itens:</span> {
                    pedido.itens.length + 
                    pedidosSelecionadosParaJuncao.reduce((sum, id) => {
                      const p = pedidosDisponiveis.find(p => p.id === id);
                      return sum + (p ? p.itens : 0);
                    }, 0)
                  }
                </p>
                <p>
                  <span className="text-gray-600">Valor total:</span> {
                    formatCurrency(
                      pedido.total + 
                      pedidosSelecionadosParaJuncao.reduce((sum, id) => {
                        const p = pedidosDisponiveis.find(p => p.id === id);
                        return sum + (p ? p.total : 0);
                      }, 0)
                    )
                  }
                </p>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setJuncaoDialogOpen(false)}
            >
              Cancelar
            </Button>
            <Button 
              onClick={realizarJuncaoPedidos}
              disabled={pedidosSelecionadosParaJuncao.length === 0}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Layers className="w-4 h-4 mr-2" />
              Juntar Pedidos
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
