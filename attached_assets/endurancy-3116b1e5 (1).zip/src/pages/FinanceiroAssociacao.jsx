import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  DollarSign,
  Calendar,
  Users,
  FileText,
  ArrowDownCircle,
  ArrowUpCircle,
  BarChart4,
  PieChart,
  Briefcase,
  Landmark,
  FileSearch,
  FilePlus,
  Mic,
  PlusCircle,
  Download,
  Upload,
  Bell,
  ReceiptIcon
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { InvokeLLM } from "@/api/integrations";

export default function FinanceiroAssociacao() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("visao-geral");
  const [isAudioRecording, setIsAudioRecording] = useState(false);
  const [audioTranscription, setAudioTranscription] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Funções para navegação
  const navigateTo = (page) => {
    navigate(createPageUrl(page));
  };

  // Função simulada para transcrição de áudio
  const handleAudioTranscription = async () => {
    if (isAudioRecording) {
      setIsLoading(true);
      setIsAudioRecording(false);
      
      try {
        // Simulação de resposta do GPT para transcrição
        const response = await InvokeLLM({
          prompt: "Simule a transcrição de uma ata de reunião de uma associação, formatada corretamente com introdução, pautas, deliberações e encerramento.",
          response_json_schema: {
            type: "object",
            properties: {
              transcricao: { type: "string" },
              metadata: {
                type: "object",
                properties: {
                  duracao: { type: "string" },
                  participantes_detectados: { type: "array", items: { type: "string" } },
                  palavras_chave: { type: "array", items: { type: "string" } }
                }
              }
            }
          }
        });
        
        setAudioTranscription(response.transcricao);
      } catch (error) {
        console.error("Erro ao transcrever áudio:", error);
      } finally {
        setIsLoading(false);
      }
    } else {
      setIsAudioRecording(true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gestão Financeira</h1>
          <p className="text-gray-500 mt-1">
            Gerencie as finanças, orçamentos, relatórios e obrigações fiscais da sua associação
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Exportar
          </Button>
          <Button className="gap-2" onClick={() => navigateTo("NovoLancamento")}>
            <PlusCircle className="w-4 h-4" />
            Novo Lançamento
          </Button>
        </div>
      </div>

      <Tabs defaultValue="visao-geral" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="flex flex-wrap">
          <TabsTrigger value="visao-geral" className="flex items-center gap-2">
            <BarChart4 className="w-4 h-4" />
            <span>Visão Geral</span>
          </TabsTrigger>
          <TabsTrigger value="contas" className="flex items-center gap-2">
            <DollarSign className="w-4 h-4" />
            <span>Contas a Pagar/Receber</span>
          </TabsTrigger>
          <TabsTrigger value="dre" className="flex items-center gap-2">
            <PieChart className="w-4 h-4" />
            <span>DRE</span>
          </TabsTrigger>
          <TabsTrigger value="orcamento" className="flex items-center gap-2">
            <Briefcase className="w-4 h-4" />
            <span>Orçamento Anual</span>
          </TabsTrigger>
          <TabsTrigger value="fiscal" className="flex items-center gap-2">
            <Landmark className="w-4 h-4" />
            <span>Obrigações Fiscais</span>
          </TabsTrigger>
          <TabsTrigger value="reunioes" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span>Reuniões & Atas</span>
          </TabsTrigger>
          <TabsTrigger value="planejamento" className="flex items-center gap-2">
            <FileSearch className="w-4 h-4" />
            <span>Planejamento Estratégico</span>
          </TabsTrigger>
        </TabsList>

        {/* Visão Geral */}
        <TabsContent value="visao-geral" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Receitas (Mês Atual)</CardTitle>
                <CardDescription>Valor total recebido no mês</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">R$ 32.500,00</div>
                <p className="text-sm text-gray-500 mt-1">+12% em relação ao mês anterior</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Despesas (Mês Atual)</CardTitle>
                <CardDescription>Valor total gasto no mês</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">R$ 27.800,00</div>
                <p className="text-sm text-gray-500 mt-1">-5% em relação ao mês anterior</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Saldo Atual</CardTitle>
                <CardDescription>Saldo em contas bancárias</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">R$ 154.700,00</div>
                <p className="text-sm text-gray-500 mt-1">Atualizado em 15/05/2023</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Últimos Lançamentos</CardTitle>
              <CardDescription>Movimentações financeiras recentes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between py-2">
                  <div className="flex items-center gap-4">
                    <div className="bg-green-100 p-2 rounded-full">
                      <ArrowDownCircle className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Recebimento Anuidade</p>
                      <p className="text-sm text-gray-500">15/05/2023</p>
                    </div>
                  </div>
                  <div className="text-green-600 font-medium">+ R$ 2.400,00</div>
                </div>
                <Separator />
                
                <div className="flex items-center justify-between py-2">
                  <div className="flex items-center gap-4">
                    <div className="bg-red-100 p-2 rounded-full">
                      <ArrowUpCircle className="h-5 w-5 text-red-600" />
                    </div>
                    <div>
                      <p className="font-medium">Pagamento Aluguel</p>
                      <p className="text-sm text-gray-500">12/05/2023</p>
                    </div>
                  </div>
                  <div className="text-red-600 font-medium">- R$ 5.000,00</div>
                </div>
                <Separator />
                
                <div className="flex items-center justify-between py-2">
                  <div className="flex items-center gap-4">
                    <div className="bg-green-100 p-2 rounded-full">
                      <ArrowDownCircle className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Doação Recebida</p>
                      <p className="text-sm text-gray-500">10/05/2023</p>
                    </div>
                  </div>
                  <div className="text-green-600 font-medium">+ R$ 1.500,00</div>
                </div>
                <Separator />
                
                <div className="flex items-center justify-between py-2">
                  <div className="flex items-center gap-4">
                    <div className="bg-red-100 p-2 rounded-full">
                      <ArrowUpCircle className="h-5 w-5 text-red-600" />
                    </div>
                    <div>
                      <p className="font-medium">Conta de Energia</p>
                      <p className="text-sm text-gray-500">08/05/2023</p>
                    </div>
                  </div>
                  <div className="text-red-600 font-medium">- R$ 980,00</div>
                </div>
                <Separator />
                
                <div className="flex items-center justify-between py-2">
                  <div className="flex items-center gap-4">
                    <div className="bg-red-100 p-2 rounded-full">
                      <ArrowUpCircle className="h-5 w-5 text-red-600" />
                    </div>
                    <div>
                      <p className="font-medium">Folha de Pagamento</p>
                      <p className="text-sm text-gray-500">05/05/2023</p>
                    </div>
                  </div>
                  <div className="text-red-600 font-medium">- R$ 12.500,00</div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => navigateTo("HistoricoFinanceiro")}>
                Ver todos os lançamentos
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Contas a Pagar/Receber */}
        <TabsContent value="contas" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Contas a Pagar</CardTitle>
                <CardDescription>Próximos 30 dias: R$ 28.450,00</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Aluguel Sede</p>
                      <p className="text-sm text-gray-500">Vencimento: 25/05/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-amber-100 text-amber-800">Pendente</Badge>
                      <div className="font-medium">R$ 5.000,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Folha de Pagamento</p>
                      <p className="text-sm text-gray-500">Vencimento: 05/06/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-amber-100 text-amber-800">Pendente</Badge>
                      <div className="font-medium">R$ 12.500,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Seguro Predial</p>
                      <p className="text-sm text-gray-500">Vencimento: 10/06/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-amber-100 text-amber-800">Pendente</Badge>
                      <div className="font-medium">R$ 3.200,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Serviços de Limpeza</p>
                      <p className="text-sm text-gray-500">Vencimento: 15/06/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-amber-100 text-amber-800">Pendente</Badge>
                      <div className="font-medium">R$ 1.800,00</div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => navigateTo("ContasPagar")}>
                  Ver todas as contas a pagar
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Contas a Receber</CardTitle>
                <CardDescription>Próximos 30 dias: R$ 45.800,00</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Anuidade - Carlos Silva</p>
                      <p className="text-sm text-gray-500">Vencimento: 20/05/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-100 text-blue-800">A Receber</Badge>
                      <div className="font-medium">R$ 1.200,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Anuidade - Maria Souza</p>
                      <p className="text-sm text-gray-500">Vencimento: 22/05/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-100 text-blue-800">A Receber</Badge>
                      <div className="font-medium">R$ 1.200,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Anuidade - João Ferreira</p>
                      <p className="text-sm text-gray-500">Vencimento: 25/05/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-100 text-blue-800">A Receber</Badge>
                      <div className="font-medium">R$ 1.200,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Doação Programada</p>
                      <p className="text-sm text-gray-500">Previsão: 01/06/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-100 text-blue-800">A Receber</Badge>
                      <div className="font-medium">R$ 5.000,00</div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => navigateTo("ContasReceber")}>
                  Ver todas as contas a receber
                </Button>
              </CardFooter>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Ferramentas de Gestão Financeira</CardTitle>
              <CardDescription>Acesse as principais ferramentas de gerenciamento financeiro</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2" onClick={() => navigateTo("ConciliacaoBancaria")}>
                  <Upload className="h-6 w-6" />
                  <p>Conciliação Bancária</p>
                </Button>
                
                <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2" onClick={() => navigateTo("EmissaoNFe")}>
                  <ReceiptIcon className="h-6 w-6" />
                  <p>Emissão de NF-e</p>
                </Button>
                
                <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2" onClick={() => navigateTo("ExportacaoContabil")}>
                  <Download className="h-6 w-6" />
                  <p>Exportação Contábil</p>
                </Button>
                
                <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2" onClick={() => navigateTo("RelatoriosFinanceiros")}>
                  <FileText className="h-6 w-6" />
                  <p>Relatórios Financeiros</p>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* DRE */}
        <TabsContent value="dre" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Demonstração de Resultado do Exercício</CardTitle>
              <CardDescription>DRE Anual: 2023</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium text-lg">Receitas</h3>
                  <Separator className="my-2" />
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Receitas com Anuidades</span>
                      <span className="font-medium">R$ 144.000,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Doações Recebidas</span>
                      <span className="font-medium">R$ 85.000,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Eventos e Serviços</span>
                      <span className="font-medium">R$ 32.500,00</span>
                    </div>
                    <div className="flex justify-between text-lg font-medium">
                      <span>Total de Receitas</span>
                      <span className="text-green-600">R$ 261.500,00</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium text-lg">Despesas</h3>
                  <Separator className="my-2" />
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Despesas Administrativas</span>
                      <span className="font-medium">R$ 48.300,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Despesas com Pessoal</span>
                      <span className="font-medium">R$ 150.000,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Despesas com Ocupação</span>
                      <span className="font-medium">R$ 60.000,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Despesas com Eventos</span>
                      <span className="font-medium">R$ 18.400,00</span>
                    </div>
                    <div className="flex justify-between text-lg font-medium">
                      <span>Total de Despesas</span>
                      <span className="text-red-600">R$ 276.700,00</span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex justify-between text-xl font-bold">
                  <span>Resultado do Exercício</span>
                  <span className="text-red-600">-R$ 15.200,00</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <p className="text-sm text-gray-500 w-full">
                *Valores acumulados do exercício atual até o mês de Maio/2023
              </p>
              <div className="flex gap-2 w-full">
                <Button variant="outline" className="flex-1" onClick={() => navigateTo("RelatoriosDRE")}>
                  Ver Relatórios Anteriores
                </Button>
                <Button variant="outline" className="flex-1">
                  <Download className="w-4 h-4 mr-2" />
                  Exportar DRE
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Orçamento Anual */}
        <TabsContent value="orcamento" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Orçamento Anual 2023</CardTitle>
                  <CardDescription>Acompanhamento orçamentário do exercício atual</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => navigateTo("NovoOrcamento")}>
                    <FilePlus className="w-4 h-4 mr-2" />
                    Novo Orçamento
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium text-lg">Receitas</h3>
                  <Separator className="my-2" />
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Anuidades</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">R$ 144.000,00 / R$ 220.000,00</span>
                          <Badge className="bg-amber-100 text-amber-800">65%</Badge>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-amber-500 h-2 rounded-full" style={{ width: "65%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Doações</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">R$ 85.000,00 / R$ 120.000,00</span>
                          <Badge className="bg-amber-100 text-amber-800">71%</Badge>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-amber-500 h-2 rounded-full" style={{ width: "71%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Eventos</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">R$ 32.500,00 / R$ 60.000,00</span>
                          <Badge className="bg-red-100 text-red-800">54%</Badge>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: "54%" }}></div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium text-lg">Despesas</h3>
                  <Separator className="my-2" />
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Pessoal</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">R$ 150.000,00 / R$ 180.000,00</span>
                          <Badge className="bg-green-100 text-green-800">83%</Badge>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: "83%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Administrativo</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">R$ 48.300,00 / R$ 60.000,00</span>
                          <Badge className="bg-green-100 text-green-800">81%</Badge>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: "81%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Ocupação</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">R$ 60.000,00 / R$ 60.000,00</span>
                          <Badge className="bg-red-100 text-red-800">100%</Badge>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: "100%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Eventos</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">R$ 18.400,00 / R$ 40.000,00</span>
                          <Badge className="bg-green-100 text-green-800">46%</Badge>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: "46%" }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <div className="space-y-2 w-full">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Total Previsto (Receitas):</span>
                  <span className="font-bold">R$ 400.000,00</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Total Previsto (Despesas):</span>
                  <span className="font-bold">R$ 340.000,00</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Resultado Previsto:</span>
                  <span className="font-bold text-green-600">R$ 60.000,00</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between items-center">
                  <span className="font-medium">Resultado Atual:</span>
                  <span className="font-bold text-red-600">-R$ 15.200,00</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between items-center">
                  <span className="font-medium">Desvio orçamentário:</span>
                  <span className="font-bold text-red-600">-R$ 75.200,00</span>
                </div>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Obrigações Fiscais */}
        <TabsContent value="fiscal" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Obrigações Fiscais e Tributárias</CardTitle>
              <CardDescription>Acompanhamento das obrigações legais da associação</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-md border">
                  <div className="p-4 bg-gray-50 border-b">
                    <h3 className="font-medium">Declarações e Obrigações Acessórias</h3>
                  </div>
                  <div className="divide-y">
                    <div className="flex justify-between items-center p-4">
                      <div>
                        <p className="font-medium">Declaração de Imposto de Renda (DIRF)</p>
                        <p className="text-sm text-gray-500">Prazo: 28/02/2023</p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Entregue</Badge>
                    </div>
                    
                    <div className="flex justify-between items-center p-4">
                      <div>
                        <p className="font-medium">Relação Anual de Informações Sociais (RAIS)</p>
                        <p className="text-sm text-gray-500">Prazo: 31/03/2023</p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Entregue</Badge>
                    </div>
                    
                    <div className="flex justify-between items-center p-4">
                      <div>
                        <p className="font-medium">Declaração de Débitos e Créditos Tributários Federais (DCTF)</p>
                        <p className="text-sm text-gray-500">Prazo: 15/06/2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-amber-100 text-amber-800">Pendente</Badge>
                        <Bell className="w-4 h-4 text-amber-500" />
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center p-4">
                      <div>
                        <p className="font-medium">EFD-Reinf</p>
                        <p className="text-sm text-gray-500">Prazo: 15/07/2023</p>
                      </div>
                      <Badge className="bg-gray-100 text-gray-800">A Vencer</Badge>
                    </div>
                  </div>
                </div>
                
                <div className="rounded-md border">
                  <div className="p-4 bg-gray-50 border-b">
                    <h3 className="font-medium">Certidões Negativas</h3>
                  </div>
                  <div className="divide-y">
                    <div className="flex justify-between items-center p-4">
                      <div>
                        <p className="font-medium">Certidão Negativa de Débitos Relativos aos Tributos Federais</p>
                        <p className="text-sm text-gray-500">Validade: 20/09/2023</p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Regular</Badge>
                    </div>
                    
                    <div className="flex justify-between items-center p-4">
                      <div>
                        <p className="font-medium">Certidão de Regularidade do FGTS</p>
                        <p className="text-sm text-gray-500">Validade: 15/06/2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-amber-100 text-amber-800">Quase Vencendo</Badge>
                        <Bell className="w-4 h-4 text-amber-500" />
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center p-4">
                      <div>
                        <p className="font-medium">Certidão Negativa de Débitos Trabalhistas</p>
                        <p className="text-sm text-gray-500">Validade: 12/11/2023</p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Regular</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => navigateTo("GestaoFiscal")}>
                Gerenciar Obrigações Fiscais
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Integração Contábil</CardTitle>
              <CardDescription>Gerenciamento da integração com o contador</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Exportação para Domínio Sistemas</p>
                    <p className="text-sm text-gray-500">Última exportação: 30/04/2023</p>
                  </div>
                  <Button variant="outline" onClick={() => navigateTo("ExportacaoDominio")}>
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                </div>
                <Separator />
                
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Importação de Arquivo Bancário</p>
                    <p className="text-sm text-gray-500">Última importação: 15/05/2023</p>
                  </div>
                  <Button variant="outline" onClick={() => navigateTo("ImportacaoBancaria")}>
                    <Upload className="w-4 h-4 mr-2" />
                    Importar
                  </Button>
                </div>
                <Separator />
                
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Envio de Documentos ao Contador</p>
                    <p className="text-sm text-gray-500">32 documentos enviados este mês</p>
                  </div>
                  <Button variant="outline" onClick={() => navigateTo("EnvioDocumentos")}>
                    <FileText className="w-4 h-4 mr-2" />
                    Gerenciar
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reuniões & Atas */}
        <TabsContent value="reunioes" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Calendário de Reuniões</CardTitle>
                  <CardDescription>Próximas reuniões da diretoria e assembleia</CardDescription>
                </div>
                <Button onClick={() => navigateTo("NovaReuniao")}>
                  <PlusCircle className="w-4 h-4 mr-2" />
                  Nova Reunião
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-md border p-4 bg-amber-50">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-medium">Reunião de Diretoria - Maio</h3>
                      <p className="text-sm text-gray-500">Quinta-feira, 25/05/2023 - 14:00</p>
                    </div>
                    <Badge>Próxima</Badge>
                  </div>
                  <p className="text-sm">Pauta: Análise de resultados do trimestre, planejamento de eventos, aprovação de novos associados.</p>
                  <div className="mt-4 flex flex-wrap gap-1">
                    <Badge variant="outline" className="bg-white">10 participantes confirmados</Badge>
                    <Badge variant="outline" className="bg-white">Sala de Reuniões Principal</Badge>
                  </div>
                </div>
                
                <div className="rounded-md border p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-medium">Assembleia Geral Ordinária</h3>
                      <p className="text-sm text-gray-500">Sexta-feira, 15/06/2023 - 18:00</p>
                    </div>
                    <Badge variant="outline">Agendada</Badge>
                  </div>
                  <p className="text-sm">Pauta: Apresentação do relatório anual, prestação de contas, eleição de novos membros.</p>
                  <div className="mt-4 flex flex-wrap gap-1">
                    <Badge variant="outline">Todos os associados</Badge>
                    <Badge variant="outline">Auditório</Badge>
                  </div>
                </div>
                
                <div className="rounded-md border p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-medium">Reunião Extraordinária - Planejamento Estratégico</h3>
                      <p className="text-sm text-gray-500">Segunda-feira, 10/07/2023 - 09:00</p>
                    </div>
                    <Badge variant="outline">Agendada</Badge>
                  </div>
                  <p className="text-sm">Pauta: Revisão do planejamento estratégico, definição de metas para o próximo ano.</p>
                  <div className="mt-4 flex flex-wrap gap-1">
                    <Badge variant="outline">Diretoria e Conselho</Badge>
                    <Badge variant="outline">Sala de Reuniões Principal</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => navigateTo("CalendarioReunioes")}>
                Ver calendário completo
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Atas de Reunião</CardTitle>
                  <CardDescription>Registro e consulta de atas de reuniões anteriores</CardDescription>
                </div>
                <Button onClick={() => navigateTo("NovaAta")}>
                  <FilePlus className="w-4 h-4 mr-2" />
                  Nova Ata
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-md border divide-y">
                  <div className="flex justify-between items-center p-4">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="font-medium">Ata da Reunião de Diretoria</p>
                        <p className="text-sm text-gray-500">28/04/2023</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => navigateTo("VerAta?id=12345")}>
                      Visualizar
                    </Button>
                  </div>
                  
                  <div className="flex justify-between items-center p-4">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="font-medium">Ata da Assembleia Geral Ordinária</p>
                        <p className="text-sm text-gray-500">15/03/2023</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => navigateTo("VerAta?id=12344")}>
                      Visualizar
                    </Button>
                  </div>
                  
                  <div className="flex justify-between items-center p-4">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="font-medium">Ata da Reunião Extraordinária</p>
                        <p className="text-sm text-gray-500">10/02/2023</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => navigateTo("VerAta?id=12343")}>
                      Visualizar
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex-col space-y-4">
              <div className="w-full bg-green-50 rounded-lg p-4">
                <h3 className="font-medium flex items-center gap-2">
                  <Mic className="h-5 w-5 text-green-600" />
                  Digitação por voz
                </h3>
                <p className="text-sm mt-1 mb-3">Utilize reconhecimento de voz para agilizar a digitação de atas.</p>
                <Button 
                  variant={isAudioRecording ? "destructive" : "outline"} 
                  className="w-full" 
                  onClick={handleAudioTranscription}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    "Processando..."
                  ) : isAudioRecording ? (
                    <>
                      <span className="animate-pulse mr-2">●</span>
                      Gravando... (Clique para parar)
                    </>
                  ) : (
                    <>
                      <Mic className="w-4 h-4 mr-2" />
                      Iniciar gravação
                    </>
                  )}
                </Button>
                
                {audioTranscription && (
                  <div className="mt-4 bg-white p-3 rounded-md border text-sm">
                    <p className="font-medium mb-1">Transcrição:</p>
                    <p className="text-gray-700">{audioTranscription.substring(0, 100)}...</p>
                    <div className="flex justify-end mt-2">
                      <Button variant="ghost" size="sm" onClick={() => navigateTo("EditarAta")}>
                        Editar transcrição
                      </Button>
                    </div>
                  </div>
                )}
              </div>
              
              <Button variant="outline" className="w-full" onClick={() => navigateTo("AcervoAtas")}>
                Ver todas as atas
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Planejamento Estratégico */}
        <TabsContent value="planejamento" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Planejamento Estratégico 2023-2025</CardTitle>
                  <CardDescription>Acompanhamento de metas e objetivos estratégicos</CardDescription>
                </div>
                <Button variant="outline" onClick={() => navigateTo("PlanejamentoEstrategico")}>
                  Ver completo
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium text-lg mb-2">Objetivos Estratégicos</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Aumentar o número de associados em 30%</span>
                        <Badge className="bg-amber-100 text-amber-800">Em andamento</Badge>
                      </div>
                      <div className="flex justify-between text-sm text-gray-500 mb-1">
                        <span>Progresso: 15% (45 novos associados de 180 previstos)</span>
                        <span>Prazo: Dez/2023</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-amber-500 h-2 rounded-full" style={{ width: "15%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Implementar 3 novos programas assistenciais</span>
                        <Badge className="bg-green-100 text-green-800">No prazo</Badge>
                      </div>
                      <div className="flex justify-between text-sm text-gray-500 mb-1">
                        <span>Progresso: 33% (1 programa implementado de 3)</span>
                        <span>Prazo: Jun/2024</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: "33%" }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Atingir sustentabilidade financeira</span>
                        <Badge className="bg-red-100 text-red-800">Atrasado</Badge>
                      </div>
                      <div className="flex justify-between text-sm text-gray-500 mb-1">
                        <span>Progresso: 40% (déficit atual de 15.200,00)</span>
                        <span>Prazo: Dez/2023</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: "40%" }}></div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium text-lg mb-3">Próximos Eventos Planejados</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9 bg-purple-100">
                          <AvatarFallback className="text-purple-700">EV</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">Workshop de Capacitação</p>
                          <p className="text-sm text-gray-500">20/06/2023 - Auditório Principal</p>
                        </div>
                      </div>
                      <Badge>20 dias</Badge>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9 bg-blue-100">
                          <AvatarFallback className="text-blue-700">CS</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">Campanha de Arrecadação</p>
                          <p className="text-sm text-gray-500">15/07/2023 - Online</p>
                        </div>
                      </div>
                      <Badge>45 dias</Badge>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9 bg-green-100">
                          <AvatarFallback className="text-green-700">CF</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">Feira Anual</p>
                          <p className="text-sm text-gray-500">10/09/2023 - Centro de Convenções</p>
                        </div>
                      </div>
                      <Badge>100 dias</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex gap-4">
              <Button variant="outline" className="flex-1" onClick={() => navigateTo("NovoEvento")}>
                <PlusCircle className="w-4 h-4 mr-2" />
                Novo Evento
              </Button>
              <Button variant="outline" className="flex-1" onClick={() => navigateTo("GestaoMetas")}>
                <FileSearch className="w-4 h-4 mr-2" />
                Gestão de Metas
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}