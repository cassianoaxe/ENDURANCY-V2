
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Building2,
  Settings,
  Shield,
  CreditCard,
  Save,
  Plus,
  Edit,
  Trash2,
  Check,
  X,
  AlertTriangle,
  Info,
  HelpCircle,
  ExternalLink,
  FileText,
  Mail,
  RefreshCw,
  CheckCircle,
  ArrowRight,
  DollarSign,
  Percent,
  Wallet,
  Lock,
  Zap,
  QrCode,
  MoreHorizontal,
  Eye,
  Copy
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel } from '@/components/ui/dropdown-menu';
import { Checkbox } from '@/components/ui/checkbox';

export default function ComplyPaySettings() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('geral');
  const [isLoading, setIsLoading] = useState(false);
  const [showNewMethodDialog, setShowNewMethodDialog] = useState(false);
  const [selectedMethodType, setSelectedMethodType] = useState(null);
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [webhooks, setWebhooks] = useState([]);
  const [isWebhookModalOpen, setIsWebhookModalOpen] = useState(false);
  const [editingWebhook, setEditingWebhook] = useState(null);

  // Mock payment methods
  useEffect(() => {
    const mockPaymentMethods = [
      {
        id: 'method-1',
        name: 'Cartão de Crédito (Cielo)',
        type: 'credit_card',
        provider: 'Cielo',
        is_active: true,
        is_default: true,
        integration_type: 'api',
        fees: { percentage: 2.99, fixed: 0.39 },
        last_tested: '2023-10-15T14:30:00Z'
      },
      {
        id: 'method-2',
        name: 'Boleto Bancário',
        type: 'boleto',
        provider: 'Banco do Brasil',
        is_active: true,
        is_default: false,
        integration_type: 'api',
        fees: { percentage: 1.5, fixed: 2.5 },
        last_tested: '2023-10-12T11:45:00Z'
      },
      {
        id: 'method-3',
        name: 'PIX',
        type: 'pix',
        provider: 'Mercado Pago',
        is_active: true,
        is_default: false,
        integration_type: 'api',
        fees: { percentage: 0.99, fixed: 0 },
        last_tested: '2023-10-18T09:20:00Z'
      },
      {
        id: 'method-4',
        name: 'Transferência Bancária',
        type: 'bank_account',
        provider: 'Manual',
        is_active: true,
        is_default: false,
        integration_type: 'manual',
        fees: { percentage: 0, fixed: 0 },
        last_tested: null
      }
    ];

    const mockWebhooks = [
      {
        id: 'webhook-1',
        name: 'Notificação de Pagamento',
        url: 'https://api.example.com/payment-notification',
        events: ['payment.success', 'payment.failed'],
        is_active: true,
        last_triggered: '2023-10-20T15:45:00Z',
        created_date: '2023-09-15T10:00:00Z'
      },
      {
        id: 'webhook-2',
        name: 'Notificação de Reembolso',
        url: 'https://api.example.com/refund-notification',
        events: ['refund.initiated', 'refund.completed'],
        is_active: true,
        last_triggered: '2023-10-18T11:30:00Z',
        created_date: '2023-09-15T10:15:00Z'
      }
    ];

    setPaymentMethods(mockPaymentMethods);
    setWebhooks(mockWebhooks);
  }, []);

  const getMethodTypeIcon = (type) => {
    switch(type) {
      case 'credit_card':
        return <CreditCard className="h-5 w-5 text-blue-500" />;
      case 'debit_card':
        return <CreditCard className="h-5 w-5 text-green-500" />;
      case 'boleto':
        return <FileText className="h-5 w-5 text-purple-500" />;
      case 'pix':
        return <QrCode className="h-5 w-5 text-orange-500" />;
      case 'bank_account':
        return <Building2 className="h-5 w-5 text-teal-500" />;
      default:
        return <DollarSign className="h-5 w-5 text-gray-500" />;
    }
  };

  const handleSaveWebhook = (data) => {
    if (editingWebhook) {
      // Update existing webhook
      setWebhooks(prev => prev.map(webhook => 
        webhook.id === editingWebhook.id ? {...webhook, ...data} : webhook
      ));
      toast({
        title: "Webhook atualizado",
        description: "O webhook foi atualizado com sucesso."
      });
    } else {
      // Create new webhook
      const newWebhook = {
        id: `webhook-${webhooks.length + 1}`,
        created_date: new Date().toISOString(),
        is_active: true,
        last_triggered: null,
        ...data
      };
      setWebhooks(prev => [...prev, newWebhook]);
      toast({
        title: "Webhook criado",
        description: "O novo webhook foi criado com sucesso."
      });
    }
    setIsWebhookModalOpen(false);
    setEditingWebhook(null);
  };

  const handleDeleteMethod = (methodId) => {
    setPaymentMethods(prev => prev.filter(method => method.id !== methodId));
    toast({
      title: "Método de pagamento removido",
      description: "O método de pagamento foi removido com sucesso."
    });
  };

  const handleToggleMethodStatus = (methodId) => {
    setPaymentMethods(prev => prev.map(method => 
      method.id === methodId ? {...method, is_active: !method.is_active} : method
    ));
    toast({
      title: "Status atualizado",
      description: "O status do método de pagamento foi atualizado com sucesso."
    });
  };

  const handleSetDefaultMethod = (methodId) => {
    setPaymentMethods(prev => prev.map(method => ({
      ...method,
      is_default: method.id === methodId
    })));
    toast({
      title: "Método padrão definido",
      description: "O método de pagamento padrão foi atualizado com sucesso."
    });
  };

  const handleTestConnection = (methodId) => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setPaymentMethods(prev => prev.map(method => 
        method.id === methodId ? {...method, last_tested: new Date().toISOString()} : method
      ));
      setIsLoading(false);
      toast({
        title: "Conexão testada",
        description: "A conexão com o provedor de pagamento foi testada com sucesso."
      });
    }, 1500);
  };

  const handleSaveSettings = () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Configurações salvas",
        description: "As configurações de pagamento foram salvas com sucesso."
      });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Configurações do ComplyPay</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Gerencie métodos de pagamento, integrações e preferências do sistema de pagamentos
          </p>
        </div>
        <Button onClick={handleSaveSettings} disabled={isLoading}>
          {isLoading ? "Salvando..." : "Salvar Alterações"}
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="geral" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            <span>Geral</span>
          </TabsTrigger>
          <TabsTrigger value="payment-methods" className="flex items-center gap-2">
            <CreditCard className="w-4 h-4" />
            <span>Métodos de Pagamento</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            <span>Segurança</span>
          </TabsTrigger>
          <TabsTrigger value="integrations" className="flex items-center gap-2">
            <Zap className="w-4 h-4" />
            <span>Integrações</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Mail className="w-4 h-4" />
            <span>Notificações</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="geral" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações Gerais</CardTitle>
              <CardDescription>
                Configure as opções básicas do sistema de pagamentos
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Moeda Padrão</Label>
                  <Select defaultValue="BRL">
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a moeda" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BRL">Real (BRL)</SelectItem>
                      <SelectItem value="USD">Dólar Americano (USD)</SelectItem>
                      <SelectItem value="EUR">Euro (EUR)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500">A moeda utilizada para processamento de pagamentos</p>
                </div>

                <div className="space-y-2">
                  <Label>Ambiente</Label>
                  <Select defaultValue="sandbox">
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o ambiente" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sandbox">Sandbox (Testes)</SelectItem>
                      <SelectItem value="production">Produção</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500">Ambiente no qual as transações serão processadas</p>
                </div>

                <div className="space-y-2">
                  <Label>Tempo de Expiração de Faturas (dias)</Label>
                  <Input type="number" defaultValue={15} min={1} max={90} />
                  <p className="text-sm text-gray-500">Tempo em dias até uma fatura expirar</p>
                </div>

                <div className="space-y-2">
                  <Label>Tentativas de Cobrança Automática</Label>
                  <Input type="number" defaultValue={3} min={1} max={10} />
                  <p className="text-sm text-gray-500">Número de tentativas para cobranças automáticas</p>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Opções de Pagamento</h3>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Permitir Pagamentos Parciais</Label>
                    <p className="text-sm text-gray-500">Habilitar pagamentos parciais de faturas</p>
                  </div>
                  <Switch defaultChecked={false} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Redirecionar após Pagamento</Label>
                    <p className="text-sm text-gray-500">Redirecionar para página de agradecimento após pagamento</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Solicitar Endereço de Faturamento</Label>
                    <p className="text-sm text-gray-500">Solicitar endereço de faturamento para pagamentos com cartão</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Emitir Recibos Automaticamente</Label>
                    <p className="text-sm text-gray-500">Emitir e enviar recibos por email após pagamento confirmado</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment-methods" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Métodos de Pagamento</CardTitle>
                  <CardDescription>Gerencie os métodos de pagamento disponíveis</CardDescription>
                </div>
                <Dialog open={showNewMethodDialog} onOpenChange={setShowNewMethodDialog}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Adicionar Método
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>Adicionar Método de Pagamento</DialogTitle>
                      <DialogDescription>
                        Selecione o tipo de método de pagamento que deseja adicionar.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4 py-4">
                      <RadioGroup value={selectedMethodType} onValueChange={setSelectedMethodType}>
                        <div className="flex items-center space-x-2 border rounded-md p-3 hover:bg-gray-50 cursor-pointer" onClick={() => setSelectedMethodType('credit_card')}>
                          <RadioGroupItem value="credit_card" id="credit_card" />
                          <div className="flex items-center">
                            <CreditCard className="mr-2 h-5 w-5 text-blue-500" />
                            <Label htmlFor="credit_card" className="cursor-pointer font-medium">Cartão de Crédito</Label>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 border rounded-md p-3 hover:bg-gray-50 cursor-pointer" onClick={() => setSelectedMethodType('pix')}>
                          <RadioGroupItem value="pix" id="pix" />
                          <div className="flex items-center">
                            <QrCode className="mr-2 h-5 w-5 text-orange-500" />
                            <Label htmlFor="pix" className="cursor-pointer font-medium">PIX</Label>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2 border rounded-md p-3 hover:bg-gray-50 cursor-pointer" onClick={() => setSelectedMethodType('boleto')}>
                          <RadioGroupItem value="boleto" id="boleto" />
                          <div className="flex items-center">
                            <FileText className="mr-2 h-5 w-5 text-purple-500" />
                            <Label htmlFor="boleto" className="cursor-pointer font-medium">Boleto Bancário</Label>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2 border rounded-md p-3 hover:bg-gray-50 cursor-pointer" onClick={() => setSelectedMethodType('bank_account')}>
                          <RadioGroupItem value="bank_account" id="bank_account" />
                          <div className="flex items-center">
                            <Building2 className="mr-2 h-5 w-5 text-teal-500" />
                            <Label htmlFor="bank_account" className="cursor-pointer font-medium">Transferência Bancária</Label>
                          </div>
                        </div>
                      </RadioGroup>
                    </div>
                    
                    <DialogFooter>
                      <Button 
                        variant="outline" 
                        onClick={() => setShowNewMethodDialog(false)}
                      >
                        Cancelar
                      </Button>
                      <Button 
                        onClick={() => {
                          setShowNewMethodDialog(false);
                          toast({
                            title: "Configuração de novo método",
                            description: "A configuração de um novo método está em desenvolvimento."
                          });
                        }} 
                        disabled={!selectedMethodType}
                      >
                        Continuar
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Método de Pagamento</TableHead>
                    <TableHead>Provedor</TableHead>
                    <TableHead>Taxas</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Padrão</TableHead>
                    <TableHead>Última Verificação</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paymentMethods.map((method) => (
                    <TableRow key={method.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          {getMethodTypeIcon(method.type)}
                          <span className="ml-2">{method.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{method.provider}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="text-sm">{method.fees.percentage}% + R$ {method.fees.fixed.toFixed(2)}</span>
                          <span className="text-xs text-gray-500">por transação</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={method.is_active ? "success" : "secondary"}>
                          {method.is_active ? "Ativo" : "Inativo"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {method.is_default ? <CheckCircle className="h-5 w-5 text-green-500" /> : null}
                      </TableCell>
                      <TableCell>
                        {method.last_tested ? (
                          <div className="flex flex-col">
                            <span className="text-sm">{new Date(method.last_tested).toLocaleDateString()}</span>
                            <span className="text-xs text-gray-500">{new Date(method.last_tested).toLocaleTimeString()}</span>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-500">Nunca testado</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => toast({
                              title: "Editar método",
                              description: "A edição de método está em desenvolvimento."
                            })}>
                              <Edit className="mr-2 h-4 w-4" />
                              <span>Editar</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleToggleMethodStatus(method.id)}>
                              {method.is_active ? (
                                <>
                                  <X className="mr-2 h-4 w-4" />
                                  <span>Desativar</span>
                                </>
                              ) : (
                                <>
                                  <Check className="mr-2 h-4 w-4" />
                                  <span>Ativar</span>
                                </>
                              )}
                            </DropdownMenuItem>
                            {!method.is_default && (
                              <DropdownMenuItem onClick={() => handleSetDefaultMethod(method.id)}>
                                <CheckCircle className="mr-2 h-4 w-4" />
                                <span>Definir como Padrão</span>
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => handleTestConnection(method.id)}>
                              <RefreshCw className="mr-2 h-4 w-4" />
                              <span>Testar Conexão</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              className="text-red-600"
                              onClick={() => handleDeleteMethod(method.id)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              <span>Remover</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Segurança</CardTitle>
              <CardDescription>Configure os parâmetros de segurança para processamento de pagamentos</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Validação de Transações</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Valor Máximo por Transação (R$)</Label>
                    <Input type="number" defaultValue={10000} min={0} />
                    <p className="text-sm text-gray-500">Valor máximo permitido em uma única transação</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Limite Diário de Transações</Label>
                    <Input type="number" defaultValue={50} min={0} />
                    <p className="text-sm text-gray-500">Número máximo de transações por dia</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Verificação de Endereço (AVS)</Label>
                    <p className="text-sm text-gray-500">Verificar endereço do titular do cartão</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Verificação de Código de Segurança (CVV)</Label>
                    <p className="text-sm text-gray-500">Exigir código de segurança em pagamentos com cartão</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Autenticação 3D Secure</Label>
                    <p className="text-sm text-gray-500">Habilitar autenticação 3D Secure para pagamentos com cartão</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Detecção de Fraude</h3>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Detecção Automática de Fraude</Label>
                    <p className="text-sm text-gray-500">Usar algoritmos de detecção de fraude</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Bloquear Transações Suspeitas</Label>
                    <p className="text-sm text-gray-500">Bloquear automaticamente transações identificadas como de alto risco</p>
                  </div>
                  <Switch defaultChecked={false} />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Verificação de Geolocalização</Label>
                    <p className="text-sm text-gray-500">Verificar localização do pagador</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                
                <div className="space-y-2">
                  <Label>Nível de Sensibilidade da Detecção de Fraude</Label>
                  <Select defaultValue="medium">
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o nível" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Baixo</SelectItem>
                      <SelectItem value="medium">Médio</SelectItem>
                      <SelectItem value="high">Alto</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500">Sensibilidade dos algoritmos de detecção de fraude</p>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Segurança de Dados</h3>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Criptografia de Dados de Pagamento</Label>
                    <p className="text-sm text-gray-500">Ativar criptografia para dados sensíveis de pagamento</p>
                  </div>
                  <Switch defaultChecked={true} disabled />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Armazenar Dados de Cartão</Label>
                    <p className="text-sm text-gray-500">Armazenar dados de cartão para futuras transações (em conformidade com PCI DSS)</p>
                  </div>
                  <Switch defaultChecked={false} />
                </div>
                
                <div className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-green-500" />
                  <p className="text-sm">Todas as transações são processadas em ambiente seguro e certificado PCI DSS.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Webhooks</CardTitle>
                  <CardDescription>Configure endpoints para receber notificações de eventos</CardDescription>
                </div>
                <Button onClick={() => {
                  setEditingWebhook(null);
                  setIsWebhookModalOpen(true);
                }}>
                  <Plus className="mr-2 h-4 w-4" />
                  Novo Webhook
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>URL</TableHead>
                    <TableHead>Eventos</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Última Execução</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {webhooks.map((webhook) => (
                    <TableRow key={webhook.id}>
                      <TableCell className="font-medium">{webhook.name}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <span className="text-sm truncate max-w-[200px]">{webhook.url}</span>
                          <Button variant="ghost" size="sm" onClick={() => {
                            navigator.clipboard.writeText(webhook.url);
                            toast({
                              title: "URL copiada",
                              description: "A URL do webhook foi copiada para a área de transferência."
                            });
                          }}>
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {webhook.events.map((event, index) => (
                            <Badge key={index} variant="outline">{event}</Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={webhook.is_active ? "success" : "secondary"}>
                          {webhook.is_active ? "Ativo" : "Inativo"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {webhook.last_triggered ? (
                          <div className="flex flex-col">
                            <span className="text-sm">{new Date(webhook.last_triggered).toLocaleDateString()}</span>
                            <span className="text-xs text-gray-500">{new Date(webhook.last_triggered).toLocaleTimeString()}</span>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-500">Nunca</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => {
                              setEditingWebhook(webhook);
                              setIsWebhookModalOpen(true);
                            }}>
                              <Edit className="mr-2 h-4 w-4" />
                              <span>Editar</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => {
                              setWebhooks(prev => prev.map(w => 
                                w.id === webhook.id ? {...w, is_active: !w.is_active} : w
                              ));
                              toast({
                                title: "Status atualizado",
                                description: `O webhook foi ${webhook.is_active ? 'desativado' : 'ativado'} com sucesso.`
                              });
                            }}>
                              {webhook.is_active ? (
                                <>
                                  <X className="mr-2 h-4 w-4" />
                                  <span>Desativar</span>
                                </>
                              ) : (
                                <>
                                  <Check className="mr-2 h-4 w-4" />
                                  <span>Ativar</span>
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => toast({
                              title: "Teste de webhook",
                              description: "Um evento de teste foi enviado para o webhook."
                            })}>
                              <RefreshCw className="mr-2 h-4 w-4" />
                              <span>Testar</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              className="text-red-600"
                              onClick={() => {
                                setWebhooks(prev => prev.filter(w => w.id !== webhook.id));
                                toast({
                                  title: "Webhook removido",
                                  description: "O webhook foi removido com sucesso."
                                });
                              }}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              <span>Remover</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              <Dialog open={isWebhookModalOpen} onOpenChange={setIsWebhookModalOpen}>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{editingWebhook ? 'Editar Webhook' : 'Novo Webhook'}</DialogTitle>
                    <DialogDescription>
                      Configure um endpoint para receber notificações de eventos do sistema.
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="webhook-name">Nome</Label>
                      <Input 
                        id="webhook-name" 
                        defaultValue={editingWebhook?.name || ''} 
                        placeholder="Ex: Notificação de Pagamento"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="webhook-url">URL do Endpoint</Label>
                      <Input 
                        id="webhook-url" 
                        defaultValue={editingWebhook?.url || ''} 
                        placeholder="https://exemplo.com/webhook"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Eventos</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="flex items-center space-x-2">
                          <Checkbox id="payment.success" defaultChecked={editingWebhook?.events.includes('payment.success')} />
                          <Label htmlFor="payment.success">Pagamento Aprovado</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox id="payment.failed" defaultChecked={editingWebhook?.events.includes('payment.failed')} />
                          <Label htmlFor="payment.failed">Pagamento Falhou</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox id="refund.initiated" defaultChecked={editingWebhook?.events.includes('refund.initiated')} />
                          <Label htmlFor="refund.initiated">Reembolso Iniciado</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox id="refund.completed" defaultChecked={editingWebhook?.events.includes('refund.completed')} />
                          <Label htmlFor="refund.completed">Reembolso Concluído</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox id="subscription.created" defaultChecked={editingWebhook?.events.includes('subscription.created')} />
                          <Label htmlFor="subscription.created">Assinatura Criada</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox id="subscription.canceled" defaultChecked={editingWebhook?.events.includes('subscription.canceled')} />
                          <Label htmlFor="subscription.canceled">Assinatura Cancelada</Label>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox id="webhook-active" defaultChecked={editingWebhook ? editingWebhook.is_active : true} />
                      <Label htmlFor="webhook-active">Webhook Ativo</Label>
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsWebhookModalOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={() => {
                      const data = {
                        name: document.getElementById('webhook-name').value,
                        url: document.getElementById('webhook-url').value,
                        events: ['payment.success', 'payment.failed'],
                        is_active: document.getElementById('webhook-active').checked
                      };
                      handleSaveWebhook(data);
                    }}>
                      {editingWebhook ? 'Atualizar' : 'Criar'}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Integrações com Serviços Externos</CardTitle>
              <CardDescription>Configure integrações com serviços de terceiros</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-md">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-md">
                    <Building2 className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Sistema Financeiro</h3>
                    <p className="text-sm text-gray-500">Integração com o módulo financeiro interno</p>
                  </div>
                </div>
                <Switch defaultChecked={true} />
              </div>
              
              <div className="flex items-center justify-between p-4 border rounded-md">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-purple-100 rounded-md">
                    <FileText className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Emissor de Notas Fiscais</h3>
                    <p className="text-sm text-gray-500">Integração com sistema de emissão de notas fiscais</p>
                  </div>
                </div>
                <Switch defaultChecked={false} />
              </div>
              
              <div className="flex items-center justify-between p-4 border rounded-md">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-green-100 rounded-md">
                    <Mail className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Sistema de Email Marketing</h3>
                    <p className="text-sm text-gray-500">Envio de campanhas e automações para clientes</p>
                  </div>
                </div>
                <Switch defaultChecked={false} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notificações por Email</CardTitle>
              <CardDescription>Configure as notificações por email do sistema de pagamentos</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Email de Nova Fatura</Label>
                  <p className="text-sm text-gray-500">Enviar email quando uma nova fatura for gerada</p>
                </div>
                <Switch defaultChecked={true} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Lembrete de Fatura Pendente</Label>
                  <p className="text-sm text-gray-500">Enviar lembretes para faturas pendentes</p>
                </div>
                <Switch defaultChecked={true} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Confirmação de Pagamento</Label>
                  <p className="text-sm text-gray-500">Enviar confirmação quando um pagamento for aprovado</p>
                </div>
                <Switch defaultChecked={true} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Notificação de Reembolso</Label>
                  <p className="text-sm text-gray-500">Enviar notificação quando um reembolso for processado</p>
                </div>
                <Switch defaultChecked={true} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Alerta de Falha de Pagamento</Label>
                  <p className="text-sm text-gray-500">Enviar alerta quando um pagamento falhar</p>
                </div>
                <Switch defaultChecked={true} />
              </div>

              <Separator />
              
              <div className="space-y-2">
                <Label>Email do Remetente</Label>
                <Input defaultValue="pagamentos@minhaorganizacao.com.br" placeholder="Ex: pagamentos@minhaorganizacao.com.br" />
              </div>
              
              <div className="space-y-2">
                <Label>Nome do Remetente</Label>
                <Input defaultValue="Sistema de Pagamentos" placeholder="Ex: Sistema de Pagamentos" />
              </div>
              
              <div className="space-y-2">
                <Label>Email para Cópia (CC)</Label>
                <Input defaultValue="financeiro@minhaorganizacao.com.br" placeholder="Ex: financeiro@minhaorganizacao.com.br" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Notificações para Administradores</CardTitle>
              <CardDescription>Configure as notificações internas para administradores do sistema</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Notificação de Pagamento de Alto Valor</Label>
                  <p className="text-sm text-gray-500">Notificar administradores sobre pagamentos acima de R$ 5.000</p>
                </div>
                <Switch defaultChecked={true} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Alerta de Transação Suspeita</Label>
                  <p className="text-sm text-gray-500">Alertar sobre transações marcadas como suspeitas</p>
                </div>
                <Switch defaultChecked={true} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Resumo Diário de Transações</Label>
                  <p className="text-sm text-gray-500">Enviar resumo diário das transações processadas</p>
                </div>
                <Switch defaultChecked={true} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Notificação de Assinatura Cancelada</Label>
                  <p className="text-sm text-gray-500">Notificar quando uma assinatura for cancelada</p>
                </div>
                <Switch defaultChecked={true} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Alerta de Falha na Integração</Label>
                  <p className="text-sm text-gray-500">Alertar quando houver falha na integração com provedores de pagamento</p>
                </div>
                <Switch defaultChecked={true} />
              </div>

              <Separator />
              
              <div className="space-y-2">
                <Label>Emails dos Administradores (separados por vírgula)</Label>
                <Input defaultValue="admin@minhaorganizacao.com.br, financeiro@minhaorganizacao.com.br" />
              </div>
              
              <div className="space-y-2">
                <Label>Nível de Prioridade para Notificações</Label>
                <Select defaultValue="high">
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o nível" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Baixa</SelectItem>
                    <SelectItem value="medium">Média</SelectItem>
                    <SelectItem value="high">Alta</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} disabled={isLoading}>
          {isLoading ? "Salvando..." : "Salvar Alterações"}
        </Button>
      </div>
    </div>
  );
}
