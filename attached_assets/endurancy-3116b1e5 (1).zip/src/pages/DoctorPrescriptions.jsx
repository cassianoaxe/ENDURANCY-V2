import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import DoctorLayout from '../components/DoctorLayout';
import { 
  Search, Filter, Plus, MoreHorizontal,
  FileText, Calendar, Eye, Download, Pencil,
  ClipboardCheck, CheckCircle, XCircle, Clock,
  Printer, Share2, Ban, ChevronLeft, ChevronRight,
  AlertTriangle, CreditCard
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Spinner } from "@/components/ui/spinner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function DoctorPrescriptions() {
  const navigate = useNavigate();
  const [prescriptions, setPrescriptions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [filteredPrescriptions, setFilteredPrescriptions] = useState([]);
  const [showNewPrescriptionDialog, setShowNewPrescriptionDialog] = useState(false);
  const [showRenewDialog, setShowRenewDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedPrescription, setSelectedPrescription] = useState(null);
  const [patients, setPatients] = useState([]);
  const [showFilters, setShowFilters] = useState(false);
  const [sortOrder, setSortOrder] = useState({ field: 'date', direction: 'desc' });
  
  const [filters, setFilters] = useState({
    status: 'all',
    dateFrom: '',
    dateTo: '',
    product: 'all'
  });

  const [newPrescription, setNewPrescription] = useState({
    patientId: '',
    products: [{ name: '', dosage: '', frequency: '', duration: '30 dias', instructions: '' }],
    diagnosis: '',
    notes: '',
    validityDays: 90
  });

  const prescriptionsPerPage = 10;

  const availableProducts = [
    { id: 'cbd5', name: 'CBD Oil 5%', variations: ['30ml', '50ml', '100ml'] },
    { id: 'cbd10', name: 'CBD Oil 10%', variations: ['30ml', '50ml'] },
    { id: 'cbd20', name: 'CBD Oil 20%', variations: ['30ml'] },
    { id: 'thc5', name: 'THC Oil 5%', variations: ['30ml'] },
    { id: 'cbd_caps', name: 'CBD Cápsulas 25mg', variations: ['30 cáps', '60 cáps'] },
    { id: 'cbd_spray', name: 'CBD Spray Oral', variations: ['30ml'] },
    { id: 'cbd_topical', name: 'CBD Creme Tópico', variations: ['50g'] }
  ];

  useEffect(() => {
    loadPrescriptions();
    loadPatients();
  }, []);

  useEffect(() => {
    filterAndSortPrescriptions();
  }, [prescriptions, searchQuery, activeTab, sortOrder, filters]);

  const loadPrescriptions = () => {
    setIsLoading(true);
    
    setTimeout(() => {
      const mockPrescriptions = [
        {
          id: 'PR001',
          patientId: 'PAT001',
          patientName: 'Maria Oliveira',
          date: '2024-03-01',
          status: 'active',
          expiryDate: '2024-06-01',
          products: [
            { name: 'CBD Oil 5%', dosage: '1ml', frequency: '2x ao dia', duration: '90 dias' }
          ],
          diagnosis: 'Insônia e Ansiedade',
          notes: 'Paciente relatou melhora significativa no sono após 2 semanas de uso.',
          doctor: 'Dr. João Silva',
          created: '2024-03-01T10:30:00Z'
        },
        {
          id: 'PR002',
          patientId: 'PAT002',
          patientName: 'João Santos',
          date: '2024-02-10',
          status: 'active',
          expiryDate: '2024-05-10',
          products: [
            { name: 'CBD Oil 10%', dosage: '0.5ml', frequency: '2x ao dia', duration: '90 dias' }
          ],
          diagnosis: 'Dor Crônica',
          notes: 'Aumentar dosagem em caso de dor persistente após 2 semanas.',
          doctor: 'Dr. João Silva',
          created: '2024-02-10T14:15:00Z'
        },
        {
          id: 'PR003',
          patientId: 'PAT003',
          patientName: 'Ana Pereira',
          date: '2024-01-20',
          status: 'active',
          expiryDate: '2024-04-20',
          products: [
            { name: 'CBD Oil 20%', dosage: '0.3ml', frequency: '2x ao dia', duration: '90 dias' }
          ],
          diagnosis: 'Epilepsia',
          notes: 'Monitorar frequência de crises e ajustar dosagem conforme necessário.',
          doctor: 'Dr. João Silva',
          created: '2024-01-20T09:45:00Z'
        },
        {
          id: 'PR004',
          patientId: 'PAT004',
          patientName: 'Carlos Mendes',
          date: '2023-12-15',
          status: 'expiring',
          expiryDate: '2024-03-15',
          products: [
            { name: 'CBD Oil 10%', dosage: '0.5ml', frequency: '3x ao dia', duration: '90 dias' }
          ],
          diagnosis: 'Parkinson',
          notes: 'Paciente relatou redução significativa nos tremores.',
          doctor: 'Dr. João Silva',
          created: '2023-12-15T11:20:00Z'
        },
        {
          id: 'PR005',
          patientId: 'PAT005',
          patientName: 'Paulo Silva',
          date: '2023-11-05',
          status: 'expired',
          expiryDate: '2024-02-05',
          products: [
            { name: 'CBD Oil 5%', dosage: '0.5ml', frequency: '1x ao dia', duration: '90 dias' }
          ],
          diagnosis: 'TDAH e Insônia',
          notes: 'Paciente não retornou para avaliação. Entrar em contato para acompanhamento.',
          doctor: 'Dr. João Silva',
          created: '2023-11-05T16:00:00Z'
        },
        {
          id: 'PR006',
          patientId: 'PAT006',
          patientName: 'Marta Alvez',
          date: '2024-02-25',
          status: 'active',
          expiryDate: '2024-05-25',
          products: [
            { name: 'CBD Cápsulas 25mg', dosage: '1 cápsula', frequency: '1x ao dia', duration: '90 dias' },
            { name: 'CBD Oil 5%', dosage: '0.5ml', frequency: 'Em casos de crise', duration: '90 dias' }
          ],
          diagnosis: 'Enxaqueca Crônica',
          notes: 'Utilizar óleo apenas durante crises de enxaqueca se as cápsulas não forem suficientes.',
          doctor: 'Dr. João Silva',
          created: '2024-02-25T08:30:00Z'
        },
        {
          id: 'PR007',
          patientId: 'PAT007',
          patientName: 'Roberto Martins',
          date: '2023-12-20',
          status: 'expired',
          expiryDate: '2024-03-20',
          products: [
            { name: 'CBD Oil 5%', dosage: '0.5ml', frequency: '2x ao dia', duration: '90 dias' }
          ],
          diagnosis: 'Ansiedade Generalizada',
          notes: 'Prescrição expirada. Paciente relatou resultados positivos mas não retornou para renovação.',
          doctor: 'Dr. João Silva',
          created: '2023-12-20T13:45:00Z'
        }
      ];
      
      setPrescriptions(mockPrescriptions);
      setFilteredPrescriptions(mockPrescriptions);
      setIsLoading(false);
    }, 1000);
  };

  const loadPatients = () => {
    setTimeout(() => {
      const mockPatients = [
        { id: 'PAT001', fullName: 'Maria Oliveira', age: 39, gender: 'Feminino' },
        { id: 'PAT002', fullName: 'João Santos', age: 51, gender: 'Masculino' },
        { id: 'PAT003', fullName: 'Ana Pereira', age: 34, gender: 'Feminino' },
        { id: 'PAT004', fullName: 'Carlos Mendes', age: 58, gender: 'Masculino' },
        { id: 'PAT005', fullName: 'Paulo Silva', age: 36, gender: 'Masculino' },
        { id: 'PAT006', fullName: 'Marta Alvez', age: 42, gender: 'Feminino' },
        { id: 'PAT007', fullName: 'Roberto Martins', age: 29, gender: 'Masculino' }
      ];
      
      setPatients(mockPatients);
    }, 800);
  };

  const filterAndSortPrescriptions = () => {
    if (!prescriptions.length) return;
    
    let filtered = [...prescriptions];
    
    if (activeTab === 'active') {
      filtered = filtered.filter(p => p.status === 'active');
    } else if (activeTab === 'expiring') {
      filtered = filtered.filter(p => p.status === 'expiring');
    } else if (activeTab === 'expired') {
      filtered = filtered.filter(p => p.status === 'expired');
    }
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        p => p.patientName.toLowerCase().includes(query) || 
             p.id.toLowerCase().includes(query) ||
             p.diagnosis.toLowerCase().includes(query)
      );
    }
    
    if (filters.status !== 'all') {
      filtered = filtered.filter(p => p.status === filters.status);
    }
    
    if (filters.dateFrom) {
      const fromDate = new Date(filters.dateFrom);
      filtered = filtered.filter(p => new Date(p.date) >= fromDate);
    }
    
    if (filters.dateTo) {
      const toDate = new Date(filters.dateTo);
      toDate.setHours(23, 59, 59);
      filtered = filtered.filter(p => new Date(p.date) <= toDate);
    }
    
    if (filters.product !== 'all') {
      filtered = filtered.filter(p => 
        p.products.some(prod => prod.name.includes(filters.product))
      );
    }
    
    filtered.sort((a, b) => {
      const aValue = a[sortOrder.field];
      const bValue = b[sortOrder.field];
      
      if (!aValue && !bValue) return 0;
      if (!aValue) return 1;
      if (!bValue) return -1;
      
      const compareResult = 
        typeof aValue === 'string'
          ? aValue.localeCompare(bValue)
          : aValue - bValue;
      
      return sortOrder.direction === 'asc' ? compareResult : -compareResult;
    });
    
    setFilteredPrescriptions(filtered);
  };

  const handleCreatePrescription = () => {
    if (!newPrescription.patientId) {
      // toast notification would go here
      return;
    }
    
    if (!newPrescription.products[0].name || !newPrescription.products[0].dosage || !newPrescription.products[0].frequency) {
      // toast notification would go here
      return;
    }
    
    const today = new Date();
    const expiryDate = new Date(today);
    expiryDate.setDate(today.getDate() + newPrescription.validityDays);
    
    const patient = patients.find(p => p.id === newPrescription.patientId);
    
    const newPrescriptionObj = {
      id: `PR${String(prescriptions.length + 1).padStart(3, '0')}`,
      patientId: newPrescription.patientId,
      patientName: patient.fullName,
      date: today.toISOString().split('T')[0],
      status: 'active',
      expiryDate: expiryDate.toISOString().split('T')[0],
      products: newPrescription.products.filter(p => p.name),
      diagnosis: newPrescription.diagnosis,
      notes: newPrescription.notes,
      doctor: 'Dr. João Silva',
      created: new Date().toISOString()
    };
    
    setPrescriptions([newPrescriptionObj, ...prescriptions]);
    
    // Toast notification would go here
    
    setNewPrescription({
      patientId: '',
      products: [{ name: '', dosage: '', frequency: '', duration: '30 dias', instructions: '' }],
      diagnosis: '',
      notes: '',
      validityDays: 90
    });
    
    setShowNewPrescriptionDialog(false);
  };

  const handleViewPrescription = (prescription) => {
    setSelectedPrescription(prescription);
    setShowViewDialog(true);
  };

  const handleRenewPrescription = (prescription) => {
    setSelectedPrescription(prescription);
    setNewPrescription({
      patientId: prescription.patientId,
      products: prescription.products,
      diagnosis: prescription.diagnosis,
      notes: `Renovação da prescrição ${prescription.id}. ${prescription.notes}`,
      validityDays: 90
    });
    setShowRenewDialog(true);
  };

  const handleAddProduct = () => {
    setNewPrescription({
      ...newPrescription,
      products: [...newPrescription.products, { name: '', dosage: '', frequency: '', duration: '30 dias', instructions: '' }]
    });
  };

  const handleRemoveProduct = (index) => {
    if (newPrescription.products.length === 1) return;
    
    const updatedProducts = [...newPrescription.products];
    updatedProducts.splice(index, 1);
    
    setNewPrescription({
      ...newPrescription,
      products: updatedProducts
    });
  };

  const handleProductChange = (index, field, value) => {
    const updatedProducts = [...newPrescription.products];
    updatedProducts[index] = {
      ...updatedProducts[index],
      [field]: value
    };
    
    setNewPrescription({
      ...newPrescription,
      products: updatedProducts
    });
  };

  const handleSort = (field) => {
    setSortOrder(prev => ({
      field,
      direction: prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const resetFilters = () => {
    setFilters({
      status: 'all',
      dateFrom: '',
      dateTo: '',
      product: 'all'
    });
    setSearchQuery('');
  };
  
  const getStatusBadge = (status) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Ativa</Badge>;
      case 'expiring':
        return <Badge className="bg-yellow-100 text-yellow-800">Expirando</Badge>;
      case 'expired':
        return <Badge className="bg-red-100 text-red-800">Expirada</Badge>;
      default:
        return <Badge variant="outline">Desconhecido</Badge>;
    }
  };

  const getExpiryDaysLeft = (expiryDateStr) => {
    const today = new Date();
    const expiryDate = new Date(expiryDateStr);
    const diffTime = expiryDate - today;
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const getRemainingDaysText = (daysLeft) => {
    if (daysLeft < 0) return "Expirada";
    if (daysLeft === 0) return "Expira hoje";
    return `${daysLeft} dias restantes`;
  };

  const getPagedPrescriptions = () => {
    const startIndex = (currentPage - 1) * prescriptionsPerPage;
    return filteredPrescriptions.slice(startIndex, startIndex + prescriptionsPerPage);
  };

  const pageCount = Math.ceil(filteredPrescriptions.length / prescriptionsPerPage);

  const CustomPagination = ({ currentPage, pageCount, onPageChange }) => {
    if (pageCount <= 1) return null;
    
    const getPageNumbers = () => {
      const pages = [];
      const maxVisiblePages = 5;
      
      if (pageCount <= maxVisiblePages) {
        for (let i = 1; i <= pageCount; i++) {
          pages.push(i);
        }
      } else {
        pages.push(1);
        
        const startPage = Math.max(2, currentPage - 1);
        const endPage = Math.min(pageCount - 1, currentPage + 1);
        
        if (startPage > 2) {
          pages.push('...');
        }
        
        for (let i = startPage; i <= endPage; i++) {
          pages.push(i);
        }
        
        if (endPage < pageCount - 1) {
          pages.push('...');
        }
        
        pages.push(pageCount);
      }
      
      return pages;
    };
    
    return (
      <div className="flex items-center justify-center space-x-2 py-4">
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        
        {getPageNumbers().map((page, index) => (
          page === '...' ? (
            <span key={`ellipsis-${index}`} className="px-2">...</span>
          ) : (
            <Button
              key={page}
              variant={currentPage === page ? "default" : "outline"}
              size="sm"
              onClick={() => onPageChange(page)}
            >
              {page}
            </Button>
          )
        ))}
        
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === pageCount}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    );
  };

  const uniqueProducts = ['all', ...new Set(prescriptions.flatMap(p => p.products.map(prod => prod.name)))];

  return (
    <DoctorLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Prescrições</h1>
            <p className="text-gray-500">Gerencie prescrições de medicamentos</p>
          </div>
          <Button 
            className="gap-2 bg-pink-600 hover:bg-pink-700"
            onClick={() => setShowNewPrescriptionDialog(true)}
          >
            <Plus className="w-4 h-4" />
            Nova Prescrição
          </Button>
        </div>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div className="relative flex-1 md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <Input 
              className="pl-10" 
              placeholder="Buscar prescrições..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button 
            variant="outline"
            className="flex items-center gap-1"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter size={16} />
            <span className="hidden md:inline">Filtros</span>
          </Button>
        </div>

        {showFilters && (
          <Card className="mb-6 bg-white">
            <CardContent className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    value={filters.status} 
                    onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="active">Ativas</SelectItem>
                      <SelectItem value="expiring">Expirando</SelectItem>
                      <SelectItem value="expired">Expiradas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="product">Produto</Label>
                  <Select 
                    value={filters.product} 
                    onValueChange={(value) => setFilters(prev => ({ ...prev, product: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      {uniqueProducts.map((product) => (
                        <SelectItem key={product} value={product}>
                          {product === 'all' ? 'Todos' : product}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="dateFrom">Data Inicial</Label>
                  <Input 
                    id="dateFrom"
                    type="date" 
                    value={filters.dateFrom}
                    onChange={handleFilterChange}
                    name="dateFrom"
                  />
                </div>
                
                <div>
                  <Label htmlFor="dateTo">Data Final</Label>
                  <Input 
                    id="dateTo"
                    type="date" 
                    value={filters.dateTo}
                    onChange={handleFilterChange}
                    name="dateTo"
                  />
                </div>
              </div>
              
              <div className="flex justify-end mt-6">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={resetFilters}
                  className="mr-2"
                >
                  Limpar Filtros
                </Button>
                <Button 
                  size="sm"
                  onClick={() => setShowFilters(false)}
                >
                  Aplicar
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="mb-6"
        >
          <TabsList>
            <TabsTrigger value="all">Todas</TabsTrigger>
            <TabsTrigger value="active">Ativas</TabsTrigger>
            <TabsTrigger value="expiring">Expirando</TabsTrigger>
            <TabsTrigger value="expired">Expiradas</TabsTrigger>
          </TabsList>
        </Tabs>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center p-8">
            <Spinner className="text-pink-600 mb-4" />
            <p className="text-gray-500">Carregando prescrições...</p>
          </div>
        ) : filteredPrescriptions.length === 0 ? (
          <Card className="bg-white">
            <CardContent className="flex flex-col items-center justify-center p-8">
              <FileText size={48} className="text-gray-300 mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhuma prescrição encontrada</h3>
              <p className="text-gray-500 text-center max-w-md">
                {searchQuery || filters.status !== 'all' || filters.product !== 'all' || filters.dateFrom || filters.dateTo
                  ? "Nenhuma prescrição corresponde aos filtros aplicados. Tente modificar sua busca."
                  : "Você ainda não tem prescrições cadastradas. Clique em 'Nova Prescrição' para começar."}
              </p>
              {(searchQuery || filters.status !== 'all' || filters.product !== 'all' || filters.dateFrom || filters.dateTo) && (
                <Button
                  variant="outline"
                  onClick={resetFilters}
                  className="mt-4"
                >
                  Limpar Filtros
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <>
            <Card className="bg-white">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">ID</TableHead>
                    <TableHead>Paciente</TableHead>
                    <TableHead>Produtos</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Validade</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {getPagedPrescriptions().map((prescription) => {
                    const daysLeft = getExpiryDaysLeft(prescription.expiryDate);
                    const daysLeftText = getRemainingDaysText(daysLeft);
                    
                    return (
                      <TableRow key={prescription.id}>
                        <TableCell className="font-medium">{prescription.id}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="bg-pink-100 text-pink-600">
                                {prescription.patientName.split(' ').map(name => name[0]).join('').slice(0, 2)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{prescription.patientName}</div>
                              <div className="text-sm text-gray-500">{prescription.diagnosis}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {prescription.products.map((product, index) => (
                              <Badge key={index} variant="outline" className="bg-blue-50 text-blue-800">
                                {product.name}
                              </Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(prescription.status)}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-1">
                            <span className="text-sm">
                              {new Date(prescription.expiryDate).toLocaleDateString('pt-BR')}
                            </span>
                            <span className={`text-xs ${
                              daysLeft < 0 
                                ? 'text-red-600' 
                                : daysLeft <= 15 
                                  ? 'text-yellow-600' 
                                  : 'text-green-600'
                            }`}>
                              {daysLeftText}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end items-center space-x-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-pink-600 hover:text-pink-800 hover:bg-pink-50"
                              onClick={() => handleViewPrescription(prescription)}
                            >
                              <Eye size={18} />
                            </Button>
                            
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal size={18} />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() => handleViewPrescription(prescription)}
                                >
                                  <Eye size={16} className="mr-2" />
                                  Visualizar
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => {}}>
                                  <Download size={16} className="mr-2" />
                                  Baixar PDF
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => {}}>
                                  <Printer size={16} className="mr-2" />
                                  Imprimir
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => {}}>
                                  <Share2 size={16} className="mr-2" />
                                  Compartilhar
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => handleRenewPrescription(prescription)}
                                  disabled={prescription.status === 'active'}
                                >
                                  <ClipboardCheck size={16} className="mr-2" />
                                  Renovar
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => {}}>
                                  <Pencil size={16} className="mr-2" />
                                  Editar
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem 
                                  className="text-red-600"
                                  onClick={() => {}}
                                >
                                  <Ban size={16} className="mr-2" />
                                  Cancelar
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </Card>

            <CustomPagination
              currentPage={currentPage}
              pageCount={pageCount}
              onPageChange={setCurrentPage}
            />
          </>
        )}

        <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
          <DialogContent className="sm:max-w-3xl max-h-[90vh]">
            {selectedPrescription && (
              <ScrollArea className="max-h-[calc(90vh-80px)]">
                <DialogHeader className="flex flex-row items-center justify-between">
                  <div>
                    <DialogTitle className="text-xl">Prescrição #{selectedPrescription.id}</DialogTitle>
                    <DialogDescription>
                      Emitida em {new Date(selectedPrescription.date).toLocaleDateString('pt-BR')}
                    </DialogDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="text-pink-600 border-pink-200 hover:bg-pink-50"
                      onClick={() => {}}
                    >
                      <Download size={16} className="mr-2" />
                      PDF
                    </Button>
                  </div>
                </DialogHeader>
                
                <div className="mt-6 space-y-6">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          {getStatusBadge(selectedPrescription.status)}
                          <div>
                            <p className="text-sm font-medium">Validade</p>
                            <p className="text-sm text-gray-500">
                              Até {new Date(selectedPrescription.expiryDate).toLocaleDateString('pt-BR')}
                            </p>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <p className="text-sm font-medium">Médico Responsável</p>
                          <p className="text-sm text-gray-500">{selectedPrescription.doctor}</p>
                        </div>
                      </div>
                      
                      {selectedPrescription.status === 'expiring' && (
                        <div className="mt-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200 flex items-center gap-2 text-yellow-800">
                          <AlertTriangle size={16} />
                          <span className="text-sm">
                            Esta prescrição expira em breve. Considere agendar uma consulta de renovação.
                          </span>
                        </div>
                      )}
                      
                      {selectedPrescription.status === 'expired' && (
                        <div className="mt-4 p-3 bg-red-50 rounded-lg border border-red-200 flex items-center gap-2 text-red-800">
                          <AlertTriangle size={16} />
                          <span className="text-sm">
                            Esta prescrição está expirada. É necessário emitir uma nova prescrição.
                          </span>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Dados do Paciente</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-4">
                        <Avatar className="h-12 w-12">
                          <AvatarFallback className="bg-pink-100 text-pink-600">
                            {selectedPrescription.patientName.split(' ').map(name => name[0]).join('').slice(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium">{selectedPrescription.patientName}</h4>
                          <p className="text-sm text-gray-500">{selectedPrescription.diagnosis}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Produtos Prescritos</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {selectedPrescription.products.map((product, index) => (
                          <div key={index} className="p-4 border rounded-lg">
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="font-medium">{product.name}</h4>
                              <Badge variant="outline" className="bg-blue-50 text-blue-800">
                                {product.duration}
                              </Badge>
                            </div>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <p className="text-gray-500">Dosagem</p>
                                <p>{product.dosage}</p>
                              </div>
                              <div>
                                <p className="text-gray-500">Frequência</p>
                                <p>{product.frequency}</p>
                              </div>
                            </div>
                            {product.instructions && (
                              <div className="mt-3 text-sm">
                                <p className="text-gray-500">Instruções Específicas</p>
                                <p>{product.instructions}</p>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                  
                  {selectedPrescription.notes && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base">Observações</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-700">{selectedPrescription.notes}</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </ScrollArea>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DoctorLayout>
  );
}