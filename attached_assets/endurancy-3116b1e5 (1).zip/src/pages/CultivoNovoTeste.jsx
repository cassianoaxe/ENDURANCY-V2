
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Beaker, 
  ArrowLeft, 
  Upload, 
  UploadCloud, 
  Save, 
  Plus, 
  Trash2, 
  Calendar, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  Download 
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { UploadFile } from "@/api/integrations";
import { toast } from "@/components/ui/use-toast";

// Dados simulados para lotes
const mockBatches = [
  { id: "l2023-001", name: "Lote CBD Therapy 001", strain: "CBD Therapy", type: "Óleo CBD 5%" },
  { id: "l2023-002", name: "Lote Harlequin 002", strain: "Harlequin", type: "Flor seca" },
  { id: "l2023-003", name: "Lote Charlotte's Web 003", strain: "Charlotte's Web", type: "Extrato Full Spectrum" }
];

// Tipos de testes disponíveis
const testTypes = [
  { id: "potencia", name: "Potência (Canabinoides)", description: "Análise do perfil e concentração de canabinoides" },
  { id: "terpenos", name: "Perfil de Terpenos", description: "Análise qualitativa e quantitativa de terpenos" },
  { id: "pesticidas", name: "Pesticidas", description: "Análise de resíduos de pesticidas" },
  { id: "metais", name: "Metais Pesados", description: "Análise de metais pesados (Pb, Hg, As, Cd)" },
  { id: "solventes", name: "Solventes Residuais", description: "Análise de solventes residuais" },
  { id: "microbiologico", name: "Microbiológico", description: "Análise microbiológica (fungos, bactérias)" },
  { id: "umidade", name: "Umidade", description: "Análise do teor de umidade" },
  { id: "completo", name: "Teste Completo", description: "Inclui todos os testes acima" }
];

// Laboratórios parceiros
const laboratories = [
  { id: "lab001", name: "CannabLab Análises", location: "São Paulo/SP" },
  { id: "lab002", name: "Phytolab Análises", location: "Rio de Janeiro/RJ" },
  { id: "lab003", name: "GreenAnalytics", location: "Curitiba/PR" }
];

export default function CultivoNovoTeste() {
  const navigate = useNavigate();
  
  const [testData, setTestData] = useState({
    batch_id: "",
    test_id: `TE-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 1000)).padStart(3, '0')}`,
    lab_id: "",
    sample_id: "",
    sample_date: new Date().toISOString().split('T')[0],
    test_date: "",
    report_date: "",
    selected_tests: [],
    overall_pass: null,
    failure_reasons: "",
    notes: ""
  });
  
  const [uploadedDocs, setUploadedDocs] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedBatch, setSelectedBatch] = useState(null);
  
  useEffect(() => {
    // No efeito real, carregaríamos os lotes disponíveis da API
  }, []);
  
  const handleBatchChange = (batchId) => {
    setTestData({...testData, batch_id: batchId});
    const batch = mockBatches.find(b => b.id === batchId);
    setSelectedBatch(batch);
  };
  
  const handleTestTypeToggle = (testId) => {
    const currentTests = [...testData.selected_tests];
    
    if (testId === "completo") {
      if (currentTests.includes("completo")) {
        setTestData({...testData, selected_tests: []});
      } else {
        setTestData({...testData, selected_tests: ["completo"]});
      }
      return;
    }
    
    // Se "completo" já está selecionado, removemos
    if (currentTests.includes("completo")) {
      const newTests = currentTests.filter(t => t !== "completo");
      if (currentTests.includes(testId)) {
        setTestData({...testData, selected_tests: newTests.filter(t => t !== testId)});
      } else {
        setTestData({...testData, selected_tests: [...newTests, testId]});
      }
    } else {
      if (currentTests.includes(testId)) {
        setTestData({...testData, selected_tests: currentTests.filter(t => t !== testId)});
      } else {
        setTestData({...testData, selected_tests: [...currentTests, testId]});
      }
    }
  };
  
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    setIsUploading(true);
    
    try {
      const result = await UploadFile({ file });
      
      const newDoc = {
        id: `doc-${Date.now()}`,
        name: file.name,
        type: file.type,
        size: file.size,
        url: result.file_url,
        uploadedAt: new Date().toISOString()
      };
      
      setUploadedDocs([...uploadedDocs, newDoc]);
      
      toast({
        title: "Documento enviado com sucesso",
        description: `O arquivo "${file.name}" foi carregado.`,
      });
    } catch (error) {
      console.error("Erro ao fazer upload:", error);
      toast({
        title: "Erro ao fazer upload",
        description: "Não foi possível carregar o arquivo. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  const removeDocument = (docId) => {
    setUploadedDocs(uploadedDocs.filter(doc => doc.id !== docId));
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!testData.batch_id) {
      toast({
        title: "Selecione um lote",
        description: "É necessário selecionar um lote para registrar o teste.",
        variant: "destructive",
      });
      return;
    }
    
    if (testData.selected_tests.length === 0) {
      toast({
        title: "Selecione pelo menos um tipo de teste",
        description: "É necessário selecionar pelo menos um tipo de teste a ser realizado.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Em um ambiente real, enviaríamos dados para API
      // Simulamos um atraso de rede
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Teste registrado com sucesso",
        description: `O teste ${testData.test_id} foi registrado para o lote ${selectedBatch?.name}.`,
      });
      
      // Voltar para a lista de testes
      navigate(createPageUrl("CultivoTestes"));
    } catch (error) {
      console.error("Erro ao submeter teste:", error);
      toast({
        title: "Erro ao registrar teste",
        description: "Ocorreu um erro ao registrar o teste. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' bytes';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" asChild>
            <Link to={createPageUrl("CultivoTestes")}>
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">Novo Teste Laboratorial</h1>
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Beaker className="h-5 w-5 text-green-600" />
              Informações Básicas
            </CardTitle>
            <CardDescription>
              Informações gerais sobre o teste a ser realizado
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="test_id">ID do Teste</Label>
                <Input 
                  id="test_id" 
                  value={testData.test_id} 
                  onChange={(e) => setTestData({...testData, test_id: e.target.value})}
                  disabled
                />
                <p className="text-sm text-gray-500">ID gerado automaticamente</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="batch_id">Lote</Label>
                <Select 
                  value={testData.batch_id}
                  onValueChange={handleBatchChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um lote" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockBatches.map(batch => (
                      <SelectItem key={batch.id} value={batch.id}>
                        {batch.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {selectedBatch && (
                  <div className="mt-2 p-2 bg-gray-50 rounded-md">
                    <p className="text-sm"><span className="font-medium">Strain:</span> {selectedBatch.strain}</p>
                    <p className="text-sm"><span className="font-medium">Tipo:</span> {selectedBatch.type}</p>
                  </div>
                )}
              </div>
            </div>
            
            <Separator />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="lab_id">Laboratório</Label>
                <Select 
                  value={testData.lab_id}
                  onValueChange={(value) => setTestData({...testData, lab_id: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um laboratório" />
                  </SelectTrigger>
                  <SelectContent>
                    {laboratories.map(lab => (
                      <SelectItem key={lab.id} value={lab.id}>
                        {lab.name} ({lab.location})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="sample_id">ID da Amostra</Label>
                <Input 
                  id="sample_id" 
                  placeholder="Ex: AM-2023-001" 
                  value={testData.sample_id} 
                  onChange={(e) => setTestData({...testData, sample_id: e.target.value})}
                />
                <p className="text-sm text-gray-500">Identificador fornecido pelo laboratório</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="sample_date">Data da Amostragem</Label>
                <Input 
                  id="sample_date" 
                  type="date" 
                  value={testData.sample_date} 
                  onChange={(e) => setTestData({...testData, sample_date: e.target.value})}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="test_date">Data do Teste</Label>
                <Input 
                  id="test_date" 
                  type="date" 
                  value={testData.test_date} 
                  onChange={(e) => setTestData({...testData, test_date: e.target.value})}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="report_date">Data do Relatório</Label>
                <Input 
                  id="report_date" 
                  type="date" 
                  value={testData.report_date} 
                  onChange={(e) => setTestData({...testData, report_date: e.target.value})}
                />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-green-600" />
              Tipos de Testes
            </CardTitle>
            <CardDescription>
              Selecione os tipos de testes que serão realizados
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {testTypes.map(test => (
                <div 
                  key={test.id} 
                  className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                    (testData.selected_tests.includes(test.id) || 
                     (test.id !== "completo" && testData.selected_tests.includes("completo"))) 
                     ? 'bg-green-50 border-green-200' 
                     : 'hover:bg-gray-50'
                  }`}
                  onClick={() => handleTestTypeToggle(test.id)}
                >
                  <div className="flex items-start gap-2">
                    <Switch 
                      checked={
                        testData.selected_tests.includes(test.id) || 
                        (test.id !== "completo" && testData.selected_tests.includes("completo"))
                      }
                      onCheckedChange={() => handleTestTypeToggle(test.id)}
                    />
                    <div>
                      <p className="font-medium">{test.name}</p>
                      <p className="text-sm text-gray-500">{test.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-4">
              <p className="text-sm text-gray-500">
                <strong>Nota:</strong> A opção "Teste Completo" inclui automaticamente todos os outros testes.
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UploadCloud className="h-5 w-5 text-green-600" />
              Documentos e Resultados
            </CardTitle>
            <CardDescription>
              Faça upload do relatório de testes e outros documentos relevantes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="file-upload">Upload de Documentos</Label>
              <div className="mt-2 flex items-center gap-4">
                <Input 
                  id="file-upload" 
                  type="file" 
                  className="w-full max-w-lg"
                  onChange={handleFileUpload}
                  disabled={isUploading}
                />
                
                {isUploading && (
                  <div className="animate-spin w-5 h-5 border-t-2 border-b-2 border-green-600 rounded-full"></div>
                )}
              </div>
              
              <p className="text-sm text-gray-500 mt-2">
                Aceita PDF, Word, Excel, JPG, PNG (Max 10MB)
              </p>
            </div>
            
            {uploadedDocs.length > 0 && (
              <div className="space-y-3 mt-4">
                <h3 className="text-sm font-medium">Documentos enviados</h3>
                <div className="space-y-2">
                  {uploadedDocs.map(doc => (
                    <div 
                      key={doc.id} 
                      className="flex items-center justify-between p-3 border rounded-md"
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="font-medium text-sm">{doc.name}</p>
                          <p className="text-xs text-gray-500">
                            {formatFileSize(doc.size)} • {new Date(doc.uploadedAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon"
                          asChild
                        >
                          <a href={doc.url} target="_blank" rel="noopener noreferrer">
                            <Download className="h-4 w-4" />
                          </a>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => removeDocument(doc.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <Separator />
            
            <div className="space-y-3">
              <div className="space-y-2">
                <Label>Resultado Final</Label>
                <div className="flex gap-4">
                  <div className="flex items-center gap-2">
                    <input 
                      type="radio" 
                      id="result-pass" 
                      name="overall_result" 
                      checked={testData.overall_pass === true}
                      onChange={() => setTestData({...testData, overall_pass: true})}
                      className="w-4 h-4 text-green-600"
                    />
                    <Label htmlFor="result-pass" className="flex items-center gap-1 cursor-pointer">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                      Aprovado
                    </Label>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <input 
                      type="radio" 
                      id="result-fail" 
                      name="overall_result" 
                      checked={testData.overall_pass === false}
                      onChange={() => setTestData({...testData, overall_pass: false})}
                      className="w-4 h-4 text-red-600"
                    />
                    <Label htmlFor="result-fail" className="flex items-center gap-1 cursor-pointer">
                      <XCircle className="h-4 w-4 text-red-600" />
                      Reprovado
                    </Label>
                  </div>
                </div>
              </div>
              
              {testData.overall_pass === false && (
                <div className="space-y-2">
                  <Label htmlFor="failure_reasons">Motivos da Reprovação</Label>
                  <Textarea 
                    id="failure_reasons" 
                    placeholder="Descreva os motivos da reprovação..." 
                    value={testData.failure_reasons}
                    onChange={(e) => setTestData({...testData, failure_reasons: e.target.value})}
                  />
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="notes">Observações</Label>
                <Textarea 
                  id="notes" 
                  placeholder="Observações adicionais sobre o teste..." 
                  value={testData.notes}
                  onChange={(e) => setTestData({...testData, notes: e.target.value})}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" type="button" asChild>
              <Link to={createPageUrl("CultivoTestes")}>Cancelar</Link>
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-b-transparent"></div>
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Salvar Teste
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  );
}
