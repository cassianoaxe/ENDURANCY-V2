import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Tag,
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Calendar,
  Percent,
  ArrowUp,
  ArrowDown,
  Clock,
  Check,
  X,
  Edit,
  Trash,
  Copy,
  DollarSign,
  Eye,
  Package,
  Users,
  BarChart4,
  AlertTriangle,
  RefreshCw,
  Gift
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

// Dados simulados para promoções
const mockPromotions = [
  {
    id: "1",
    name: "Desconto Primavera",
    code: "PRIMAVERA2023",
    type: "percentage",
    value: 15,
    min_purchase: 200,
    start_date: "2023-09-21T00:00:00",
    end_date: "2023-12-20T23:59:59",
    status: "active",
    usage_limit: 500,
    usage_count: 328,
    products: [], // todos os produtos
    description: "Desconto de 15% em todos os produtos para a primavera",
    created_date: "2023-09-10T15:30:00",
    user_limit: 1,
    target_audience: "all"
  },
  {
    id: "2",
    name: "Frete Grátis",
    code: "FRETEFREE",
    type: "shipping",
    value: 100,
    min_purchase: 300,
    start_date: "2023-10-01T00:00:00",
    end_date: "2023-11-30T23:59:59",
    status: "active",
    usage_limit: 200,
    usage_count: 87,
    products: [], // todos os produtos
    description: "Frete grátis para compras acima de R$ 300",
    created_date: "2023-09-15T10:45:00",
    user_limit: 1,
    target_audience: "all"
  },
  {
    id: "3",
    name: "Desconto CBD 30%",
    code: "CBD30",
    type: "percentage",
    value: 30,
    min_purchase: 0,
    start_date: "2023-10-15T00:00:00",
    end_date: "2023-10-31T23:59:59",
    status: "expired",
    usage_limit: 100,
    usage_count: 100,
    products: ["Óleo CBD 10%", "Óleo CBD 20%", "Cápsulas CBD"],
    description: "30% de desconto em produtos selecionados de CBD",
    created_date: "2023-10-01T16:20:00",
    user_limit: 1,
    target_audience: "customers"
  },
  {
    id: "4",
    name: "Desconto Primeira Compra",
    code: "WELCOME10",
    type: "percentage",
    value: 10,
    min_purchase: 100,
    start_date: "2023-01-01T00:00:00",
    end_date: "2023-12-31T23:59:59",
    status: "active",
    usage_limit: null,
    usage_count: 412,
    products: [], // todos os produtos
    description: "10% de desconto para primeira compra",
    created_date: "2023-01-01T08:00:00",
    user_limit: 1,
    target_audience: "new_customers"
  },
  {
    id: "5",
    name: "Black Friday 40%",
    code: "BLACK40",
    type: "percentage",
    value: 40,
    min_purchase: 400,
    start_date: "2023-11-24T00:00:00",
    end_date: "2023-11-26T23:59:59",
    status: "scheduled",
    usage_limit: 300,
    usage_count: 0,
    products: [], // todos os produtos
    description: "Mega desconto de Black Friday",
    created_date: "2023-10-10T11:30:00",
    user_limit: 1,
    target_audience: "all"
  },
  {
    id: "6",
    name: "Cupom R$50 Off",
    code: "MENOS50",
    type: "fixed",
    value: 50,
    min_purchase: 250,
    start_date: "2023-10-01T00:00:00",
    end_date: "2023-12-31T23:59:59",
    status: "active",
    usage_limit: 150,
    usage_count: 42,
    products: [], // todos os produtos
    description: "Desconto fixo de R$50 em compras acima de R$250",
    created_date: "2023-09-25T09:15:00",
    user_limit: 1,
    target_audience: "all"
  }
];

// Dados simulados para estatísticas de uso
const mockUsageStats = [
  { month: 'Jan', redemptions: 20, total_discount: 1800 },
  { month: 'Fev', redemptions: 35, total_discount: 3200 },
  { month: 'Mar', redemptions: 42, total_discount: 3800 },
  { month: 'Abr', redemptions: 38, total_discount: 3400 },
  { month: 'Mai', redemptions: 45, total_discount: 4100 },
  { month: 'Jun', redemptions: 50, total_discount: 4500 },
  { month: 'Jul', redemptions: 62, total_discount: 5600 },
  { month: 'Ago', redemptions: 68, total_discount: 6100 },
  { month: 'Set', redemptions: 75, total_discount: 6800 },
  { month: 'Out', redemptions: 80, total_discount: 7200 },
  { month: 'Nov', redemptions: 0, total_discount: 0 },
  { month: 'Dez', redemptions: 0, total_discount: 0 }
];

// Lista de produtos para seleção em promoções
const mockProducts = [
  { id: "1", name: "Óleo CBD 10%", price: 150.00, category: "Medicinal" },
  { id: "2", name: "Óleo CBD 20%", price: 250.00, category: "Medicinal" },
  { id: "3", name: "Óleo CBD 30%", price: 350.00, category: "Medicinal" },
  { id: "4", name: "Cápsulas CBD", price: 180.00, category: "Medicinal" },
  { id: "5", name: "Pomada CBD", price: 80.00, category: "Medicinal" },
  { id: "6", name: "Camiseta Associação", price: 60.00, category: "Institucional" },
  { id: "7", name: "Garrafa Térmica", price: 45.00, category: "Institucional" },
  { id: "8", name: "Livro Cannabis Medicinal", price: 70.00, category: "Literatura" }
];

export default function Promocoes() {
  const [promotions, setPromotions] = useState([]);
  const [filteredPromotions, setFilteredPromotions] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [sortField, setSortField] = useState("created_date");
  const [sortDirection, setSortDirection] = useState("desc");
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPromotion, setSelectedPromotion] = useState(null);
  const [showNewPromotionDialog, setShowNewPromotionDialog] = useState(false);
  const [showPromotionDetails, setShowPromotionDetails] = useState(false);
  const [activeTab, setActiveTab] = useState("all");

  // Estados para novo cupom
  const [newPromotion, setNewPromotion] = useState({
    name: "",
    code: "",
    type: "percentage",
    value: 0,
    min_purchase: 0,
    start_date: new Date().toISOString().split('T')[0],
    end_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: "active",
    usage_limit: null,
    products: [],
    description: "",
    user_limit: 1,
    target_audience: "all"
  });

  useEffect(() => {
    // Simulando carregamento da API
    const loadPromotions = async () => {
      setIsLoading(true);
      try {
        // Em uma implementação real, isso seria uma chamada à API
        setTimeout(() => {
          setPromotions(mockPromotions);
          setFilteredPromotions(mockPromotions);
          setIsLoading(false);
        }, 500);
      } catch (error) {
        console.error("Erro ao carregar promoções:", error);
        setIsLoading(false);
      }
    };

    loadPromotions();
  }, []);

  useEffect(() => {
    // Aplicar filtros e ordenação
    let result = [...promotions];

    // Filtrar por termo de busca
    if (searchTerm) {
      result = result.filter(promotion =>
        promotion.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        promotion.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        promotion.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filtrar por status
    if (statusFilter !== "all") {
      result = result.filter(promotion => promotion.status === statusFilter);
    }

    // Filtrar por tipo
    if (typeFilter !== "all") {
      result = result.filter(promotion => promotion.type === typeFilter);
    }

    // Filtrar por aba ativa
    if (activeTab === "active") {
      result = result.filter(promotion => promotion.status === "active");
    } else if (activeTab === "scheduled") {
      result = result.filter(promotion => promotion.status === "scheduled");
    } else if (activeTab === "expired") {
      result = result.filter(promotion => promotion.status === "expired" || promotion.status === "inactive");
    }

    // Ordenar resultados
    result.sort((a, b) => {
      let valueA = a[sortField];
      let valueB = b[sortField];

      // Converter datas para timestamp para comparação
      if (sortField.includes('date')) {
        valueA = new Date(valueA).getTime();
        valueB = new Date(valueB).getTime();
      }

      if (valueA < valueB) return sortDirection === "asc" ? -1 : 1;
      if (valueA > valueB) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });

    setFilteredPromotions(result);
  }, [promotions, searchTerm, statusFilter, typeFilter, sortField, sortDirection, activeTab]);

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const handleStatusChange = (promotionId, newStatus) => {
    const updatedPromotions = promotions.map(promotion => {
      if (promotion.id === promotionId) {
        return { ...promotion, status: newStatus };
      }
      return promotion;
    });

    setPromotions(updatedPromotions);
  };

  const handleCopy = (promotionCode) => {
    navigator.clipboard.writeText(promotionCode)
      .then(() => {
        // Mostrar notificação ou toast
        console.log(`Código ${promotionCode} copiado para a área de transferência`);
      })
      .catch(err => {
        console.error('Falha ao copiar código:', err);
      });
  };

  const handleCreatePromotion = () => {
    // Em uma implementação real, isso enviaria para a API
    const newId = (promotions.length + 1).toString();
    const createdPromo = {
      ...newPromotion,
      id: newId,
      created_date: new Date().toISOString(),
      usage_count: 0
    };

    setPromotions([...promotions, createdPromo]);
    setShowNewPromotionDialog(false);
    setNewPromotion({
      name: "",
      code: "",
      type: "percentage",
      value: 0,
      min_purchase: 0,
      start_date: new Date().toISOString().split('T')[0],
      end_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: "active",
      usage_limit: null,
      products: [],
      description: "",
      user_limit: 1,
      target_audience: "all"
    });
  };

  const formatDate = (dateString) => {
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    return new Date(dateString).toLocaleDateString('pt-BR', options);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Ativo</Badge>;
      case 'scheduled':
        return <Badge className="bg-blue-100 text-blue-800">Agendado</Badge>;
      case 'expired':
        return <Badge className="bg-red-100 text-red-800">Expirado</Badge>;
      case 'inactive':
        return <Badge className="bg-gray-100 text-gray-800">Inativo</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getTypeLabel = (type) => {
    switch (type) {
      case 'percentage':
        return 'Percentual';
      case 'fixed':
        return 'Valor Fixo';
      case 'shipping':
        return 'Frete Grátis';
      default:
        return type;
    }
  };

  const formatValue = (promotion) => {
    if (promotion.type === 'percentage') {
      return `${promotion.value}%`;
    } else if (promotion.type === 'fixed') {
      return `R$ ${promotion.value.toFixed(2)}`;
    } else if (promotion.type === 'shipping') {
      return 'Frete Grátis';
    }
    return promotion.value;
  };

  const generatePromotionCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewPromotion({...newPromotion, code});
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Promoções</h1>
          <p className="text-gray-500 mt-1">
            Gerencie promoções, descontos e cupons para seus clientes
          </p>
        </div>
        <Button 
          onClick={() => setShowNewPromotionDialog(true)}
          className="bg-green-600 hover:bg-green-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nova Promoção
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <Tabs 
              defaultValue="all" 
              value={activeTab}
              onValueChange={setActiveTab}
              className="w-full"
            >
              <TabsList className="grid grid-cols-4 sm:w-[400px]">
                <TabsTrigger value="all">Todas</TabsTrigger>
                <TabsTrigger value="active">Ativas</TabsTrigger>
                <TabsTrigger value="scheduled">Agendadas</TabsTrigger>
                <TabsTrigger value="expired">Expiradas</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar promoções..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-full sm:w-[300px]"
                />
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon">
                    <Filter className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="px-2 py-1.5 text-xs text-muted-foreground font-semibold">Filtrar por</div>
                  <DropdownMenuSeparator />
                  
                  <div className="px-2 py-1.5 text-xs text-muted-foreground font-semibold">Tipo</div>
                  <DropdownMenuItem onClick={() => setTypeFilter("all")}>
                    {typeFilter === "all" && <Check className="h-4 w-4 mr-2" />}
                    Todos
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTypeFilter("percentage")}>
                    {typeFilter === "percentage" && <Check className="h-4 w-4 mr-2" />}
                    Percentual
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTypeFilter("fixed")}>
                    {typeFilter === "fixed" && <Check className="h-4 w-4 mr-2" />}
                    Valor Fixo
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTypeFilter("shipping")}>
                    {typeFilter === "shipping" && <Check className="h-4 w-4 mr-2" />}
                    Frete Grátis
                  </DropdownMenuItem>

                  <DropdownMenuSeparator />
                  
                  <div className="px-2 py-1.5 text-xs text-muted-foreground font-semibold">Status</div>
                  <DropdownMenuItem onClick={() => setStatusFilter("all")}>
                    {statusFilter === "all" && <Check className="h-4 w-4 mr-2" />}
                    Todos
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("active")}>
                    {statusFilter === "active" && <Check className="h-4 w-4 mr-2" />}
                    Ativos
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("scheduled")}>
                    {statusFilter === "scheduled" && <Check className="h-4 w-4 mr-2" />}
                    Agendados
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("expired")}>
                    {statusFilter === "expired" && <Check className="h-4 w-4 mr-2" />}
                    Expirados
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("inactive")}>
                    {statusFilter === "inactive" && <Check className="h-4 w-4 mr-2" />}
                    Inativos
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : filteredPromotions.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Tag className="h-12 w-12 text-gray-400 mb-3" />
              <h3 className="text-lg font-medium text-gray-900">Nenhuma promoção encontrada</h3>
              <p className="text-gray-500 mt-1 max-w-md">
                {searchTerm || statusFilter !== "all" || typeFilter !== "all" 
                  ? "Nenhuma promoção corresponde aos filtros aplicados. Tente ajustar seus critérios de busca." 
                  : "Você ainda não tem nenhuma promoção cadastrada. Clique em 'Nova Promoção' para começar."}
              </p>
              {searchTerm || statusFilter !== "all" || typeFilter !== "all" ? (
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => {
                    setSearchTerm("");
                    setStatusFilter("all");
                    setTypeFilter("all");
                  }}
                >
                  Limpar filtros
                </Button>
              ) : null}
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[250px]">
                      <Button 
                        variant="ghost" 
                        className="flex items-center gap-1 px-0 font-medium"
                        onClick={() => handleSort("name")}
                      >
                        Nome
                        {sortField === "name" && (
                          sortDirection === "asc" ? 
                            <ArrowUp className="h-4 w-4" /> : 
                            <ArrowDown className="h-4 w-4" />
                        )}
                      </Button>
                    </TableHead>
                    <TableHead className="w-[150px]">Código</TableHead>
                    <TableHead className="w-[120px]">
                      <Button 
                        variant="ghost" 
                        className="flex items-center gap-1 px-0 font-medium"
                        onClick={() => handleSort("type")}
                      >
                        Tipo
                        {sortField === "type" && (
                          sortDirection === "asc" ? 
                            <ArrowUp className="h-4 w-4" /> : 
                            <ArrowDown className="h-4 w-4" />
                        )}
                      </Button>
                    </TableHead>
                    <TableHead className="w-[100px]">Valor</TableHead>
                    <TableHead className="w-[120px]">
                      <Button 
                        variant="ghost" 
                        className="flex items-center gap-1 px-0 font-medium"
                        onClick={() => handleSort("start_date")}
                      >
                        Início
                        {sortField === "start_date" && (
                          sortDirection === "asc" ? 
                            <ArrowUp className="h-4 w-4" /> : 
                            <ArrowDown className="h-4 w-4" />
                        )}
                      </Button>
                    </TableHead>
                    <TableHead className="w-[120px]">
                      <Button 
                        variant="ghost" 
                        className="flex items-center gap-1 px-0 font-medium"
                        onClick={() => handleSort("end_date")}
                      >
                        Término
                        {sortField === "end_date" && (
                          sortDirection === "asc" ? 
                            <ArrowUp className="h-4 w-4" /> : 
                            <ArrowDown className="h-4 w-4" />
                        )}
                      </Button>
                    </TableHead>
                    <TableHead className="w-[120px]">Status</TableHead>
                    <TableHead className="w-[120px]">Usos</TableHead>
                    <TableHead className="w-[100px]">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPromotions.map((promotion) => (
                    <TableRow key={promotion.id}>
                      <TableCell className="font-medium">{promotion.name}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <code className="bg-gray-100 px-2 py-1 rounded text-sm">{promotion.code}</code>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => handleCopy(promotion.code)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell>{getTypeLabel(promotion.type)}</TableCell>
                      <TableCell>{formatValue(promotion)}</TableCell>
                      <TableCell>{formatDate(promotion.start_date)}</TableCell>
                      <TableCell>{formatDate(promotion.end_date)}</TableCell>
                      <TableCell>{getStatusBadge(promotion.status)}</TableCell>
                      <TableCell>
                        {promotion.usage_count} / {promotion.usage_limit ? promotion.usage_limit : '∞'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => {
                              setSelectedPromotion(promotion);
                              setShowPromotionDetails(true);
                            }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem 
                                onClick={() => {
                                  setSelectedPromotion(promotion);
                                  setShowPromotionDetails(true);
                                }}
                              >
                                <Eye className="h-4 w-4 mr-2" />
                                Ver detalhes
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Edit className="h-4 w-4 mr-2" />
                                Editar
                              </DropdownMenuItem>
                              {promotion.status === "active" ? (
                                <DropdownMenuItem onClick={() => handleStatusChange(promotion.id, "inactive")}>
                                  <X className="h-4 w-4 mr-2" />
                                  Desativar
                                </DropdownMenuItem>
                              ) : promotion.status === "inactive" || promotion.status === "scheduled" ? (
                                <DropdownMenuItem onClick={() => handleStatusChange(promotion.id, "active")}>
                                  <Check className="h-4 w-4 mr-2" />
                                  Ativar
                                </DropdownMenuItem>
                              ) : null}
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-red-600">
                                <Trash className="h-4 w-4 mr-2" />
                                Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de criação de nova promoção */}
      <Dialog open={showNewPromotionDialog} onOpenChange={setShowNewPromotionDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Nova Promoção</DialogTitle>
            <DialogDescription>
              Crie uma nova promoção ou cupom de desconto para seus clientes.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label htmlFor="name" className="text-right">
                  Nome da Promoção
                </Label>
                <Input
                  id="name"
                  value={newPromotion.name}
                  onChange={(e) => setNewPromotion({...newPromotion, name: e.target.value})}
                  placeholder="Ex: Desconto de Black Friday"
                  className="col-span-3"
                />
              </div>
              
              <div className="relative">
                <Label htmlFor="code" className="text-right">
                  Código do Cupom
                </Label>
                <div className="flex">
                  <Input
                    id="code"
                    value={newPromotion.code}
                    onChange={(e) => setNewPromotion({...newPromotion, code: e.target.value.toUpperCase()})}
                    placeholder="Ex: BLACKFRIDAY"
                    className="uppercase"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="ml-2"
                    onClick={generatePromotionCode}
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div>
                <Label htmlFor="type" className="text-right">
                  Tipo de Desconto
                </Label>
                <Select
                  value={newPromotion.type}
                  onValueChange={(value) => setNewPromotion({...newPromotion, type: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentual (%)</SelectItem>
                    <SelectItem value="fixed">Valor Fixo (R$)</SelectItem>
                    <SelectItem value="shipping">Frete Grátis</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="value" className="text-right">
                  Valor do Desconto
                </Label>
                <div className="relative">
                  <Input
                    id="value"
                    type="number"
                    value={newPromotion.value}
                    onChange={(e) => setNewPromotion({...newPromotion, value: parseFloat(e.target.value) || 0})}
                    className="pl-8"
                    disabled={newPromotion.type === "shipping"}
                  />
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                    {newPromotion.type === "percentage" ? "%" : "R$"}
                  </div>
                </div>
              </div>
              
              <div>
                <Label htmlFor="min_purchase" className="text-right">
                  Compra Mínima
                </Label>
                <div className="relative">
                  <Input
                    id="min_purchase"
                    type="number"
                    value={newPromotion.min_purchase}
                    onChange={(e) => setNewPromotion({...newPromotion, min_purchase: parseFloat(e.target.value) || 0})}
                    className="pl-8"
                  />
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                    R$
                  </div>
                </div>
              </div>
              
              <div>
                <Label htmlFor="usage_limit" className="text-right">
                  Limite de Uso Total
                </Label>
                <Input
                  id="usage_limit"
                  type="number"
                  placeholder="Ilimitado"
                  value={newPromotion.usage_limit === null ? "" : newPromotion.usage_limit}
                  onChange={(e) => setNewPromotion({...newPromotion, usage_limit: e.target.value === "" ? null : parseInt(e.target.value)})}
                />
              </div>
              
              <div>
                <Label htmlFor="start_date" className="text-right">
                  Data de Início
                </Label>
                <Input
                  id="start_date"
                  type="date"
                  value={newPromotion.start_date}
                  onChange={(e) => setNewPromotion({...newPromotion, start_date: e.target.value})}
                />
              </div>
              
              <div>
                <Label htmlFor="end_date" className="text-right">
                  Data de Término
                </Label>
                <Input
                  id="end_date"
                  type="date"
                  value={newPromotion.end_date}
                  onChange={(e) => setNewPromotion({...newPromotion, end_date: e.target.value})}
                />
              </div>
              
              <div className="col-span-2">
                <Label htmlFor="target_audience" className="text-right">
                  Público Alvo
                </Label>
                <Select
                  value={newPromotion.target_audience}
                  onValueChange={(value) => setNewPromotion({...newPromotion, target_audience: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o público alvo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os clientes</SelectItem>
                    <SelectItem value="new_customers">Apenas novos clientes</SelectItem>
                    <SelectItem value="customers">Apenas clientes existentes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="col-span-2">
                <Label htmlFor="description" className="text-right">
                  Descrição
                </Label>
                <Textarea
                  id="description"
                  value={newPromotion.description}
                  onChange={(e) => setNewPromotion({...newPromotion, description: e.target.value})}
                  placeholder="Descreva a promoção..."
                  className="col-span-3"
                />
              </div>
              
              <div className="col-span-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="status" className="text-right">
                    Status
                  </Label>
                  <Switch
                    id="status"
                    checked={newPromotion.status === "active" || newPromotion.status === "scheduled"}
                    onCheckedChange={(checked) => 
                      setNewPromotion({
                        ...newPromotion, 
                        status: checked ? 
                          (new Date(newPromotion.start_date) > new Date() ? "scheduled" : "active") : 
                          "inactive"
                      })
                    }
                  />
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  {newPromotion.status === "active" ? "A promoção estará ativa imediatamente" : 
                   newPromotion.status === "scheduled" ? "A promoção será ativada automaticamente na data de início" : 
                   "A promoção permanecerá inativa até ser manualmente ativada"}
                </p>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewPromotionDialog(false)}>
              Cancelar
            </Button>
            <Button type="submit" onClick={handleCreatePromotion}>
              Criar Promoção
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de detalhes da promoção */}
      <Dialog open={showPromotionDetails} onOpenChange={setShowPromotionDetails}>
        {selectedPromotion && (
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Detalhes da Promoção</DialogTitle>
              <DialogDescription>
                Informações detalhadas sobre a promoção selecionada.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">{selectedPromotion.name}</h3>
                {getStatusBadge(selectedPromotion.status)}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Código</p>
                  <div className="flex items-center gap-1 mt-1">
                    <code className="bg-gray-100 px-2 py-1 rounded text-sm">{selectedPromotion.code}</code>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => handleCopy(selectedPromotion.code)}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Tipo de Desconto</p>
                  <p className="mt-1">{getTypeLabel(selectedPromotion.type)}</p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Valor do Desconto</p>
                  <p className="mt-1">{formatValue(selectedPromotion)}</p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Compra Mínima</p>
                  <p className="mt-1">
                    {selectedPromotion.min_purchase > 0 
                      ? `R$ ${selectedPromotion.min_purchase.toFixed(2)}` 
                      : "Sem valor mínimo"}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Período de Validade</p>
                  <p className="mt-1">
                    {formatDate(selectedPromotion.start_date)} - {formatDate(selectedPromotion.end_date)}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Limite de Uso</p>
                  <p className="mt-1">
                    {selectedPromotion.usage_count} / {selectedPromotion.usage_limit ? selectedPromotion.usage_limit : '∞'}
                  </p>
                </div>
                
                <div className="col-span-2">
                  <p className="text-sm text-gray-500">Descrição</p>
                  <p className="mt-1">{selectedPromotion.description}</p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Público Alvo</p>
                  <p className="mt-1">
                    {selectedPromotion.target_audience === "all" ? "Todos os clientes" : 
                     selectedPromotion.target_audience === "new_customers" ? "Apenas novos clientes" : 
                     "Apenas clientes existentes"}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Limite por Usuário</p>
                  <p className="mt-1">
                    {selectedPromotion.user_limit === 1 ? "1 uso por cliente" : 
                     selectedPromotion.user_limit ? `${selectedPromotion.user_limit} usos por cliente` : 
                     "Uso ilimitado por cliente"}
                  </p>
                </div>
                
                {selectedPromotion.products && selectedPromotion.products.length > 0 && (
                  <div className="col-span-2">
                    <p className="text-sm text-gray-500">Produtos Aplicáveis</p>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {selectedPromotion.products.map((product, index) => (
                        <Badge key={index} variant="outline">{product}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowPromotionDetails(false)}>
                Fechar
              </Button>
              <Button>
                <Edit className="h-4 w-4 mr-2" />
                Editar
              </Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}