
import React, { useState, useEffect } from 'react';
import { 
  Leaf, 
  BarChart, 
  Info, 
  Check, 
  Plus, 
  Search, 
  Settings,
  Download,
  ArrowRight,
  Building2,
  DollarSign,
  Sprout,
  ClipboardList,
  Scale,
  X
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";

// Dados de amostra de organizações
const mockOrganizations = [
  {
    id: "org1",
    name: "MediCannabis Farma",
    type: "Empresa",
    plan: "Empresarial Pro",
    contact_name: "João Silva",
    contact_email: "joao@medicannabis.com.br",
    status: "Ativo",
    modules: {
      cultivo: {
        enabled: true,
        tier: "Intermediário",
        price: 899,
        active_since: "2023-04-15T10:00:00Z",
        next_billing: "2023-08-15T10:00:00Z",
        billing_status: "active"
      }
    }
  },
  {
    id: "org2",
    name: "Associação Médica Verde",
    type: "Associação",
    plan: "Associação Premium",
    contact_name: "Maria Oliveira",
    contact_email: "maria@amv.org.br",
    status: "Ativo",
    modules: {
      cultivo: {
        enabled: true,
        tier: "Avançado",
        price: 1499,
        active_since: "2023-03-10T14:30:00Z",
        next_billing: "2023-08-10T14:30:00Z",
        billing_status: "active"
      }
    }
  },
  {
    id: "org3",
    name: "CannaPesquisa Instituto",
    type: "Associação",
    plan: "Associação Plus",
    contact_name: "Pedro Almeida",
    contact_email: "pedro@cannapesquisa.org",
    status: "Ativo",
    modules: {
      cultivo: {
        enabled: false
      }
    }
  },
  {
    id: "org4",
    name: "Green Medical Brasil",
    type: "Empresa",
    plan: "Empresarial Básico",
    contact_name: "Ana Sousa",
    contact_email: "ana@greenmedical.com.br",
    status: "Ativo",
    modules: {
      cultivo: {
        enabled: true,
        tier: "Básico",
        price: 499,
        active_since: "2023-06-20T09:15:00Z",
        next_billing: "2023-08-20T09:15:00Z",
        billing_status: "active"
      }
    }
  },
  {
    id: "org5",
    name: "Cannabis Brasil Sul",
    type: "Empresa",
    plan: "Empresarial Pro",
    contact_name: "Carlos Mendes",
    contact_email: "carlos@cannabisbrasil.com.br",
    status: "Rejeitado",
    modules: {
      cultivo: {
        enabled: false
      }
    }
  }
];

// Dados do módulo
const moduleData = {
  name: "Cultivo",
  icon: Leaf,
  description: "O módulo de cultivo permite o gerenciamento completo do ciclo de cultivo de cannabis medicinal, desde o plantio até a colheita.",
  colorClass: "bg-green-100 text-green-800",
  features: [
    "Gestão de plantas e lotes",
    "Rastreamento de crescimento",
    "Controle de estoque de plantas",
    "Gestão de strains",
    "Transferências internas"
  ],
  tiers: [
    { 
      name: "Básico", 
      price: 499, 
      limit: "10 plantas",
      features: [
        { name: "Gestão de plantas", included: true },
        { name: "Rastreamento básico", included: true },
        { name: "Controle de estoque", included: true },
        { name: "Relatórios básicos", included: true },
        { name: "Gestão de strains", included: false }
      ]
    },
    { 
      name: "Intermediário", 
      price: 899, 
      limit: "50 plantas",
      features: [
        { name: "Gestão de plantas", included: true },
        { name: "Rastreamento avançado", included: true },
        { name: "Controle de estoque", included: true },
        { name: "Relatórios detalhados", included: true },
        { name: "Gestão de strains", included: true }
      ]
    },
    { 
      name: "Avançado", 
      price: 1499, 
      limit: "Ilimitado",
      features: [
        { name: "Gestão de plantas", included: true },
        { name: "Rastreamento avançado", included: true },
        { name: "Controle de estoque", included: true },
        { name: "Relatórios personalizados", included: true },
        { name: "Gestão de strains", included: true }
      ]
    }
  ],
  stats: {
    total_orgs: 3,
    active_orgs: 3,
    total_revenue: 2897,
    plants_tracked: 783
  }
};

export default function ModuloCultivo() {
  const [organizations, setOrganizations] = useState([]);
  const [filteredOrgs, setFilteredOrgs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState("all");
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    // Simular carregamento de dados
    setTimeout(() => {
      setOrganizations(mockOrganizations);
      setFilteredOrgs(mockOrganizations);
      setLoading(false);
    }, 1000);
  }, []);

  // Filtragem de organizações quando o termo de pesquisa ou filtro muda
  useEffect(() => {
    let filtered = organizations;
    
    // Aplicar pesquisa por texto
    if (searchTerm) {
      filtered = filtered.filter(org => 
        org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        org.contact_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        org.contact_email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Aplicar filtro de status do módulo
    if (filter === "enabled") {
      filtered = filtered.filter(org => org.modules.cultivo?.enabled);
    } else if (filter === "disabled") {
      filtered = filtered.filter(org => !org.modules.cultivo?.enabled);
    }
    
    setFilteredOrgs(filtered);
  }, [searchTerm, filter, organizations]);

  const handleToggleModule = (orgId, enabled) => {
    const updatedOrgs = organizations.map(org => {
      if (org.id === orgId) {
        return {
          ...org,
          modules: {
            ...org.modules,
            cultivo: {
              ...org.modules.cultivo,
              enabled,
              tier: enabled ? "Básico" : undefined,
              price: enabled ? 499 : undefined,
              active_since: enabled ? new Date().toISOString() : undefined,
              next_billing: enabled ? new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString() : undefined,
              billing_status: enabled ? "active" : undefined
            }
          }
        };
      }
      return org;
    });
    
    setOrganizations(updatedOrgs);
    
    toast({
      title: enabled ? "Módulo ativado" : "Módulo desativado",
      description: `O módulo de Cultivo foi ${enabled ? 'ativado' : 'desativado'} com sucesso para ${organizations.find(org => org.id === orgId).name}.`,
    });
  };

  const updateModuleTier = (orgId, tier) => {
    const tierData = moduleData.tiers.find(t => t.name === tier);
    
    const updatedOrgs = organizations.map(org => {
      if (org.id === orgId) {
        return {
          ...org,
          modules: {
            ...org.modules,
            cultivo: {
              ...org.modules.cultivo,
              tier,
              price: tierData.price,
              next_billing: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString()
            }
          }
        };
      }
      return org;
    });
    
    setOrganizations(updatedOrgs);
    
    toast({
      title: "Plano atualizado",
      description: `O plano de Cultivo foi atualizado para ${tier} com sucesso.`,
    });
  };

  const formatDate = (dateString) => {
    if (!dateString) return '--';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  // Estatísticas do módulo
  const stats = {
    total_orgs: filteredOrgs.length,
    active_orgs: filteredOrgs.filter(org => org.modules.cultivo?.enabled).length,
    total_revenue: filteredOrgs.reduce((sum, org) => sum + (org.modules.cultivo?.enabled ? org.modules.cultivo.price : 0), 0),
    average_price: filteredOrgs.filter(org => org.modules.cultivo?.enabled).length > 0 
      ? filteredOrgs.reduce((sum, org) => sum + (org.modules.cultivo?.enabled ? org.modules.cultivo.price : 0), 0) / 
        filteredOrgs.filter(org => org.modules.cultivo?.enabled).length 
      : 0
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-full ${moduleData.colorClass}`}>
              <Leaf className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-bold">Módulo de Cultivo</h1>
          </div>
          <p className="text-gray-500 mt-1">
            Gerencie as organizações que utilizam o módulo de cultivo
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Exportar
          </Button>
          <Button variant="outline" className="gap-2">
            <Settings className="w-4 h-4" />
            Configurações
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="organizations">Organizações</TabsTrigger>
          <TabsTrigger value="pricing">Preços e Planos</TabsTrigger>
          <TabsTrigger value="usage">Uso e Métricas</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Informações do Módulo</CardTitle>
              <CardDescription>
                Detalhes sobre o módulo de cultivo e suas funcionalidades
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-1">
                  <p className="text-gray-700">{moduleData.description}</p>
                  
                  <div className="mt-6">
                    <h3 className="font-medium mb-2">Principais Funcionalidades:</h3>
                    <ul className="space-y-1">
                      {moduleData.features.map((feature, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <Check className="w-4 h-4 text-green-500" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                <div className="w-full md:w-80 bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-medium mb-4">Estatísticas</h3>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Organizações ativas:</span>
                      <Badge variant="outline" className="bg-green-50">
                        {stats.active_orgs} / {stats.total_orgs}
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Receita mensal:</span>
                      <Badge variant="outline" className="bg-blue-50">
                        R$ {stats.total_revenue}
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Preço médio:</span>
                      <Badge variant="outline" className="bg-purple-50">
                        R$ {stats.average_price.toFixed(2)}
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Organizações Ativas</CardTitle>
                <CardDescription>Total de organizações utilizando o módulo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-blue-500" />
                    <span className="text-2xl font-bold">{stats.active_orgs}</span>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">
                    {((stats.active_orgs / stats.total_orgs) * 100).toFixed(0)}%
                  </Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Receita Mensal</CardTitle>
                <CardDescription>Receita total gerada pelo módulo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-green-500" />
                    <span className="text-2xl font-bold">R$ {stats.total_revenue}</span>
                  </div>
                  <Badge className="bg-green-100 text-green-800">
                    Mensal
                  </Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Plantas Rastreadas</CardTitle>
                <CardDescription>Total de plantas no sistema</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sprout className="w-5 h-5 text-green-500" />
                    <span className="text-2xl font-bold">783</span>
                  </div>
                  <Badge className="bg-green-100 text-green-800">
                    +12% este mês
                  </Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Lotes Ativos</CardTitle>
                <CardDescription>Lotes em andamento</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ClipboardList className="w-5 h-5 text-purple-500" />
                    <span className="text-2xl font-bold">42</span>
                  </div>
                  <Badge className="bg-purple-100 text-purple-800">
                    +3 esta semana
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Organizações Recentes</CardTitle>
              <CardDescription>
                Organizações que ativaram o módulo recentemente
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {loading ? (
                  <div className="space-y-4 animate-pulse">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 bg-gray-200 rounded-full"></div>
                          <div>
                            <div className="h-4 bg-gray-200 rounded w-40 mb-2"></div>
                            <div className="h-3 bg-gray-200 rounded w-32"></div>
                          </div>
                        </div>
                        <div className="h-8 bg-gray-200 rounded w-24"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  filteredOrgs
                    .filter(org => org.modules.cultivo?.enabled)
                    .sort((a, b) => new Date(b.modules.cultivo.active_since) - new Date(a.modules.cultivo.active_since))
                    .slice(0, 5)
                    .map(org => (
                      <div key={org.id} className="flex justify-between items-center p-3 hover:bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback className="bg-green-100 text-green-800">
                              {org.name.substring(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{org.name}</p>
                            <div className="flex items-center gap-2 text-sm text-gray-500">
                              <span>Desde: {formatDate(org.modules.cultivo.active_since)}</span>
                              <span>•</span>
                              <span>Plano: {org.modules.cultivo.tier}</span>
                            </div>
                          </div>
                        </div>
                        <Badge className="bg-green-100 text-green-800">
                          R$ {org.modules.cultivo.price}/mês
                        </Badge>
                      </div>
                    ))
                )}
                
                {!loading && filteredOrgs.filter(org => org.modules.cultivo?.enabled).length === 0 && (
                  <div className="text-center py-6">
                    <p className="text-gray-500">Nenhuma organização está utilizando o módulo</p>
                    <Button className="mt-4">
                      <Plus className="w-4 h-4 mr-2" />
                      Adicionar Organização
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => setActiveTab("organizations")}>
                Ver Todas as Organizações
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="organizations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Organizações</CardTitle>
              <CardDescription>
                Gerencie todas as organizações que podem usar o módulo de Cultivo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col md:flex-row gap-4 justify-between">
                <div className="relative w-full md:w-64">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Buscar organização..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    variant={filter === "all" ? "default" : "outline"} 
                    onClick={() => setFilter("all")}
                  >
                    Todas
                  </Button>
                  <Button 
                    variant={filter === "enabled" ? "default" : "outline"} 
                    onClick={() => setFilter("enabled")}
                  >
                    Módulo Ativo
                  </Button>
                  <Button 
                    variant={filter === "disabled" ? "default" : "outline"} 
                    onClick={() => setFilter("disabled")}
                  >
                    Módulo Inativo
                  </Button>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                {loading ? (
                  <div className="space-y-4 animate-pulse">
                    {[1, 2, 3, 4, 5].map(i => (
                      <div key={i} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 bg-gray-200 rounded-full"></div>
                            <div>
                              <div className="h-5 bg-gray-200 rounded w-40 mb-2"></div>
                              <div className="flex gap-2">
                                <div className="h-4 bg-gray-200 rounded w-20"></div>
                                <div className="h-4 bg-gray-200 rounded w-24"></div>
                              </div>
                            </div>
                          </div>
                          <div className="h-8 bg-gray-200 rounded w-40"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  filteredOrgs.length > 0 ? (
                    filteredOrgs.map(org => (
                      <div key={org.id} className="p-4 border rounded-lg hover:bg-gray-50">
                        <div className="flex flex-col md:flex-row justify-between gap-4">
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarFallback className="bg-green-100 text-green-800">
                                {org.name.substring(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{org.name}</p>
                              <div className="flex flex-wrap gap-2 mt-1">
                                <Badge variant="outline">
                                  {org.type}
                                </Badge>
                                <Badge variant="outline">
                                  {org.plan}
                                </Badge>
                                <Badge className={
                                  org.status === 'Ativo' ? 'bg-green-100 text-green-800' : 
                                  org.status === 'Pendente' ? 'bg-yellow-100 text-yellow-800' : 
                                  'bg-red-100 text-red-800'
                                }>
                                  {org.status}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-4">
                            {org.modules.cultivo?.enabled ? (
                              <div className="text-right mr-4">
                                <p className="text-sm text-gray-500">Próxima cobrança</p>
                                <p className="font-medium">{formatDate(org.modules.cultivo.next_billing)}</p>
                                <p className="text-sm text-gray-500">
                                  {org.modules.cultivo.tier} - R$ {org.modules.cultivo.price}/mês
                                </p>
                              </div>
                            ) : (
                              <div className="text-right mr-4">
                                <p className="text-sm text-gray-500">Módulo inativo</p>
                                <p className="font-medium">Não ativado</p>
                              </div>
                            )}
                            
                            <div className="flex items-center gap-2">
                              <Switch 
                                checked={org.modules.cultivo?.enabled || false}
                                onCheckedChange={(checked) => handleToggleModule(org.id, checked)}
                              />
                              <Label className={org.modules.cultivo?.enabled ? "text-green-600" : "text-gray-500"}>
                                {org.modules.cultivo?.enabled ? "Ativo" : "Inativo"}
                              </Label>
                            </div>
                          </div>
                        </div>
                        
                        {org.modules.cultivo?.enabled && (
                          <div className="mt-4 pt-4 border-t">
                            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                              <div>
                                <p className="text-sm font-medium">Plano atual: <span className="text-green-600">{org.modules.cultivo.tier}</span></p>
                                <p className="text-xs text-gray-500">Ativo desde {formatDate(org.modules.cultivo.active_since)}</p>
                              </div>
                              
                              <div className="flex gap-2">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => updateModuleTier(org.id, "Básico")}
                                  className={org.modules.cultivo.tier === "Básico" ? "bg-green-50 border-green-200" : ""}
                                >
                                  Básico
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => updateModuleTier(org.id, "Intermediário")}
                                  className={org.modules.cultivo.tier === "Intermediário" ? "bg-green-50 border-green-200" : ""}
                                >
                                  Intermediário
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => updateModuleTier(org.id, "Avançado")}
                                  className={org.modules.cultivo.tier === "Avançado" ? "bg-green-50 border-green-200" : ""}
                                >
                                  Avançado
                                </Button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-12">
                      <Info className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-700">Nenhuma organização encontrada</h3>
                      <p className="text-gray-500 mt-1">Tente ajustar seus filtros de busca</p>
                    </div>
                  )
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pricing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Planos do Módulo de Cultivo</CardTitle>
              <CardDescription>
                Configure os preços e limites dos planos disponíveis
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {moduleData.tiers.map((tier, index) => (
                  <Card key={index} className="flex flex-col h-full border-green-200">
                    <CardHeader className={index === 1 ? "bg-green-50" : ""}>
                      {index === 1 && (
                        <Badge className="mb-2 bg-green-600">Recomendado</Badge>
                      )}
                      <CardTitle>{tier.name}</CardTitle>
                      <CardDescription>
                        Limite: {tier.limit}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="flex-1">
                      <div className="mb-6">
                        <span className="text-3xl font-bold">R$ {tier.price}</span>
                        <span className="text-gray-500 ml-1">/mês</span>
                      </div>
                      
                      <ul className="space-y-2">
                        {tier.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center gap-2 text-sm">
                            {feature.included ? (
                              <Check className="w-4 h-4 text-green-500" />
                            ) : (
                              <X className="w-4 h-4 text-gray-300" />
                            )}
                            <span className={feature.included ? "" : "text-gray-400"}>
                              {feature.name}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full" variant={index === 1 ? "default" : "outline"}>
                        Editar Plano
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Cobrança</CardTitle>
              <CardDescription>
                Configure como o módulo será cobrado das organizações
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-medium">Ciclo de Cobrança</h3>
                  <div className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <p className="font-medium">Cobrança Mensal</p>
                      <p className="text-sm text-gray-500">Cobrado todo mês no dia da ativação</p>
                    </div>
                    <Switch checked={true} />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <p className="font-medium">Cobrança Anual</p>
                      <p className="text-sm text-gray-500">Desconto de 10% no pagamento anual</p>
                    </div>
                    <Switch checked={false} />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-medium">Método de Cobrança</h3>
                  <div className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <p className="font-medium">Cobrança Automática</p>
                      <p className="text-sm text-gray-500">Via método de pagamento salvo</p>
                    </div>
                    <Switch checked={true} />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <p className="font-medium">Fatura Manual</p>
                      <p className="text-sm text-gray-500">Envio de fatura para pagamento</p>
                    </div>
                    <Switch checked={true} />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="usage" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Métricas de Uso</CardTitle>
              <CardDescription>
                Estatísticas de uso do módulo de cultivo em todas as organizações
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 w-full bg-gray-100 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <BarChart className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500">Gráficos de uso seriam exibidos aqui</p>
                  <p className="text-sm text-gray-400 mt-1">Dados de plantas, lotes e colheitas por organização</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Principais Métricas</CardTitle>
                <CardDescription>
                  Totais de uso em todas as organizações
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-full bg-green-100">
                        <Sprout className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Total de Plantas</p>
                        <p className="text-2xl font-bold">783</p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">+12%</Badge>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-full bg-blue-100">
                        <ClipboardList className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Total de Lotes</p>
                        <p className="text-2xl font-bold">42</p>
                      </div>
                    </div>
                    <Badge className="bg-blue-100 text-blue-800">+5%</Badge>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-full bg-purple-100">
                        <Scale className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Total em Estoque (kg)</p>
                        <p className="text-2xl font-bold">128.5</p>
                      </div>
                    </div>
                    <Badge className="bg-purple-100 text-purple-800">+8%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Maiores Usuários</CardTitle>
                <CardDescription>
                  Organizações com maior uso do módulo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {!loading && filteredOrgs
                    .filter(org => org.modules.cultivo?.enabled)
                    .slice(0, 5)
                    .map((org, index) => (
                      <div key={org.id} className="flex items-center gap-4">
                        <div className="w-6 text-center font-medium text-gray-500">
                          #{index + 1}
                        </div>
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-green-100 text-green-800">
                            {org.name.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="font-medium">{org.name}</p>
                          <p className="text-sm text-gray-500">{org.modules.cultivo.tier}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{Math.floor(Math.random() * 150) + 20}</p>
                          <p className="text-sm text-gray-500">plantas</p>
                        </div>
                      </div>
                    ))}
                    
                  {loading && (
                    <div className="animate-pulse space-y-4">
                      {[1, 2, 3, 4, 5].map(i => (
                        <div key={i} className="flex items-center gap-4">
                          <div className="w-6"></div>
                          <div className="h-10 w-10 bg-gray-200 rounded-full"></div>
                          <div className="flex-1">
                            <div className="h-4 bg-gray-200 rounded w-32 mb-2"></div>
                            <div className="h-3 bg-gray-200 rounded w-20"></div>
                          </div>
                          <div className="w-16">
                            <div className="h-4 bg-gray-200 rounded w-12 mb-2 ml-auto"></div>
                            <div className="h-3 bg-gray-200 rounded w-16 ml-auto"></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
