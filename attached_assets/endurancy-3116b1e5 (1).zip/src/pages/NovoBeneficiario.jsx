import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { AssistenciaBeneficiario } from '@/api/entities';
import { SendEmail } from "@/api/integrations";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  User, 
  Mail, 
  Phone, 
  Home, 
  FileText, 
  Calendar, 
  ArrowLeft,
  CheckCircle,
  Info,
  AlertCircle
} from 'lucide-react';

export default function NovoBeneficiario() {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    // Dados Pessoais
    nome: '',
    cpf: '',
    data_nascimento: '',
    telefone: '',
    email: '',
    endereco: {
      cep: '',
      logradouro: '',
      numero: '',
      complemento: '',
      bairro: '',
      cidade: '',
      estado: ''
    },
    
    // Dados Médicos e de Assistência
    condicao_medica: '',
    medicamentos: [],
    percentual_isencao: 100,
    valor_subsidio: 0,
    assistente_social: '',
    
    // Situação e observações
    situacao: 'ativo',
    observacoes: '',
    
    // Outros dados
    data_ingresso: new Date().toISOString().split('T')[0],
    organization_id: 'org_1', // Substituir pelo ID real da organização
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Criar novo beneficiário no sistema
      await AssistenciaBeneficiario.create(formData);
      
      // Enviar email de notificação
      if (formData.email) {
        await SendEmail({
          to: formData.email,
          subject: "Cadastro no Programa Social",
          body: `
            Olá ${formData.nome},

            Seu cadastro no programa social foi realizado com sucesso.
            
            Percentual de isenção: ${formData.percentual_isencao}%
            Valor do subsídio: R$ ${formData.valor_subsidio.toLocaleString('pt-BR')}
            
            Para mais informações, entre em contato com nossa equipe social.
            
            Atenciosamente,
            Equipe do Programa Social
          `
        });
      }

      // Redirecionar para a página de beneficiários
      navigate(createPageUrl("Social"));
    } catch (error) {
      console.error('Erro ao cadastrar beneficiário:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          className="mr-2"
          onClick={() => navigate(createPageUrl("Social"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">Novo Beneficiário</h1>
          <p className="text-gray-500">Cadastro de novo beneficiário no programa social</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Dados Pessoais</CardTitle>
              <CardDescription>Informações básicas do beneficiário</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-2">
                  <FormField>
                    <FormLabel>Nome Completo *</FormLabel>
                    <FormControl>
                      <Input
                        name="nome"
                        value={formData.nome}
                        onChange={handleInputChange}
                        required
                        placeholder="Nome completo do beneficiário"
                      />
                    </FormControl>
                  </FormField>
                </div>

                <FormField>
                  <FormLabel>CPF *</FormLabel>
                  <FormControl>
                    <Input
                      name="cpf"
                      value={formData.cpf}
                      onChange={handleInputChange}
                      required
                      placeholder="000.000.000-00"
                    />
                  </FormControl>
                </FormField>

                <FormField>
                  <FormLabel>Data de Nascimento *</FormLabel>
                  <FormControl>
                    <Input
                      type="date"
                      name="data_nascimento"
                      value={formData.data_nascimento}
                      onChange={handleInputChange}
                      required
                    />
                  </FormControl>
                </FormField>

                <FormField>
                  <FormLabel>Telefone *</FormLabel>
                  <FormControl>
                    <Input
                      name="telefone"
                      value={formData.telefone}
                      onChange={handleInputChange}
                      required
                      placeholder="(00) 00000-0000"
                    />
                  </FormControl>
                </FormField>

                <FormField>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="email@exemplo.com"
                    />
                  </FormControl>
                </FormField>
              </div>

              <div className="mt-6">
                <h3 className="font-medium mb-3">Endereço</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField>
                    <FormLabel>CEP</FormLabel>
                    <FormControl>
                      <Input
                        name="endereco.cep"
                        value={formData.endereco.cep}
                        onChange={handleInputChange}
                        placeholder="00000-000"
                      />
                    </FormControl>
                  </FormField>

                  <div className="md:col-span-2">
                    <FormField>
                      <FormLabel>Logradouro</FormLabel>
                      <FormControl>
                        <Input
                          name="endereco.logradouro"
                          value={formData.endereco.logradouro}
                          onChange={handleInputChange}
                          placeholder="Rua, Avenida, etc."
                        />
                      </FormControl>
                    </FormField>
                  </div>

                  <FormField>
                    <FormLabel>Número</FormLabel>
                    <FormControl>
                      <Input
                        name="endereco.numero"
                        value={formData.endereco.numero}
                        onChange={handleInputChange}
                        placeholder="Número"
                      />
                    </FormControl>
                  </FormField>

                  <FormField>
                    <FormLabel>Complemento</FormLabel>
                    <FormControl>
                      <Input
                        name="endereco.complemento"
                        value={formData.endereco.complemento}
                        onChange={handleInputChange}
                        placeholder="Apto, Bloco, etc."
                      />
                    </FormControl>
                  </FormField>

                  <FormField>
                    <FormLabel>Bairro</FormLabel>
                    <FormControl>
                      <Input
                        name="endereco.bairro"
                        value={formData.endereco.bairro}
                        onChange={handleInputChange}
                        placeholder="Bairro"
                      />
                    </FormControl>
                  </FormField>

                  <FormField>
                    <FormLabel>Cidade</FormLabel>
                    <FormControl>
                      <Input
                        name="endereco.cidade"
                        value={formData.endereco.cidade}
                        onChange={handleInputChange}
                        placeholder="Cidade"
                      />
                    </FormControl>
                  </FormField>

                  <FormField>
                    <FormLabel>Estado</FormLabel>
                    <FormControl>
                      <Select
                        value={formData.endereco.estado}
                        onValueChange={(value) => handleSelectChange('endereco.estado', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o estado" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="AC">Acre</SelectItem>
                          <SelectItem value="AL">Alagoas</SelectItem>
                          <SelectItem value="AP">Amapá</SelectItem>
                          <SelectItem value="AM">Amazonas</SelectItem>
                          <SelectItem value="BA">Bahia</SelectItem>
                          <SelectItem value="CE">Ceará</SelectItem>
                          <SelectItem value="DF">Distrito Federal</SelectItem>
                          <SelectItem value="ES">Espírito Santo</SelectItem>
                          <SelectItem value="GO">Goiás</SelectItem>
                          <SelectItem value="MA">Maranhão</SelectItem>
                          <SelectItem value="MT">Mato Grosso</SelectItem>
                          <SelectItem value="MS">Mato Grosso do Sul</SelectItem>
                          <SelectItem value="MG">Minas Gerais</SelectItem>
                          <SelectItem value="PA">Pará</SelectItem>
                          <SelectItem value="PB">Paraíba</SelectItem>
                          <SelectItem value="PR">Paraná</SelectItem>
                          <SelectItem value="PE">Pernambuco</SelectItem>
                          <SelectItem value="PI">Piauí</SelectItem>
                          <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                          <SelectItem value="RN">Rio Grande do Norte</SelectItem>
                          <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                          <SelectItem value="RO">Rondônia</SelectItem>
                          <SelectItem value="RR">Roraima</SelectItem>
                          <SelectItem value="SC">Santa Catarina</SelectItem>
                          <SelectItem value="SP">São Paulo</SelectItem>
                          <SelectItem value="SE">Sergipe</SelectItem>
                          <SelectItem value="TO">Tocantins</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormControl>
                  </FormField>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Informações Médicas e Assistenciais</CardTitle>
              <CardDescription>Dados sobre a condição médica e assistência</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-2">
                  <FormField>
                    <FormLabel>Condição Médica Principal *</FormLabel>
                    <FormControl>
                      <Textarea
                        name="condicao_medica"
                        value={formData.condicao_medica}
                        onChange={handleInputChange}
                        required
                        placeholder="Descreva a condição médica principal do beneficiário"
                      />
                    </FormControl>
                  </FormField>
                </div>

                <div className="col-span-2">
                  <FormField>
                    <FormLabel>Medicamentos</FormLabel>
                    <FormControl>
                      <Textarea
                        name="medicamentos_texto"
                        onChange={(e) => handleSelectChange('medicamentos', e.target.value.split(',').map(item => item.trim()))}
                        placeholder="Informe os medicamentos separados por vírgula"
                      />
                    </FormControl>
                    <FormDescription>
                      Informe os medicamentos utilizados pelo beneficiário, separados por vírgula.
                    </FormDescription>
                  </FormField>
                </div>

                <FormField>
                  <FormLabel>Percentual de Isenção *</FormLabel>
                  <FormControl>
                    <Select
                      value={formData.percentual_isencao.toString()}
                      onValueChange={(value) => handleSelectChange('percentual_isencao', parseInt(value))}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o percentual" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="100">100% (Isenção Total)</SelectItem>
                        <SelectItem value="75">75%</SelectItem>
                        <SelectItem value="50">50%</SelectItem>
                        <SelectItem value="25">25%</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormControl>
                </FormField>

                <FormField>
                  <FormLabel>Valor do Subsídio (R$) *</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      name="valor_subsidio"
                      value={formData.valor_subsidio}
                      onChange={handleInputChange}
                      required
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                    />
                  </FormControl>
                </FormField>

                <FormField>
                  <FormLabel>Assistente Social Responsável</FormLabel>
                  <FormControl>
                    <Input
                      name="assistente_social"
                      value={formData.assistente_social}
                      onChange={handleInputChange}
                      placeholder="Nome do assistente social responsável"
                    />
                  </FormControl>
                </FormField>

                <FormField>
                  <FormLabel>Situação *</FormLabel>
                  <FormControl>
                    <Select
                      value={formData.situacao}
                      onValueChange={(value) => handleSelectChange('situacao', value)}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a situação" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ativo">Ativo</SelectItem>
                        <SelectItem value="pendente_reavaliacao">Pendente de Reavaliação</SelectItem>
                        <SelectItem value="inativo">Inativo</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormControl>
                </FormField>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Informações Adicionais</CardTitle>
              <CardDescription>Observações e outros dados importantes</CardDescription>
            </CardHeader>
            <CardContent>
              <FormField>
                <FormLabel>Observações</FormLabel>
                <FormControl>
                  <Textarea
                    name="observacoes"
                    value={formData.observacoes}
                    onChange={handleInputChange}
                    placeholder="Observações adicionais sobre o beneficiário"
                    className="h-24"
                  />
                </FormControl>
              </FormField>

              <Alert className="mt-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Ao cadastrar um beneficiário, ele será automaticamente incluído no programa social
                  e receberá um email de confirmação caso o email seja fornecido.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-2">
            <Button 
              variant="outline" 
              type="button"
              onClick={() => navigate(createPageUrl("Social"))}
            >
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Cadastrando...' : 'Cadastrar Beneficiário'}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}