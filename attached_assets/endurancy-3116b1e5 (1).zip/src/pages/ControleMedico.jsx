import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { 
  Calendar, 
  Clock, 
  FileText, 
  Heart, 
  MessageSquare, 
  Pill, 
  User as UserIcon, 
  AlertTriangle, 
  ChevronRight, 
  CheckCircle2, 
  Plus, 
  Building2,
  Users,
  UserCheck,
  CalendarClock, 
  BarChart3, 
  FileCheck,
  ClipboardList,
  Stethoscope,
  Clipboard
} from 'lucide-react';

export default function ControleMedico() {
  const [dashboardData, setDashboardData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [showOrgSelector, setShowOrgSelector] = useState(false);
  const [selectedOrg, setSelectedOrg] = useState('');
  const [organizations, setOrganizations] = useState([
    { id: 'org1', name: 'MediCannabis Farma' },
    { id: 'org2', name: 'Associação Médica Verde' },
    { id: 'org3', name: 'CannaPesquisa Instituto' },
    { id: 'org4', name: 'Green Medical Brasil' },
    { id: 'org5', name: 'Cannabis Brasil Sul' },
    { id: 'org6', name: 'Cultivo Sustentável Ltda' }
  ]);

  // Check if user needs to select organization
  useEffect(() => {
    const needsOrg = localStorage.getItem('mockNeedsOrg') === 'true';
    const hasOrg = localStorage.getItem('mockOrgId');
    
    if (needsOrg && !hasOrg) {
      setShowOrgSelector(true);
    } else {
      // If organization is already selected, load dashboard data
      loadDashboardData();
    }
  }, []);

  const loadDashboardData = () => {
    setIsLoading(true);
    // Simular carregamento de dados do dashboard
    setTimeout(() => {
      setDashboardData({
        organization: localStorage.getItem('mockOrgName') || "Associação Médica Verde",
        doctor: {
          name: localStorage.getItem('mockUserName') || "Dr. João Silva",
          specialty: "Neurologia",
          crm: "12345-SP",
          photoUrl: null, // URL da foto do médico, se disponível
          role: "Médico Interno"
        },
        stats: {
          activePatients: 42,
          pendingPrescriptions: 8,
          upcomingAppointments: 3,
          totalPrescriptionsMonth: 37
        },
        upcomingAppointments: [
          {
            id: "APT-001",
            patient: "Ana Silva",
            date: "2023-08-15T14:30:00",
            type: "Reavaliação",
            isVirtual: true
          },
          {
            id: "APT-002",
            patient: "Carlos Oliveira",
            date: "2023-08-16T10:00:00",
            type: "Consulta inicial",
            isVirtual: false
          },
          {
            id: "APT-003",
            patient: "Maria Santos",
            date: "2023-08-17T16:15:00",
            type: "Acompanhamento",
            isVirtual: true
          }
        ],
        pendingPrescriptions: [
          {
            id: "PRES-001",
            patient: "Pedro Almeida",
            requestDate: "2023-08-10T09:45:00",
            status: "pending_review",
            urgency: "normal"
          },
          {
            id: "PRES-002",
            patient: "Juliana Costa",
            requestDate: "2023-08-11T14:20:00",
            status: "draft",
            urgency: "high"
          }
        ],
        recentPatients: [
          {
            id: "PAT-001",
            name: "Luiz Fernando",
            condition: "Epilepsia",
            lastAppointment: "2023-08-09T11:30:00"
          },
          {
            id: "PAT-002",
            name: "Fernanda Lima",
            condition: "Dor crônica",
            lastAppointment: "2023-08-08T16:45:00"
          },
          {
            id: "PAT-003",
            name: "Roberto Carlos",
            condition: "Insônia",
            lastAppointment: "2023-08-07T09:15:00"
          }
        ]
      });
      setIsLoading(false);
    }, 1000);
  };

  const handleOrgSelect = () => {
    if (!selectedOrg) {
      toast({
        title: "Seleção obrigatória",
        description: "Por favor, selecione uma organização para continuar",
        variant: "destructive"
      });
      return;
    }

    // Store selected organization
    const orgName = organizations.find(org => org.id === selectedOrg)?.name || "Organização";
    localStorage.setItem('mockOrgId', selectedOrg);
    localStorage.setItem('mockOrgName', orgName);
    localStorage.setItem('mockNeedsOrg', 'false');
    
    setShowOrgSelector(false);
    
    toast({
      title: "Organização selecionada",
      description: `Você selecionou ${orgName}`,
    });
    
    // Now load dashboard data
    loadDashboardData();
  };

  if (isLoading && !showOrgSelector) {
    return (
      <div className="h-screen flex flex-col items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        <p className="mt-4 text-gray-600">Carregando dados do painel médico...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Organization selector dialog */}
      <Dialog open={showOrgSelector} onOpenChange={setShowOrgSelector}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Selecione sua organização</DialogTitle>
            <DialogDescription>
              Por favor, selecione a organização que você está vinculado para continuar.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="organization">Organização</Label>
              <Select
                value={selectedOrg}
                onValueChange={setSelectedOrg}
              >
                <SelectTrigger id="organization">
                  <SelectValue placeholder="Selecione sua organização" />
                </SelectTrigger>
                <SelectContent>
                  {organizations.map((org) => (
                    <SelectItem key={org.id} value={org.id}>
                      {org.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" onClick={handleOrgSelect}>
              Confirmar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Custom header for medical control */}
      <header className="bg-white border-b border-gray-200 shadow-sm py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Link to={createPageUrl("Index")} className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <span className="text-blue-600 font-bold text-xl">E</span>
              </div>
              <span className="font-semibold text-xl">Endurancy</span>
            </Link>
            <span className="text-gray-400 mx-2">|</span>
            <span className="text-gray-600">Controle Médico</span>
          </div>
          
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              className="text-gray-600 border-blue-100 flex items-center gap-2"
              onClick={() => setShowOrgSelector(true)}
            >
              <Building2 className="w-4 h-4" />
              {dashboardData?.organization || "Selecionar organização"}
            </Button>
            
            <Button variant="ghost" size="sm" className="text-gray-600">
              <MessageSquare className="w-4 h-4 mr-2" />
              Suporte
            </Button>
            
            <div className="flex items-center gap-2 cursor-pointer p-1 rounded-lg hover:bg-gray-100">
              <Avatar className="w-8 h-8">
                {dashboardData?.doctor.photoUrl ? (
                  <AvatarImage src={dashboardData.doctor.photoUrl} alt={dashboardData.doctor.name} />
                ) : (
                  <AvatarFallback className="bg-blue-100 text-blue-700">
                    {dashboardData?.doctor.name?.substring(0, 2).toUpperCase() || "JS"}
                  </AvatarFallback>
                )}
              </Avatar>
              <div>
                <p className="text-sm font-medium">{dashboardData?.doctor.name || "Dr. João Silva"}</p>
                <p className="text-xs text-gray-500">{dashboardData?.doctor.role || "Médico Interno"}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {!dashboardData && !isLoading ? (
          <Card className="max-w-md mx-auto p-6 text-center">
            <CardHeader>
              <CardTitle>Bem-vindo ao Controle Médico</CardTitle>
              <CardDescription>
                Por favor, selecione uma organização para visualizar seus dados
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                onClick={() => setShowOrgSelector(true)}
                className="mt-4"
              >
                Selecionar organização
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-12 gap-6">
            {/* Sidebar navigation for medical control */}
            <aside className="col-span-12 md:col-span-3 lg:col-span-2">
              <nav className="bg-white rounded-lg shadow-sm p-4">
                <div className="space-y-1">
                  <Link to={createPageUrl("ControleMedico")} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-50 text-blue-700 font-medium">
                    <Stethoscope className="w-4 h-4" />
                    <span>Dashboard</span>
                  </Link>
                  <Link to={createPageUrl("PrescricoesClientes")} className="flex items-center gap-2 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-50 font-medium">
                    <FileCheck className="w-4 h-4" />
                    <span>Prescrições</span>
                  </Link>
                  <Link to={createPageUrl("CrmPacientes")} className="flex items-center gap-2 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-50 font-medium">
                    <Users className="w-4 h-4" />
                    <span>Pacientes</span>
                  </Link>
                  <Link to={createPageUrl("ConsultasMedicas")} className="flex items-center gap-2 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-50 font-medium">
                    <CalendarClock className="w-4 h-4" />
                    <span>Agenda</span>
                  </Link>
                  <Link to={createPageUrl("FinanceiroMedico")} className="flex items-center gap-2 px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-50 font-medium">
                    <BarChart3 className="w-4 h-4" />
                    <span>Financeiro</span>
                  </Link>
                  
                  <div className="pt-4 mt-4 border-t border-gray-200">
                    <Button 
                      variant="outline" 
                      className="w-full text-red-600 border-red-200 hover:bg-red-50"
                      onClick={() => {
                        localStorage.removeItem('mockUserType');
                        localStorage.removeItem('mockUserEmail');
                        localStorage.removeItem('mockUserName');
                        localStorage.removeItem('mockOrgId');
                        localStorage.removeItem('mockOrgName');
                        localStorage.removeItem('mockNeedsOrg');
                        window.location.href = window.location.origin + createPageUrl("Access");
                      }}
                    >
                      Sair
                    </Button>
                  </div>
                </div>
              </nav>
            </aside>

            {/* Main content */}
            <div className="col-span-12 md:col-span-9 lg:col-span-10">
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                <h1 className="text-2xl font-bold mb-2">Olá, Dr. {dashboardData?.doctor.name?.split(' ')[0] || "João"}!</h1>
                <p className="text-gray-600">Bem-vindo ao seu painel de controle médico em {dashboardData?.organization || "sua organização"}.</p>
              </div>

              {/* Stats cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <Card>
                  <CardContent className="p-6 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-500 mb-1">Pacientes Ativos</p>
                      <p className="text-2xl font-bold">{dashboardData?.stats.activePatients || 0}</p>
                    </div>
                    <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                      <UserCheck className="h-6 w-6 text-blue-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-500 mb-1">Prescrições Pendentes</p>
                      <p className="text-2xl font-bold">{dashboardData?.stats.pendingPrescriptions || 0}</p>
                    </div>
                    <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center">
                      <ClipboardList className="h-6 w-6 text-amber-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-500 mb-1">Consultas Agendadas</p>
                      <p className="text-2xl font-bold">{dashboardData?.stats.upcomingAppointments || 0}</p>
                    </div>
                    <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                      <Calendar className="h-6 w-6 text-green-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-500 mb-1">Prescrições do Mês</p>
                      <p className="text-2xl font-bold">{dashboardData?.stats.totalPrescriptionsMonth || 0}</p>
                    </div>
                    <div className="h-12 w-12 rounded-full bg-purple-100 flex items-center justify-center">
                      <FileText className="h-6 w-6 text-purple-600" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="mb-6">
                  <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                  <TabsTrigger value="appointments">Consultas</TabsTrigger>
                  <TabsTrigger value="prescriptions">Prescrições</TabsTrigger>
                  <TabsTrigger value="patients">Pacientes</TabsTrigger>
                </TabsList>

                <TabsContent value="overview">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg flex items-center justify-between">
                          <span className="flex items-center gap-2">
                            <Calendar className="w-5 h-5 text-blue-600" /> 
                            Próximas Consultas
                          </span>
                          <Badge className="bg-blue-100 text-blue-800">Hoje</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {dashboardData?.upcomingAppointments && dashboardData.upcomingAppointments.length > 0 ? (
                          <div className="space-y-4">
                            {dashboardData.upcomingAppointments.map((appointment) => (
                              <div key={appointment.id} className="flex justify-between items-center p-3 border border-gray-100 rounded-lg">
                                <div>
                                  <p className="font-medium">{appointment.patient}</p>
                                  <div className="flex items-center gap-2 mt-1">
                                    <Badge variant="outline" className="text-xs font-normal">
                                      {appointment.type}
                                    </Badge>
                                    <span className="text-sm text-gray-500">
                                      {new Date(appointment.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                    </span>
                                  </div>
                                </div>
                                <Badge className={appointment.isVirtual ? 
                                  "bg-indigo-100 text-indigo-800" : "bg-purple-100 text-purple-800"}>
                                  {appointment.isVirtual ? "Telemedicina" : "Presencial"}
                                </Badge>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-4">
                            <p className="text-gray-500 mb-4">Nenhuma consulta agendada</p>
                            <Button variant="outline" className="text-blue-700 border-blue-200">
                              <Calendar className="w-4 h-4 mr-2" /> Ver agenda
                            </Button>
                          </div>
                        )}
                        <div className="mt-4">
                          <Link to={createPageUrl("ConsultasMedicas")}>
                            <Button variant="ghost" className="text-blue-700 hover:text-blue-800 hover:bg-blue-50 p-0 flex items-center gap-1">
                              Ver agenda completa <ChevronRight className="w-4 h-4" />
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg flex items-center justify-between">
                          <span className="flex items-center gap-2">
                            <ClipboardList className="w-5 h-5 text-blue-600" /> 
                            Prescrições Pendentes
                          </span>
                          <Badge className="bg-amber-100 text-amber-800">{dashboardData?.stats.pendingPrescriptions || 0} pendentes</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {dashboardData?.pendingPrescriptions && dashboardData.pendingPrescriptions.length > 0 ? (
                          <div className="space-y-4">
                            {dashboardData.pendingPrescriptions.map((prescription) => (
                              <div key={prescription.id} className="flex justify-between items-center p-3 border border-gray-100 rounded-lg">
                                <div>
                                  <p className="font-medium">{prescription.patient}</p>
                                  <div className="flex items-center gap-2 mt-1">
                                    <span className="text-sm text-gray-500">
                                      {new Date(prescription.requestDate).toLocaleDateString()}
                                    </span>
                                    {prescription.urgency === 'high' && (
                                      <Badge className="bg-red-100 text-red-800">Urgente</Badge>
                                    )}
                                  </div>
                                </div>
                                <Badge className={
                                  prescription.status === 'pending_review' 
                                    ? "bg-amber-100 text-amber-800" 
                                    : "bg-blue-100 text-blue-800"
                                }>
                                  {prescription.status === 'pending_review' ? "Revisão Pendente" : "Rascunho"}
                                </Badge>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-4">
                            <p className="text-gray-500 mb-4">Nenhuma prescrição pendente</p>
                            <Button variant="outline" className="text-blue-700 border-blue-200">
                              <Plus className="w-4 h-4 mr-2" /> Nova prescrição
                            </Button>
                          </div>
                        )}
                        <div className="mt-4">
                          <Link to={createPageUrl("PrescricoesClientes")}>
                            <Button variant="ghost" className="text-blue-700 hover:text-blue-800 hover:bg-blue-50 p-0 flex items-center gap-1">
                              Ver todas prescrições <ChevronRight className="w-4 h-4" />
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="grid grid-cols-1 gap-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg flex items-center">
                          <Users className="w-5 h-5 text-blue-600 mr-2" /> 
                          Pacientes Recentes
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {dashboardData?.recentPatients && dashboardData.recentPatients.length > 0 ? (
                          <div className="divide-y">
                            {dashboardData.recentPatients.map((patient) => (
                              <div key={patient.id} className="flex justify-between items-center py-4">
                                <div>
                                  <p className="font-medium">{patient.name}</p>
                                  <div className="flex items-center gap-2 mt-1">
                                    <Badge variant="outline" className="text-xs font-normal">
                                      {patient.condition}
                                    </Badge>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="text-sm text-gray-500">
                                    Última consulta: {new Date(patient.lastAppointment).toLocaleDateString()}
                                  </span>
                                  <Button variant="ghost" size="icon" className="text-gray-500 hover:text-blue-600">
                                    <ChevronRight className="w-5 h-5" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-4">
                            <p className="text-gray-500">Nenhum paciente recente</p>
                          </div>
                        )}
                        <div className="mt-4">
                          <Link to={createPageUrl("CrmPacientes")}>
                            <Button variant="ghost" className="text-blue-700 hover:text-blue-800 hover:bg-blue-50 p-0 flex items-center gap-1">
                              Ver todos pacientes <ChevronRight className="w-4 h-4" />
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="appointments">
                  <Card>
                    <CardHeader>
                      <CardTitle>Agenda de Consultas</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Link to={createPageUrl("ConsultasMedicas")}>
                        <Button>Ver agenda completa</Button>
                      </Link>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="prescriptions">
                  <Card>
                    <CardHeader>
                      <CardTitle>Prescrições</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Link to={createPageUrl("PrescricoesClientes")}>
                        <Button>Ver todas prescrições</Button>
                      </Link>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="patients">
                  <Card>
                    <CardHeader>
                      <CardTitle>Pacientes</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Link to={createPageUrl("CrmPacientes")}>
                        <Button>Ver todos pacientes</Button>
                      </Link>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}