import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Representante } from '@/api/entities';
import { Medico } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";
import { ArrowLeft, Save, Plus, Trash2, ArrowRight, PlusCircle, UserCog, UserPlus, DollarSign } from "lucide-react";

export default function NovoRepresentante() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const representanteId = searchParams.get('id');
  const isEditing = !!representanteId;

  const [formData, setFormData] = useState({
    nome_completo: '',
    email: '',
    cpf: '',
    telefone: '',
    endereco: {
      cep: '',
      logradouro: '',
      numero: '',
      complemento: '',
      bairro: '',
      cidade: '',
      estado: ''
    },
    tipo_vinculo: 'autonomo',
    percentual_comissao: 5,
    regiao_atuacao: [],
    dados_bancarios: {
      banco: '',
      agencia: '',
      conta: '',
      tipo_conta: 'corrente',
      pix: ''
    },
    medicos_cadastrados: [],
    status: 'ativo'
  });

  const [novaRegiao, setNovaRegiao] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState("informacoes-basicas");
  const [medicosSistema, setMedicosSistema] = useState([]);
  const [medicoSelecionado, setMedicoSelecionado] = useState('');
  const [percentualComissaoMedico, setPercentualComissaoMedico] = useState(3);

  useEffect(() => {
    if (isEditing) {
      loadRepresentante();
    }
    loadMedicosSistema();
  }, [representanteId]);

  const loadRepresentante = async () => {
    try {
      setIsLoading(true);
      const representante = await Representante.get(representanteId);
      setFormData({
        ...representante,
        endereco: representante.endereco || {
          cep: '',
          logradouro: '',
          numero: '',
          complemento: '',
          bairro: '',
          cidade: '',
          estado: ''
        },
        dados_bancarios: representante.dados_bancarios || {
          banco: '',
          agencia: '',
          conta: '',
          tipo_conta: 'corrente',
          pix: ''
        },
        regiao_atuacao: representante.regiao_atuacao || [],
        medicos_cadastrados: representante.medicos_cadastrados || []
      });
    } catch (error) {
      console.error('Erro ao carregar dados do representante:', error);
      toast({
        title: "Erro ao carregar dados",
        description: "Não foi possível carregar os dados do representante.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadMedicosSistema = async () => {
    try {
      const medicos = await Medico.list();
      setMedicosSistema(medicos);
    } catch (error) {
      console.error('Erro ao carregar médicos:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAddressChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      endereco: {
        ...prev.endereco,
        [name]: value
      }
    }));
  };

  const handleBankDataChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      dados_bancarios: {
        ...prev.dados_bancarios,
        [name]: value
      }
    }));
  };

  const handleAddRegiao = () => {
    if (novaRegiao.trim()) {
      setFormData(prev => ({
        ...prev,
        regiao_atuacao: [...prev.regiao_atuacao, novaRegiao.trim()]
      }));
      setNovaRegiao('');
    }
  };

  const handleRemoveRegiao = (index) => {
    setFormData(prev => ({
      ...prev,
      regiao_atuacao: prev.regiao_atuacao.filter((_, i) => i !== index)
    }));
  };

  const handleAddMedico = async () => {
    if (!medicoSelecionado) return;
    
    const medicoJaExiste = formData.medicos_cadastrados.some(
      medico => medico.medico_id === medicoSelecionado
    );
    
    if (medicoJaExiste) {
      toast({
        title: "Médico já adicionado",
        description: "Este médico já está associado a este representante.",
        variant: "destructive"
      });
      return;
    }
    
    const medicoData = medicosSistema.find(medico => medico.id === medicoSelecionado);
    if (!medicoData) return;
    
    const novoMedico = {
      medico_id: medicoData.id,
      nome_medico: medicoData.nome_completo,
      crm: medicoData.crm,
      uf_crm: medicoData.uf_crm,
      data_cadastro: new Date().toISOString(),
      percentual_comissao_especial: percentualComissaoMedico
    };
    
    setFormData(prev => ({
      ...prev,
      medicos_cadastrados: [...prev.medicos_cadastrados, novoMedico]
    }));

    // Atualiza também o médico para refletir o representante
    try {
      await Medico.update(medicoData.id, {
        representante_id: isEditing ? representanteId : null,  // Será atualizado após a criação
        percentual_comissao_representante: percentualComissaoMedico
      });
    } catch (error) {
      console.error('Erro ao atualizar médico:', error);
    }
    
    setMedicoSelecionado('');
    setPercentualComissaoMedico(3);
  };

  const handleRemoveMedico = async (index) => {
    const medicoRemovido = formData.medicos_cadastrados[index];
    
    setFormData(prev => ({
      ...prev,
      medicos_cadastrados: prev.medicos_cadastrados.filter((_, i) => i !== index)
    }));

    // Atualiza o médico para remover a associação com o representante
    try {
      await Medico.update(medicoRemovido.medico_id, {
        representante_id: null,
        percentual_comissao_representante: 0
      });
    } catch (error) {
      console.error('Erro ao atualizar médico:', error);
    }
  };

  const lookupAddressByCep = async () => {
    const cep = formData.endereco.cep.replace(/\D/g, '');
    if (cep.length !== 8) return;

    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await response.json();
      
      if (!data.erro) {
        setFormData(prev => ({
          ...prev,
          endereco: {
            ...prev.endereco,
            logradouro: data.logradouro,
            bairro: data.bairro,
            cidade: data.localidade,
            estado: data.uf
          }
        }));
      }
    } catch (error) {
      console.error('Erro ao buscar CEP:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const dataToSubmit = {
        ...formData,
        data_cadastro: formData.data_cadastro || new Date().toISOString()
      };

      if (isEditing) {
        await Representante.update(representanteId, dataToSubmit);
        
        // Atualiza os médicos para refletir a associação
        for (const medico of formData.medicos_cadastrados) {
          await Medico.update(medico.medico_id, {
            representante_id: representanteId,
            percentual_comissao_representante: medico.percentual_comissao_especial
          });
        }
        
        toast({
          title: "Representante atualizado",
          description: "Os dados do representante foram atualizados com sucesso.",
        });
      } else {
        const novoRepresentante = await Representante.create(dataToSubmit);
        
        // Atualiza os médicos com o ID do novo representante
        for (const medico of formData.medicos_cadastrados) {
          await Medico.update(medico.medico_id, {
            representante_id: novoRepresentante.id,
            percentual_comissao_representante: medico.percentual_comissao_especial
          });
        }
        
        toast({
          title: "Representante cadastrado",
          description: "O representante foi cadastrado com sucesso.",
        });
      }
      
      navigate(createPageUrl('Representantes'));
    } catch (error) {
      console.error('Erro ao salvar representante:', error);
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar os dados do representante.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin h-12 w-12 border-4 border-green-500 rounded-full border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto py-6">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate(createPageUrl('Representantes'))}
          className="mr-4"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">{isEditing ? 'Editar Representante' : 'Cadastrar Novo Representante'}</h1>
          <p className="text-gray-500 mt-1">
            {isEditing 
              ? 'Atualize os dados do representante de vendas' 
              : 'Preencha os dados para cadastrar um novo representante de vendas'}
          </p>
        </div>
      </div>
      
      <form onSubmit={handleSubmit}>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="informacoes-basicas">Informações Básicas</TabsTrigger>
            <TabsTrigger value="financeiro">Dados Financeiros</TabsTrigger>
            <TabsTrigger value="medicos">Médicos Associados</TabsTrigger>
          </TabsList>
          
          <TabsContent value="informacoes-basicas" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Dados Pessoais</CardTitle>
                <CardDescription>Informações básicas do representante</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nome_completo">Nome Completo *</Label>
                    <Input 
                      id="nome_completo" 
                      name="nome_completo" 
                      value={formData.nome_completo} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input 
                      id="email" 
                      name="email" 
                      type="email"
                      value={formData.email} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="telefone">Telefone *</Label>
                    <Input 
                      id="telefone" 
                      name="telefone" 
                      value={formData.telefone} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="cpf">CPF *</Label>
                    <Input 
                      id="cpf" 
                      name="cpf" 
                      value={formData.cpf} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tipo_vinculo">Tipo de Vínculo *</Label>
                    <Select 
                      value={formData.tipo_vinculo} 
                      onValueChange={(value) => setFormData({...formData, tipo_vinculo: value})} 
                      required
                    >
                      <SelectTrigger id="tipo_vinculo">
                        <SelectValue placeholder="Selecione o tipo de vínculo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="clt">CLT</SelectItem>
                        <SelectItem value="pj">Pessoa Jurídica</SelectItem>
                        <SelectItem value="autonomo">Autônomo</SelectItem>
                        <SelectItem value="parceiro">Parceiro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status *</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(value) => setFormData({...formData, status: value})} 
                    required
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                      <SelectItem value="suspenso">Suspenso</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Endereço</CardTitle>
                <CardDescription>Informações de localização do representante</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="cep">CEP</Label>
                    <div className="flex gap-2">
                      <Input 
                        id="cep" 
                        name="cep" 
                        value={formData.endereco?.cep} 
                        onChange={handleAddressChange} 
                      />
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={lookupAddressByCep}
                      >
                        Buscar
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="logradouro">Logradouro</Label>
                    <Input 
                      id="logradouro" 
                      name="logradouro" 
                      value={formData.endereco?.logradouro} 
                      onChange={handleAddressChange} 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="numero">Número</Label>
                    <Input 
                      id="numero" 
                      name="numero" 
                      value={formData.endereco?.numero} 
                      onChange={handleAddressChange} 
                    />
                  </div>
                  <div className="md:col-span-2 space-y-2">
                    <Label htmlFor="complemento">Complemento</Label>
                    <Input 
                      id="complemento" 
                      name="complemento" 
                      value={formData.endereco?.complemento} 
                      onChange={handleAddressChange} 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="bairro">Bairro</Label>
                    <Input 
                      id="bairro" 
                      name="bairro" 
                      value={formData.endereco?.bairro} 
                      onChange={handleAddressChange} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cidade">Cidade</Label>
                    <Input 
                      id="cidade" 
                      name="cidade" 
                      value={formData.endereco?.cidade} 
                      onChange={handleAddressChange} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="estado">Estado</Label>
                    <Select 
                      value={formData.endereco?.estado} 
                      onValueChange={(value) => setFormData({
                        ...formData, 
                        endereco: {...formData.endereco, estado: value}
                      })}
                    >
                      <SelectTrigger id="estado">
                        <SelectValue placeholder="UF" />
                      </SelectTrigger>
                      <SelectContent>
                        {["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"].map((uf) => (
                          <SelectItem key={uf} value={uf}>{uf}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Regiões de Atuação</CardTitle>
                <CardDescription>Defina as regiões onde este representante atua</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {formData.regiao_atuacao?.map((regiao, index) => (
                    <Badge key={index} className="flex items-center gap-1">
                      {regiao}
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 rounded-full"
                        onClick={() => handleRemoveRegiao(index)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </Badge>
                  ))}
                </div>
                <div className="flex">
                  <Input
                    placeholder="Adicionar região (ex: São Paulo, Zona Sul, etc.)"
                    value={novaRegiao}
                    onChange={(e) => setNovaRegiao(e.target.value)}
                    className="mr-2"
                  />
                  <Button 
                    type="button" 
                    size="icon" 
                    onClick={handleAddRegiao}
                    disabled={!novaRegiao.trim()}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex justify-end">
              <Button 
                type="button" 
                onClick={() => setActiveTab("financeiro")}
                className="ml-auto"
              >
                Próximo
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="financeiro" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Percentual de Comissão</CardTitle>
                <CardDescription>Configure o percentual padrão de comissão do representante</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="percentual_comissao">Percentual de Comissão Padrão (%)*</Label>
                  <Input 
                    id="percentual_comissao" 
                    name="percentual_comissao" 
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={formData.percentual_comissao} 
                    onChange={handleChange} 
                    required 
                  />
                  <p className="text-xs text-gray-500">
                    Este percentual será aplicado para todas as vendas realizadas por este representante, 
                    exceto para as vendas provenientes de médicos onde há um percentual específico definido.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Dados Bancários</CardTitle>
                <CardDescription>Informações bancárias para pagamento de comissões</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="banco">Banco</Label>
                    <Input 
                      id="banco" 
                      name="banco" 
                      value={formData.dados_bancarios?.banco} 
                      onChange={handleBankDataChange} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="agencia">Agência</Label>
                    <Input 
                      id="agencia" 
                      name="agencia" 
                      value={formData.dados_bancarios?.agencia} 
                      onChange={handleBankDataChange} 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="conta">Conta</Label>
                    <Input 
                      id="conta" 
                      name="conta" 
                      value={formData.dados_bancarios?.conta} 
                      onChange={handleBankDataChange} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tipo_conta">Tipo de Conta</Label>
                    <Select 
                      value={formData.dados_bancarios?.tipo_conta} 
                      onValueChange={(value) => setFormData({
                        ...formData, 
                        dados_bancarios: {...formData.dados_bancarios, tipo_conta: value}
                      })}
                    >
                      <SelectTrigger id="tipo_conta">
                        <SelectValue placeholder="Selecione o tipo de conta" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="corrente">Conta Corrente</SelectItem>
                        <SelectItem value="poupanca">Conta Poupança</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="pix">Chave PIX</Label>
                  <Input 
                    id="pix" 
                    name="pix" 
                    value={formData.dados_bancarios?.pix} 
                    onChange={handleBankDataChange} 
                  />
                </div>
              </CardContent>
            </Card>
            
            <div className="flex justify-between">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setActiveTab("informacoes-basicas")}
              >
                Anterior
              </Button>
              <Button 
                type="button" 
                onClick={() => setActiveTab("medicos")}
              >
                Próximo
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="medicos" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Médicos Associados</CardTitle>
                <CardDescription>
                  Médicos cadastrados por este representante. O representante receberá comissão pelas vendas dos pacientes destes médicos.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-col gap-4">
                  {formData.medicos_cadastrados && formData.medicos_cadastrados.length > 0 ? (
                    <div className="space-y-4">
                      {formData.medicos_cadastrados.map((medico, index) => (
                        <div key={index} className="flex justify-between items-center border p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
                          <div>
                            <div className="font-medium">{medico.nome_medico}</div>
                            <div className="text-sm text-gray-500 flex space-x-3">
                              <span>CRM: {medico.crm}/{medico.uf_crm}</span>
                              <span>•</span>
                              <span className="flex items-center">
                                <DollarSign className="h-3 w-3 mr-1" />
                                Comissão: {medico.percentual_comissao_especial}%
                              </span>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-500 hover:text-red-700"
                            onClick={() => handleRemoveMedico(index)}
                            title="Remover médico"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center p-6 border border-dashed rounded-lg">
                      <UserCog className="mx-auto h-10 w-10 text-gray-400 mb-2" />
                      <h3 className="text-lg font-medium text-gray-600 dark:text-gray-300">Nenhum médico associado</h3>
                      <p className="text-gray-500 text-sm mt-1">
                        Associe médicos a este representante para rastrear comissões pelas vendas.
                      </p>
                    </div>
                  )}

                  <div className="border-t pt-4 mt-2">
                    <h3 className="font-medium mb-3">Adicionar Médico</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="md:col-span-2 space-y-2">
                        <Label htmlFor="medico">Selecionar Médico</Label>
                        <Select
                          value={medicoSelecionado}
                          onValueChange={setMedicoSelecionado}
                        >
                          <SelectTrigger id="medico">
                            <SelectValue placeholder="Selecione um médico para associar" />
                          </SelectTrigger>
                          <SelectContent>
                            {medicosSistema
                              .filter(medico => 
                                !formData.medicos_cadastrados?.some(m => m.medico_id === medico.id)
                              )
                              .map((medico) => (
                                <SelectItem key={medico.id} value={medico.id}>
                                  {medico.nome_completo} - CRM: {medico.crm}/{medico.uf_crm}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="percentual_comissao_medico">Comissão (%)</Label>
                        <Input
                          id="percentual_comissao_medico"
                          type="number"
                          min="0"
                          max="100"
                          step="0.1"
                          value={percentualComissaoMedico}
                          onChange={(e) => setPercentualComissaoMedico(Number(e.target.value))}
                        />
                      </div>
                      <div className="md:col-span-3">
                        <Button
                          type="button"
                          onClick={handleAddMedico}
                          disabled={!medicoSelecionado}
                          className="w-full"
                        >
                          <UserPlus className="mr-2 h-4 w-4" />
                          Adicionar Médico
                        </Button>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Se o médico que deseja associar não está na lista, primeiro cadastre-o no sistema através da seção "Cadastro de Médicos".
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex justify-between">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setActiveTab("financeiro")}
              >
                Anterior
              </Button>
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="flex gap-2 items-center"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin h-4 w-4 border-2 border-white rounded-full border-t-transparent"></div>
                    <span>Salvando...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Salvar</span>
                  </>
                )}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </form>
    </div>
  );
}