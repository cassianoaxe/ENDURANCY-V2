import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Save, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function NovoConteudo() {
  const navigate = useNavigate();

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate(createPageUrl('BibliotecaEducativa'))}
          className="mr-4"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">Novo Conteúdo Educativo</h1>
          <p className="text-gray-500 mt-1">
            Crie conteúdo educativo para pacientes e profissionais
          </p>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Informações do Conteúdo</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Página em desenvolvimento. Em breve você poderá adicionar novos conteúdos educativos.</p>
          <div className="flex justify-end mt-6 space-x-2">
            <Button variant="outline" onClick={() => navigate(createPageUrl('BibliotecaEducativa'))}>
              Cancelar
            </Button>
            <Button>
              <Send className="mr-2 h-4 w-4" />
              Publicar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}