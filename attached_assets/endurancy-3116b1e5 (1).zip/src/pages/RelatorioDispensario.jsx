
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { toast } from "@/components/ui/use-toast";
import { User } from '@/api/entities';
import { Venda } from '@/api/entities';
import { EstoqueDispensario } from '@/api/entities';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  LineChart,
  Printer,
  Download,
  Calendar,
  FileText,
  BarChart2,
  DollarSign,
  Package,
  ArrowUpDown,
  RefreshCw,
  Filter,
  ShoppingBag,
  ChevronDown,
  FileDown,
  Info
} from 'lucide-react';
import { format, subDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function RelatorioDispensario() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [vendas, setVendas] = useState([]);
  const [produtosMaisVendidos, setProdutosMaisVendidos] = useState([]);
  const [periodoRelatorio, setPeriodoRelatorio] = useState("hoje");
  const [dataInicio, setDataInicio] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [dataFim, setDataFim] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [tipoRelatorio, setTipoRelatorio] = useState("vendas");
  const [isExporting, setIsExporting] = useState(false);
  const [resumoVendas, setResumoVendas] = useState({
    total_vendas: 0,
    ticket_medio: 0,
    total_itens: 0,
    vendas_por_forma_pagamento: {
      dinheiro: 0,
      cartao_credito: 0,
      cartao_debito: 0,
      pix: 0
    }
  });

  useEffect(() => {
    const loadData = () => {
      try {
        const userType = localStorage.getItem('mockUserType');
        if (!userType) {
          console.log("User not authenticated, redirecting to login");
          navigate(createPageUrl("Access"));
          return;
        }

        const mockVendas = [
          {
            id: "venda1",
            numero_venda: "V-0001",
            data_venda: new Date().toISOString(),
            total: 85.90,
            items: [
              { produto_id: "p1", nome_produto: "Produto 1", quantidade: 2, valor_unitario: 25.50, valor_total: 51.00 },
              { produto_id: "p2", nome_produto: "Produto 2", quantidade: 1, valor_unitario: 34.90, valor_total: 34.90 }
            ],
            pagamento: { forma: "dinheiro" }
          },
          {
            id: "venda2",
            numero_venda: "V-0002",
            data_venda: new Date().toISOString(),
            total: 145.80,
            items: [
              { produto_id: "p3", nome_produto: "Produto 3", quantidade: 1, valor_unitario: 99.90, valor_total: 99.90 },
              { produto_id: "p1", nome_produto: "Produto 1", quantidade: 1, valor_unitario: 25.50, valor_total: 25.50 },
              { produto_id: "p4", nome_produto: "Produto 4", quantidade: 1, valor_unitario: 20.40, valor_total: 20.40 }
            ],
            pagamento: { forma: "cartao_credito" }
          }
        ];

        const mockProdutosMaisVendidos = [
          { produto_id: "p1", nome: "Produto 1", quantidade_vendida: 3, valor_total: 76.50 },
          { produto_id: "p3", nome: "Produto 3", quantidade_vendida: 1, valor_total: 99.90 },
          { produto_id: "p2", nome: "Produto 2", quantidade_vendida: 1, valor_total: 34.90 },
          { produto_id: "p4", nome: "Produto 4", quantidade_vendida: 1, valor_total: 20.40 }
        ];

        setVendas(mockVendas);
        setProdutosMaisVendidos(mockProdutosMaisVendidos);
        calcularResumoVendas(mockVendas);
        setIsLoading(false);
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar os relatórios.",
          variant: "destructive",
        });
      }
    };

    loadData();
  }, [navigate]);

  const calcularResumoVendas = (vendasData) => {
    if (!vendasData || vendasData.length === 0) {
      setResumoVendas({
        total_vendas: 0,
        ticket_medio: 0,
        total_itens: 0,
        vendas_por_forma_pagamento: {
          dinheiro: 0,
          cartao_credito: 0,
          cartao_debito: 0,
          pix: 0
        }
      });
      return;
    }

    const totalVendas = vendasData.reduce((acc, venda) => acc + venda.total, 0);

    const totalItens = vendasData.reduce((acc, venda) => 
      acc + venda.items.reduce((itemAcc, item) => itemAcc + item.quantidade, 0), 0);
    
    const ticketMedio = vendasData.length > 0 ? totalVendas / vendasData.length : 0;
    
    const vendasPorFormaPagamento = {
      dinheiro: 0,
      cartao_credito: 0,
      cartao_debito: 0,
      pix: 0
    };

    vendasData.forEach(venda => {
      const formaPagamento = venda.pagamento?.forma || 'dinheiro';
      vendasPorFormaPagamento[formaPagamento] = (vendasPorFormaPagamento[formaPagamento] || 0) + venda.total;
    });

    setResumoVendas({
      total_vendas: totalVendas,
      ticket_medio: ticketMedio,
      total_itens: totalItens,
      vendas_por_forma_pagamento: vendasPorFormaPagamento
    });
  };

  const formatMoney = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Relatórios do Dispensário</h1>
          <p className="text-gray-500">Análise de vendas, estoque e movimentações</p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            onClick={() => {
              setIsExporting(true);
              setTimeout(() => {
                toast({
                  title: "Relatório exportado",
                  description: "O relatório foi exportado com sucesso.",
                });
                setIsExporting(false);
              }, 1500);
            }}
            disabled={isExporting}
          >
            {isExporting ? (
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Download className="mr-2 h-4 w-4" />
            )}
            Exportar
          </Button>
          <Button variant="outline">
            <Printer className="mr-2 h-4 w-4" />
            Imprimir
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filtros do Relatório</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="tipo-relatorio">Tipo de Relatório</Label>
              <Select value={tipoRelatorio} onValueChange={setTipoRelatorio}>
                <SelectTrigger id="tipo-relatorio">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="vendas">Vendas</SelectItem>
                  <SelectItem value="produtos">Produtos Mais Vendidos</SelectItem>
                  <SelectItem value="pagamentos">Formas de Pagamento</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="periodo-relatorio">Período</Label>
              <Select value={periodoRelatorio} onValueChange={setPeriodoRelatorio}>
                <SelectTrigger id="periodo-relatorio">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hoje">Hoje</SelectItem>
                  <SelectItem value="ontem">Ontem</SelectItem>
                  <SelectItem value="semana">Esta Semana</SelectItem>
                  <SelectItem value="mes">Este Mês</SelectItem>
                  <SelectItem value="personalizado">Personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="data-inicio">Data Início</Label>
              <Input 
                id="data-inicio" 
                type="date" 
                value={dataInicio} 
                onChange={(e) => {
                  setDataInicio(e.target.value);
                  setPeriodoRelatorio("personalizado");
                }}
              />
            </div>
            
            <div>
              <Label htmlFor="data-fim">Data Fim</Label>
              <Input 
                id="data-fim" 
                type="date" 
                value={dataFim} 
                onChange={(e) => {
                  setDataFim(e.target.value);
                  setPeriodoRelatorio("personalizado");
                }}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total de Vendas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatMoney(resumoVendas.total_vendas)}</div>
            <p className="text-xs text-gray-500">
              {vendas.length} vendas no período
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Ticket Médio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatMoney(resumoVendas.ticket_medio)}</div>
            <p className="text-xs text-gray-500">
              Valor médio por venda
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total de Itens</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{resumoVendas.total_itens}</div>
            <p className="text-xs text-gray-500">
              Produtos vendidos no período
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Forma de Pagamento</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Dinheiro:</span>
                <span className="font-medium">{formatMoney(resumoVendas.vendas_por_forma_pagamento.dinheiro)}</span>
              </div>
              <div className="flex justify-between">
                <span>Cartão de Crédito:</span>
                <span className="font-medium">{formatMoney(resumoVendas.vendas_por_forma_pagamento.cartao_credito)}</span>
              </div>
              <div className="flex justify-between">
                <span>Cartão de Débito:</span>
                <span className="font-medium">{formatMoney(resumoVendas.vendas_por_forma_pagamento.cartao_debito)}</span>
              </div>
              <div className="flex justify-between">
                <span>PIX:</span>
                <span className="font-medium">{formatMoney(resumoVendas.vendas_por_forma_pagamento.pix)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={tipoRelatorio} onValueChange={setTipoRelatorio} className="space-y-4">
        <TabsList>
          <TabsTrigger value="vendas" className="flex items-center gap-2">
            <BarChart className="h-4 w-4" />
            Vendas
          </TabsTrigger>
          <TabsTrigger value="produtos" className="flex items-center gap-2">
            <Package className="h-4 w-4" />
            Produtos Mais Vendidos
          </TabsTrigger>
          <TabsTrigger value="pagamentos" className="flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            Formas de Pagamento
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="vendas">
          <Card>
            <CardHeader>
              <CardTitle>Vendas no Período</CardTitle>
              <CardDescription>
                Relatório de vendas de {format(new Date(dataInicio), 'dd/MM/yyyy')} a {format(new Date(dataFim), 'dd/MM/yyyy')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Código</TableHead>
                      <TableHead>Data/Hora</TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Itens</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Forma Pagamento</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          <RefreshCw className="h-6 w-6 animate-spin mx-auto text-gray-400" />
                        </TableCell>
                      </TableRow>
                    ) : vendas.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          <div className="flex flex-col items-center gap-2">
                            <Info className="h-8 w-8 text-gray-400" />
                            <p className="text-gray-500">Nenhuma venda no período selecionado</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      vendas.map((venda) => (
                        <TableRow key={venda.id}>
                          <TableCell>{venda.numero_venda}</TableCell>
                          <TableCell>
                            {format(new Date(venda.data_venda), 'dd/MM/yyyy HH:mm')}
                          </TableCell>
                          <TableCell>
                            {venda.cliente?.nome || 'Cliente não identificado'}
                          </TableCell>
                          <TableCell>
                            {venda.items?.reduce((acc, item) => acc + item.quantidade, 0) || 0}
                          </TableCell>
                          <TableCell className="font-medium">
                            {formatMoney(venda.total)}
                          </TableCell>
                          <TableCell>
                            {venda.pagamento?.forma === 'dinheiro' && 'Dinheiro'}
                            {venda.pagamento?.forma === 'cartao_credito' && 'Cartão de Crédito'}
                            {venda.pagamento?.forma === 'cartao_debito' && 'Cartão de Débito'}
                            {venda.pagamento?.forma === 'pix' && 'PIX'}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="produtos">
          <Card>
            <CardHeader>
              <CardTitle>Produtos Mais Vendidos</CardTitle>
              <CardDescription>
                Ranking dos produtos mais vendidos no período
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">#</TableHead>
                      <TableHead>Produto</TableHead>
                      <TableHead>Quantidade</TableHead>
                      <TableHead>Valor Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-8">
                          <RefreshCw className="h-6 w-6 animate-spin mx-auto text-gray-400" />
                        </TableCell>
                      </TableRow>
                    ) : produtosMaisVendidos.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-8">
                          <div className="flex flex-col items-center gap-2">
                            <Info className="h-8 w-8 text-gray-400" />
                            <p className="text-gray-500">Nenhuma venda no período selecionado</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      produtosMaisVendidos.map((produto, index) => (
                        <TableRow key={produto.produto_id}>
                          <TableCell>{index + 1}</TableCell>
                          <TableCell>{produto.nome}</TableCell>
                          <TableCell>{produto.quantidade_vendida}</TableCell>
                          <TableCell>{formatMoney(produto.valor_total)}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="pagamentos">
          <Card>
            <CardHeader>
              <CardTitle>Vendas por Forma de Pagamento</CardTitle>
              <CardDescription>
                Distribuição de vendas por forma de pagamento no período
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-4">
                    {Object.entries(resumoVendas.vendas_por_forma_pagamento).map(([forma, valor]) => (
                      <div key={forma} className="flex items-center gap-2">
                        <div 
                          className="h-full w-3 rounded-full"
                          style={{ 
                            backgroundColor: 
                              forma === 'dinheiro' ? '#10b981' :
                              forma === 'cartao_credito' ? '#3b82f6' :
                              forma === 'cartao_debito' ? '#8b5cf6' : 
                              '#ec4899'
                          }}
                        />
                        <div className="flex-1">
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium">
                              {forma === 'dinheiro' ? 'Dinheiro' :
                              forma === 'cartao_credito' ? 'Cartão de Crédito' :
                              forma === 'cartao_debito' ? 'Cartão de Débito' : 
                              'PIX'}
                            </span>
                            <span className="text-sm">{formatMoney(valor)}</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div 
                              className="h-2.5 rounded-full"
                              style={{
                                width: `${(valor / resumoVendas.total_vendas * 100) || 0}%`,
                                backgroundColor: 
                                  forma === 'dinheiro' ? '#10b981' :
                                  forma === 'cartao_credito' ? '#3b82f6' :
                                  forma === 'cartao_debito' ? '#8b5cf6' : 
                                  '#ec4899'
                              }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-lg font-medium mb-4">Estatísticas</h3>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-gray-500">Total de vendas</p>
                        <p className="text-xl font-semibold">{formatMoney(resumoVendas.total_vendas)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Número de vendas</p>
                        <p className="text-xl font-semibold">{vendas.length}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Forma de pagamento mais utilizada</p>
                        <p className="text-xl font-semibold">
                          {Object.entries(resumoVendas.vendas_por_forma_pagamento)
                            .sort((a, b) => b[1] - a[1])[0]?.[0] === 'dinheiro' ? 'Dinheiro' :
                          Object.entries(resumoVendas.vendas_por_forma_pagamento)
                            .sort((a, b) => b[1] - a[1])[0]?.[0] === 'cartao_credito' ? 'Cartão de Crédito' :
                          Object.entries(resumoVendas.vendas_por_forma_pagamento)
                            .sort((a, b) => b[1] - a[1])[0]?.[0] === 'cartao_debito' ? 'Cartão de Débito' : 
                          'PIX'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Relatório Detalhado</h3>
                  
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Forma de Pagamento</TableHead>
                        <TableHead>Vendas</TableHead>
                        <TableHead>Percentual</TableHead>
                        <TableHead>Valor Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isLoading ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center py-4">
                            <RefreshCw className="h-6 w-6 animate-spin mx-auto text-gray-400" />
                          </TableCell>
                        </TableRow>
                      ) : (
                        Object.entries(resumoVendas.vendas_por_forma_pagamento).map(([forma, valor]) => {
                          const count = vendas.filter(v => v.pagamento?.forma === forma).length;
                          const percent = resumoVendas.total_vendas > 0 
                            ? (valor / resumoVendas.total_vendas * 100).toFixed(2) 
                            : '0.00';
                            
                          return (
                            <TableRow key={forma}>
                              <TableCell className="font-medium">
                                {forma === 'dinheiro' ? 'Dinheiro' :
                                forma === 'cartao_credito' ? 'Cartão de Crédito' :
                                forma === 'cartao_debito' ? 'Cartão de Débito' : 
                                'PIX'}
                              </TableCell>
                              <TableCell>{count}</TableCell>
                              <TableCell>{percent}%</TableCell>
                              <TableCell>{formatMoney(valor)}</TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
