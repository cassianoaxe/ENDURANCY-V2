import React, { useState } from 'react';
import { 
  ShieldCheck, 
  ArrowLeft, 
  Save, 
  Plus, 
  Trash2, 
  Calendar,
  FileCheck,
  Upload,
  HelpCircle,
  CheckSquare,
  XSquare,
  FileBadge,
  Clock
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function ProducaoGarantiaLiberacao() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("info");
  const [formData, setFormData] = useState({
    produto: "",
    lote: "",
    tipoLiberacao: "lote_produzido",
    dataProducao: "",
    dataValidade: "",
    analiseQualidadeId: "",
    observacoes: "",
    responsavel: "",
    documentos: [
      { id: 1, tipo: "ordem_producao", nome: "Ordem de Produção", conforme: false, obrigatorio: true },
      { id: 2, tipo: "registro_fabricacao", nome: "Registro de Fabricação", conforme: false, obrigatorio: true },
      { id: 3, tipo: "analise_qualidade", nome: "Laudo de Análise", conforme: false, obrigatorio: true },
      { id: 4, tipo: "etiqueta", nome: "Etiqueta de Identificação", conforme: false, obrigatorio: true }
    ],
    decisao: "",
    parecer: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleCheckboxChange = (id, checked) => {
    const updatedDocumentos = formData.documentos.map(doc => 
      doc.id === id ? { ...doc, conforme: checked } : doc
    );
    setFormData({
      ...formData,
      documentos: updatedDocumentos
    });
  };

  const addDocumento = () => {
    const newId = formData.documentos.length > 0 
      ? Math.max(...formData.documentos.map(d => d.id)) + 1 
      : 1;
    setFormData({
      ...formData,
      documentos: [...formData.documentos, { id: newId, tipo: "", nome: "", conforme: false, obrigatorio: false }]
    });
  };

  const removeDocumento = (id) => {
    // Não permitir remover documentos obrigatórios
    const documento = formData.documentos.find(doc => doc.id === id);
    if (documento && documento.obrigatorio) return;

    setFormData({
      ...formData,
      documentos: formData.documentos.filter(doc => doc.id !== id)
    });
  };

  const handleDocumentoChange = (id, field, value) => {
    const updatedDocumentos = formData.documentos.map(doc => 
      doc.id === id ? { ...doc, [field]: value } : doc
    );
    setFormData({
      ...formData,
      documentos: updatedDocumentos
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Dados da liberação:", formData);
    
    // Simulando submissão bem-sucedida
    setTimeout(() => {
      navigate(createPageUrl("ProducaoGarantiaQualidade"));
    }, 1000);
  };

  const getConformidadeStatus = () => {
    const obrigatorios = formData.documentos.filter(doc => doc.obrigatorio);
    const conformes = obrigatorios.filter(doc => doc.conforme);
    
    if (conformes.length === obrigatorios.length) {
      return { status: "completo", text: "Todos os documentos estão conformes" };
    } else {
      const pendentes = obrigatorios.length - conformes.length;
      return { status: "pendente", text: `${pendentes} documento(s) obrigatório(s) pendente(s)` };
    }
  };

  const conformidadeStatus = getConformidadeStatus();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Link to={createPageUrl("ProducaoGarantiaQualidade")}>
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Nova Liberação de Lote</h1>
            <p className="text-muted-foreground">
              Registre uma nova liberação para um lote de produto
            </p>
          </div>
        </div>

        <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
          <Save className="w-4 h-4 mr-2" />
          Salvar Liberação
        </Button>
      </div>

      <Card>
        <CardHeader>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="info">Informações do Lote</TabsTrigger>
              <TabsTrigger value="documentos">Documentação</TabsTrigger>
              <TabsTrigger value="decisao">Decisão</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit}>
            <TabsContent value="info" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="produto">Produto</Label>
                  <Select 
                    name="produto" 
                    value={formData.produto} 
                    onValueChange={(value) => handleSelectChange("produto", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o produto" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PCBD-10">Óleo CBD 10%</SelectItem>
                      <SelectItem value="PCBD-20">Óleo CBD 20%</SelectItem>
                      <SelectItem value="CAPS-CBD">Cápsulas CBD</SelectItem>
                      <SelectItem value="TOP-CBD">Creme CBD Tópico</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="lote">Número do Lote</Label>
                  <Input 
                    name="lote" 
                    value={formData.lote} 
                    onChange={handleChange} 
                    placeholder="Informe o número do lote"
                  />
                </div>

                <div>
                  <Label htmlFor="tipoLiberacao">Tipo de Liberação</Label>
                  <Select 
                    name="tipoLiberacao" 
                    value={formData.tipoLiberacao} 
                    onValueChange={(value) => handleSelectChange("tipoLiberacao", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo de liberação" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="lote_produzido">Lote Produzido</SelectItem>
                      <SelectItem value="lote_quarentena">Lote em Quarentena</SelectItem>
                      <SelectItem value="materia_prima">Matéria-Prima</SelectItem>
                      <SelectItem value="insumo">Insumo de Produção</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="analiseQualidadeId">Análise de Qualidade</Label>
                  <Select 
                    name="analiseQualidadeId" 
                    value={formData.analiseQualidadeId} 
                    onValueChange={(value) => handleSelectChange("analiseQualidadeId", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a análise relacionada" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="QC-2023-001">QC-2023-001 (Óleo CBD 10%)</SelectItem>
                      <SelectItem value="QC-2023-005">QC-2023-005 (Óleo CBD 5%)</SelectItem>
                      <SelectItem value="QC-2023-003">QC-2023-003 (Matéria-Prima: CBD Isolado)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="dataProducao">Data de Produção</Label>
                  <div className="relative">
                    <Input 
                      type="date" 
                      name="dataProducao" 
                      value={formData.dataProducao} 
                      onChange={handleChange} 
                    />
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="dataValidade">Data de Validade</Label>
                  <div className="relative">
                    <Input 
                      type="date" 
                      name="dataValidade" 
                      value={formData.dataValidade} 
                      onChange={handleChange} 
                    />
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="responsavel">Responsável pelo Lote</Label>
                  <Select 
                    name="responsavel" 
                    value={formData.responsavel} 
                    onValueChange={(value) => handleSelectChange("responsavel", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o responsável" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="maria.silva">Maria Silva</SelectItem>
                      <SelectItem value="joao.santos">João Santos</SelectItem>
                      <SelectItem value="ana.oliveira">Ana Oliveira</SelectItem>
                      <SelectItem value="carlos.mendes">Carlos Mendes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea 
                    name="observacoes" 
                    value={formData.observacoes} 
                    onChange={handleChange} 
                    placeholder="Informações adicionais sobre o lote"
                    className="min-h-[100px]"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="documentos" className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">Documentação Necessária</h3>
                <div className="flex items-center gap-2">
                  <Badge className={
                    conformidadeStatus.status === "completo" 
                      ? "bg-green-100 text-green-800" 
                      : "bg-yellow-100 text-yellow-800"
                  }>
                    {conformidadeStatus.status === "completo" 
                      ? <CheckSquare className="w-3 h-3 mr-1" /> 
                      : <Clock className="w-3 h-3 mr-1" />}
                    {conformidadeStatus.text}
                  </Badge>
                  <Button 
                    type="button" 
                    onClick={addDocumento} 
                    variant="outline" 
                    size="sm" 
                    className="gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Adicionar Documento
                  </Button>
                </div>
              </div>

              <Card className="border border-gray-200 dark:border-gray-700">
                <CardContent className="p-4">
                  <div className="grid grid-cols-12 font-medium text-sm py-2 border-b">
                    <div className="col-span-5">Documento</div>
                    <div className="col-span-3">Tipo</div>
                    <div className="col-span-2 text-center">Obrigatório</div>
                    <div className="col-span-2 text-center">Conforme</div>
                  </div>

                  {formData.documentos.map((doc) => (
                    <div key={doc.id} className="grid grid-cols-12 py-3 border-b last:border-0 items-center">
                      <div className="col-span-5 flex items-center gap-2">
                        {doc.obrigatorio ? (
                          <span>{doc.nome}</span>
                        ) : (
                          <Input 
                            value={doc.nome} 
                            onChange={(e) => handleDocumentoChange(doc.id, "nome", e.target.value)} 
                            placeholder="Nome do documento"
                          />
                        )}
                      </div>
                      <div className="col-span-3">
                        {doc.obrigatorio ? (
                          <Badge variant="outline">{doc.tipo}</Badge>
                        ) : (
                          <Select 
                            value={doc.tipo} 
                            onValueChange={(value) => handleDocumentoChange(doc.id, "tipo", value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Tipo de documento" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="procedimento">Procedimento</SelectItem>
                              <SelectItem value="registro">Registro</SelectItem>
                              <SelectItem value="laudo">Laudo</SelectItem>
                              <SelectItem value="certificado">Certificado</SelectItem>
                              <SelectItem value="outro">Outro</SelectItem>
                            </SelectContent>
                          </Select>
                        )}
                      </div>
                      <div className="col-span-2 text-center">
                        {doc.obrigatorio ? (
                          <CheckSquare className="w-5 h-5 mx-auto text-green-600" />
                        ) : (
                          <XSquare className="w-5 h-5 mx-auto text-gray-400" />
                        )}
                      </div>
                      <div className="col-span-2 flex justify-center">
                        <Checkbox 
                          id={`conforme-${doc.id}`}
                          checked={doc.conforme}
                          onCheckedChange={(checked) => handleCheckboxChange(doc.id, checked)}
                        />
                        {!doc.obrigatorio && (
                          <Button 
                            type="button" 
                            onClick={() => removeDocumento(doc.id)} 
                            variant="ghost" 
                            size="sm" 
                            className="text-red-500 hover:text-red-700 ml-2"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <div className="flex gap-4 mt-4">
                <Button variant="outline" type="button" className="gap-2">
                  <Upload className="w-4 h-4" />
                  Anexar Certificado
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="decisao" className="space-y-4">
              <Card className="border border-gray-200 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg">Parecer da Garantia da Qualidade</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="decisao" className="text-base font-medium">Decisão</Label>
                    <RadioGroup 
                      value={formData.decisao} 
                      onValueChange={(value) => handleSelectChange("decisao", value)}
                      className="mt-2 space-y-3"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="liberado" id="liberado" />
                        <Label htmlFor="liberado" className="flex items-center">
                          <CheckSquare className="w-4 h-4 mr-2 text-green-600" />
                          Liberar para Uso/Distribuição
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="liberado_com_restricao" id="liberado_com_restricao" />
                        <Label htmlFor="liberado_com_restricao" className="flex items-center">
                          <FileBadge className="w-4 h-4 mr-2 text-yellow-600" />
                          Liberar com Restrições
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="retido" id="retido" />
                        <Label htmlFor="retido" className="flex items-center">
                          <XSquare className="w-4 h-4 mr-2 text-red-600" />
                          Reter/Não Liberar
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div>
                    <Label htmlFor="parecer" className="text-base font-medium">Parecer Técnico</Label>
                    <Textarea 
                      name="parecer" 
                      value={formData.parecer} 
                      onChange={handleChange} 
                      placeholder="Descreva o parecer técnico e justificativa para a decisão"
                      className="min-h-[150px] mt-2"
                    />
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-between mt-6">
                <Button variant="outline" type="button" onClick={() => setActiveTab("documentos")}>
                  Voltar
                </Button>
                <Button 
                  type="submit" 
                  className="bg-green-600 hover:bg-green-700"
                  disabled={!formData.decisao || !formData.parecer}
                >
                  <ShieldCheck className="w-4 h-4 mr-2" />
                  Finalizar Liberação
                </Button>
              </div>
            </TabsContent>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}