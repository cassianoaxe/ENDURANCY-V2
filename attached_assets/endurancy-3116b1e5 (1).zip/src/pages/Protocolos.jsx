import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Search, 
  Filter, 
  Plus, 
  Download, 
  ExternalLink, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  User,
  Calendar,
  Tag,
  Edit,
  Trash2,
  Eye,
  FileCheck,
  ArrowUpRight
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

// Mock data
const mockProtocolos = [
  {
    id: "p1",
    codigo: "PROT-2023-001",
    titulo: "Protocolo de Pesquisa: Eficácia do CBD no Tratamento da Epilepsia Refratária",
    versao: "1.0",
    data_criacao: "2023-05-15",
    autor: {
      id: "a1",
      nome: "Dra. Maria Silva",
      cargo: "Pesquisadora Principal"
    },
    status: "aprovado",
    metodologia: {
      tipo_estudo: "Estudo clínico randomizado",
      tamanho_amostra: 100,
      criterios_inclusao: [
        "Pacientes com epilepsia refratária",
        "Idade entre 18 e 65 anos",
        "Sem tratamento prévio com cannabis"
      ],
      criterios_exclusao: [
        "Gestantes ou lactantes",
        "Histórico de dependência química",
        "Doenças psiquiátricas graves"
      ]
    },
    aprovacoes: [
      {
        comite: "Comitê de Ética em Pesquisa",
        data_aprovacao: "2023-06-01",
        numero_aprovacao: "CEP-2023-001"
      }
    ],
    documento_url: "https://example.com/protocolo-001.pdf"
  },
  {
    id: "p2",
    codigo: "PROT-2023-002",
    titulo: "Protocolo de Pesquisa: Cannabis Medicinal no Tratamento da Dor Crônica",
    versao: "2.1",
    data_criacao: "2023-06-20",
    autor: {
      id: "a2",
      nome: "Dr. João Santos",
      cargo: "Coordenador de Pesquisa"
    },
    status: "em_revisao",
    metodologia: {
      tipo_estudo: "Estudo observacional prospectivo",
      tamanho_amostra: 150,
      criterios_inclusao: [
        "Pacientes com dor crônica",
        "Dor persistente por mais de 6 meses",
        "Tratamentos convencionais sem sucesso"
      ],
      criterios_exclusao: [
        "Menores de 21 anos",
        "Histórico de reações adversas a cannabis",
        "Comorbidades graves"
      ]
    },
    aprovacoes: [],
    documento_url: "https://example.com/protocolo-002.pdf"
  },
  {
    id: "p3",
    codigo: "PROT-2023-003",
    titulo: "Protocolo: Efeitos do THC:CBD em Pacientes com Esclerose Múltipla",
    versao: "1.2",
    data_criacao: "2023-07-10",
    autor: {
      id: "a3",
      nome: "Dra. Ana Lima",
      cargo: "Neurologista Pesquisadora"
    },
    status: "rascunho",
    metodologia: {
      tipo_estudo: "Ensaio clínico duplo-cego",
      tamanho_amostra: 80,
      criterios_inclusao: [
        "Diagnóstico confirmado de EM",
        "EDSS entre 2.0 e 6.5",
        "Idade entre 25 e 55 anos"
      ],
      criterios_exclusao: [
        "Surto nos últimos 30 dias",
        "Uso prévio de canabinoides",
        "Outras doenças neurológicas"
      ]
    },
    aprovacoes: [],
    documento_url: "https://example.com/protocolo-003.pdf"
  }
];

export default function Protocolos() {
  const [protocolos, setProtocolos] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadProtocolos = async () => {
      setIsLoading(true);
      try {
        // Simular delay de API
        await new Promise(resolve => setTimeout(resolve, 1000));
        setProtocolos(mockProtocolos);
      } catch (error) {
        console.error("Erro ao carregar protocolos:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadProtocolos();
  }, []);

  const statusColors = {
    rascunho: "bg-gray-100 text-gray-800",
    em_revisao: "bg-yellow-100 text-yellow-800",
    aprovado: "bg-green-100 text-green-800",
    arquivado: "bg-blue-100 text-blue-800"
  };

  const statusIcons = {
    rascunho: <FileText className="w-4 h-4" />,
    em_revisao: <Clock className="w-4 h-4" />,
    aprovado: <CheckCircle className="w-4 h-4" />,
    arquivado: <AlertTriangle className="w-4 h-4" />
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const filteredProtocolos = protocolos.filter(protocolo => {
    const matchesSearch = protocolo.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         protocolo.codigo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || protocolo.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Protocolos de Pesquisa</h1>
          <p className="text-muted-foreground">Gerencie os protocolos de pesquisa e suas aprovações</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">
          <Plus className="w-4 h-4 mr-2" />
          Novo Protocolo
        </Button>
      </div>

      {/* Filtros e Busca */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar protocolos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Status</SelectItem>
            <SelectItem value="rascunho">Rascunho</SelectItem>
            <SelectItem value="em_revisao">Em Revisão</SelectItem>
            <SelectItem value="aprovado">Aprovado</SelectItem>
            <SelectItem value="arquivado">Arquivado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Lista de Protocolos */}
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 rounded"></div>
                  <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredProtocolos.map((protocolo) => (
            <Card key={protocolo.id} className="overflow-hidden hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-gray-500" />
                      {protocolo.titulo}
                    </CardTitle>
                    <CardDescription>Código: {protocolo.codigo}</CardDescription>
                  </div>
                  <Badge className={statusColors[protocolo.status]}>
                    <div className="flex items-center gap-1">
                      {statusIcons[protocolo.status]}
                      {protocolo.status === 'em_revisao' ? 'Em Revisão' : 
                       protocolo.status.charAt(0).toUpperCase() + protocolo.status.slice(1)}
                    </div>
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium">Autor:</span>
                    <span className="text-sm">{protocolo.autor.nome}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium">Data:</span>
                    <span className="text-sm">{formatDate(protocolo.data_criacao)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tag className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium">Versão:</span>
                    <span className="text-sm">{protocolo.versao}</span>
                  </div>
                </div>

                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2">Metodologia:</h4>
                  <p className="text-sm text-gray-600">{protocolo.metodologia.tipo_estudo}</p>
                </div>

                {protocolo.aprovacoes.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium mb-2">Aprovações:</h4>
                    {protocolo.aprovacoes.map((aprovacao, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>{aprovacao.comite} - {formatDate(aprovacao.data_aprovacao)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter className="bg-gray-50 dark:bg-gray-800/50">
                <div className="flex justify-between items-center w-full">
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="w-4 h-4 mr-2" />
                      Visualizar
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-red-600">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}