import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Briefcase, 
  Users, 
  UserPlus, 
  ClipboardList, 
  Calendar, 
  FileText,
  TrendingUp,
  ArrowDownUp,
  Search,
  Filter,
  BarChart,
  PieChart,
  CheckCircle2,
  Clock,
  FolderOpen,
  Building,
  GraduationCap,
  AlertTriangle,
  MoreHorizontal,
  Phone,
  Mail,
  UserCheck
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RechartsPieChart,  Cell, Pie, LineChart, Line } from 'recharts';

// Dados mockados para o dashboard
const mockStats = {
  totalColaboradores: 32,
  novosColaboradoresMes: 3,
  vagasAbertas: 5,
  candidatosPendentes: 18,
  documentosPendentes: 7
};

const mockColaboradores = [
  { 
    id: 'colab1',
    nome: 'Marcos Silva',
    email: 'marcos.silva@email.com',
    telefone: '(11) 98765-4321',
    cargo: 'Gerente de Cultivo',
    departamento: 'Cultivo',
    data_contratacao: '2022-05-15',
    status: 'ativo',
    avatar: 'MS'
  },
  { 
    id: 'colab2',
    nome: 'Ana Pereira',
    email: 'ana.pereira@email.com',
    telefone: '(11) 91234-5678',
    cargo: 'Especialista em Produção',
    departamento: 'Produção',
    data_contratacao: '2022-08-10',
    status: 'ativo',
    avatar: 'AP'
  },
  { 
    id: 'colab3',
    nome: 'João Oliveira',
    email: 'joao.oliveira@email.com',
    telefone: '(11) 92345-6789',
    cargo: 'Farmacêutico',
    departamento: 'Qualidade',
    data_contratacao: '2023-01-05',
    status: 'ativo',
    avatar: 'JO'
  },
  { 
    id: 'colab4',
    nome: 'Clara Santos',
    email: 'clara.santos@email.com',
    telefone: '(11) 93456-7890',
    cargo: 'Analista de RH',
    departamento: 'RH',
    data_contratacao: '2023-07-01',
    status: 'ativo',
    avatar: 'CS'
  }
];

const mockVagasAbertas = [
  {
    id: 'vaga1',
    titulo: 'Especialista em Cultivo',
    departamento: 'Cultivo',
    tipo: 'CLT',
    publicada_em: '2023-07-10',
    status: 'aberta',
    candidatos: 12,
    local: 'São Paulo, SP',
    experiencia: '3+ anos'
  },
  {
    id: 'vaga2',
    titulo: 'Técnico de Laboratório',
    departamento: 'Qualidade',
    tipo: 'CLT',
    publicada_em: '2023-07-15',
    status: 'aberta',
    candidatos: 8,
    local: 'São Paulo, SP',
    experiencia: '2+ anos'
  },
  {
    id: 'vaga3',
    titulo: 'Farmacêutico(a)',
    departamento: 'Produção',
    tipo: 'CLT',
    publicada_em: '2023-07-20',
    status: 'aberta',
    candidatos: 5,
    local: 'São Paulo, SP',
    experiencia: '3+ anos'
  },
  {
    id: 'vaga4',
    titulo: 'Assistente Administrativo',
    departamento: 'Administrativo',
    tipo: 'CLT',
    publicada_em: '2023-07-25',
    status: 'aberta',
    candidatos: 20,
    local: 'São Paulo, SP',
    experiencia: '1+ ano'
  },
  {
    id: 'vaga5',
    titulo: 'Representante Comercial',
    departamento: 'Comercial',
    tipo: 'Contrato',
    publicada_em: '2023-07-18',
    status: 'aberta',
    candidatos: 15,
    local: 'Remoto',
    experiencia: '2+ anos'
  }
];

const mockCandidatos = [
  {
    id: 'cand1',
    nome: 'Roberto Almeida',
    email: 'roberto.almeida@email.com',
    vaga_id: 'vaga1',
    vaga_titulo: 'Especialista em Cultivo',
    status: 'entrevista',
    etapa: 'Entrevista Técnica',
    avaliacao: 4,
    data_candidatura: '2023-07-15',
    data_ultima_atualizacao: '2023-07-25'
  },
  {
    id: 'cand2',
    nome: 'Mariana Costa',
    email: 'mariana.costa@email.com',
    vaga_id: 'vaga1',
    vaga_titulo: 'Especialista em Cultivo',
    status: 'avaliacao',
    etapa: 'Teste Prático',
    avaliacao: 3,
    data_candidatura: '2023-07-18',
    data_ultima_atualizacao: '2023-07-28'
  },
  {
    id: 'cand3',
    nome: 'Felipe Mendes',
    email: 'felipe.mendes@email.com',
    vaga_id: 'vaga2',
    vaga_titulo: 'Técnico de Laboratório',
    status: 'nova',
    etapa: 'Triagem',
    avaliacao: null,
    data_candidatura: '2023-07-20',
    data_ultima_atualizacao: '2023-07-20'
  },
  {
    id: 'cand4',
    nome: 'Sandra Dias',
    email: 'sandra.dias@email.com',
    vaga_id: 'vaga3',
    vaga_titulo: 'Farmacêutico(a)',
    status: 'entrevista',
    etapa: 'Entrevista RH',
    avaliacao: 5,
    data_candidatura: '2023-07-22',
    data_ultima_atualizacao: '2023-07-29'
  }
];

const mockDocumentos = [
  {
    id: 'doc1',
    nome: 'Ficha de Admissão',
    colaborador_id: 'colab4',
    colaborador_nome: 'Clara Santos',
    tipo: 'admissao',
    status: 'pendente',
    prazo: '2023-08-10',
    importancia: 'alta'
  },
  {
    id: 'doc2',
    nome: 'Acordo de Confidencialidade',
    colaborador_id: 'colab4',
    colaborador_nome: 'Clara Santos',
    tipo: 'contrato',
    status: 'pendente',
    prazo: '2023-08-10',
    importancia: 'alta'
  },
  {
    id: 'doc3',
    nome: 'Certificado de Treinamento',
    colaborador_id: 'colab3',
    colaborador_nome: 'João Oliveira',
    tipo: 'treinamento',
    status: 'pendente',
    prazo: '2023-08-15',
    importancia: 'media'
  },
  {
    id: 'doc4',
    nome: 'Atualização de Documentos Pessoais',
    colaborador_id: 'colab1',
    colaborador_nome: 'Marcos Silva',
    tipo: 'pessoal',
    status: 'pendente',
    prazo: '2023-08-20',
    importancia: 'baixa'
  }
];

const mockEscalas = [
  {
    id: 'esc1',
    area: 'Cultivo - Sala 1',
    mes: 'Agosto 2023',
    responsaveis: [
      { 
        colaborador_id: 'colab1', 
        nome: 'Marcos Silva', 
        dias: [1, 2, 3, 4, 7, 8, 9, 10, 11, 14, 15, 16, 17, 18, 21, 22, 23, 24, 25, 28, 29, 30, 31]
      }
    ],
    status: 'publicada'
  },
  {
    id: 'esc2',
    area: 'Produção - Setor A',
    mes: 'Agosto 2023',
    responsaveis: [
      { 
        colaborador_id: 'colab2', 
        nome: 'Ana Pereira', 
        dias: [1, 2, 3, 4, 7, 8, 9, 10, 11, 14, 15, 16, 17, 18, 21, 22, 23, 24, 25, 28, 29, 30, 31]
      }
    ],
    status: 'publicada'
  },
  {
    id: 'esc3',
    area: 'Qualidade - Laboratório',
    mes: 'Agosto 2023',
    responsaveis: [
      { 
        colaborador_id: 'colab3', 
        nome: 'João Oliveira', 
        dias: [1, 2, 3, 4, 7, 8, 9, 10, 11, 14, 15, 16, 17, 18, 21, 22, 23, 24, 25, 28, 29, 30, 31]
      }
    ],
    status: 'publicada'
  }
];

const mockColaboradoresMensais = [
  { mes: 'Jan', novos: 2, saidas: 0, total: 26 },
  { mes: 'Fev', novos: 1, saidas: 1, total: 26 },
  { mes: 'Mar', novos: 3, saidas: 0, total: 29 },
  { mes: 'Abr', novos: 0, saidas: 1, total: 28 },
  { mes: 'Mai', novos: 0, saidas: 0, total: 28 },
  { mes: 'Jun', novos: 1, saidas: 0, total: 29 },
  { mes: 'Jul', novos: 3, saidas: 0, total: 32 }
];

const mockColaboradoresPorDepartamento = [
  { nome: 'Cultivo', valor: 12 },
  { nome: 'Produção', valor: 8 },
  { nome: 'Qualidade', valor: 5 },
  { nome: 'Administrativo', valor: 4 },
  { nome: 'Comercial', valor: 3 }
];

const mockColaboradoresPorCargo = [
  { nome: 'Técnico', valor: 14 },
  { nome: 'Especialista', valor: 9 },
  { nome: 'Gerente', valor: 5 },
  { nome: 'Assistente', valor: 4 }
];

// Componente de Estatísticas
const StatsSection = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-6">
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Total de Colaboradores</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.totalColaboradores}</CardTitle>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-blue-600 mt-2">
            <UserPlus className="w-4 h-4 mr-1" />
            <span>{stats.novosColaboradoresMes} novos este mês</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Vagas Abertas</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.vagasAbertas}</CardTitle>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <Briefcase className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-green-600 mt-2">
            <TrendingUp className="w-4 h-4 mr-1" />
            <span>3 novas nos últimos 30 dias</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Candidatos em Análise</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.candidatosPendentes}</CardTitle>
            </div>
            <div className="p-3 bg-amber-50 rounded-lg">
              <UserCheck className="w-5 h-5 text-amber-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-amber-600 mt-2">
            <Clock className="w-4 h-4 mr-1" />
            <span>5 em fase de entrevista</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Documentos Pendentes</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.documentosPendentes}</CardTitle>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <FileText className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-purple-600 mt-2">
            <AlertTriangle className="w-4 h-4 mr-1" />
            <span>3 de alta prioridade</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Aniversários do Mês</CardDescription>
              <CardTitle className="text-3xl font-bold">2</CardTitle>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <Calendar className="w-5 h-5 text-red-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-red-600 mt-2">
            <CheckCircle2 className="w-4 h-4 mr-1" />
            <span>Próximo: João (12/08)</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Gráfico de Barras - Colaboradores
const ColaboradoresMensaisChart = ({ data }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Evolução de Colaboradores</CardTitle>
        <CardDescription>Admissões, desligamentos e total mensal</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <RechartsBarChart
              data={data}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="mes" />
              <YAxis yAxisId="left" orientation="left" />
              <YAxis yAxisId="right" orientation="right" domain={[0, 40]} />
              <Tooltip />
              <Legend />
              <Bar yAxisId="left" dataKey="novos" name="Novos" fill="#4CAF50" />
              <Bar yAxisId="left" dataKey="saidas" name="Saídas" fill="#F44336" />
              <Line yAxisId="right" type="monotone" dataKey="total" name="Total" stroke="#2196F3" strokeWidth={2} />
            </RechartsBarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Gráfico de Pizza - Colaboradores por Departamento
const ColaboradoresPorDepartamentoChart = ({ data }) => {
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#A569BD'];
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Colaboradores por Departamento</CardTitle>
        <CardDescription>Distribuição atual da equipe</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="valor"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Colaboradores Recentes
const ColaboradoresRecentesSection = ({ colaboradores }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Colaboradores Recentes</CardTitle>
            <CardDescription>Últimas contratações</CardDescription>
          </div>
          <Link to={createPageUrl("RhColaboradores")}>
            <Button variant="outline" size="sm">Ver Todos</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {colaboradores.map((colaborador, index) => (
            <div key={index} className="flex items-start gap-4">
              <Avatar>
                <AvatarFallback>{colaborador.avatar}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between">
                  <div>
                    <p className="font-medium">{colaborador.nome}</p>
                    <p className="text-sm text-gray-500">{colaborador.cargo}</p>
                  </div>
                  <Badge 
                    className="bg-green-100 text-green-800"
                  >
                    Ativo
                  </Badge>
                </div>
                <div className="flex justify-between items-center mt-2 text-sm">
                  <div className="flex items-center">
                    <Building className="w-3.5 h-3.5 mr-1 text-gray-500" />
                    <span className="text-gray-600">{colaborador.departamento}</span>
                  </div>
                  <div className="flex items-center text-blue-600">
                    <Calendar className="w-3.5 h-3.5 mr-1" />
                    <span>Desde: {new Date(colaborador.data_contratacao).toLocaleDateString()}</span>
                  </div>
                </div>
                <div className="flex space-x-4 mt-2">
                  <button className="text-gray-500 hover:text-gray-700 flex items-center text-xs">
                    <Phone className="w-3 h-3 mr-1" />
                    {colaborador.telefone}
                  </button>
                  <button className="text-gray-500 hover:text-gray-700 flex items-center text-xs">
                    <Mail className="w-3 h-3 mr-1" />
                    {colaborador.email}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Vagas Abertas
const VagasAbertasSection = ({ vagas }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Vagas Abertas</CardTitle>
            <CardDescription>Processos seletivos em andamento</CardDescription>
          </div>
          <Link to={createPageUrl("RhRecrutamento")}>
            <Button variant="outline" size="sm">Ver Todas</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {vagas.slice(0, 3).map((vaga, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">{vaga.titulo}</p>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <Building className="w-3.5 h-3.5 mr-1" />
                    <span>{vaga.departamento}</span>
                    <span className="mx-2">•</span>
                    <span className="capitalize">{vaga.tipo}</span>
                  </div>
                </div>
                <Badge className="bg-green-100 text-green-800">
                  Aberta
                </Badge>
              </div>
              
              <div className="mt-3 flex justify-between items-center">
                <div className="text-sm">
                  <div className="flex items-center text-gray-600">
                    <GraduationCap className="w-3.5 h-3.5 mr-1 text-gray-500" />
                    <span>Experiência: {vaga.experiencia}</span>
                  </div>
                  <div className="flex items-center text-gray-600 mt-1">
                    <Users className="w-3.5 h-3.5 mr-1 text-gray-500" />
                    <span>{vaga.candidatos} candidatos</span>
                  </div>
                </div>
                <Button size="sm">Ver Detalhes</Button>
              </div>
            </div>
          ))}
          
          {vagas.length > 3 && (
            <div className="text-center">
              <Link to={createPageUrl("RhRecrutamento")}>
                <Button variant="outline">Ver todas as {vagas.length} vagas</Button>
              </Link>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Candidatos
const CandidatosSection = ({ candidatos }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Candidatos Recentes</CardTitle>
            <CardDescription>Processos seletivos em andamento</CardDescription>
          </div>
          <Link to={createPageUrl("RhRecrutamento")}>
            <Button variant="outline" size="sm">Ver Todos</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {candidatos.map((candidato, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">{candidato.nome}</p>
                  <p className="text-sm text-gray-500">{candidato.email}</p>
                </div>
                <Badge 
                  className={
                    candidato.status === 'nova' ? 'bg-blue-100 text-blue-800' :
                    candidato.status === 'avaliacao' ? 'bg-purple-100 text-purple-800' :
                    candidato.status === 'entrevista' ? 'bg-amber-100 text-amber-800' :
                    'bg-green-100 text-green-800'
                  }
                >
                  <span className="capitalize">{candidato.status}</span>
                </Badge>
              </div>
              
              <div className="mt-3">
                <div className="flex items-center text-sm mb-2">
                  <Briefcase className="w-3.5 h-3.5 mr-1 text-gray-500" />
                  <span className="text-gray-700">{candidato.vaga_titulo}</span>
                </div>
                
                <div className="flex justify-between items-center text-sm">
                  <div className="flex items-center text-gray-600">
                    <Clock className="w-3.5 h-3.5 mr-1" />
                    <span>Etapa: {candidato.etapa}</span>
                  </div>
                  <div className="text-gray-600">
                    Candidatura: {new Date(candidato.data_candidatura).toLocaleDateString()}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Documentos Pendentes
const DocumentosSection = ({ documentos }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Documentos Pendentes</CardTitle>
            <CardDescription>Documentos que necessitam atenção</CardDescription>
          </div>
          <Link to={createPageUrl("RhDocumentos")}>
            <Button variant="outline" size="sm">Ver Todos</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {documentos.map((documento, index) => (
            <div 
              key={index} 
              className={`border rounded-lg p-4 ${
                documento.importancia === 'alta' ? 'border-red-200 bg-red-50' :
                documento.importancia === 'media' ? 'border-amber-200 bg-amber-50' :
                'border-gray-200 bg-gray-50'
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">{documento.nome}</p>
                  <p className="text-sm text-gray-600">{documento.colaborador_nome}</p>
                </div>
                <Badge 
                  className={
                    documento.importancia === 'alta' ? 'bg-red-100 text-red-800' :
                    documento.importancia === 'media' ? 'bg-amber-100 text-amber-800' :
                    'bg-green-100 text-green-800'
                  }
                >
                  <span className="capitalize">{documento.importancia} prioridade</span>
                </Badge>
              </div>
              
              <div className="mt-3 flex justify-between items-center">
                <div className="flex items-center text-sm text-gray-600">
                  <Calendar className="w-3.5 h-3.5 mr-1" />
                  <span>Prazo: {new Date(documento.prazo).toLocaleDateString()}</span>
                </div>
                <Button size="sm">
                  <FolderOpen className="w-3.5 h-3.5 mr-1" />
                  Ver Documento
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Escalas
const EscalasSection = ({ escalas }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Escalas de Trabalho</CardTitle>
            <CardDescription>Escalas ativas para o mês</CardDescription>
          </div>
          <Link to={createPageUrl("RhEscalas")}>
            <Button variant="outline" size="sm">Ver Todas</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {escalas.map((escala, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">{escala.area}</p>
                  <p className="text-sm text-gray-500">{escala.mes}</p>
                </div>
                <Badge className="bg-green-100 text-green-800">
                  Publicada
                </Badge>
              </div>
              
              <div className="mt-3">
                <p className="text-sm font-medium mb-2">Responsáveis:</p>
                <div className="space-y-2">
                  {escala.responsaveis.map((resp, idx) => (
                    <div key={idx} className="flex justify-between items-center bg-gray-50 p-2 rounded">
                      <div className="flex items-center">
                        <Avatar className="w-6 h-6 mr-2">
                          <AvatarFallback className="text-xs">{resp.nome.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm">{resp.nome}</span>
                      </div>
                      <span className="text-xs text-gray-500">{resp.dias.length} dias designados</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Principal
export default function RhDashboard() {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({});
  const [colaboradores, setColaboradores] = useState([]);
  const [vagasAbertas, setVagasAbertas] = useState([]);
  const [candidatos, setCandidatos] = useState([]);
  const [documentos, setDocumentos] = useState([]);
  const [escalas, setEscalas] = useState([]);
  const [colaboradoresMensais, setColaboradoresMensais] = useState([]);
  const [colaboradoresPorDepartamento, setColaboradoresPorDepartamento] = useState([]);
  const [colaboradoresPorCargo, setColaboradoresPorCargo] = useState([]);
  const [periodFilter, setPeriodFilter] = useState('month');
  
  useEffect(() => {
    loadDashboardData();
  }, [periodFilter]);
  
  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      
      // Em produção, aqui seriam chamadas para as APIs reais
      // Simulando carregamento
      setTimeout(() => {
        setStats(mockStats);
        setColaboradores(mockColaboradores);
        setVagasAbertas(mockVagasAbertas);
        setCandidatos(mockCandidatos);
        setDocumentos(mockDocumentos);
        setEscalas(mockEscalas);
        setColaboradoresMensais(mockColaboradoresMensais);
        setColaboradoresPorDepartamento(mockColaboradoresPorDepartamento);
        setColaboradoresPorCargo(mockColaboradoresPorCargo);
        setIsLoading(false);
      }, 800);
      
    } catch (error) {
      console.error("Erro ao carregar dados do dashboard:", error);
      setIsLoading(false);
    }
  };
  
  const handleRefresh = () => {
    loadDashboardData();
  };
  
  const handlePeriodChange = (value) => {
    setPeriodFilter(value);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Dashboard RH</h1>
          <p className="text-gray-500 mt-1">
            Gestão de colaboradores, recrutamento e documentação
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <Select value={periodFilter} onValueChange={handlePeriodChange}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Última Semana</SelectItem>
              <SelectItem value="month">Último Mês</SelectItem>
              <SelectItem value="quarter">Último Trimestre</SelectItem>
              <SelectItem value="year">Último Ano</SelectItem>
            </SelectContent>
          </Select>
          
          <Button onClick={handleRefresh} variant="outline" className="gap-2">
            <ArrowDownUp className="w-4 h-4" />
            Atualizar
          </Button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
          <p className="ml-2">Carregando dados do dashboard...</p>
        </div>
      ) : (
        <>
          <StatsSection stats={stats} />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ColaboradoresMensaisChart data={colaboradoresMensais} />
            <ColaboradoresPorDepartamentoChart data={colaboradoresPorDepartamento} />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <ColaboradoresRecentesSection colaboradores={colaboradores} />
            </div>
            <div className="lg:col-span-2">
              <VagasAbertasSection vagas={vagasAbertas} />
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <CandidatosSection candidatos={candidatos} />
            <DocumentosSection documentos={documentos} />
          </div>
          
          <div className="grid grid-cols-1 gap-6">
            <EscalasSection escalas={escalas} />
          </div>
        </>
      )}
    </div>
  );
}