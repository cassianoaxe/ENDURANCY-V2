
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Tag, 
  Search, 
  Printer, 
  Filter, 
  Download, 
  Package, 
  Truck, 
  QrCode,
  CheckCircle,
  Copy,
  Settings,
  FileText,
  FileCheck,
  FilePlus,
  FileClock,
  FileWarning,
  ShieldCheck,
  ClipboardCheck,
  Nfc,
  Eye
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Dados mockados para demonstração
const pedidos = [
  {
    id: 'P12345',
    cliente: 'Maria Silva',
    endereco: 'Rua das Flores, 123 - São Paulo, SP - 01234-567',
    data: '21/07/2023',
    status: 'preparando',
    metodo_envio: 'Correios - PAC',
    etiqueta_impressa: false,
    prescricao_id: 'PR-3901',
    rastreio: null,
    produtos: [
      { id: 'prod1', nome: 'Óleo CBD 10%', quantidade: 1 },
      { id: 'prod2', nome: 'Cápsulas CBD 20mg', quantidade: 2 }
    ]
  },
  {
    id: 'P12346',
    cliente: 'João Pereira',
    endereco: 'Av. Paulista, 1000 - São Paulo, SP - 01310-100',
    data: '22/07/2023',
    status: 'preparando',
    metodo_envio: 'Correios - SEDEX',
    etiqueta_impressa: true,
    prescricao_id: 'PR-3902',
    rastreio: 'BR987654321',
    produtos: [
      { id: 'prod3', nome: 'Óleo CBD 5%', quantidade: 1 }
    ]
  },
  {
    id: 'P12347',
    cliente: 'Ana Costa',
    endereco: 'Rua Direita, 45 - Rio de Janeiro, RJ - 20000-001',
    data: '22/07/2023',
    status: 'preparando',
    metodo_envio: 'Transportadora',
    etiqueta_impressa: false,
    prescricao_id: 'PR-3903',
    rastreio: null,
    produtos: [
      { id: 'prod4', nome: 'Extrato Full Spectrum', quantidade: 1 },
      { id: 'prod5', nome: 'Creme Tópico CBD', quantidade: 1 }
    ]
  },
  {
    id: 'P12350',
    cliente: 'Roberto Almeida',
    endereco: 'Rua das Margaridas, 78 - Belo Horizonte, MG - 30000-000',
    data: '24/07/2023',
    status: 'preparando',
    metodo_envio: 'Correios - PAC',
    etiqueta_impressa: false,
    prescricao_id: 'PR-3904',
    rastreio: null,
    produtos: [
      { id: 'prod1', nome: 'Óleo CBD 10%', quantidade: 1 }
    ]
  },
  {
    id: 'P12351',
    cliente: 'Lucia Ferreira',
    endereco: 'Av. Brasil, 500 - Curitiba, PR - 80000-000',
    data: '24/07/2023',
    status: 'preparando',
    metodo_envio: 'Correios - SEDEX',
    etiqueta_impressa: false,
    prescricao_id: 'PR-3905',
    rastreio: null,
    produtos: [
      { id: 'prod6', nome: 'Óleo CBD 15%', quantidade: 1 },
      { id: 'prod7', nome: 'Spray Sublingual', quantidade: 1 }
    ]
  }
];

// Dados mockados para prescrições
const prescricoes = [
  {
    id: 'PR-3901',
    paciente: 'Maria Silva',
    medico: 'Dr. Carlos Santos',
    crm: 'CRM-SP 123456',
    data_emissao: '18/07/2023',
    validade: '18/01/2024',
    produtos: [
      { nome: 'Óleo CBD 10%', dosagem: '2 gotas, 2x ao dia' },
      { nome: 'Cápsulas CBD 20mg', dosagem: '1 cápsula pela manhã' }
    ]
  },
  {
    id: 'PR-3902',
    paciente: 'João Pereira',
    medico: 'Dra. Ana Oliveira',
    crm: 'CRM-SP 654321',
    data_emissao: '19/07/2023',
    validade: '19/01/2024',
    produtos: [
      { nome: 'Óleo CBD 5%', dosagem: '3 gotas, 3x ao dia' }
    ]
  },
  {
    id: 'PR-3903',
    paciente: 'Ana Costa',
    medico: 'Dr. Ricardo Almeida',
    crm: 'CRM-RJ 789012',
    data_emissao: '20/07/2023',
    validade: '20/01/2024',
    produtos: [
      { nome: 'Extrato Full Spectrum', dosagem: '0.5ml ao dia' },
      { nome: 'Creme Tópico CBD', dosagem: 'Aplicar na área afetada 2x ao dia' }
    ]
  },
  {
    id: 'PR-3904',
    paciente: 'Roberto Almeida',
    medico: 'Dra. Carla Mendes',
    crm: 'CRM-MG 345678',
    data_emissao: '21/07/2023',
    validade: '21/01/2024',
    produtos: [
      { nome: 'Óleo CBD 10%', dosagem: '2 gotas ao deitar' }
    ]
  },
  {
    id: 'PR-3905',
    paciente: 'Lucia Ferreira',
    medico: 'Dr. Paulo Lima',
    crm: 'CRM-PR 876543',
    data_emissao: '22/07/2023',
    validade: '22/01/2024',
    produtos: [
      { nome: 'Óleo CBD 15%', dosagem: '1 gota, 2x ao dia' },
      { nome: 'Spray Sublingual', dosagem: '2 borrifadas ao deitar' }
    ]
  }
];

export default function Etiquetas() {
  const [pedidosSelecionados, setPedidosSelecionados] = useState([]);
  const [filtro, setFiltro] = useState('preparando');
  const [termoBusca, setTermoBusca] = useState('');
  const [transportadora, setTransportadora] = useState('correios');
  const [formatoEtiqueta, setFormatoEtiqueta] = useState('a4');
  const [pedidosFiltrados, setPedidosFiltrados] = useState([]);
  const [selecionarTodos, setSelecionarTodos] = useState(false);
  const [tipoDocumento, setTipoDocumento] = useState('etiqueta');
  const [declaracaoConteudo, setDeclaracaoConteudo] = useState(false);
  const [tipoEnvio, setTipoEnvio] = useState('nacional');
  const [incluirPrescricao, setIncluirPrescricao] = useState(true);
  const [showPrescricaoPreview, setShowPrescricaoPreview] = useState(false);
  const [showDeclaracaoPreview, setShowDeclaracaoPreview] = useState(false);
  const [prescricaoSelecionada, setPrescricaoSelecionada] = useState(null);
  const [pedidoSelecionado, setPedidoSelecionado] = useState(null);

  useEffect(() => {
    filtrarPedidos();
  }, [filtro, termoBusca]);

  useEffect(() => {
    if (selecionarTodos) {
      setPedidosSelecionados(pedidosFiltrados.map(p => p.id));
    } else {
      setPedidosSelecionados([]);
    }
  }, [selecionarTodos, pedidosFiltrados]);

  const filtrarPedidos = () => {
    let resultados = pedidos;
    
    // Filtrar por status
    if (filtro !== 'todos') {
      resultados = resultados.filter(pedido => pedido.status === filtro);
    }
    
    // Filtrar por termo de busca
    if (termoBusca) {
      resultados = resultados.filter(pedido => 
        pedido.id.toLowerCase().includes(termoBusca.toLowerCase()) ||
        pedido.cliente.toLowerCase().includes(termoBusca.toLowerCase()) ||
        pedido.endereco.toLowerCase().includes(termoBusca.toLowerCase())
      );
    }
    
    setPedidosFiltrados(resultados);
  };

  const toggleSelecionarPedido = (pedidoId) => {
    if (pedidosSelecionados.includes(pedidoId)) {
      setPedidosSelecionados(pedidosSelecionados.filter(id => id !== pedidoId));
    } else {
      setPedidosSelecionados([...pedidosSelecionados, pedidoId]);
    }
  };

  const handleSelecionarTodos = (checked) => {
    setSelecionarTodos(checked);
  };

  const imprimirSelecionados = () => {
    console.log(`Imprimindo ${tipoDocumento} para os pedidos: ${pedidosSelecionados.join(', ')}`);
    
    let mensagem = "";
    if (tipoDocumento === 'etiqueta') {
      mensagem = `Etiquetas geradas com sucesso para ${pedidosSelecionados.length} pedidos.`;
    } else if (tipoDocumento === 'prescricao') {
      mensagem = `Prescrições impressas com sucesso para ${pedidosSelecionados.length} pedidos.`;
    } else if (tipoDocumento === 'declaracao') {
      mensagem = `Declarações de conteúdo geradas com sucesso para ${pedidosSelecionados.length} pedidos.`;
    }
    
    alert(mensagem);
  };

  const visualizarPrescricao = (pedidoId) => {
    const pedido = pedidos.find(p => p.id === pedidoId);
    if (pedido) {
      const prescricao = prescricoes.find(p => p.id === pedido.prescricao_id);
      setPedidoSelecionado(pedido);
      setPrescricaoSelecionada(prescricao);
      setShowPrescricaoPreview(true);
    }
  };

  const visualizarDeclaracao = (pedidoId) => {
    const pedido = pedidos.find(p => p.id === pedidoId);
    if (pedido) {
      setPedidoSelecionado(pedido);
      setShowDeclaracaoPreview(true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Documentos de Envio</h1>
          <p className="text-gray-500 mt-1">
            Gere e imprima etiquetas, prescrições e declarações para seus pedidos
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button 
            disabled={pedidosSelecionados.length === 0} 
            onClick={imprimirSelecionados} 
            className="gap-2"
          >
            <Printer className="w-4 h-4" />
            Imprimir Selecionados ({pedidosSelecionados.length})
          </Button>
        </div>
      </div>

      <Tabs defaultValue="documentos" className="space-y-4">
        <TabsList>
          <TabsTrigger value="documentos">Documentos de Envio</TabsTrigger>
          <TabsTrigger value="prescricoes">Prescrições</TabsTrigger>
          <TabsTrigger value="declaracoes">Declarações de Conteúdo</TabsTrigger>
        </TabsList>
        
        <TabsContent value="documentos" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3">
              <div className="flex flex-col sm:flex-row justify-between gap-4 mb-4">
                <div className="relative w-full sm:w-80">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
                  <Input 
                    placeholder="Buscar pedido por ID, cliente..." 
                    value={termoBusca}
                    onChange={(e) => setTermoBusca(e.target.value)}
                    className="pl-10"
                  />
                </div>

                <div className="flex gap-2 ml-auto">
                  <Button variant="outline" className="gap-2">
                    <Filter className="w-4 h-4" />
                    Filtrar
                  </Button>
                  <Button variant="outline" className="gap-2">
                    <Download className="w-4 h-4" />
                    Exportar
                  </Button>
                </div>
              </div>

              <Tabs value={filtro} onValueChange={setFiltro} className="mb-6">
                <TabsList className="grid grid-cols-4">
                  <TabsTrigger value="todos">Todos</TabsTrigger>
                  <TabsTrigger value="preparando">Preparando</TabsTrigger>
                  <TabsTrigger value="impresso">Etiquetas Impressas</TabsTrigger>
                  <TabsTrigger value="enviado">Enviados</TabsTrigger>
                </TabsList>
              </Tabs>

              <Card>
                <CardContent className="p-0">
                  {pedidosFiltrados.length === 0 ? (
                    <div className="p-8 text-center">
                      <Tag className="w-12 h-12 mx-auto text-gray-300 mb-3" />
                      <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhum pedido encontrado</h3>
                      <p className="text-gray-500">
                        Nenhum pedido corresponde aos filtros aplicados.
                      </p>
                      <Button variant="outline" className="mt-4" onClick={() => { setFiltro('todos'); setTermoBusca(''); }}>
                        Limpar filtros
                      </Button>
                    </div>
                  ) : (
                    <div className="rounded-lg border overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead>
                            <tr className="bg-gray-50">
                              <th className="px-4 py-3 text-left">
                                <div className="flex items-center">
                                  <Checkbox 
                                    id="select-all" 
                                    checked={selecionarTodos}
                                    onCheckedChange={handleSelecionarTodos}
                                    aria-label="Selecionar todos os pedidos"
                                  />
                                </div>
                              </th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Pedido</th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Cliente</th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Endereço</th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Método de Envio</th>
                              <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">Status</th>
                              <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Ações</th>
                            </tr>
                          </thead>
                          <tbody>
                            {pedidosFiltrados.map((pedido, i) => (
                              <tr key={pedido.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                <td className="px-4 py-3">
                                  <Checkbox 
                                    checked={pedidosSelecionados.includes(pedido.id)}
                                    onCheckedChange={() => toggleSelecionarPedido(pedido.id)}
                                    aria-label={`Selecionar pedido ${pedido.id}`}
                                  />
                                </td>
                                <td className="px-4 py-3">
                                  <div className="flex items-center">
                                    <span className="text-sm font-medium">
                                      #{pedido.id}
                                    </span>
                                  </div>
                                </td>
                                <td className="px-4 py-3 text-sm text-gray-700">{pedido.cliente}</td>
                                <td className="px-4 py-3 text-sm text-gray-700 max-w-xs truncate">{pedido.endereco}</td>
                                <td className="px-4 py-3 text-sm text-gray-700">{pedido.metodo_envio}</td>
                                <td className="px-4 py-3 text-center">
                                  {pedido.etiqueta_impressa ? (
                                    <Badge className="bg-green-100 text-green-800">Etiqueta Impressa</Badge>
                                  ) : (
                                    <Badge className="bg-blue-100 text-blue-800">Aguardando Etiqueta</Badge>
                                  )}
                                </td>
                                <td className="px-4 py-3 text-right">
                                  <div className="flex justify-end gap-2">
                                    <Button 
                                      variant="ghost" 
                                      size="icon"
                                      title="Imprimir etiqueta"
                                    >
                                      <Printer className="w-4 h-4" />
                                    </Button>
                                    <Button 
                                      variant="ghost" 
                                      size="icon"
                                      title="Visualizar prescrição"
                                      onClick={() => visualizarPrescricao(pedido.id)}
                                    >
                                      <FileCheck className="w-4 h-4" />
                                    </Button>
                                    <Button 
                                      variant="ghost" 
                                      size="icon"
                                      title="Visualizar declaração"
                                      onClick={() => visualizarDeclaracao(pedido.id)}
                                    >
                                      <FileText className="w-4 h-4" />
                                    </Button>
                                    {pedido.rastreio && (
                                      <Button 
                                        variant="ghost" 
                                        size="icon"
                                        title="Copiar código de rastreio"
                                      >
                                        <Copy className="w-4 h-4" />
                                      </Button>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Configurações de Impressão</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Tipo de Documento</Label>
                    <RadioGroup
                      value={tipoDocumento}
                      onValueChange={setTipoDocumento}
                      className="flex flex-col space-y-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="etiqueta" id="etiqueta" />
                        <Label htmlFor="etiqueta" className="flex items-center gap-2">
                          <Tag className="h-4 w-4" />
                          <span>Etiqueta de Envio</span>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="prescricao" id="prescricao" />
                        <Label htmlFor="prescricao" className="flex items-center gap-2">
                          <FileCheck className="h-4 w-4" />
                          <span>Prescrição Médica</span>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="declaracao" id="declaracao" />
                        <Label htmlFor="declaracao" className="flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          <span>Declaração de Conteúdo</span>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {tipoDocumento === "etiqueta" && (
                    <>
                      <div className="space-y-2">
                        <Label>Transportadora</Label>
                        <Select value={transportadora} onValueChange={setTransportadora}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione a transportadora" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="correios">Correios</SelectItem>
                            <SelectItem value="jadlog">Jadlog</SelectItem>
                            <SelectItem value="transportadora">Transportadora Própria</SelectItem>
                            <SelectItem value="outros">Outros</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Formato da Etiqueta</Label>
                        <Select value={formatoEtiqueta} onValueChange={setFormatoEtiqueta}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o formato" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="a4">A4 (2 etiquetas)</SelectItem>
                            <SelectItem value="a6">A6 (1 etiqueta)</SelectItem>
                            <SelectItem value="termica">Térmica 10x15cm</SelectItem>
                            <SelectItem value="zebra">Zebra ZPL</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Adicionar Documentação</Label>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox 
                              id="include-prescription" 
                              checked={incluirPrescricao} 
                              onCheckedChange={setIncluirPrescricao}
                            />
                            <label htmlFor="include-prescription" className="text-sm text-gray-700 cursor-pointer">
                              Incluir prescrição médica
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox 
                              id="include-declaration" 
                              checked={declaracaoConteudo} 
                              onCheckedChange={setDeclaracaoConteudo}
                            />
                            <label htmlFor="include-declaration" className="text-sm text-gray-700 cursor-pointer">
                              Declaração de conteúdo para Correios
                            </label>
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  {tipoDocumento === "prescricao" && (
                    <>
                      <div className="space-y-2">
                        <Label>Formato do Documento</Label>
                        <Select defaultValue="a4">
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o formato" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="a4">A4</SelectItem>
                            <SelectItem value="a5">A5</SelectItem>
                            <SelectItem value="letter">Carta</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Opções de Impressão</Label>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox id="include-logo-prescricao" defaultChecked />
                            <label htmlFor="include-logo-prescricao" className="text-sm text-gray-700 cursor-pointer">
                              Incluir logo da empresa
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="include-header" defaultChecked />
                            <label htmlFor="include-header" className="text-sm text-gray-700 cursor-pointer">
                              Incluir cabeçalho com dados do médico
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="include-instructions" defaultChecked />
                            <label htmlFor="include-instructions" className="text-sm text-gray-700 cursor-pointer">
                              Incluir instruções de uso
                            </label>
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  {tipoDocumento === "declaracao" && (
                    <>
                      <div className="space-y-2">
                        <Label>Tipo de Envio</Label>
                        <RadioGroup
                          value={tipoEnvio}
                          onValueChange={setTipoEnvio}
                          className="flex flex-col space-y-2"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="nacional" id="nacional" />
                            <Label htmlFor="nacional">Nacional</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="internacional" id="internacional" />
                            <Label htmlFor="internacional">Internacional</Label>
                          </div>
                        </RadioGroup>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Formato do Documento</Label>
                        <Select defaultValue="a4">
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o formato" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="a4">A4</SelectItem>
                            <SelectItem value="a5">A5</SelectItem>
                            <SelectItem value="correios">Padrão Correios</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Informações Adicionais</Label>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox id="include-valor" defaultChecked />
                            <label htmlFor="include-valor" className="text-sm text-gray-700 cursor-pointer">
                              Incluir valor declarado
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="include-anvisainfo" defaultChecked />
                            <label htmlFor="include-anvisainfo" className="text-sm text-gray-700 cursor-pointer">
                              Incluir informações ANVISA
                            </label>
                          </div>
                          {tipoEnvio === "internacional" && (
                            <div className="flex items-center space-x-2">
                              <Checkbox id="include-translation" defaultChecked />
                              <label htmlFor="include-translation" className="text-sm text-gray-700 cursor-pointer">
                                Incluir tradução em inglês
                              </label>
                            </div>
                          )}
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
                <CardFooter>
                  <Button variant="outline" size="sm" className="w-full gap-2">
                    <Settings className="w-4 h-4" />
                    Configurações Avançadas
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Ações Rápidas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button 
                    variant="outline"
                    className="w-full justify-start gap-2 text-left h-10"
                    disabled={pedidosSelecionados.length === 0 || tipoDocumento !== "etiqueta"}
                  >
                    <Printer className="w-4 h-4 text-gray-500" />
                    <span>Imprimir Etiquetas ({tipoDocumento === "etiqueta" ? pedidosSelecionados.length : 0})</span>
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2 text-left h-10"
                    disabled={pedidosSelecionados.length === 0 || tipoDocumento !== "prescricao"}
                  >
                    <FileCheck className="w-4 h-4 text-gray-500" />
                    <span>Imprimir Prescrições ({tipoDocumento === "prescricao" ? pedidosSelecionados.length : 0})</span>
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2 text-left h-10"
                    disabled={pedidosSelecionados.length === 0 || tipoDocumento !== "declaracao"}
                  >
                    <FileText className="w-4 h-4 text-gray-500" />
                    <span>Imprimir Declarações ({tipoDocumento === "declaracao" ? pedidosSelecionados.length : 0})</span>
                  </Button>
                  <Button variant="outline" className="w-full justify-start gap-2 text-left h-10">
                    <ClipboardCheck className="w-4 h-4 text-gray-500" />
                    <span>Gerar Lista de Postagem</span>
                  </Button>
                  <Button variant="outline" className="w-full justify-start gap-2 text-left h-10">
                    <QrCode className="w-4 h-4 text-gray-500" />
                    <span>Gerar QR Codes</span>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="prescricoes" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <CardTitle>Prescrições Médicas</CardTitle>
                  <CardDescription>
                    Imprima prescrições médicas para anexar aos seus pedidos
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="relative w-80">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
                        <Input 
                          placeholder="Buscar por ID ou paciente..." 
                          className="pl-10"
                        />
                      </div>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" className="gap-2">
                          <FilePlus className="w-4 h-4" />
                          Nova Prescrição
                        </Button>
                        <Button className="gap-2">
                          <Printer className="w-4 h-4" />
                          Imprimir Selecionadas
                        </Button>
                      </div>
                    </div>
                    
                    <div className="rounded-lg border overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead>
                            <tr className="bg-gray-50">
                              <th className="px-4 py-3 text-left">
                                <Checkbox id="select-all-prescriptions" />
                              </th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">ID</th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Paciente</th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Médico</th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Data</th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Validade</th>
                              <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Ações</th>
                            </tr>
                          </thead>
                          <tbody>
                            {prescricoes.map((prescricao, i) => (
                              <tr key={prescricao.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                <td className="px-4 py-3">
                                  <Checkbox id={`pres-${prescricao.id}`} />
                                </td>
                                <td className="px-4 py-3 text-sm font-medium">{prescricao.id}</td>
                                <td className="px-4 py-3 text-sm text-gray-700">{prescricao.paciente}</td>
                                <td className="px-4 py-3 text-sm text-gray-700">{prescricao.medico}</td>
                                <td className="px-4 py-3 text-sm text-gray-700">{prescricao.data_emissao}</td>
                                <td className="px-4 py-3 text-sm text-gray-700">{prescricao.validade}</td>
                                <td className="px-4 py-3 text-right">
                                  <div className="flex justify-end gap-2">
                                    <Button variant="ghost" size="icon" onClick={() => { setPrescricaoSelecionada(prescricao); setShowPrescricaoPreview(true); }}>
                                      <Printer className="w-4 h-4" />
                                    </Button>
                                    <Button variant="ghost" size="icon">
                                      <Printer className="w-4 h-4" />
                                    </Button>
                                    <Button variant="ghost" size="icon">
                                      <Download className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Configurações de Prescrição</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Formato do Documento</Label>
                    <Select defaultValue="a4">
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o formato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="a4">A4</SelectItem>
                        <SelectItem value="a5">A5</SelectItem>
                        <SelectItem value="letter">Carta</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Opções de Impressão</Label>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="include-logo-prescricao2" defaultChecked />
                        <label htmlFor="include-logo-prescricao2" className="text-sm text-gray-700 cursor-pointer">
                          Incluir logo da empresa
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="include-header2" defaultChecked />
                        <label htmlFor="include-header2" className="text-sm text-gray-700 cursor-pointer">
                          Incluir cabeçalho com dados do médico
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="include-instructions2" defaultChecked />
                        <label htmlFor="include-instructions2" className="text-sm text-gray-700 cursor-pointer">
                          Incluir instruções de uso
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="include-qrcode2" defaultChecked />
                        <label htmlFor="include-qrcode2" className="text-sm text-gray-700 cursor-pointer">
                          Incluir QR Code para verificação
                        </label>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full gap-2">
                    <Printer className="w-4 h-4" />
                    Imprimir Modelo
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="declaracoes" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <CardTitle>Declaração de Conteúdo - Correios</CardTitle>
                  <CardDescription>
                    Gere e imprima declarações de conteúdo para envios pelo Correios
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-sm text-gray-600">
                      A Declaração de Conteúdo é um documento obrigatório para envios pelos Correios que contenha mercadorias. 
                      Este documento deve conter informações detalhadas sobre o conteúdo da embalagem.
                    </p>
                    
                    <div className="rounded-lg bg-blue-50 p-4 border border-blue-100 text-blue-800">
                      <div className="flex gap-2">
                        <ShieldCheck className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-medium">Informações importantes:</h4>
                          <p className="text-sm">
                            Para medicamentos controlados, é obrigatório incluir a prescrição médica junto com 
                            a declaração de conteúdo. Certifique-se de adicionar as informações corretas sobre
                            o produto, como nome e quantidade.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="relative w-80">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
                        <Input 
                          placeholder="Buscar pedido..." 
                          className="pl-10"
                        />
                      </div>
                      
                      <div className="flex gap-2">
                        <Button className="gap-2">
                          <Printer className="w-4 h-4" />
                          Gerar Declarações
                        </Button>
                      </div>
                    </div>
                    
                    <div className="rounded-lg border overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead>
                            <tr className="bg-gray-50">
                              <th className="px-4 py-3 text-left">
                                <Checkbox id="select-all-declarations" />
                              </th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Pedido</th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Cliente</th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Produtos</th>
                              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Método de Envio</th>
                              <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Ações</th>
                            </tr>
                          </thead>
                          <tbody>
                            {pedidos.map((pedido, i) => (
                              <tr key={pedido.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                <td className="px-4 py-3">
                                  <Checkbox id={`decl-${pedido.id}`} />
                                </td>
                                <td className="px-4 py-3 text-sm font-medium">#{pedido.id}</td>
                                <td className="px-4 py-3 text-sm text-gray-700">{pedido.cliente}</td>
                                <td className="px-4 py-3 text-sm text-gray-700">
                                  {pedido.produtos.map(p => p.nome).join(', ')}
                                </td>
                                <td className="px-4 py-3 text-sm text-gray-700">{pedido.metodo_envio}</td>
                                <td className="px-4 py-3 text-right">
                                  <div className="flex justify-end gap-2">
                                    <Button variant="ghost" size="icon" onClick={() => { setPedidoSelecionado(pedido); setShowDeclaracaoPreview(true); }}>
                                      <Eye className="w-4 h-4" />
                                    </Button>
                                    <Button variant="ghost" size="icon">
                                      <Printer className="w-4 h-4" />
                                    </Button>
                                    <Button variant="ghost" size="icon">
                                      <Download className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Configurações de Declaração</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Tipo de Envio</Label>
                    <RadioGroup
                      value={tipoEnvio}
                      onValueChange={setTipoEnvio}
                      className="flex flex-col space-y-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="nacional" id="nacional2" />
                        <Label htmlFor="nacional2">Nacional</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="internacional" id="internacional2" />
                        <Label htmlFor="internacional2">Internacional</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Formato do Documento</Label>
                    <Select defaultValue="a4">
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o formato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="a4">A4</SelectItem>
                        <SelectItem value="a5">A5</SelectItem>
                        <SelectItem value="correios">Padrão Correios</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Informações Adicionais</Label>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="include-valor2" defaultChecked />
                        <label htmlFor="include-valor2" className="text-sm text-gray-700 cursor-pointer">
                          Incluir valor declarado
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="include-anvisainfo2" defaultChecked />
                        <label htmlFor="include-anvisainfo2" className="text-sm text-gray-700 cursor-pointer">
                          Incluir informações ANVISA
                        </label>
                      </div>
                      {tipoEnvio === "internacional" && (
                        <div className="flex items-center space-x-2">
                          <Checkbox id="include-translation2" defaultChecked />
                          <label htmlFor="include-translation2" className="text-sm text-gray-700 cursor-pointer">
                            Incluir tradução em inglês
                          </label>
                        </div>
                      )}
                      <div className="flex items-center space-x-2">
                        <Checkbox id="include-remetente" defaultChecked />
                        <label htmlFor="include-remetente" className="text-sm text-gray-700 cursor-pointer">
                          Incluir dados completos do remetente
                        </label>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full gap-2">
                    <Printer className="w-4 h-4" />
                    Imprimir Modelo
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Diálogo de visualização de prescrição */}
      <Dialog open={showPrescricaoPreview} onOpenChange={setShowPrescricaoPreview}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>Prescrição Médica #{prescricaoSelecionada?.id}</DialogTitle>
            <DialogDescription>
              Visualização da prescrição médica para o paciente {prescricaoSelecionada?.paciente}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 max-h-[70vh] overflow-y-auto">
            {prescricaoSelecionada && (
              <div className="border rounded-lg p-8 bg-white">
                <div className="flex justify-between items-center mb-6 border-b pb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center">
                      <span className="text-green-600 font-bold text-xl">E</span>
                    </div>
                    <div>
                      <h2 className="text-xl font-bold">Endurancy</h2>
                      <p className="text-sm text-gray-500">CNPJ: 12.345.678/0001-90</p>
                      <p className="text-sm text-gray-500">Soluções em Cannabis Medicinal</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <h3 className="font-bold">PRESCRIÇÃO MÉDICA</h3>
                    <p className="text-sm text-gray-500">Emissão: {prescricaoSelecionada.data_emissao}</p>
                    <p className="text-sm text-gray-500">Validade: {prescricaoSelecionada.validade}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-6 mb-6">
                  <div>
                    <h3 className="text-sm font-bold text-gray-500 mb-2">DADOS DO PACIENTE</h3>
                    <p className="font-medium">{prescricaoSelecionada.paciente}</p>
                    <p className="text-sm text-gray-600">CPF: XXX.XXX.XXX-XX</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-gray-500 mb-2">DADOS DO MÉDICO</h3>
                    <p className="font-medium">{prescricaoSelecionada.medico}</p>
                    <p className="text-sm text-gray-600">{prescricaoSelecionada.crm}</p>
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-sm font-bold text-gray-500 mb-2">MEDICAMENTOS PRESCRITOS</h3>
                  <div className="space-y-3">
                    {prescricaoSelecionada.produtos.map((produto, index) => (
                      <div key={index} className="border rounded-lg p-3">
                        <p className="font-medium">{produto.nome}</p>
                        <p className="text-sm text-gray-600">Posologia: {produto.dosagem}</p>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-sm font-bold text-gray-500 mb-2">OBSERVAÇÕES</h3>
                  <p className="text-sm text-gray-600">
                    Este medicamento deve ser utilizado conforme orientação médica. Não interrompa o 
                    tratamento sem consultar seu médico. Em caso de efeitos colaterais, entre em 
                    contato imediatamente com seu médico.
                  </p>
                </div>
                
                <div className="pt-8 mt-8 border-t flex justify-between items-end">
                  <div className="w-40">
                    <div className="border-b border-black pb-1 mb-1"></div>
                    <p className="text-sm text-center">{prescricaoSelecionada.medico}</p>
                    <p className="text-xs text-center text-gray-500">{prescricaoSelecionada.crm}</p>
                  </div>
                  
                  <div className="bg-gray-100 p-4 rounded-lg flex items-center gap-2">
                    <QrCode className="w-8 h-8 text-gray-500" />
                    <div>
                      <h4 className="text-xs font-bold">VERIFICAÇÃO DIGITAL</h4>
                      <p className="text-xs text-gray-500">Escaneie para verificar autenticidade</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPrescricaoPreview(false)}>
              Fechar
            </Button>
            <Button>
              <Printer className="mr-2 h-4 w-4" />
              Imprimir Prescrição
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de visualização de declaração de conteúdo */}
      <Dialog open={showDeclaracaoPreview} onOpenChange={setShowDeclaracaoPreview}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>Declaração de Conteúdo - Pedido #{pedidoSelecionado?.id}</DialogTitle>
            <DialogDescription>
              Visualização da declaração de conteúdo para envio pelos Correios
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 max-h-[70vh] overflow-y-auto">
            {pedidoSelecionado && (
              <div className="border rounded-lg p-8 bg-white">
                <div className="flex justify-between items-center mb-6 border-b pb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <Truck className="w-8 h-8 text-yellow-600" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold">DECLARAÇÃO DE CONTEÚDO</h2>
                      <p className="text-sm text-gray-500">Correios - Serviço Postal Brasileiro</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500">Data: {pedidoSelecionado.data}</p>
                    <p className="text-sm text-gray-500">Pedido: #{pedidoSelecionado.id}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-6 mb-6">
                  <div>
                    <h3 className="text-sm font-bold text-gray-500 mb-2">REMETENTE</h3>
                    <p className="font-medium">Endurancy Cannabis Medicinal</p>
                    <p className="text-sm text-gray-600">CNPJ: 12.345.678/0001-90</p>
                    <p className="text-sm text-gray-600">Endereço: Av. Brasil, 1500 - Rio de Janeiro, RJ</p>
                    <p className="text-sm text-gray-600">CEP: 20000-000</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-gray-500 mb-2">DESTINATÁRIO</h3>
                    <p className="font-medium">{pedidoSelecionado.cliente}</p>
                    <p className="text-sm text-gray-600">{pedidoSelecionado.endereco}</p>
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-sm font-bold text-gray-500 mb-2">CONTEÚDO DA POSTAGEM</h3>
                  <div className="border rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="px-4 py-2 text-left">Descrição</th>
                          <th className="px-4 py-2 text-center">Quantidade</th>
                          <th className="px-4 py-2 text-right">Valor Unitário (R$)</th>
                          <th className="px-4 py-2 text-right">Valor Total (R$)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {pedidoSelecionado.produtos.map((produto, index) => (
                          <tr key={index} className="border-t">
                            <td className="px-4 py-2">{produto.nome}</td>
                            <td className="px-4 py-2 text-center">{produto.quantidade}</td>
                            <td className="px-4 py-2 text-right">150,00</td>
                            <td className="px-4 py-2 text-right">{150 * produto.quantidade},00</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="border-t bg-gray-50">
                          <td colSpan={3} className="px-4 py-2 text-right font-medium">Valor Total:</td>
                          <td className="px-4 py-2 text-right font-medium">
                            {pedidoSelecionado.produtos.reduce((total, produto) => total + (150 * produto.quantidade), 0)},00
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
                
                <div className="mb-6 p-4 border rounded-lg bg-gray-50">
                  <h3 className="text-sm font-bold text-gray-500 mb-2">OBSERVAÇÕES IMPORTANTES</h3>
                  <p className="text-sm text-gray-600">
                    Declaro para os devidos fins que o conteúdo descrito acima corresponde exatamente ao contido
                    na embalagem e que não se trata de material perigoso, inflamável ou sujeito à regulamentação
                    especial para transporte. Estes produtos possuem registro ANVISA e estão sendo enviados de acordo
                    com prescrição médica em anexo.
                  </p>
                </div>
                
                <div className="pt-8 mt-8 border-t flex justify-between items-end">
                  <div className="w-40">
                    <div className="border-b border-black pb-1 mb-1"></div>
                    <p className="text-sm text-center">Assinatura do Remetente</p>
                  </div>
                  
                  <div className="w-40">
                    <div className="border-b border-black pb-1 mb-1"></div>
                    <p className="text-sm text-center">Assinatura do Destinatário</p>
                  </div>
                </div>
                
                <div className="mt-8 pt-2 border-t text-xs text-gray-500 text-center">
                  <p>Esta declaração deve acompanhar o envio para fins de fiscalização.</p>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeclaracaoPreview(false)}>
              Fechar
            </Button>
            <Button>
              <Printer className="mr-2 h-4 w-4" />
              Imprimir Declaração
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
