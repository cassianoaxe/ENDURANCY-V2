import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Package, 
  ArrowLeft, 
  Save, 
  Plus, 
  Trash2, 
  Check, 
  X,
  Info
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";

export default function ProducaoNovaMateriaPrima() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const materialId = searchParams.get('id');
  const isEditMode = Boolean(materialId);
  
  const [formData, setFormData] = useState({
    codigo: "",
    nome: "",
    tipo: "materia_prima",
    descricao: "",
    requer_analise_qualidade: true,
    unidade_medida: "",
    fabricante: "",
    fornecedor: "",
    validade_dias: 365,
    condicoes_armazenamento: ""
  });
  
  const [especificacoes, setEspecificacoes] = useState([]);
  const [novaEspecificacao, setNovaEspecificacao] = useState({
    parametro: "",
    metodo: "",
    especificacao_min: "",
    especificacao_max: "",
    unidade: "",
    obrigatorio: true
  });
  
  const [showEspecificacaoForm, setShowEspecificacaoForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  useEffect(() => {
    // Se estiver em modo de edição, carregue os dados existentes
    if (isEditMode) {
      loadMaterialData(materialId);
    } else {
      // Gere um código automático para novo material
      const randomCode = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      setFormData({
        ...formData,
        codigo: `MP-${new Date().getFullYear()}-${randomCode}`
      });
    }
  }, [materialId]);
  
  const loadMaterialData = async (id) => {
    try {
      setIsLoading(true);
      // Em um cenário real, buscaríamos os dados do servidor
      // Aqui simulamos um carregamento
      setTimeout(() => {
        // Mock data
        const materialMock = {
          id,
          codigo: "MP-CBD-001",
          nome: "Extrato CBD Isolado",
          tipo: "materia_prima",
          descricao: "Extrato de CBD isolado com pureza mínima de 99.5%",
          requer_analise_qualidade: true,
          unidade_medida: "kg",
          fabricante: "CannabEx",
          fornecedor: "CannabTech Distribuidora",
          validade_dias: 730,
          condicoes_armazenamento: "Manter em local fresco, seco e ao abrigo da luz. Temperatura entre 15°C e 25°C."
        };
        
        const especificacoesMock = [
          {
            parametro: "Pureza CBD",
            metodo: "HPLC",
            especificacao_min: "99.5",
            especificacao_max: "100.0",
            unidade: "%",
            obrigatorio: true
          },
          {
            parametro: "Teor THC",
            metodo: "HPLC",
            especificacao_min: "",
            especificacao_max: "0.05",
            unidade: "%",
            obrigatorio: true
          },
          {
            parametro: "Metais Pesados",
            metodo: "ICP-MS",
            especificacao_min: "",
            especificacao_max: "Conforme monografia",
            unidade: "ppm",
            obrigatorio: true
          }
        ];
        
        setFormData(materialMock);
        setEspecificacoes(especificacoesMock);
        setIsLoading(false);
      }, 1000);
    } catch (error) {
      console.error("Erro ao carregar dados do material:", error);
      toast({
        title: "Erro ao carregar dados",
        description: "Não foi possível carregar os dados do material.",
        variant: "destructive"
      });
      setIsLoading(false);
    }
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  const handleSwitchChange = (name, checked) => {
    setFormData({
      ...formData,
      [name]: checked
    });
  };
  
  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  const handleEspecificacaoChange = (e) => {
    const { name, value } = e.target;
    setNovaEspecificacao({
      ...novaEspecificacao,
      [name]: value
    });
  };
  
  const handleEspecificacaoSwitchChange = (checked) => {
    setNovaEspecificacao({
      ...novaEspecificacao,
      obrigatorio: checked
    });
  };
  
  const addEspecificacao = () => {
    if (!novaEspecificacao.parametro || !novaEspecificacao.metodo) {
      toast({
        title: "Campos obrigatórios",
        description: "Parâmetro e método são campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }
    
    setEspecificacoes([...especificacoes, novaEspecificacao]);
    setNovaEspecificacao({
      parametro: "",
      metodo: "",
      especificacao_min: "",
      especificacao_max: "",
      unidade: "",
      obrigatorio: true
    });
    setShowEspecificacaoForm(false);
  };
  
  const removeEspecificacao = (index) => {
    const updatedEspecificacoes = [...especificacoes];
    updatedEspecificacoes.splice(index, 1);
    setEspecificacoes(updatedEspecificacoes);
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.nome || !formData.codigo || !formData.unidade_medida) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // Em um cenário real, enviaríamos os dados para o servidor
      // Aqui simulamos o envio
      setTimeout(() => {
        toast({
          title: isEditMode ? "Material atualizado" : "Material cadastrado",
          description: isEditMode 
            ? `O material ${formData.nome} foi atualizado com sucesso.` 
            : `O material ${formData.nome} foi cadastrado com sucesso.`,
        });
        
        setIsSubmitting(false);
        navigate(createPageUrl("ProducaoMateriasPrimas"));
      }, 1500);
    } catch (error) {
      console.error("Erro ao salvar material:", error);
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar o material.",
        variant: "destructive"
      });
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => navigate(createPageUrl("ProducaoMateriasPrimas"))}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Package className="h-6 w-6" />
              {isEditMode ? "Editar Material" : "Novo Material"}
            </h1>
            <p className="text-gray-500 mt-1">
              {isEditMode 
                ? "Atualize as informações do material existente" 
                : "Cadastre um novo material ou embalagem no sistema"}
            </p>
          </div>
        </div>
        
        <Button className="gap-2" onClick={handleSubmit} disabled={isSubmitting}>
          <Save className="h-4 w-4" />
          {isSubmitting ? "Salvando..." : "Salvar Material"}
        </Button>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center h-60">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações Básicas</CardTitle>
              <CardDescription>
                Informações gerais sobre o material
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="codigo">Código <span className="text-red-500">*</span></Label>
                  <Input
                    id="codigo"
                    name="codigo"
                    value={formData.codigo}
                    onChange={handleInputChange}
                    placeholder="Ex: MP-CBD-001"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome <span className="text-red-500">*</span></Label>
                  <Input
                    id="nome"
                    name="nome"
                    value={formData.nome}
                    onChange={handleInputChange}
                    placeholder="Nome do material"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tipo">Tipo <span className="text-red-500">*</span></Label>
                  <Select
                    value={formData.tipo}
                    onValueChange={(value) => handleSelectChange("tipo", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="materia_prima">Matéria-Prima</SelectItem>
                      <SelectItem value="embalagem">Embalagem</SelectItem>
                      <SelectItem value="consumivel">Consumível</SelectItem>
                      <SelectItem value="produto_terminado">Produto Terminado</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="unidade_medida">Unidade de Medida <span className="text-red-500">*</span></Label>
                  <Input
                    id="unidade_medida"
                    name="unidade_medida"
                    value={formData.unidade_medida}
                    onChange={handleInputChange}
                    placeholder="Ex: kg, L, un"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="fabricante">Fabricante</Label>
                  <Input
                    id="fabricante"
                    name="fabricante"
                    value={formData.fabricante}
                    onChange={handleInputChange}
                    placeholder="Nome do fabricante"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="fornecedor">Fornecedor Principal</Label>
                  <Input
                    id="fornecedor"
                    name="fornecedor"
                    value={formData.fornecedor}
                    onChange={handleInputChange}
                    placeholder="Nome do fornecedor principal"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="validade_dias">Validade (em dias)</Label>
                  <Input
                    id="validade_dias"
                    name="validade_dias"
                    type="number"
                    value={formData.validade_dias}
                    onChange={handleInputChange}
                    placeholder="Ex: 365"
                  />
                </div>
                
                <div className="space-y-2 flex items-center gap-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="requer_analise_qualidade"
                      checked={formData.requer_analise_qualidade}
                      onCheckedChange={(checked) => handleSwitchChange("requer_analise_qualidade", checked)}
                    />
                    <Label htmlFor="requer_analise_qualidade">Requer Análise de Qualidade</Label>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição</Label>
                <Textarea
                  id="descricao"
                  name="descricao"
                  value={formData.descricao}
                  onChange={handleInputChange}
                  placeholder="Descrição detalhada do material"
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="condicoes_armazenamento">Condições de Armazenamento</Label>
                <Textarea
                  id="condicoes_armazenamento"
                  name="condicoes_armazenamento"
                  value={formData.condicoes_armazenamento}
                  onChange={handleInputChange}
                  placeholder="Detalhes sobre as condições ideais de armazenamento"
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>
          
          {formData.requer_analise_qualidade && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Especificações de Qualidade</CardTitle>
                  <CardDescription>
                    Parâmetros e especificações para controle de qualidade
                  </CardDescription>
                </div>
                <Button 
                  onClick={() => setShowEspecificacaoForm(true)} 
                  className="gap-2"
                  variant="outline"
                >
                  <Plus className="h-4 w-4" />
                  Adicionar Especificação
                </Button>
              </CardHeader>
              <CardContent>
                {especificacoes.length === 0 && !showEspecificacaoForm ? (
                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertTitle>Nenhuma especificação</AlertTitle>
                    <AlertDescription>
                      Este material requer análise de qualidade, mas ainda não possui especificações definidas.
                      Adicione as especificações necessárias para a garantia da qualidade.
                    </AlertDescription>
                  </Alert>
                ) : (
                  <div className="space-y-6">
                    {showEspecificacaoForm && (
                      <Card className="border-dashed">
                        <CardHeader className="pb-3">
                          <CardTitle className="text-base">Nova Especificação</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor="parametro">Parâmetro <span className="text-red-500">*</span></Label>
                              <Input
                                id="parametro"
                                name="parametro"
                                value={novaEspecificacao.parametro}
                                onChange={handleEspecificacaoChange}
                                placeholder="Ex: Pureza, pH, Viscosidade"
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor="metodo">Método de Análise <span className="text-red-500">*</span></Label>
                              <Input
                                id="metodo"
                                name="metodo"
                                value={novaEspecificacao.metodo}
                                onChange={handleEspecificacaoChange}
                                placeholder="Ex: HPLC, Titulação"
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor="especificacao_min">Especificação Mínima</Label>
                              <Input
                                id="especificacao_min"
                                name="especificacao_min"
                                value={novaEspecificacao.especificacao_min}
                                onChange={handleEspecificacaoChange}
                                placeholder="Valor mínimo aceitável"
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor="especificacao_max">Especificação Máxima</Label>
                              <Input
                                id="especificacao_max"
                                name="especificacao_max"
                                value={novaEspecificacao.especificacao_max}
                                onChange={handleEspecificacaoChange}
                                placeholder="Valor máximo aceitável"
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor="unidade">Unidade</Label>
                              <Input
                                id="unidade"
                                name="unidade"
                                value={novaEspecificacao.unidade}
                                onChange={handleEspecificacaoChange}
                                placeholder="Ex: %, mg/kg, pH"
                              />
                            </div>
                            
                            <div className="flex items-center space-x-2 pt-8">
                              <Switch
                                id="obrigatorio"
                                checked={novaEspecificacao.obrigatorio}
                                onCheckedChange={handleEspecificacaoSwitchChange}
                              />
                              <Label htmlFor="obrigatorio">Teste Obrigatório</Label>
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="justify-between border-t px-6 py-4">
                          <Button variant="ghost" onClick={() => setShowEspecificacaoForm(false)}>
                            Cancelar
                          </Button>
                          <Button onClick={addEspecificacao}>
                            Adicionar
                          </Button>
                        </CardFooter>
                      </Card>
                    )}
                    
                    {especificacoes.length > 0 && (
                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Parâmetro</TableHead>
                              <TableHead>Método</TableHead>
                              <TableHead>Especificação</TableHead>
                              <TableHead>Unidade</TableHead>
                              <TableHead>Obrigatório</TableHead>
                              <TableHead className="text-right">Ações</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {especificacoes.map((spec, index) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium">{spec.parametro}</TableCell>
                                <TableCell>{spec.metodo}</TableCell>
                                <TableCell>
                                  {spec.especificacao_min && spec.especificacao_max 
                                    ? `${spec.especificacao_min} - ${spec.especificacao_max}` 
                                    : spec.especificacao_min 
                                      ? `Mín: ${spec.especificacao_min}`
                                      : spec.especificacao_max 
                                        ? `Máx: ${spec.especificacao_max}`
                                        : 'N/A'}
                                </TableCell>
                                <TableCell>{spec.unidade || 'N/A'}</TableCell>
                                <TableCell>
                                  {spec.obrigatorio ? (
                                    <Check className="h-4 w-4 text-green-600" />
                                  ) : (
                                    <X className="h-4 w-4 text-gray-400" />
                                  )}
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => removeEspecificacao(index)}
                                  >
                                    <Trash2 className="h-4 w-4 text-red-500" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}