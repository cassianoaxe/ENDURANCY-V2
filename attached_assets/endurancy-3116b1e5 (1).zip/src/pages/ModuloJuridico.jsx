
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Scale, 
  FileText, 
  ClipboardList, 
  Award, 
  ArrowRight, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  BarChart3,
  FileCheck,
  BarChart4,
  Plus,
  Users,
  Building2,
  Leaf, 
  Heart,
  MoreHorizontal
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem,
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function ModuloJuridico() {
  const [activeTab, setActiveTab] = useState("visao-geral");
  const [loading, setLoading] = useState(true);
  const [moduleEnabled, setModuleEnabled] = useState(false);
  const [organizations, setOrganizations] = useState([]);
  const [showAddOrgDialog, setShowAddOrgDialog] = useState(false);
  const [availableOrganizations, setAvailableOrganizations] = useState([]);
  const [selectedOrganizationId, setSelectedOrganizationId] = useState("");
  const [stats, setStats] = useState({
    total_acoes: 0,
    procedentes: 0,
    improcedentes: 0,
    em_andamento: 0,
    total_organizacoes: 0,
    organizacoes_ativas: 0
  });

  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
      setModuleEnabled(true);
      setOrganizations([
        { id: 1, name: "Associação CannaVida", type: "Associação", active: true, actions: 24, patients: 127 },
        { id: 2, name: "MediCanna Brasil", type: "Empresa", active: true, actions: 18, patients: 89 },
        { id: 3, name: "Instituto Cannabis Medicinal", type: "Associação", active: false, actions: 0, patients: 43 },
        { id: 4, name: "PharmaCann", type: "Empresa", active: true, actions: 15, patients: 76 },
        { id: 5, name: "Verde Esperança", type: "Associação", active: true, actions: 31, patients: 152 }
      ]);
      setAvailableOrganizations([
        { id: 6, name: "Herbal Medicines Ltda", type: "Empresa", patients: 45 },
        { id: 7, name: "Associação Brasileira de Cannabis", type: "Associação", patients: 92 },
        { id: 8, name: "CannaMed Farmacêutica", type: "Empresa", patients: 63 },
        { id: 9, name: "Coletivo Verde", type: "Associação", patients: 108 }
      ]);
      setStats({
        total_acoes: 124,
        procedentes: 67,
        improcedentes: 12,
        em_andamento: 45,
        total_organizacoes: 24,
        organizacoes_ativas: 18
      });
    }, 1000);
  }, []);

  const toggleModuleStatus = () => {
    setModuleEnabled(!moduleEnabled);
  };

  const addModuleToOrganization = () => {
    if (selectedOrganizationId) {
      const selectedOrg = availableOrganizations.find(org => org.id.toString() === selectedOrganizationId);
      if (selectedOrg) {
        setOrganizations([...organizations, {...selectedOrg, active: true, actions: 0}]);
        setAvailableOrganizations(availableOrganizations.filter(org => org.id.toString() !== selectedOrganizationId));
        setShowAddOrgDialog(false);
        setSelectedOrganizationId("");
      }
    }
  };

  const toggleOrganizationStatus = (orgId) => {
    setOrganizations(organizations.map(org => {
      if (org.id === orgId) {
        return {...org, active: !org.active};
      }
      return org;
    }));
  };

  const removeModuleFromOrganization = (orgId) => {
    const orgToRemove = organizations.find(org => org.id === orgId);
    if (orgToRemove) {
      setOrganizations(organizations.filter(org => org.id !== orgId));
      setAvailableOrganizations([...availableOrganizations, {
        id: orgToRemove.id,
        name: orgToRemove.name,
        type: orgToRemove.type,
        patients: orgToRemove.patients
      }]);
    }
  };

  const featureList = [
    { icon: <FileText className="w-5 h-5 text-blue-600" />, title: "Gestão de Ações Judiciais", description: "Controle centralizado de processos judiciais para fornecimento de medicamentos" },
    { icon: <ClipboardList className="w-5 h-5 text-indigo-600" />, title: "Controle de Prazos", description: "Acompanhamento de prazos processuais com alertas automáticos" },
    { icon: <Award className="w-5 h-5 text-green-600" />, title: "Gestão de Liminares", description: "Acompanhamento específico de pedidos de liminares e seus resultados" },
    { icon: <Users className="w-5 h-5 text-purple-600" />, title: "Perfil dos Pacientes", description: "Informações completas dos pacientes vinculados aos processos" }
  ];

  const renderIcon = (IconComponent, className = "w-5 h-5") => {
    if (!IconComponent) return null;
    return <IconComponent className={className} />;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[500px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">Carregando informações do módulo...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Scale className="w-6 h-6 text-blue-600" />
            Módulo Jurídico
          </h1>
          <p className="text-gray-500 mt-1">
            Gerencie ações judiciais para fornecimento de medicamentos
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Label htmlFor="module-status" className="font-medium">Status do Módulo:</Label>
            <Switch id="module-status" checked={moduleEnabled} onCheckedChange={toggleModuleStatus} />
            <Badge className={moduleEnabled ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
              {moduleEnabled ? "Ativo" : "Inativo"}
            </Badge>
          </div>
          <Button variant="outline" asChild>
            <Link to={createPageUrl("JuridicoDashboard")}>
              <BarChart3 className="w-4 h-4 mr-2" />
              Dashboard
            </Link>
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="visao-geral">Visão Geral</TabsTrigger>
          <TabsTrigger value="organizacoes">Organizações</TabsTrigger>
          <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
        </TabsList>
        
        <TabsContent value="visao-geral" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>{stats.total_acoes}</CardTitle>
                <CardDescription>Total de Ações</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-blue-600">
                  {renderIcon(FileText)}
                  <span>Em andamento: {stats.em_andamento}</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>{stats.procedentes}</CardTitle>
                <CardDescription>Ações Procedentes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-green-600">
                  {renderIcon(CheckCircle2)}
                  <span>Taxa de êxito: {Math.round(stats.procedentes / stats.total_acoes * 100)}%</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>{stats.total_organizacoes}</CardTitle>
                <CardDescription>Organizações</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-indigo-600">
                  {renderIcon(Building2)}
                  <span>Ativas: {stats.organizacoes_ativas}</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>R$ 3.2M</CardTitle>
                <CardDescription>Economia Estimada</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-purple-600">
                  {renderIcon(BarChart4)}
                  <span>Medicamentos fornecidos</span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Recursos e Funcionalidades</CardTitle>
              <CardDescription>
                O módulo jurídico facilita a gestão de ações judiciais relacionadas ao fornecimento de medicamentos à base de cannabis.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-6 sm:grid-cols-2">
              {featureList.map((feature, index) => (
                <div key={index} className="flex gap-2">
                  <div className="mt-0.5">{feature.icon}</div>
                  <div>
                    <h3 className="font-medium">{feature.title}</h3>
                    <p className="text-sm text-gray-500">{feature.description}</p>
                  </div>
                </div>
              ))}
            </CardContent>
            <CardFooter>
              <Button variant="outline" asChild className="w-full sm:w-auto">
                <Link to={createPageUrl("JuridicoAcoes")}>
                  Ver ações judiciais
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="organizacoes" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Organizações com Módulo Jurídico</CardTitle>
                <CardDescription>
                  Lista de organizações com acesso ao módulo jurídico
                </CardDescription>
              </div>
              <Button onClick={() => setShowAddOrgDialog(true)}>
                {renderIcon(Plus)}
                Adicionar Organização
              </Button>
            </CardHeader>
            <CardContent>
              {organizations.length === 0 ? (
                <div className="text-center py-8">
                  {renderIcon(Building2)}
                  <h3 className="mt-2 text-lg font-medium">Nenhuma organização encontrada</h3>
                  <p className="text-gray-500">Adicione organizações para usar o módulo jurídico</p>
                  <Button className="mt-4" onClick={() => setShowAddOrgDialog(true)}>
                    {renderIcon(Plus)}
                    Adicionar Organização
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {organizations.map((org) => (
                    <div key={org.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-50 rounded-lg">
                          {renderIcon(Building2, "w-5 h-5 text-blue-600")}
                        </div>
                        <div>
                          <Link 
                            to={`${createPageUrl("Organization")}?id=${org.id}`}
                            className="font-medium hover:underline"
                          >
                            {org.name}
                          </Link>
                          <div className="flex items-center gap-2 text-sm text-gray-500">
                            <Badge variant="outline" className="text-xs">{org.type}</Badge>
                            <span>•</span>
                            <span>{org.patients} pacientes</span>
                            <span>•</span>
                            <span>{org.actions} ações</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={org.active ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                          {org.active ? "Ativo" : "Inativo"}
                        </Badge>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              {renderIcon(MoreHorizontal, "h-4 w-4")}
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => toggleOrganizationStatus(org.id)}>
                              {org.active ? "Desativar" : "Ativar"} módulo
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link to={`${createPageUrl("JuridicoAcoes")}?org=${org.id}`}>
                                Ver ações judiciais
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              className="text-red-600"
                              onClick={() => removeModuleFromOrganization(org.id)}
                            >
                              Remover módulo
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="configuracoes" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do Módulo</CardTitle>
              <CardDescription>Defina as configurações gerais do módulo jurídico</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="alertas-prazos">Alertas de prazos processuais</Label>
                  <Switch id="alertas-prazos" defaultChecked />
                </div>
                <p className="text-sm text-gray-500">Enviar alertas por email sobre prazos processuais próximos</p>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="relatorios-automaticos">Relatórios automáticos</Label>
                  <Switch id="relatorios-automaticos" defaultChecked />
                </div>
                <p className="text-sm text-gray-500">Gerar relatórios automáticos mensais de desempenho</p>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="compartilhar-dados">Compartilhar dados entre organizações</Label>
                  <Switch id="compartilhar-dados" />
                </div>
                <p className="text-sm text-gray-500">Permite compartilhar estratégias judiciais entre organizações (anônimas)</p>
              </div>
              
              <div className="space-y-2">
                <Label>Dias de antecedência para alertas</Label>
                <Select defaultValue="7">
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Selecione o período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 dias</SelectItem>
                    <SelectItem value="5">5 dias</SelectItem>
                    <SelectItem value="7">7 dias</SelectItem>
                    <SelectItem value="10">10 dias</SelectItem>
                    <SelectItem value="15">15 dias</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-2">
              <Button variant="outline">Restabelecer Padrões</Button>
              <Button>Salvar Configurações</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showAddOrgDialog} onOpenChange={setShowAddOrgDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Organização</DialogTitle>
            <DialogDescription>
              Selecione uma organização para ativar o módulo jurídico
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Label htmlFor="organization">Organização</Label>
            <Select 
              value={selectedOrganizationId} 
              onValueChange={setSelectedOrganizationId}
            >
              <SelectTrigger className="w-full mt-1" id="organization">
                <SelectValue placeholder="Selecione uma organização" />
              </SelectTrigger>
              <SelectContent>
                {availableOrganizations.map((org) => (
                  <SelectItem key={org.id} value={org.id.toString()}>
                    {org.name} ({org.type})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {availableOrganizations.length === 0 && (
              <p className="text-sm text-amber-600 mt-2 flex items-center">
                {renderIcon(AlertTriangle, "w-4 h-4 mr-1")}
                Todas as organizações já possuem o módulo jurídico ativado
              </p>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddOrgDialog(false)}>
              Cancelar
            </Button>
            <Button
              onClick={addModuleToOrganization}
              disabled={!selectedOrganizationId || availableOrganizations.length === 0}
            >
              Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
