import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Truck,
  Box,
  Package,
  Search,
  Filter,
  Plus,
  X,
  Check,
  CheckSquare,
  Clock,
  Calendar,
  FileText,
  UserCheck,
  Users,
  MapPin,
  MoreHorizontal,
  Edit,
  Printer,
  QrCode,
  ScanBarcode,
  PackageCheck,
  PackageOpen,
  Eye,
  Trash,
  AlertTriangle,
  Download,
  RefreshCw,
  Send,
  ArrowRightCircle
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from "@/components/ui/dropdown-menu";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";

// Dados simulados para malotes
const mockShipments = [
  {
    id: "1",
    shipment_number: "ML-12345",
    status: "em_preparacao",
    carrier: "Correios",
    service: "SEDEX",
    created_date: "2023-11-15T09:30:00",
    scheduled_date: "2023-11-16",
    tracking_code: "",
    total_orders: 5,
    orders_ready: 3,
    orders: [
      { id: "1", number: "PED-12340", customer: "João Silva", status: "pronto", items: 2 },
      { id: "2", number: "PED-12341", customer: "Maria Oliveira", status: "pronto", items: 1 },
      { id: "3", number: "PED-12342", customer: "Carlos Santos", status: "pronto", items: 3 },
      { id: "4", number: "PED-12343", customer: "Ana Costa", status: "separando", items: 2 },
      { id: "5", number: "PED-12344", customer: "Paulo Mendes", status: "separando", items: 1 }
    ],
    destination: "Agência Correios - Centro",
    notes: "Malote com pedidos SEDEX para região Sudeste",
    responsible: "Ana Carolina",
    weight: 3.2, // kg
    estimated_cost: 125.50
  },
  {
    id: "2",
    shipment_number: "ML-12346",
    status: "enviado",
    carrier: "Correios",
    service: "PAC",
    created_date: "2023-11-14T14:45:00",
    scheduled_date: "2023-11-15",
    shipping_date: "2023-11-15T10:30:00",
    tracking_code: "BR987654321BR",
    total_orders: 8,
    orders_ready: 8,
    orders: [
      { id: "6", number: "PED-12330", customer: "Roberto Alves", status: "enviado", items: 1 },
      { id: "7", number: "PED-12331", customer: "Fernanda Lima", status: "enviado", items: 2 },
      { id: "8", number: "PED-12332", customer: "Marcelo Souza", status: "enviado", items: 1 },
      { id: "9", number: "PED-12333", customer: "Juliana Pereira", status: "enviado", items: 3 },
      { id: "10", number: "PED-12334", customer: "Ricardo Gomes", status: "enviado", items: 1 },
      { id: "11", number: "PED-12335", customer: "Camila Dias", status: "enviado", items: 2 },
      { id: "12", number: "PED-12336", customer: "Bruno Rocha", status: "enviado", items: 1 },
      { id: "13", number: "PED-12337", customer: "Aline Santos", status: "enviado", items: 1 }
    ],
    destination: "Agência Correios - Vila Mariana",
    notes: "Malote com pedidos PAC para região Sul",
    responsible: "Carlos Eduardo",
    weight: 5.8, // kg
    receipt_url: "https://exemplo.com/comprovante.pdf",
    estimated_cost: 145.80,
    actual_cost: 142.30
  },
  {
    id: "3",
    shipment_number: "ML-12347",
    status: "agendado",
    carrier: "Jadlog",
    service: "Expresso",
    created_date: "2023-11-15T11:20:00",
    scheduled_date: "2023-11-17",
    total_orders: 4,
    orders_ready: 4,
    orders: [
      { id: "14", number: "PED-12350", customer: "Eduardo Silva", status: "pronto", items: 2 },
      { id: "15", number: "PED-12351", customer: "Patrícia Oliveira", status: "pronto", items: 1 },
      { id: "16", number: "PED-12352", customer: "Rodrigo Lima", status: "pronto", items: 3 },
      { id: "17", number: "PED-12353", customer: "Carla Mendes", status: "pronto", items: 2 }
    ],
    destination: "Unidade Jadlog - Lapa",
    notes: "Malote com pedidos Jadlog para região Nordeste",
    responsible: "Marcos Paulo",
    weight: 4.1, // kg
    estimated_cost: 168.90,
    pickup_time: "14:00 - 16:00"
  },
  {
    id: "4",
    shipment_number: "ML-12348",
    status: "cancelado",
    carrier: "Transportadora",
    service: "Standard",
    created_date: "2023-11-13T09:15:00",
    scheduled_date: "2023-11-14",
    canceled_date: "2023-11-13T16:45:00",
    total_orders: 3,
    orders_ready: 0,
    orders: [
      { id: "18", number: "PED-12360", customer: "Mariana Costa", status: "realocado", items: 1 },
      { id: "19", number: "PED-12361", customer: "Felipe Santos", status: "realocado", items: 2 },
      { id: "20", number: "PED-12362", customer: "Daniela Pereira", status: "realocado", items: 1 }
    ],
    destination: "Transportadora XYZ - Unidade Central",
    notes: "Malote cancelado devido a problemas com a transportadora. Pedidos realocados para outros malotes.",
    responsible: "Diego Almeida",
    cancel_reason: "Transportadora sem disponibilidade na data agendada"
  },
  {
    id: "5",
    shipment_number: "ML-12349",
    status: "em_preparacao",
    carrier: "Correios",
    service: "SEDEX",
    created_date: "2023-11-15T13:40:00",
    scheduled_date: "2023-11-16",
    total_orders: 6,
    orders_ready: 2,
    orders: [
      { id: "21", number: "PED-12370", customer: "Luciana Martins", status: "pronto", items: 1 },
      { id: "22", number: "PED-12371", customer: "Rafael Gomes", status: "pronto", items: 2 },
      { id: "23", number: "PED-12372", customer: "Sandra Oliveira", status: "separando", items: 1 },
      { id: "24", number: "PED-12373", customer: "Victor Almeida", status: "separando", items: 3 },
      { id: "25", number: "PED-12374", customer: "Beatriz Lima", status: "separando", items: 1 },
      { id: "26", number: "PED-12375", customer: "Thiago Costa", status: "separando", items: 2 }
    ],
    destination: "Agência Correios - Pinheiros",
    notes: "Malote com pedidos SEDEX para região Centro-Oeste",
    responsible: "Renata Soares",
    weight: 4.5, // kg
    estimated_cost: 135.20
  }
];

export default function ExpedicaoMalotes() {
  const [malotes, setMalotes] = useState(mockShipments);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [carrierFilter, setCarrierFilter] = useState("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [selectedMalote, setSelectedMalote] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false);
  
  // Novo malote form state
  const [newMalote, setNewMalote] = useState({
    carrier: "",
    service: "",
    scheduled_date: "",
    destination: "",
    notes: "",
    responsible: ""
  });
  
  const filteredMalotes = malotes.filter(malote => {
    // Filtrar por termo de busca
    const matchesSearch = 
      malote.shipment_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      malote.destination.toLowerCase().includes(searchTerm.toLowerCase()) ||
      malote.orders.some(order => 
        order.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer.toLowerCase().includes(searchTerm.toLowerCase())
      );
    
    // Filtrar por status
    const matchesStatus = statusFilter === "all" || malote.status === statusFilter;
    
    // Filtrar por transportadora
    const matchesCarrier = carrierFilter === "all" || malote.carrier === carrierFilter;
    
    return matchesSearch && matchesStatus && matchesCarrier;
  });

  const handleAddMalote = () => {
    // Lógica para adicionar novo malote
    const newShipment = {
      id: `${malotes.length + 1}`,
      shipment_number: `ML-${12350 + malotes.length}`,
      status: "em_preparacao",
      carrier: newMalote.carrier,
      service: newMalote.service,
      created_date: new Date().toISOString(),
      scheduled_date: newMalote.scheduled_date,
      total_orders: 0,
      orders_ready: 0,
      orders: [],
      destination: newMalote.destination,
      notes: newMalote.notes,
      responsible: newMalote.responsible,
      weight: 0,
      estimated_cost: 0
    };
    
    setMalotes([...malotes, newShipment]);
    setIsAddDialogOpen(false);
    // Resetar form
    setNewMalote({
      carrier: "",
      service: "",
      scheduled_date: "",
      destination: "",
      notes: "",
      responsible: ""
    });
  };

  const handleViewMalote = (malote) => {
    setSelectedMalote(malote);
    setIsDetailDialogOpen(true);
    setIsEditMode(false);
  };

  const handleEditMalote = () => {
    setIsEditMode(true);
  };

  const handleSaveEdit = () => {
    const updatedMalotes = malotes.map(m => 
      m.id === selectedMalote.id ? selectedMalote : m
    );
    setMalotes(updatedMalotes);
    setIsEditMode(false);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "em_preparacao":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Em Preparação</Badge>;
      case "agendado":
        return <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">Agendado</Badge>;
      case "enviado":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Enviado</Badge>;
      case "entregue":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Entregue</Badge>;
      case "cancelado":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Cancelado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getOrderStatusBadge = (status) => {
    switch (status) {
      case "pronto":
        return <Badge className="bg-green-50 text-green-700 border-green-200">Pronto</Badge>;
      case "separando":
        return <Badge className="bg-yellow-50 text-yellow-700 border-yellow-200">Separando</Badge>;
      case "enviado":
        return <Badge className="bg-blue-50 text-blue-700 border-blue-200">Enviado</Badge>;
      case "realocado":
        return <Badge className="bg-purple-50 text-purple-700 border-purple-200">Realocado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
  };

  const formatDateTime = (dateTimeString) => {
    if (!dateTimeString) return "";
    const date = new Date(dateTimeString);
    return date.toLocaleString('pt-BR');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Malotes de Expedição</h1>
          <p className="text-gray-500 mt-1">
            Gerencie os malotes para envio de pedidos
          </p>
        </div>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Novo Malote
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between bg-white p-4 rounded-lg shadow-sm">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar malotes..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Status</SelectItem>
              <SelectItem value="em_preparacao">Em Preparação</SelectItem>
              <SelectItem value="agendado">Agendado</SelectItem>
              <SelectItem value="enviado">Enviado</SelectItem>
              <SelectItem value="entregue">Entregue</SelectItem>
              <SelectItem value="cancelado">Cancelado</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={carrierFilter} onValueChange={setCarrierFilter}>
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue placeholder="Transportadora" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              <SelectItem value="Correios">Correios</SelectItem>
              <SelectItem value="Jadlog">Jadlog</SelectItem>
              <SelectItem value="Transportadora">Transportadora</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredMalotes.length === 0 ? (
        <Card className="w-full">
          <CardContent className="flex flex-col items-center justify-center p-10">
            <Box className="h-16 w-16 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium">Nenhum malote encontrado</h3>
            <p className="text-gray-500 text-center mt-1">
              Não foram encontrados malotes com os filtros aplicados.
            </p>
            <Button variant="outline" className="mt-4" onClick={() => {
              setSearchTerm("");
              setStatusFilter("all");
              setCarrierFilter("all");
            }}>
              Limpar Filtros
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {filteredMalotes.map((malote) => (
            <Card key={malote.id} className="w-full">
              <CardContent className="p-0">
                <div className="p-4 sm:p-6 flex flex-col sm:flex-row justify-between gap-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                    <div className={`p-3 rounded-lg ${
                      malote.status === 'enviado' ? 'bg-green-100 text-green-700' :
                      malote.status === 'em_preparacao' ? 'bg-blue-100 text-blue-700' :
                      malote.status === 'agendado' ? 'bg-purple-100 text-purple-700' :
                      malote.status === 'cancelado' ? 'bg-red-100 text-red-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      <Package className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{malote.shipment_number}</h3>
                      <div className="flex flex-wrap gap-2 mt-1 text-sm text-gray-500">
                        <span className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          {formatDate(malote.scheduled_date)}
                        </span>
                        <span className="flex items-center">
                          <Truck className="h-4 w-4 mr-1" />
                          {malote.carrier} - {malote.service}
                        </span>
                        <span className="flex items-center">
                          <Package className="h-4 w-4 mr-1" />
                          {malote.total_orders} {malote.total_orders === 1 ? 'pedido' : 'pedidos'}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                    <div className="flex flex-col sm:items-end">
                      {getStatusBadge(malote.status)}
                      <div className="text-sm text-gray-500 mt-1">
                        Criado em {formatDate(malote.created_date)}
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleViewMalote(malote)}
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      Detalhes
                    </Button>
                  </div>
                </div>
                <div className="px-6 py-3 bg-gray-50 border-t flex justify-between items-center">
                  <div className="text-sm text-gray-500">
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {malote.destination}
                    </div>
                  </div>
                  <div className="flex items-center text-sm">
                    <Progress
                      value={(malote.orders_ready / malote.total_orders) * 100}
                      className="w-32 h-2 mr-2"
                    />
                    <span className="text-gray-500">
                      {malote.orders_ready}/{malote.total_orders} prontos
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Dialog para adicionar novo malote */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Criar Novo Malote</DialogTitle>
            <DialogDescription>
              Preencha as informações para criar um novo malote de expedição.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="carrier">Transportadora</Label>
                <Select 
                  value={newMalote.carrier} 
                  onValueChange={(value) => setNewMalote({...newMalote, carrier: value})}
                >
                  <SelectTrigger id="carrier">
                    <SelectValue placeholder="Selecionar" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Correios">Correios</SelectItem>
                    <SelectItem value="Jadlog">Jadlog</SelectItem>
                    <SelectItem value="Transportadora">Transportadora</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="service">Serviço</Label>
                <Select 
                  value={newMalote.service} 
                  onValueChange={(value) => setNewMalote({...newMalote, service: value})}
                >
                  <SelectTrigger id="service">
                    <SelectValue placeholder="Selecionar" />
                  </SelectTrigger>
                  <SelectContent>
                    {newMalote.carrier === "Correios" && (
                      <>
                        <SelectItem value="SEDEX">SEDEX</SelectItem>
                        <SelectItem value="PAC">PAC</SelectItem>
                      </>
                    )}
                    {newMalote.carrier === "Jadlog" && (
                      <>
                        <SelectItem value="Expresso">Expresso</SelectItem>
                        <SelectItem value="Econômico">Econômico</SelectItem>
                      </>
                    )}
                    {newMalote.carrier === "Transportadora" && (
                      <>
                        <SelectItem value="Standard">Standard</SelectItem>
                        <SelectItem value="Expresso">Expresso</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="scheduled_date">Data Programada</Label>
              <Input
                id="scheduled_date"
                type="date"
                value={newMalote.scheduled_date}
                onChange={(e) => setNewMalote({...newMalote, scheduled_date: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="destination">Destino</Label>
              <Input
                id="destination"
                placeholder="Agência ou local de entrega"
                value={newMalote.destination}
                onChange={(e) => setNewMalote({...newMalote, destination: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="responsible">Responsável</Label>
              <Input
                id="responsible"
                placeholder="Nome do responsável"
                value={newMalote.responsible}
                onChange={(e) => setNewMalote({...newMalote, responsible: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                placeholder="Informações adicionais sobre o malote"
                rows={3}
                value={newMalote.notes}
                onChange={(e) => setNewMalote({...newMalote, notes: e.target.value})}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleAddMalote} disabled={!newMalote.carrier || !newMalote.service || !newMalote.scheduled_date || !newMalote.destination}>
              Criar Malote
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog para visualizar detalhes do malote */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Detalhes do Malote {selectedMalote?.shipment_number}
              {getStatusBadge(selectedMalote?.status)}
            </DialogTitle>
          </DialogHeader>
          
          {selectedMalote && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Informações Gerais</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Criado em:</span>
                      <span className="text-sm font-medium">{formatDateTime(selectedMalote.created_date)}</span>
                    </div>
                    {isEditMode ? (
                      <div className="space-y-2">
                        <Label htmlFor="edit-scheduled_date">Data Programada</Label>
                        <Input
                          id="edit-scheduled_date"
                          type="date"
                          value={selectedMalote.scheduled_date}
                          onChange={(e) => setSelectedMalote({...selectedMalote, scheduled_date: e.target.value})}
                        />
                      </div>
                    ) : (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Data Programada:</span>
                        <span className="text-sm font-medium">{formatDate(selectedMalote.scheduled_date)}</span>
                      </div>
                    )}
                    {selectedMalote.shipping_date && (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Data de Envio:</span>
                        <span className="text-sm font-medium">{formatDateTime(selectedMalote.shipping_date)}</span>
                      </div>
                    )}
                    {isEditMode ? (
                      <div className="space-y-2">
                        <Label htmlFor="edit-carrier">Transportadora</Label>
                        <Select 
                          value={selectedMalote.carrier} 
                          onValueChange={(value) => setSelectedMalote({...selectedMalote, carrier: value})}
                        >
                          <SelectTrigger id="edit-carrier">
                            <SelectValue placeholder="Selecionar" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Correios">Correios</SelectItem>
                            <SelectItem value="Jadlog">Jadlog</SelectItem>
                            <SelectItem value="Transportadora">Transportadora</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    ) : (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Transportadora:</span>
                        <span className="text-sm font-medium">{selectedMalote.carrier}</span>
                      </div>
                    )}
                    {isEditMode ? (
                      <div className="space-y-2">
                        <Label htmlFor="edit-service">Serviço</Label>
                        <Select 
                          value={selectedMalote.service} 
                          onValueChange={(value) => setSelectedMalote({...selectedMalote, service: value})}
                        >
                          <SelectTrigger id="edit-service">
                            <SelectValue placeholder="Selecionar" />
                          </SelectTrigger>
                          <SelectContent>
                            {selectedMalote.carrier === "Correios" && (
                              <>
                                <SelectItem value="SEDEX">SEDEX</SelectItem>
                                <SelectItem value="PAC">PAC</SelectItem>
                              </>
                            )}
                            {selectedMalote.carrier === "Jadlog" && (
                              <>
                                <SelectItem value="Expresso">Expresso</SelectItem>
                                <SelectItem value="Econômico">Econômico</SelectItem>
                              </>
                            )}
                            {selectedMalote.carrier === "Transportadora" && (
                              <>
                                <SelectItem value="Standard">Standard</SelectItem>
                                <SelectItem value="Expresso">Expresso</SelectItem>
                              </>
                            )}
                          </SelectContent>
                        </Select>
                      </div>
                    ) : (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Serviço:</span>
                        <span className="text-sm font-medium">{selectedMalote.service}</span>
                      </div>
                    )}
                    {selectedMalote.tracking_code && (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Código de Rastreio:</span>
                        <span className="text-sm font-medium">{selectedMalote.tracking_code}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Detalhes do Envio</h4>
                  <div className="space-y-2">
                    {isEditMode ? (
                      <div className="space-y-2">
                        <Label htmlFor="edit-destination">Destino</Label>
                        <Input
                          id="edit-destination"
                          value={selectedMalote.destination}
                          onChange={(e) => setSelectedMalote({...selectedMalote, destination: e.target.value})}
                        />
                      </div>
                    ) : (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Destino:</span>
                        <span className="text-sm font-medium">{selectedMalote.destination}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Qtd. Pedidos:</span>
                      <span className="text-sm font-medium">{selectedMalote.total_orders}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Pedidos Prontos:</span>
                      <span className="text-sm font-medium">{selectedMalote.orders_ready} / {selectedMalote.total_orders}</span>
                    </div>
                    {selectedMalote.weight > 0 && (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Peso Total:</span>
                        <span className="text-sm font-medium">{selectedMalote.weight} kg</span>
                      </div>
                    )}
                    {selectedMalote.estimated_cost > 0 && (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Custo Estimado:</span>
                        <span className="text-sm font-medium">R$ {selectedMalote.estimated_cost.toFixed(2)}</span>
                      </div>
                    )}
                    {selectedMalote.actual_cost > 0 && (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Custo Real:</span>
                        <span className="text-sm font-medium">R$ {selectedMalote.actual_cost.toFixed(2)}</span>
                      </div>
                    )}
                    {isEditMode ? (
                      <div className="space-y-2">
                        <Label htmlFor="edit-responsible">Responsável</Label>
                        <Input
                          id="edit-responsible"
                          value={selectedMalote.responsible}
                          onChange={(e) => setSelectedMalote({...selectedMalote, responsible: e.target.value})}
                        />
                      </div>
                    ) : (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">Responsável:</span>
                        <span className="text-sm font-medium">{selectedMalote.responsible}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              {isEditMode ? (
                <div className="space-y-2">
                  <Label htmlFor="edit-notes">Observações</Label>
                  <Textarea
                    id="edit-notes"
                    value={selectedMalote.notes}
                    onChange={(e) => setSelectedMalote({...selectedMalote, notes: e.target.value})}
                    rows={3}
                  />
                </div>
              ) : (
                selectedMalote.notes && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-1">Observações</h4>
                    <p className="text-sm p-3 bg-gray-50 rounded-lg">{selectedMalote.notes}</p>
                  </div>
                )
              )}
              
              <div>
                <h4 className="text-sm font-medium text-gray-500 mb-2">Pedidos no Malote</h4>
                <div className="border rounded-md overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nº Pedido</TableHead>
                        <TableHead>Cliente</TableHead>
                        <TableHead>Itens</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedMalote.orders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell className="font-medium">{order.number}</TableCell>
                          <TableCell>{order.customer}</TableCell>
                          <TableCell>{order.items}</TableCell>
                          <TableCell>{getOrderStatusBadge(order.status)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
              
              {selectedMalote.cancel_reason && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Malote Cancelado</AlertTitle>
                  <AlertDescription>{selectedMalote.cancel_reason}</AlertDescription>
                </Alert>
              )}
            </div>
          )}
          
          <DialogFooter className="flex-col sm:flex-row gap-2">
            {isEditMode ? (
              <>
                <Button variant="outline" onClick={() => setIsEditMode(false)}>Cancelar</Button>
                <Button onClick={handleSaveEdit}>Salvar Alterações</Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => setIsDetailDialogOpen(false)}>Fechar</Button>
                {selectedMalote?.status !== "enviado" && selectedMalote?.status !== "cancelado" && (
                  <Button onClick={handleEditMalote}>Editar Malote</Button>
                )}
                {selectedMalote?.status === "em_preparacao" && (
                  <Button className="bg-green-600 hover:bg-green-700">
                    <Check className="h-4 w-4 mr-1" />
                    Finalizar Malote
                  </Button>
                )}
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}