import React, { useState, useEffect } from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { 
  Plus, 
  RefreshCw, 
  MoreHorizontal, 
  FileText, 
  Edit, 
  Trash,
  ClipboardList,
  Search
} from "lucide-react";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";

export default function ProducaoOrdens() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [ordensProducao, setOrdensProducao] = useState([]);
  
  useEffect(() => {
    // Simular carregamento de dados
    const timer = setTimeout(() => {
      const mockOrdens = [
        {
          id: "OP-2023-001",
          produto: "Óleo CBD 10% Full Spectrum",
          lote: "L202301",
          quantidade: 100,
          unidade: "frascos",
          data_inicio: "2023-08-15",
          data_prevista: "2023-08-20",
          responsavel: "Maria Silva",
          status: "em_andamento",
          progresso: 65
        },
        {
          id: "OP-2023-002",
          produto: "Cápsulas CBD 25mg",
          lote: "L202302",
          quantidade: 1000,
          unidade: "cápsulas",
          data_inicio: "2023-08-10",
          data_prevista: "2023-08-18",
          responsavel: "João Pereira",
          status: "concluido",
          progresso: 100
        },
        {
          id: "OP-2023-003",
          produto: "Pomada CBD 2%",
          lote: "L202303",
          quantidade: 200,
          unidade: "potes",
          data_inicio: "2023-08-20",
          data_prevista: "2023-08-25",
          responsavel: "Ana Costa",
          status: "planejado",
          progresso: 0
        },
        {
          id: "OP-2023-004",
          produto: "Tintura CBD 5%",
          lote: "L202304",
          quantidade: 150,
          unidade: "frascos",
          data_inicio: "2023-08-05",
          data_prevista: "2023-08-12",
          responsavel: "Carlos Mendes",
          status: "parado",
          progresso: 30
        },
        {
          id: "OP-2023-005",
          produto: "Spray Nasal CBD",
          lote: "L202305",
          quantidade: 80,
          unidade: "frascos",
          data_inicio: "2023-08-18",
          data_prevista: "2023-08-22",
          responsavel: "Laura Dias",
          status: "em_andamento",
          progresso: 45
        }
      ];
      
      setOrdensProducao(mockOrdens);
      setLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);
  
  const getStatusBadge = (status) => {
    switch (status) {
      case 'planejado':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Planejado</Badge>;
      case 'em_andamento':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Em Andamento</Badge>;
      case 'parado':
        return <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">Parado</Badge>;
      case 'concluido':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Concluído</Badge>;
      case 'cancelado':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Cancelado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  const handleNovaOrdem = () => {
    navigate(createPageUrl("ProducaoNovaOrdem"));
  };
  
  const handleEdit = (id) => {
    // For now, just show an alert
    alert("Funcionalidade de edição em desenvolvimento. ID: " + id);
  };
  
  const handleShowDetails = (id) => {
    // For now, just show an alert
    alert("Funcionalidade de visualização em desenvolvimento. ID: " + id);
  };
  
  const handleDeleteOrder = (id) => {
    if (window.confirm("Tem certeza que deseja excluir esta ordem de produção? Esta ação não poderá ser desfeita.")) {
      setOrdensProducao(ordensProducao.filter(ordem => ordem.id !== id));
      alert(`Ordem ${id} excluída com sucesso`);
    }
  };

  const handleStatusChange = (id, newStatus) => {
    const updatedOrdens = ordensProducao.map(ordem => {
      if (ordem.id === id) {
        return { ...ordem, status: newStatus };
      }
      return ordem;
    });
    
    setOrdensProducao(updatedOrdens);
    alert(`Status da ordem ${id} alterado para ${newStatus}`);
  };

  const filteredOrdens = ordensProducao.filter(ordem => {
    // Filter by status
    const statusMatch = filterStatus === 'all' || ordem.status === filterStatus;
    
    // Filter by search term
    const searchMatch = searchTerm === '' || 
      ordem.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ordem.produto.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ordem.lote.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ordem.responsavel.toLowerCase().includes(searchTerm.toLowerCase());
    
    return statusMatch && searchMatch;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Ordens de Produção</h1>
          <p className="text-gray-500 mt-1">
            Planejamento e controle da produção de lotes
          </p>
        </div>
        <Button onClick={handleNovaOrdem}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Ordem
        </Button>
      </div>
      
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="all">Todas</TabsTrigger>
            <TabsTrigger value="planned">Planejadas</TabsTrigger>
            <TabsTrigger value="in_progress">Em Andamento</TabsTrigger>
            <TabsTrigger value="completed">Concluídas</TabsTrigger>
          </TabsList>
          
          <div className="flex gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                type="search"
                placeholder="Buscar ordem..."
                className="pl-8 w-64"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="planejado">Planejado</SelectItem>
                <SelectItem value="em_andamento">Em Andamento</SelectItem>
                <SelectItem value="parado">Parado</SelectItem>
                <SelectItem value="concluido">Concluído</SelectItem>
                <SelectItem value="cancelado">Cancelado</SelectItem>
              </SelectContent>
            </Select>
            
            <Button variant="outline" size="icon" onClick={() => {
              setSearchTerm("");
              setFilterStatus("all");
            }}>
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <TabsContent value="all" className="mt-0">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500"></div>
              <span className="mt-2 text-sm text-gray-500">Carregando ordens de produção...</span>
            </div>
          ) : filteredOrdens.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64">
              <ClipboardList className="h-12 w-12 text-gray-300" />
              <h3 className="mt-2 text-gray-700 font-medium">Nenhuma ordem encontrada</h3>
              <p className="text-sm text-gray-500">
                {searchTerm || filterStatus !== 'all' 
                  ? "Tente ajustar os filtros para ver mais resultados" 
                  : "Crie uma nova ordem de produção para começar"}
              </p>
              <Button variant="outline" className="mt-4" onClick={handleNovaOrdem}>
                <Plus className="mr-2 h-4 w-4" />
                Nova Ordem
              </Button>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Produto</TableHead>
                    <TableHead>Lote</TableHead>
                    <TableHead>Quantidade</TableHead>
                    <TableHead>Data Prevista</TableHead>
                    <TableHead>Responsável</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Progresso</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrdens.map((ordem) => (
                    <TableRow key={ordem.id} className="cursor-pointer hover:bg-gray-50" onClick={() => handleShowDetails(ordem.id)}>
                      <TableCell className="font-medium">{ordem.id}</TableCell>
                      <TableCell>{ordem.produto}</TableCell>
                      <TableCell>{ordem.lote}</TableCell>
                      <TableCell>{ordem.quantidade} {ordem.unidade}</TableCell>
                      <TableCell>{new Date(ordem.data_prevista).toLocaleDateString('pt-BR')}</TableCell>
                      <TableCell>{ordem.responsavel}</TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        {getStatusBadge(ordem.status)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${
                                ordem.status === 'concluido' ? 'bg-green-500' : 
                                ordem.status === 'cancelado' ? 'bg-red-500' : 
                                'bg-blue-500'
                              }`}
                              style={{ width: `${ordem.progresso}%` }}
                            ></div>
                          </div>
                          <span className="text-xs">{ordem.progresso}%</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <span className="sr-only">Abrir menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleShowDetails(ordem.id)}>
                              <FileText className="mr-2 h-4 w-4" />
                              Ver detalhes
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEdit(ordem.id)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              onClick={() => handleDeleteOrder(ordem.id)}
                              className="text-red-600 focus:text-red-600"
                            >
                              <Trash className="mr-2 h-4 w-4" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="planned" className="mt-0">
          {/* Similar content as "all" tab but filtered for planned orders */}
          <div className="text-center py-8">
            <p>Conteúdo filtrado para ordens planejadas</p>
          </div>
        </TabsContent>
        
        <TabsContent value="in_progress" className="mt-0">
          {/* Similar content as "all" tab but filtered for in-progress orders */}
          <div className="text-center py-8">
            <p>Conteúdo filtrado para ordens em andamento</p>
          </div>
        </TabsContent>
        
        <TabsContent value="completed" className="mt-0">
          {/* Similar content as "all" tab but filtered for completed orders */}
          <div className="text-center py-8">
            <p>Conteúdo filtrado para ordens concluídas</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}