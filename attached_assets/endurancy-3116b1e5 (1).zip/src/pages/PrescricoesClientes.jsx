import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  FileCheck, 
  Search, 
  Plus, 
  Filter, 
  Clock, 
  Download, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  Calendar, 
  User, 
  FileText, 
  MoreHorizontal,
  ChevronDown,
  CalendarDays,
  StethoscopeIcon,
  Pill,
  Heart,
  Building,
  ArrowUpDown,
  Eye,
  FileEdit,
  Archive,
  Send,
  Printer
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";

// Dados simulados para prescrições
const mockPrescriptions = [
  {
    id: "presc001",
    numero: "P-2023-0156",
    paciente: {
      id: "pac001",
      nome: "Maria Silva Oliveira",
      cpf: "123.456.789-00"
    },
    medico: {
      nome: "Dr. João Carlos Santos",
      crm: "12345-SP",
      especialidade: "Neurologia"
    },
    data_emissao: "2023-06-01",
    data_validade: "2024-06-01",
    status: "aprovada",
    produtos: [
      {
        id: "prod001",
        nome: "Óleo CBD 5% 30ml",
        dosagem: "5 gotas, 2x ao dia",
        quantidade: 2,
        duracao: "60 dias"
      }
    ],
    diagnostico: "Epilepsia Refratária",
    observacoes: "Iniciar com dosagem reduzida por 7 dias.",
    file_url: "#",
    revisado_por: "Ana Oliveira",
    data_revisao: "2023-06-02",
  },
  {
    id: "presc002",
    numero: "P-2023-0157",
    paciente: {
      id: "pac002",
      nome: "José Pereira Souza",
      cpf: "987.654.321-00"
    },
    medico: {
      nome: "Dra. Ana Paula Mendes",
      crm: "54321-SP",
      especialidade: "Medicina da Dor"
    },
    data_emissao: "2023-05-12",
    data_validade: "2023-11-12",
    status: "aprovada",
    produtos: [
      {
        id: "prod003",
        nome: "Tinturas CBD 3% 50ml",
        dosagem: "1ml, 2x ao dia",
        quantidade: 3,
        duracao: "90 dias"
      },
      {
        id: "prod006",
        nome: "Creme CBD tópico 50g",
        dosagem: "Aplicar nas áreas afetadas, 3x ao dia",
        quantidade: 2,
        duracao: "60 dias"
      }
    ],
    diagnostico: "Dor Crônica, Fibromialgia",
    observacoes: "Acompanhar efeitos colaterais.",
    file_url: "#",
    revisado_por: "Carlos Mendes",
    data_revisao: "2023-05-13",
  },
  {
    id: "presc003",
    numero: "P-2023-0158",
    paciente: {
      id: "pac003",
      nome: "Antônio Carlos Ferreira",
      cpf: "456.789.123-00"
    },
    medico: {
      nome: "Dr. Roberto Almeida",
      crm: "23456-SP",
      especialidade: "Geriatria"
    },
    data_emissao: "2023-06-01",
    data_validade: "2023-12-01",
    status: "aprovada",
    produtos: [
      {
        id: "prod004",
        nome: "Óleo CBD 10% 10ml",
        dosagem: "3 gotas, 3x ao dia",
        quantidade: 6,
        duracao: "180 dias"
      }
    ],
    diagnostico: "Parkinson, Artrite",
    observacoes: "Paciente reporta melhora significativa nos tremores.",
    file_url: "#",
    revisado_por: "Ana Oliveira",
    data_revisao: "2023-06-02",
  },
  {
    id: "presc004",
    numero: "P-2023-0159",
    paciente: {
      id: "pac005",
      nome: "Carlos Eduardo Santos",
      cpf: "321.654.987-00"
    },
    medico: {
      nome: "Dr. Paulo Menezes",
      crm: "34567-SP",
      especialidade: "Neurologia"
    },
    data_emissao: "2023-05-25",
    data_validade: "2023-11-25",
    status: "pendente",
    produtos: [
      {
        id: "prod005",
        nome: "Cápsulas CBD 20mg",
        dosagem: "1 cápsula, 2x ao dia",
        quantidade: 3,
        duracao: "90 dias"
      }
    ],
    diagnostico: "Esclerose Múltipla",
    observacoes: "Primeira prescrição para este paciente. Monitorar efeitos.",
    file_url: "#",
    revisado_por: "",
    data_revisao: "",
  },
  {
    id: "presc005",
    numero: "P-2023-0155",
    paciente: {
      id: "pac007",
      nome: "Roberto Gomes Costa",
      cpf: "234.567.891-00"
    },
    medico: {
      nome: "Dra. Cristina Martins",
      crm: "45678-SP",
      especialidade: "Psiquiatria"
    },
    data_emissao: "2023-05-20",
    data_validade: "2023-11-20",
    status: "rejeitada",
    produtos: [
      {
        id: "prod002",
        nome: "Óleo CBD 20% 30ml",
        dosagem: "5 gotas, 1x ao dia",
        quantidade: 1,
        duracao: "60 dias"
      }
    ],
    diagnostico: "Transtorno de Ansiedade Generalizada",
    observacoes: "Paciente já em uso de múltiplos medicamentos.",
    file_url: "#",
    revisado_por: "Carlos Mendes",
    data_revisao: "2023-05-22",
    motivo_rejeicao: "Dosagem acima do recomendado para o diagnóstico apresentado."
  },
  {
    id: "presc006",
    numero: "P-2023-0160",
    paciente: {
      id: "pac008",
      nome: "Amanda Lima Santos",
      cpf: "789.123.456-00"
    },
    medico: {
      nome: "Dr. Felipe Barros",
      crm: "56789-SP",
      especialidade: "Oncologia"
    },
    data_emissao: "2023-06-05",
    data_validade: "2023-09-05",
    status: "expirada",
    produtos: [
      {
        id: "prod001",
        nome: "Óleo CBD 5% 30ml",
        dosagem: "10 gotas, 3x ao dia",
        quantidade: 3,
        duracao: "90 dias"
      }
    ],
    diagnostico: "Efeitos colaterais de quimioterapia - Náusea e Insônia",
    observacoes: "Usar em conjunto com a medicação convencional.",
    file_url: "#",
    revisado_por: "Ana Oliveira",
    data_revisao: "2023-06-06",
  }
];

export default function PrescricoesClientes() {
  const navigate = useNavigate();
  const [prescriptions, setPrescriptions] = useState([]);
  const [filteredPrescriptions, setFilteredPrescriptions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedPrescription, setSelectedPrescription] = useState(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [activeTab, setActiveTab] = useState("todas");

  useEffect(() => {
    // Simula carregamento de dados
    setTimeout(() => {
      setPrescriptions(mockPrescriptions);
      setFilteredPrescriptions(mockPrescriptions);
      setIsLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    applyFilters();
  }, [searchTerm, statusFilter, activeTab, prescriptions]);

  const applyFilters = () => {
    let filtered = [...prescriptions];
    
    // Filtro por status
    if (statusFilter !== "all") {
      filtered = filtered.filter(prescription => prescription.status === statusFilter);
    }
    
    // Filtro por tab
    if (activeTab === "pendentes") {
      filtered = filtered.filter(prescription => prescription.status === "pendente");
    } else if (activeTab === "aprovadas") {
      filtered = filtered.filter(prescription => prescription.status === "aprovada");
    } else if (activeTab === "rejeitadas") {
      filtered = filtered.filter(prescription => prescription.status === "rejeitada");
    } else if (activeTab === "expiradas") {
      filtered = filtered.filter(prescription => prescription.status === "expirada");
    }
    
    // Filtro por termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(prescription => 
        prescription.numero.toLowerCase().includes(term) ||
        prescription.paciente.nome.toLowerCase().includes(term) ||
        prescription.paciente.cpf.includes(term) ||
        prescription.medico.nome.toLowerCase().includes(term) ||
        prescription.medico.crm.toLowerCase().includes(term)
      );
    }
    
    setFilteredPrescriptions(filtered);
  };

  const handleViewPrescription = (prescription) => {
    setSelectedPrescription(prescription);
    setShowDetailDialog(true);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  const getStatusBadge = (status) => {
    switch(status) {
      case "aprovada":
        return <Badge className="bg-green-100 text-green-800">Aprovada</Badge>;
      case "pendente":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case "rejeitada":
        return <Badge className="bg-red-100 text-red-800">Rejeitada</Badge>;
      case "expirada":
        return <Badge className="bg-gray-100 text-gray-800">Expirada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Prescrições</h1>
          <p className="text-gray-500 mt-1">
            Gerenciamento de prescrições médicas
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            className="gap-2"
            onClick={() => navigate(createPageUrl("PrescricoesClientes"))}
          >
            <Download className="w-4 h-4" />
            Exportar
          </Button>
          <Button
            className="gap-2"
            onClick={() => navigate(createPageUrl("NovaPrescricao"))}
          >
            <Plus className="w-4 h-4" />
            Nova Prescrição
          </Button>
        </div>
      </div>

      <Tabs defaultValue="todas" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="todas">Todas</TabsTrigger>
          <TabsTrigger value="pendentes">Pendentes</TabsTrigger>
          <TabsTrigger value="aprovadas">Aprovadas</TabsTrigger>
          <TabsTrigger value="rejeitadas">Rejeitadas</TabsTrigger>
          <TabsTrigger value="expiradas">Expiradas</TabsTrigger>
        </TabsList>

        <div className="flex flex-col md:flex-row md:items-center gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar por número, paciente, médico..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Filtrar por status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="aprovada">Aprovadas</SelectItem>
              <SelectItem value="pendente">Pendentes</SelectItem>
              <SelectItem value="rejeitada">Rejeitadas</SelectItem>
              <SelectItem value="expirada">Expiradas</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <TabsContent value="todas" className="m-0">
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex justify-center items-center p-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
                  <span className="ml-3">Carregando prescrições...</span>
                </div>
              ) : filteredPrescriptions.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[180px]">
                        <div className="flex items-center gap-1">
                          Número
                          <ArrowUpDown className="w-4 h-4" />
                        </div>
                      </TableHead>
                      <TableHead>Paciente</TableHead>
                      <TableHead>Médico</TableHead>
                      <TableHead>
                        <div className="flex items-center gap-1">
                          Data Emissão
                          <ArrowUpDown className="w-4 h-4" />
                        </div>
                      </TableHead>
                      <TableHead>
                        <div className="flex items-center gap-1">
                          Validade
                          <ArrowUpDown className="w-4 h-4" />
                        </div>
                      </TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPrescriptions.map((prescription) => (
                      <TableRow key={prescription.id}>
                        <TableCell className="font-medium">{prescription.numero}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="bg-primary/10 text-primary">
                                {prescription.paciente.nome.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{prescription.paciente.nome}</p>
                              <p className="text-sm text-gray-500">{prescription.paciente.cpf}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <p>{prescription.medico.nome}</p>
                            <p className="text-sm text-gray-500">{prescription.medico.crm} • {prescription.medico.especialidade}</p>
                          </div>
                        </TableCell>
                        <TableCell>{formatDate(prescription.data_emissao)}</TableCell>
                        <TableCell>{formatDate(prescription.data_validade)}</TableCell>
                        <TableCell>{getStatusBadge(prescription.status)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-5 w-5" />
                                <span className="sr-only">Abrir menu</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleViewPrescription(prescription)}>
                                <Eye className="w-4 h-4 mr-2" />
                                Visualizar
                              </DropdownMenuItem>
                              {prescription.status === 'pendente' && (
                                <>
                                  <DropdownMenuItem>
                                    <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                                    Aprovar
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <XCircle className="w-4 h-4 mr-2 text-red-600" />
                                    Rejeitar
                                  </DropdownMenuItem>
                                </>
                              )}
                              <DropdownMenuItem>
                                <FileEdit className="w-4 h-4 mr-2" />
                                Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Printer className="w-4 h-4 mr-2" />
                                Imprimir
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Archive className="w-4 h-4 mr-2" />
                                Arquivar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center p-8">
                  <FileText className="w-12 h-12 text-gray-300 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">Nenhuma prescrição encontrada</h3>
                  <p className="text-gray-500 mt-1">
                    {searchTerm 
                      ? `Não encontramos prescrições correspondentes a "${searchTerm}"`
                      : "Nenhuma prescrição foi encontrada com os filtros atuais."}
                  </p>
                  {searchTerm && (
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => setSearchTerm("")}
                    >
                      Limpar busca
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pendentes" className="m-0">
          {/* Conteúdo para prescrições pendentes - usa o mesmo layout */}
        </TabsContent>

        <TabsContent value="aprovadas" className="m-0">
          {/* Conteúdo para prescrições aprovadas - usa o mesmo layout */}
        </TabsContent>

        <TabsContent value="rejeitadas" className="m-0">
          {/* Conteúdo para prescrições rejeitadas - usa o mesmo layout */}
        </TabsContent>

        <TabsContent value="expiradas" className="m-0">
          {/* Conteúdo para prescrições expiradas - usa o mesmo layout */}
        </TabsContent>
      </Tabs>

      {/* Dialog para detalhes da prescrição */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Detalhes da Prescrição</DialogTitle>
            <DialogDescription>
              Informações completas da prescrição médica
            </DialogDescription>
          </DialogHeader>

          {selectedPrescription && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Informações Gerais</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm text-gray-500">Número da Prescrição</p>
                      <p className="font-medium">{selectedPrescription.numero}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Status</p>
                      <div className="mt-1">{getStatusBadge(selectedPrescription.status)}</div>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Data de Emissão</p>
                      <p className="font-medium">{formatDate(selectedPrescription.data_emissao)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Data de Validade</p>
                      <p className="font-medium">{formatDate(selectedPrescription.data_validade)}</p>
                    </div>
                    {selectedPrescription.status === "rejeitada" && (
                      <div>
                        <p className="text-sm text-gray-500">Motivo da Rejeição</p>
                        <p className="text-red-600">{selectedPrescription.motivo_rejeicao}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Paciente e Médico</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm text-gray-500">Paciente</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-primary/10 text-primary">
                            {selectedPrescription.paciente.nome.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{selectedPrescription.paciente.nome}</p>
                          <p className="text-sm text-gray-500">{selectedPrescription.paciente.cpf}</p>
                        </div>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Médico</p>
                      <p className="font-medium">{selectedPrescription.medico.nome}</p>
                      <p className="text-sm text-gray-500">{selectedPrescription.medico.crm} • {selectedPrescription.medico.especialidade}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Diagnóstico</p>
                      <p className="font-medium">{selectedPrescription.diagnostico}</p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Produtos Prescritos</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Produto</TableHead>
                        <TableHead>Dosagem</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Duração</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedPrescription.produtos.map((produto, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{produto.nome}</TableCell>
                          <TableCell>{produto.dosagem}</TableCell>
                          <TableCell>{produto.quantidade} unidades</TableCell>
                          <TableCell>{produto.duracao}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Observações e Revisão</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-500">Observações Médicas</p>
                    <p>{selectedPrescription.observacoes || "Nenhuma observação registrada."}</p>
                  </div>
                  
                  {selectedPrescription.status !== "pendente" && (
                    <div>
                      <p className="text-sm text-gray-500">Revisado por</p>
                      <p>{selectedPrescription.revisado_por} • {formatDate(selectedPrescription.data_revisao)}</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <DialogFooter className="flex justify-between items-center gap-2">
                <div>
                  <Button variant="outline" className="gap-2" onClick={() => window.print()}>
                    <Printer className="w-4 h-4" />
                    Imprimir
                  </Button>
                </div>
                <div className="flex gap-2">
                  {selectedPrescription.status === "pendente" && (
                    <>
                      <Button variant="destructive" className="gap-2">
                        <XCircle className="w-4 h-4" />
                        Rejeitar
                      </Button>
                      <Button className="gap-2 bg-green-600 hover:bg-green-700">
                        <CheckCircle className="w-4 h-4" />
                        Aprovar
                      </Button>
                    </>
                  )}
                  <Button variant="secondary" onClick={() => setShowDetailDialog(false)}>
                    Fechar
                  </Button>
                </div>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}