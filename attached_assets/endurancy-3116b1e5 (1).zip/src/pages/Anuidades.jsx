
import React, { useState, useEffect } from 'react';
import { 
  CreditCard, 
  Search, 
  Filter, 
  PlusCircle, 
  FileText, 
  Calendar,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Download,
  Clock,
  DollarSign,
  Users,
  BarChart4,
  BadgePercent,
  FileCheck,
  Mail,
  Send,
  Settings,
  MoreHorizontal,
  Eye,
  Plus
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";

// Dados mockados para anuidades
const anuidadesConfigMock = [
  {
    id: "an2023",
    ano: "2023",
    valor_padrao: 240.00,
    data_vencimento: "2023-01-31",
    status: "ativa",
    pagamentos_totais: 45,
    pagamentos_realizados: 38,
    valor_total: 10800.00,
    valor_recebido: 9120.00
  },
  {
    id: "an2022",
    ano: "2022",
    valor_padrao: 220.00,
    data_vencimento: "2022-01-31",
    status: "encerrada",
    pagamentos_totais: 42,
    pagamentos_realizados: 40,
    valor_total: 9240.00,
    valor_recebido: 8800.00
  },
  {
    id: "an2024",
    ano: "2024",
    valor_padrao: 260.00,
    data_vencimento: "2024-01-31",
    status: "em_lancamento",
    pagamentos_totais: 50,
    pagamentos_realizados: 0,
    valor_total: 13000.00,
    valor_recebido: 0.00
  }
];

// Dados mockados para pagamentos de anuidades
const pagamentosAnuidadesMock = [
  {
    id: "pag001",
    associado_nome: "Maria Silva",
    associado_id: "a001",
    anuidade_id: "an2023",
    ano_referencia: "2023",
    valor_original: 240.00,
    valor_pago: 240.00,
    data_vencimento: "2023-01-31",
    data_pagamento: "2023-01-15",
    status: "pago",
    metodo_pagamento: "pix"
  },
  {
    id: "pag002",
    associado_nome: "João Pereira",
    associado_id: "a002",
    anuidade_id: "an2023",
    ano_referencia: "2023",
    valor_original: 240.00,
    valor_pago: 240.00,
    data_vencimento: "2023-01-31",
    data_pagamento: "2023-01-20",
    status: "pago",
    metodo_pagamento: "transferencia"
  },
  {
    id: "pag003",
    associado_nome: "Ana Costa",
    associado_id: "a003",
    anuidade_id: "an2023",
    ano_referencia: "2023",
    valor_original: 240.00,
    valor_pago: null,
    data_vencimento: "2023-01-31",
    data_pagamento: null,
    status: "atrasado",
    metodo_pagamento: null
  },
  {
    id: "pag004",
    associado_nome: "Carlos Santos",
    associado_id: "a004",
    anuidade_id: "an2023",
    ano_referencia: "2023",
    valor_original: 240.00,
    valor_pago: null,
    data_vencimento: "2023-01-31",
    data_pagamento: null,
    status: "pendente",
    metodo_pagamento: null
  },
  {
    id: "pag005",
    associado_nome: "Fernanda Lima",
    associado_id: "a005",
    anuidade_id: "an2023",
    ano_referencia: "2023",
    valor_original: 240.00,
    valor_pago: 240.00,
    data_vencimento: "2023-01-31",
    data_pagamento: "2023-01-10",
    status: "pago",
    metodo_pagamento: "boleto"
  }
];

export default function Anuidades() {
  const [searchTerm, setSearchTerm] = useState("");
  const [anuidadeSelecionada, setAnuidadeSelecionada] = useState("an2023");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [anuidadesConfig, setAnuidadesConfig] = useState([]);
  const [pagamentos, setPagamentos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("geral");
  
  useEffect(() => {
    // Simulando carregamento de dados
    setTimeout(() => {
      setAnuidadesConfig(anuidadesConfigMock);
      setPagamentos(pagamentosAnuidadesMock);
      setIsLoading(false);
    }, 1000);
  }, []);
  
  const anuidadeAtual = anuidadesConfig.find(a => a.id === anuidadeSelecionada) || {};
  
  // Filtrar pagamentos pela anuidade selecionada e status
  const filteredPagamentos = pagamentos.filter(pag => {
    const matchesAnuidade = pag.anuidade_id === anuidadeSelecionada;
    const matchesStatus = statusFilter === "todos" || pag.status === statusFilter;
    const matchesSearch = searchTerm === "" || 
      pag.associado_nome.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesAnuidade && matchesStatus && matchesSearch;
  });
  
  const getStatusBadge = (status) => {
    switch (status) {
      case "pago":
        return <Badge className="bg-green-100 text-green-800">Pago</Badge>;
      case "pendente":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case "atrasado":
        return <Badge className="bg-red-100 text-red-800">Atrasado</Badge>;
      case "isento":
        return <Badge className="bg-blue-100 text-blue-800">Isento</Badge>;
      case "ativa":
        return <Badge className="bg-green-100 text-green-800">Ativa</Badge>;
      case "encerrada":
        return <Badge className="bg-gray-100 text-gray-800">Encerrada</Badge>;
      case "em_lancamento":
        return <Badge className="bg-blue-100 text-blue-800">Em Lançamento</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Gestão de Anuidades</h1>
          <p className="text-gray-500 mt-1">Configure e gerencie os pagamentos de anuidades dos associados</p>
        </div>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <PlusCircle className="w-4 h-4" />
              Nova Anuidade
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Configurar Nova Anuidade</DialogTitle>
              <DialogDescription>
                Defina os parâmetros para a nova anuidade que será cobrada dos associados.
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <label className="text-right">Ano</label>
                <Input 
                  className="col-span-3" 
                  placeholder="2024" 
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <label className="text-right">Valor (R$)</label>
                <Input 
                  type="number" 
                  className="col-span-3" 
                  placeholder="250.00" 
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <label className="text-right">Vencimento</label>
                <Input 
                  type="date" 
                  className="col-span-3" 
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <label className="text-right">Desconto Antecipado (%)</label>
                <Input 
                  type="number" 
                  className="col-span-3" 
                  placeholder="10" 
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <label className="text-right">Multa por Atraso (%)</label>
                <Input 
                  type="number" 
                  className="col-span-3" 
                  placeholder="2" 
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button type="submit">Criar Anuidade</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="geral">Visão Geral</TabsTrigger>
          <TabsTrigger value="pagamentos">Pagamentos</TabsTrigger>
          <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
        </TabsList>
        
        <TabsContent value="geral">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Total de Associados</CardDescription>
                <CardTitle className="text-3xl font-bold">50</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-green-600 mt-2">
                  <Users className="w-4 h-4 mr-1" />
                  38 associados em dia
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Taxa de Adimplência</CardDescription>
                <CardTitle className="text-3xl font-bold">76%</CardTitle>
              </CardHeader>
              <CardContent>
                <Progress value={76} className="h-2 mt-2" />
                <div className="flex items-center text-sm text-blue-600 mt-2">
                  <BarChart4 className="w-4 h-4 mr-1" />
                  Aumento de 5% em relação a 2022
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Valor Total Arrecadado</CardDescription>
                <CardTitle className="text-3xl font-bold">R$ 9.120,00</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-green-600 mt-2">
                  <DollarSign className="w-4 h-4 mr-1" />
                  84% do valor total esperado
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Anuidades</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ano</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Vencimento</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Progresso</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {anuidadesConfig.map((anuidade) => (
                      <TableRow 
                        key={anuidade.id} 
                        className={anuidade.id === anuidadeSelecionada ? "bg-gray-50" : ""}
                        onClick={() => setAnuidadeSelecionada(anuidade.id)}
                        style={{ cursor: 'pointer' }}
                      >
                        <TableCell className="font-medium">{anuidade.ano}</TableCell>
                        <TableCell>R$ {anuidade.valor_padrao.toFixed(2)}</TableCell>
                        <TableCell>{new Date(anuidade.data_vencimento).toLocaleDateString()}</TableCell>
                        <TableCell>{getStatusBadge(anuidade.status)}</TableCell>
                        <TableCell>
                          {anuidade.status !== 'em_lancamento' && (
                            <div className="flex flex-col gap-1">
                              <Progress 
                                value={(anuidade.pagamentos_realizados / anuidade.pagamentos_totais) * 100} 
                                className="h-2" 
                              />
                              <span className="text-xs text-gray-500">
                                {anuidade.pagamentos_realizados} de {anuidade.pagamentos_totais} ({Math.round((anuidade.pagamentos_realizados / anuidade.pagamentos_totais) * 100)}%)
                              </span>
                            </div>
                          )}
                          {anuidade.status === 'em_lancamento' && (
                            <span className="text-xs text-gray-500">Não iniciado</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Detalhes da Anuidade {anuidadeAtual.ano || ""}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.keys(anuidadeAtual).length > 0 ? (
                  <>
                    <div className="flex justify-between items-center">
                      <h3 className="text-sm font-medium">Status:</h3>
                      {getStatusBadge(anuidadeAtual.status)}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Valor Padrão:</h3>
                        <p className="text-lg font-medium">R$ {anuidadeAtual.valor_padrao?.toFixed(2)}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Data de Vencimento:</h3>
                        <p className="text-lg font-medium">{new Date(anuidadeAtual.data_vencimento).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Total de Associados:</h3>
                        <p className="text-lg font-medium">{anuidadeAtual.pagamentos_totais}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Pagamentos Realizados:</h3>
                        <p className="text-lg font-medium">{anuidadeAtual.pagamentos_realizados}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Valor Total Esperado:</h3>
                        <p className="text-lg font-medium">R$ {anuidadeAtual.valor_total?.toFixed(2)}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Valor Total Recebido:</h3>
                        <p className="text-lg font-medium">R$ {anuidadeAtual.valor_recebido?.toFixed(2)}</p>
                      </div>
                    </div>
                    
                    <div className="flex gap-3 pt-4">
                      <Button 
                        className="gap-2" 
                        disabled={anuidadeAtual.status === 'encerrada'}
                      >
                        <Send className="w-4 h-4" />
                        Enviar Lembretes
                      </Button>
                      <Button 
                        variant="outline" 
                        className="gap-2"
                        disabled={anuidadeAtual.status === 'encerrada'}
                      >
                        <FileText className="w-4 h-4" />
                        Gerar Relatório
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <AlertTriangle className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                    <p>Selecione uma anuidade para ver os detalhes.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="pagamentos">
          <div className="space-y-6">
            {/* Seletor de Anuidade e Filtros */}
            <div className="flex flex-col md:flex-row gap-4">
              <Select
                value={anuidadeSelecionada}
                onValueChange={setAnuidadeSelecionada}
              >
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Anuidade" />
                </SelectTrigger>
                <SelectContent>
                  {anuidadesConfig.map((anuidade) => (
                    <SelectItem key={anuidade.id} value={anuidade.id}>
                      {anuidade.ano}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Buscar por nome do associado..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Select
                value={statusFilter}
                onValueChange={setStatusFilter}
              >
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  <SelectItem value="pago">Pagos</SelectItem>
                  <SelectItem value="pendente">Pendentes</SelectItem>
                  <SelectItem value="atrasado">Atrasados</SelectItem>
                  <SelectItem value="isento">Isentos</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                className="gap-2"
              >
                <Filter className="w-4 h-4" />
                Mais Filtros
              </Button>
            </div>
            
            {/* Tabela de Pagamentos */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Associado</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Vencimento</TableHead>
                  <TableHead>Data de Pagamento</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Método</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPagamentos.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                      Nenhum pagamento encontrado com os filtros selecionados.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredPagamentos.map((pagamento) => (
                    <TableRow key={pagamento.id}>
                      <TableCell className="font-medium">{pagamento.associado_nome}</TableCell>
                      <TableCell>R$ {pagamento.valor_original?.toFixed(2)}</TableCell>
                      <TableCell>{new Date(pagamento.data_vencimento).toLocaleDateString()}</TableCell>
                      <TableCell>{pagamento.data_pagamento ? new Date(pagamento.data_pagamento).toLocaleDateString() : '-'}</TableCell>
                      <TableCell>{getStatusBadge(pagamento.status)}</TableCell>
                      <TableCell>{pagamento.metodo_pagamento || '-'}</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Ações</DropdownMenuLabel>
                            {pagamento.status === 'pendente' || pagamento.status === 'atrasado' ? (
                              <DropdownMenuItem>
                                <CheckCircle2 className="mr-2 h-4 w-4 text-green-600" />
                                Registrar Pagamento
                              </DropdownMenuItem>
                            ) : null}
                            {pagamento.status === 'pendente' || pagamento.status === 'atrasado' ? (
                              <DropdownMenuItem>
                                <Mail className="mr-2 h-4 w-4" />
                                Enviar Lembrete
                              </DropdownMenuItem>
                            ) : null}
                            {pagamento.status === 'pendente' || pagamento.status === 'atrasado' ? (
                              <DropdownMenuItem>
                                <BadgePercent className="mr-2 h-4 w-4 text-blue-600" />
                                Conceder Isenção
                              </DropdownMenuItem>
                            ) : null}
                            {pagamento.status === 'pago' ? (
                              <DropdownMenuItem>
                                <Eye className="mr-2 h-4 w-4" />
                                Ver Comprovante
                              </DropdownMenuItem>
                            ) : null}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <FileText className="mr-2 h-4 w-4" />
                              Detalhes
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
            
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Mostrando {filteredPagamentos.length} de {pagamentos.filter(p => p.anuidade_id === anuidadeSelecionada).length} pagamentos
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled>Anterior</Button>
                <Button variant="outline" size="sm" disabled>Próximo</Button>
              </div>
            </div>
            
            <div className="flex justify-end gap-3">
              <Button variant="outline" className="gap-2">
                <Download className="w-4 h-4" />
                Exportar Lista
              </Button>
              <Button className="gap-2">
                <Send className="w-4 h-4" />
                Enviar Lembretes em Massa
              </Button>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="configuracoes">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Anuidades</CardTitle>
              <CardDescription>
                Defina as configurações globais para cobrança de anuidades
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Mês de Vencimento Padrão</label>
                  <Select defaultValue="01">
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o mês" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="01">Janeiro</SelectItem>
                      <SelectItem value="02">Fevereiro</SelectItem>
                      <SelectItem value="03">Março</SelectItem>
                      <SelectItem value="04">Abril</SelectItem>
                      <SelectItem value="05">Maio</SelectItem>
                      <SelectItem value="06">Junho</SelectItem>
                      <SelectItem value="07">Julho</SelectItem>
                      <SelectItem value="08">Agosto</SelectItem>
                      <SelectItem value="09">Setembro</SelectItem>
                      <SelectItem value="10">Outubro</SelectItem>
                      <SelectItem value="11">Novembro</SelectItem>
                      <SelectItem value="12">Dezembro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Dia de Vencimento Padrão</label>
                  <Select defaultValue="31">
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o dia" />
                    </SelectTrigger>
                    <SelectContent>
                      {[...Array(31)].map((_, i) => (
                        <SelectItem key={i+1} value={(i+1).toString().padStart(2, '0')}>
                          {i+1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Percentual de Desconto para Pagamento Antecipado</label>
                  <div className="flex items-center">
                    <Input type="number" defaultValue="10" />
                    <span className="ml-2">%</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Dias de Antecipação para Desconto</label>
                  <Input type="number" defaultValue="30" />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Percentual de Multa por Atraso</label>
                  <div className="flex items-center">
                    <Input type="number" defaultValue="2" />
                    <span className="ml-2">%</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Percentual de Juros ao Mês</label>
                  <div className="flex items-center">
                    <Input type="number" defaultValue="1" />
                    <span className="ml-2">%</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Métodos de Pagamento Aceitos</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="pix" defaultChecked />
                    <label htmlFor="pix">PIX</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="boleto" defaultChecked />
                    <label htmlFor="boleto">Boleto</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="cartao" defaultChecked />
                    <label htmlFor="cartao">Cartão de Crédito</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="transferencia" defaultChecked />
                    <label htmlFor="transferencia">Transferência Bancária</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="dinheiro" defaultChecked />
                    <label htmlFor="dinheiro">Dinheiro</label>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Parcelamento</label>
                <div className="flex flex-col gap-2">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="parcelamento" defaultChecked />
                    <label htmlFor="parcelamento">Permitir Parcelamento</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <label className="text-sm">Número máximo de parcelas:</label>
                    <Select defaultValue="3">
                      <SelectTrigger className="w-20">
                        <SelectValue placeholder="" />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5, 6, 12].map((num) => (
                          <SelectItem key={num} value={num.toString()}>
                            {num}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button className="gap-2">
                <Settings className="w-4 h-4" />
                Salvar Configurações
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
