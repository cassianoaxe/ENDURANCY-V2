import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Leaf, 
  ClipboardList, 
  Plus, 
  Search, 
  Filter, 
  Calendar, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Sprout,
  SunMedium, 
  Trash2, 
  Download, 
  Printer,
  ArrowUpDown,
  Scissors,
  FileText,
  CheckCircle2,
  AlertTriangle
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Batch } from "@/api/entities";
import { format } from 'date-fns';

// Dados mockados para lotes
const mockLotes = [
  { 
    id: 'batch1', 
    batch_id: 'LOTE-2023-0142', 
    name: 'Lote Charlotte Web Junho', 
    strain: 'Charlotte\'s Web', 
    origin: 'clone', 
    mother_plant_id: 'PLT-MAE-023', 
    current_phase: 'vegetativo', 
    location: 'Sala Vegetativo 1', 
    creation_date: '2023-06-15', 
    phase_start_date: '2023-06-30', 
    expected_harvest_date: '2023-08-30', 
    initial_plant_count: 50, 
    current_plant_count: 48,
    status: 'ativo',
    health_status: 'saudável'
  },
  { 
    id: 'batch2', 
    batch_id: 'LOTE-2023-0143', 
    name: 'Lote CBD Skunk Junho', 
    strain: 'CBD Skunk', 
    origin: 'clone', 
    mother_plant_id: 'PLT-MAE-018', 
    current_phase: 'floração', 
    location: 'Sala Floração 1', 
    creation_date: '2023-06-01', 
    phase_start_date: '2023-07-01', 
    expected_harvest_date: '2023-08-15', 
    initial_plant_count: 40, 
    current_plant_count: 36,
    status: 'ativo',
    health_status: 'problema leve'
  },
  { 
    id: 'batch3', 
    batch_id: 'LOTE-2023-0144', 
    name: 'Lote Cannatonic Junho', 
    strain: 'Cannatonic', 
    origin: 'clone', 
    mother_plant_id: 'PLT-MAE-015', 
    current_phase: 'floração', 
    location: 'Sala Floração 2', 
    creation_date: '2023-06-05', 
    phase_start_date: '2023-07-05', 
    expected_harvest_date: '2023-08-20', 
    initial_plant_count: 45, 
    current_plant_count: 42,
    status: 'ativo',
    health_status: 'saudável'
  },
  { 
    id: 'batch4', 
    batch_id: 'LOTE-2023-0145', 
    name: 'Lote Harlequin Julho', 
    strain: 'Harlequin', 
    origin: 'semente', 
    mother_plant_id: null, 
    current_phase: 'propagação', 
    location: 'Sala Propagação', 
    creation_date: '2023-07-10', 
    phase_start_date: '2023-07-10', 
    expected_harvest_date: '2023-10-01', 
    initial_plant_count: 60, 
    current_plant_count: 60,
    status: 'ativo',
    health_status: 'saudável'
  },
  { 
    id: 'batch5', 
    batch_id: 'LOTE-2023-0130', 
    name: 'Lote ACDC Maio', 
    strain: 'ACDC', 
    origin: 'clone', 
    mother_plant_id: 'PLT-MAE-021', 
    current_phase: 'colheita', 
    location: 'Sala de Secagem', 
    creation_date: '2023-05-02', 
    phase_start_date: '2023-07-20', 
    expected_harvest_date: '2023-07-22', 
    initial_plant_count: 45, 
    current_plant_count: 0,
    harvested_plant_count: 42,
    discarded_plant_count: 3,
    total_wet_weight: 18600,
    status: 'concluído',
    health_status: 'saudável'
  }
];

// Função para obter ícone por fase
const getPhaseIcon = (phase) => {
  switch(phase) {
    case 'propagação':
      return <Sprout className="w-4 h-4 text-blue-600" />;
    case 'vegetativo':
      return <Leaf className="w-4 h-4 text-green-600" />;
    case 'floração':
      return <SunMedium className="w-4 h-4 text-purple-600" />;
    case 'colheita':
      return <Scissors className="w-4 h-4 text-amber-600" />;
    case 'secagem':
      return <FileText className="w-4 h-4 text-gray-600" />;
    default:
      return <ClipboardList className="w-4 h-4 text-gray-600" />;
  }
};

// Função para obter cor por status de saúde
const getHealthColor = (status) => {
  switch(status) {
    case 'saudável':
      return 'bg-green-100 text-green-800';
    case 'problema leve':
      return 'bg-yellow-100 text-yellow-800';
    case 'problema grave':
      return 'bg-orange-100 text-orange-800';
    case 'infestação':
    case 'doença':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

const getLoteStatus = (status) => {
  switch(status) {
    case 'ativo':
      return <Badge className="bg-green-100 text-green-800">Ativo</Badge>;
    case 'concluído':
      return <Badge className="bg-blue-100 text-blue-800">Concluído</Badge>;
    case 'descartado':
      return <Badge className="bg-red-100 text-red-800">Descartado</Badge>;
    default:
      return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
  }
};

// Componente principal
export default function CultivoLotes() {
  const [isLoading, setIsLoading] = useState(true);
  const [lotes, setLotes] = useState([]);
  const [filteredLotes, setFilteredLotes] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');
  const [phaseFilter, setPhaseFilter] = useState('todas');
  const [strainFilter, setStrainFilter] = useState('todas');
  const [sortConfig, setSortConfig] = useState({ key: 'creation_date', direction: 'desc' });
  const [activeTab, setActiveTab] = useState('todos');

  useEffect(() => {
    loadLotes();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [searchTerm, statusFilter, phaseFilter, strainFilter, activeTab, lotes]);

  const loadLotes = async () => {
    try {
      setIsLoading(true);
      
      // Em produção, aqui seriam chamadas para as APIs reais
      // const fetchedLotes = await Batch.list('-created_date');
      
      // Simulando carregamento
      setTimeout(() => {
        setLotes(mockLotes);
        setFilteredLotes(mockLotes);
        setIsLoading(false);
      }, 800);
      
    } catch (error) {
      console.error("Erro ao carregar lotes:", error);
      setIsLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...lotes];
    
    // Filtro por aba
    if (activeTab === 'ativos') {
      filtered = filtered.filter(lote => lote.status === 'ativo');
    } else if (activeTab === 'concluidos') {
      filtered = filtered.filter(lote => lote.status === 'concluído');
    } else if (activeTab === 'descartados') {
      filtered = filtered.filter(lote => lote.status === 'descartado');
    }
    
    // Filtro por termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(lote => 
        lote.name.toLowerCase().includes(term) || 
        lote.batch_id.toLowerCase().includes(term) ||
        lote.strain.toLowerCase().includes(term)
      );
    }
    
    // Filtro por status
    if (statusFilter !== 'todos') {
      filtered = filtered.filter(lote => lote.status === statusFilter);
    }
    
    // Filtro por fase
    if (phaseFilter !== 'todas') {
      filtered = filtered.filter(lote => lote.current_phase === phaseFilter);
    }
    
    // Filtro por strain
    if (strainFilter !== 'todas') {
      filtered = filtered.filter(lote => lote.strain === strainFilter);
    }
    
    // Ordenação
    filtered.sort((a, b) => {
      if (a[sortConfig.key] < b[sortConfig.key]) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (a[sortConfig.key] > b[sortConfig.key]) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
    
    setFilteredLotes(filtered);
  };

  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), 'dd/MM/yyyy');
    } catch (error) {
      return dateString;
    }
  };

  // Obtém lista única de strains para o filtro
  const uniqueStrains = ['todas', ...Array.from(new Set(lotes.map(lote => lote.strain)))];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Lotes de Cultivo</h1>
          <p className="text-gray-500 mt-1">
            Gerenciamento de lotes de plantas por ciclo de cultivo
          </p>
        </div>
        
        <Link to={createPageUrl("CultivoNovoLote")}>
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            Novo Lote
          </Button>
        </Link>
      </div>
      
      <Tabs defaultValue="todos" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="todos">Todos os Lotes</TabsTrigger>
          <TabsTrigger value="ativos">Lotes Ativos</TabsTrigger>
          <TabsTrigger value="concluidos">Concluídos</TabsTrigger>
          <TabsTrigger value="descartados">Descartados</TabsTrigger>
        </TabsList>
        
        <TabsContent value="todos" className="space-y-4">
          <Card>
            <CardHeader className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar lotes..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <div className="flex gap-2">
                  <Select value={phaseFilter} onValueChange={setPhaseFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Fase" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todas">Todas as Fases</SelectItem>
                      <SelectItem value="propagação">Propagação</SelectItem>
                      <SelectItem value="vegetativo">Vegetativo</SelectItem>
                      <SelectItem value="floração">Floração</SelectItem>
                      <SelectItem value="colheita">Colheita</SelectItem>
                      <SelectItem value="secagem">Secagem</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select value={strainFilter} onValueChange={setStrainFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Strain" />
                    </SelectTrigger>
                    <SelectContent>
                      {uniqueStrains.map((strain, index) => (
                        <SelectItem key={index} value={strain}>
                          {strain === 'todas' ? 'Todas as Strains' : strain}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex justify-end gap-2">
                  <Button variant="outline" size="icon" onClick={() => {
                    setSearchTerm('');
                    setStatusFilter('todos');
                    setPhaseFilter('todas');
                    setStrainFilter('todas');
                  }}>
                    <Filter className="w-4 h-4" />
                  </Button>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Exportar
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <FileText className="w-4 h-4 mr-2" />
                        Exportar para CSV
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Printer className="w-4 h-4 mr-2" />
                        Imprimir relatório
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
                  <p className="ml-2">Carregando lotes...</p>
                </div>
              ) : filteredLotes.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-12 text-center">
                  <ClipboardList className="w-12 h-12 text-gray-300 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900">Nenhum lote encontrado</h3>
                  <p className="text-gray-500 mt-1 max-w-md mx-auto">
                    Não foram encontrados lotes com os filtros selecionados. Tente ajustar seus critérios de busca ou crie um novo lote.
                  </p>
                  <Link to={createPageUrl("CultivoNovoLote")}>
                    <Button className="mt-4 gap-2">
                      <Plus className="w-4 h-4" />
                      Criar Novo Lote
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="border-t overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[80px]">ID</TableHead>
                        <TableHead>
                          <div className="flex items-center cursor-pointer" onClick={() => handleSort('name')}>
                            Nome
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </div>
                        </TableHead>
                        <TableHead>Strain</TableHead>
                        <TableHead>
                          <div className="flex items-center cursor-pointer" onClick={() => handleSort('current_phase')}>
                            Fase
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </div>
                        </TableHead>
                        <TableHead>Plantas</TableHead>
                        <TableHead>
                          <div className="flex items-center cursor-pointer" onClick={() => handleSort('creation_date')}>
                            Data Criação
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </div>
                        </TableHead>
                        <TableHead>
                          <div className="flex items-center cursor-pointer" onClick={() => handleSort('expected_harvest_date')}>
                            Colheita Prev.
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </div>
                        </TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Saúde</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredLotes.map((lote) => (
                        <TableRow key={lote.id}>
                          <TableCell className="font-medium">{lote.batch_id.split('-').pop()}</TableCell>
                          <TableCell>
                            <div className="font-medium">{lote.name}</div>
                            <div className="text-xs text-gray-500">
                              {lote.origin === 'clone' ? 'Clone' : 'Semente'}
                              {lote.mother_plant_id && ` • Mãe: ${lote.mother_plant_id}`}
                            </div>
                          </TableCell>
                          <TableCell>{lote.strain}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              {getPhaseIcon(lote.current_phase)}
                              <span className="capitalize">{lote.current_phase}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">{lote.current_plant_count}</div>
                            <div className="text-xs text-gray-500">
                              {lote.status === 'concluído' ? (
                                <>
                                  <CheckCircle2 className="w-3 h-3 text-green-500 inline mr-1" />
                                  {lote.harvested_plant_count} colhidas
                                </>
                              ) : (
                                `${lote.current_plant_count}/${lote.initial_plant_count}`
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{formatDate(lote.creation_date)}</TableCell>
                          <TableCell>
                            {lote.current_phase === 'colheita' || lote.status === 'concluído' ? 
                              <span className="text-green-600 font-medium">Concluído</span> : 
                              formatDate(lote.expected_harvest_date)
                            }
                          </TableCell>
                          <TableCell>{getLoteStatus(lote.status)}</TableCell>
                          <TableCell>
                            <Badge className={getHealthColor(lote.health_status)}>
                              {lote.health_status === 'saudável' ? (
                                <CheckCircle2 className="w-3 h-3 mr-1" />
                              ) : (
                                <AlertTriangle className="w-3 h-3 mr-1" />
                              )}
                              <span className="capitalize">{lote.health_status}</span>
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                  <span className="sr-only">Abrir menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                <DropdownMenuItem>
                                  <Link 
                                    to={`${createPageUrl("CultivoLoteDetalhes")}?id=${lote.id}`}
                                    className="flex items-center"
                                  >
                                    <Eye className="mr-2 h-4 w-4" />
                                    <span>Ver detalhes</span>
                                  </Link>
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="mr-2 h-4 w-4" />
                                  <span>Editar</span>
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                {lote.status === 'ativo' && (
                                  <>
                                    <DropdownMenuItem>
                                      <Scissors className="mr-2 h-4 w-4" />
                                      <span>Iniciar colheita</span>
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <Trash2 className="mr-2 h-4 w-4" />
                                      <span>Descartar lote</span>
                                    </DropdownMenuItem>
                                  </>
                                )}
                                <DropdownMenuItem>
                                  <Printer className="mr-2 h-4 w-4" />
                                  <span>Imprimir etiquetas</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Os demais TabsContent herdam o conteúdo de "todos" através da lógica de filtros aplicada ao activeTab */}
        <TabsContent value="ativos"><div className="h-4"></div></TabsContent>
        <TabsContent value="concluidos"><div className="h-4"></div></TabsContent>
        <TabsContent value="descartados"><div className="h-4"></div></TabsContent>
      </Tabs>
    </div>
  );
}