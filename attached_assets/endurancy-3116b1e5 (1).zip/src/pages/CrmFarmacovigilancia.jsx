import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  AlertTriangle, 
  Search, 
  Filter, 
  Clock, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  MoreHorizontal, 
  CalendarDays, 
  User, 
  Pill, 
  FlaskConical, 
  Shield, 
  BarChart2,
  Download,
  RefreshCw,
  Send,
  ArrowUpRight,
  Link,
  MessageSquare,
  Plus,
  AlertCircle,
  FileWarning,
  UserMinus
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/components/ui/use-toast";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export default function CrmFarmacovigilancia() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [tipoEvento, setTipoEvento] = useState("all");
  const [gravidadeFilter, setGravidadeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [eventos, setEventos] = useState([]);
  const [showNovoEvento, setShowNovoEvento] = useState(false);
  const [showNovoAcompanhamento, setShowNovoAcompanhamento] = useState(false);
  const [selectedEvento, setSelectedEvento] = useState(null);
  const [novoAcompanhamento, setNovoAcompanhamento] = useState("");
  const [showNotificarAnvisa, setShowNotificarAnvisa] = useState(false);

  const urlParams = new URLSearchParams(location.search);
  const idFromURL = urlParams.get('id');

  // Mock data para eventos de farmacovigilância
  const mockEventos = [
    {
      id: "FV-2023-001",
      tipo: "reacao_adversa",
      data: "2023-11-10T14:35:22Z",
      paciente: {
        nome: "Maria Silva",
        idade: 45,
        sexo: "feminino"
      },
      produto: "Óleo de CBD 5%",
      lote: "LOT-2023-001",
      descricao: "Paciente relatou tontura e náusea depois de usar o medicamento pela primeira vez",
      gravidade: "moderada",
      status: "em_analise",
      responsavel: "Dr. Ana Costa",
      origem: "sac",
      origem_id: "SAC-2023-003",
      notificado_anvisa: false,
      notificado_fabricante: true,
      data_inicio_uso: "2023-11-05",
      data_evento: "2023-11-06",
      acompanhamentos: [
        {
          data: "2023-11-11T09:30:00Z",
          usuario: "Ana Costa",
          comentario: "Entrei em contato com a paciente para obter mais detalhes. Evento ocorreu após primeira dose, sintomas duraram cerca de 2 horas."
        },
        {
          data: "2023-11-12T14:20:00Z",
          usuario: "Carlos Santos",
          comentario: "Solicitei histórico médico da paciente para verificar possíveis interações medicamentosas."
        }
      ]
    },
    {
      id: "FV-2023-002",
      tipo: "ineficacia",
      data: "2023-11-12T10:45:30Z",
      paciente: {
        nome: "João Oliveira",
        idade: 38,
        sexo: "masculino"
      },
      produto: "Cápsulas de CBD 25mg",
      lote: "LOT-2023-006",
      descricao: "Paciente não observou melhora dos sintomas após 45 dias de tratamento contínuo",
      gravidade: "baixa",
      status: "concluido",
      responsavel: "Dr. Pedro Santos",
      origem: "consulta",
      origem_id: "CON-2023-056",
      notificado_anvisa: true,
      notificado_fabricante: true,
      data_inicio_uso: "2023-09-20",
      data_evento: "2023-11-05",
      acompanhamentos: [
        {
          data: "2023-11-13T11:15:00Z",
          usuario: "Pedro Santos",
          comentario: "Análise do caso constatou que a dosagem prescrita estava abaixo da recomendada para a condição do paciente."
        },
        {
          data: "2023-11-14T09:40:00Z",
          usuario: "Ana Costa",
          comentario: "Médico prescreveu novo regime terapêutico com dosagem ajustada. Caso encerrado como não relacionado ao produto."
        }
      ]
    },
    {
      id: "FV-2023-003",
      tipo: "reacao_adversa",
      data: "2023-11-14T16:20:15Z",
      paciente: {
        nome: "Sandra Vieira",
        idade: 52,
        sexo: "feminino"
      },
      produto: "Óleo de CBD 10%",
      lote: "LOT-2023-004",
      descricao: "Paciente apresentou rash cutâneo e coceira após 3 dias de uso",
      gravidade: "grave",
      status: "pendente",
      responsavel: "",
      origem: "sac",
      origem_id: "SAC-2023-005",
      notificado_anvisa: false,
      notificado_fabricante: false,
      data_inicio_uso: "2023-11-10",
      data_evento: "2023-11-13",
      acompanhamentos: []
    },
    {
      id: "FV-2023-004",
      tipo: "reacao_adversa",
      data: "2023-11-15T13:10:05Z",
      paciente: {
        nome: "Roberto Costa",
        idade: 67,
        sexo: "masculino"
      },
      produto: "Pomada CBD 2%",
      lote: "LOT-2023-008",
      descricao: "Paciente relatou vermelhidão e irritação no local de aplicação",
      gravidade: "leve",
      status: "em_analise",
      responsavel: "Dr. Carlos Santos",
      origem: "consulta",
      origem_id: "CON-2023-078",
      notificado_anvisa: false,
      notificado_fabricante: false,
      data_inicio_uso: "2023-11-12",
      data_evento: "2023-11-14",
      acompanhamentos: [
        {
          data: "2023-11-16T10:30:00Z",
          usuario: "Carlos Santos",
          comentario: "Paciente tem histórico de sensibilidade cutânea. Solicitei análise da formulação para verificar possíveis alergenos."
        }
      ]
    },
    {
      id: "FV-2023-005",
      tipo: "ineficacia",
      data: "2023-11-16T09:45:30Z",
      paciente: {
        nome: "Antônio Ferreira",
        idade: 42,
        sexo: "masculino"
      },
      produto: "Óleo de CBD 5%",
      lote: "LOT-2023-002",
      descricao: "Paciente relata que não percebeu melhora da ansiedade após 30 dias de uso contínuo",
      gravidade: "moderada",
      status: "em_analise",
      responsavel: "Dra. Maria Oliveira",
      origem: "sac",
      origem_id: "SAC-2023-012",
      notificado_anvisa: false,
      notificado_fabricante: true,
      data_inicio_uso: "2023-10-15",
      data_evento: "2023-11-15",
      acompanhamentos: [
        {
          data: "2023-11-17T14:25:00Z",
          usuario: "Maria Oliveira",
          comentario: "Verificamos que o lote apresentou resultados adequados nos testes de controle de qualidade. Solicitados mais detalhes sobre a forma de uso pelo paciente."
        }
      ]
    }
  ];

  useEffect(() => {
    // Simula carregamento de dados
    setIsLoading(true);
    setTimeout(() => {
      setEventos(mockEventos);
      
      // Se veio de um encaminhamento do SAC
      if (idFromURL && idFromURL.startsWith('SAC-')) {
        // Encontrar o evento relacionado ao SAC ou criar um novo
        const eventoExistente = mockEventos.find(e => e.origem_id === idFromURL);
        
        if (eventoExistente) {
          setSelectedEvento(eventoExistente);
          toast({
            title: "Evento já registrado",
            description: `O evento ${eventoExistente.id} já foi registrado para este atendimento.`,
          });
        } else {
          setShowNovoEvento(true);
        }
      }
      
      setIsLoading(false);
    }, 1000);
  }, [idFromURL]);

  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleFilter = (field, value) => {
    if (field === 'tipo') {
      setTipoEvento(value);
    } else if (field === 'gravidade') {
      setGravidadeFilter(value);
    } else if (field === 'status') {
      setStatusFilter(value);
    }
  };

  const handleAcompanhamentoChange = (e) => {
    setNovoAcompanhamento(e.target.value);
  };

  const handleSubmitAcompanhamento = () => {
    if (!novoAcompanhamento.trim()) return;
    
    setIsLoading(true);
    
    setTimeout(() => {
      const updatedEventos = eventos.map(evento => {
        if (evento.id === selectedEvento.id) {
          const updatedEvento = {
            ...evento,
            acompanhamentos: [
              ...evento.acompanhamentos,
              {
                data: new Date().toISOString(),
                usuario: "Usuário Logado",
                comentario: novoAcompanhamento
              }
            ]
          };
          setSelectedEvento(updatedEvento);
          return updatedEvento;
        }
        return evento;
      });
      
      setEventos(updatedEventos);
      setNovoAcompanhamento("");
      setShowNovoAcompanhamento(false);
      
      toast({
        title: "Acompanhamento registrado",
        description: "O registro de acompanhamento foi adicionado com sucesso.",
      });
      
      setIsLoading(false);
    }, 1000);
  };

  const handleNotificarAnvisa = () => {
    setIsLoading(true);
    
    setTimeout(() => {
      const updatedEventos = eventos.map(evento => {
        if (evento.id === selectedEvento.id) {
          const updatedEvento = {
            ...evento,
            notificado_anvisa: true,
            acompanhamentos: [
              ...evento.acompanhamentos,
              {
                data: new Date().toISOString(),
                usuario: "Usuário Logado",
                comentario: "Notificação enviada à ANVISA via sistema NOTIVISA"
              }
            ]
          };
          setSelectedEvento(updatedEvento);
          return updatedEvento;
        }
        return evento;
      });
      
      setEventos(updatedEventos);
      setShowNotificarAnvisa(false);
      
      toast({
        title: "Notificado com sucesso",
        description: "O evento foi notificado à ANVISA com sucesso.",
      });
      
      // Enviar notificação para o módulo de garantia da qualidade
      toast({
        title: "Notificação enviada",
        description: "Uma notificação foi enviada para a Garantia da Qualidade.",
      });
      
      setIsLoading(false);
    }, 1500);
  };

  const filteredEventos = eventos.filter(evento => {
    const matchesSearch = 
      evento.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evento.paciente.nome.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evento.produto.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evento.lote.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evento.descricao.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesTipo = tipoEvento === "all" || evento.tipo === tipoEvento;
    const matchesGravidade = gravidadeFilter === "all" || evento.gravidade === gravidadeFilter;
    const matchesStatus = statusFilter === "all" || evento.status === statusFilter;
    
    return matchesSearch && matchesTipo && matchesGravidade && matchesStatus;
  });

  const getTipoBadge = (tipo) => {
    switch(tipo) {
      case 'reacao_adversa':
        return <Badge className="bg-amber-100 text-amber-800">Reação Adversa</Badge>;
      case 'ineficacia':
        return <Badge className="bg-orange-100 text-orange-800">Ineficácia Terapêutica</Badge>;
      default:
        return <Badge>{tipo}</Badge>;
    }
  };

  const getGravidadeBadge = (gravidade) => {
    switch(gravidade) {
      case 'leve':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Leve</Badge>;
      case 'moderada':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Moderada</Badge>;
      case 'grave':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Grave</Badge>;
      default:
        return <Badge variant="outline">{gravidade}</Badge>;
    }
  };

  const getStatusBadge = (status) => {
    switch(status) {
      case 'pendente':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Pendente</Badge>;
      case 'em_analise':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Em Análise</Badge>;
      case 'concluido':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Concluído</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Farmacovigilância</h1>
          <p className="text-gray-500 mt-1">
            Monitoramento e análise de reações adversas e ineficácia terapêutica
          </p>
        </div>
        <Button onClick={() => {
          setSelectedEvento(null);
          setShowNovoEvento(true);
        }} className="gap-2">
          <Plus className="h-4 w-4" />
          Novo Evento
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filtros</CardTitle>
          <CardDescription>Refine os eventos por tipo, gravidade, status ou busca</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Buscar</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por ID, paciente, produto..."
                  value={searchQuery}
                  onChange={handleSearch}
                  className="pl-8"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Tipo de Evento</Label>
              <Select value={tipoEvento} onValueChange={(value) => handleFilter('tipo', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os tipos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os tipos</SelectItem>
                  <SelectItem value="reacao_adversa">Reações Adversas</SelectItem>
                  <SelectItem value="ineficacia">Ineficácia Terapêutica</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Gravidade</Label>
              <Select value={gravidadeFilter} onValueChange={(value) => handleFilter('gravidade', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Todas as gravidades" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as gravidades</SelectItem>
                  <SelectItem value="leve">Leve</SelectItem>
                  <SelectItem value="moderada">Moderada</SelectItem>
                  <SelectItem value="grave">Grave</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={statusFilter} onValueChange={(value) => handleFilter('status', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="pendente">Pendente</SelectItem>
                  <SelectItem value="em_analise">Em Análise</SelectItem>
                  <SelectItem value="concluido">Concluído</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Eventos de Farmacovigilância</CardTitle>
            <Badge>{filteredEventos.length} eventos</Badge>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <RefreshCw className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredEventos.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64">
              <AlertTriangle className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-medium">Nenhum evento encontrado</p>
              <p className="text-muted-foreground text-center mt-2">
                Não existem eventos que correspondam aos critérios de filtro selecionados.
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Paciente</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Produto/Lote</TableHead>
                    <TableHead>Gravidade</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>ANVISA</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEventos.map((evento) => (
                    <TableRow key={evento.id}>
                      <TableCell className="font-medium">{evento.id}</TableCell>
                      <TableCell>{formatDate(evento.data)}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{evento.paciente.nome}</span>
                          <span className="text-xs text-muted-foreground">
                            {evento.paciente.idade} anos, {evento.paciente.sexo}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>{getTipoBadge(evento.tipo)}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{evento.produto}</span>
                          <span className="text-xs text-muted-foreground">Lote: {evento.lote}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getGravidadeBadge(evento.gravidade)}</TableCell>
                      <TableCell>{getStatusBadge(evento.status)}</TableCell>
                      <TableCell>
                        {evento.notificado_anvisa ? (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Notificado
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                            Pendente
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => {
                            setSelectedEvento(evento);
                            const dialogElement = document.getElementById('evento-details-dialog');
                            if (dialogElement) {
                              dialogElement.showModal();
                            }
                          }}
                        >
                          <FileText className="h-4 w-4 mr-2" />
                          Detalhes
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detalhes do Evento */}
      {selectedEvento && (
        <Dialog id="evento-details-dialog">
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <span>{selectedEvento.id}</span>
                {getTipoBadge(selectedEvento.tipo)}
              </DialogTitle>
              <DialogDescription>
                Registrado em {formatDate(selectedEvento.data)}
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="detalhes">
              <TabsList className="mb-4">
                <TabsTrigger value="detalhes">Detalhes</TabsTrigger>
                <TabsTrigger value="acompanhamento">
                  Acompanhamento
                  <Badge className="ml-2 h-5 w-5 rounded-full text-xs">
                    {selectedEvento.acompanhamentos.length}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="notificacoes">Notificações</TabsTrigger>
              </TabsList>
              
              <TabsContent value="detalhes">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2">
                        <User className="h-4 w-4" />
                        Informações do Paciente
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-sm font-medium">Nome</p>
                        <p>{selectedEvento.paciente.nome}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium">Idade</p>
                          <p>{selectedEvento.paciente.idade} anos</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Sexo</p>
                          <p>{selectedEvento.paciente.sexo}</p>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Origem do Relato</p>
                        <p className="flex items-center gap-1">
                          {selectedEvento.origem === 'sac' ? 'SAC' : 'Consulta Médica'}
                          <Link className="h-3.5 w-3.5 cursor-pointer" onClick={() => navigate(createPageUrl(selectedEvento.origem === 'sac' ? 'CrmSac' : 'CrmPacientes'))} />
                        </p>
                      </div>
                      {selectedEvento.responsavel && (
                        <div>
                          <p className="text-sm font-medium">Responsável</p>
                          <p>{selectedEvento.responsavel}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2">
                        <Pill className="h-4 w-4" />
                        Informações do Produto
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-sm font-medium">Produto</p>
                        <p>{selectedEvento.produto}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Lote</p>
                        <p>{selectedEvento.lote}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium">Início do Uso</p>
                          <p>{new Date(selectedEvento.data_inicio_uso).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Data do Evento</p>
                          <p>{new Date(selectedEvento.data_evento).toLocaleDateString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="md:col-span-2">
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        Descrição do Evento
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>{selectedEvento.descricao}</p>
                      
                      <div className="flex items-center gap-3 mt-4">
                        <div className="bg-amber-50 px-3 py-1.5 rounded-md border border-amber-100 flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4 text-amber-500" />
                          <span className="text-sm font-medium text-amber-700">Gravidade: {selectedEvento.gravidade}</span>
                        </div>
                        
                        <div className="bg-blue-50 px-3 py-1.5 rounded-md border border-blue-100 flex items-center gap-2">
                          <Clock className="h-4 w-4 text-blue-500" />
                          <span className="text-sm font-medium text-blue-700">Status: {selectedEvento.status.replace('_', ' ')}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="acompanhamento">
                <Card>
                  <CardHeader className="flex flex-row justify-between">
                    <div>
                      <CardTitle>Histórico de Acompanhamento</CardTitle>
                      <CardDescription>
                        Registro de todas as ações e acompanhamento do caso
                      </CardDescription>
                    </div>
                    <Button onClick={() => setShowNovoAcompanhamento(true)} className="gap-2">
                      <Plus className="h-4 w-4" />
                      Novo Registro
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {selectedEvento.acompanhamentos.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-8 text-center">
                        <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
                        <p className="text-lg font-medium">Nenhum acompanhamento registrado</p>
                        <p className="text-muted-foreground mt-2 max-w-md">
                          Ainda não existem registros de acompanhamento para este evento de farmacovigilância.
                        </p>
                        <Button onClick={() => setShowNovoAcompanhamento(true)} className="mt-4 gap-2">
                          <Plus className="h-4 w-4" />
                          Adicionar Registro
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {selectedEvento.acompanhamentos.map((item, index) => (
                          <Card key={index} className="relative overflow-hidden">
                            <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary"></div>
                            <CardContent className="p-4">
                              <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center gap-2">
                                  <p className="font-medium">{item.usuario}</p>
                                  <Badge variant="outline" className="text-xs">
                                    {formatDate(item.data)}
                                  </Badge>
                                </div>
                              </div>
                              <p>{item.comentario}</p>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="notificacoes">
                <Card>
                  <CardHeader>
                    <CardTitle>Notificações regulatórias</CardTitle>
                    <CardDescription>
                      Status das notificações à ANVISA e outros órgãos reguladores
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">ANVISA (NOTIVISA)</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex justify-between items-center">
                            {selectedEvento.notificado_anvisa ? (
                              <div className="flex items-center gap-2 text-green-600">
                                <CheckCircle2 className="h-5 w-5" />
                                <div>
                                  <p className="font-medium">Notificado</p>
                                  <p className="text-sm text-muted-foreground">
                                    {/* Data fictícia de notificação */}
                                    Notificado em {new Date(selectedEvento.data).toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2 text-amber-600">
                                <AlertCircle className="h-5 w-5" />
                                <div>
                                  <p className="font-medium">Não notificado</p>
                                  <p className="text-sm text-muted-foreground">
                                    Notificação pendente
                                  </p>
                                </div>
                              </div>
                            )}
                            
                            {!selectedEvento.notificado_anvisa && (
                              <Button onClick={() => setShowNotificarAnvisa(true)}>
                                Notificar Agora
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">Fabricante/Fornecedor</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex justify-between items-center">
                            {selectedEvento.notificado_fabricante ? (
                              <div className="flex items-center gap-2 text-green-600">
                                <CheckCircle2 className="h-5 w-5" />
                                <div>
                                  <p className="font-medium">Notificado</p>
                                  <p className="text-sm text-muted-foreground">
                                    {/* Data fictícia de notificação */}
                                    Notificado em {new Date(selectedEvento.data).toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2 text-amber-600">
                                <AlertCircle className="h-5 w-5" />
                                <div>
                                  <p className="font-medium">Não notificado</p>
                                  <p className="text-sm text-muted-foreground">
                                    Notificação pendente
                                  </p>
                                </div>
                              </div>
                            )}
                            
                            {!selectedEvento.notificado_fabricante && (
                              <Button variant="outline">
                                Notificar Fabricante
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className="md:col-span-2">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">Garantia da Qualidade</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center gap-4">
                            <div className="flex-1">
                              <p className="text-sm">
                                A notificação ao setor de Garantia da Qualidade é importante para avaliação de possíveis impactos na qualidade do produto e necessidade de ações corretivas ou recall.
                              </p>
                            </div>
                            <Button 
                              className="gap-2" 
                              variant="secondary"
                              onClick={() => {
                                toast({
                                  title: "Notificação enviada",
                                  description: "A Garantia da Qualidade foi notificada sobre este evento.",
                                });
                              }}
                            >
                              <Send className="h-4 w-4" />
                              Notificar GQ
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
            
            <DialogFooter className="gap-2">
              {selectedEvento.status !== 'concluido' && (
                <Button 
                  variant="outline" 
                  className="gap-2"
                  onClick={() => {
                    const updatedEventos = eventos.map(evento => {
                      if (evento.id === selectedEvento.id) {
                        const updatedEvento = {
                          ...evento,
                          status: 'concluido'
                        };
                        setSelectedEvento(updatedEvento);
                        return updatedEvento;
                      }
                      return evento;
                    });
                    
                    setEventos(updatedEventos);
                    
                    toast({
                      title: "Evento concluído",
                      description: `O evento ${selectedEvento.id} foi marcado como concluído.`,
                    });
                  }}
                >
                  <CheckCircle2 className="h-4 w-4" />
                  Concluir Evento
                </Button>
              )}
              
              <Button 
                className="gap-2"
                onClick={() => {
                  const printWindow = window.open('', '_blank');
                  if (printWindow) {
                    printWindow.document.write(`
                      <html>
                        <head>
                          <title>Relatório de Farmacovigilância - ${selectedEvento.id}</title>
                          <style>
                            body { font-family: Arial, sans-serif; line-height: 1.6; padding: 20px; }
                            h1 { color: #333; }
                            .section { margin-bottom: 20px; }
                            .label { font-weight: bold; margin-bottom: 5px; }
                            table { width: 100%; border-collapse: collapse; margin: 15px 0; }
                            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                            th { background-color: #f2f2f2; }
                          </style>
                        </head>
                        <body>
                          <h1>Relatório de Farmacovigilância - ${selectedEvento.id}</h1>
                          <div class="section">
                            <p><span class="label">Tipo:</span> ${selectedEvento.tipo === 'reacao_adversa' ? 'Reação Adversa' : 'Ineficácia Terapêutica'}</p>
                            <p><span class="label">Data do Registro:</span> ${formatDate(selectedEvento.data)}</p>
                            <p><span class="label">Gravidade:</span> ${selectedEvento.gravidade}</p>
                            <p><span class="label">Status:</span> ${selectedEvento.status}</p>
                          </div>
                          <div class="section">
                            <h2>Paciente</h2>
                            <p><span class="label">Nome:</span> ${selectedEvento.paciente.nome}</p>
                            <p><span class="label">Idade:</span> ${selectedEvento.paciente.idade} anos</p>
                            <p><span class="label">Sexo:</span> ${selectedEvento.paciente.sexo}</p>
                          </div>
                          <div class="section">
                            <h2>Produto</h2>
                            <p><span class="label">Nome:</span> ${selectedEvento.produto}</p>
                            <p><span class="label">Lote:</span> ${selectedEvento.lote}</p>
                            <p><span class="label">Início do Uso:</span> ${new Date(selectedEvento.data_inicio_uso).toLocaleDateString()}</p>
                            <p><span class="label">Data do Evento:</span> ${new Date(selectedEvento.data_evento).toLocaleDateString()}</p>
                          </div>
                          <div class="section">
                            <h2>Descrição</h2>
                            <p>${selectedEvento.descricao}</p>
                          </div>
                          <div class="section">
                            <h2>Acompanhamento</h2>
                            ${selectedEvento.acompanhamentos.length === 0 ? 
                              '<p>Nenhum acompanhamento registrado.</p>' : 
                              `<table>
                                <tr>
                                  <th>Data</th>
                                  <th>Usuário</th>
                                  <th>Comentário</th>
                                </tr>
                                ${selectedEvento.acompanhamentos.map(a => 
                                  `<tr>
                                    <td>${formatDate(a.data)}</td>
                                    <td>${a.usuario}</td>
                                    <td>${a.comentario}</td>
                                  </tr>`
                                ).join('')}
                              </table>`
                            }
                          </div>
                        </body>
                      </html>
                    `);
                    printWindow.document.close();
                    printWindow.print();
                  }
                }}
              >
                <Download className="h-4 w-4" />
                Gerar Relatório
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Diálogo para novo acompanhamento */}
      <Dialog open={showNovoAcompanhamento} onOpenChange={setShowNovoAcompanhamento}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Novo Registro de Acompanhamento</DialogTitle>
            <DialogDescription>
              Registre informações adicionais, ações realizadas e acompanhamento do caso.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea 
              placeholder="Detalhes do acompanhamento..."
              value={novoAcompanhamento}
              onChange={handleAcompanhamentoChange}
              rows={6}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNovoAcompanhamento(false)}>
              Cancelar
            </Button>
            <Button disabled={!novoAcompanhamento.trim()} onClick={handleSubmitAcompanhamento}>
              {isLoading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : null}
              Registrar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para notificar ANVISA */}
      <Dialog open={showNotificarAnvisa} onOpenChange={setShowNotificarAnvisa}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Notificar ANVISA (NOTIVISA)</DialogTitle>
            <DialogDescription>
              Esta ação irá registrar a notificação deste evento à ANVISA através do sistema NOTIVISA.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-amber-50 p-4 rounded-md border border-amber-200">
              <div className="flex gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
                <div>
                  <p className="font-medium text-amber-800">Importante</p>
                  <p className="text-sm text-amber-700 mt-1">
                    De acordo com a RDC 406/2020, a notificação de eventos adversos graves deve ser feita em até 72h após o conhecimento.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Protocolo NOTIVISA</Label>
              <Input placeholder="Insira o número do protocolo (opcional)" />
              <p className="text-xs text-muted-foreground">
                Se você já registrou esta notificação manualmente no sistema NOTIVISA, insira o número de protocolo.
              </p>
            </div>
            
            <div className="space-y-2">
              <Label>Observações adicionais</Label>
              <Textarea 
                placeholder="Informações adicionais para a notificação..." 
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNotificarAnvisa(false)}>
              Cancelar
            </Button>
            <Button onClick={handleNotificarAnvisa}>
              {isLoading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : null}
              Confirmar Notificação
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}