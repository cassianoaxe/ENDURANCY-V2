import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Warehouse, 
  Search, 
  Plus, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  FileText, 
  Download, 
  Package, 
  ArrowUpDown, 
  MoreHorizontal,
  Beaker,
  Calendar
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";

// Dados simulados para matérias-primas
const mockMaterials = [
  {
    id: "mp001",
    codigo: "MP-CBD-001",
    nome: "Extrato CBD Isolado",
    tipo: "materia_prima",
    fabricante: "CannabEx",
    quantidade_disponivel: 5.2,
    unidade_medida: "kg",
    requer_analise_qualidade: true,
    status: "aprovado"
  },
  {
    id: "mp002",
    codigo: "MP-MCT-001",
    nome: "Óleo MCT",
    tipo: "materia_prima",
    fabricante: "NatureOils",
    quantidade_disponivel: 125,
    unidade_medida: "L",
    requer_analise_qualidade: true,
    status: "aprovado"
  },
  {
    id: "mp003",
    codigo: "MP-HEM-001",
    nome: "Óleo Semente de Cânhamo",
    tipo: "materia_prima",
    fabricante: "HempHarvest",
    quantidade_disponivel: 12,
    unidade_medida: "L",
    requer_analise_qualidade: true,
    status: "em_analise"
  },
  {
    id: "mp004",
    codigo: "EM-VID-001",
    nome: "Embalagens Vidro Âmbar 30ml",
    tipo: "embalagem",
    fabricante: "GlassPack",
    quantidade_disponivel: 850,
    unidade_medida: "un",
    requer_analise_qualidade: false,
    status: "aprovado"
  },
  {
    id: "mp005",
    codigo: "EM-CG-001",
    nome: "Conta-gotas",
    tipo: "embalagem",
    fabricante: "GlassPack",
    quantidade_disponivel: 820,
    unidade_medida: "un",
    requer_analise_qualidade: false,
    status: "aprovado"
  },
  {
    id: "mp006",
    codigo: "MP-TER-001",
    nome: "Terpenos Naturais",
    tipo: "materia_prima",
    fabricante: "TerpTech",
    quantidade_disponivel: 1.2,
    unidade_medida: "L",
    requer_analise_qualidade: true,
    status: "reprovado"
  },
  {
    id: "mp007",
    codigo: "EM-ROT-001",
    nome: "Rótulos Adesivos 30ml",
    tipo: "embalagem",
    fabricante: "LabelPrint",
    quantidade_disponivel: 1200,
    unidade_medida: "un",
    requer_analise_qualidade: false,
    status: "aprovado"
  },
  {
    id: "mp008",
    codigo: "MP-CBG-001",
    nome: "Extrato CBG",
    tipo: "materia_prima",
    fabricante: "CannabEx",
    quantidade_disponivel: 0.8,
    unidade_medida: "kg",
    requer_analise_qualidade: true,
    status: "quarentena"
  }
];

// Dados simulados para lotes de materiais
const mockBatches = [
  {
    id: "lot001",
    material_id: "mp001",
    lote_fabricante: "CBX-202305-12",
    codigo_lote: "LMP-001-2023",
    quantidade_total: 10,
    quantidade_disponivel: 5.2,
    unidade_medida: "kg",
    data_recebimento: "2023-05-15",
    data_fabricacao: "2023-05-01",
    data_validade: "2024-05-01",
    status: "aprovado",
    fornecedor: "CannabTech Distribuidora"
  },
  {
    id: "lot002",
    material_id: "mp002",
    lote_fabricante: "MCT-202304-45",
    codigo_lote: "LMP-002-2023",
    quantidade_total: 200,
    quantidade_disponivel: 125,
    unidade_medida: "L",
    data_recebimento: "2023-04-20",
    data_fabricacao: "2023-04-05",
    data_validade: "2024-04-05",
    status: "aprovado",
    fornecedor: "Insumos Farmacêuticos SA"
  },
  {
    id: "lot003",
    material_id: "mp003",
    lote_fabricante: "HH-202306-32",
    codigo_lote: "LMP-003-2023",
    quantidade_total: 20,
    quantidade_disponivel: 12,
    unidade_medida: "L",
    data_recebimento: "2023-06-10",
    data_fabricacao: "2023-06-01",
    data_validade: "2024-06-01",
    status: "em_analise",
    fornecedor: "Insumos Naturais Ltda"
  },
  {
    id: "lot004",
    material_id: "mp006",
    lote_fabricante: "TP-202305-07",
    codigo_lote: "LMP-006-2023",
    quantidade_total: 2,
    quantidade_disponivel: 1.2,
    unidade_medida: "L",
    data_recebimento: "2023-05-20",
    data_fabricacao: "2023-05-10",
    data_validade: "2023-11-10",
    status: "reprovado",
    fornecedor: "Aromas e Essências Ltda",
    motivo_reprovacao: "Contaminação por solventes acima do limite permitido"
  },
  {
    id: "lot005",
    material_id: "mp008",
    lote_fabricante: "CBX-202307-05",
    codigo_lote: "LMP-008-2023",
    quantidade_total: 1,
    quantidade_disponivel: 0.8,
    unidade_medida: "kg",
    data_recebimento: "2023-07-10",
    data_fabricacao: "2023-07-01",
    data_validade: "2024-07-01",
    status: "quarentena",
    fornecedor: "CannabTech Distribuidora"
  }
];

export default function ProducaoMateriasPrimas() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("todos");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [activeTab, setActiveTab] = useState("materiais");
  const [materials, setMaterials] = useState([]);
  const [batches, setBatches] = useState([]);
  const [selectedMaterial, setSelectedMaterial] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showMaterialDetails, setShowMaterialDetails] = useState(false);
  const [showBatchDetails, setShowBatchDetails] = useState(false);
  const [selectedBatch, setSelectedBatch] = useState(null);
  
  useEffect(() => {
    loadData();
  }, []);
  
  const loadData = async () => {
    try {
      setIsLoading(true);
      // Em um cenário real, estes dados viriam da API
      // Simulando uma requisição
      setTimeout(() => {
        setMaterials(mockMaterials);
        setBatches(mockBatches);
        setIsLoading(false);
      }, 800);
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
      toast({
        title: "Erro ao carregar dados",
        description: "Não foi possível carregar os dados de matérias-primas.",
        variant: "destructive"
      });
      setIsLoading(false);
    }
  };
  
  const handleSearch = (e) => {
    setSearch(e.target.value);
  };
  
  const handleViewMaterial = (material) => {
    setSelectedMaterial(material);
    setShowMaterialDetails(true);
  };
  
  const handleViewBatch = (batch) => {
    setSelectedBatch(batch);
    setShowBatchDetails(true);
  };
  
  const getMaterialBatches = (materialId) => {
    return batches.filter(batch => batch.material_id === materialId);
  };
  
  const filteredMaterials = materials.filter(material => {
    const matchesSearch = material.nome.toLowerCase().includes(search.toLowerCase()) || 
                          material.codigo.toLowerCase().includes(search.toLowerCase());
    const matchesType = filter === "todos" || material.tipo === filter;
    const matchesStatus = statusFilter === "todos" || material.status === statusFilter;
    
    return matchesSearch && matchesType && matchesStatus;
  });
  
  const getStatusBadge = (status) => {
    switch(status) {
      case 'aprovado':
        return <Badge className="bg-green-100 text-green-800">Aprovado</Badge>;
      case 'reprovado':
        return <Badge className="bg-red-100 text-red-800">Reprovado</Badge>;
      case 'quarentena':
        return <Badge className="bg-yellow-100 text-yellow-800">Quarentena</Badge>;
      case 'em_analise':
        return <Badge className="bg-blue-100 text-blue-800">Em Análise</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };
  
  const getTipoLabel = (tipo) => {
    switch(tipo) {
      case 'materia_prima':
        return 'Matéria-Prima';
      case 'embalagem':
        return 'Embalagem';
      case 'consumivel':
        return 'Consumível';
      default:
        return tipo;
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Warehouse className="h-6 w-6" />
            Matérias-Primas e Embalagens
          </h1>
          <p className="text-gray-500 mt-1">
            Gerenciamento de matérias-primas, embalagens e seus lotes
          </p>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <Link to={createPageUrl("ProducaoNovaMateriaPrima")}>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Matéria-Prima
            </Button>
          </Link>
          
          <Link to={createPageUrl("ProducaoNovoLoteMaterial")}>
            <Button variant="outline" className="gap-2">
              <Plus className="h-4 w-4" />
              Novo Lote
            </Button>
          </Link>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="materiais">Materiais</TabsTrigger>
          <TabsTrigger value="lotes">Lotes</TabsTrigger>
        </TabsList>
        
        <TabsContent value="materiais" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <CardTitle>Catálogo de Materiais</CardTitle>
                
                <div className="flex flex-wrap gap-3">
                  <div className="relative w-64">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      placeholder="Buscar por nome ou código"
                      className="pl-8"
                      value={search}
                      onChange={handleSearch}
                    />
                  </div>
                  
                  <Select value={filter} onValueChange={setFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos os Tipos</SelectItem>
                      <SelectItem value="materia_prima">Matérias-Primas</SelectItem>
                      <SelectItem value="embalagem">Embalagens</SelectItem>
                      <SelectItem value="consumivel">Consumíveis</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos os Status</SelectItem>
                      <SelectItem value="aprovado">Aprovado</SelectItem>
                      <SelectItem value="em_analise">Em Análise</SelectItem>
                      <SelectItem value="quarentena">Quarentena</SelectItem>
                      <SelectItem value="reprovado">Reprovado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center h-60">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
                </div>
              ) : filteredMaterials.length === 0 ? (
                <div className="text-center py-10">
                  <Package className="mx-auto h-12 w-12 text-gray-300" />
                  <h3 className="mt-2 text-lg font-medium text-gray-900">Nenhum material encontrado</h3>
                  <p className="mt-1 text-gray-500">Tente ajustar os filtros ou adicionar um novo material.</p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Código</TableHead>
                        <TableHead>Nome</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Fabricante</TableHead>
                        <TableHead className="text-right">Quantidade Disponível</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredMaterials.map((material) => (
                        <TableRow key={material.id}>
                          <TableCell className="font-medium">{material.codigo}</TableCell>
                          <TableCell>{material.nome}</TableCell>
                          <TableCell>{getTipoLabel(material.tipo)}</TableCell>
                          <TableCell>{material.fabricante}</TableCell>
                          <TableCell className="text-right">
                            {material.quantidade_disponivel} {material.unidade_medida}
                          </TableCell>
                          <TableCell>{getStatusBadge(material.status)}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Abrir menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleViewMaterial(material)}>
                                  Ver detalhes
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Link to={`${createPageUrl("ProducaoNovaMateriaPrima")}?id=${material.id}`} className="w-full">
                                    Editar
                                  </Link>
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <Link to={`${createPageUrl("ProducaoNovoLoteMaterial")}?material_id=${material.id}`} className="w-full">
                                    Adicionar lote
                                  </Link>
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  Gerenciar especificações
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="lotes" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <CardTitle>Lotes de Materiais</CardTitle>
                
                <div className="flex flex-wrap gap-3">
                  <div className="relative w-64">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      placeholder="Buscar por código ou lote"
                      className="pl-8"
                    />
                  </div>
                  
                  <Select defaultValue="todos">
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos os Status</SelectItem>
                      <SelectItem value="aprovado">Aprovado</SelectItem>
                      <SelectItem value="em_analise">Em Análise</SelectItem>
                      <SelectItem value="quarentena">Quarentena</SelectItem>
                      <SelectItem value="reprovado">Reprovado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center h-60">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
                </div>
              ) : batches.length === 0 ? (
                <div className="text-center py-10">
                  <Package className="mx-auto h-12 w-12 text-gray-300" />
                  <h3 className="mt-2 text-lg font-medium text-gray-900">Nenhum lote encontrado</h3>
                  <p className="mt-1 text-gray-500">Adicione um novo lote para começar.</p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Código Lote</TableHead>
                        <TableHead>Material</TableHead>
                        <TableHead>Lote Fabricante</TableHead>
                        <TableHead>Data Validade</TableHead>
                        <TableHead className="text-right">Quantidade</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {batches.map((batch) => {
                        const material = materials.find(m => m.id === batch.material_id);
                        return (
                          <TableRow key={batch.id}>
                            <TableCell className="font-medium">{batch.codigo_lote}</TableCell>
                            <TableCell>{material ? material.nome : 'N/A'}</TableCell>
                            <TableCell>{batch.lote_fabricante}</TableCell>
                            <TableCell>{batch.data_validade}</TableCell>
                            <TableCell className="text-right">
                              {batch.quantidade_disponivel} / {batch.quantidade_total} {batch.unidade_medida}
                            </TableCell>
                            <TableCell>{getStatusBadge(batch.status)}</TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" className="h-8 w-8 p-0">
                                    <span className="sr-only">Abrir menu</span>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => handleViewBatch(batch)}>
                                    Ver detalhes
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Link to={`${createPageUrl("ProducaoNovoLoteMaterial")}?id=${batch.id}`} className="w-full">
                                      Editar
                                    </Link>
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem>
                                    <Link to={`${createPageUrl("ProducaoQualidadeNovaAnalise")}?lote_id=${batch.id}`} className="w-full">
                                      Enviar para análise
                                    </Link>
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    Consultar histórico
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Diálogo de Detalhes do Material */}
      <Dialog open={showMaterialDetails} onOpenChange={setShowMaterialDetails}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Material</DialogTitle>
            <DialogDescription>
              Informações detalhadas e lotes do material.
            </DialogDescription>
          </DialogHeader>
          
          {selectedMaterial && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Nome</h3>
                  <p className="mt-1 text-lg">{selectedMaterial.nome}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Código</h3>
                  <p className="mt-1 text-lg">{selectedMaterial.codigo}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Tipo</h3>
                  <p className="mt-1">{getTipoLabel(selectedMaterial.tipo)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Fabricante</h3>
                  <p className="mt-1">{selectedMaterial.fabricante}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Quantidade Disponível</h3>
                  <p className="mt-1">{selectedMaterial.quantidade_disponivel} {selectedMaterial.unidade_medida}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Status</h3>
                  <div className="mt-1">{getStatusBadge(selectedMaterial.status)}</div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Requer Análise de Qualidade</h3>
                  <p className="mt-1">{selectedMaterial.requer_analise_qualidade ? "Sim" : "Não"}</p>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Lotes Disponíveis</h3>
                
                {getMaterialBatches(selectedMaterial.id).length === 0 ? (
                  <div className="text-center py-6 bg-gray-50 rounded-lg">
                    <Package className="mx-auto h-8 w-8 text-gray-300" />
                    <p className="mt-2 text-gray-500">Não há lotes cadastrados para este material.</p>
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Código Lote</TableHead>
                          <TableHead>Lote Fabricante</TableHead>
                          <TableHead>Data Validade</TableHead>
                          <TableHead className="text-right">Quantidade</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {getMaterialBatches(selectedMaterial.id).map((batch) => (
                          <TableRow key={batch.id}>
                            <TableCell className="font-medium">{batch.codigo_lote}</TableCell>
                            <TableCell>{batch.lote_fabricante}</TableCell>
                            <TableCell>{batch.data_validade}</TableCell>
                            <TableCell className="text-right">
                              {batch.quantidade_disponivel} / {batch.quantidade_total} {batch.unidade_medida}
                            </TableCell>
                            <TableCell>{getStatusBadge(batch.status)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMaterialDetails(false)}>
              Fechar
            </Button>
            
            {selectedMaterial && (
              <Link to={`${createPageUrl("ProducaoNovaMateriaPrima")}?id=${selectedMaterial.id}`}>
                <Button>Editar Material</Button>
              </Link>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Diálogo de Detalhes do Lote */}
      <Dialog open={showBatchDetails} onOpenChange={setShowBatchDetails}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Lote</DialogTitle>
            <DialogDescription>
              Informações detalhadas sobre o lote de material.
            </DialogDescription>
          </DialogHeader>
          
          {selectedBatch && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Código do Lote</h3>
                  <p className="mt-1 text-lg">{selectedBatch.codigo_lote}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Material</h3>
                  <p className="mt-1 text-lg">
                    {materials.find(m => m.id === selectedBatch.material_id)?.nome || 'N/A'}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Lote do Fabricante</h3>
                  <p className="mt-1">{selectedBatch.lote_fabricante}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Fornecedor</h3>
                  <p className="mt-1">{selectedBatch.fornecedor}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Data de Recebimento</h3>
                  <p className="mt-1">{selectedBatch.data_recebimento}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Data de Fabricação</h3>
                  <p className="mt-1">{selectedBatch.data_fabricacao}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Data de Validade</h3>
                  <p className="mt-1">{selectedBatch.data_validade}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Quantidade Total</h3>
                  <p className="mt-1">{selectedBatch.quantidade_total} {selectedBatch.unidade_medida}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Quantidade Disponível</h3>
                  <p className="mt-1">{selectedBatch.quantidade_disponivel} {selectedBatch.unidade_medida}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Status</h3>
                  <div className="mt-1">{getStatusBadge(selectedBatch.status)}</div>
                </div>
              </div>
              
              {selectedBatch.status === 'reprovado' && selectedBatch.motivo_reprovacao && (
                <div className="bg-red-50 border border-red-200 rounded-md p-4">
                  <h3 className="text-sm font-medium text-red-800">Motivo da Reprovação</h3>
                  <p className="mt-1 text-red-700">{selectedBatch.motivo_reprovacao}</p>
                </div>
              )}
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Análises e Documentos</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button variant="outline" className="justify-start gap-2">
                    <FileText className="h-4 w-4" />
                    Nota Fiscal
                  </Button>
                  
                  <Button variant="outline" className="justify-start gap-2">
                    <Beaker className="h-4 w-4" />
                    Laudo de Análise
                  </Button>
                  
                  <Button variant="outline" className="justify-start gap-2">
                    <FileText className="h-4 w-4" />
                    Certificado do Fabricante
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBatchDetails(false)}>
              Fechar
            </Button>
            
            {selectedBatch && (
              <Link to={`${createPageUrl("ProducaoNovoLoteMaterial")}?id=${selectedBatch.id}`}>
                <Button>Editar Lote</Button>
              </Link>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}