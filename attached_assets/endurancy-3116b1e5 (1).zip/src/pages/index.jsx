import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Organizations from "./Organizations";

import Requests from "./Requests";

import Analytics from "./Analytics";

import Activities from "./Activities";

import Backups from "./Backups";

import Emergencies from "./Emergencies";

import Plans from "./Plans";

import Financial from "./Financial";

import EmailTemplates from "./EmailTemplates";

import Admins from "./Admins";

import Settings from "./Settings";

import Request from "./Request";

import NewOrganization from "./NewOrganization";

import UserManagement from "./UserManagement";

import Reports from "./Reports";

import AuditLogs from "./AuditLogs";

import HelpCenter from "./HelpCenter";

import Notifications from "./Notifications";

import OrgDashboard from "./OrgDashboard";

import PatientPortal from "./PatientPortal";

import Landing from "./Landing";

import Index from "./Index";

import RegisterPage from "./RegisterPage";

import ForgotPassword from "./ForgotPassword";

import Access from "./Access";

import RecoverPassword from "./RecoverPassword";

import LegalDocuments from "./LegalDocuments";

import Newsletter from "./Newsletter";

import CultivoDashboard from "./CultivoDashboard";

import CultivoLotes from "./CultivoLotes";

import CultivoNovoLote from "./CultivoNovoLote";

import CultivoEstoque from "./CultivoEstoque";

import CultivoTransferencias from "./CultivoTransferencias";

import CultivoStrains from "./CultivoStrains";

import ModulosDashboard from "./ModulosDashboard";

import ProducaoDashboard from "./ProducaoDashboard";

import CultivoPlantas from "./CultivoPlantas";

import CrmDashboard from "./CrmDashboard";

import RhDashboard from "./RhDashboard";

import PatrimonioDashboard from "./PatrimonioDashboard";

import AssociacaoTransparencia from "./AssociacaoTransparencia";

import TransparencySettings from "./TransparencySettings";

import ModuleManagement from "./ModuleManagement";

import DocumentManagement from "./DocumentManagement";

import TransparencyDocuments from "./TransparencyDocuments";

import TransparencyMembers from "./TransparencyMembers";

import TransparencyFinancial from "./TransparencyFinancial";

import UserProfile from "./UserProfile";

import ModuloCultivo from "./ModuloCultivo";

import ModuloProducao from "./ModuloProducao";

import ModuloCRM from "./ModuloCRM";

import ModuloRH from "./ModuloRH";

import ModuloVendas from "./ModuloVendas";

import VendasDashboard from "./VendasDashboard";

import Pedidos from "./Pedidos";

import Produtos from "./Produtos";

import Etiquetas from "./Etiquetas";

import Rastreamento from "./Rastreamento";

import Associados from "./Associados";

import Anuidades from "./Anuidades";

import NovoAssociado from "./NovoAssociado";

import Clientes from "./Clientes";

import layout from "./layout";

import AutorizacoesAnvisa from "./AutorizacoesAnvisa";

import JuridicoDashboard from "./JuridicoDashboard";

import JuridicoAcoes from "./JuridicoAcoes";

import ModuloJuridico from "./ModuloJuridico";

import Organization from "./Organization";

import Billing from "./Billing";

import ProducaoQualidade from "./ProducaoQualidade";

import ProducaoQualidadeNovaAnalise from "./ProducaoQualidadeNovaAnalise";

import ProducaoGarantiaQualidade from "./ProducaoGarantiaQualidade";

import ProducaoGarantiaLiberacao from "./ProducaoGarantiaLiberacao";

import CultivoTestes from "./CultivoTestes";

import CultivoNovoTeste from "./CultivoNovoTeste";

import ProducaoMateriasPrimas from "./ProducaoMateriasPrimas";

import ProducaoNovaMateriaPrima from "./ProducaoNovaMateriaPrima";

import ProducaoNovoLoteMaterial from "./ProducaoNovoLoteMaterial";

import ProducaoFornecedores from "./ProducaoFornecedores";

import ProducaoNovoFornecedor from "./ProducaoNovoFornecedor";

import ProducaoOrdens from "./ProducaoOrdens";

import ProducaoNovaOrdem from "./ProducaoNovaOrdem";

import CrmPacientes from "./CrmPacientes";

import PrescricoesClientes from "./PrescricoesClientes";

import NovaPrescricao from "./NovaPrescricao";

import CrmPacienteCadastro from "./CrmPacienteCadastro";

import CrmPrescricoes from "./CrmPrescricoes";

import CrmAtendimento from "./CrmAtendimento";

import CrmCampanhas from "./CrmCampanhas";

import TransparencyCertifications from "./TransparencyCertifications";

import RhRecrutamento from "./RhRecrutamento";

import RhColaboradores from "./RhColaboradores";

import RhDocumentos from "./RhDocumentos";

import RhEscalas from "./RhEscalas";

import CultivoRelatorios from "./CultivoRelatorios";

import JuridicoDocumentos from "./JuridicoDocumentos";

import JuridicoCompliance from "./JuridicoCompliance";

import DetalhePedido from "./DetalhePedido";

import Patients from "./Patients";

import DocumentosAssociados from "./DocumentosAssociados";

import PrescricoesAssociados from "./PrescricoesAssociados";

import ComprasDashboard from "./ComprasDashboard";

import SolicitacoesCompra from "./SolicitacoesCompra";

import NovaSolicitacaoCompra from "./NovaSolicitacaoCompra";

import ModuloCompras from "./ModuloCompras";

import Estoque from "./Estoque";

import PedidosCompra from "./PedidosCompra";

import NovoPedido from "./NovoPedido";

import ProducaoDistribuicao from "./ProducaoDistribuicao";

import NovoProduto from "./NovoProduto";

import ModuloLaboratorio from "./ModuloLaboratorio";

import ProducaoAuditTrail from "./ProducaoAuditTrail";

import ProducaoAjuda from "./ProducaoAjuda";

import CrmSac from "./CrmSac";

import CrmFarmacovigilancia from "./CrmFarmacovigilancia";

import CrmRecolhimento from "./CrmRecolhimento";

import CultivoNovaTransferencia from "./CultivoNovaTransferencia";

import EditarPedido from "./EditarPedido";

import ExpedicaoDashboard from "./ExpedicaoDashboard";

import ExpedicaoJuncaoPedidos from "./ExpedicaoJuncaoPedidos";

import ExpedicaoMalotes from "./ExpedicaoMalotes";

import ExpedicaoPreparacao from "./ExpedicaoPreparacao";

import OrgUsuarios from "./OrgUsuarios";

import ExpedicaoEstoque from "./ExpedicaoEstoque";

import ExpedicaoRastreios from "./ExpedicaoRastreios";

import ExpedicaoCodigosBarras from "./ExpedicaoCodigosBarras";

import Promocoes from "./Promocoes";

import CrmNovaCampanha from "./CrmNovaCampanha";

import OrgConfiguracoes from "./OrgConfiguracoes";

import AssistenciaSocial from "./AssistenciaSocial";

import Menu from "./Menu";

import FinanceiroAssociacao from "./FinanceiroAssociacao";

import ContasPagar from "./ContasPagar";

import NovoLancamento from "./NovoLancamento";

import FinanceiroDashboard from "./FinanceiroDashboard";

import FluxoCaixa from "./FluxoCaixa";

import AnaliseFinanceiraIA from "./AnaliseFinanceiraIA";

import CalendarioFinanceiro from "./CalendarioFinanceiro";

import ConciliacaoBancaria from "./ConciliacaoBancaria";

import EventManagement from "./EventManagement";

import OrcamentoAnual from "./OrcamentoAnual";

import ConfiguracoesFinanceiro from "./ConfiguracoesFinanceiro";

import ComplyPay from "./ComplyPay";

import ComplyPayInvoices from "./ComplyPayInvoices";

import ComplyPayTransactions from "./ComplyPayTransactions";

import ComplyPaySubscriptions from "./ComplyPaySubscriptions";

import ComplyPaySettings from "./ComplyPaySettings";

import ComplyPayIntegrations from "./ComplyPayIntegrations";

import GestaoContas from "./GestaoContas";

import ModuloComunicacao from "./ModuloComunicacao";

import CalendarioComunicacao from "./CalendarioComunicacao";

import CampanhasEmail from "./CampanhasEmail";

import ControleMedico from "./ControleMedico";

import ListaMedicos from "./ListaMedicos";

import CadastroMedico from "./CadastroMedico";

import ConsultasMedicas from "./ConsultasMedicas";

import FinanceiroMedico from "./FinanceiroMedico";

import TelemedicinaPaciente from "./TelemedicinaPaciente";

import TelemedicinaMedico from "./TelemedicinaMedico";

import ConsultaVirtual from "./ConsultaVirtual";

import SymptomChecker from "./SymptomChecker";

import BibliotecaEducativa from "./BibliotecaEducativa";

import FeedbackConsulta from "./FeedbackConsulta";

import FeedbackAnalytics from "./FeedbackAnalytics";

import MedicationReminders from "./MedicationReminders";

import NovoConteudo from "./NovoConteudo";

import NotificacoesComunicacao from "./NotificacoesComunicacao";

import AprovacoesPrescriscoes from "./AprovacoesPrescriscoes";

import UploadPrescritionPage from "./UploadPrescritionPage";

import UploadPrescricaoPage from "./UploadPrescricaoPage";

import StatusPrescricao from "./StatusPrescricao";

import NotificationPreferencesPage from "./NotificationPreferencesPage";

import CredenciaisServicos from "./CredenciaisServicos";

import PatientDashboard from "./PatientDashboard";

import ArquivosComunicacao from "./ArquivosComunicacao";

import Representantes from "./Representantes";

import Comissoes from "./Comissoes";

import ComissoesMedicas from "./ComissoesMedicas";

import NovoRepresentante from "./NovoRepresentante";

import DoctorPortal from "./DoctorPortal";

import PatientPortalPWAConfig from "./PatientPortalPWAConfig";

import DoctorDashboard from "./DoctorDashboard";

import DoctorPatients from "./DoctorPatients";

import DoctorPrescriptions from "./DoctorPrescriptions";

import DoctorSettings from "./DoctorSettings";

import DoctorFinancial from "./DoctorFinancial";

import DoctorAppointments from "./DoctorAppointments";

import ModuloDispensario from "./ModuloDispensario";

import PDV from "./PDV";

import DispensarioAssinatura from "./DispensarioAssinatura";

import DispensarioDashboard from "./DispensarioDashboard";

import EstoqueDispensario from "./EstoqueDispensario";

import DispensarioCaixa from "./DispensarioCaixa";

import GerenciarReceituario from "./GerenciarReceituario";

import RelatorioSNGPC from "./RelatorioSNGPC";

import AdminModuloDispensario from "./AdminModuloDispensario";

import RelatorioDispensario from "./RelatorioDispensario";

import DispensarioConfig from "./DispensarioConfig";

import Social from "./Social";

import PortalSocial from "./PortalSocial";

import CadastroSocial from "./CadastroSocial";

import AgendamentoEntrevistaSocial from "./AgendamentoEntrevistaSocial";

import NovoBeneficiario from "./NovoBeneficiario";

import FinanceiroSocial from "./FinanceiroSocial";

import Tasks from "./Tasks";

import Communications from "./Communications";

import CommunicationSettings from "./CommunicationSettings";

import TasksDashboard from "./TasksDashboard";

import TasksSettings from "./TasksSettings";

import MyTasks from "./MyTasks";

import Onboarding from "./Onboarding";

import OnboardingTutorials from "./OnboardingTutorials";

import OnboardingProgress from "./OnboardingProgress";

import OnboardingTutorialView from "./OnboardingTutorialView";

import OnboardingAdmin from "./OnboardingAdmin";

import OnboardingContent from "./OnboardingContent";

import OnboardingAccess from "./OnboardingAccess";

import OnboardingAnalytics from "./OnboardingAnalytics";

import OnboardingSettings from "./OnboardingSettings";

import AISettings from "./AISettings";

import AIPlans from "./AIPlans";

import CatalogoProdutos from "./CatalogoProdutos";

import CatalogoNovoProduto from "./CatalogoNovoProduto";

import CatalogoDetalhesProduto from "./CatalogoDetalhesProduto";

import ProducaoAlmoxarifadoMP from "./ProducaoAlmoxarifadoMP";

import ProducaoAlmoxarifadoPA from "./ProducaoAlmoxarifadoPA";

import ProducaoMovimentacoes from "./ProducaoMovimentacoes";

import ProducaoDescartes from "./ProducaoDescartes";

import ProducaoRastreabilidade from "./ProducaoRastreabilidade";

import EstoqueAtivos from "./EstoqueAtivos";

import EstoqueExcipientes from "./EstoqueExcipientes";

import EstoqueEmbalagens from "./EstoqueEmbalagens";

import EstoqueRotulos from "./EstoqueRotulos";

import EstoqueProdutoAcabado from "./EstoqueProdutoAcabado";

import NovaMovimentacaoEstoque from "./NovaMovimentacaoEstoque";

import ProducaoOnboarding from "./ProducaoOnboarding";

import ProducaoProcesso from "./ProducaoProcesso";

import ProducaoDiluicao from "./ProducaoDiluicao";

import ProducaoEnvasamento from "./ProducaoEnvasamento";

import ProducaoEmbalagem from "./ProducaoEmbalagem";

import ProducaoExtracao from "./ProducaoExtracao";

import UserPermissions from "./UserPermissions";

import OrgEstrutura from "./OrgEstrutura";

import PesquisaDashboard from "./PesquisaDashboard";

import CatalogoPesquisas from "./CatalogoPesquisas";

import BancoPacientes from "./BancoPacientes";

import DoencasCondicoes from "./DoencasCondicoes";

import EstatisticasPesquisa from "./EstatisticasPesquisa";

import GruposPesquisa from "./GruposPesquisa";

import Protocolos from "./Protocolos";

import Colaboracoes from "./Colaboracoes";

import NovaPesquisa from "./NovaPesquisa";

import NovoGrupoPesquisa from "./NovoGrupoPesquisa";

import EditarGrupoPesquisa from "./EditarGrupoPesquisa";

import MembroGrupoPesquisa from "./MembroGrupoPesquisa";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Organizations: Organizations,
    
    Requests: Requests,
    
    Analytics: Analytics,
    
    Activities: Activities,
    
    Backups: Backups,
    
    Emergencies: Emergencies,
    
    Plans: Plans,
    
    Financial: Financial,
    
    EmailTemplates: EmailTemplates,
    
    Admins: Admins,
    
    Settings: Settings,
    
    Request: Request,
    
    NewOrganization: NewOrganization,
    
    UserManagement: UserManagement,
    
    Reports: Reports,
    
    AuditLogs: AuditLogs,
    
    HelpCenter: HelpCenter,
    
    Notifications: Notifications,
    
    OrgDashboard: OrgDashboard,
    
    PatientPortal: PatientPortal,
    
    Landing: Landing,
    
    Index: Index,
    
    RegisterPage: RegisterPage,
    
    ForgotPassword: ForgotPassword,
    
    Access: Access,
    
    RecoverPassword: RecoverPassword,
    
    LegalDocuments: LegalDocuments,
    
    Newsletter: Newsletter,
    
    CultivoDashboard: CultivoDashboard,
    
    CultivoLotes: CultivoLotes,
    
    CultivoNovoLote: CultivoNovoLote,
    
    CultivoEstoque: CultivoEstoque,
    
    CultivoTransferencias: CultivoTransferencias,
    
    CultivoStrains: CultivoStrains,
    
    ModulosDashboard: ModulosDashboard,
    
    ProducaoDashboard: ProducaoDashboard,
    
    CultivoPlantas: CultivoPlantas,
    
    CrmDashboard: CrmDashboard,
    
    RhDashboard: RhDashboard,
    
    PatrimonioDashboard: PatrimonioDashboard,
    
    AssociacaoTransparencia: AssociacaoTransparencia,
    
    TransparencySettings: TransparencySettings,
    
    ModuleManagement: ModuleManagement,
    
    DocumentManagement: DocumentManagement,
    
    TransparencyDocuments: TransparencyDocuments,
    
    TransparencyMembers: TransparencyMembers,
    
    TransparencyFinancial: TransparencyFinancial,
    
    UserProfile: UserProfile,
    
    ModuloCultivo: ModuloCultivo,
    
    ModuloProducao: ModuloProducao,
    
    ModuloCRM: ModuloCRM,
    
    ModuloRH: ModuloRH,
    
    ModuloVendas: ModuloVendas,
    
    VendasDashboard: VendasDashboard,
    
    Pedidos: Pedidos,
    
    Produtos: Produtos,
    
    Etiquetas: Etiquetas,
    
    Rastreamento: Rastreamento,
    
    Associados: Associados,
    
    Anuidades: Anuidades,
    
    NovoAssociado: NovoAssociado,
    
    Clientes: Clientes,
    
    layout: layout,
    
    AutorizacoesAnvisa: AutorizacoesAnvisa,
    
    JuridicoDashboard: JuridicoDashboard,
    
    JuridicoAcoes: JuridicoAcoes,
    
    ModuloJuridico: ModuloJuridico,
    
    Organization: Organization,
    
    Billing: Billing,
    
    ProducaoQualidade: ProducaoQualidade,
    
    ProducaoQualidadeNovaAnalise: ProducaoQualidadeNovaAnalise,
    
    ProducaoGarantiaQualidade: ProducaoGarantiaQualidade,
    
    ProducaoGarantiaLiberacao: ProducaoGarantiaLiberacao,
    
    CultivoTestes: CultivoTestes,
    
    CultivoNovoTeste: CultivoNovoTeste,
    
    ProducaoMateriasPrimas: ProducaoMateriasPrimas,
    
    ProducaoNovaMateriaPrima: ProducaoNovaMateriaPrima,
    
    ProducaoNovoLoteMaterial: ProducaoNovoLoteMaterial,
    
    ProducaoFornecedores: ProducaoFornecedores,
    
    ProducaoNovoFornecedor: ProducaoNovoFornecedor,
    
    ProducaoOrdens: ProducaoOrdens,
    
    ProducaoNovaOrdem: ProducaoNovaOrdem,
    
    CrmPacientes: CrmPacientes,
    
    PrescricoesClientes: PrescricoesClientes,
    
    NovaPrescricao: NovaPrescricao,
    
    CrmPacienteCadastro: CrmPacienteCadastro,
    
    CrmPrescricoes: CrmPrescricoes,
    
    CrmAtendimento: CrmAtendimento,
    
    CrmCampanhas: CrmCampanhas,
    
    TransparencyCertifications: TransparencyCertifications,
    
    RhRecrutamento: RhRecrutamento,
    
    RhColaboradores: RhColaboradores,
    
    RhDocumentos: RhDocumentos,
    
    RhEscalas: RhEscalas,
    
    CultivoRelatorios: CultivoRelatorios,
    
    JuridicoDocumentos: JuridicoDocumentos,
    
    JuridicoCompliance: JuridicoCompliance,
    
    DetalhePedido: DetalhePedido,
    
    Patients: Patients,
    
    DocumentosAssociados: DocumentosAssociados,
    
    PrescricoesAssociados: PrescricoesAssociados,
    
    ComprasDashboard: ComprasDashboard,
    
    SolicitacoesCompra: SolicitacoesCompra,
    
    NovaSolicitacaoCompra: NovaSolicitacaoCompra,
    
    ModuloCompras: ModuloCompras,
    
    Estoque: Estoque,
    
    PedidosCompra: PedidosCompra,
    
    NovoPedido: NovoPedido,
    
    ProducaoDistribuicao: ProducaoDistribuicao,
    
    NovoProduto: NovoProduto,
    
    ModuloLaboratorio: ModuloLaboratorio,
    
    ProducaoAuditTrail: ProducaoAuditTrail,
    
    ProducaoAjuda: ProducaoAjuda,
    
    CrmSac: CrmSac,
    
    CrmFarmacovigilancia: CrmFarmacovigilancia,
    
    CrmRecolhimento: CrmRecolhimento,
    
    CultivoNovaTransferencia: CultivoNovaTransferencia,
    
    EditarPedido: EditarPedido,
    
    ExpedicaoDashboard: ExpedicaoDashboard,
    
    ExpedicaoJuncaoPedidos: ExpedicaoJuncaoPedidos,
    
    ExpedicaoMalotes: ExpedicaoMalotes,
    
    ExpedicaoPreparacao: ExpedicaoPreparacao,
    
    OrgUsuarios: OrgUsuarios,
    
    ExpedicaoEstoque: ExpedicaoEstoque,
    
    ExpedicaoRastreios: ExpedicaoRastreios,
    
    ExpedicaoCodigosBarras: ExpedicaoCodigosBarras,
    
    Promocoes: Promocoes,
    
    CrmNovaCampanha: CrmNovaCampanha,
    
    OrgConfiguracoes: OrgConfiguracoes,
    
    AssistenciaSocial: AssistenciaSocial,
    
    Menu: Menu,
    
    FinanceiroAssociacao: FinanceiroAssociacao,
    
    ContasPagar: ContasPagar,
    
    NovoLancamento: NovoLancamento,
    
    FinanceiroDashboard: FinanceiroDashboard,
    
    FluxoCaixa: FluxoCaixa,
    
    AnaliseFinanceiraIA: AnaliseFinanceiraIA,
    
    CalendarioFinanceiro: CalendarioFinanceiro,
    
    ConciliacaoBancaria: ConciliacaoBancaria,
    
    EventManagement: EventManagement,
    
    OrcamentoAnual: OrcamentoAnual,
    
    ConfiguracoesFinanceiro: ConfiguracoesFinanceiro,
    
    ComplyPay: ComplyPay,
    
    ComplyPayInvoices: ComplyPayInvoices,
    
    ComplyPayTransactions: ComplyPayTransactions,
    
    ComplyPaySubscriptions: ComplyPaySubscriptions,
    
    ComplyPaySettings: ComplyPaySettings,
    
    ComplyPayIntegrations: ComplyPayIntegrations,
    
    GestaoContas: GestaoContas,
    
    ModuloComunicacao: ModuloComunicacao,
    
    CalendarioComunicacao: CalendarioComunicacao,
    
    CampanhasEmail: CampanhasEmail,
    
    ControleMedico: ControleMedico,
    
    ListaMedicos: ListaMedicos,
    
    CadastroMedico: CadastroMedico,
    
    ConsultasMedicas: ConsultasMedicas,
    
    FinanceiroMedico: FinanceiroMedico,
    
    TelemedicinaPaciente: TelemedicinaPaciente,
    
    TelemedicinaMedico: TelemedicinaMedico,
    
    ConsultaVirtual: ConsultaVirtual,
    
    SymptomChecker: SymptomChecker,
    
    BibliotecaEducativa: BibliotecaEducativa,
    
    FeedbackConsulta: FeedbackConsulta,
    
    FeedbackAnalytics: FeedbackAnalytics,
    
    MedicationReminders: MedicationReminders,
    
    NovoConteudo: NovoConteudo,
    
    NotificacoesComunicacao: NotificacoesComunicacao,
    
    AprovacoesPrescriscoes: AprovacoesPrescriscoes,
    
    UploadPrescritionPage: UploadPrescritionPage,
    
    UploadPrescricaoPage: UploadPrescricaoPage,
    
    StatusPrescricao: StatusPrescricao,
    
    NotificationPreferencesPage: NotificationPreferencesPage,
    
    CredenciaisServicos: CredenciaisServicos,
    
    PatientDashboard: PatientDashboard,
    
    ArquivosComunicacao: ArquivosComunicacao,
    
    Representantes: Representantes,
    
    Comissoes: Comissoes,
    
    ComissoesMedicas: ComissoesMedicas,
    
    NovoRepresentante: NovoRepresentante,
    
    DoctorPortal: DoctorPortal,
    
    PatientPortalPWAConfig: PatientPortalPWAConfig,
    
    DoctorDashboard: DoctorDashboard,
    
    DoctorPatients: DoctorPatients,
    
    DoctorPrescriptions: DoctorPrescriptions,
    
    DoctorSettings: DoctorSettings,
    
    DoctorFinancial: DoctorFinancial,
    
    DoctorAppointments: DoctorAppointments,
    
    ModuloDispensario: ModuloDispensario,
    
    PDV: PDV,
    
    DispensarioAssinatura: DispensarioAssinatura,
    
    DispensarioDashboard: DispensarioDashboard,
    
    EstoqueDispensario: EstoqueDispensario,
    
    DispensarioCaixa: DispensarioCaixa,
    
    GerenciarReceituario: GerenciarReceituario,
    
    RelatorioSNGPC: RelatorioSNGPC,
    
    AdminModuloDispensario: AdminModuloDispensario,
    
    RelatorioDispensario: RelatorioDispensario,
    
    DispensarioConfig: DispensarioConfig,
    
    Social: Social,
    
    PortalSocial: PortalSocial,
    
    CadastroSocial: CadastroSocial,
    
    AgendamentoEntrevistaSocial: AgendamentoEntrevistaSocial,
    
    NovoBeneficiario: NovoBeneficiario,
    
    FinanceiroSocial: FinanceiroSocial,
    
    Tasks: Tasks,
    
    Communications: Communications,
    
    CommunicationSettings: CommunicationSettings,
    
    TasksDashboard: TasksDashboard,
    
    TasksSettings: TasksSettings,
    
    MyTasks: MyTasks,
    
    Onboarding: Onboarding,
    
    OnboardingTutorials: OnboardingTutorials,
    
    OnboardingProgress: OnboardingProgress,
    
    OnboardingTutorialView: OnboardingTutorialView,
    
    OnboardingAdmin: OnboardingAdmin,
    
    OnboardingContent: OnboardingContent,
    
    OnboardingAccess: OnboardingAccess,
    
    OnboardingAnalytics: OnboardingAnalytics,
    
    OnboardingSettings: OnboardingSettings,
    
    AISettings: AISettings,
    
    AIPlans: AIPlans,
    
    CatalogoProdutos: CatalogoProdutos,
    
    CatalogoNovoProduto: CatalogoNovoProduto,
    
    CatalogoDetalhesProduto: CatalogoDetalhesProduto,
    
    ProducaoAlmoxarifadoMP: ProducaoAlmoxarifadoMP,
    
    ProducaoAlmoxarifadoPA: ProducaoAlmoxarifadoPA,
    
    ProducaoMovimentacoes: ProducaoMovimentacoes,
    
    ProducaoDescartes: ProducaoDescartes,
    
    ProducaoRastreabilidade: ProducaoRastreabilidade,
    
    EstoqueAtivos: EstoqueAtivos,
    
    EstoqueExcipientes: EstoqueExcipientes,
    
    EstoqueEmbalagens: EstoqueEmbalagens,
    
    EstoqueRotulos: EstoqueRotulos,
    
    EstoqueProdutoAcabado: EstoqueProdutoAcabado,
    
    NovaMovimentacaoEstoque: NovaMovimentacaoEstoque,
    
    ProducaoOnboarding: ProducaoOnboarding,
    
    ProducaoProcesso: ProducaoProcesso,
    
    ProducaoDiluicao: ProducaoDiluicao,
    
    ProducaoEnvasamento: ProducaoEnvasamento,
    
    ProducaoEmbalagem: ProducaoEmbalagem,
    
    ProducaoExtracao: ProducaoExtracao,
    
    UserPermissions: UserPermissions,
    
    OrgEstrutura: OrgEstrutura,
    
    PesquisaDashboard: PesquisaDashboard,
    
    CatalogoPesquisas: CatalogoPesquisas,
    
    BancoPacientes: BancoPacientes,
    
    DoencasCondicoes: DoencasCondicoes,
    
    EstatisticasPesquisa: EstatisticasPesquisa,
    
    GruposPesquisa: GruposPesquisa,
    
    Protocolos: Protocolos,
    
    Colaboracoes: Colaboracoes,
    
    NovaPesquisa: NovaPesquisa,
    
    NovoGrupoPesquisa: NovoGrupoPesquisa,
    
    EditarGrupoPesquisa: EditarGrupoPesquisa,
    
    MembroGrupoPesquisa: MembroGrupoPesquisa,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Organizations" element={<Organizations />} />
                
                <Route path="/Requests" element={<Requests />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/Activities" element={<Activities />} />
                
                <Route path="/Backups" element={<Backups />} />
                
                <Route path="/Emergencies" element={<Emergencies />} />
                
                <Route path="/Plans" element={<Plans />} />
                
                <Route path="/Financial" element={<Financial />} />
                
                <Route path="/EmailTemplates" element={<EmailTemplates />} />
                
                <Route path="/Admins" element={<Admins />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Request" element={<Request />} />
                
                <Route path="/NewOrganization" element={<NewOrganization />} />
                
                <Route path="/UserManagement" element={<UserManagement />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/AuditLogs" element={<AuditLogs />} />
                
                <Route path="/HelpCenter" element={<HelpCenter />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/OrgDashboard" element={<OrgDashboard />} />
                
                <Route path="/PatientPortal" element={<PatientPortal />} />
                
                <Route path="/Landing" element={<Landing />} />
                
                <Route path="/Index" element={<Index />} />
                
                <Route path="/RegisterPage" element={<RegisterPage />} />
                
                <Route path="/ForgotPassword" element={<ForgotPassword />} />
                
                <Route path="/Access" element={<Access />} />
                
                <Route path="/RecoverPassword" element={<RecoverPassword />} />
                
                <Route path="/LegalDocuments" element={<LegalDocuments />} />
                
                <Route path="/Newsletter" element={<Newsletter />} />
                
                <Route path="/CultivoDashboard" element={<CultivoDashboard />} />
                
                <Route path="/CultivoLotes" element={<CultivoLotes />} />
                
                <Route path="/CultivoNovoLote" element={<CultivoNovoLote />} />
                
                <Route path="/CultivoEstoque" element={<CultivoEstoque />} />
                
                <Route path="/CultivoTransferencias" element={<CultivoTransferencias />} />
                
                <Route path="/CultivoStrains" element={<CultivoStrains />} />
                
                <Route path="/ModulosDashboard" element={<ModulosDashboard />} />
                
                <Route path="/ProducaoDashboard" element={<ProducaoDashboard />} />
                
                <Route path="/CultivoPlantas" element={<CultivoPlantas />} />
                
                <Route path="/CrmDashboard" element={<CrmDashboard />} />
                
                <Route path="/RhDashboard" element={<RhDashboard />} />
                
                <Route path="/PatrimonioDashboard" element={<PatrimonioDashboard />} />
                
                <Route path="/AssociacaoTransparencia" element={<AssociacaoTransparencia />} />
                
                <Route path="/TransparencySettings" element={<TransparencySettings />} />
                
                <Route path="/ModuleManagement" element={<ModuleManagement />} />
                
                <Route path="/DocumentManagement" element={<DocumentManagement />} />
                
                <Route path="/TransparencyDocuments" element={<TransparencyDocuments />} />
                
                <Route path="/TransparencyMembers" element={<TransparencyMembers />} />
                
                <Route path="/TransparencyFinancial" element={<TransparencyFinancial />} />
                
                <Route path="/UserProfile" element={<UserProfile />} />
                
                <Route path="/ModuloCultivo" element={<ModuloCultivo />} />
                
                <Route path="/ModuloProducao" element={<ModuloProducao />} />
                
                <Route path="/ModuloCRM" element={<ModuloCRM />} />
                
                <Route path="/ModuloRH" element={<ModuloRH />} />
                
                <Route path="/ModuloVendas" element={<ModuloVendas />} />
                
                <Route path="/VendasDashboard" element={<VendasDashboard />} />
                
                <Route path="/Pedidos" element={<Pedidos />} />
                
                <Route path="/Produtos" element={<Produtos />} />
                
                <Route path="/Etiquetas" element={<Etiquetas />} />
                
                <Route path="/Rastreamento" element={<Rastreamento />} />
                
                <Route path="/Associados" element={<Associados />} />
                
                <Route path="/Anuidades" element={<Anuidades />} />
                
                <Route path="/NovoAssociado" element={<NovoAssociado />} />
                
                <Route path="/Clientes" element={<Clientes />} />
                
                <Route path="/layout" element={<layout />} />
                
                <Route path="/AutorizacoesAnvisa" element={<AutorizacoesAnvisa />} />
                
                <Route path="/JuridicoDashboard" element={<JuridicoDashboard />} />
                
                <Route path="/JuridicoAcoes" element={<JuridicoAcoes />} />
                
                <Route path="/ModuloJuridico" element={<ModuloJuridico />} />
                
                <Route path="/Organization" element={<Organization />} />
                
                <Route path="/Billing" element={<Billing />} />
                
                <Route path="/ProducaoQualidade" element={<ProducaoQualidade />} />
                
                <Route path="/ProducaoQualidadeNovaAnalise" element={<ProducaoQualidadeNovaAnalise />} />
                
                <Route path="/ProducaoGarantiaQualidade" element={<ProducaoGarantiaQualidade />} />
                
                <Route path="/ProducaoGarantiaLiberacao" element={<ProducaoGarantiaLiberacao />} />
                
                <Route path="/CultivoTestes" element={<CultivoTestes />} />
                
                <Route path="/CultivoNovoTeste" element={<CultivoNovoTeste />} />
                
                <Route path="/ProducaoMateriasPrimas" element={<ProducaoMateriasPrimas />} />
                
                <Route path="/ProducaoNovaMateriaPrima" element={<ProducaoNovaMateriaPrima />} />
                
                <Route path="/ProducaoNovoLoteMaterial" element={<ProducaoNovoLoteMaterial />} />
                
                <Route path="/ProducaoFornecedores" element={<ProducaoFornecedores />} />
                
                <Route path="/ProducaoNovoFornecedor" element={<ProducaoNovoFornecedor />} />
                
                <Route path="/ProducaoOrdens" element={<ProducaoOrdens />} />
                
                <Route path="/ProducaoNovaOrdem" element={<ProducaoNovaOrdem />} />
                
                <Route path="/CrmPacientes" element={<CrmPacientes />} />
                
                <Route path="/PrescricoesClientes" element={<PrescricoesClientes />} />
                
                <Route path="/NovaPrescricao" element={<NovaPrescricao />} />
                
                <Route path="/CrmPacienteCadastro" element={<CrmPacienteCadastro />} />
                
                <Route path="/CrmPrescricoes" element={<CrmPrescricoes />} />
                
                <Route path="/CrmAtendimento" element={<CrmAtendimento />} />
                
                <Route path="/CrmCampanhas" element={<CrmCampanhas />} />
                
                <Route path="/TransparencyCertifications" element={<TransparencyCertifications />} />
                
                <Route path="/RhRecrutamento" element={<RhRecrutamento />} />
                
                <Route path="/RhColaboradores" element={<RhColaboradores />} />
                
                <Route path="/RhDocumentos" element={<RhDocumentos />} />
                
                <Route path="/RhEscalas" element={<RhEscalas />} />
                
                <Route path="/CultivoRelatorios" element={<CultivoRelatorios />} />
                
                <Route path="/JuridicoDocumentos" element={<JuridicoDocumentos />} />
                
                <Route path="/JuridicoCompliance" element={<JuridicoCompliance />} />
                
                <Route path="/DetalhePedido" element={<DetalhePedido />} />
                
                <Route path="/Patients" element={<Patients />} />
                
                <Route path="/DocumentosAssociados" element={<DocumentosAssociados />} />
                
                <Route path="/PrescricoesAssociados" element={<PrescricoesAssociados />} />
                
                <Route path="/ComprasDashboard" element={<ComprasDashboard />} />
                
                <Route path="/SolicitacoesCompra" element={<SolicitacoesCompra />} />
                
                <Route path="/NovaSolicitacaoCompra" element={<NovaSolicitacaoCompra />} />
                
                <Route path="/ModuloCompras" element={<ModuloCompras />} />
                
                <Route path="/Estoque" element={<Estoque />} />
                
                <Route path="/PedidosCompra" element={<PedidosCompra />} />
                
                <Route path="/NovoPedido" element={<NovoPedido />} />
                
                <Route path="/ProducaoDistribuicao" element={<ProducaoDistribuicao />} />
                
                <Route path="/NovoProduto" element={<NovoProduto />} />
                
                <Route path="/ModuloLaboratorio" element={<ModuloLaboratorio />} />
                
                <Route path="/ProducaoAuditTrail" element={<ProducaoAuditTrail />} />
                
                <Route path="/ProducaoAjuda" element={<ProducaoAjuda />} />
                
                <Route path="/CrmSac" element={<CrmSac />} />
                
                <Route path="/CrmFarmacovigilancia" element={<CrmFarmacovigilancia />} />
                
                <Route path="/CrmRecolhimento" element={<CrmRecolhimento />} />
                
                <Route path="/CultivoNovaTransferencia" element={<CultivoNovaTransferencia />} />
                
                <Route path="/EditarPedido" element={<EditarPedido />} />
                
                <Route path="/ExpedicaoDashboard" element={<ExpedicaoDashboard />} />
                
                <Route path="/ExpedicaoJuncaoPedidos" element={<ExpedicaoJuncaoPedidos />} />
                
                <Route path="/ExpedicaoMalotes" element={<ExpedicaoMalotes />} />
                
                <Route path="/ExpedicaoPreparacao" element={<ExpedicaoPreparacao />} />
                
                <Route path="/OrgUsuarios" element={<OrgUsuarios />} />
                
                <Route path="/ExpedicaoEstoque" element={<ExpedicaoEstoque />} />
                
                <Route path="/ExpedicaoRastreios" element={<ExpedicaoRastreios />} />
                
                <Route path="/ExpedicaoCodigosBarras" element={<ExpedicaoCodigosBarras />} />
                
                <Route path="/Promocoes" element={<Promocoes />} />
                
                <Route path="/CrmNovaCampanha" element={<CrmNovaCampanha />} />
                
                <Route path="/OrgConfiguracoes" element={<OrgConfiguracoes />} />
                
                <Route path="/AssistenciaSocial" element={<AssistenciaSocial />} />
                
                <Route path="/Menu" element={<Menu />} />
                
                <Route path="/FinanceiroAssociacao" element={<FinanceiroAssociacao />} />
                
                <Route path="/ContasPagar" element={<ContasPagar />} />
                
                <Route path="/NovoLancamento" element={<NovoLancamento />} />
                
                <Route path="/FinanceiroDashboard" element={<FinanceiroDashboard />} />
                
                <Route path="/FluxoCaixa" element={<FluxoCaixa />} />
                
                <Route path="/AnaliseFinanceiraIA" element={<AnaliseFinanceiraIA />} />
                
                <Route path="/CalendarioFinanceiro" element={<CalendarioFinanceiro />} />
                
                <Route path="/ConciliacaoBancaria" element={<ConciliacaoBancaria />} />
                
                <Route path="/EventManagement" element={<EventManagement />} />
                
                <Route path="/OrcamentoAnual" element={<OrcamentoAnual />} />
                
                <Route path="/ConfiguracoesFinanceiro" element={<ConfiguracoesFinanceiro />} />
                
                <Route path="/ComplyPay" element={<ComplyPay />} />
                
                <Route path="/ComplyPayInvoices" element={<ComplyPayInvoices />} />
                
                <Route path="/ComplyPayTransactions" element={<ComplyPayTransactions />} />
                
                <Route path="/ComplyPaySubscriptions" element={<ComplyPaySubscriptions />} />
                
                <Route path="/ComplyPaySettings" element={<ComplyPaySettings />} />
                
                <Route path="/ComplyPayIntegrations" element={<ComplyPayIntegrations />} />
                
                <Route path="/GestaoContas" element={<GestaoContas />} />
                
                <Route path="/ModuloComunicacao" element={<ModuloComunicacao />} />
                
                <Route path="/CalendarioComunicacao" element={<CalendarioComunicacao />} />
                
                <Route path="/CampanhasEmail" element={<CampanhasEmail />} />
                
                <Route path="/ControleMedico" element={<ControleMedico />} />
                
                <Route path="/ListaMedicos" element={<ListaMedicos />} />
                
                <Route path="/CadastroMedico" element={<CadastroMedico />} />
                
                <Route path="/ConsultasMedicas" element={<ConsultasMedicas />} />
                
                <Route path="/FinanceiroMedico" element={<FinanceiroMedico />} />
                
                <Route path="/TelemedicinaPaciente" element={<TelemedicinaPaciente />} />
                
                <Route path="/TelemedicinaMedico" element={<TelemedicinaMedico />} />
                
                <Route path="/ConsultaVirtual" element={<ConsultaVirtual />} />
                
                <Route path="/SymptomChecker" element={<SymptomChecker />} />
                
                <Route path="/BibliotecaEducativa" element={<BibliotecaEducativa />} />
                
                <Route path="/FeedbackConsulta" element={<FeedbackConsulta />} />
                
                <Route path="/FeedbackAnalytics" element={<FeedbackAnalytics />} />
                
                <Route path="/MedicationReminders" element={<MedicationReminders />} />
                
                <Route path="/NovoConteudo" element={<NovoConteudo />} />
                
                <Route path="/NotificacoesComunicacao" element={<NotificacoesComunicacao />} />
                
                <Route path="/AprovacoesPrescriscoes" element={<AprovacoesPrescriscoes />} />
                
                <Route path="/UploadPrescritionPage" element={<UploadPrescritionPage />} />
                
                <Route path="/UploadPrescricaoPage" element={<UploadPrescricaoPage />} />
                
                <Route path="/StatusPrescricao" element={<StatusPrescricao />} />
                
                <Route path="/NotificationPreferencesPage" element={<NotificationPreferencesPage />} />
                
                <Route path="/CredenciaisServicos" element={<CredenciaisServicos />} />
                
                <Route path="/PatientDashboard" element={<PatientDashboard />} />
                
                <Route path="/ArquivosComunicacao" element={<ArquivosComunicacao />} />
                
                <Route path="/Representantes" element={<Representantes />} />
                
                <Route path="/Comissoes" element={<Comissoes />} />
                
                <Route path="/ComissoesMedicas" element={<ComissoesMedicas />} />
                
                <Route path="/NovoRepresentante" element={<NovoRepresentante />} />
                
                <Route path="/DoctorPortal" element={<DoctorPortal />} />
                
                <Route path="/PatientPortalPWAConfig" element={<PatientPortalPWAConfig />} />
                
                <Route path="/DoctorDashboard" element={<DoctorDashboard />} />
                
                <Route path="/DoctorPatients" element={<DoctorPatients />} />
                
                <Route path="/DoctorPrescriptions" element={<DoctorPrescriptions />} />
                
                <Route path="/DoctorSettings" element={<DoctorSettings />} />
                
                <Route path="/DoctorFinancial" element={<DoctorFinancial />} />
                
                <Route path="/DoctorAppointments" element={<DoctorAppointments />} />
                
                <Route path="/ModuloDispensario" element={<ModuloDispensario />} />
                
                <Route path="/PDV" element={<PDV />} />
                
                <Route path="/DispensarioAssinatura" element={<DispensarioAssinatura />} />
                
                <Route path="/DispensarioDashboard" element={<DispensarioDashboard />} />
                
                <Route path="/EstoqueDispensario" element={<EstoqueDispensario />} />
                
                <Route path="/DispensarioCaixa" element={<DispensarioCaixa />} />
                
                <Route path="/GerenciarReceituario" element={<GerenciarReceituario />} />
                
                <Route path="/RelatorioSNGPC" element={<RelatorioSNGPC />} />
                
                <Route path="/AdminModuloDispensario" element={<AdminModuloDispensario />} />
                
                <Route path="/RelatorioDispensario" element={<RelatorioDispensario />} />
                
                <Route path="/DispensarioConfig" element={<DispensarioConfig />} />
                
                <Route path="/Social" element={<Social />} />
                
                <Route path="/PortalSocial" element={<PortalSocial />} />
                
                <Route path="/CadastroSocial" element={<CadastroSocial />} />
                
                <Route path="/AgendamentoEntrevistaSocial" element={<AgendamentoEntrevistaSocial />} />
                
                <Route path="/NovoBeneficiario" element={<NovoBeneficiario />} />
                
                <Route path="/FinanceiroSocial" element={<FinanceiroSocial />} />
                
                <Route path="/Tasks" element={<Tasks />} />
                
                <Route path="/Communications" element={<Communications />} />
                
                <Route path="/CommunicationSettings" element={<CommunicationSettings />} />
                
                <Route path="/TasksDashboard" element={<TasksDashboard />} />
                
                <Route path="/TasksSettings" element={<TasksSettings />} />
                
                <Route path="/MyTasks" element={<MyTasks />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/OnboardingTutorials" element={<OnboardingTutorials />} />
                
                <Route path="/OnboardingProgress" element={<OnboardingProgress />} />
                
                <Route path="/OnboardingTutorialView" element={<OnboardingTutorialView />} />
                
                <Route path="/OnboardingAdmin" element={<OnboardingAdmin />} />
                
                <Route path="/OnboardingContent" element={<OnboardingContent />} />
                
                <Route path="/OnboardingAccess" element={<OnboardingAccess />} />
                
                <Route path="/OnboardingAnalytics" element={<OnboardingAnalytics />} />
                
                <Route path="/OnboardingSettings" element={<OnboardingSettings />} />
                
                <Route path="/AISettings" element={<AISettings />} />
                
                <Route path="/AIPlans" element={<AIPlans />} />
                
                <Route path="/CatalogoProdutos" element={<CatalogoProdutos />} />
                
                <Route path="/CatalogoNovoProduto" element={<CatalogoNovoProduto />} />
                
                <Route path="/CatalogoDetalhesProduto" element={<CatalogoDetalhesProduto />} />
                
                <Route path="/ProducaoAlmoxarifadoMP" element={<ProducaoAlmoxarifadoMP />} />
                
                <Route path="/ProducaoAlmoxarifadoPA" element={<ProducaoAlmoxarifadoPA />} />
                
                <Route path="/ProducaoMovimentacoes" element={<ProducaoMovimentacoes />} />
                
                <Route path="/ProducaoDescartes" element={<ProducaoDescartes />} />
                
                <Route path="/ProducaoRastreabilidade" element={<ProducaoRastreabilidade />} />
                
                <Route path="/EstoqueAtivos" element={<EstoqueAtivos />} />
                
                <Route path="/EstoqueExcipientes" element={<EstoqueExcipientes />} />
                
                <Route path="/EstoqueEmbalagens" element={<EstoqueEmbalagens />} />
                
                <Route path="/EstoqueRotulos" element={<EstoqueRotulos />} />
                
                <Route path="/EstoqueProdutoAcabado" element={<EstoqueProdutoAcabado />} />
                
                <Route path="/NovaMovimentacaoEstoque" element={<NovaMovimentacaoEstoque />} />
                
                <Route path="/ProducaoOnboarding" element={<ProducaoOnboarding />} />
                
                <Route path="/ProducaoProcesso" element={<ProducaoProcesso />} />
                
                <Route path="/ProducaoDiluicao" element={<ProducaoDiluicao />} />
                
                <Route path="/ProducaoEnvasamento" element={<ProducaoEnvasamento />} />
                
                <Route path="/ProducaoEmbalagem" element={<ProducaoEmbalagem />} />
                
                <Route path="/ProducaoExtracao" element={<ProducaoExtracao />} />
                
                <Route path="/UserPermissions" element={<UserPermissions />} />
                
                <Route path="/OrgEstrutura" element={<OrgEstrutura />} />
                
                <Route path="/PesquisaDashboard" element={<PesquisaDashboard />} />
                
                <Route path="/CatalogoPesquisas" element={<CatalogoPesquisas />} />
                
                <Route path="/BancoPacientes" element={<BancoPacientes />} />
                
                <Route path="/DoencasCondicoes" element={<DoencasCondicoes />} />
                
                <Route path="/EstatisticasPesquisa" element={<EstatisticasPesquisa />} />
                
                <Route path="/GruposPesquisa" element={<GruposPesquisa />} />
                
                <Route path="/Protocolos" element={<Protocolos />} />
                
                <Route path="/Colaboracoes" element={<Colaboracoes />} />
                
                <Route path="/NovaPesquisa" element={<NovaPesquisa />} />
                
                <Route path="/NovoGrupoPesquisa" element={<NovoGrupoPesquisa />} />
                
                <Route path="/EditarGrupoPesquisa" element={<EditarGrupoPesquisa />} />
                
                <Route path="/MembroGrupoPesquisa" element={<MembroGrupoPesquisa />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}