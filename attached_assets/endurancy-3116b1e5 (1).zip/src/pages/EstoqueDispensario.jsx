
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { toast } from "@/components/ui/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Package,
  Search,
  PlusCircle,
  Trash2,
  Edit,
  MoreHorizontal,
  ArrowUpRight,
  ArrowDownLeft,
  AlertTriangle,
  FileBarChart,
  FileText,
  Printer,
  BarChart,
  RefreshCw,
  CheckCircle2,
  Clock,
  Info,
  Calendar,
  FilterX,
  Filter
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function EstoqueDispensarioPage() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [produtos, setProdutos] = useState([]);
  const [produtosFiltrados, setProdutosFiltrados] = useState([]);
  const [termoBusca, setTermoBusca] = useState('');
  const [categoriaFiltro, setCategoriaFiltro] = useState('todas');
  const [statusFiltro, setStatusFiltro] = useState('todos');
  const [showNovoProdutoDialog, setShowNovoProdutoDialog] = useState(false);
  const [showMovimentacaoDialog, setShowMovimentacaoDialog] = useState(false);
  const [tipoMovimentacao, setTipoMovimentacao] = useState('entrada');
  const [produtoSelecionado, setProdutoSelecionado] = useState(null);
  const [categoriasDisponiveis, setCategoriasDisponiveis] = useState([]);
  const [novoLoteDialog, setNovoLoteDialog] = useState(false);
  const [novoLoteData, setNovoLoteData] = useState({
    lote: '',
    quantidade: '',
    data_fabricacao: '',
    data_validade: ''
  });
  const [novoProduto, setNovoProduto] = useState({
    codigo: '',
    nome: '',
    descricao: '',
    categoria: '',
    quantidade_atual: 0,
    unidade_medida: 'unidade',
    preco_venda: '',
    preco_custo: '',
    controlado: false,
    tipo_receita: 'nao_aplicavel',
    estoque_minimo: 5,
    estoque_maximo: 100,
    codigo_barras: '',
    codigo_anvisa: '',
    fabricante: ''
  });
  const [movimentacaoData, setMovimentacaoData] = useState({
    produto_id: '',
    quantidade: '',
    lote: '',
    motivo: '',
    observacoes: ''
  });
  const [showDetalhesDialog, setShowDetalhesDialog] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const loadData = () => {
      try {
        const userType = localStorage.getItem('mockUserType');
        if (!userType) {
          console.log("User not authenticated, redirecting to login");
          navigate(createPageUrl("Access"));
          return;
        }

        const mockProdutos = [
          {
            id: '1',
            codigo: 'CBD001',
            nome: 'Canabidiol 100mg/ml',
            quantidade_atual: 15,
            preco_venda: 350.00,
            categoria: 'Medicamentos',
            estoque_minimo: 5,
            estoque_maximo: 100,
            unidade_medida: 'unidade',
            controlado: true,
            tipo_receita: 'especial',
            lotes: [
              { lote: 'L2023001', data_validade: '2024-12-31', quantidade: 8, data_fabricacao: '2023-01-15' },
              { lote: 'L2023018', data_validade: '2024-11-15', quantidade: 7, data_fabricacao: '2023-02-20' }
            ]
          },
          {
            id: '2',
            codigo: 'CBD002',
            nome: 'Canabidiol 200mg/ml',
            quantidade_atual: 8,
            preco_venda: 550.00,
            categoria: 'Medicamentos',
            estoque_minimo: 5,
            estoque_maximo: 100,
            unidade_medida: 'unidade',
            controlado: true,
            tipo_receita: 'especial',
            lotes: [
              { lote: 'L2023047', data_validade: '2024-10-30', quantidade: 8, data_fabricacao: '2023-03-15' }
            ]
          },
          {
            id: '3',
            codigo: 'THC001',
            nome: 'THC/CBD 1:1 30ml',
            quantidade_atual: 5,
            preco_venda: 420.00,
            categoria: 'Medicamentos',
            estoque_minimo: 5,
            estoque_maximo: 100,
            unidade_medida: 'unidade',
            controlado: true,
            tipo_receita: 'especial_retencao',
            lotes: [
              { lote: 'L2023033', data_validade: '2024-08-15', quantidade: 5, data_fabricacao: '2023-02-10' }
            ]
          },
          {
            id: '4',
            codigo: 'CBDCAP001',
            nome: 'Cápsulas Canabidiol 25mg',
            quantidade_atual: 30,
            preco_venda: 180.00,
            categoria: 'Medicamentos',
            estoque_minimo: 20,
            estoque_maximo: 200,
            unidade_medida: 'unidade',
            controlado: true,
            tipo_receita: 'especial',
            lotes: [
              { lote: 'L2023122', data_validade: '2024-09-30', quantidade: 30, data_fabricacao: '2023-04-15' }
            ]
          },
          {
            id: '5',
            codigo: 'TOP001',
            nome: 'Creme Tópico CBD 60g',
            quantidade_atual: 12,
            preco_venda: 120.00,
            categoria: 'Tópicos',
            estoque_minimo: 10,
            estoque_maximo: 50,
            unidade_medida: 'unidade',
            controlado: false,
            tipo_receita: 'simples',
            lotes: [
              { lote: 'L2023091', data_validade: '2024-08-31', quantidade: 12, data_fabricacao: '2023-03-01' }
            ]
          },
          {
            id: '6',
            codigo: 'APET001',
            nome: 'Óleo CBD para Pets 30ml',
            quantidade_atual: 7,
            preco_venda: 150.00,
            categoria: 'Pet',
            estoque_minimo: 8,
            estoque_maximo: 40,
            unidade_medida: 'unidade',
            controlado: false,
            tipo_receita: 'nao_aplicavel',
            lotes: [
              { lote: 'L2023075', data_validade: '2024-07-15', quantidade: 7, data_fabricacao: '2023-02-28' }
            ]
          }
        ];

        const categorias = [...new Set(mockProdutos.map(p => p.categoria))];
        setCategoriasDisponiveis(categorias);

        setProdutos(mockProdutos);
        setProdutosFiltrados(mockProdutos);
        setIsLoading(false);
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar os dados do estoque.",
          variant: "destructive",
        });
      }
    };

    loadData();
  }, [navigate]);

  useEffect(() => {
    let filtered = [...produtos];
    
    if (termoBusca) {
      filtered = filtered.filter(p => 
        p.nome.toLowerCase().includes(termoBusca.toLowerCase()) ||
        p.codigo.toLowerCase().includes(termoBusca.toLowerCase()) ||
        p.codigo_barras?.toLowerCase().includes(termoBusca.toLowerCase()) ||
        p.codigo_anvisa?.toLowerCase().includes(termoBusca.toLowerCase())
      );
    }
    
    if (categoriaFiltro !== 'todas') {
      filtered = filtered.filter(p => p.categoria === categoriaFiltro);
    }
    
    if (statusFiltro === 'critico') {
      filtered = filtered.filter(p => p.quantidade_atual <= p.estoque_minimo);
    } else if (statusFiltro === 'normal') {
      filtered = filtered.filter(p => p.quantidade_atual > p.estoque_minimo && p.quantidade_atual < p.estoque_maximo);
    } else if (statusFiltro === 'excesso') {
      filtered = filtered.filter(p => p.quantidade_atual >= p.estoque_maximo);
    } else if (statusFiltro === 'zerado') {
      filtered = filtered.filter(p => p.quantidade_atual === 0);
    }
    
    setProdutosFiltrados(filtered);
  }, [termoBusca, categoriaFiltro, statusFiltro, produtos]);

  const handleNovoProdutoChange = (field, value) => {
    setNovoProduto(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleNovoLoteChange = (field, value) => {
    setNovoLoteData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleMovimentacaoChange = (field, value) => {
    setMovimentacaoData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSalvarProduto = async () => {
    try {
      setIsProcessing(true);
      
      if (!novoProduto.codigo || !novoProduto.nome || !novoProduto.categoria) {
        toast({
          title: "Dados incompletos",
          description: "Preencha todos os campos obrigatórios.",
          variant: "destructive",
        });
        return;
      }
      
      const produtoData = {
        ...novoProduto,
        organization_id: '',
        preco_venda: parseFloat(novoProduto.preco_venda) || 0,
        preco_custo: parseFloat(novoProduto.preco_custo) || 0,
        quantidade_atual: parseFloat(novoProduto.quantidade_atual) || 0,
        estoque_minimo: parseFloat(novoProduto.estoque_minimo) || 5,
        estoque_maximo: parseFloat(novoProduto.estoque_maximo) || 100,
        lotes: []
      };
      
      const updatedProductsList = [...produtos, produtoData];
      setProdutos(updatedProductsList);
      setProdutosFiltrados(updatedProductsList);
      
      setShowNovoProdutoDialog(false);
      setNovoProduto({
        codigo: '',
        nome: '',
        descricao: '',
        categoria: '',
        quantidade_atual: 0,
        unidade_medida: 'unidade',
        preco_venda: '',
        preco_custo: '',
        controlado: false,
        tipo_receita: 'nao_aplicavel',
        estoque_minimo: 5,
        estoque_maximo: 100,
        codigo_barras: '',
        codigo_anvisa: '',
        fabricante: ''
      });
      
      toast({
        title: "Produto cadastrado",
        description: "Produto adicionado com sucesso ao estoque.",
      });
      
    } catch (error) {
      console.error("Erro ao salvar produto:", error);
      toast({
        title: "Erro",
        description: "Não foi possível salvar o produto.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAdicionarLote = async () => {
    try {
      setIsProcessing(true);
      if (!produtoSelecionado) return;
      
      if (!novoLoteData.lote || !novoLoteData.quantidade || !novoLoteData.data_validade) {
        toast({
          title: "Dados incompletos",
          description: "Preencha todos os campos obrigatórios.",
          variant: "destructive",
        });
        return;
      }

      const lotesAtualizados = [...(produtoSelecionado.lotes || []), { lote: novoLoteData.lote, quantidade: parseFloat(novoLoteData.quantidade), data_fabricacao: novoLoteData.data_fabricacao, data_validade: novoLoteData.data_validade }];
      
      toast({
        title: "Lote adicionado",
        description: "Lote adicionado com sucesso ao produto.",
      });
      
    } catch (error) {
      console.error("Erro ao adicionar lote:", error);
      toast({
        title: "Erro",
        description: "Não foi possível adicionar o lote.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleMovimentacaoEstoque = async () => {
    try {
      setIsProcessing(true);
      if (!produtoSelecionado) return;
      
      if (!movimentacaoData.quantidade || parseFloat(movimentacaoData.quantidade) <= 0) {
        toast({
          title: "Quantidade inválida",
          description: "Informe uma quantidade válida para a movimentação.",
          variant: "destructive",
        });
        return;
      }

      let novaQuantidade = produtoSelecionado.quantidade_atual + parseFloat(movimentacaoData.quantidade);
      
      toast({
        title: "Movimentação registrada",
        description: `Movimentação de estoque registrada com sucesso.`,
      });
      
    } catch (error) {
      console.error(`Erro ao registrar movimentação:`, error);
      toast({
        title: "Erro",
        description: `Não foi possível registrar a movimentação.`,
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExcluirProduto = async () => {
    if (!produtoSelecionado) return;
    
    try {
      setIsProcessing(true);
      const updatedProductsList = produtos.filter(produto => produto.id !== produtoSelecionado.id);
      setProdutos(updatedProductsList);
      setProdutosFiltrados(updatedProductsList);
      
      toast({
        title: "Produto excluído",
        description: "Produto removido com sucesso do estoque.",
      });
      
    } catch (error) {
      console.error("Erro ao excluir produto:", error);
      toast({
        title: "Erro",
        description: "Não foi possível excluir o produto.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const abrirMovimentacao = (produto, tipo) => {
    setProdutoSelecionado(produto);
    setTipoMovimentacao(tipo);
    
    setMovimentacaoData({
      produto_id: produto.id,
      quantidade: '',
      lote: '',
      motivo: '',
      observacoes: ''
    });
    
    setShowMovimentacaoDialog(true);
  };

  const formatMoney = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getStatusColor = (produto) => {
    if (produto.quantidade_atual <= 0) {
      return "destructive";
    } else if (produto.quantidade_atual <= produto.estoque_minimo) {
      return "warning";
    } else if (produto.quantidade_atual >= produto.estoque_maximo) {
      return "info";
    } else {
      return "success";
    }
  };

  const getStatusText = (produto) => {
    if (produto.quantidade_atual <= 0) {
      return "Zerado";
    } else if (produto.quantidade_atual <= produto.estoque_minimo) {
      return "Crítico";
    } else if (produto.quantidade_atual >= produto.estoque_maximo) {
      return "Excesso";
    } else {
      return "Normal";
    }
  };

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Estoque do Dispensário</h1>
          <p className="text-gray-500">Gestão completa do estoque de produtos</p>
        </div>
        <Button onClick={() => setShowNovoProdutoDialog(true)}>
          <PlusCircle className="h-4 w-4 mr-2" />
          Novo Produto
        </Button>
      </div>

      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="flex flex-col space-y-4 md:flex-row md:space-x-4 md:space-y-0">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  className="pl-10"
                  placeholder="Buscar por nome, código, código de barras..."
                  value={termoBusca}
                  onChange={(e) => setTermoBusca(e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex gap-4">
              <Select value={categoriaFiltro} onValueChange={setCategoriaFiltro}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Categoria" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas as Categorias</SelectItem>
                  {categoriasDisponiveis.map((categoria, index) => (
                    <SelectItem key={index} value={categoria}>{categoria}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={statusFiltro} onValueChange={setStatusFiltro}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos os Status</SelectItem>
                  <SelectItem value="critico">Estoque Crítico</SelectItem>
                  <SelectItem value="normal">Estoque Normal</SelectItem>
                  <SelectItem value="excesso">Estoque em Excesso</SelectItem>
                  <SelectItem value="zerado">Estoque Zerado</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" onClick={() => {
                setTermoBusca('');
                setCategoriaFiltro('todas');
                setStatusFiltro('todos');
              }}>
                <FilterX className="h-4 w-4 mr-2" />
                Limpar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="p-6">
          <CardTitle>Produtos em Estoque</CardTitle>
          <CardDescription>
            {produtosFiltrados.length} produtos encontrados
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Código</TableHead>
                <TableHead>Produto</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead>Estoque</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Preço Venda</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-10">
                    <div className="flex items-center justify-center">
                      <RefreshCw className="h-6 w-6 animate-spin text-gray-400 mr-2" />
                      <span>Carregando produtos...</span>
                    </div>
                  </TableCell>
                </TableRow>
              ) : produtosFiltrados.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-10">
                    <div className="flex flex-col items-center justify-center">
                      <Package className="h-12 w-12 text-gray-400 mb-2" />
                      <p className="text-gray-500">Nenhum produto encontrado</p>
                      <Button 
                        variant="link" 
                        onClick={() => {
                          setTermoBusca('');
                          setCategoriaFiltro('todas');
                          setStatusFiltro('todos');
                        }}
                      >
                        Limpar filtros
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                produtosFiltrados.map((produto) => (
                  <TableRow key={produto.id} className="cursor-pointer hover:bg-gray-50" onClick={() => {
                    setProdutoSelecionado(produto);
                    setShowDetalhesDialog(true);
                  }}>
                    <TableCell className="font-medium">{produto.codigo}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span>{produto.nome}</span>
                        {produto.controlado && (
                          <Badge variant="outline" className="mt-1 w-fit">
                            Controlado
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{produto.categoria}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span>{produto.quantidade_atual} {produto.unidade_medida}</span>
                        <span className="text-xs text-gray-500">
                          Mín: {produto.estoque_minimo} / Máx: {produto.estoque_maximo}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(produto)}>
                        {getStatusText(produto)}
                      </Badge>
                    </TableCell>
                    <TableCell>{formatMoney(produto.preco_venda)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Opções</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={(e) => {
                            e.stopPropagation();
                            abrirMovimentacao(produto, 'entrada');
                          }}>
                            <ArrowDownLeft className="h-4 w-4 mr-2" />
                            Registrar Entrada
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={(e) => {
                            e.stopPropagation();
                            abrirMovimentacao(produto, 'saida');
                          }}>
                            <ArrowUpRight className="h-4 w-4 mr-2" />
                            Registrar Saída
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={(e) => {
                            e.stopPropagation();
                            setProdutoSelecionado(produto);
                            setNovoLoteDialog(true);
                            setNovoLoteData({
                              lote: '',
                              quantidade: '',
                              data_fabricacao: '',
                              data_validade: ''
                            });
                          }}>
                            <PlusCircle className="h-4 w-4 mr-2" />
                            Adicionar Lote
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={showNovoProdutoDialog} onOpenChange={setShowNovoProdutoDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Cadastrar Novo Produto</DialogTitle>
            <DialogDescription>
              Preencha os dados do produto para adicionar ao estoque
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="max-h-[70vh]">
            <div className="space-y-6 p-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="codigo">Código *</Label>
                  <Input
                    id="codigo"
                    placeholder="Código do produto"
                    value={novoProduto.codigo}
                    onChange={(e) => handleNovoProdutoChange('codigo', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="codigo_barras">Código de Barras</Label>
                  <Input
                    id="codigo_barras"
                    placeholder="Código de barras (opcional)"
                    value={novoProduto.codigo_barras}
                    onChange={(e) => handleNovoProdutoChange('codigo_barras', e.target.value)}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="nome">Nome do Produto *</Label>
                <Input
                  id="nome"
                  placeholder="Nome completo do produto"
                  value={novoProduto.nome}
                  onChange={(e) => handleNovoProdutoChange('nome', e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição</Label>
                <Input
                  id="descricao"
                  placeholder="Descrição detalhada do produto"
                  value={novoProduto.descricao}
                  onChange={(e) => handleNovoProdutoChange('descricao', e.target.value)}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="categoria">Categoria *</Label>
                  <Input
                    id="categoria"
                    placeholder="Categoria do produto"
                    value={novoProduto.categoria}
                    onChange={(e) => handleNovoProdutoChange('categoria', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="fabricante">Fabricante</Label>
                  <Input
                    id="fabricante"
                    placeholder="Nome do fabricante"
                    value={novoProduto.fabricante}
                    onChange={(e) => handleNovoProdutoChange('fabricante', e.target.value)}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="preco_custo">Preço de Custo</Label>
                  <Input
                    id="preco_custo"
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0,00"
                    value={novoProduto.preco_custo}
                    onChange={(e) => handleNovoProdutoChange('preco_custo', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="preco_venda">Preço de Venda *</Label>
                  <Input
                    id="preco_venda"
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0,00"
                    value={novoProduto.preco_venda}
                    onChange={(e) => handleNovoProdutoChange('preco_venda', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="unidade_medida">Unidade de Medida</Label>
                  <Select
                    value={novoProduto.unidade_medida}
                    onValueChange={(value) => handleNovoProdutoChange('unidade_medida', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a unidade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unidade">Unidade</SelectItem>
                      <SelectItem value="caixa">Caixa</SelectItem>
                      <SelectItem value="frasco">Frasco</SelectItem>
                      <SelectItem value="ampola">Ampola</SelectItem>
                      <SelectItem value="comprimido">Comprimido</SelectItem>
                      <SelectItem value="ml">Mililitro (ml)</SelectItem>
                      <SelectItem value="g">Grama (g)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="quantidade_atual">Estoque Inicial</Label>
                  <Input
                    id="quantidade_atual"
                    type="number"
                    min="0"
                    placeholder="0"
                    value={novoProduto.quantidade_atual}
                    onChange={(e) => handleNovoProdutoChange('quantidade_atual', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="estoque_minimo">Estoque Mínimo</Label>
                  <Input
                    id="estoque_minimo"
                    type="number"
                    min="0"
                    placeholder="5"
                    value={novoProduto.estoque_minimo}
                    onChange={(e) => handleNovoProdutoChange('estoque_minimo', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="estoque_maximo">Estoque Máximo</Label>
                  <Input
                    id="estoque_maximo"
                    type="number"
                    min="0"
                    placeholder="100"
                    value={novoProduto.estoque_maximo}
                    onChange={(e) => handleNovoProdutoChange('estoque_maximo', e.target.value)}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Label htmlFor="controlado" className="flex items-center gap-2 cursor-pointer">
                    <input
                      id="controlado"
                      type="checkbox"
                      className="w-4 h-4"
                      checked={novoProduto.controlado}
                      onChange={(e) => handleNovoProdutoChange('controlado', e.target.checked)}
                    />
                    Produto Controlado (sujeito a receita)
                  </Label>
                </div>
              </div>
              
              {novoProduto.controlado && (
                <div className="space-y-2">
                  <Label htmlFor="tipo_receita">Tipo de Receita</Label>
                  <Select
                    value={novoProduto.tipo_receita}
                    onValueChange={(value) => handleNovoProdutoChange('tipo_receita', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo de receita" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="simples">Receita Simples</SelectItem>
                      <SelectItem value="especial">Receita Especial</SelectItem>
                      <SelectItem value="antimicrobiano">Antimicrobiano</SelectItem>
                      <SelectItem value="especial_retencao">Receita Especial com Retenção</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="codigo_anvisa">Registro ANVISA</Label>
                <Input
                  id="codigo_anvisa"
                  placeholder="Código de registro na ANVISA (se aplicável)"
                  value={novoProduto.codigo_anvisa}
                  onChange={(e) => handleNovoProdutoChange('codigo_anvisa', e.target.value)}
                />
              </div>
            </div>
          </ScrollArea>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNovoProdutoDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSalvarProduto} disabled={isProcessing}>
              {isProcessing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                'Salvar Produto'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showDetalhesDialog} onOpenChange={setShowDetalhesDialog}>
        <DialogContent className="max-w-3xl">
          {produtoSelecionado && (
            <>
              <DialogHeader>
                <DialogTitle>Detalhes do Produto</DialogTitle>
                <DialogDescription>
                  Informações completas e lotes do produto
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">{produtoSelecionado.nome}</h3>
                  <div className="space-y-2">
                    <p><span className="font-medium">Código:</span> {produtoSelecionado.codigo}</p>
                    {produtoSelecionado.codigo_barras && (
                      <p><span className="font-medium">Código de Barras:</span> {produtoSelecionado.codigo_barras}</p>
                    )}
                    <p><span className="font-medium">Categoria:</span> {produtoSelecionado.categoria}</p>
                    {produtoSelecionado.fabricante && (
                      <p><span className="font-medium">Fabricante:</span> {produtoSelecionado.fabricante}</p>
                    )}
                    <p><span className="font-medium">Preço de Venda:</span> {formatMoney(produtoSelecionado.preco_venda)}</p>
                    {produtoSelecionado.preco_custo > 0 && (
                      <p><span className="font-medium">Preço de Custo:</span> {formatMoney(produtoSelecionado.preco_custo)}</p>
                    )}
                    
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant={getStatusColor(produtoSelecionado)}>
                        {getStatusText(produtoSelecionado)}
                      </Badge>
                      
                      {produtoSelecionado.controlado && (
                        <Badge variant="outline">
                          Controlado
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <h4 className="font-medium mb-1">Estoque</h4>
                    <p>
                      <span className="font-medium">Quantidade Atual:</span> {produtoSelecionado.quantidade_atual} {produtoSelecionado.unidade_medida}
                    </p>
                    <p>
                      <span className="font-medium">Mínimo:</span> {produtoSelecionado.estoque_minimo} {produtoSelecionado.unidade_medida} | 
                      <span className="font-medium ml-2">Máximo:</span> {produtoSelecionado.estoque_maximo} {produtoSelecionado.unidade_medida}
                    </p>
                  </div>
                  
                  <div className="mt-4">
                    <h4 className="font-medium mb-1">Descrição</h4>
                    <p className="text-gray-700">
                      {produtoSelecionado.descricao || "Sem descrição disponível"}
                    </p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Lotes em Estoque</h4>
                  {produtoSelecionado.lotes && produtoSelecionado.lotes.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Lote</TableHead>
                          <TableHead>Quantidade</TableHead>
                          <TableHead>Validade</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {produtoSelecionado.lotes.map((lote, index) => (
                          <TableRow key={index}>
                            <TableCell>{lote.lote}</TableCell>
                            <TableCell>{lote.quantidade} {produtoSelecionado.unidade_medida}</TableCell>
                            <TableCell>
                              {lote.data_validade ? format(new Date(lote.data_validade), 'dd/MM/yyyy') : '-'}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="p-4 bg-gray-50 rounded-md text-center">
                      <p className="text-gray-500">Nenhum lote cadastrado</p>
                    </div>
                  )}
                </div>
              </div>
              
              <Separator className="my-4" />
              
              <div className="flex justify-between">
                <div className="space-x-2">
                  <Button variant="outline" onClick={() => abrirMovimentacao(produtoSelecionado, 'entrada')}>
                    <ArrowDownLeft className="h-4 w-4 mr-2" />
                    Entrada
                  </Button>
                  <Button variant="outline" onClick={() => abrirMovimentacao(produtoSelecionado, 'saida')}>
                    <ArrowUpRight className="h-4 w-4 mr-2" />
                    Saída
                  </Button>
                  <Button variant="outline" onClick={() => {
                    setProdutoSelecionado(produtoSelecionado);
                    setNovoLoteDialog(true);
                  }}>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Novo Lote
                  </Button>
                </div>
                
                <div>
                  <Button variant="destructive" onClick={() => setShowConfirmDelete(true)}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    Excluir
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={novoLoteDialog} onOpenChange={setNovoLoteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Novo Lote</DialogTitle>
            <DialogDescription>
              {produtoSelecionado?.nome}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="lote">Número do Lote *</Label>
              <Input
                id="lote"
                placeholder="Número do lote"
                value={novoLoteData.lote}
                onChange={(e) => handleNovoLoteChange('lote', e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="quantidade">Quantidade *</Label>
              <Input
                id="quantidade"
                type="number"
                min="0"
                step="0.01"
                placeholder={`Quantidade em ${produtoSelecionado?.unidade_medida || 'unidades'}`}
                value={novoLoteData.quantidade}
                onChange={(e) => handleNovoLoteChange('quantidade', e.target.value)}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="data_fabricacao">Data de Fabricação</Label>
                <Input
                  id="data_fabricacao"
                  type="date"
                  value={novoLoteData.data_fabricacao}
                  onChange={(e) => handleNovoLoteChange('data_fabricacao', e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="data_validade">Data de Validade *</Label>
                <Input
                  id="data_validade"
                  type="date"
                  value={novoLoteData.data_validade}
                  onChange={(e) => handleNovoLoteChange('data_validade', e.target.value)}
                />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setNovoLoteDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAdicionarLote} disabled={isProcessing}>
              {isProcessing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Adicionando...
                </>
              ) : (
                'Adicionar Lote'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showMovimentacaoDialog} onOpenChange={setShowMovimentacaoDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {tipoMovimentacao === 'entrada' ? 'Registrar Entrada' : 'Registrar Saída'}
            </DialogTitle>
            <DialogDescription>
              {produtoSelecionado?.nome}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="quantidade">Quantidade *</Label>
              <Input
                id="quantidade"
                type="number"
                min="0.01"
                step="0.01"
                placeholder={`Quantidade em ${produtoSelecionado?.unidade_medida || 'unidades'}`}
                value={movimentacaoData.quantidade}
                onChange={(e) => handleMovimentacaoChange('quantidade', e.target.value)}
              />
            </div>
            
            {produtoSelecionado && produtoSelecionado.lotes && produtoSelecionado.lotes.length > 0 && (
              <div className="space-y-2">
                <Label htmlFor="lote">Lote</Label>
                <Select
                  value={movimentacaoData.lote}
                  onValueChange={(value) => handleMovimentacaoChange('lote', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o lote" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Sem especificar lote</SelectItem>
                    {produtoSelecionado.lotes.map((lote, index) => (
                      <SelectItem key={index} value={lote.lote}>
                        {lote.lote} - {lote.quantidade} {produtoSelecionado.unidade_medida} - Val: {
                          lote.data_validade ? format(new Date(lote.data_validade), 'dd/MM/yyyy') : 'N/A'
                        }
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="motivo">Motivo</Label>
              <Input
                id="motivo"
                placeholder="Motivo da movimentação"
                value={movimentacaoData.motivo}
                onChange={(e) => handleMovimentacaoChange('motivo', e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="observacoes">Observações</Label>
              <Input
                id="observacoes"
                placeholder="Observações adicionais"
                value={movimentacaoData.observacoes}
                onChange={(e) => handleMovimentacaoChange('observacoes', e.target.value)}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMovimentacaoDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleMovimentacaoEstoque}
              disabled={isProcessing}
              variant={tipoMovimentacao === 'entrada' ? 'default' : 'secondary'}
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Processando...
                </>
              ) : (
                <>
                  {tipoMovimentacao === 'entrada' ? (
                    <>
                      <ArrowDownLeft className="h-4 w-4 mr-2" />
                      Registrar Entrada
                    </>
                  ) : (
                    <>
                      <ArrowUpRight className="h-4 w-4 mr-2" />
                      Registrar Saída
                    </>
                  )}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showConfirmDelete} onOpenChange={setShowConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir produto</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir o produto "{produtoSelecionado?.nome}"? 
              Esta ação não pode ser desfeita e removerá todos os lotes associados.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleExcluirProduto}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Excluindo...
                </>
              ) : (
                'Excluir'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
