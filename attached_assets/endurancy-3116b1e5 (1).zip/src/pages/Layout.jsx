

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities"; 
import { toast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuTrigger, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator 
} from "@/components/ui/dropdown-menu";
import {
  Bell,
  LogOut,
  LayoutGrid,
  BarChart4,
  ClipboardList,
  Database,
  AlertTriangle,
  Layers,
  Users,
  Building2,
  DollarSign,
  Mail,
  UserCog,
  Settings,
  Sun,
  Moon,
  Menu,
  Leaf,
  Factory,
  Heart,
  Briefcase,
  Scale,
  Glasses,
  Receipt,
  Send,
  TrendingUp,
  FileText,
  FileCheck,
  ClipboardCheck,
  ShieldCheck,
  Calendar,
  Video,
  BrainCircuit,
  UserPlus,
  MessageSquare,
  FilePlus,
  ArrowUpCircle,
  ArrowDownCircle,
  Brain,
  CreditCard,
  ArrowLeftRight,
  RefreshCw,
  Zap,
  Cloud,
  Lock,
  ShoppingCart,
  ShoppingBag,
  Package,
  Truck,
  Tag,
  Box,
  PackageCheck,
  Printer,
  ScanBarcode,
  Archive,
  BoxSelect,
  ScanLine,
  PackageOpen,
  Sprout,
  Beaker,
  CheckSquare,
  Warehouse,
  Headphones,
  Smartphone,
  BadgePercent,
  Globe,
  FileBadge,
  Award,
  LineChart,
  FolderOpen,
  Clipboard,
  Landmark,
  FileBox,
  ChevronLeft,
  ChevronRight,
  X,
  ChevronDown,
  History,
  HelpCircle,
  Trello,
  GraduationCap,
  BookOpen,
  CheckCircle,
  Search,
  Trash2,
  Droplets,
  FlaskConical,
  Microscope,
  FileSearch,
  Stethoscope,
  Activity,
  BookMarked,
  Group,
  Share2,
  FilePlus2,
  ScrollText,
  Database as LucideDatabase,
  PieChart,
  TableProperties,
} from "lucide-react";
import OrganizationHeader from './components/onboarding/OrganizationHeader';
import AICopilot from './components/ai/AICopilot';
import CopilotButton from './components/ai/CopilotButton';
import { SimpleTooltip, SimpleTooltipProvider, SimpleTooltipTrigger, SimpleTooltipContent } from "./components/ui/simple-tooltip";

const superAdminMenuSections = [
  {
    title: "GESTÃO DE ONBOARDING",
    items: [
      { icon: GraduationCap, label: 'Dashboard Onboarding', path: 'OnboardingAdmin' },
      { icon: FileText, label: 'Gerenciar Conteúdos', path: 'OnboardingContent' },
      { icon: Users, label: 'Permissões de Acesso', path: 'OnboardingAccess' },
      { icon: Settings, label: 'Configurações', path: 'OnboardingSettings' },
      { icon: BarChart4, label: 'Analytics', path: 'OnboardingAnalytics' },
    ],
  },
  {
    title: "VISÃO GERAL",
    items: [
      { icon: LayoutGrid, label: 'Dashboard', path: 'Dashboard' },
      { icon: BarChart4, label: 'Analytics', path: 'Analytics' },
    ],
  },
  {
    title: "GESTÃO",
    items: [
      { icon: Building2, label: 'Organizações', path: 'Organizations' },
      { icon: Building2, label: 'Solicitações', path: 'Requests' },
      { icon: Layers, label: 'Planos', path: 'Plans' },
      { icon: UserCog, label: 'Administradores', path: 'Admins' },
    ],
  },
  {
    title: "MÓDULOS",
    items: [
      { icon: ShoppingCart, label: 'Módulo Compras', path: 'ModuloCompras' },
      { icon: Leaf, label: 'Cultivo', path: 'ModuloCultivo' },
      { icon: Factory, label: 'Produção', path: 'ModuloProducao' },
      { icon: Heart, label: 'CRM', path: 'ModuloCRM' },
      { icon: Briefcase, label: 'RH', path: 'ModuloRH' },
      { icon: Scale, label: 'Jurídico', path: 'ModuloJuridico' },
      { icon: Heart, label: 'Social', path: 'Social' },
      { icon: Glasses, label: 'Transparência', path: 'TransparencySettings' },
      { icon: BrainCircuit, label: 'Inteligência Artificial', path: 'AISettings' },
    ],
  },
  {
    title: "FINANCEIRO",
    items: [
      { icon: DollarSign, label: 'Financeiro', path: 'Financial' },
      { icon: Receipt, label: 'Faturamento', path: 'Billing' },
    ],
  },
  {
    title: "COMUNICAÇÃO",
    items: [
      { icon: Mail, label: 'Templates de Email', path: 'EmailTemplates' },
      { icon: Send, label: 'Newsletter', path: 'Newsletter' },
    ],
  },
  {
    title: "AUDITORIA",
    items: [
      { icon: ClipboardList, label: 'Registro de Atividades', path: 'Activities' },
      { icon: TrendingUp, label: 'Analytics', path: 'Analytics' },
    ],
  },
  {
    title: "SISTEMA",
    items: [
      { icon: Settings, label: 'Configurações', path: 'Settings' },
      { icon: LucideDatabase, label: 'Backups', path: 'Backups' },
      { icon: AlertTriangle, label: 'Emergências', path: 'Emergencias' },
    ],
  },
  {
    title: "DISPENSÁRIO",
    items: [
      { icon: ShoppingBag, label: 'Dispensário', path: 'AdminModuloDispensario' },
    ],
  },
];

const orgAdminMenuSections = [
  {
    title: "ONBOARDING",
    items: [
      { icon: GraduationCap, label: 'Visão Geral', path: 'Onboarding' },
      { icon: BookOpen, label: 'Tutoriais', path: 'OnboardingTutorials' },
      { icon: CheckCircle, label: 'Meu Progresso', path: 'OnboardingProgress' },
    ],
  },
  {
    title: "VISÃO GERAL",
    items: [
      { icon: LayoutGrid, label: 'Dashboard', path: 'OrgDashboard' },
      { icon: BarChart4, label: 'Analytics', path: 'Analytics' },
      { icon: GraduationCap, label: 'Onboarding', path: 'Onboarding' },
    ],
  },
  {
    title: "TAREFAS",
    items: [
      { icon: LayoutGrid, label: 'Dashboard Tarefas', path: 'TasksDashboard' },
      { icon: Trello, label: 'Quadro Kanban', path: 'Tasks' },
      { icon: CheckSquare, label: 'Minhas Tarefas', path: 'MyTasks' },
      { icon: Settings, label: 'Configurações', path: 'TasksSettings' },
    ],
  },
  {
    title: "ASSOCIADOS",
    items: [
      { icon: Users, label: 'Quadro de Associados', path: 'Associados' },
      { icon: FileText, label: 'Documentos', path: 'DocumentosAssociados' },
      { icon: FileCheck, label: 'Prescrições', path: 'PrescricoesAssociados' },
      { icon: ClipboardCheck, label: 'Aprovação de Prescrições', path: 'AprovacoesPrescriscoes' },
    ],
    showFor: "Associação",
  },
  {
    title: "SOCIAL",
    items: [
      { icon: Heart, label: 'Dashboard Social', path: 'Social' },
      { icon: Users, label: 'Beneficiários', path: 'CadastroSocial' },
      { icon: DollarSign, label: 'Financeiro Social', path: 'FinanceiroSocial' },
      { icon: Globe, label: 'Portal Social', path: 'PortalSocial' },
    ],
    showFor: "Associação",
  },
  {
    title: "CLIENTES",
    items: [
      { icon: Users, label: 'Clientes', path: 'Clientes' },
      { icon: FileText, label: 'Documentos', path: 'DocumentosClientes' },
      { icon: ShieldCheck, label: 'Autorizações ANVISA', path: 'AutorizacoesAnvisa' },
      { icon: FileCheck, label: 'Prescrições', path: 'PrescricoesClientes' },
    ],
    showFor: "Empresa",
  },
  {
    title: "CULTIVO",
    items: [
      { icon: Leaf, label: 'Dashboard Cultivo', path: 'CultivoDashboard' },
      { icon: Sprout, label: 'Plantas', path: 'CultivoPlantas' },
      { icon: ClipboardList, label: 'Lotes', path: 'CultivoLotes' },
      { icon: ArrowLeftRight, label: 'Transferências', path: 'CultivoTransferencias' },
      { icon: Scale, label: 'Estoque', path: 'CultivoEstoque' },
      { icon: Beaker, label: 'Testes Laboratoriais', path: 'CultivoTestes' },
      { icon: Leaf, label: 'Strains', path: 'CultivoStrains' },
      { icon: FileText, label: 'Relatórios', path: 'CultivoRelatorios' },
    ],
  },
  {
    title: "PRODUÇÃO",
    items: [
      { icon: GraduationCap, label: 'Onboarding Produção', path: 'ProducaoOnboarding' },
      { icon: Factory, label: 'Dashboard Produção', path: 'ProducaoDashboard' },
      { icon: ArrowLeftRight, label: 'Movimentações', path: 'ProducaoMovimentacoes' },
      { icon: ClipboardList, label: 'Ordens de Produção', path: 'ProducaoOrdens' },
      { icon: ShieldCheck, label: 'Garantia da Qualidade', path: 'ProducaoGarantiaQualidade' },
      { icon: CheckSquare, label: 'Controle de Qualidade', path: 'ProducaoQualidade' },
      { icon: History, label: 'Audit Trail', path: 'ProducaoAuditTrail' },
      { icon: Factory, label: 'Processo Produtivo', path: 'ProducaoProcesso' },
      { icon: Beaker, label: 'Setor Extração', path: 'ProducaoExtracao' },
      { icon: Droplets, label: 'Setor Diluição', path: 'ProducaoDiluicao' },
      { icon: FlaskConical, label: 'Setor Envasamento', path: 'ProducaoEnvasamento' },
      { icon: PackageOpen, label: 'Setor Embalagem', path: 'ProducaoEmbalagem' },
      { icon: Trash2, label: 'Descartes', path: 'ProducaoDescartes' },
      { icon: Search, label: 'Rastreabilidade', path: 'ProducaoRastreabilidade' },
    ],
  },
  {
    title: "EDUCAÇÃO DO PACIENTE",
    items: [
      { icon: FileText, label: 'Biblioteca de Conteúdos', path: 'BibliotecaEducativa' },
      { icon: MessageSquare, label: 'Perguntas Frequentes', path: 'FaqPacientes' },
      { icon: FilePlus, label: 'Novo Conteúdo', path: 'NovoConteudo' },
    ],
  },
  {
    title: "FINANCEIRO",
    items: [
      { icon: DollarSign, label: 'Dashboard Financeiro', path: 'FinanceiroDashboard' },
      { icon: ArrowUpCircle, label: 'Contas a Pagar', path: 'ContasPagar' },
      { icon: ArrowDownCircle, label: 'Contas a Receber', path: 'ContasReceber' },
      { icon: BarChart4, label: 'DRE', path: 'RelatoriosDRE' },
      { icon: Briefcase, label: 'Orçamento', path: 'OrcamentoAnual' },
      { icon: Calendar, label: 'Fluxo de Caixa', path: 'FluxoCaixa' },
      { icon: Calendar, label: 'Calendário Financeiro', path: 'CalendarioFinanceiro' },
      { icon: FileText, label: 'Conciliação Bancária', path: 'ConciliacaoBancaria' },
      { icon: Brain, label: 'Análise com IA', path: 'AnaliseFinanceiraIA' },
      { icon: Settings, label: 'Configurações', path: 'ConfiguracoesFinanceiro' },
    ],
  },
  {
    title: "COMPLYPAY",
    items: [
      { icon: CreditCard, label: 'Dashboard', path: 'ComplyPay' },
      { icon: Receipt, label: 'Faturas', path: 'ComplyPayInvoices' },
      { icon: ArrowLeftRight, label: 'Transações', path: 'ComplyPayTransactions' },
      { icon: RefreshCw, label: 'Assinaturas', path: 'ComplyPaySubscriptions' },
      { icon: Zap, label: 'Integrações', path: 'ComplyPayIntegrations' },
      { icon: Settings, label: 'Configurações', path: 'ComplyPaySettings' },
    ],
  },
  {
    title: "COMUNICAÇÃO",
    items: [
      { icon: Mail, label: 'Módulo Comunicação', path: 'ModuloComunicacao' },
      { icon: Calendar, label: 'Calendário', path: 'CalendarioComunicacao' },
      { icon: Send, label: 'Campanhas de Email', path: 'CampanhasEmail' },
      { icon: Bell, label: 'Notificações', path: 'NotificacoesComunicacao' },
      { icon: Cloud, label: 'Arquivos e Mídias', path: 'ArquivosComunicacao' },
      { icon: Lock, label: 'Credenciais', path: 'CredenciaisServicos' },
    ],
  },
  {
    title: "COMPRAS E ESTOQUE",
    items: [
      { icon: ShoppingCart, label: 'Dashboard Compras', path: 'ComprasDashboard' },
      { icon: FileText, label: 'Solicitações de Compra', path: 'SolicitacoesCompra' },
      { icon: ShoppingBag, label: 'Fornecedores', path: 'ProducaoFornecedores' },
      { icon: Package, label: 'Estoque', path: 'Estoque' },
      { icon: Truck, label: 'Pedidos de Compra', path: 'PedidosCompra' },
    ],
  },
  {
    title: "VENDAS",
    items: [
      { icon: ShoppingBag, label: 'Dashboard Vendas', path: 'VendasDashboard' },
      { icon: ShoppingCart, label: 'Pedidos', path: 'Pedidos' },
      { icon: Package, label: 'Produtos', path: 'Produtos' },
      { icon: Tag, label: 'Promoções', path: 'Promocoes' },
      { icon: Truck, label: 'Rastreamento', path: 'Rastreamento' },
    ],
  },
  {
    title: "EXPEDIÇÃO",
    items: [
      { icon: Box, label: 'Dashboard Expedição', path: 'ExpedicaoDashboard' },
      { icon: PackageCheck, label: 'Preparação de Pedidos', path: 'ExpedicaoPreparacao' },
      { icon: Printer, label: 'Etiquetas', path: 'Etiquetas' },
      { icon: ScanBarcode, label: 'Leitura de Códigos', path: 'ExpedicaoCodigosBarras' },
      { icon: Archive, label: 'Documentação', path: 'ExpedicaoDocumentacao' },
      { icon: BoxSelect, label: 'Junção de Pedidos', path: 'ExpedicaoJuncaoPedidos' },
      { icon: Truck, label: 'Registro de Malotes', path: 'ExpedicaoMalotes' },
      { icon: ScanLine, label: 'Atualização de Rastreios', path: 'ExpedicaoRastreios' },
      { icon: PackageOpen, label: 'Estoque da Expedição', path: 'ExpedicaoEstoque' },
    ],
  },
  {
    title: "DISPENSÁRIO",
    items: [
      { icon: LayoutGrid, label: 'Dashboard', path: 'DispensarioDashboard' },
      { icon: ShoppingBag, label: 'PDV', path: 'PDV' },
      { icon: Package, label: 'Estoque', path: 'EstoqueDispensario' },
      { icon: FileText, label: 'Receituário', path: 'GerenciarReceituario' },
      { icon: DollarSign, label: 'Caixa', path: 'DispensarioCaixa' },
      { icon: BarChart4, label: 'Relatórios', path: 'RelatorioDispensario' },
      { icon: FileText, label: 'SNGPC', path: 'RelatorioSNGPC' },
      { icon: Settings, label: 'Configurações', path: 'DispensarioConfig' },
    ],
  },
  {
    title: "JURÍDICO",
    items: [
      { icon: Scale, label: 'Dashboard Jurídico', path: 'JuridicoDashboard' },
      { icon: FileText, label: 'Ações Judiciais', path: 'JuridicoAcoes' },
      { icon: FileCheck, label: 'Documentos Jurídicos', path: 'JuridicoDocumentos' },
      { icon: ShieldCheck, label: 'Compliance', path: 'JuridicoCompliance' },
    ],
  },
  {
    title: "TRANSPARÊNCIA",
    items: [
      { icon: Globe, label: 'Portal de Transparência', path: 'AssociacaoTransparencia' },
      { icon: FileBadge, label: 'Documentos Públicos', path: 'TransparencyDocuments' },
      { icon: Award, label: 'Certificações', path: 'TransparencyCertifications' },
      { icon: LineChart, label: 'Relatórios Financeiros', path: 'TransparencyFinancial' },
      { icon: Users, label: 'Membros e Governança', path: 'TransparencyMembers' },
    ],
  },
  {
    title: "RH",
    items: [
      { icon: Briefcase, label: 'Dashboard RH', path: 'RhDashboard' },
      { icon: UserPlus, label: 'Recrutamento', path: 'RhRecrutamento' },
      { icon: Users, label: 'Colaboradores', path: 'RhColaboradores' },
      { icon: FolderOpen, label: 'Documentos', path: 'RhDocumentos' },
      { icon: Calendar, label: 'Escalas', path: 'RhEscalas' },
    ],
  },
  {
    title: "PATRIMÔNIO",
    items: [
      { icon: Landmark, label: 'Dashboard Patrimônio', path: 'PatrimonioDashboard' },
      { icon: Building2, label: 'Instalações', path: 'PatrimonioInstalacoes' },
      { icon: FileBox, label: 'Equipamentos', path: 'PatrimonioEquipamentos' },
      { icon: Clipboard, label: 'Manutenções', path: 'PatrimonioManutencoes' },
    ],
  },
  {
    title: "PESQUISA CIENTÍFICA",
    items: [
      { icon: Microscope, label: 'Dashboard Pesquisa', path: 'PesquisaDashboard' },
      { icon: FileSearch, label: 'Catálogo de Pesquisas', path: 'CatalogoPesquisas' },
      { icon: Database, label: 'Banco de Pacientes', path: 'BancoPacientes' },
      { icon: Stethoscope, label: 'Doenças e Condições', path: 'DoencasCondicoes' },
      { icon: Activity, label: 'Estatísticas', path: 'EstatisticasPesquisa' },
      { icon: Group, label: 'Grupos de Pesquisa', path: 'GruposPesquisa' },
      { icon: BookMarked, label: 'Protocolos', path: 'Protocolos' },
      { icon: Share2, label: 'Colaborações', path: 'Colaboracoes' },
      { icon: FilePlus2, label: 'Nova Pesquisa', path: 'NovaPesquisa' },
    ],
  },
  {
    title: "CONFIGURAÇÕES",
    items: [
      { icon: Users, label: 'Usuários', path: 'OrgUsuarios' },
      { icon: ShieldCheck, label: 'Permissões', path: 'UserPermissions' },
      { icon: Building2, label: 'Estrutura Organizacional', path: 'OrgEstrutura' },
      { icon: Settings, label: 'Configurações', path: 'OrgConfiguracoes' },
      { icon: CreditCard, label: 'Anuidades', path: 'Anuidades' },
    ],
  },
];

const Layout = ({ children, currentPageName }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { pathname } = location;
  const isOnboarding = pathname.includes('Onboarding');

  const [isDarkMode, setIsDarkMode] = useState(() => localStorage.getItem('theme') === 'dark');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [userType, setUserType] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [organizationType, setOrganizationType] = useState(null);
  const [expandedSections, setExpandedSections] = useState({});
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);

  const safeCurrentPageName = currentPageName || '';
  const publicPages = ["Index", "TermsOfService", "PrivacyPolicy", "Contact"];
  const authPages = ["Access", "RecoverPassword", "RegisterPage", "ForgotPassword", "Landing", "PatientPortal", "DoctorPortal"];
  const isPublicPage = publicPages.includes(safeCurrentPageName);
  const isAuthPage = authPages.includes(safeCurrentPageName);

  const determineOrgType = React.useCallback(() => {
    const savedOrgType = localStorage.getItem('mockOrgType');
    setOrganizationType(savedOrgType || "Associação");
  }, []);

  const loadCurrentUser = React.useCallback(async () => {
    setIsLoading(true);
    try {
      const mockUserType = localStorage.getItem('mockUserType');
      const mockUserEmail = localStorage.getItem('mockUserEmail');
      const mockUserName = localStorage.getItem('mockUserName');

      if (mockUserType && mockUserEmail) {
        setCurrentUser({
          id: "mock-user-1",
          full_name: mockUserName || "Usuário Demonstração",
          email: mockUserEmail,
          role: "admin",
          user_type: mockUserType,
        });
        setUserType(mockUserType);
        setIsAuthenticated(true);
      } else {
        setCurrentUser({
          id: "superuser-1",
          full_name: "Comply",
          email: "admin@endurancy.com",
          role: "admin",
          user_type: "superadmin",
        });
        setUserType("superadmin");
        setIsAuthenticated(true);
      }
    } catch (error) {
      console.error("Error loading current user", error);
      setCurrentUser({
        id: "fallback-user",
        full_name: "Administrador Padrão",
        email: "admin@endurancy.com",
        role: "admin",
        user_type: "superadmin",
      });
      setUserType("superadmin");
      setIsAuthenticated(true);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    console.log("Layout loaded, current user type:", localStorage.getItem('mockUserType'));

    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
      if (window.innerWidth < 1024) {
        setIsSidebarOpen(false);
        setIsSidebarCollapsed(false);
      } else {
        setIsSidebarOpen(true);
      }
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    if (window.location.pathname === '/') {
      navigate(createPageUrl("Index"));
      return;
    }

    if (!isPublicPage && !isAuthPage) {
      loadCurrentUser();
      determineOrgType();
    } else {
      setIsLoading(false);
    }
  }, [safeCurrentPageName, navigate, isPublicPage, isAuthPage, loadCurrentUser, determineOrgType]);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    localStorage.setItem('theme', !isDarkMode ? 'dark' : 'light');
  };

  const toggleSidebar = () => {
    if (isMobile) {
      setIsSidebarOpen(!isSidebarOpen);
    } else {
      setIsSidebarCollapsed(!isSidebarCollapsed);
    }
  };

  const handleLogout = () => {
    try {
      sessionStorage.setItem('isLoggingOut', 'true');
      localStorage.removeItem('mockUserType');
      localStorage.removeItem('mockUserEmail');
      localStorage.removeItem('mockUserName');
      localStorage.removeItem('mockOrgType');
      window.location.href = '/Access';
    } catch (error) {
      console.error("Error during logout:", error);
      window.location.href = '/Access';
    }
  };

  const closeSidebarOnMobile = () => {
    if (isMobile) {
      setIsSidebarOpen(false);
    }
  };

  const toggleSection = (sectionIndex) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionIndex]: !prev[sectionIndex]
    }));
  };

  if (!safeCurrentPageName) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-green-200 border-t-green-600"></div>
          <p className="text-sm text-gray-500">Carregando...</p>
        </div>
      </div>
    );
  }

  if (safeCurrentPageName === "Index" || 
      safeCurrentPageName === "PatientDashboard" || 
      safeCurrentPageName === "PatientPortal" ||
      safeCurrentPageName === "DoctorDashboard" || 
      safeCurrentPageName === "DoctorPortal" || 
      safeCurrentPageName === "ConsultaVirtual" || 
      safeCurrentPageName === "SymptomChecker" || 
      safeCurrentPageName.startsWith("Doctor") || 
      isAuthPage) {
    return children;
  }

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-green-200 border-t-green-600"></div>
          <p className="text-sm text-gray-500">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated && !isPublicPage && !isAuthPage) {
    navigate(createPageUrl("Access"));
    return null;
  }

  const menuSections = userType === "orgadmin" ? orgAdminMenuSections : superAdminMenuSections;

  return (
    <div className={isDarkMode ? 'dark' : ''}>
      <div className="min-h-screen flex bg-gray-50 dark:bg-gray-900 dark:text-gray-100">
        {isMobile && isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-30"
            onClick={() => setIsSidebarOpen(false)}
          ></div>
        )}
        
        <aside 
          className={`fixed top-0 left-0 z-40 h-screen transition-all duration-300 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700
            ${isMobile 
              ? isSidebarOpen ? 'translate-x-0' : '-translate-x-full' 
              : isSidebarCollapsed ? 'w-16' : 'w-64'}`}
        >
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-green-100 dark:bg-green-800 rounded-lg flex items-center justify-center">
                  <span className="text-green-600 dark:text-green-200 font-semibold">E</span>
                </div>
                <span className="font-semibold text-xl text-gray-900 dark:text-white">Endurancy</span>
              </div>

              {!isMobile && (
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={toggleSidebar}
                  className="hidden lg:flex text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
              )}
            </div>

            <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
              {menuSections.map((section, index) => {
                if (section.showFor) {
                  if (Array.isArray(section.showFor)) {
                    if (!section.showFor.includes(organizationType)) {
                      return null;
                    }
                  } else if (section.showFor !== organizationType) {
                    return null;
                  }
                }

                const isExpanded = expandedSections[index] || false;
                const hasActiveItem = section.items.some(item => safeCurrentPageName === item.path);

                return (
                  <div key={index} className="space-y-0.5">
                    <button
                      onClick={() => toggleSection(index)}
                      className={`w-full flex items-center justify-between py-2 px-3 rounded-lg text-xs transition-colors
                        ${hasActiveItem 
                          ? 'bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400' 
                          : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'
                        }`}
                    >
                      <span className="font-medium">{section.title}</span>
                      <ChevronDown 
                        className={`w-4 h-4 transition-transform duration-200 ${isExpanded ? 'transform rotate-180' : ''}`} 
                      />
                    </button>

                    <div className={`overflow-hidden transition-all duration-300 ease-in-out ${
                      isExpanded ? 'max-h-96' : 'max-h-0'
                    }`}>
                      <div className="pt-1 pl-2">
                        {section.items.map((item) => {
                          const IconComponent = item.icon;
                          const isActive = safeCurrentPageName === item.path;

                          return (
                            <Link
                              key={item.path}
                              to={createPageUrl(item.path)}
                              className={`flex items-center px-3 py-2 rounded-lg transition-colors text-xs ${
                                isActive
                                  ? 'bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400'
                                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'
                              }`}
                              onClick={closeSidebarOnMobile}
                            >
                              <IconComponent className="w-4 h-4 flex-shrink-0" />
                              <span className="ml-2">{item.label}</span>
                            </Link>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })}
            </nav>

            <div className="p-4 border-t border-gray-200 dark:border-gray-700">
              <Button
                variant="outline"
                className="w-full justify-start gap-2 text-red-600 dark:text-red-400 dark:border-gray-600 hover:bg-gray-200 dark:hover:bg-gray-700"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4" />
                Sair
              </Button>
            </div>
          </div>
        </aside>

        <div className={`flex-1 transition-all duration-300 bg-gray-50 dark:bg-gray-900 ${isMobile ? '' : isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64'}`}>
          <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-30">
            <div className="flex h-16 items-center justify-between px-6">
              <Button 
                variant="ghost" 
                size="icon"
                className="lg:hidden"
                onClick={() => setIsSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>

              {isOnboarding && (
                <div className="flex-1 flex justify-center">
                  <OrganizationHeader />
                </div>
              )}

              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={toggleTheme}
                  className="text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  {isDarkMode ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                </Button>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="relative text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700">
                      <Bell className="h-5 w-5" />
                      <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center bg-green-500">2</Badge>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-80">
                    <DropdownMenuLabel className="flex items-center justify-between">
                      <span>Notificações</span>
                      <Link to={createPageUrl("Notifications")} className="text-xs text-blue-600 dark:text-blue-400 hover:underline">Ver todas</Link>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <div className="max-h-80 overflow-y-auto">
                    </div>
                  </DropdownMenuContent>
                </DropdownMenu>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <div className="flex items-center gap-2 cursor-pointer p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-green-100 dark:bg-green-800 text-green-700 dark:text-green-200">
                          {userType === "orgadmin" ? "OA" : "C"}
                        </AvatarFallback>
                      </Avatar>
                      <div className="hidden md:block">
                        <p className="text-sm font-medium text-gray-900 dark:text-white">{currentUser?.full_name || (userType === "orgadmin" ? "Org Admin" : "Comply")}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{userType === "orgadmin" ? "Administrador da Organização" : "Comply"}</p>
                      </div>
                    </div>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <div className="p-2 border-b border-gray-200 dark:border-gray-700">
                      <p className="font-medium text-gray-900 dark:text-gray-100">{currentUser?.full_name || "Usuário Demonstração"}</p>
                      <p className="text-sm text-gray-500">{currentUser?.email || "usuario@exemplo.com"}</p>
                    </div>
                    <DropdownMenuItem onClick={() => navigate(createPageUrl("UserProfile"))}>
                      <UserCog className="w-4 h-4 mr-2" />
                      Meu Perfil
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate(createPageUrl("Settings"))}>
                      <Settings className="w-4 h-4 mr-2" />
                      Configurações
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                      <LogOut className="w-4 h-4 mr-2" />
                      Sair
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </header>

          <main className="p-6 min-h-screen bg-gray-50 dark:bg-gray-900">
            {children}
          </main>

          <CopilotButton 
            onClick={() => setIsCopilotOpen(!isCopilotOpen)} 
            isOpen={isCopilotOpen} 
          />
          <AICopilot 
            isOpen={isCopilotOpen} 
            onClose={() => setIsCopilotOpen(false)} 
          />
        </div>
      </div>

      <style jsx="true">{`
        .dark {
          color-scheme: dark;
        }
        
        .dark * {
          --tw-border-opacity: 1 !important;
          border-color: rgba(55, 65, 81, var(--tw-border-opacity)) !important;
        }
        
        .dark .bg-white, 
        .dark [class*="bg-white"],
        .dark table,
        .dark tbody,
        .dark tr,
        .dark td,
        .dark th {
          background-color: rgb(31, 41, 55) !important;
          color: rgb(243, 244, 246) !important;
        }
        
        .dark table,
        .dark tbody,
        .dark tr,
        .dark td,
        .dark th {
          border-color: rgb(55, 65, 81) !important;
        }
        
        .dark input,
        .dark select,
        .dark textarea {
          background-color: rgb(31, 41, 55) !important;
          color: rgb(243, 244, 246) !important;
          border-color: rgb(75, 85, 99) !important;
        }
        
        .dark .bg-green-100 {
          background-color: rgb(22, 101, 52) !important;
        }
        
        .dark .text-green-600 {
          color: rgb(167, 243, 208) !important;
        }
      `}</style>
    </div>
  );
}

export default Layout;

