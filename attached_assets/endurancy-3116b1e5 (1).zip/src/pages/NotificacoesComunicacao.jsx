
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  Notification 
} from '@/api/entities';
import { 
  Bell, 
  Search, 
  Filter, 
  MoreHorizontal, 
  CheckCircle, 
  AlertTriangle, 
  MessageSquare, 
  Info, 
  UserPlus, 
  Calendar, 
  Clock, 
  Check, 
  X, 
  RefreshCw, 
  Settings, 
  Send, 
  Trash2, 
  ArrowLeft,
  Mail // Added Mail icon import
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsList, 
  TabsTrigger, 
  TabsContent 
} from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Spinner } from '@/components/ui/spinner';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

export default function NotificacoesComunicacao() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState([]);
  const [filteredNotifications, setFilteredNotifications] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  const [priority, setPriority] = useState('all');
  const [showSettingsDialog, setShowSettingsDialog] = useState(false);
  
  const [notificationSettings, setNotificationSettings] = useState({
    email_enabled: true,
    push_enabled: true,
    sms_enabled: false,
    sound_alerts: true,
    daily_digest: false,
    marketing_notifications: true,
    system_updates: true,
    weekly_summary: true,
    real_time_alerts: true
  });

  useEffect(() => {
    loadNotifications();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [notifications, filter, priority, searchTerm]);

  const loadNotifications = async () => {
    setLoading(true);
    try {
      // In a real app, we would fetch from database
      // const fetchedNotifications = await Notification.list();
      
      // Using mock data for now
      setTimeout(() => {
        const mockData = generateMockNotifications();
        setNotifications(mockData);
        setFilteredNotifications(mockData);
        setLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Error loading notifications', error);
      setLoading(false);
    }
  };

  const generateMockNotifications = () => {
    return [
      {
        id: '1',
        type: 'request',
        priority: 'high',
        title: 'Novo paciente aguardando aprovação',
        message: 'João Silva está aguardando aprovação para acesso ao sistema.',
        is_read: false,
        related_type: 'patient',
        related_id: 'pat_123',
        action_url: createPageUrl('Patients'),
        created_date: new Date(Date.now() - 30 * 60000).toISOString() // 30 minutes ago
      },
      {
        id: '2',
        type: 'alert',
        priority: 'high',
        title: 'Estoque baixo de produto',
        message: 'O produto "Óleo CBD 5%" está com estoque abaixo do nível mínimo.',
        is_read: false,
        related_type: 'product',
        related_id: 'prod_456',
        action_url: createPageUrl('Estoque'),
        created_date: new Date(Date.now() - 2 * 3600000).toISOString() // 2 hours ago
      },
      {
        id: '3',
        type: 'info',
        priority: 'medium',
        title: 'Nova campanha de email criada',
        message: 'A campanha "Novos produtos CBD" foi criada e está pronta para revisão.',
        is_read: true,
        related_type: 'campaign',
        related_id: 'camp_789',
        action_url: createPageUrl('CampanhasEmail'),
        created_date: new Date(Date.now() - 1 * 86400000).toISOString() // 1 day ago
      },
      {
        id: '4',
        type: 'message',
        priority: 'medium',
        title: 'Nova mensagem do paciente',
        message: 'Maria Oliveira enviou uma pergunta sobre dosagem.',
        is_read: false,
        related_type: 'message',
        related_id: 'msg_101',
        action_url: createPageUrl('CrmAtendimento'),
        created_date: new Date(Date.now() - 4 * 3600000).toISOString() // 4 hours ago
      },
      {
        id: '5',
        type: 'success',
        priority: 'low',
        title: 'Campanha enviada com sucesso',
        message: 'A campanha "Bem-vindo" foi enviada para 152 destinatários.',
        is_read: true,
        related_type: 'campaign',
        related_id: 'camp_202',
        action_url: createPageUrl('CampanhasEmail'),
        created_date: new Date(Date.now() - 2 * 86400000).toISOString() // 2 days ago
      },
      {
        id: '6',
        type: 'alert',
        priority: 'high',
        title: 'Falha no envio de notificações',
        message: 'Ocorreu um erro ao enviar notificações por e-mail aos pacientes.',
        is_read: false,
        related_type: 'system',
        related_id: 'sys_303',
        action_url: createPageUrl('Settings'),
        created_date: new Date(Date.now() - 45 * 60000).toISOString() // 45 minutes ago
      },
      {
        id: '7',
        type: 'info',
        priority: 'low',
        title: 'Atualização do sistema concluída',
        message: 'O sistema foi atualizado para a versão 2.3.4 com novos recursos.',
        is_read: true,
        related_type: 'system',
        related_id: 'sys_404',
        action_url: null,
        created_date: new Date(Date.now() - 3 * 86400000).toISOString() // 3 days ago
      }
    ];
  };

  const applyFilters = () => {
    let filtered = [...notifications];
    
    // Apply type filter
    if (filter !== 'all') {
      filtered = filtered.filter(item => item.type === filter);
    }
    
    // Apply priority filter
    if (priority !== 'all') {
      filtered = filtered.filter(item => item.priority === priority);
    }
    
    // Apply search
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(
        item => item.title.toLowerCase().includes(term) || 
               item.message.toLowerCase().includes(term)
      );
    }
    
    setFilteredNotifications(filtered);
  };

  const handleMarkAsRead = (id) => {
    setNotifications(prev => 
      prev.map(item => 
        item.id === id ? { ...item, is_read: true } : item
      )
    );
  };

  const handleMarkAllAsRead = () => {
    setNotifications(prev => 
      prev.map(item => ({ ...item, is_read: true }))
    );
  };

  const handleDelete = (id) => {
    setNotifications(prev => 
      prev.filter(item => item.id !== id)
    );
  };

  const handleClearAll = () => {
    setNotifications([]);
  };

  const handleRefresh = () => {
    loadNotifications();
  };

  const handleSettingsChange = (key, value) => {
    setNotificationSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const formatTimeAgo = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 60) {
      return `${diffMins} min atrás`;
    } else if (diffHours < 24) {
      return `${diffHours} h atrás`;
    } else if (diffDays < 7) {
      return `${diffDays} d atrás`;
    } else {
      return date.toLocaleDateString('pt-BR');
    }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'alert':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'info':
        return <Info className="h-5 w-5 text-blue-500" />;
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'message':
        return <MessageSquare className="h-5 w-5 text-purple-500" />;
      case 'request':
        return <UserPlus className="h-5 w-5 text-amber-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };

  const getPriorityBadge = (priority) => {
    switch (priority) {
      case 'high':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Alta</Badge>;
      case 'medium':
        return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">Média</Badge>;
      case 'low':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Baixa</Badge>;
      default:
        return null;
    }
  };

  const unreadCount = notifications.filter(item => !item.is_read).length;

  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <Button
            variant="ghost"
            size="sm"
            className="mb-2"
            onClick={() => navigate(createPageUrl('ModuloComunicacao'))}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar para Comunicação
          </Button>
          <h1 className="text-2xl font-bold">Notificações</h1>
          <p className="text-muted-foreground">
            Gerencie as notificações do sistema de comunicação
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            className="flex items-center"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Atualizar
          </Button>
          
          {unreadCount > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleMarkAllAsRead}
              className="flex items-center"
            >
              <Check className="mr-2 h-4 w-4" />
              Marcar todas como lidas
            </Button>
          )}
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowSettingsDialog(true)}
            className="flex items-center"
          >
            <Settings className="mr-2 h-4 w-4" />
            Configurações
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-6">
        <div className="md:col-span-1 space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Buscar</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Buscar notificações..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Tipo</Label>
                <Select value={filter} onValueChange={setFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    <SelectItem value="alert">Alertas</SelectItem>
                    <SelectItem value="info">Informações</SelectItem>
                    <SelectItem value="success">Sucessos</SelectItem>
                    <SelectItem value="message">Mensagens</SelectItem>
                    <SelectItem value="request">Solicitações</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Prioridade</Label>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a prioridade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    <SelectItem value="high">Alta</SelectItem>
                    <SelectItem value="medium">Média</SelectItem>
                    <SelectItem value="low">Baixa</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {notifications.length > 0 && (
                <Button
                  variant="ghost"
                  className="w-full mt-4 text-red-600 hover:text-red-700 hover:bg-red-50"
                  onClick={handleClearAll}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Limpar todas
                </Button>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Resumo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Total</span>
                  <span className="font-medium">{notifications.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Não lidas</span>
                  <Badge variant="secondary">{unreadCount}</Badge>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Alta prioridade</span>
                  <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                    {notifications.filter(n => n.priority === 'high').length}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Média prioridade</span>
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                    {notifications.filter(n => n.priority === 'medium').length}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Baixa prioridade</span>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    {notifications.filter(n => n.priority === 'low').length}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="md:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle>
                {filter === 'all' ? 'Todas as Notificações' : 
                 filter === 'alert' ? 'Alertas' :
                 filter === 'info' ? 'Informações' :
                 filter === 'success' ? 'Sucessos' :
                 filter === 'message' ? 'Mensagens' : 'Solicitações'}
              </CardTitle>
              <CardDescription>
                {filteredNotifications.length === 0
                  ? "Nenhuma notificação encontrada"
                  : `Mostrando ${filteredNotifications.length} ${filteredNotifications.length === 1 ? 'notificação' : 'notificações'}`}
              </CardDescription>
            </CardHeader>
            
            <ScrollArea className="h-[600px]">
              {loading ? (
                <div className="flex justify-center items-center py-20">
                  <Spinner />
                </div>
              ) : filteredNotifications.length === 0 ? (
                <div className="text-center py-20">
                  <Bell className="mx-auto h-12 w-12 text-gray-300" />
                  <h3 className="mt-4 text-lg font-medium">Nenhuma notificação</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    {searchTerm 
                      ? `Não há notificações correspondentes aos critérios de busca.` 
                      : `Não há notificações ${filter !== 'all' ? `do tipo ${filter}` : ''} para exibir.`}
                  </p>
                </div>
              ) : (
                <CardContent className="p-0">
                  {filteredNotifications.map((notification) => (
                    <div 
                      key={notification.id}
                      className={`p-4 border-b last:border-b-0 hover:bg-gray-50 ${
                        !notification.is_read ? 'bg-blue-50/50' : ''
                      }`}
                    >
                      <div className="flex gap-4">
                        <div className="flex-shrink-0 mt-1">
                          <div className="p-2 bg-white rounded-full shadow-sm">
                            {getNotificationIcon(notification.type)}
                          </div>
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium text-gray-900 mb-1">
                                {notification.title}
                              </h4>
                              <p className="text-gray-600">
                                {notification.message}
                              </p>
                            </div>
                            
                            <div className="flex items-center ml-4">
                              <div className="text-xs text-gray-500 mr-2">
                                {formatTimeAgo(notification.created_date)}
                              </div>
                              
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  {!notification.is_read && (
                                    <DropdownMenuItem onClick={() => handleMarkAsRead(notification.id)}>
                                      <Check className="mr-2 h-4 w-4" />
                                      Marcar como lida
                                    </DropdownMenuItem>
                                  )}
                                  {notification.action_url && (
                                    <DropdownMenuItem onClick={() => navigate(notification.action_url)}>
                                      <ArrowLeft className="mr-2 h-4 w-4" />
                                      Ver detalhes
                                    </DropdownMenuItem>
                                  )}
                                  <DropdownMenuItem onClick={() => handleDelete(notification.id)}>
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Excluir
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2 mt-2">
                            {getPriorityBadge(notification.priority)}
                            {!notification.is_read && (
                              <Badge className="bg-blue-50 text-blue-700 border-blue-200">
                                Nova
                              </Badge>
                            )}
                          </div>
                          
                          {notification.action_url && (
                            <div className="mt-2">
                              <Button 
                                variant="link" 
                                className="p-0 h-auto text-sm" 
                                onClick={() => navigate(notification.action_url)}
                              >
                                Ver detalhes
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              )}
            </ScrollArea>
          </Card>
        </div>
      </div>
      
      {/* Settings Dialog */}
      <Dialog open={showSettingsDialog} onOpenChange={setShowSettingsDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Configurações de Notificações</DialogTitle>
            <DialogDescription>
              Personalize como você recebe notificações do sistema de comunicação.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4 space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Canais de Notificação</h3>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-gray-500" />
                  <Label htmlFor="email-notifications">Notificações por email</Label>
                </div>
                <Switch 
                  id="email-notifications"
                  checked={notificationSettings.email_enabled}
                  onCheckedChange={(value) => handleSettingsChange('email_enabled', value)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="h-4 w-4 text-gray-500" />
                  <Label htmlFor="push-notifications">Notificações push</Label>
                </div>
                <Switch 
                  id="push-notifications"
                  checked={notificationSettings.push_enabled}
                  onCheckedChange={(value) => handleSettingsChange('push_enabled', value)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4 text-gray-500" />
                  <Label htmlFor="sms-notifications">Notificações por SMS</Label>
                </div>
                <Switch 
                  id="sms-notifications"
                  checked={notificationSettings.sms_enabled}
                  onCheckedChange={(value) => handleSettingsChange('sms_enabled', value)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="h-4 w-4 text-gray-500" />
                  <Label htmlFor="sound-alerts">Alertas sonoros</Label>
                </div>
                <Switch 
                  id="sound-alerts"
                  checked={notificationSettings.sound_alerts}
                  onCheckedChange={(value) => handleSettingsChange('sound_alerts', value)}
                />
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Preferências de Notificação</h3>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <Label htmlFor="daily-digest">Resumo diário</Label>
                </div>
                <Switch 
                  id="daily-digest"
                  checked={notificationSettings.daily_digest}
                  onCheckedChange={(value) => handleSettingsChange('daily_digest', value)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Send className="h-4 w-4 text-gray-500" />
                  <Label htmlFor="marketing-notifications">Campanhas de marketing</Label>
                </div>
                <Switch 
                  id="marketing-notifications"
                  checked={notificationSettings.marketing_notifications}
                  onCheckedChange={(value) => handleSettingsChange('marketing_notifications', value)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Settings className="h-4 w-4 text-gray-500" />
                  <Label htmlFor="system-updates">Atualizações do sistema</Label>
                </div>
                <Switch 
                  id="system-updates"
                  checked={notificationSettings.system_updates}
                  onCheckedChange={(value) => handleSettingsChange('system_updates', value)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <Label htmlFor="weekly-summary">Resumo semanal</Label>
                </div>
                <Switch 
                  id="weekly-summary"
                  checked={notificationSettings.weekly_summary}
                  onCheckedChange={(value) => handleSettingsChange('weekly_summary', value)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-gray-500" />
                  <Label htmlFor="real-time-alerts">Alertas em tempo real</Label>
                </div>
                <Switch 
                  id="real-time-alerts"
                  checked={notificationSettings.real_time_alerts}
                  onCheckedChange={(value) => handleSettingsChange('real_time_alerts', value)}
                />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSettingsDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={() => setShowSettingsDialog(false)}>
              Salvar Configurações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
