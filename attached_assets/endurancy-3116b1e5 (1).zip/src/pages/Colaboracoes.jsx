import React, { useState, useEffect } from 'react';
import { 
  Share2, 
  Plus, 
  Search, 
  Filter, 
  Building2, 
  Users, 
  Globe, 
  FileText,
  ExternalLink,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Edit,
  Trash2,
  Eye,
  CheckCircle,
  AlertTriangle,
  HandshakeIcon,
  Link
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

// Mock data
const mockColaboracoes = [
  {
    id: "c1",
    instituicao: "Universidade Federal de São Paulo",
    tipo: "pesquisa",
    status: "ativa",
    data_inicio: "2023-01-15",
    data_fim: "2024-01-15",
    descricao: "Colaboração para pesquisa sobre efeitos da cannabis no tratamento de epilepsia",
    pesquisas_relacionadas: [
      "Estudo clínico fase II - CBD em epilepsia refratária",
      "Análise de biomarcadores em pacientes tratados com cannabis"
    ],
    contato_principal: {
      nome: "Dr. Ricardo Santos",
      cargo: "Coordenador de Pesquisa",
      email: "ricardo.santos@unifesp.br",
      telefone: "(11) 9999-8888"
    },
    documentos: [
      { tipo: "Acordo de Colaboração", url: "#" },
      { tipo: "Protocolo de Pesquisa", url: "#" }
    ],
    localizacao: "São Paulo, SP",
    area_pesquisa: "Neurologia"
  },
  {
    id: "c2",
    instituicao: "Hospital Albert Einstein",
    tipo: "clinica",
    status: "ativa",
    data_inicio: "2023-03-01",
    data_fim: "2024-03-01",
    descricao: "Parceria para desenvolvimento de protocolos clínicos em dor crônica",
    pesquisas_relacionadas: [
      "Avaliação de eficácia em dor neuropática",
      "Estudo de qualidade de vida em pacientes com dor crônica"
    ],
    contato_principal: {
      nome: "Dra. Maria Oliveira",
      cargo: "Diretora Clínica",
      email: "maria.oliveira@einstein.br",
      telefone: "(11) 7777-6666"
    },
    documentos: [
      { tipo: "Termo de Cooperação", url: "#" },
      { tipo: "Protocolos Clínicos", url: "#" }
    ],
    localizacao: "São Paulo, SP",
    area_pesquisa: "Dor Crônica"
  },
  {
    id: "c3",
    instituicao: "Instituto de Pesquisas Cannábicas",
    tipo: "desenvolvimento",
    status: "em_negociacao",
    data_inicio: "2023-06-01",
    descricao: "Desenvolvimento conjunto de novos produtos e formulações",
    pesquisas_relacionadas: [
      "Desenvolvimento de novas formulações de CBD",
      "Estudos de estabilidade de produtos"
    ],
    contato_principal: {
      nome: "Dr. João Lima",
      cargo: "Diretor de P&D",
      email: "joao.lima@ipc.org",
      telefone: "(11) 5555-4444"
    },
    documentos: [
      { tipo: "Proposta de Colaboração", url: "#" }
    ],
    localizacao: "Campinas, SP",
    area_pesquisa: "Desenvolvimento de Produtos"
  }
];

export default function Colaboracoes() {
  const [colaboracoes, setColaboracoes] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [tipoFilter, setTipoFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadColaboracoes = async () => {
      setIsLoading(true);
      try {
        // Simular delay de API
        await new Promise(resolve => setTimeout(resolve, 1000));
        setColaboracoes(mockColaboracoes);
      } catch (error) {
        console.error("Erro ao carregar colaborações:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadColaboracoes();
  }, []);

  const statusColors = {
    ativa: "bg-green-100 text-green-800",
    em_negociacao: "bg-yellow-100 text-yellow-800",
    concluida: "bg-blue-100 text-blue-800",
    cancelada: "bg-red-100 text-red-800"
  };

  const tipoColors = {
    pesquisa: "bg-purple-100 text-purple-800",
    clinica: "bg-blue-100 text-blue-800",
    desenvolvimento: "bg-indigo-100 text-indigo-800"
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const filteredColaboracoes = colaboracoes.filter(colaboracao => {
    const matchesSearch = colaboracao.instituicao.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         colaboracao.descricao.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTipo = tipoFilter === 'all' || colaboracao.tipo === tipoFilter;
    const matchesStatus = statusFilter === 'all' || colaboracao.status === statusFilter;
    return matchesSearch && matchesTipo && matchesStatus;
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Colaborações</h1>
          <p className="text-muted-foreground">Gerencie as colaborações e parcerias institucionais</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">
          <Plus className="w-4 h-4 mr-2" />
          Nova Colaboração
        </Button>
      </div>

      {/* Filtros e Busca */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar colaborações..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={tipoFilter} onValueChange={setTipoFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Tipos</SelectItem>
            <SelectItem value="pesquisa">Pesquisa</SelectItem>
            <SelectItem value="clinica">Clínica</SelectItem>
            <SelectItem value="desenvolvimento">Desenvolvimento</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Status</SelectItem>
            <SelectItem value="ativa">Ativa</SelectItem>
            <SelectItem value="em_negociacao">Em Negociação</SelectItem>
            <SelectItem value="concluida">Concluída</SelectItem>
            <SelectItem value="cancelada">Cancelada</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Lista de Colaborações */}
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 rounded"></div>
                  <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredColaboracoes.map((colaboracao) => (
            <Card key={colaboracao.id} className="overflow-hidden hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="flex items-center gap-2">
                      <Building2 className="w-5 h-5 text-gray-500" />
                      {colaboracao.instituicao}
                    </CardTitle>
                    <CardDescription className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      {colaboracao.localizacao}
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Badge className={tipoColors[colaboracao.tipo]}>
                      {colaboracao.tipo.charAt(0).toUpperCase() + colaboracao.tipo.slice(1)}
                    </Badge>
                    <Badge className={statusColors[colaboracao.status]}>
                      {colaboracao.status === 'em_negociacao' ? 'Em Negociação' : 
                       colaboracao.status.charAt(0).toUpperCase() + colaboracao.status.slice(1)}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-sm text-gray-600">{colaboracao.descricao}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        Data de Início
                      </h4>
                      <p className="text-sm">{formatDate(colaboracao.data_inicio)}</p>
                    </div>
                    
                    {colaboracao.data_fim && (
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          Data de Término
                        </h4>
                        <p className="text-sm">{formatDate(colaboracao.data_fim)}</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      Contato Principal
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <div className="flex items-center gap-2 text-sm">
                        <span className="font-medium">{colaboracao.contato_principal.nome}</span>
                        <span className="text-gray-500">({colaboracao.contato_principal.cargo})</span>
                      </div>
                      <div className="flex items-center gap-4 text-sm">
                        <a href={`mailto:${colaboracao.contato_principal.email}`} className="flex items-center gap-1 text-blue-600 hover:text-blue-800">
                          <Mail className="w-4 h-4" />
                          Email
                        </a>
                        <a href={`tel:${colaboracao.contato_principal.telefone}`} className="flex items-center gap-1 text-blue-600 hover:text-blue-800">
                          <Phone className="w-4 h-4" />
                          Telefone
                        </a>
                      </div>
                    </div>
                  </div>

                  {colaboracao.pesquisas_relacionadas.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium flex items-center gap-2">
                        <FileText className="w-4 h-4" />
                        Pesquisas Relacionadas
                      </h4>
                      <ul className="list-disc list-inside text-sm text-gray-600">
                        {colaboracao.pesquisas_relacionadas.map((pesquisa, index) => (
                          <li key={index}>{pesquisa}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 dark:bg-gray-800/50">
                <div className="flex justify-between items-center w-full">
                  <div className="flex gap-2">
                    {colaboracao.documentos.map((doc, index) => (
                      <Button key={index} variant="outline" size="sm" className="flex items-center gap-2">
                        <FileText className="w-4 h-4" />
                        {doc.tipo}
                        <ExternalLink className="w-3 h-3" />
                      </Button>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-red-600">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}