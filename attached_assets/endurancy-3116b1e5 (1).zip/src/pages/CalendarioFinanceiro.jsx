
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Download,
  FileText,
  Plus,
  Trash,
  Edit,
  Bell,
  Link as LinkIcon,
  ExternalLink,
  Check,
  ArrowUpRight,
  User,
  Building2,
  DollarSign,
  FileBarChart,
  CreditCard,
  AlarmClock,
  Flag,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { format, isToday, isWithinInterval, addDays, eachDayOfInterval, parseISO, isSameDay, addMonths, getDay, getDate, startOfMonth, endOfMonth, getMonth, getYear, endOfDay, startOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from '@/components/ui/use-toast';

// Define a simple utility function to combine class names
function classNames(...classes) {
  return classes.filter(Boolean).join(' ');
}

// Componente auxiliar de seleção de data e hora
const DateTimePicker = ({ date, setDate }) => {
  const [selectedTime, setSelectedTime] = useState(date ? format(date, 'HH:mm') : '09:00');

  useEffect(() => {
    if (date && selectedTime) {
      const [hours, minutes] = selectedTime.split(':').map(Number);
      const newDate = new Date(date);
      newDate.setHours(hours);
      newDate.setMinutes(minutes);
      setDate(newDate);
    }
  }, [selectedTime]);

  const handleDateSelect = (newDate) => {
    if (!newDate) return;
    
    const hours = date ? date.getHours() : 9;
    const minutes = date ? date.getMinutes() : 0;
    
    const updatedDate = new Date(newDate);
    updatedDate.setHours(hours);
    updatedDate.setMinutes(minutes);
    
    setDate(updatedDate);
  };

  return (
    <div className="space-y-2">
      <div className="grid gap-2">
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={classNames(
                "justify-start text-left font-normal w-full",
                !date && "text-muted-foreground"
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {date ? format(date, "PPP", { locale: ptBR }) : "Selecione a data"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <Calendar
              mode="single"
              selected={date}
              onSelect={handleDateSelect}
              initialFocus
              locale={ptBR}
            />
          </PopoverContent>
        </Popover>
      </div>
      
      <div className="grid gap-2">
        <Label htmlFor="time">Horário</Label>
        <Input 
          id="time" 
          type="time" 
          value={selectedTime}
          onChange={(e) => setSelectedTime(e.target.value)}
        />
      </div>
    </div>
  );
};

export default function CalendarioFinanceiro() {
  const navigate = useNavigate();
  const [date, setDate] = useState(new Date());
  const [viewMode, setViewMode] = useState('month');
  const [events, setEvents] = useState([]);
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [showEventDetails, setShowEventDetails] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [newEvent, setNewEvent] = useState({
    title: '',
    description: '',
    startDate: new Date(),
    endDate: new Date(),
    type: 'meeting',
    location: '',
    participants: '',
    reminders: ['30min'],
    color: 'green',
    isAllDay: false,
    isRecurring: false,
    recurrencePattern: 'none',
    syncWithExternalCalendar: false,
    attachments: [],
    completed: false
  });
  const [filterType, setFilterType] = useState('all');
  const [showCompleted, setShowCompleted] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [exportFormat, setExportFormat] = useState('ical');
  const [calendarRangeText, setCalendarRangeText] = useState('');
  
  const eventTypes = [
    { value: 'meeting', label: 'Reunião', icon: <User className="w-4 h-4" /> },
    { value: 'deadline', label: 'Prazo', icon: <Flag className="w-4 h-4" /> },
    { value: 'report', label: 'Relatório', icon: <FileBarChart className="w-4 h-4" /> },
    { value: 'tax', label: 'Obrigação Fiscal', icon: <Building2 className="w-4 h-4" /> },
    { value: 'payment', label: 'Pagamento', icon: <CreditCard className="w-4 h-4" /> },
    { value: 'review', label: 'Revisão Financeira', icon: <DollarSign className="w-4 h-4" /> },
    { value: 'other', label: 'Outro', icon: <FileText className="w-4 h-4" /> }
  ];
  
  const reminderOptions = [
    { value: 'none', label: 'Sem lembrete' },
    { value: '5min', label: '5 minutos antes' },
    { value: '15min', label: '15 minutos antes' },
    { value: '30min', label: '30 minutos antes' },
    { value: '1hour', label: '1 hora antes' },
    { value: '2hours', label: '2 horas antes' },
    { value: '1day', label: '1 dia antes' },
    { value: '2days', label: '2 dias antes' },
    { value: '1week', label: '1 semana antes' }
  ];
  
  const colorOptions = [
    { value: 'green', label: 'Verde', class: 'bg-green-500' },
    { value: 'blue', label: 'Azul', class: 'bg-blue-500' },
    { value: 'red', label: 'Vermelho', class: 'bg-red-500' },
    { value: 'yellow', label: 'Amarelo', class: 'bg-yellow-500' },
    { value: 'purple', label: 'Roxo', class: 'bg-purple-500' },
    { value: 'gray', label: 'Cinza', class: 'bg-gray-500' }
  ];
  
  const recurrencePatterns = [
    { value: 'none', label: 'Sem recorrência' },
    { value: 'daily', label: 'Diariamente' },
    { value: 'weekly', label: 'Semanalmente' },
    { value: 'biweekly', label: 'Quinzenalmente' },
    { value: 'monthly', label: 'Mensalmente' },
    { value: 'quarterly', label: 'Trimestralmente' },
    { value: 'yearly', label: 'Anualmente' }
  ];
  
  const sampleEvents = [
    {
      id: '1',
      title: 'Reunião Mensal de Resultados',
      description: 'Apresentação dos resultados financeiros do mês e análise de KPIs',
      startDate: addDays(new Date(), 2).setHours(10, 0, 0, 0),
      endDate: addDays(new Date(), 2).setHours(11, 30, 0, 0),
      type: 'meeting',
      location: 'Sala de Conferência',
      participants: 'Diretor Financeiro, Contadores, Gerentes',
      reminders: ['1day', '1hour'],
      color: 'blue',
      isAllDay: false,
      isRecurring: true,
      recurrencePattern: 'monthly',
      syncWithExternalCalendar: true,
      attachments: ['relatorio_preliminar.pdf'],
      completed: false
    },
    {
      id: '2',
      title: 'Prazo Final - Imposto de Renda',
      description: 'Data limite para entrega da declaração anual do IR',
      startDate: addDays(new Date(), 5).setHours(23, 59, 0, 0),
      endDate: addDays(new Date(), 5).setHours(23, 59, 0, 0),
      type: 'tax',
      location: '',
      participants: 'Departamento Fiscal, Contador',
      reminders: ['1week', '2days'],
      color: 'red',
      isAllDay: true,
      isRecurring: true,
      recurrencePattern: 'yearly',
      syncWithExternalCalendar: true,
      attachments: [],
      completed: false
    },
    {
      id: '3',
      title: 'Pagamento de Fornecedores',
      description: 'Processamento de pagamentos para fornecedores principais',
      startDate: addDays(new Date(), -1).setHours(14, 0, 0, 0),
      endDate: addDays(new Date(), -1).setHours(16, 0, 0, 0),
      type: 'payment',
      location: '',
      participants: 'Contas a Pagar',
      reminders: ['1day'],
      color: 'green',
      isAllDay: false,
      isRecurring: true,
      recurrencePattern: 'biweekly',
      syncWithExternalCalendar: false,
      attachments: ['lista_pagamentos.xlsx'],
      completed: true
    },
    {
      id: '4',
      title: 'Revisão de Orçamento Trimestral',
      description: 'Análise de desempenho do orçamento e realização de ajustes',
      startDate: addDays(new Date(), 7).setHours(9, 0, 0, 0),
      endDate: addDays(new Date(), 7).setHours(12, 0, 0, 0),
      type: 'review',
      location: 'Sala de Reuniões 2',
      participants: 'Diretoria, Gerentes de Departamento',
      reminders: ['2days'],
      color: 'purple',
      isAllDay: false,
      isRecurring: true,
      recurrencePattern: 'quarterly',
      syncWithExternalCalendar: true,
      attachments: [],
      completed: false
    },
    {
      id: '5',
      title: 'Fechamento Contábil',
      description: 'Fechamento contábil do mês anterior',
      startDate: new Date().setHours(9, 0, 0, 0),
      endDate: new Date().setHours(18, 0, 0, 0),
      type: 'deadline',
      location: '',
      participants: 'Equipe Contábil',
      reminders: ['1day'],
      color: 'yellow',
      isAllDay: true,
      isRecurring: true,
      recurrencePattern: 'monthly',
      syncWithExternalCalendar: false,
      attachments: [],
      completed: false
    },
    {
      id: '6',
      title: 'Relatório DRE',
      description: 'Preparação do relatório de Demonstração de Resultados',
      startDate: addDays(new Date(), 3).setHours(13, 0, 0, 0),
      endDate: addDays(new Date(), 3).setHours(15, 0, 0, 0),
      type: 'report',
      location: '',
      participants: 'Analista Financeiro, Contador',
      reminders: ['1day'],
      color: 'blue',
      isAllDay: false,
      isRecurring: true,
      recurrencePattern: 'monthly',
      syncWithExternalCalendar: true,
      attachments: ['modelo_dre.xlsx'],
      completed: false
    }
  ];
  
  useEffect(() => {
    setEvents(sampleEvents);
    updateCalendarRangeText(date, viewMode);
  }, []);
  
  useEffect(() => {
    updateCalendarRangeText(date, viewMode);
  }, [date, viewMode]);
  
  const updateCalendarRangeText = (date, mode) => {
    if (mode === 'month') {
      setCalendarRangeText(format(date, 'MMMM yyyy', { locale: ptBR }));
    } else if (mode === 'week') {
      const start = addDays(date, -getDay(date));
      const end = addDays(start, 6);
      setCalendarRangeText(`${format(start, 'dd/MM', { locale: ptBR })} - ${format(end, 'dd/MM/yyyy', { locale: ptBR })}`);
    } else if (mode === 'day') {
      setCalendarRangeText(format(date, 'EEEE, dd MMMM yyyy', { locale: ptBR }));
    }
  };
  
  const goToPrevious = () => {
    if (viewMode === 'month') {
      setDate(prevDate => addMonths(prevDate, -1));
    } else if (viewMode === 'week') {
      setDate(prevDate => addDays(prevDate, -7));
    } else if (viewMode === 'day') {
      setDate(prevDate => addDays(prevDate, -1));
    }
  };
  
  const goToNext = () => {
    if (viewMode === 'month') {
      setDate(prevDate => addMonths(prevDate, 1));
    } else if (viewMode === 'week') {
      setDate(prevDate => addDays(prevDate, 7));
    } else if (viewMode === 'day') {
      setDate(prevDate => addDays(prevDate, 1));
    }
  };
  
  const goToToday = () => {
    setDate(new Date());
  };
  
  const getFilteredEvents = () => {
    return events.filter(event => {
      const typeMatch = filterType === 'all' || event.type === filterType;
      const completionMatch = showCompleted || !event.completed;
      const searchMatch = !searchTerm || 
        event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.description.toLowerCase().includes(searchTerm.toLowerCase());
      return typeMatch && completionMatch && searchMatch;
    });
  };
  
  const getMonthEvents = () => {
    const filteredEvents = getFilteredEvents();
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(date);
    
    return filteredEvents.filter(event => {
      const eventStart = new Date(event.startDate);
      return isWithinInterval(eventStart, { start: monthStart, end: monthEnd });
    });
  };
  
  const hasEventsOnDay = (day) => {
    const filteredEvents = getFilteredEvents();
    return filteredEvents.some(event => {
      const eventDate = new Date(event.startDate);
      return isSameDay(eventDate, day);
    });
  };
  
  const getEventsForDay = (day) => {
    const filteredEvents = getFilteredEvents();
    return filteredEvents.filter(event => {
      const eventDate = new Date(event.startDate);
      return isSameDay(eventDate, day);
    }).sort((a, b) => new Date(a.startDate) - new Date(b.startDate));
  };
  
  const getEventColor = (colorName) => {
    const colorOption = colorOptions.find(option => option.value === colorName);
    return colorOption ? colorOption.class : 'bg-gray-500';
  };
  
  const renderMonthCalendar = () => {
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(date);
    const startDate = addDays(monthStart, -getDay(monthStart));
    const endDate = addDays(monthEnd, 6 - getDay(monthEnd));
    
    const days = eachDayOfInterval({ start: startDate, end: endDate });
    const weeks = [];
    
    for (let i = 0; i < days.length; i += 7) {
      weeks.push(days.slice(i, i + 7));
    }
    
    return (
      <div className="border rounded-md overflow-hidden bg-white dark:bg-gray-800">
        <div className="grid grid-cols-7 border-b">
          {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((day, index) => (
            <div key={index} className="p-2 text-center text-sm font-medium">
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 auto-rows-fr">
          {weeks.flat().map((day, index) => {
            const isCurrentMonth = getMonth(day) === getMonth(date);
            const isTodayDate = isToday(day);
            const dayEvents = getEventsForDay(day);
            
            return (
              <div 
                key={index} 
                className={classNames(
                  "min-h-24 p-1 border flex flex-col",
                  !isCurrentMonth && "bg-gray-50 dark:bg-gray-900/30 text-gray-400",
                  isTodayDate && "bg-blue-50 dark:bg-blue-900/20"
                )}
                onClick={() => {
                  setDate(day);
                  setViewMode('day');
                }}
              >
                <div className={classNames(
                  "flex justify-center items-center h-6 w-6 rounded-full text-sm mx-auto mb-1",
                  isTodayDate ? "bg-blue-600 text-white" : "hover:bg-gray-200 dark:hover:bg-gray-700"
                )}>
                  {getDate(day)}
                </div>
                <div className="flex-1 overflow-y-auto">
                  {dayEvents.slice(0, 3).map((event, idx) => (
                    <div 
                      key={idx} 
                      className={classNames(
                        "text-xs rounded px-1 py-0.5 mb-1 truncate cursor-pointer",
                        getEventColor(event.color),
                        "text-white"
                      )}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedEvent(event);
                        setShowEventDetails(true);
                      }}
                    >
                      {event.isAllDay ? '● ' : `${format(new Date(event.startDate), 'HH:mm')} `}
                      {event.title}
                      {event.completed && ' ✓'}
                    </div>
                  ))}
                  {dayEvents.length > 3 && (
                    <div className="text-xs text-center text-gray-500">
                      +{dayEvents.length - 3} mais
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };
  
  const renderWeekCalendar = () => {
    const startDate = addDays(date, -getDay(date));
    const endDate = addDays(startDate, 6);
    const days = eachDayOfInterval({ start: startDate, end: endDate });
    
    const hours = Array.from({ length: 24 }, (_, i) => i);
    
    return (
      <div className="border rounded-md overflow-hidden bg-white dark:bg-gray-800">
        <div className="grid grid-cols-8 border-b">
          <div className="p-2 text-center text-sm font-medium border-r">
            Hora
          </div>
          {days.map((day, index) => (
            <div 
              key={index} 
              className={classNames(
                "p-2 text-center text-sm font-medium",
                isToday(day) && "bg-blue-50 dark:bg-blue-900/20"
              )}
            >
              <div>{format(day, 'EEE', { locale: ptBR })}</div>
              <div className={classNames(
                "flex justify-center items-center h-6 w-6 rounded-full mx-auto",
                isToday(day) ? "bg-blue-600 text-white" : ""
              )}>
                {getDate(day)}
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-8">
          <div className="border-r">
            {hours.map(hour => (
              <div key={hour} className="border-b p-1 h-12 text-xs text-center">
                {hour}:00
              </div>
            ))}
          </div>
          {days.map((day, dayIndex) => (
            <div key={dayIndex} className="relative">
              {hours.map(hour => (
                <div 
                  key={hour} 
                  className={classNames(
                    "border-b border-r p-1 h-12",
                    isToday(day) && "bg-blue-50/50 dark:bg-blue-900/10"
                  )}
                  onClick={() => {
                    const newDate = new Date(day);
                    newDate.setHours(hour);
                    setDate(newDate);
                    setViewMode('day');
                  }}
                ></div>
              ))}
              
              <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
                {getEventsForDay(day).map((event, idx) => {
                  if (event.isAllDay) return null;
                  
                  const eventStart = new Date(event.startDate);
                  const eventEnd = new Date(event.endDate);
                  const startHour = eventStart.getHours() + (eventStart.getMinutes() / 60);
                  const endHour = eventEnd.getHours() + (eventEnd.getMinutes() / 60);
                  const duration = endHour - startHour;
                  
                  return (
                    <div 
                      key={idx}
                      className={classNames(
                        "absolute text-xs rounded px-1 py-0.5 truncate cursor-pointer pointer-events-auto overflow-hidden",
                        getEventColor(event.color),
                        "text-white"
                      )}
                      style={{
                        top: `${startHour * 48}px`,
                        height: `${duration * 48}px`,
                        left: '4px',
                        right: '4px',
                        zIndex: 10
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedEvent(event);
                        setShowEventDetails(true);
                      }}
                    >
                      <div className="font-medium">
                        {format(eventStart, 'HH:mm')} - {format(eventEnd, 'HH:mm')}
                      </div>
                      <div>{event.title}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };
  
  const renderDayCalendar = () => {
    const hours = Array.from({ length: 24 }, (_, i) => i);
    const dayEvents = getEventsForDay(date);
    const allDayEvents = dayEvents.filter(event => event.isAllDay);
    const timedEvents = dayEvents.filter(event => !event.isAllDay);
    
    return (
      <div className="border rounded-md overflow-hidden bg-white dark:bg-gray-800">
        <div className="p-4 text-center border-b">
          <h2 className="text-xl font-bold">
            {format(date, 'EEEE, dd MMMM yyyy', { locale: ptBR })}
            {isToday(date) && <Badge className="ml-2 bg-blue-500">Hoje</Badge>}
          </h2>
        </div>
        
        {allDayEvents.length > 0 && (
          <div className="p-2 border-b">
            <div className="text-sm font-medium mb-2">Eventos de dia inteiro:</div>
            <div className="space-y-1">
              {allDayEvents.map((event, idx) => (
                <div 
                  key={idx}
                  className={classNames(
                    "rounded px-2 py-1 cursor-pointer flex items-center gap-2",
                    getEventColor(event.color),
                    "text-white"
                  )}
                  onClick={() => {
                    setSelectedEvent(event);
                    setShowEventDetails(true);
                  }}
                >
                  {event.completed && <Check className="w-4 h-4" />}
                  <div className="flex-1">
                    <div className="font-medium">{event.title}</div>
                    <div className="text-xs opacity-90">{event.type}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-12">
          <div className="col-span-1 border-r">
            {hours.map(hour => (
              <div key={hour} className="border-b p-1 h-20 text-xs text-right pr-2">
                {hour}:00
              </div>
            ))}
          </div>
          
          <div className="col-span-11 relative">
            {hours.map(hour => (
              <div 
                key={hour} 
                className="border-b p-1 h-20"
                onClick={() => {
                  const newDate = new Date(date);
                  newDate.setHours(hour);
                  setNewEvent({
                    ...newEvent,
                    startDate: newDate,
                    endDate: new Date(newDate.getTime() + 60 * 60 * 1000)
                  });
                  setShowAddEvent(true);
                }}
              ></div>
            ))}
            
            <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
              {timedEvents.map((event, idx) => {
                const eventStart = new Date(event.startDate);
                const eventEnd = new Date(event.endDate);
                const startHour = eventStart.getHours() + (eventStart.getMinutes() / 60);
                const endHour = eventEnd.getHours() + (eventEnd.getMinutes() / 60);
                const duration = endHour - startHour;
                
                return (
                  <div 
                    key={idx}
                    className={classNames(
                      "absolute rounded px-2 py-1 truncate cursor-pointer pointer-events-auto overflow-auto",
                      getEventColor(event.color),
                      "text-white"
                    )}
                    style={{
                      top: `${startHour * 80}px`,
                      height: `${duration * 80}px`,
                      left: '8px',
                      right: '8px',
                      minHeight: '24px',
                      zIndex: 10
                    }}
                    onClick={() => {
                      setSelectedEvent(event);
                      setShowEventDetails(true);
                    }}
                  >
                    <div className="font-medium flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {format(eventStart, 'HH:mm')} - {format(eventEnd, 'HH:mm')}
                      {event.completed && <Check className="w-4 h-4 ml-auto" />}
                    </div>
                    <div className="font-bold">{event.title}</div>
                    <div className="text-xs mt-1 opacity-90">{event.location}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  const renderUpcomingEvents = () => {
    const filteredEvents = getFilteredEvents();
    const today = new Date();
    const upcomingEvents = filteredEvents
      .filter(event => new Date(event.startDate) >= startOfDay(today))
      .sort((a, b) => new Date(a.startDate) - new Date(b.startDate))
      .slice(0, 5);
    
    return (
      <Card>
        <CardHeader>
          <CardTitle>Próximos Eventos</CardTitle>
        </CardHeader>
        <CardContent>
          {upcomingEvents.length === 0 ? (
            <div className="text-center py-4 text-gray-500">
              Nenhum evento próximo encontrado.
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingEvents.map((event, idx) => {
                const eventStart = new Date(event.startDate);
                const isToday = isSameDay(eventStart, today);
                
                return (
                  <div 
                    key={idx} 
                    className="flex items-start p-2 rounded-md border cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800"
                    onClick={() => {
                      setSelectedEvent(event);
                      setShowEventDetails(true);
                    }}
                  >
                    <div className={classNames(
                      "w-3 h-3 mt-1.5 mr-3 rounded-full flex-shrink-0",
                      getEventColor(event.color)
                    )}></div>
                    <div className="flex-1">
                      <div className="font-medium">{event.title}</div>
                      <div className="text-xs mt-1 flex items-center gap-1">
                        <CalendarIcon className="w-3 h-3" />
                        {isToday ? 'Hoje' : format(eventStart, 'dd/MM/yyyy')}
                        {!event.isAllDay && (
                          <span className="flex items-center gap-1 ml-2">
                            <Clock className="w-3 h-3" />
                            {format(eventStart, 'HH:mm')}
                          </span>
                        )}
                      </div>
                      {event.location && (
                        <div className="text-xs mt-1 text-gray-500">
                          {event.location}
                        </div>
                      )}
                    </div>
                    {event.completed && (
                      <Badge className="ml-2 bg-green-500">Concluído</Badge>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    );
  };
  
  const handleExport = () => {
    toast({
      title: "Calendário exportado",
      description: `Eventos exportados em formato ${exportFormat.toUpperCase()}`,
    });
  };
  
  const handleAddEvent = () => {
    const newId = (Math.max(...events.map(e => parseInt(e.id))) + 1).toString();
    
    setEvents([
      ...events,
      {
        ...newEvent,
        id: newId
      }
    ]);
    
    setShowAddEvent(false);
    setNewEvent({
      title: '',
      description: '',
      startDate: new Date(),
      endDate: new Date(),
      type: 'meeting',
      location: '',
      participants: '',
      reminders: ['30min'],
      color: 'green',
      isAllDay: false,
      isRecurring: false,
      recurrencePattern: 'none',
      syncWithExternalCalendar: false,
      attachments: [],
      completed: false
    });
    
    toast({
      title: "Evento adicionado",
      description: "O evento foi adicionado com sucesso ao calendário.",
    });
  };
  
  const handleUpdateEvent = () => {
    if (!selectedEvent) return;
    
    setEvents(
      events.map(event => 
        event.id === selectedEvent.id ? selectedEvent : event
      )
    );
    
    setShowEventDetails(false);
    setSelectedEvent(null);
    
    toast({
      title: "Evento atualizado",
      description: "As alterações foram salvas com sucesso.",
    });
  };
  
  const handleDeleteEvent = () => {
    if (!selectedEvent) return;
    
    setEvents(
      events.filter(event => event.id !== selectedEvent.id)
    );
    
    setShowEventDetails(false);
    setSelectedEvent(null);
    
    toast({
      title: "Evento excluído",
      description: "O evento foi removido do calendário.",
    });
  };
  
  const handleToggleComplete = () => {
    if (!selectedEvent) return;
    
    const updatedEvent = {
      ...selectedEvent,
      completed: !selectedEvent.completed
    };
    
    setSelectedEvent(updatedEvent);
    
    setEvents(
      events.map(event => 
        event.id === selectedEvent.id ? updatedEvent : event
      )
    );
    
    toast({
      title: updatedEvent.completed ? "Evento concluído" : "Evento reaberto",
      description: updatedEvent.completed ? 
        "O evento foi marcado como concluído." : 
        "O evento foi marcado como não concluído.",
    });
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Calendário Financeiro</h1>
          <p className="text-gray-500 mt-1">
            Gerencie eventos, reuniões e prazos financeiros importantes
          </p>
        </div>
        
        <div className="flex gap-2">
          <Select value={exportFormat} onValueChange={setExportFormat}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Formato" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ical">iCalendar</SelectItem>
              <SelectItem value="csv">CSV</SelectItem>
              <SelectItem value="pdf">PDF</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="gap-2" onClick={handleExport}>
            <Download className="w-4 h-4" />
            Exportar
          </Button>
          
          <Button className="gap-2" onClick={() => {
            setNewEvent({
              ...newEvent,
              startDate: date,
              endDate: new Date(date.getTime() + 60 * 60 * 1000)
            });
            setShowAddEvent(true);
          }}>
            <Plus className="w-4 h-4" />
            Novo Evento
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-6">
          <div className="flex flex-wrap justify-between items-center gap-4 bg-white dark:bg-gray-800 p-4 rounded-md border">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={goToPrevious}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" onClick={goToToday}>
                Hoje
              </Button>
              <Button variant="outline" size="icon" onClick={goToNext}>
                <ChevronRight className="w-4 h-4" />
              </Button>
              <div className="text-lg font-medium ml-2">
                {calendarRangeText}
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Select value={viewMode} onValueChange={setViewMode}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="Visualização" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="month">Mês</SelectItem>
                  <SelectItem value="week">Semana</SelectItem>
                  <SelectItem value="day">Dia</SelectItem>
                </SelectContent>
              </Select>
              
              <Input
                type="text"
                placeholder="Buscar eventos..."
                className="w-[200px]"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 bg-white dark:bg-gray-800 p-4 rounded-md border">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtrar por tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                {eventTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value} className="flex items-center gap-2">
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div className="flex items-center gap-2">
              <Checkbox 
                id="show-completed" 
                checked={showCompleted}
                onCheckedChange={setShowCompleted}
              />
              <Label htmlFor="show-completed">Mostrar concluídos</Label>
            </div>
          </div>
          
          {viewMode === 'month' && renderMonthCalendar()}
          {viewMode === 'week' && renderWeekCalendar()}
          {viewMode === 'day' && renderDayCalendar()}
        </div>
        
        <div className="space-y-6">
          {renderUpcomingEvents()}
          
          <Card>
            <CardHeader>
              <CardTitle>Integração</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Sincronizar com:</Label>
                <div className="flex flex-col space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="google" />
                    <Label htmlFor="google" className="flex items-center gap-2">
                      <span>Google Calendar</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="outlook" />
                    <Label htmlFor="outlook" className="flex items-center gap-2">
                      <span>Microsoft Outlook</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="apple" />
                    <Label htmlFor="apple" className="flex items-center gap-2">
                      <span>Apple Calendar</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </Label>
                  </div>
                </div>
              </div>
              
              <div className="pt-2">
                <Button variant="outline" className="w-full">
                  <LinkIcon className="w-4 h-4 mr-2" />
                  Configurar Integrações
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Categorias</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {eventTypes.map((type) => (
                  <div key={type.value} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {type.icon}
                      <span>{type.label}</span>
                    </div>
                    <div className="h-3 w-3 rounded-full bg-gray-200"></div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Dialog open={showAddEvent} onOpenChange={setShowAddEvent}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Adicionar Evento</DialogTitle>
            <DialogDescription>
              Preencha os dados do evento financeiro.
            </DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="basic">
            <TabsList className="w-full">
              <TabsTrigger value="basic" className="flex-1">Básico</TabsTrigger>
              <TabsTrigger value="details" className="flex-1">Detalhes</TabsTrigger>
              <TabsTrigger value="reminders" className="flex-1">Lembretes</TabsTrigger>
            </TabsList>
            
            <TabsContent value="basic" className="space-y-4 py-4">
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="title">Título</Label>
                  <Input 
                    id="title" 
                    placeholder="Título do evento" 
                    value={newEvent.title}
                    onChange={(e) => setNewEvent({...newEvent, title: e.target.value})}
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea 
                    id="description" 
                    placeholder="Descrição do evento" 
                    value={newEvent.description}
                    onChange={(e) => setNewEvent({...newEvent, description: e.target.value})}
                  />
                </div>
                
                <div className="flex items-center gap-2">
                  <Checkbox 
                    id="all-day" 
                    checked={newEvent.isAllDay}
                    onCheckedChange={(checked) => setNewEvent({...newEvent, isAllDay: !!checked})}
                  />
                  <Label htmlFor="all-day">Evento de dia inteiro</Label>
                </div>
                
                <div className="grid gap-2">
                  <Label>Data e hora de início</Label>
                  <DateTimePicker 
                    date={newEvent.startDate} 
                    setDate={(date) => setNewEvent({...newEvent, startDate: date})} 
                  />
                </div>
                
                {!newEvent.isAllDay && (
                  <div className="grid gap-2">
                    <Label>Data e hora de término</Label>
                    <DateTimePicker 
                      date={newEvent.endDate} 
                      setDate={(date) => setNewEvent({...newEvent, endDate: date})} 
                    />
                  </div>
                )}
                
                <div className="grid gap-2">
                  <Label htmlFor="type">Tipo de evento</Label>
                  <Select 
                    value={newEvent.type}
                    onValueChange={(value) => setNewEvent({...newEvent, type: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {eventTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center gap-2">
                            {type.icon}
                            <span>{type.label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="color">Cor</Label>
                  <Select 
                    value={newEvent.color}
                    onValueChange={(value) => setNewEvent({...newEvent, color: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a cor" />
                    </SelectTrigger>
                    <SelectContent>
                      {colorOptions.map((color) => (
                        <SelectItem key={color.value} value={color.value}>
                          <div className="flex items-center gap-2">
                            <div className={`w-4 h-4 rounded-full ${color.class}`}></div>
                            <span>{color.label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="details" className="space-y-4 py-4">
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="location">Local</Label>
                  <Input 
                    id="location" 
                    placeholder="Local do evento" 
                    value={newEvent.location}
                    onChange={(e) => setNewEvent({...newEvent, location: e.target.value})}
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="participants">Participantes</Label>
                  <Textarea 
                    id="participants" 
                    placeholder="Nomes dos participantes" 
                    value={newEvent.participants}
                    onChange={(e) => setNewEvent({...newEvent, participants: e.target.value})}
                  />
                </div>
                
                <div className="flex items-center gap-2">
                  <Checkbox 
                    id="recurring" 
                    checked={newEvent.isRecurring}
                    onCheckedChange={(checked) => setNewEvent({
                      ...newEvent, 
                      isRecurring: !!checked,
                      recurrencePattern: checked ? 'weekly' : 'none'
                    })}
                  />
                  <Label htmlFor="recurring">Evento recorrente</Label>
                </div>
                
                {newEvent.isRecurring && (
                  <div className="grid gap-2">
                    <Label htmlFor="recurrence">Padrão de recorrência</Label>
                    <Select 
                      value={newEvent.recurrencePattern}
                      onValueChange={(value) => setNewEvent({...newEvent, recurrencePattern: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o padrão" />
                      </SelectTrigger>
                      <SelectContent>
                        {recurrencePatterns.slice(1).map((pattern) => (
                          <SelectItem key={pattern.value} value={pattern.value}>
                            {pattern.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="reminders" className="space-y-4 py-4">
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label>Lembretes</Label>
                  <div className="space-y-2">
                    {reminderOptions.slice(1).map((option) => (
                      <div key={option.value} className="flex items-center gap-2">
                        <Checkbox 
                          id={`reminder-${option.value}`} 
                          checked={newEvent.reminders.includes(option.value)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setNewEvent({
                                ...newEvent, 
                                reminders: [...newEvent.reminders, option.value]
                              });
                            } else {
                              setNewEvent({
                                ...newEvent, 
                                reminders: newEvent.reminders.filter(r => r !== option.value)
                              });
                            }
                          }}
                        />
                        <Label htmlFor={`reminder-${option.value}`}>{option.label}</Label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Checkbox 
                    id="sync-calendar" 
                    checked={newEvent.syncWithExternalCalendar}
                    onCheckedChange={(checked) => setNewEvent({...newEvent, syncWithExternalCalendar: !!checked})}
                  />
                  <Label htmlFor="sync-calendar">Sincronizar com calendários externos</Label>
                </div>
                
                <div className="border-t pt-4">
                  <h4 className="text-sm font-medium mb-2">Notificações</h4>
                  <div className="flex items-center gap-2">
                    <Checkbox id="notify-email" />
                    <Label htmlFor="notify-email">Enviar por e-mail</Label>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <Checkbox id="notify-system" defaultChecked />
                    <Label htmlFor="notify-system">Notificação no sistema</Label>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddEvent(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddEvent} disabled={!newEvent.title}>
              Adicionar Evento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog open={showEventDetails} onOpenChange={setShowEventDetails}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-auto">
          {selectedEvent && (
            <>
              <DialogHeader>
                <div className="flex justify-between items-start">
                  <DialogTitle>{selectedEvent.title}</DialogTitle>
                  <Badge 
                    className={`${selectedEvent.completed ? 'bg-green-500' : getEventColor(selectedEvent.color)}`}
                  >
                    {selectedEvent.completed ? 'Concluído' : eventTypes.find(t => t.value === selectedEvent.type)?.label}
                  </Badge>
                </div>
                <DialogDescription>
                  {format(new Date(selectedEvent.startDate), selectedEvent.isAllDay ? 'dd/MM/yyyy' : 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                  {!selectedEvent.isAllDay && ` - ${format(new Date(selectedEvent.endDate), 'HH:mm', { locale: ptBR })}`}
                </DialogDescription>
              </DialogHeader>
              
              <Tabs defaultValue="details">
                <TabsList className="w-full">
                  <TabsTrigger value="details" className="flex-1">Detalhes</TabsTrigger>
                  <TabsTrigger value="edit" className="flex-1">Editar</TabsTrigger>
                </TabsList>
                
                <TabsContent value="details" className="py-4">
                  <div className="space-y-4">
                    <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md">
                      <p className="text-gray-700 dark:text-gray-300">{selectedEvent.description}</p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      {selectedEvent.location && (
                        <div>
                          <Label className="text-gray-500">Local</Label>
                          <p className="font-medium">{selectedEvent.location}</p>
                        </div>
                      )}
                      
                      {selectedEvent.participants && (
                        <div>
                          <Label className="text-gray-500">Participantes</Label>
                          <p className="font-medium">{selectedEvent.participants}</p>
                        </div>
                      )}
                      
                      {selectedEvent.isRecurring && (
                        <div>
                          <Label className="text-gray-500">Recorrência</Label>
                          <p className="font-medium">
                            {recurrencePatterns.find(p => p.value === selectedEvent.recurrencePattern)?.label}
                          </p>
                        </div>
                      )}
                      
                      {selectedEvent.reminders.length > 0 && (
                        <div>
                          <Label className="text-gray-500">Lembretes</Label>
                          <div className="space-y-1">
                            {selectedEvent.reminders.map(reminder => (
                              <Badge key={reminder} variant="outline" className="mr-1">
                                {reminderOptions.find(r => r.value === reminder)?.label}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    {selectedEvent.attachments.length > 0 && (
                      <div className="pt-2">
                        <Label className="text-gray-500">Anexos</Label>
                        <div className="space-y-2 mt-1">
                          {selectedEvent.attachments.map((attachment, idx) => (
                            <div key={idx} className="flex items-center gap-2 p-2 bg-gray-50 dark:bg-gray-800 rounded-md">
                              <FileText className="w-4 h-4 text-blue-500" />
                              <span className="text-sm">{attachment}</span>
                              <Button size="sm" variant="ghost" className="ml-auto">
                                <Download className="w-4 h-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </TabsContent>
                
                <TabsContent value="edit" className="py-4">
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="edit-title">Título</Label>
                      <Input 
                        id="edit-title" 
                        value={selectedEvent.title}
                        onChange={(e) => setSelectedEvent({...selectedEvent, title: e.target.value})}
                      />
                    </div>
                    
                    <div className="grid gap-2">
                      <Label htmlFor="edit-description">Descrição</Label>
                      <Textarea 
                        id="edit-description" 
                        value={selectedEvent.description}
                        onChange={(e) => setSelectedEvent({...selectedEvent, description: e.target.value})}
                      />
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Checkbox 
                        id="edit-all-day" 
                        checked={selectedEvent.isAllDay}
                        onCheckedChange={(checked) => setSelectedEvent({...selectedEvent, isAllDay: !!checked})}
                      />
                      <Label htmlFor="edit-all-day">Evento de dia inteiro</Label>
                    </div>
                    
                    <div className="grid gap-2">
                      <Label>Data e hora de início</Label>
                      <DateTimePicker 
                        date={new Date(selectedEvent.startDate)} 
                        setDate={(date) => setSelectedEvent({...selectedEvent, startDate: date})} 
                      />
                    </div>
                    
                    {!selectedEvent.isAllDay && (
                      <div className="grid gap-2">
                        <Label>Data e hora de término</Label>
                        <DateTimePicker 
                          date={new Date(selectedEvent.endDate)} 
                          setDate={(date) => setSelectedEvent({...selectedEvent, endDate: date})} 
                        />
                      </div>
                    )}
                    
                    <div className="grid gap-2">
                      <Label htmlFor="edit-type">Tipo de evento</Label>
                      <Select 
                        value={selectedEvent.type}
                        onValueChange={(value) => setSelectedEvent({...selectedEvent, type: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          {eventTypes.map((type) => (
                            <SelectItem key={type.value} value={type.value}>
                              <div className="flex items-center gap-2">
                                {type.icon}
                                <span>{type.label}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="grid gap-2">
                      <Label htmlFor="edit-color">Cor</Label>
                      <Select 
                        value={selectedEvent.color}
                        onValueChange={(value) => setSelectedEvent({...selectedEvent, color: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione a cor" />
                        </SelectTrigger>
                        <SelectContent>
                          {colorOptions.map((color) => (
                            <SelectItem key={color.value} value={color.value}>
                              <div className="flex items-center gap-2">
                                <div className={`w-4 h-4 rounded-full ${color.class}`}></div>
                                <span>{color.label}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="grid gap-2">
                      <Label htmlFor="edit-location">Local</Label>
                      <Input 
                        id="edit-location" 
                        value={selectedEvent.location}
                        onChange={(e) => setSelectedEvent({...selectedEvent, location: e.target.value})}
                      />
                    </div>
                    
                    <div className="grid gap-2">
                      <Label htmlFor="edit-participants">Participantes</Label>
                      <Textarea 
                        id="edit-participants" 
                        value={selectedEvent.participants}
                        onChange={(e) => setSelectedEvent({...selectedEvent, participants: e.target.value})}
                      />
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
              
              <DialogFooter className="flex justify-between">
                <div className="flex gap-2">
                  <Button variant="destructive" size="sm" onClick={handleDeleteEvent}>
                    <Trash className="w-4 h-4 mr-1" />
                    Excluir
                  </Button>
                  <Button 
                    variant={selectedEvent.completed ? "outline" : "default"} 
                    size="sm" 
                    onClick={handleToggleComplete}
                  >
                    <Check className="w-4 h-4 mr-1" />
                    {selectedEvent.completed ? 'Reabrir' : 'Concluir'}
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setShowEventDetails(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleUpdateEvent}>
                    Salvar Alterações
                  </Button>
                </div>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
