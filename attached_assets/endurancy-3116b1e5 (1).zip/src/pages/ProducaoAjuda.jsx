import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  HelpCircle, 
  FileText, 
  Factory, 
  CheckSquare, 
  ShieldCheck, 
  Package, 
  History, 
  Book, 
  Search, 
  Play, 
  PlayCircle, 
  Info, 
  Lightbulb, 
  ThumbsUp,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Award,
  Video,
  Coffee,
  Eye,
  Users,
  Receipt,
  Warehouse,
  Truck,
  ArrowUpRight,
  BookOpen,
  LayoutGrid,
  MessageSquare,
  FlaskConical,
  Bell
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";

export default function ProducaoAjuda() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("inicio");
  const [searchQuery, setSearchQuery] = useState("");
  const [currentTutorialStep, setCurrentTutorialStep] = useState(0);

  // Dados para o tour guiado
  const tourSteps = [
    {
      title: "Bem-vindo ao módulo de Produção",
      description: "Este módulo permite gerenciar todo o processo produtivo de medicamentos, desde a criação de ordens de produção até a liberação do produto final para distribuição.",
      icon: <Factory className="h-10 w-10 text-primary" />,
      image: "https://images.unsplash.com/photo-1563453392212-326f5e854473?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Dashboard de Produção",
      description: "O Dashboard apresenta uma visão geral da produção com indicadores-chave, ordens de produção ativas, alertas de qualidade e materiais críticos.",
      icon: <LayoutGrid className="h-10 w-10 text-primary" />,
      path: "ProducaoDashboard",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Ordens de Produção",
      description: "Aqui você pode criar, consultar e gerenciar todas as ordens de produção. Cada ordem contém informações sobre o produto, lote, quantidade, e status de produção.",
      icon: <Receipt className="h-10 w-10 text-primary" />,
      path: "ProducaoOrdens",
      image: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Matérias-Primas",
      description: "Gerencie o cadastro, entrada, análise e controle de todas as matérias-primas utilizadas na produção, incluindo controle de lotes e validação.",
      icon: <Warehouse className="h-10 w-10 text-primary" />,
      path: "ProducaoMateriasPrimas",
      image: "https://images.unsplash.com/photo-1617881770125-6fb0d039ecad?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Controle de Qualidade",
      description: "O setor de controle de qualidade realiza análises e testes para garantir a conformidade das matérias-primas e produtos acabados.",
      icon: <CheckSquare className="h-10 w-10 text-primary" />,
      path: "ProducaoQualidade",
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Garantia da Qualidade",
      description: "Após a aprovação pelo controle de qualidade, a garantia da qualidade monitora e libera os lotes para distribuição, garantindo a conformidade com as BPF.",
      icon: <ShieldCheck className="h-10 w-10 text-primary" />,
      path: "ProducaoGarantiaQualidade",
      image: "https://images.unsplash.com/photo-1530973428-5bf2db2e4d71?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Fornecedores",
      description: "Cadastre e gerencie os fornecedores qualificados para matérias-primas, embalagens e insumos farmacêuticos.",
      icon: <Truck className="h-10 w-10 text-primary" />,
      path: "ProducaoFornecedores",
      image: "https://images.unsplash.com/photo-1577577415542-de5f4ef333b4?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Distribuição",
      description: "Após a liberação, os produtos são disponibilizados no estoque de distribuição para envio aos pacientes e demais destinatários.",
      icon: <Package className="h-10 w-10 text-primary" />,
      path: "ProducaoDistribuicao",
      image: "https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Audit Trail",
      description: "O sistema mantém um registro detalhado de todas as operações realizadas, atendendo aos requisitos regulatórios da ANVISA.",
      icon: <History className="h-10 w-10 text-primary" />,
      path: "ProducaoAuditTrail",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1000&auto=format&fit=crop"
    },
    {
      title: "Parabéns!",
      description: "Você completou o tour pelo módulo de Produção. Agora você está pronto para começar a utilizar o sistema em conformidade com as Boas Práticas de Fabricação.",
      icon: <Award className="h-10 w-10 text-primary" />,
      image: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?q=80&w=1000&auto=format&fit=crop"
    }
  ];

  // FAQ
  const faqItems = [
    {
      question: "Como criar uma nova ordem de produção?",
      answer: "Para criar uma nova ordem de produção, acesse o menu 'Ordens de Produção' e clique no botão 'Nova Ordem'. Preencha todas as informações necessárias como produto, tamanho do lote e prazo previsto. O sistema verificará automaticamente a disponibilidade de matérias-primas necessárias para o lote."
    },
    {
      question: "Como registrar as etapas de produção concluídas?",
      answer: "Acesse a ordem de produção em andamento e utilize a 'Timeline de Fabricação' para registrar cada etapa concluída (diluição, envase, rotulagem, embalagem). Para cada etapa, preencha o checklist de verificação e assine digitalmente a conclusão da etapa."
    },
    {
      question: "O que fazer quando um lote for finalizado na produção?",
      answer: "Após concluir todas as etapas produtivas, finalize o processo na tela de 'Ordens de Produção'. Isso movimentará automaticamente o lote para a status de QUARENTENA no Controle de Qualidade, onde serão realizadas as análises necessárias."
    },
    {
      question: "Como reconciliar materiais após a produção?",
      answer: "Na finalização do processo produtivo, o sistema solicitará a reconciliação dos materiais. Informe a quantidade utilizada de cada material, a quantidade de produto final obtida e justifique eventuais perdas no processo."
    },
    {
      question: "Como funcionam as aprovações de qualidade?",
      answer: "O Controle de Qualidade realiza a amostragem e análises do produto, registrando os resultados no sistema. Se todos os parâmetros estiverem conformes, o lote é aprovado e movido para status APROVADO. Em seguida, a Garantia da Qualidade faz a liberação final para LIBERADO PARA DISTRIBUIÇÃO."
    },
    {
      question: "O que fazer em caso de desvio de qualidade?",
      answer: "Registre o desvio de qualidade no sistema através do módulo 'Controle de Qualidade > Desvios'. Descreva detalhadamente o problema, sua criticidade e as ações imediatas tomadas. Um fluxo de investigação será iniciado para determinar as causas e ações corretivas."
    },
    {
      question: "Como consultar o histórico de um lote específico?",
      answer: "Acesse o menu 'Audit Trail' e utilize os filtros para buscar pelo número do lote desejado. O sistema apresentará todo o histórico de operações realizadas com aquele lote, desde sua criação até a distribuição."
    },
    {
      question: "Como emitir documentação para um lote produtivo?",
      answer: "A documentação do lote (Ordem de Fabricação, Registros de Produção, Laudo de Análise) pode ser emitida através do menu 'Garantia da Qualidade > Documentação'. Selecione o lote desejado e os documentos necessários para gerar os PDFs."
    }
  ];

  // Vídeos tutoriais
  const tutorialVideos = [
    {
      title: "Introdução ao Módulo de Produção",
      duration: "5:30 min",
      thumbnail: "https://images.unsplash.com/photo-1598620617148-c9e8ddee6711?q=80&w=1000&auto=format&fit=crop",
      description: "Visão geral do módulo e seus principais recursos"
    },
    {
      title: "Criando e Gerenciando Ordens de Produção",
      duration: "8:45 min",
      thumbnail: "https://images.unsplash.com/photo-1581091877018-dac6a371d50f?q=80&w=1000&auto=format&fit=crop",
      description: "Aprenda a criar, editar e gerenciar ordens de produção"
    },
    {
      title: "Registro de Etapas Produtivas",
      duration: "7:15 min",
      thumbnail: "https://images.unsplash.com/photo-1581093458791-9d36a8a4ed9c?q=80&w=1000&auto=format&fit=crop",
      description: "Como registrar cada etapa da produção corretamente"
    },
    {
      title: "Controle de Qualidade e Aprovação de Lotes",
      duration: "10:20 min",
      thumbnail: "https://images.unsplash.com/photo-1581093450021-4a7360e9a6b5?q=80&w=1000&auto=format&fit=crop",
      description: "Processo completo de análise e aprovação de lotes"
    },
    {
      title: "Gestão de Matérias-Primas",
      duration: "6:40 min",
      thumbnail: "https://images.unsplash.com/photo-1579154341098-e4e158cc7f55?q=80&w=1000&auto=format&fit=crop",
      description: "Gerenciamento de recebimento, análise e controle de matérias-primas"
    },
    {
      title: "Garantia da Qualidade e Documentação",
      duration: "9:30 min",
      thumbnail: "https://images.unsplash.com/photo-1541276045896-c73c6572eb25?q=80&w=1000&auto=format&fit=crop",
      description: "Como gerenciar a documentação do sistema de qualidade"
    }
  ];

  // Regulamentações e referências
  const regulations = [
    {
      title: "RDC 301/2019",
      description: "Boas Práticas de Fabricação de Medicamentos",
      link: "https://www.gov.br/anvisa/pt-br"
    },
    {
      title: "RDC 327/2019",
      description: "Procedimentos para a concessão de Autorização Sanitária para fabricação de produtos de Cannabis",
      link: "https://www.gov.br/anvisa/pt-br"
    },
    {
      title: "RDC 67/2007",
      description: "Boas Práticas de Manipulação de Preparações Magistrais e Oficinais",
      link: "https://www.gov.br/anvisa/pt-br"
    },
    {
      title: "RDC 17/2010",
      description: "Boas Práticas de Fabricação de Medicamentos (Complementar)",
      link: "https://www.gov.br/anvisa/pt-br"
    },
    {
      title: "Farmacopeia Brasileira",
      description: "Compêndio oficial farmacêutico brasileiro",
      link: "https://www.gov.br/anvisa/pt-br/assuntos/farmacopeia"
    }
  ];

  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  const filteredFaq = faqItems.filter(item => 
    item.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
    item.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleNext = () => {
    if (currentTutorialStep < tourSteps.length - 1) {
      setCurrentTutorialStep(currentTutorialStep + 1);
    }
  };

  const handlePrev = () => {
    if (currentTutorialStep > 0) {
      setCurrentTutorialStep(currentTutorialStep - 1);
    }
  };

  const handleGoToSection = (path) => {
    if (path) {
      navigate(createPageUrl(path));
    }
  };

  const renderTourStep = () => {
    const step = tourSteps[currentTutorialStep];
    return (
      <Card className="border-2 border-primary/20">
        <CardContent className="p-0">
          {step.image && (
            <div className="w-full h-48 overflow-hidden">
              <img 
                src={step.image} 
                alt={step.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}
          <div className="p-6">
            <div className="flex items-center gap-4 mb-4">
              {step.icon}
              <div>
                <h3 className="text-xl font-semibold">{step.title}</h3>
                <p className="text-sm text-muted-foreground">
                  Passo {currentTutorialStep + 1} de {tourSteps.length}
                </p>
              </div>
            </div>
            <Progress value={(currentTutorialStep + 1) / tourSteps.length * 100} className="mb-6" />
            <p className="mb-6 text-gray-600">{step.description}</p>

            <div className="flex justify-between">
              <Button 
                onClick={handlePrev} 
                disabled={currentTutorialStep === 0}
                variant="outline"
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Anterior
              </Button>
              <div className="flex gap-2">
                {step.path && (
                  <Button 
                    onClick={() => handleGoToSection(step.path)}
                    variant="secondary"
                    className="gap-2"
                  >
                    <Eye className="h-4 w-4" />
                    Visitar Seção
                  </Button>
                )}
                <Button 
                  onClick={handleNext} 
                  disabled={currentTutorialStep === tourSteps.length - 1}
                  className="gap-2"
                >
                  {currentTutorialStep === tourSteps.length - 1 ? (
                    <>
                      <CheckCircle2 className="h-4 w-4" />
                      Concluir
                    </>
                  ) : (
                    <>
                      Próximo
                      <ArrowRight className="h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Central de Ajuda - Módulo Produção</h1>
          <p className="text-gray-500 mt-1">
            Orientações, tutoriais e FAQ para utilização do módulo de produção em conformidade com a ANVISA
          </p>
        </div>
        <div className="w-full md:w-64">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar ajuda..."
              className="pl-8"
              value={searchQuery}
              onChange={handleSearch}
            />
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid grid-cols-1 md:grid-cols-5 h-auto">
          <TabsTrigger value="inicio" className="flex items-center gap-2">
            <Info className="h-4 w-4" />
            <span>Início</span>
          </TabsTrigger>
          <TabsTrigger value="tour" className="flex items-center gap-2">
            <PlayCircle className="h-4 w-4" />
            <span>Tour Guiado</span>
          </TabsTrigger>
          <TabsTrigger value="faq" className="flex items-center gap-2">
            <HelpCircle className="h-4 w-4" />
            <span>Perguntas Frequentes</span>
          </TabsTrigger>
          <TabsTrigger value="tutorials" className="flex items-center gap-2">
            <Video className="h-4 w-4" />
            <span>Vídeos Tutoriais</span>
          </TabsTrigger>
          <TabsTrigger value="regulation" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            <span>Regulamentação</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="inicio">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PlayCircle className="h-5 w-5 text-primary" />
                  Conheça o Módulo de Produção
                </CardTitle>
                <CardDescription>
                  Inicie um tour guiado pelos principais recursos do módulo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  O módulo de produção foi desenvolvido para atender às exigências das Boas Práticas de Fabricação (BPF) 
                  e garantir a rastreabilidade completa do processo produtivo.
                </p>
                <Button onClick={() => setActiveTab("tour")} className="w-full">Iniciar Tour Guiado</Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-amber-500" />
                  Dicas Rápidas
                </CardTitle>
                <CardDescription>
                  Aprenda rapidamente as principais funcionalidades
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-3">
                  <div className="bg-primary/10 p-2 rounded-full h-fit">
                    <CheckCircle2 className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Comece pelo Dashboard</h4>
                    <p className="text-sm text-gray-600">Visualize as ordens de produção ativas e as prioridades do dia</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="bg-primary/10 p-2 rounded-full h-fit">
                    <CheckCircle2 className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Verificação de Materiais</h4>
                    <p className="text-sm text-gray-600">Sempre verifique a disponibilidade de matérias-primas antes de iniciar uma produção</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="bg-primary/10 p-2 rounded-full h-fit">
                    <CheckCircle2 className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Registre cada etapa</h4>
                    <p className="text-sm text-gray-600">Documente todas as etapas de produção em tempo real para garantir a rastreabilidade</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tour">
          {renderTourStep()}
        </TabsContent>

        <TabsContent value="faq">
          <Card>
            <CardHeader>
              <CardTitle>Perguntas Frequentes</CardTitle>
              <CardDescription>
                Respostas para as dúvidas mais comuns sobre o módulo de produção
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {filteredFaq.map((item, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent>
                      <p className="text-gray-600">{item.answer}</p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tutorials">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tutorialVideos.map((video, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="relative h-48">
                  <img 
                    src={video.thumbnail} 
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <Button variant="outline" className="bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-full w-12 h-12 p-0">
                      <Play className="h-6 w-6 text-white" />
                    </Button>
                  </div>
                  <Badge className="absolute top-2 right-2 bg-black/70">{video.duration}</Badge>
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{video.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">{video.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="regulation">
          <Card>
            <CardHeader>
              <CardTitle>Regulamentações e Referências</CardTitle>
              <CardDescription>
                Normas e diretrizes da ANVISA aplicáveis ao processo produtivo
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {regulations.map((regulation, index) => (
                  <div key={index} className="flex justify-between items-center p-4 border rounded-lg hover:bg-gray-50">
                    <div>
                      <h3 className="font-medium">{regulation.title}</h3>
                      <p className="text-sm text-gray-600">{regulation.description}</p>
                    </div>
                    <Button variant="outline" size="sm" asChild>
                      <a href={regulation.link} target="_blank" rel="noopener noreferrer">
                        <ArrowUpRight className="h-4 w-4 mr-2" />
                        Acessar
                      </a>
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}