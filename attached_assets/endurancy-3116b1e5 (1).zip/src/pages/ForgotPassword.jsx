import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, ArrowLeft, CheckCircle } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    
    // Email validation
    if (!email.includes('@') || !email.includes('.')) {
      setError("Por favor, insira um email válido");
      setIsLoading(false);
      return;
    }
    
    try {
      // This is a simulation - no actual email is sent
      setTimeout(() => {
        setIsSubmitted(true);
        setIsLoading(false);
        
        toast({
          title: "Simulação de envio de email",
          description: "Nenhum email real foi enviado. Esta é uma demonstração.",
        });
      }, 1500);
      
    } catch (error) {
      console.error("Error:", error);
      setError("Ocorreu um erro ao enviar o email. Por favor, tente novamente.");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gradient-to-b from-gray-50 to-gray-100 px-4">
      <Link to={createPageUrl("Index")} className="absolute top-8 left-8 flex items-center gap-2">
        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
          <span className="text-green-600 font-bold">E</span>
        </div>
        <span className="font-semibold text-xl">Endurancy</span>
      </Link>
      
      <div className="w-full max-w-md">
        <Card>
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl">Esqueceu sua senha?</CardTitle>
            <CardDescription>
              {isSubmitted 
                ? "Enviamos um email com instruções para redefinir sua senha."
                : "Digite seu email abaixo e enviaremos um link para redefinir sua senha."}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isSubmitted ? (
              <div className="text-center py-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-lg font-medium mb-2">Email enviado com sucesso!</h3>
                <p className="text-gray-500 mb-4">
                  Enviamos um email para <strong>{email}</strong> com instruções para redefinir sua senha.
                </p>
                <Alert className="mb-4">
                  <AlertTitle>Essa é uma demonstração</AlertTitle>
                  <AlertDescription>
                    Este é um ambiente de demonstração. Nenhum email real foi enviado. Em um sistema de produção,
                    você receberia um email com um link para redefinir sua senha.
                  </AlertDescription>
                </Alert>
                <p className="text-sm text-gray-500">
                  <button 
                    onClick={() => setIsSubmitted(false)}
                    className="text-blue-600 hover:underline ml-1"
                  >
                    Tentar novamente
                  </button> ou <Link to={createPageUrl("Access")} className="text-blue-600 hover:underline">voltar para o login</Link>
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {error && (
                  <div className="bg-red-50 text-red-600 p-3 rounded-md text-sm">
                    {error}
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu.email@exemplo.com"
                      className="pl-10"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>
                
                <Alert className="bg-yellow-50 border-yellow-100">
                  <AlertTitle>Ambiente de demonstração</AlertTitle>
                  <AlertDescription>
                    Este é um ambiente de demonstração. Nenhum email real será enviado.
                  </AlertDescription>
                </Alert>
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? "Enviando..." : "Enviar link de redefinição"}
                </Button>
              </form>
            )}
          </CardContent>
          <CardFooter>
            <div className="w-full text-center">
              <Link 
                to={createPageUrl("Access")} 
                className="flex items-center justify-center text-sm text-blue-600 hover:underline"
              >
                <ArrowLeft className="w-3 h-3 mr-1" />
                Voltar para o login
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}