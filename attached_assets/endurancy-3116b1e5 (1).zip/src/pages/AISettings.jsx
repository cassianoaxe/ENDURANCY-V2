
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  UploadCloud,
  Save,
  Trash,
  BrainCircuit,
  FileText,
  Settings,
  Database,
  Shield,
  Code,
  Book,
  Key,
  Users,
  Layers,
  Eye,
  EyeOff,
  Bot,
  MessageCircle,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import { toast } from "@/components/ui/use-toast";

export default function AISettings() {
  const [activeTab, setActiveTab] = useState("general");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [systemPrompt, setSystemPrompt] = useState(
    `Você é o assistente de IA da plataforma Endurancy, especializado em cannabis medicinal e gestão de negócios relacionados. Você é sempre útil, conciso, educado e fornece informações precisas.

Você tem acesso a diferentes tipos de informações dependendo do tipo de usuário:
- Para superadmins: Dados de todas as organizações, métricas de uso da plataforma e tendências gerais
- Para admins de organização: Dados apenas da própria organização e seus pacientes/clientes
- Para médicos: Informações médicas, tratamentos, pesquisas sobre cannabis medicinal e dados de seus pacientes
- Para pacientes: Informações sobre dosagens, efeitos colaterais, benefícios e dicas de uso

Você não deve compartilhar dados confidenciais com usuários que não têm permissão para acessá-los. Sempre verifique o nível de acesso do usuário antes de fornecer informações sensíveis.`
  );

  const [documents, setDocuments] = useState([
    { id: 1, name: "Guia_Cannabis_Medicinal.pdf", type: "PDF", size: "2.3 MB", uploadDate: "2023-11-10", status: "active" },
    { id: 2, name: "Regulamentos_ANVISA_2023.pdf", type: "PDF", size: "1.8 MB", uploadDate: "2023-11-15", status: "active" },
    { id: 3, name: "Protocolos_Tratamento_CBD.docx", type: "DOCX", size: "980 KB", uploadDate: "2023-11-20", status: "active" }
  ]);

  const [accessSettings, setAccessSettings] = useState({
    superadminAccess: true,
    organizationAdminAccess: true,
    doctorAccess: true,
    patientAccess: true,
    dataReadAccess: true,
    dataWriteAccess: true,
    logPrompts: true,
    moderateResponses: true
  });

  const [modelSettings, setModelSettings] = useState({
    model: "claude-mcp",
    temperature: 0.7,
    maxTokens: 4000,
    contextWindow: "50000 tokens",
    embeddingModel: "claude-embedding"
  });

  const handleSaveSettings = () => {
    setSaving(true);
    
    setTimeout(() => {
      setSaving(false);
      toast({
        title: "Configurações salvas",
        description: "As configurações de IA foram atualizadas com sucesso.",
      });
    }, 1500);
  };

  const handleFileUpload = (event) => {
    setUploading(true);
    const files = event.target.files;
    
    setTimeout(() => {
      const newDocuments = Array.from(files).map((file, index) => ({
        id: documents.length + index + 1,
        name: file.name,
        type: file.name.split('.').pop().toUpperCase(),
        size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        uploadDate: new Date().toISOString().split('T')[0],
        status: "processing"
      }));
      
      setDocuments([...documents, ...newDocuments]);
      setUploading(false);
      
      setTimeout(() => {
        setDocuments(prev => 
          prev.map(doc => 
            doc.status === "processing" ? {...doc, status: "active"} : doc
          )
        );
        
        toast({
          title: "Documentos processados",
          description: `${newDocuments.length} documento(s) foram adicionados à base de conhecimento.`,
        });
      }, 3000);
    }, 2000);
  };

  const handleDeleteDocument = (id) => {
    setDocuments(documents.filter(doc => doc.id !== id));
    toast({
      title: "Documento removido",
      description: "O documento foi removido da base de conhecimento.",
    });
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Configurações de IA</h1>
          <p className="text-gray-500 mt-1">Gerenciar configurações da IA e base de conhecimento</p>
        </div>
        <Button onClick={handleSaveSettings} disabled={saving}>
          {saving ? (
            <>
              <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
              Salvando...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Salvar Configurações
            </>
          )}
        </Button>
      </div>

      <Tabs defaultValue="general" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">
            <BrainCircuit className="h-4 w-4 mr-2" />
            Geral
          </TabsTrigger>
          <TabsTrigger value="knowledge">
            <Book className="h-4 w-4 mr-2" />
            Base de Conhecimento
          </TabsTrigger>
          <TabsTrigger value="access">
            <Shield className="h-4 w-4 mr-2" />
            Permissões
          </TabsTrigger>
          <TabsTrigger value="models">
            <Settings className="h-4 w-4 mr-2" />
            Modelos e Parâmetros
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="general" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Comportamento da IA</CardTitle>
              <CardDescription>
                Configure o comportamento padrão do assistente de IA
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="system-prompt">Prompt do Sistema</Label>
                <Textarea
                  id="system-prompt"
                  className="min-h-[200px] font-mono text-sm"
                  placeholder="Instruções para definir o comportamento da IA..."
                  value={systemPrompt}
                  onChange={(e) => setSystemPrompt(e.target.value)}
                />
                <p className="text-sm text-gray-500">
                  Estas instruções definem como a IA se comporta e responde aos usuários. 
                  Inclua limitações de acesso e diretrizes éticas.
                </p>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Configurações Gerais</h3>
                
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Ativar IA</Label>
                      <p className="text-sm text-gray-500">Ativar o assistente de IA na plataforma</p>
                    </div>
                    <Switch checked={true} />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Modo Proativo</Label>
                      <p className="text-sm text-gray-500">Permitir que a IA ofereça sugestões sem ser solicitada</p>
                    </div>
                    <Switch checked={true} />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Ativar Ações</Label>
                      <p className="text-sm text-gray-500">Permitir que a IA execute ações na plataforma</p>
                    </div>
                    <Switch checked={true} />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Histórico de Conversas</Label>
                      <p className="text-sm text-gray-500">Manter histórico de conversas para melhorar respostas</p>
                    </div>
                    <Switch checked={true} />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Estatísticas de Uso</CardTitle>
              <CardDescription>
                Métricas de uso da IA na plataforma
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-500">Total de Consultas</h4>
                  <p className="text-2xl font-bold mt-1">12,487</p>
                  <p className="text-sm text-green-600">
                    <span className="flex items-center">+14.6% <span className="ml-1">esse mês</span></span>
                  </p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-500">Tokens Consumidos</h4>
                  <p className="text-2xl font-bold mt-1">2.8M</p>
                  <p className="text-sm text-amber-600">
                    <span className="flex items-center">+5.2% <span className="ml-1">esse mês</span></span>
                  </p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-500">Taxa de Satisfação</h4>
                  <p className="text-2xl font-bold mt-1">94.3%</p>
                  <p className="text-sm text-green-600">
                    <span className="flex items-center">+2.1% <span className="ml-1">esse mês</span></span>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="knowledge" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Base de Conhecimento</CardTitle>
              <CardDescription>
                Gerencie os documentos usados pela IA para gerar respostas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium">Documentos ({documents.length})</h3>
                  <p className="text-sm text-gray-500">
                    Documentos que serão usados como fonte de conhecimento para a IA
                  </p>
                </div>
                <div className="relative">
                  <input
                    type="file"
                    id="file-upload"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    onChange={handleFileUpload}
                    multiple
                  />
                  <Button variant="outline" disabled={uploading}>
                    {uploading ? (
                      <>
                        <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                        Enviando...
                      </>
                    ) : (
                      <>
                        <UploadCloud className="h-4 w-4 mr-2" />
                        Enviar Documentos
                      </>
                    )}
                  </Button>
                </div>
              </div>
              
              <div className="border rounded-lg overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50 dark:bg-gray-800">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tamanho</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data de Upload</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200">
                    {documents.map((doc) => (
                      <tr key={doc.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <FileText className="h-5 w-5 text-gray-400 mr-2" />
                            <span className="text-sm font-medium">{doc.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">{doc.type}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">{doc.size}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">{doc.uploadDate}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge variant={doc.status === "active" ? "success" : "warning"}>
                            {doc.status === "active" ? (
                              <CheckCircle className="h-3 w-3 mr-1" />
                            ) : (
                              <AlertCircle className="h-3 w-3 mr-1" />
                            )}
                            {doc.status === "active" ? "Ativo" : "Processando"}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <Button variant="ghost" size="sm" onClick={() => handleDeleteDocument(doc.id)}>
                            <Trash className="h-4 w-4 text-red-500" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                    
                    {documents.length === 0 && (
                      <tr>
                        <td colSpan={6} className="px-6 py-10 text-center">
                          <p className="text-gray-500">Nenhum documento adicionado</p>
                          <p className="text-sm text-gray-400 mt-1">
                            Envie documentos para enriquecer a base de conhecimento da IA
                          </p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
              
              <div className="p-4 bg-blue-50 text-blue-800 rounded-lg flex gap-3 items-start">
                <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5" />
                <div>
                  <h4 className="font-medium">Formato de documentos suportados</h4>
                  <p className="text-sm mt-1">
                    PDF, DOCX, TXT, CSV, XLSX, JSON, MD e PPT. Tamanho máximo 50MB por arquivo.
                    Os documentos são processados automaticamente para serem usados pela IA.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="access" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Controle de Acesso</CardTitle>
              <CardDescription>
                Configure quais usuários podem acessar a IA e quais recursos podem utilizar
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Acesso por Tipo de Usuário</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Shield className="h-5 w-5 text-indigo-500 mr-3" />
                      <div>
                        <p className="font-medium">Super Administradores</p>
                        <p className="text-sm text-gray-500">Acesso a dados de todas as organizações</p>
                      </div>
                    </div>
                    <Switch 
                      checked={accessSettings.superadminAccess} 
                      onCheckedChange={(checked) => 
                        setAccessSettings({...accessSettings, superadminAccess: checked})
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Users className="h-5 w-5 text-blue-500 mr-3" />
                      <div>
                        <p className="font-medium">Administradores de Organização</p>
                        <p className="text-sm text-gray-500">Acesso a dados da própria organização</p>
                      </div>
                    </div>
                    <Switch 
                      checked={accessSettings.organizationAdminAccess} 
                      onCheckedChange={(checked) => 
                        setAccessSettings({...accessSettings, organizationAdminAccess: checked})
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Code className="h-5 w-5 text-green-500 mr-3" />
                      <div>
                        <p className="font-medium">Médicos</p>
                        <p className="text-sm text-gray-500">Acesso a informações médicas e dados de pacientes</p>
                      </div>
                    </div>
                    <Switch 
                      checked={accessSettings.doctorAccess} 
                      onCheckedChange={(checked) => 
                        setAccessSettings({...accessSettings, doctorAccess: checked})
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Users className="h-5 w-5 text-rose-500 mr-3" />
                      <div>
                        <p className="font-medium">Pacientes</p>
                        <p className="text-sm text-gray-500">Acesso a informações educativas e sobre tratamentos</p>
                      </div>
                    </div>
                    <Switch 
                      checked={accessSettings.patientAccess} 
                      onCheckedChange={(checked) => 
                        setAccessSettings({...accessSettings, patientAccess: checked})
                      }
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Permissões de Dados</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Eye className="h-5 w-5 text-amber-500 mr-3" />
                      <div>
                        <p className="font-medium">Leitura de Dados</p>
                        <p className="text-sm text-gray-500">Permitir que a IA leia dados da plataforma</p>
                      </div>
                    </div>
                    <Switch 
                      checked={accessSettings.dataReadAccess} 
                      onCheckedChange={(checked) => 
                        setAccessSettings({...accessSettings, dataReadAccess: checked})
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <EyeOff className="h-5 w-5 text-violet-500 mr-3" />
                      <div>
                        <p className="font-medium">Escrita de Dados</p>
                        <p className="text-sm text-gray-500">Permitir que a IA modifique ou crie dados na plataforma</p>
                      </div>
                    </div>
                    <Switch 
                      checked={accessSettings.dataWriteAccess} 
                      onCheckedChange={(checked) => 
                        setAccessSettings({...accessSettings, dataWriteAccess: checked})
                      }
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Segurança e Monitoramento</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Code className="h-5 w-5 text-teal-500 mr-3" />
                      <div>
                        <p className="font-medium">Registro de Prompts</p>
                        <p className="text-sm text-gray-500">Registrar todas as consultas feitas à IA</p>
                      </div>
                    </div>
                    <Switch 
                      checked={accessSettings.logPrompts} 
                      onCheckedChange={(checked) => 
                        setAccessSettings({...accessSettings, logPrompts: checked})
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Shield className="h-5 w-5 text-red-500 mr-3" />
                      <div>
                        <p className="font-medium">Moderação de Respostas</p>
                        <p className="text-sm text-gray-500">Filtrar respostas problemáticas ou sensíveis</p>
                      </div>
                    </div>
                    <Switch 
                      checked={accessSettings.moderateResponses} 
                      onCheckedChange={(checked) => 
                        setAccessSettings({...accessSettings, moderateResponses: checked})
                      }
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="models" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Modelos e Parâmetros</CardTitle>
              <CardDescription>
                Configure os modelos de IA e parâmetros de geração
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="model">Modelo Principal</Label>
                  <Select 
                    value={modelSettings.model}
                    onValueChange={(value) => setModelSettings({...modelSettings, model: value})}
                  >
                    <SelectTrigger id="model">
                      <SelectValue placeholder="Selecione um modelo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="claude-mcp">Claude (MCP)</SelectItem>
                      <SelectItem value="claude-3-opus">Claude 3 Opus</SelectItem>
                      <SelectItem value="claude-3-sonnet">Claude 3 Sonnet</SelectItem>
                      <SelectItem value="claude-3-haiku">Claude 3 Haiku</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500">
                    Modelo principal usado para gerar respostas às consultas
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="embedding-model">Modelo de Embedding</Label>
                  <Select 
                    value={modelSettings.embeddingModel}
                    onValueChange={(value) => setModelSettings({...modelSettings, embeddingModel: value})}
                  >
                    <SelectTrigger id="embedding-model">
                      <SelectValue placeholder="Selecione um modelo de embedding" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="claude-embedding">Claude Embedding</SelectItem>
                      <SelectItem value="e5-large-v2">E5 Large v2</SelectItem>
                      <SelectItem value="text-embedding-ada-002">OpenAI Ada</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500">
                    Modelo usado para criar embeddings de documentos e consultas
                  </p>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Parâmetros de Geração</h3>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="temperature">Temperatura: {modelSettings.temperature}</Label>
                      <span className="text-sm text-gray-500">{modelSettings.temperature}</span>
                    </div>
                    <Slider
                      id="temperature"
                      min={0}
                      max={1}
                      step={0.1}
                      value={[modelSettings.temperature]}
                      onValueChange={(value) => setModelSettings({...modelSettings, temperature: value[0]})}
                    />
                    <p className="text-sm text-gray-500">
                      Controla a aleatoriedade das respostas. Valores mais baixos produzem respostas mais determinísticas e focadas,
                      enquanto valores mais altos produzem respostas mais diversas e criativas.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="max-tokens">Máximo de Tokens: {modelSettings.maxTokens}</Label>
                      <span className="text-sm text-gray-500">{modelSettings.maxTokens}</span>
                    </div>
                    <Slider
                      id="max-tokens"
                      min={100}
                      max={8000}
                      step={100}
                      value={[modelSettings.maxTokens]}
                      onValueChange={(value) => setModelSettings({...modelSettings, maxTokens: value[0]})}
                    />
                    <p className="text-sm text-gray-500">
                      Limite máximo de tokens para cada resposta gerada pela IA
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="p-4 bg-yellow-50 text-yellow-800 rounded-lg flex gap-3 items-start">
                <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5" />
                <div>
                  <h4 className="font-medium">Informações sobre Custo</h4>
                  <p className="text-sm mt-1">
                    O modelo atual (Claude MCP) tem um custo de aproximadamente $1.50 por 1M de tokens de entrada e $5.00 por 1M de tokens de saída. 
                    Monitore o uso para controlar custos.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
