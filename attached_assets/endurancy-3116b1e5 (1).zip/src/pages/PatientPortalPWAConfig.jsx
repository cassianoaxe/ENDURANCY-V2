import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { InfoIcon } from "lucide-react";

export default function PatientPortalPWAConfig() {
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-6">Configuração PWA do Portal do Paciente</h1>
      
      <Alert className="mb-6">
        <InfoIcon className="h-4 w-4" />
        <AlertTitle>Informação sobre PWA</AlertTitle>
        <AlertDescription>
          O Portal do Paciente foi configurado para funcionar como um Progressive Web App (PWA).
          Esta página fornece informação sobre a configuração e implementação.
        </AlertDescription>
      </Alert>
      
      <Tabs defaultValue="manifest">
        <TabsList className="mb-4">
          <TabsTrigger value="manifest">Manifest</TabsTrigger>
          <TabsTrigger value="serviceworker">Service Worker</TabsTrigger>
          <TabsTrigger value="offline">Offline Support</TabsTrigger>
        </TabsList>
        
        <TabsContent value="manifest">
          <Card>
            <CardHeader>
              <CardTitle>Web App Manifest</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">O Web App Manifest é um arquivo JSON que contém informações sobre o aplicativo web, como nome, ícones, cores e comportamento de exibição.</p>
              
              <pre className="bg-gray-50 p-4 rounded-lg overflow-auto text-sm border">
{`{
  "name": "Portal do Paciente Endurancy",
  "short_name": "Endurancy",
  "description": "Portal do Paciente da plataforma Endurancy para Cannabis Medicinal",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#10b981",
  "icons": [
    {
      "src": "/icons/icon-192x192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icons/icon-512x512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
    // ... Outros tamanhos de ícones
  ]
}`}
              </pre>
              
              <p className="mt-4">Este arquivo deve ser referenciado na página HTML principal com a tag <code>&lt;link rel="manifest" href="/manifest.json"&gt;</code>.</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="serviceworker">
          <Card>
            <CardHeader>
              <CardTitle>Service Worker</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">O Service Worker é um script que seu navegador executa em segundo plano, possibilitando recursos como notificações push, sincronização em segundo plano e experiências offline.</p>
              
              <p className="mb-2">Funcionalidades implementadas no Service Worker:</p>
              <ul className="list-disc pl-6 mb-4 space-y-1">
                <li>Cache de arquivos estáticos para funcionamento offline</li>
                <li>Estratégia de cache "Cache First" para recursos principais</li>
                <li>Sincronização em segundo plano quando o app volta a ficar online</li>
                <li>Suporte a notificações push</li>
              </ul>
              
              <p className="mb-4">O Service Worker é registrado com:</p>
              <pre className="bg-gray-50 p-4 rounded-lg overflow-auto text-sm border">
{`if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .then(registration => {
        console.log('ServiceWorker registration successful');
      })
      .catch(error => {
        console.log('ServiceWorker registration failed');
      });
  });
}`}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="offline">
          <Card>
            <CardHeader>
              <CardTitle>Suporte Offline</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">O Portal do Paciente foi projetado para funcionar mesmo quando o usuário está offline, com as seguintes funcionalidades:</p>
              
              <ul className="list-disc pl-6 mb-4 space-y-1">
                <li>Armazenamento local do carrinho de compras</li>
                <li>Exibição de página offline personalizada quando não há conexão</li>
                <li>Acesso a informações básicas do perfil, medicações e prescrições</li>
                <li>Indicadores visuais de status de conexão</li>
                <li>Sincronização automática quando a conexão é restaurada</li>
              </ul>
              
              <p className="mb-2">A detecção de status online/offline é implementada com:</p>
              <pre className="bg-gray-50 p-4 rounded-lg overflow-auto text-sm border">
{`// Detecção de status online/offline
const [isOnline, setIsOnline] = useState(navigator.onLine);

useEffect(() => {
  const handleOnlineStatus = () => {
    setIsOnline(navigator.onLine);
    
    if (navigator.onLine) {
      toast({
        title: "Conexão restaurada",
        description: "Você está online novamente."
      });
    } else {
      toast({
        title: "Sem conexão",
        description: "Você está offline. Algumas funções podem não estar disponíveis."
      });
    }
  };

  window.addEventListener('online', handleOnlineStatus);
  window.addEventListener('offline', handleOnlineStatus);

  return () => {
    window.removeEventListener('online', handleOnlineStatus);
    window.removeEventListener('offline', handleOnlineStatus);
  };
}, []);`}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}