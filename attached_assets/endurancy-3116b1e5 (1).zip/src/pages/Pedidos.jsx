
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ShoppingBag, 
  Search, 
  Filter, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Truck, 
  Package, 
  FileText, 
  Users, 
  MoreHorizontal, 
  PlusCircle, 
  Eye, 
  Edit, 
  Trash2, 
  Download, 
  Mail, 
  Printer, 
  RefreshCw,
  CheckSquare,
  Layers,
  ArrowRightLeft
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";

// Dados simulados de pedidos
const mockPedidos = [
  {
    id: "ped-001",
    numero: "P23050001",
    cliente: {
      id: "cli-001",
      nome: "Maria Silva",
      avatar: "MS"
    },
    data: "2023-05-10T14:30:00Z",
    status: "entregue",
    total: 350.90,
    itens: 3,
    endereco: "Rua das Flores, 123 - São Paulo, SP",
    observacao: "Entregar no período da tarde",
    formaPagamento: "cartão de crédito",
    ultimaAtualizacao: "2023-05-15T10:20:00Z",
    juntoComPedido: null,
    disponivelParaJuncao: true
  },
  {
    id: "ped-002",
    numero: "P23050002",
    cliente: {
      id: "cli-002",
      nome: "João Santos",
      avatar: "JS"
    },
    data: "2023-05-12T11:45:00Z",
    status: "processando",
    total: 125.50,
    itens: 2,
    endereco: "Av. Paulista, 1000 - São Paulo, SP",
    observacao: "Juntar com pedido P23050005 do mesmo cliente",
    formaPagamento: "pix",
    ultimaAtualizacao: "2023-05-12T15:30:00Z",
    juntoComPedido: null,
    disponivelParaJuncao: true
  },
  {
    id: "ped-003",
    numero: "P23050003",
    cliente: {
      id: "cli-003",
      nome: "Ana Costa",
      avatar: "AC"
    },
    data: "2023-05-15T09:20:00Z",
    status: "enviado",
    total: 540.00,
    itens: 4,
    endereco: "Rua Augusta, 234 - São Paulo, SP",
    observacao: "Cliente solicitou embalagem discreta",
    formaPagamento: "boleto",
    ultimaAtualizacao: "2023-05-16T08:45:00Z",
    juntoComPedido: null,
    disponivelParaJuncao: true
  },
  {
    id: "ped-004",
    numero: "P23050004",
    cliente: {
      id: "cli-004",
      nome: "Roberto Alves",
      avatar: "RA"
    },
    data: "2023-05-17T16:10:00Z",
    status: "cancelado",
    total: 780.30,
    itens: 6,
    endereco: "Rua Oscar Freire, 500 - São Paulo, SP",
    observacao: "Pedido cancelado a pedido do cliente",
    formaPagamento: "cartão de crédito",
    ultimaAtualizacao: "2023-05-17T18:30:00Z",
    juntoComPedido: null,
    disponivelParaJuncao: false
  },
  {
    id: "ped-005",
    numero: "P23050005",
    cliente: {
      id: "cli-002",
      nome: "João Santos",
      avatar: "JS"
    },
    data: "2023-05-18T10:30:00Z",
    status: "pendente",
    total: 420.80,
    itens: 3,
    endereco: "Av. Paulista, 1000 - São Paulo, SP",
    observacao: "Cliente solicitou juntar com pedido anterior P23050002",
    formaPagamento: "pix",
    ultimaAtualizacao: "2023-05-18T10:30:00Z",
    juntoComPedido: null,
    disponivelParaJuncao: true
  },
  {
    id: "ped-006",
    numero: "P23050006",
    cliente: {
      id: "cli-005",
      nome: "Carla Mendes",
      avatar: "CM"
    },
    data: "2023-05-20T14:20:00Z",
    status: "aguardando_pagamento",
    total: 150.00,
    itens: 1,
    endereco: "Rua Haddock Lobo, 123 - São Paulo, SP",
    observacao: "",
    formaPagamento: "boleto",
    ultimaAtualizacao: "2023-05-20T14:20:00Z",
    juntoComPedido: null,
    disponivelParaJuncao: true
  },
  {
    id: "ped-007",
    numero: "P23050007",
    cliente: {
      id: "cli-006",
      nome: "Paulo Rodrigues",
      avatar: "PR"
    },
    data: "2023-05-22T09:15:00Z",
    status: "aprovado",
    total: 890.50,
    itens: 5,
    endereco: "Av. Rebouças, 500 - São Paulo, SP",
    observacao: "",
    formaPagamento: "transferência bancária",
    ultimaAtualizacao: "2023-05-22T10:45:00Z",
    juntoComPedido: null,
    disponivelParaJuncao: true
  },
  {
    id: "ped-008",
    numero: "P23050008",
    cliente: {
      id: "cli-007",
      nome: "Fernanda Lima",
      avatar: "FL"
    },
    data: "2023-05-23T11:30:00Z",
    status: "entregue",
    total: 320.00,
    itens: 2,
    endereco: "Rua dos Pinheiros, 100 - São Paulo, SP",
    observacao: "",
    formaPagamento: "cartão de crédito",
    ultimaAtualizacao: "2023-05-25T15:40:00Z",
    juntoComPedido: null,
    disponivelParaJuncao: true
  }
];

export default function Pedidos() {
  const navigate = useNavigate();
  const [pedidos, setPedidos] = useState([]);
  const [filteredPedidos, setFilteredPedidos] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [loading, setLoading] = useState(true);
  const [selectedPedidos, setSelectedPedidos] = useState([]);
  const [showJuntar, setShowJuntar] = useState(false);
  const [pedidoParaJuncao, setPedidoParaJuncao] = useState(null);
  const [pedidosSelecionadosParaJuncao, setPedidosSelecionadosParaJuncao] = useState([]);
  const [juncaoDialogOpen, setJuncaoDialogOpen] = useState(false);

  useEffect(() => {
    loadPedidos();
  }, []);

  useEffect(() => {
    filterPedidos();
  }, [pedidos, searchTerm, statusFilter]);

  const loadPedidos = async () => {
    try {
      setLoading(true);
      setTimeout(() => {
        setPedidos(mockPedidos);
        setLoading(false);
      }, 1000);
    } catch (error) {
      console.error("Erro ao carregar pedidos", error);
      setLoading(false);
    }
  };

  const filterPedidos = () => {
    let filtered = [...pedidos];

    if (searchTerm) {
      filtered = filtered.filter(pedido => 
        pedido.numero.toLowerCase().includes(searchTerm.toLowerCase()) ||
        pedido.cliente.nome.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== "todos") {
      filtered = filtered.filter(pedido => pedido.status === statusFilter);
    }

    setFilteredPedidos(filtered);
  };

  const formatarDataSegura = (dataString) => {
    if (!dataString) return "Data não disponível";
    
    try {
      const data = new Date(dataString);
      if (isNaN(data.getTime())) {
        return "Data inválida";
      }
      return new Intl.DateTimeFormat('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }).format(data);
    } catch (error) {
      console.error("Erro ao formatar data:", error);
      return "Erro na data";
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      "pendente": { color: "bg-yellow-100 text-yellow-800", label: "Pendente" },
      "aprovado": { color: "bg-blue-100 text-blue-800", label: "Aprovado" },
      "processando": { color: "bg-purple-100 text-purple-800", label: "Processando" },
      "enviado": { color: "bg-indigo-100 text-indigo-800", label: "Enviado" },
      "entregue": { color: "bg-green-100 text-green-800", label: "Entregue" },
      "cancelado": { color: "bg-red-100 text-red-800", label: "Cancelado" },
      "aguardando_pagamento": { color: "bg-orange-100 text-orange-800", label: "Aguardando Pagamento" }
    };

    const config = statusConfig[status] || { color: "bg-gray-100 text-gray-800", label: "Desconhecido" };

    return (
      <Badge className={config.color}>
        {config.label}
      </Badge>
    );
  };

  const handlePedidoSelect = (pedidoId) => {
    if (selectedPedidos.includes(pedidoId)) {
      setSelectedPedidos(selectedPedidos.filter(id => id !== pedidoId));
    } else {
      setSelectedPedidos([...selectedPedidos, pedidoId]);
    }
  };

  const pedidoContemTermoJuncao = (observacao) => {
    if (!observacao) return false;
    
    const termosJuncao = ["juntar", "mesclar", "unir", "combinar", "agrupar"];
    const observacaoLower = observacao.toLowerCase();
    
    return termosJuncao.some(termo => observacaoLower.includes(termo));
  };

  const abrirDialogJuncaoPedidos = (pedido) => {
    const pedidosElegiveis = pedidos.filter(p => 
      p.id !== pedido.id && 
      p.cliente.id === pedido.cliente.id && 
      p.status !== "cancelado" && 
      p.status !== "entregue" &&
      !p.juntoComPedido &&
      p.disponivelParaJuncao
    );
    
    setPedidoParaJuncao(pedido);
    setPedidosSelecionadosParaJuncao([]);
    setJuncaoDialogOpen(true);
  };

  const toggleSelecionarPedidoParaJuncao = (pedidoId) => {
    if (pedidosSelecionadosParaJuncao.includes(pedidoId)) {
      setPedidosSelecionadosParaJuncao(
        pedidosSelecionadosParaJuncao.filter(id => id !== pedidoId)
      );
    } else {
      setPedidosSelecionadosParaJuncao([...pedidosSelecionadosParaJuncao, pedidoId]);
    }
  };

  const realizarJuncaoPedidos = async () => {
    if (!pedidoParaJuncao || pedidosSelecionadosParaJuncao.length === 0) {
      return;
    }

    try {
      const pedidosPorId = Object.fromEntries(pedidos.map(p => [p.id, p]));
      
      const todosIdsJuncao = [pedidoParaJuncao.id, ...pedidosSelecionadosParaJuncao];
      const pedidosJuntados = todosIdsJuncao.map(id => pedidosPorId[id]);
      
      const totalConsolidado = pedidosJuntados.reduce((sum, p) => sum + p.total, 0);
      const totalItens = pedidosJuntados.reduce((sum, p) => sum + p.itens, 0);
      
      const novoPedidoConsolidado = {
        id: `ped-cons-${Date.now()}`,
        numero: `PC${Date.now().toString().slice(-6)}`,
        cliente: pedidoParaJuncao.cliente,
        data: new Date().toISOString(),
        status: "processando",
        total: totalConsolidado,
        itens: totalItens,
        endereco: pedidoParaJuncao.endereco,
        observacao: `Pedido consolidado dos pedidos: ${todosIdsJuncao.map(id => pedidosPorId[id].numero).join(", ")}`,
        formaPagamento: pedidoParaJuncao.formaPagamento,
        ultimaAtualizacao: new Date().toISOString(),
        juntoComPedido: null,
        disponivelParaJuncao: false,
        pedidosOriginais: todosIdsJuncao
      };
      
      const pedidosAtualizados = pedidos.map(p => {
        if (todosIdsJuncao.includes(p.id)) {
          return {
            ...p,
            status: "consolidado",
            juntoComPedido: novoPedidoConsolidado.id,
            disponivelParaJuncao: false,
            observacao: p.observacao + ` [Consolidado no pedido ${novoPedidoConsolidado.numero}]`
          };
        }
        return p;
      });
      
      setPedidos([novoPedidoConsolidado, ...pedidosAtualizados]);
      
      setPedidoParaJuncao(null);
      setPedidosSelecionadosParaJuncao([]);
      setJuncaoDialogOpen(false);
      
      alert(`Pedidos consolidados com sucesso no novo pedido ${novoPedidoConsolidado.numero}`);
      
    } catch (error) {
      console.error("Erro ao juntar pedidos", error);
      alert("Ocorreu um erro ao tentar juntar os pedidos. Tente novamente.");
    }
  };

  const reverterJuncaoPedidos = async (pedidoConsolidado) => {
    if (!pedidoConsolidado || !pedidoConsolidado.pedidosOriginais) {
      return;
    }

    try {
      const pedidosAtualizados = pedidos.map(p => {
        if (pedidoConsolidado.pedidosOriginais.includes(p.id)) {
          const observacaoAtualizada = p.observacao.replace(`[Consolidado no pedido ${pedidoConsolidado.numero}]`, '[Junção revertida]');
          
          return {
            ...p,
            status: "pendente",
            juntoComPedido: null,
            disponivelParaJuncao: true,
            observacao: observacaoAtualizada
          };
        }
        
        if (p.id === pedidoConsolidado.id) {
          return {
            ...p,
            status: "revertido",
            observacao: p.observacao + " [Junção revertida]",
            disponivelParaJuncao: false
          };
        }
        
        return p;
      });
      
      setPedidos(pedidosAtualizados);
      
      alert(`Junção do pedido ${pedidoConsolidado.numero} revertida com sucesso.`);
      
    } catch (error) {
      console.error("Erro ao reverter junção de pedidos", error);
      alert("Ocorreu um erro ao tentar reverter a junção. Tente novamente.");
    }
  };

  const renderJuncaoDialog = () => (
    <Dialog open={juncaoDialogOpen} onOpenChange={setJuncaoDialogOpen}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Juntar Pedidos</DialogTitle>
          <DialogDescription>
            Selecione os pedidos que deseja juntar com o pedido {pedidoParaJuncao?.numero}
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <div className="p-4 mb-4 bg-blue-50 rounded-lg border border-blue-100">
            <h3 className="font-semibold text-blue-800 mb-2">Pedido Base</h3>
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">
                  <span className="text-gray-600">Pedido:</span> {pedidoParaJuncao?.numero}
                </p>
                <p className="text-sm">
                  <span className="text-gray-600">Cliente:</span> {pedidoParaJuncao?.cliente.nome}
                </p>
                <p className="text-sm">
                  <span className="text-gray-600">Total:</span> {formatCurrency(pedidoParaJuncao?.total || 0)}
                </p>
              </div>
              <div>
                <p className="text-sm">
                  <span className="text-gray-600">Data:</span> {formatarDataSegura(pedidoParaJuncao?.data)}
                </p>
                <p className="text-sm">
                  <span className="text-gray-600">Status:</span> {pedidoParaJuncao?.status}
                </p>
                <p className="text-sm">
                  <span className="text-gray-600">Itens:</span> {pedidoParaJuncao?.itens}
                </p>
              </div>
              <div>
                <p className="text-xs italic max-w-md truncate">
                  <span className="text-gray-600">Observação:</span> {pedidoParaJuncao?.observacao}
                </p>
              </div>
            </div>
          </div>

          <h3 className="font-semibold mb-2">Pedidos disponíveis para junção</h3>
          <div className="border rounded-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12 text-center">Selecionar</TableHead>
                  <TableHead>Número</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Itens</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pedidos
                  .filter(p => 
                    p.id !== pedidoParaJuncao?.id && 
                    p.cliente.id === pedidoParaJuncao?.cliente.id && 
                    p.status !== "cancelado" && 
                    p.status !== "entregue" &&
                    !p.juntoComPedido &&
                    p.disponivelParaJuncao
                  )
                  .map(pedido => (
                    <TableRow key={pedido.id}>
                      <TableCell className="text-center">
                        <Checkbox 
                          checked={pedidosSelecionadosParaJuncao.includes(pedido.id)}
                          onCheckedChange={() => toggleSelecionarPedidoParaJuncao(pedido.id)}
                        />
                      </TableCell>
                      <TableCell>{pedido.numero}</TableCell>
                      <TableCell>{formatarDataSegura(pedido.data)}</TableCell>
                      <TableCell>{getStatusBadge(pedido.status)}</TableCell>
                      <TableCell>{formatCurrency(pedido.total)}</TableCell>
                      <TableCell>{pedido.itens}</TableCell>
                    </TableRow>
                  ))
                }
                
                {pedidos.filter(p => 
                  p.id !== pedidoParaJuncao?.id && 
                  p.cliente.id === pedidoParaJuncao?.cliente.id && 
                  p.status !== "cancelado" && 
                  p.status !== "entregue" &&
                  !p.juntoComPedido &&
                  p.disponivelParaJuncao
                ).length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-4 text-gray-500">
                      Não há pedidos disponíveis para junção com este pedido.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          
          {pedidosSelecionadosParaJuncao.length > 0 && (
            <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
              <h3 className="font-semibold text-blue-800 mb-2">Resumo da Junção</h3>
              <p className="mb-2">
                <span className="text-gray-600">Pedidos a serem juntados:</span> {pedidosSelecionadosParaJuncao.length + 1}
              </p>
              <p className="mb-2">
                <span className="text-gray-600">Total de itens:</span> {
                  pedidoParaJuncao.itens + 
                  pedidosSelecionadosParaJuncao.reduce((sum, id) => 
                    sum + (pedidos.find(p => p.id === id)?.itens || 0), 0
                  )
                }
              </p>
              <p>
                <span className="text-gray-600">Valor total:</span> {
                  formatCurrency(
                    pedidoParaJuncao.total + 
                    pedidosSelecionadosParaJuncao.reduce((sum, id) => 
                      sum + (pedidos.find(p => p.id === id)?.total || 0), 0
                    )
                  )
                }
              </p>
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => setJuncaoDialogOpen(false)}
          >
            Cancelar
          </Button>
          <Button 
            onClick={realizarJuncaoPedidos}
            disabled={pedidosSelecionadosParaJuncao.length === 0}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Layers className="w-4 h-4 mr-2" />
            Juntar Pedidos
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gerenciamento de Pedidos</h1>
          <p className="text-gray-500 mt-1">
            Visualize, gerencie e acompanhe todos os pedidos
          </p>
        </div>
        <Button 
          onClick={() => navigate(createPageUrl('NovoPedido'))}
          className="bg-green-600 hover:bg-green-700"
        >
          <PlusCircle className="w-4 h-4 mr-2" />
          Novo Pedido
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar pedidos..."
            className="pl-10 w-full"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2 w-full md:w-auto">
          <Select 
            value={statusFilter} 
            onValueChange={setStatusFilter}
          >
            <SelectTrigger className="w-full md:w-[180px]">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4" />
                <SelectValue placeholder="Status" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Status</SelectItem>
              <SelectItem value="pendente">Pendente</SelectItem>
              <SelectItem value="aprovado">Aprovado</SelectItem>
              <SelectItem value="processando">Processando</SelectItem>
              <SelectItem value="enviado">Enviado</SelectItem>
              <SelectItem value="entregue">Entregue</SelectItem>
              <SelectItem value="cancelado">Cancelado</SelectItem>
              <SelectItem value="aguardando_pagamento">Aguardando Pagamento</SelectItem>
              <SelectItem value="consolidado">Consolidado</SelectItem>
            </SelectContent>
          </Select>

          {selectedPedidos.length > 0 && (
            <div className="flex gap-2">
              <Button variant="outline" size="icon">
                <Printer className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Download className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-lg border overflow-hidden">
        {loading ? (
          <div className="flex justify-center items-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">
                    <Checkbox 
                      checked={selectedPedidos.length > 0 && selectedPedidos.length === filteredPedidos.length}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedPedidos(filteredPedidos.map(p => p.id));
                        } else {
                          setSelectedPedidos([]);
                        }
                      }}
                    />
                  </TableHead>
                  <TableHead>Pedido</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Observação</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPedidos.length > 0 ? (
                  filteredPedidos.map((pedido) => {
                    const elegívelParaJuncao = pedidoContemTermoJuncao(pedido.observacao) && 
                                              pedido.disponivelParaJuncao &&
                                              pedido.status !== "cancelado" && 
                                              pedido.status !== "entregue" &&
                                              !pedido.juntoComPedido;
                    
                    const ehPedidoConsolidado = pedido.pedidosOriginais && pedido.pedidosOriginais.length > 0;
                    
                    const foiMesclado = pedido.juntoComPedido !== null;
                    
                    return (
                      <TableRow 
                        key={pedido.id}
                        className={foiMesclado ? "bg-gray-50" : ""}
                      >
                        <TableCell>
                          <Checkbox 
                            checked={selectedPedidos.includes(pedido.id)}
                            onCheckedChange={() => handlePedidoSelect(pedido.id)}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="font-medium flex items-center gap-2">
                            {foiMesclado && (
                              <Badge variant="outline" className="font-normal">
                                Mesclado
                              </Badge>
                            )}
                            {ehPedidoConsolidado && (
                              <Badge className="bg-purple-100 text-purple-800 font-normal">
                                Consolidado
                              </Badge>
                            )}
                            {pedido.numero}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback>{pedido.cliente.avatar}</AvatarFallback>
                            </Avatar>
                            <span>{pedido.cliente.nome}</span>
                          </div>
                        </TableCell>
                        <TableCell>{formatarDataSegura(pedido.data)}</TableCell>
                        <TableCell>{getStatusBadge(pedido.status)}</TableCell>
                        <TableCell>{formatCurrency(pedido.total)}</TableCell>
                        <TableCell>
                          <div className="max-w-xs truncate">
                            {pedido.observacao}
                            
                            {elegívelParaJuncao && (
                              <Button 
                                variant="link" 
                                size="sm" 
                                className="ml-2 text-blue-600 p-0 h-auto"
                                onClick={() => abrirDialogJuncaoPedidos(pedido)}
                              >
                                <ArrowRightLeft className="w-4 h-4 mr-1" />
                                Juntar Pedidos
                              </Button>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end">
                            <Button variant="ghost" size="icon" onClick={() => navigate(`${createPageUrl('DetalhePedido')}?id=${pedido.id}`)}>
                              <Eye className="w-4 h-4" />
                            </Button>
                            
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                <DropdownMenuItem onClick={() => navigate(`${createPageUrl('DetalhePedido')}?id=${pedido.id}`)}>
                                  <Eye className="w-4 h-4 mr-2" />
                                  Ver Detalhes
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => navigate(`${createPageUrl('EditarPedido')}?id=${pedido.id}`)}>
                                  <Edit className="w-4 h-4 mr-2" />
                                  Editar
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                
                                {elegívelParaJuncao && (
                                  <>
                                    <DropdownMenuItem onClick={() => abrirDialogJuncaoPedidos(pedido)}>
                                      <ArrowRightLeft className="w-4 h-4 mr-2" />
                                      Juntar Pedidos
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                  </>
                                )}
                                
                                {ehPedidoConsolidado && (
                                  <>
                                    <DropdownMenuItem onClick={() => reverterJuncaoPedidos(pedido)}>
                                      <RefreshCw className="w-4 h-4 mr-2" />
                                      Reverter Junção
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                  </>
                                )}
                                
                                <DropdownMenuItem>
                                  <Download className="w-4 h-4 mr-2" />
                                  Baixar Pedido
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Printer className="w-4 h-4 mr-2" />
                                  Imprimir
                                </DropdownMenuItem>
                                {pedido.status !== "cancelado" && (
                                  <DropdownMenuItem className="text-red-600">
                                    <Trash2 className="w-4 h-4 mr-2" />
                                    Cancelar Pedido
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                      {searchTerm || statusFilter !== "todos" ? (
                        <>
                          <ShoppingBag className="w-12 h-12 mx-auto text-gray-300 mb-2" />
                          <p>Nenhum pedido encontrado com os filtros aplicados.</p>
                          <Button 
                            variant="link" 
                            onClick={() => {
                              setSearchTerm("");
                              setStatusFilter("todos");
                            }}
                          >
                            Limpar Filtros
                          </Button>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-12 h-12 mx-auto text-gray-300 mb-2" />
                          <p>Não há pedidos registrados.</p>
                          <Button 
                            variant="link" 
                            onClick={() => navigate(createPageUrl('NovoPedido'))}
                          >
                            Criar um novo pedido
                          </Button>
                        </>
                      )}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {renderJuncaoDialog()}
    </div>
  );
}
