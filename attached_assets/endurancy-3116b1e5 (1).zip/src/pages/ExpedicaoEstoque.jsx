
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Box,
  Search,
  Plus,
  Check,
  X,
  ArrowDownUp,
  ChevronDown,
  Edit,
  Trash,
  PackageOpen,
  PackageCheck,
  Package,
  Truck,
  Map,
  MoreHorizontal,
  Calendar,
  AlertTriangle,
  Info,
  QrCode,
  ScanBarcode,
  Eye,
  History,
  Boxes,
  FileText,
  Filter,
  ArrowUpDown,
  BoxSelect
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

// Dados simulados para estoque de expedição
const mockInventory = [
  {
    id: "1",
    product_id: "PROD001",
    name: "Óleo CBD 10%",
    code: "CB10-001",
    category: "Óleos",
    stock_quantity: 45,
    minimum_quantity: 10,
    location: "A01-01",
    status: "disponivel",
    last_update: "2023-11-15T10:30:00",
    reserved: 5,
    batches: [
      {
        id: "1-1",
        batch_number: "LOT20231001",
        quantity: 30,
        expiry_date: "2025-10-01",
        production_date: "2023-10-01",
        status: "disponivel"
      },
      {
        id: "1-2",
        batch_number: "LOT20231015",
        quantity: 15,
        expiry_date: "2025-10-15",
        production_date: "2023-10-15",
        status: "disponivel"
      }
    ]
  },
  {
    id: "2",
    product_id: "PROD002",
    name: "Óleo CBD 20%",
    code: "CB20-002",
    category: "Óleos",
    stock_quantity: 25,
    minimum_quantity: 8,
    location: "A01-02",
    status: "disponivel",
    last_update: "2023-11-15T10:35:00",
    reserved: 2,
    batches: [
      {
        id: "2-1",
        batch_number: "LOT20231005",
        quantity: 25,
        expiry_date: "2025-10-05",
        production_date: "2023-10-05",
        status: "disponivel"
      }
    ]
  },
  {
    id: "3",
    product_id: "PROD003",
    name: "Óleo CBD 5%",
    code: "CB05-003",
    category: "Óleos",
    stock_quantity: 60,
    minimum_quantity: 15,
    location: "A01-03",
    status: "disponivel",
    last_update: "2023-11-15T10:40:00",
    reserved: 0,
    batches: [
      {
        id: "3-1",
        batch_number: "LOT20231010",
        quantity: 30,
        expiry_date: "2025-10-10",
        production_date: "2023-10-10",
        status: "disponivel"
      },
      {
        id: "3-2",
        batch_number: "LOT20231020",
        quantity: 30,
        expiry_date: "2025-10-20",
        production_date: "2023-10-20",
        status: "disponivel"
      }
    ]
  },
  {
    id: "4",
    product_id: "PROD004",
    name: "Cápsulas CBD 20mg",
    code: "CAP20-004",
    category: "Cápsulas",
    stock_quantity: 100,
    minimum_quantity: 20,
    location: "B01-01",
    status: "disponivel",
    last_update: "2023-11-15T10:45:00",
    reserved: 10,
    batches: [
      {
        id: "4-1",
        batch_number: "LOT20231012",
        quantity: 50,
        expiry_date: "2025-10-12",
        production_date: "2023-10-12",
        status: "disponivel"
      },
      {
        id: "4-2",
        batch_number: "LOT20231022",
        quantity: 50,
        expiry_date: "2025-10-22",
        production_date: "2023-10-22",
        status: "disponivel"
      }
    ]
  },
  {
    id: "5",
    product_id: "PROD005",
    name: "Pomada CBD",
    code: "POM-005",
    category: "Tópicos",
    stock_quantity: 30,
    minimum_quantity: 10,
    location: "C01-01",
    status: "disponivel",
    last_update: "2023-11-15T10:50:00",
    reserved: 5,
    batches: [
      {
        id: "5-1",
        batch_number: "LOT20231015",
        quantity: 30,
        expiry_date: "2025-10-15",
        production_date: "2023-10-15",
        status: "disponivel"
      }
    ]
  },
  {
    id: "6",
    product_id: "PROD006",
    name: "Camiseta Associação",
    code: "CAM-006",
    category: "Produtos",
    stock_quantity: 15,
    minimum_quantity: 5,
    location: "D01-01",
    status: "disponivel",
    last_update: "2023-11-15T10:55:00",
    reserved: 0,
    batches: [
      {
        id: "6-1",
        batch_number: "N/A",
        quantity: 15,
        expiry_date: null,
        production_date: "2023-09-01",
        status: "disponivel"
      }
    ]
  },
  {
    id: "7",
    product_id: "PROD007",
    name: "Óleo CBD 15%",
    code: "CB15-007",
    category: "Óleos",
    stock_quantity: 3,
    minimum_quantity: 10,
    location: "A01-04",
    status: "critico",
    last_update: "2023-11-15T11:00:00",
    reserved: 2,
    batches: [
      {
        id: "7-1",
        batch_number: "LOT20231025",
        quantity: 3,
        expiry_date: "2025-10-25",
        production_date: "2023-10-25",
        status: "disponivel"
      }
    ]
  }
];

// Dados simulados para movimentações
const mockMovements = [
  {
    id: "1",
    product_id: "PROD001",
    product_name: "Óleo CBD 10%",
    type: "entrada",
    quantity: 30,
    batch: "LOT20231001",
    date: "2023-10-02T14:30:00",
    user: "Ana Silva",
    source: "Produção",
    destination: "Expedição",
    notes: "Entrada do lote de produção"
  },
  {
    id: "2",
    product_id: "PROD001",
    product_name: "Óleo CBD 10%",
    type: "entrada",
    quantity: 15,
    batch: "LOT20231015",
    date: "2023-10-16T10:15:00",
    user: "Ana Silva",
    source: "Produção",
    destination: "Expedição",
    notes: "Entrada do lote de produção"
  },
  {
    id: "3",
    product_id: "PROD001",
    product_name: "Óleo CBD 10%",
    type: "saida",
    quantity: 2,
    batch: "LOT20231001",
    date: "2023-10-20T11:45:00",
    user: "Carlos Eduardo",
    source: "Expedição",
    destination: "Pedido PED-12345",
    notes: "Saída para atender pedido"
  },
  {
    id: "4",
    product_id: "PROD002",
    product_name: "Óleo CBD 20%",
    type: "entrada",
    quantity: 25,
    batch: "LOT20231005",
    date: "2023-10-06T09:30:00",
    user: "Ana Silva",
    source: "Produção",
    destination: "Expedição",
    notes: "Entrada do lote de produção"
  },
  {
    id: "5",
    product_id: "PROD002",
    product_name: "Óleo CBD 20%",
    type: "saida",
    quantity: 3,
    batch: "LOT20231005",
    date: "2023-10-25T14:20:00",
    user: "Carlos Eduardo",
    source: "Expedição",
    destination: "Pedido PED-12347",
    notes: "Saída para atender pedido"
  }
];

export default function ExpedicaoEstoque() {
  const [inventory, setInventory] = useState(mockInventory);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortField, setSortField] = useState("name");
  const [sortDirection, setSortDirection] = useState("asc");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [productDialogOpen, setProductDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("info");
  const [movements, setMovements] = useState(mockMovements);
  const [productHistory, setProductHistory] = useState([]);
  
  // Filtragem e ordenação dos produtos
  const filteredInventory = inventory
    .filter(product => {
      // Filtro de busca
      const matchesSearch = 
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.location.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Filtro de categoria
      const matchesCategory = categoryFilter === "all" || product.category === categoryFilter;
      
      // Filtro de status
      const matchesStatus = statusFilter === "all" || product.status === statusFilter;
      
      return matchesSearch && matchesCategory && matchesStatus;
    })
    .sort((a, b) => {
      // Ordenação
      if (sortField === "name") {
        return sortDirection === "asc" 
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      } else if (sortField === "stock") {
        return sortDirection === "asc"
          ? a.stock_quantity - b.stock_quantity
          : b.stock_quantity - a.stock_quantity;
      } else if (sortField === "location") {
        return sortDirection === "asc"
          ? a.location.localeCompare(b.location)
          : b.location.localeCompare(a.location);
      }
      return 0;
    });
  
  // Lista única de categorias para o filtro
  const categories = ["all", ...new Set(inventory.map(product => product.category))];
  
  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };
  
  const handleViewProduct = (product) => {
    setSelectedProduct(product);
    
    // Obter histórico de movimentações para o produto
    const productHistory = movements.filter(
      movement => movement.product_id === product.product_id
    ).sort((a, b) => new Date(b.date) - new Date(a.date));
    
    setProductHistory(productHistory);
    setProductDialogOpen(true);
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
  };
  
  const formatDateTime = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return date.toLocaleString('pt-BR');
  };
  
  const getStockStatus = (product) => {
    const availableStock = product.stock_quantity - product.reserved;
    
    if (availableStock <= 0) {
      return {
        badge: <Badge className="bg-red-100 text-red-800">Esgotado</Badge>,
        className: "text-red-800"
      };
    } else if (product.stock_quantity < product.minimum_quantity) {
      return {
        badge: <Badge className="bg-amber-100 text-amber-800">Crítico</Badge>,
        className: "text-amber-800"
      };
    } else if (product.stock_quantity < product.minimum_quantity * 1.5) {
      return {
        badge: <Badge className="bg-yellow-100 text-yellow-800">Baixo</Badge>,
        className: "text-yellow-800"
      };
    } else {
      return {
        badge: <Badge className="bg-green-100 text-green-800">Normal</Badge>,
        className: "text-green-800"
      };
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Estoque da Expedição</h1>
          <p className="text-gray-500 mt-1">
            Gerencie o estoque de produtos prontos para envio
          </p>
        </div>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between bg-white p-4 rounded-lg shadow-sm">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar produtos..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as Categorias</SelectItem>
              {categories.filter(c => c !== "all").map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Status</SelectItem>
              <SelectItem value="disponivel">Disponível</SelectItem>
              <SelectItem value="critico">Crítico</SelectItem>
              <SelectItem value="esgotado">Esgotado</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {filteredInventory.length === 0 ? (
        <Card className="w-full">
          <CardContent className="flex flex-col items-center justify-center p-10">
            <Boxes className="h-16 w-16 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium">Nenhum produto encontrado</h3>
            <p className="text-gray-500 text-center mt-1">
              Não foram encontrados produtos com os filtros aplicados.
            </p>
            <Button variant="outline" className="mt-4" onClick={() => {
              setSearchTerm("");
              setCategoryFilter("all");
              setStatusFilter("all");
            }}>
              Limpar Filtros
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="bg-white rounded-lg overflow-hidden border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12"></TableHead>
                <TableHead onClick={() => handleSort("name")} className="cursor-pointer hover:bg-gray-50">
                  <div className="flex items-center gap-1">
                    Produto
                    {sortField === "name" && (
                      <ArrowUpDown className={`h-4 w-4 ${sortDirection === "desc" ? "rotate-180" : ""}`} />
                    )}
                  </div>
                </TableHead>
                <TableHead>Código</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead onClick={() => handleSort("location")} className="cursor-pointer hover:bg-gray-50">
                  <div className="flex items-center gap-1">
                    Localização
                    {sortField === "location" && (
                      <ArrowUpDown className={`h-4 w-4 ${sortDirection === "desc" ? "rotate-180" : ""}`} />
                    )}
                  </div>
                </TableHead>
                <TableHead onClick={() => handleSort("stock")} className="cursor-pointer hover:bg-gray-50">
                  <div className="flex items-center gap-1">
                    Estoque
                    {sortField === "stock" && (
                      <ArrowUpDown className={`h-4 w-4 ${sortDirection === "desc" ? "rotate-180" : ""}`} />
                    )}
                  </div>
                </TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInventory.map((product) => {
                const stockStatus = getStockStatus(product);
                const availableStock = product.stock_quantity - product.reserved;
                
                return (
                  <TableRow key={product.id}>
                    <TableCell>
                      <div className={`p-2 rounded-lg ${
                        availableStock <= 0 ? 'bg-red-100' :
                        product.stock_quantity < product.minimum_quantity ? 'bg-amber-100' :
                        product.stock_quantity < product.minimum_quantity * 1.5 ? 'bg-yellow-100' :
                        'bg-green-100'
                      }`}>
                        <Package className={`h-5 w-5 ${
                          availableStock <= 0 ? 'text-red-600' :
                          product.stock_quantity < product.minimum_quantity ? 'text-amber-600' :
                          product.stock_quantity < product.minimum_quantity * 1.5 ? 'text-yellow-600' :
                          'text-green-600'
                        }`} />
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell className="font-mono text-sm">{product.code}</TableCell>
                    <TableCell>{product.category}</TableCell>
                    <TableCell>{product.location}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className={`font-medium ${stockStatus.className}`}>
                          {product.stock_quantity}
                        </span>
                        {product.reserved > 0 && (
                          <span className="text-xs text-gray-500">
                            ({product.reserved} reservado)
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{stockStatus.badge}</TableCell>
                    <TableCell>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleViewProduct(product)} 
                        className="h-8 px-2"
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Detalhes
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
      
      {/* Dialog para detalhes do produto */}
      <Dialog open={productDialogOpen} onOpenChange={setProductDialogOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          {selectedProduct && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  {selectedProduct.name}
                </DialogTitle>
                <DialogDescription>
                  Código: <span className="font-mono">{selectedProduct.code}</span> • 
                  Categoria: {selectedProduct.category} • 
                  Localização: {selectedProduct.location}
                </DialogDescription>
              </DialogHeader>
              
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-3 mb-4">
                  <TabsTrigger value="info">Informações</TabsTrigger>
                  <TabsTrigger value="lotes">Lotes</TabsTrigger>
                  <TabsTrigger value="historico">Histórico</TabsTrigger>
                </TabsList>
                
                <TabsContent value="info" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">Estoque</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-500">Total em Estoque:</span>
                            <span className="font-medium">{selectedProduct.stock_quantity}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Reservado:</span>
                            <span className="font-medium">{selectedProduct.reserved}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Disponível:</span>
                            <span className="font-medium">{selectedProduct.stock_quantity - selectedProduct.reserved}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Estoque Mínimo:</span>
                            <span className="font-medium">{selectedProduct.minimum_quantity}</span>
                          </div>
                          
                          <div className="pt-2">
                            <Label className="text-xs text-gray-500 mb-1">Nível de Estoque</Label>
                            <div className="relative pt-1">
                              <Progress 
                                value={(selectedProduct.stock_quantity / (selectedProduct.minimum_quantity * 2)) * 100}
                                className={`h-2 ${
                                  selectedProduct.stock_quantity <= 0 ? 'bg-red-500' :
                                  selectedProduct.stock_quantity < selectedProduct.minimum_quantity ? 'bg-amber-500' :
                                  selectedProduct.stock_quantity < selectedProduct.minimum_quantity * 1.5 ? 'bg-yellow-500' :
                                  'bg-green-500'
                                }`}
                              />
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">Detalhes</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-500">ID do Produto:</span>
                            <span className="font-mono text-sm">{selectedProduct.product_id}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Localização:</span>
                            <span className="font-medium">{selectedProduct.location}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Última Atualização:</span>
                            <span className="font-medium">{formatDateTime(selectedProduct.last_update)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Status:</span>
                            <span>{getStockStatus(selectedProduct).badge}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Ações</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        <Button size="sm" variant="outline" className="flex items-center gap-1">
                          <ScanBarcode className="h-4 w-4" />
                          Ler Código
                        </Button>
                        <Button size="sm" variant="outline" className="flex items-center gap-1">
                          <QrCode className="h-4 w-4" />
                          Gerar QR Code
                        </Button>
                        <Button size="sm" variant="outline" className="flex items-center gap-1">
                          <ArrowDownUp className="h-4 w-4" />
                          Movimentar
                        </Button>
                        <Button size="sm" variant="outline" className="flex items-center gap-1">
                          <FileText className="h-4 w-4" />
                          Relatório
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="lotes" className="space-y-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <BoxSelect className="h-5 w-5" />
                        Lotes Disponíveis
                      </CardTitle>
                      <CardDescription>
                        {selectedProduct.batches.length} {selectedProduct.batches.length === 1 ? 'lote' : 'lotes'} disponíveis
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Lote</TableHead>
                            <TableHead>Quantidade</TableHead>
                            <TableHead>Fabricação</TableHead>
                            <TableHead>Validade</TableHead>
                            <TableHead>Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {selectedProduct.batches.map(batch => (
                            <TableRow key={batch.id}>
                              <TableCell className="font-medium font-mono">{batch.batch_number}</TableCell>
                              <TableCell>{batch.quantity}</TableCell>
                              <TableCell>{formatDate(batch.production_date)}</TableCell>
                              <TableCell>{formatDate(batch.expiry_date)}</TableCell>
                              <TableCell>
                                <Badge className="bg-green-100 text-green-800">
                                  Disponível
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="historico" className="space-y-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <History className="h-5 w-5" />
                        Histórico de Movimentações
                      </CardTitle>
                      <CardDescription>
                        {productHistory.length} {productHistory.length === 1 ? 'registro' : 'registros'} encontrados
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {productHistory.length === 0 ? (
                        <div className="text-center py-8">
                          <Info className="h-10 w-10 text-gray-300 mx-auto mb-3" />
                          <p className="text-gray-500">Nenhum registro de movimentação encontrado para este produto.</p>
                        </div>
                      ) : (
                        <div className="space-y-4 max-h-80 overflow-y-auto pr-2">
                          {productHistory.map(movement => (
                            <div 
                              key={movement.id} 
                              className={`p-3 rounded-lg border ${
                                movement.type === "entrada" ? "border-green-200 bg-green-50" : 
                                "border-amber-200 bg-amber-50"
                              }`}
                            >
                              <div className="flex justify-between">
                                <div className="flex items-center gap-2">
                                  {movement.type === "entrada" ? (
                                    <Badge className="bg-green-100 text-green-800">Entrada</Badge>
                                  ) : (
                                    <Badge className="bg-amber-100 text-amber-800">Saída</Badge>
                                  )}
                                  <span className="font-medium">{movement.quantity} unidades</span>
                                </div>
                                <span className="text-sm text-gray-500">{formatDateTime(movement.date)}</span>
                              </div>
                              
                              <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                                <div>
                                  <span className="text-gray-500">Lote:</span>{" "}
                                  <span className="font-mono">{movement.batch}</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Usuário:</span>{" "}
                                  <span>{movement.user}</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Origem:</span>{" "}
                                  <span>{movement.source}</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Destino:</span>{" "}
                                  <span>{movement.destination}</span>
                                </div>
                              </div>
                              
                              {movement.notes && (
                                <div className="mt-2 text-sm">
                                  <span className="text-gray-500">Observações:</span>{" "}
                                  <span>{movement.notes}</span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
