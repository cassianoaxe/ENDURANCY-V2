
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  FileText, 
  Upload, 
  Download, 
  Search, 
  Filter, 
  PlusCircle, 
  Folder, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Trash2, 
  CheckCircle2, 
  Clock,
  Calendar,
  User,
  FileCheck,
  Table as TableIcon
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const mockDocumentos = [
  {
    id: "doc-001",
    nome: "Termo de Adesão - Associado",
    tipo: "termo_adesao",
    formato: "PDF",
    tamanho: "1.2 MB",
    data_upload: "2023-02-15T10:30:00Z",
    status: "aprovado",
    associado: {
      id: "asc-001",
      nome: "Maria Silva",
      avatar: "MS"
    },
    categoria: "legal",
    url: "#"
  },
  {
    id: "doc-002",
    nome: "Laudo Médico - Cannabis Medicinal",
    tipo: "laudo_medico",
    formato: "PDF",
    tamanho: "2.5 MB",
    data_upload: "2023-03-10T14:20:00Z",
    status: "aprovado",
    associado: {
      id: "asc-002",
      nome: "João Pereira",
      avatar: "JP"
    },
    categoria: "medico",
    url: "#"
  },
  {
    id: "doc-003",
    nome: "Comprovante de Residência",
    tipo: "comprovante_residencia",
    formato: "JPG",
    tamanho: "845 KB",
    data_upload: "2023-04-05T09:15:00Z",
    status: "aprovado",
    associado: {
      id: "asc-003",
      nome: "Ana Costa",
      avatar: "AC"
    },
    categoria: "pessoal",
    url: "#"
  },
  {
    id: "doc-004",
    nome: "Autorização para Cultivo",
    tipo: "autorizacao_cultivo",
    formato: "PDF",
    tamanho: "1.1 MB",
    data_upload: "2023-05-20T16:45:00Z",
    status: "pendente",
    associado: {
      id: "asc-004",
      nome: "Roberto Alves",
      avatar: "RA"
    },
    categoria: "legal",
    url: "#"
  },
  {
    id: "doc-005",
    nome: "Documento de Identificação",
    tipo: "documento_identificacao",
    formato: "PDF",
    tamanho: "950 KB",
    data_upload: "2023-05-22T11:30:00Z",
    status: "pendente",
    associado: {
      id: "asc-001",
      nome: "Maria Silva",
      avatar: "MS"
    },
    categoria: "pessoal",
    url: "#"
  },
  {
    id: "doc-006",
    nome: "Ficha de Acompanhamento",
    tipo: "ficha_acompanhamento",
    formato: "DOCX",
    tamanho: "780 KB",
    data_upload: "2023-05-25T14:10:00Z",
    status: "aprovado",
    associado: {
      id: "asc-005",
      nome: "Fernanda Lima",
      avatar: "FL"
    },
    categoria: "medico",
    url: "#"
  }
];

export default function DocumentosAssociados() {
  const navigate = useNavigate();
  const [documentos, setDocumentos] = useState([]);
  const [filteredDocumentos, setFilteredDocumentos] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');
  const [categoriaFilter, setCategoriaFilter] = useState('todas');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("todos");
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);

  useEffect(() => {
    setTimeout(() => {
      setDocumentos(mockDocumentos);
      setFilteredDocumentos(mockDocumentos);
      setLoading(false);
    }, 500);
  }, []);

  useEffect(() => {
    let result = [...documentos];
    
    if (activeTab !== "todos") {
      result = result.filter(doc => doc.status === activeTab);
    }
    
    if (statusFilter !== 'todos') {
      result = result.filter(doc => doc.status === statusFilter);
    }
    
    if (categoriaFilter !== 'todas') {
      result = result.filter(doc => doc.categoria === categoriaFilter);
    }
    
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(doc => 
        doc.nome.toLowerCase().includes(term) || 
        doc.associado.nome.toLowerCase().includes(term)
      );
    }
    
    setFilteredDocumentos(result);
  }, [documentos, searchTerm, statusFilter, categoriaFilter, activeTab]);

  const getStatusBadge = (status) => {
    switch (status) {
      case 'aprovado':
        return <Badge className="bg-green-100 text-green-800">Aprovado</Badge>;
      case 'pendente':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'rejeitado':
        return <Badge className="bg-red-100 text-red-800">Rejeitado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getFormatIcon = (formato) => {
    switch (formato.toLowerCase()) {
      case 'pdf':
        return <FileText className="w-4 h-4 text-red-500" />;
      case 'docx':
        return <FileText className="w-4 h-4 text-blue-500" />;
      case 'jpg':
      case 'jpeg':
      case 'png':
        return <FileText className="w-4 h-4 text-green-500" />;
      case 'xlsx':
        return <TableIcon className="w-4 h-4 text-green-500" />;
      default:
        return <FileText className="w-4 h-4 text-gray-500" />;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const renderUploadDialog = () => {
    return (
      <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Fazer Upload de Documento</DialogTitle>
            <DialogDescription>
              Selecione o arquivo e preencha as informações para fazer o upload de um novo documento.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="border-2 border-dashed rounded-lg p-6 text-center">
              <div className="flex flex-col items-center">
                <Upload className="h-10 w-10 text-gray-400 mb-2" />
                <p className="text-sm text-gray-600 mb-1">
                  Arraste e solte arquivos aqui ou clique para selecionar
                </p>
                <p className="text-xs text-gray-500">
                  Suportados: PDF, DOCX, JPG, PNG (máx. 10MB)
                </p>
              </div>
              <Input
                type="file"
                className="hidden"
                id="file-upload"
              />
              <Button asChild variant="outline" className="mt-4">
                <label htmlFor="file-upload" className="cursor-pointer">
                  Selecionar Arquivo
                </label>
              </Button>
            </div>
            
            <div className="grid gap-4">
              <div className="grid grid-cols-4 gap-4">
                <div className="col-span-4">
                  <label htmlFor="doc-name" className="block text-sm font-medium text-gray-700 mb-1">
                    Nome do Documento
                  </label>
                  <Input
                    id="doc-name"
                    placeholder="Digite o nome do documento"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="doc-type" className="block text-sm font-medium text-gray-700 mb-1">
                    Tipo de Documento
                  </label>
                  <Select>
                    <SelectTrigger id="doc-type">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="termo_adesao">Termo de Adesão</SelectItem>
                      <SelectItem value="laudo_medico">Laudo Médico</SelectItem>
                      <SelectItem value="comprovante_residencia">Comprovante de Residência</SelectItem>
                      <SelectItem value="documento_identificacao">Documento de Identificação</SelectItem>
                      <SelectItem value="ficha_acompanhamento">Ficha de Acompanhamento</SelectItem>
                      <SelectItem value="autorizacao_cultivo">Autorização para Cultivo</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label htmlFor="doc-category" className="block text-sm font-medium text-gray-700 mb-1">
                    Categoria
                  </label>
                  <Select>
                    <SelectTrigger id="doc-category">
                      <SelectValue placeholder="Selecione a categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="legal">Legal</SelectItem>
                      <SelectItem value="medico">Médico</SelectItem>
                      <SelectItem value="pessoal">Pessoal</SelectItem>
                      <SelectItem value="financeiro">Financeiro</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <label htmlFor="doc-associado" className="block text-sm font-medium text-gray-700 mb-1">
                  Associado
                </label>
                <Select>
                  <SelectTrigger id="doc-associado">
                    <SelectValue placeholder="Selecione o associado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="asc-001">Maria Silva</SelectItem>
                    <SelectItem value="asc-002">João Pereira</SelectItem>
                    <SelectItem value="asc-003">Ana Costa</SelectItem>
                    <SelectItem value="asc-004">Roberto Alves</SelectItem>
                    <SelectItem value="asc-005">Fernanda Lima</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setUploadDialogOpen(false)}>
              Cancelar
            </Button>
            <Button>
              Fazer Upload
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Documentos dos Associados</h1>
        <p className="text-gray-500 mt-1">
          Gerencie todos os documentos dos associados da sua organização.
        </p>
      </div>

      <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4 sm:justify-between">
        <div className="flex-1 max-w-md relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar documento ou associado..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4">
          <Select value={categoriaFilter} onValueChange={setCategoriaFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas as categorias</SelectItem>
              <SelectItem value="legal">Legal</SelectItem>
              <SelectItem value="medico">Médico</SelectItem>
              <SelectItem value="pessoal">Pessoal</SelectItem>
              <SelectItem value="financeiro">Financeiro</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os status</SelectItem>
              <SelectItem value="aprovado">Aprovado</SelectItem>
              <SelectItem value="pendente">Pendente</SelectItem>
              <SelectItem value="rejeitado">Rejeitado</SelectItem>
            </SelectContent>
          </Select>
          
          <Button onClick={() => setUploadDialogOpen(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Novo Documento
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="todos">Todos</TabsTrigger>
          <TabsTrigger value="aprovado">Aprovados</TabsTrigger>
          <TabsTrigger value="pendente">Pendentes</TabsTrigger>
          <TabsTrigger value="rejeitado">Rejeitados</TabsTrigger>
        </TabsList>
        
        <TabsContent value={activeTab}>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Lista de Documentos</CardTitle>
              <CardDescription>
                {filteredDocumentos.length} documentos encontrados
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <div className="animate-spin w-8 h-8 border-t-2 border-blue-500 border-r-2 rounded-full mx-auto mb-4"></div>
                  <p className="text-gray-500">Carregando documentos...</p>
                </div>
              ) : filteredDocumentos.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900">Nenhum documento encontrado</h3>
                  <p className="text-gray-500 mt-2">
                    Não existem documentos que correspondam aos critérios selecionados.
                  </p>
                  <Button variant="outline" className="mt-4" onClick={() => {
                    setSearchTerm('');
                    setStatusFilter('todos');
                    setCategoriaFilter('todas');
                  }}>
                    Limpar filtros
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nome do documento</TableHead>
                        <TableHead>Associado</TableHead>
                        <TableHead>Categoria</TableHead>
                        <TableHead>Data de upload</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredDocumentos.map((documento) => (
                        <TableRow key={documento.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <div className="mr-2">
                                {getFormatIcon(documento.formato)}
                              </div>
                              <span className="font-medium">{documento.nome}</span>
                              <Badge variant="outline" className="ml-2 text-xs">
                                {documento.formato}
                              </Badge>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Avatar className="h-7 w-7 mr-2">
                                <AvatarFallback>
                                  {documento.associado.avatar}
                                </AvatarFallback>
                              </Avatar>
                              <span>{documento.associado.nome}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {documento.categoria === 'legal' && 'Legal'}
                              {documento.categoria === 'medico' && 'Médico'}
                              {documento.categoria === 'pessoal' && 'Pessoal'}
                              {documento.categoria === 'financeiro' && 'Financeiro'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {formatDate(documento.data_upload)}
                          </TableCell>
                          <TableCell>
                            {getStatusBadge(documento.status)}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                <DropdownMenuItem onClick={() => window.open(documento.url)}>
                                  <Eye className="w-4 h-4 mr-2" />
                                  Visualizar
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => window.open(documento.url)}>
                                  <Download className="w-4 h-4 mr-2" />
                                  Download
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                {documento.status === 'pendente' && (
                                  <>
                                    <DropdownMenuItem>
                                      <CheckCircle2 className="w-4 h-4 mr-2 text-green-500" />
                                      Aprovar
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <Trash2 className="w-4 h-4 mr-2 text-red-500" />
                                      Rejeitar
                                    </DropdownMenuItem>
                                  </>
                                )}
                                <DropdownMenuItem>
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Excluir
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {renderUploadDialog()}
    </div>
  );
}
