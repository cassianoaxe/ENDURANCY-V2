import React, { useState, useEffect } from 'react';
import { FeedbackConsulta } from '@/api/entities';
import { 
  Chart,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  PointElement,
  LineElement,
  ArcElement
} from 'chart.js';
import { Bar, Pie, Line } from 'react-chartjs-2';
import {
  Star,
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
  ArrowUpRight,
  ArrowDownRight,
  Users,
  BarChart4,
  Clock,
  Calendar
} from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

Chart.register(
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  PointElement,
  LineElement,
  ArcElement
);

export default function FeedbackAnalytics() {
  const [loading, setLoading] = useState(true);
  const [feedbackData, setFeedbackData] = useState([]);
  const [timeRange, setTimeRange] = useState('30d');
  const [filteredData, setFilteredData] = useState([]);
  const [metricsData, setMetricsData] = useState({
    avgRating: 0,
    totalFeedbacks: 0,
    positivePercentage: 0,
    recommendPercentage: 0,
    connectionQualityAvg: 0,
    usabilityAvg: 0,
    communicationAvg: 0,
    expectationsAvg: 0,
    problemSolvingAvg: 0
  });
  
  useEffect(() => {
    loadFeedbackData();
  }, []);
  
  useEffect(() => {
    if (feedbackData.length > 0) {
      filterDataByTimeRange(timeRange);
    }
  }, [timeRange, feedbackData]);
  
  const loadFeedbackData = async () => {
    setLoading(true);
    try {
      // Substituir pelo código real quando a API estiver pronta
      // const data = await FeedbackConsulta.list();
      
      // Simulação de dados
      setTimeout(() => {
        const mockData = generateMockFeedbackData(100);
        setFeedbackData(mockData);
        filterDataByTimeRange(timeRange);
        setLoading(false);
      }, 1500);
    } catch (error) {
      console.error("Erro ao carregar dados de feedback:", error);
      setLoading(false);
    }
  };
  
  const filterDataByTimeRange = (range) => {
    const now = new Date();
    let startDate;
    
    switch (range) {
      case '7d':
        startDate = new Date(now.setDate(now.getDate() - 7));
        break;
      case '30d':
        startDate = new Date(now.setDate(now.getDate() - 30));
        break;
      case '90d':
        startDate = new Date(now.setDate(now.getDate() - 90));
        break;
      case '12m':
        startDate = new Date(now.setFullYear(now.getFullYear() - 1));
        break;
      default:
        startDate = new Date(now.setDate(now.getDate() - 30));
    }
    
    const filtered = feedbackData.filter(feedback => {
      const feedbackDate = new Date(feedback.data_feedback);
      return feedbackDate >= startDate;
    });
    
    setFilteredData(filtered);
    calculateMetrics(filtered);
  };
  
  const calculateMetrics = (data) => {
    if (!data || data.length === 0) {
      setMetricsData({
        avgRating: 0,
        totalFeedbacks: 0,
        positivePercentage: 0,
        recommendPercentage: 0,
        connectionQualityAvg: 0,
        usabilityAvg: 0,
        communicationAvg: 0,
        expectationsAvg: 0,
        problemSolvingAvg: 0
      });
      return;
    }
    
    const sumRating = data.reduce((acc, item) => acc + item.avaliacao_geral, 0);
    const avgRating = sumRating / data.length;
    
    const positiveFeedbacks = data.filter(item => item.avaliacao_geral >= 4).length;
    const positivePercentage = (positiveFeedbacks / data.length) * 100;
    
    const recommendation = data.filter(item => item.recomendaria).length;
    const recommendPercentage = (recommendation / data.length) * 100;
    
    // Avaliações detalhadas (telemedicina)
    const teleFeedbacks = data.filter(item => item.tipo_consulta === 'telemedicina');
    
    const connectionQualitySum = teleFeedbacks.reduce((acc, item) => 
      acc + (item.avaliacoes_detalhadas?.qualidade_conexao || 0), 0);
    const connectionQualityAvg = teleFeedbacks.length ? connectionQualitySum / teleFeedbacks.length : 0;
    
    const usabilitySum = teleFeedbacks.reduce((acc, item) => 
      acc + (item.avaliacoes_detalhadas?.facilidade_uso || 0), 0);
    const usabilityAvg = teleFeedbacks.length ? usabilitySum / teleFeedbacks.length : 0;
    
    const communicationSum = teleFeedbacks.reduce((acc, item) => 
      acc + (item.avaliacoes_detalhadas?.comunicacao || 0), 0);
    const communicationAvg = teleFeedbacks.length ? communicationSum / teleFeedbacks.length : 0;
    
    const expectationsSum = teleFeedbacks.reduce((acc, item) => 
      acc + (item.avaliacoes_detalhadas?.atendimento_expectativas || 0), 0);
    const expectationsAvg = teleFeedbacks.length ? expectationsSum / teleFeedbacks.length : 0;
    
    const problemSolvingSum = teleFeedbacks.reduce((acc, item) => 
      acc + (item.avaliacoes_detalhadas?.resolucao_problemas || 0), 0);
    const problemSolvingAvg = teleFeedbacks.length ? problemSolvingSum / teleFeedbacks.length : 0;
    
    setMetricsData({
      avgRating,
      totalFeedbacks: data.length,
      positivePercentage,
      recommendPercentage,
      connectionQualityAvg,
      usabilityAvg,
      communicationAvg,
      expectationsAvg,
      problemSolvingAvg
    });
  };
  
  // Funções auxiliares para geração de gráficos
  
  const getMonthlyRatingData = () => {
    const months = [];
    const ratings = [];
    
    // Agrupar por mês e calcular média mensal
    const monthlyData = {};
    
    filteredData.forEach(feedback => {
      const date = new Date(feedback.data_feedback);
      const monthYear = `${date.getMonth() + 1}/${date.getFullYear()}`;
      
      if (!monthlyData[monthYear]) {
        monthlyData[monthYear] = {
          sum: 0,
          count: 0
        };
      }
      
      monthlyData[monthYear].sum += feedback.avaliacao_geral;
      monthlyData[monthYear].count += 1;
    });
    
    // Ordenar os meses e calcular médias
    Object.keys(monthlyData)
      .sort((a, b) => {
        const [aMonth, aYear] = a.split('/').map(Number);
        const [bMonth, bYear] = b.split('/').map(Number);
        return aYear === bYear ? aMonth - bMonth : aYear - bYear;
      })
      .forEach(month => {
        months.push(month);
        const avg = monthlyData[month].sum / monthlyData[month].count;
        ratings.push(avg.toFixed(2));
      });
    
    return {
      labels: months,
      datasets: [
        {
          label: 'Avaliação Média',
          data: ratings,
          backgroundColor: 'rgba(79, 70, 229, 0.2)',
          borderColor: 'rgba(79, 70, 229, 1)',
          borderWidth: 2,
          tension: 0.3
        }
      ]
    };
  };
  
  const getTelehealthMetricsData = () => {
    return {
      labels: [
        'Qualidade da Conexão',
        'Facilidade de Uso',
        'Comunicação',
        'Atendimento às Expectativas',
        'Resolução de Problemas'
      ],
      datasets: [
        {
          data: [
            metricsData.connectionQualityAvg,
            metricsData.usabilityAvg,
            metricsData.communicationAvg,
            metricsData.expectationsAvg,
            metricsData.problemSolvingAvg
          ],
          backgroundColor: [
            'rgba(255, 99, 132, 0.7)',
            'rgba(54, 162, 235, 0.7)',
            'rgba(255, 206, 86, 0.7)',
            'rgba(75, 192, 192, 0.7)',
            'rgba(153, 102, 255, 0.7)'
          ],
          borderWidth: 1
        }
      ]
    };
  };
  
  const getPositiveAspectsData = () => {
    // Agrupar pontos positivos mencionados
    const aspects = {};
    
    filteredData.forEach(feedback => {
      if (feedback.pontos_positivos && feedback.pontos_positivos.length) {
        feedback.pontos_positivos.forEach(point => {
          if (!aspects[point]) aspects[point] = 0;
          aspects[point] += 1;
        });
      }
    });
    
    // Ordenar por frequência e pegar os top 5
    const topAspects = Object.entries(aspects)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
    
    return {
      labels: topAspects.map(([label]) => label),
      datasets: [
        {
          label: 'Número de menções',
          data: topAspects.map(([, count]) => count),
          backgroundColor: 'rgba(16, 185, 129, 0.7)',
          borderColor: 'rgba(16, 185, 129, 1)',
          borderWidth: 1
        }
      ]
    };
  };
  
  const getReportedProblemsData = () => {
    // Agrupar problemas mencionados
    const problems = {};
    
    filteredData.forEach(feedback => {
      if (feedback.problemas_relatos && feedback.problemas_relatos.length) {
        feedback.problemas_relatos.forEach(problem => {
          if (!problems[problem]) problems[problem] = 0;
          problems[problem] += 1;
        });
      }
    });
    
    // Ordenar por frequência e pegar os top 5
    const topProblems = Object.entries(problems)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
    
    return {
      labels: topProblems.map(([label]) => label),
      datasets: [
        {
          label: 'Número de menções',
          data: topProblems.map(([, count]) => count),
          backgroundColor: 'rgba(244, 63, 94, 0.7)',
          borderColor: 'rgba(244, 63, 94, 1)',
          borderWidth: 1
        }
      ]
    };
  };
  
  // Função para gerar dados de teste
  const generateMockFeedbackData = (count) => {
    const mockData = [];
    const now = new Date();
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(now.getFullYear() - 1);
    
    const positivePoints = [
      "Atendimento pontual",
      "Médico atencioso",
      "Explicações claras",
      "Plataforma fácil de usar",
      "Boa qualidade de vídeo e áudio",
      "Economia de tempo e deslocamento",
      "Prescrição clara e detalhada"
    ];
    
    const problems = [
      "Dificuldades com a tecnologia",
      "Problemas de conexão",
      "Atraso no atendimento",
      "Dificuldade para anexar documentos",
      "Explicações insuficientes",
      "Interrupções durante a consulta"
    ];
    
    const medicosIds = ['med1', 'med2', 'med3', 'med4', 'med5'];
    
    for (let i = 0; i < count; i++) {
      // Data aleatória no último ano
      const feedbackDate = new Date(
        oneYearAgo.getTime() + Math.random() * (now.getTime() - oneYearAgo.getTime())
      );
      
      // Avaliação geral - tendência positiva
      const avgRating = Math.floor(Math.random() * 5) + 1;
      const isPositive = avgRating >= 4;
      
      // Seleção aleatória de pontos positivos com base na avaliação
      const selectedPositivePoints = [];
      const positiveCount = isPositive ? 
        Math.floor(Math.random() * 4) + 2 : // 2-5 pontos para avaliações positivas
        Math.floor(Math.random() * 2) + 1;  // 1-2 pontos para avaliações negativas
      
      for (let j = 0; j < positiveCount; j++) {
        const randomPoint = positivePoints[Math.floor(Math.random() * positivePoints.length)];
        if (!selectedPositivePoints.includes(randomPoint)) {
          selectedPositivePoints.push(randomPoint);
        }
      }
      
      // Seleção aleatória de problemas com base na avaliação
      const selectedProblems = [];
      const problemCount = isPositive ? 
        Math.floor(Math.random() * 2) : // 0-1 problemas para avaliações positivas
        Math.floor(Math.random() * 3) + 1; // 1-3 problemas para avaliações negativas
      
      for (let j = 0; j < problemCount; j++) {
        const randomProblem = problems[Math.floor(Math.random() * problems.length)];
        if (!selectedProblems.includes(randomProblem)) {
          selectedProblems.push(randomProblem);
        }
      }
      
      // Tipo de consulta (75% telemedicina, 25% presencial)
      const tipoConsulta = Math.random() < 0.75 ? 'telemedicina' : 'presencial';
      
      // Comentários genéricos
      const comentariosPositivos = [
        "Excelente atendimento, médico muito atencioso.",
        "Consegui resolver meu problema sem sair de casa.",
        "Experiência muito boa, super recomendo!",
        "Consulta rápida e eficiente, sem problemas."
      ];
      
      const comentariosNegativos = [
        "Tive dificuldades com a plataforma durante a consulta.",
        "A conexão estava instável, prejudicou a comunicação.",
        "O médico parecia apressado durante o atendimento.",
        "Esperava mais detalhes na explicação do tratamento."
      ];
      
      const comentarios = isPositive ? 
        comentariosPositivos[Math.floor(Math.random() * comentariosPositivos.length)] :
        comentariosNegativos[Math.floor(Math.random() * comentariosNegativos.length)];
      
      // Avaliações detalhadas para telemedicina
      let avaliacoesDetalhadas = null;
      if (tipoConsulta === 'telemedicina') {
        // Valores de base alinhados com a avaliação geral, com alguma variação
        const baseValue = avgRating;
        avaliacoesDetalhadas = {
          qualidade_conexao: Math.min(5, Math.max(1, baseValue + (Math.random() * 2 - 1))),
          facilidade_uso: Math.min(5, Math.max(1, baseValue + (Math.random() * 2 - 1))),
          comunicacao: Math.min(5, Math.max(1, baseValue + (Math.random() * 2 - 1))),
          atendimento_expectativas: Math.min(5, Math.max(1, baseValue + (Math.random() * 2 - 1))),
          resolucao_problemas: Math.min(5, Math.max(1, baseValue + (Math.random() * 2 - 1)))
        };
      }
      
      mockData.push({
        id: `feedback-${i}`,
        organization_id: 'org1',
        consulta_id: `consulta-${Math.floor(Math.random() * 1000)}`,
        paciente_id: `patient-${Math.floor(Math.random() * 50)}`,
        medico_id: medicosIds[Math.floor(Math.random() * medicosIds.length)],
        data_feedback: feedbackDate.toISOString(),
        tipo_consulta: tipoConsulta,
        avaliacao_geral: avgRating,
        avaliacoes_detalhadas: avaliacoesDetalhadas,
        comentarios: comentarios,
        sugestoes_melhorias: Math.random() > 0.7 ? "Sugestão de melhoria para o serviço." : "",
        pontos_positivos: selectedPositivePoints,
        problemas_relatos: selectedProblems,
        recomendaria: Math.random() < (isPositive ? 0.95 : 0.3), // 95% de chance para positivo, 30% para negativo
        usaria_novamente: Math.random() < (isPositive ? 0.98 : 0.2), // 98% de chance para positivo, 20% para negativo
        permitir_publicar: Math.random() > 0.5
      });
    }
    
    return mockData;
  };
  
  const renderMetricCard = (title, value, icon, trend) => {
    const trendIcon = trend === "up" ? <ArrowUpRight className="text-green-500 h-4 w-4" /> : 
                      trend === "down" ? <ArrowDownRight className="text-red-500 h-4 w-4" /> : null;
    
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-500">{title}</p>
              <h3 className="text-2xl font-bold mt-1">{value}</h3>
            </div>
            <div className="p-2 bg-indigo-100 dark:bg-indigo-900 rounded-full">
              {icon}
            </div>
          </div>
          {trend && (
            <div className="flex items-center mt-4 text-sm">
              {trendIcon}
              <span className={`ml-1 ${trend === "up" ? "text-green-500" : "text-red-500"}`}>
                {trend === "up" ? "Aumento" : "Queda"} desde o período anterior
              </span>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };
  
  const renderRecentFeedbacks = () => {
    // Pegar os 5 feedbacks mais recentes
    const recentFeedbacks = [...filteredData]
      .sort((a, b) => new Date(b.data_feedback) - new Date(a.data_feedback))
      .slice(0, 5);
    
    if (recentFeedbacks.length === 0) {
      return (
        <div className="text-center py-8">
          <p className="text-gray-500">Nenhum feedback encontrado no período selecionado.</p>
        </div>
      );
    }
    
    return (
      <div className="space-y-4">
        {recentFeedbacks.map((feedback, index) => (
          <Card key={feedback.id || index} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="flex items-start p-6">
                <div className="flex-shrink-0 mr-4">
                  <Avatar>
                    <AvatarFallback className="bg-indigo-100 text-indigo-700">
                      {feedback.paciente_id.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium">
                        Consulta com Paciente {feedback.paciente_id.split('-')[1]}
                      </p>
                      <p className="text-sm text-gray-500">
                        {new Date(feedback.data_feedback).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1">
                      {Array.from({length: 5}).map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-4 w-4 ${i < feedback.avaliacao_geral ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <p className="mt-2 text-sm">{feedback.comentarios}</p>
                  
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                      {feedback.tipo_consulta === 'telemedicina' ? 'Telemedicina' : 'Presencial'}
                    </Badge>
                    
                    {feedback.recomendaria && (
                      <Badge className="bg-green-50 text-green-700 border-green-200">
                        <ThumbsUp className="h-3 w-3 mr-1" /> Recomendaria
                      </Badge>
                    )}
                    
                    {!feedback.recomendaria && (
                      <Badge className="bg-red-50 text-red-700 border-red-200">
                        <ThumbsDown className="h-3 w-3 mr-1" /> Não recomendaria
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };
  
  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Análise de Feedback</h1>
          <p className="text-gray-500">Métricas e insights baseados em feedbacks de consulta</p>
        </div>
        
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Selecione o período" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">Últimos 7 dias</SelectItem>
            <SelectItem value="30d">Últimos 30 dias</SelectItem>
            <SelectItem value="90d">Últimos 90 dias</SelectItem>
            <SelectItem value="12m">Último ano</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Spinner className="h-8 w-8" />
          <span className="ml-3">Carregando dados...</span>
        </div>
      ) : (
        <Tabs defaultValue="overview">
          <TabsList className="mb-6">
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="detailed">Análise Detalhada</TabsTrigger>
            <TabsTrigger value="recents">Feedbacks Recentes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {renderMetricCard(
                "Avaliação Média", 
                metricsData.avgRating.toFixed(1), 
                <Star className="text-yellow-500 h-5 w-5 fill-yellow-500" />,
                "up"
              )}
              
              {renderMetricCard(
                "Total de Feedbacks", 
                metricsData.totalFeedbacks, 
                <MessageSquare className="text-indigo-500 h-5 w-5" />,
                null
              )}
              
              {renderMetricCard(
                "Feedbacks Positivos", 
                `${metricsData.positivePercentage.toFixed(0)}%`, 
                <ThumbsUp className="text-green-500 h-5 w-5" />,
                "up"
              )}
              
              {renderMetricCard(
                "Taxa de Recomendação", 
                `${metricsData.recommendPercentage.toFixed(0)}%`, 
                <Users className="text-blue-500 h-5 w-5" />,
                "up"
              )}
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Avaliação Média Mensal</CardTitle>
                  <CardDescription>Evolução da avaliação ao longo do tempo</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <Line 
                      data={getMonthlyRatingData()} 
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                          y: {
                            min: 1,
                            max: 5,
                            ticks: {
                              stepSize: 1
                            }
                          }
                        }
                      }}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Pontos Positivos Destacados</CardTitle>
                  <CardDescription>O que os pacientes mais apreciam</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <Bar 
                      data={getPositiveAspectsData()} 
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        indexAxis: 'y',
                        scales: {
                          x: {
                            beginAtZero: true
                          }
                        }
                      }}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="detailed">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <Card>
                <CardHeader>
                  <CardTitle>Avaliação de Telemedicina</CardTitle>
                  <CardDescription>Aspectos específicos das consultas virtuais</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-72">
                    <Pie 
                      data={getTelehealthMetricsData()} 
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                          legend: {
                            position: 'right'
                          }
                        }
                      }}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Principais Problemas Relatados</CardTitle>
                  <CardDescription>Pontos de melhoria identificados</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-72">
                    <Bar 
                      data={getReportedProblemsData()} 
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        indexAxis: 'y',
                        scales: {
                          x: {
                            beginAtZero: true
                          }
                        }
                      }}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Métricas Detalhadas</CardTitle>
                <CardDescription>Análise por tipo de consulta e categoria</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-medium mb-4">Telemedicina</h3>
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-500">Qualidade da Conexão</span>
                          <span className="text-sm font-medium">{metricsData.connectionQualityAvg.toFixed(1)}/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-500 h-2 rounded-full" 
                            style={{ width: `${(metricsData.connectionQualityAvg / 5) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-500">Facilidade de Uso</span>
                          <span className="text-sm font-medium">{metricsData.usabilityAvg.toFixed(1)}/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-purple-500 h-2 rounded-full" 
                            style={{ width: `${(metricsData.usabilityAvg / 5) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-500">Comunicação</span>
                          <span className="text-sm font-medium">{metricsData.communicationAvg.toFixed(1)}/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-500 h-2 rounded-full" 
                            style={{ width: `${(metricsData.communicationAvg / 5) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-4">Satisfação Geral</h3>
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-500">Atendimento às Expectativas</span>
                          <span className="text-sm font-medium">{metricsData.expectationsAvg.toFixed(1)}/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-yellow-500 h-2 rounded-full" 
                            style={{ width: `${(metricsData.expectationsAvg / 5) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-500">Resolução de Problemas</span>
                          <span className="text-sm font-medium">{metricsData.problemSolvingAvg.toFixed(1)}/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-red-500 h-2 rounded-full" 
                            style={{ width: `${(metricsData.problemSolvingAvg / 5) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-500">Recomendação</span>
                          <span className="text-sm font-medium">{metricsData.recommendPercentage.toFixed(0)}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-indigo-500 h-2 rounded-full" 
                            style={{ width: `${metricsData.recommendPercentage}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="recents">
            <div className="mb-6">
              <h2 className="text-xl font-bold mb-4">Feedbacks Recentes</h2>
              {renderRecentFeedbacks()}
            </div>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}