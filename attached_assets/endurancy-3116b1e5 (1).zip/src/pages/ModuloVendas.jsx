import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  BarChart, 
  Info, 
  Check, 
  Plus, 
  Search, 
  Settings,
  Download,
  ArrowRight,
  Building2,
  DollarSign,
  Package,
  Tag,
  QrCode,
  Truck,
  ShoppingCart,
  Activity,
  BadgePercent,
  X
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";

// Mock data for module
const moduleData = {
  name: "Vendas",
  description: "Gestão de pedidos, produtos e envios",
  icon: ShoppingBag,
  active_organizations: 22,
  total_revenue: 0, // Gratuito
  features: [
    "Gestão de pedidos",
    "Cadastro de produtos",
    "Etiquetas de envio",
    "Rastreabilidade de pedidos",
    "Notificações de status",
    "Integração com transportadoras"
  ],
  tiers: [
    {
      name: "Gratuito",
      price: 0,
      limit: "até 100 pedidos/mês",
      features: [
        { name: "Gestão de pedidos", included: true },
        { name: "Cadastro de produtos", included: true },
        { name: "Etiquetas de envio", included: true },
        { name: "Rastreabilidade básica", included: true },
        { name: "Notificações por email", included: true },
        { name: "Relatórios básicos", included: true }
      ]
    },
    {
      name: "Básico",
      price: 299,
      limit: "até 500 pedidos/mês",
      features: [
        { name: "Todas as funcionalidades gratuitas", included: true },
        { name: "Pedidos ilimitados", included: true },
        { name: "Integração com Correios", included: true },
        { name: "Automação de etiquetas", included: true },
        { name: "Gestão de estoque", included: true },
        { name: "Relatórios avançados", included: true }
      ]
    },
    {
      name: "Profissional",
      price: 599,
      limit: "pedidos ilimitados",
      features: [
        { name: "Todas as funcionalidades do plano Básico", included: true },
        { name: "Integração com múltiplas transportadoras", included: true },
        { name: "API para integrações", included: true },
        { name: "Gestão de devoluções", included: true },
        { name: "Rastreabilidade avançada", included: true },
        { name: "Dashboards personalizados", included: true }
      ]
    }
  ],
  organizations: [
    {
      id: "org1",
      name: "MediCannabis Farma",
      type: "Empresa",
      plan: "Gratuito",
      contact_name: "João Silva",
      since: "15/07/2023",
      status: "Ativo"
    },
    {
      id: "org2",
      name: "Associação Médica Verde",
      type: "Associação",
      plan: "Gratuito",
      contact_name: "Maria Oliveira",
      since: "12/07/2023",
      status: "Ativo"
    },
    {
      id: "org3",
      name: "Green Medical Brasil",
      type: "Empresa",
      plan: "Profissional",
      contact_name: "Ana Sousa",
      since: "20/07/2023",
      status: "Ativo"
    },
    {
      id: "org4",
      name: "Cultivo Sustentável Ltda",
      type: "Empresa",
      plan: "Gratuito",
      contact_name: "Ana Costa",
      since: "28/06/2023",
      status: "Ativo"
    }
  ]
};

export default function ModuloVendas() {
  const [activeTab, setActiveTab] = useState("overview");
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const filteredOrganizations = moduleData.organizations.filter(org => 
    org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    org.contact_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-green-100 rounded-lg">
            <ShoppingBag className="w-6 h-6 text-green-700" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">Módulo Vendas</h1>
              <Badge className="bg-blue-100 text-blue-800">Gratuito</Badge>
            </div>
            <p className="text-gray-500">Gestão de pedidos, produtos e envios</p>
          </div>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Adicionar a Organização
        </Button>
      </div>
      
      <Card className="bg-green-50 border-green-100">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BadgePercent className="h-5 w-5 text-green-600" />
            Módulo Gratuito para Todas as Organizações
          </CardTitle>
          <CardDescription>
            Este módulo está disponível gratuitamente para todas as organizações na plataforma Endurancy
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-gray-700">
              Oferecemos uma versão gratuita e completa do módulo de vendas para que todas as organizações possam gerenciar seus pedidos, 
              produtos, impressão de etiquetas e rastreabilidade. Essa iniciativa visa apoiar o crescimento das organizações do setor.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <ShoppingCart className="h-5 w-5 text-green-600" />
                  <h3 className="font-medium">Gestão de Pedidos</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Receba, processe e gerencie pedidos de forma eficiente. Acompanhe o status de cada pedido desde a criação até a entrega.
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <Package className="h-5 w-5 text-green-600" />
                  <h3 className="font-medium">Cadastro de Produtos</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Cadastre seus produtos com descrições, preços, imagens e detalhes completos. Organize-os em categorias e gerencie seu catálogo.
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <Tag className="h-5 w-5 text-green-600" />
                  <h3 className="font-medium">Etiquetas de Envio</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Gere e imprima etiquetas de envio para seus pedidos. Compatível com os principais serviços de entrega.
                </p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <Truck className="h-5 w-5 text-green-600" />
                  <h3 className="font-medium">Rastreabilidade</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Acompanhe o status de entrega dos pedidos e mantenha seus clientes informados sobre o andamento do envio.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full">
            Ver tutorial de utilização
          </Button>
        </CardFooter>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 w-full md:w-auto">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="organizations">Organizações ({moduleData.organizations.length})</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Organizações Utilizando</CardDescription>
                <CardTitle className="text-3xl font-bold">{moduleData.active_organizations}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-blue-600">
                  <Info className="w-4 h-4 mr-1" />
                  {moduleData.organizations.filter(org => org.plan === "Gratuito").length} no plano gratuito
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Pedidos Processados</CardDescription>
                <CardTitle className="text-3xl font-bold">3.254</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-green-600">
                  <Activity className="w-4 h-4 mr-1" />
                  +15% este mês
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Etiquetas Geradas</CardDescription>
                <CardTitle className="text-3xl font-bold">2.876</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-green-600">
                  <Activity className="w-4 h-4 mr-1" />
                  +23% este mês
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Funcionalidades por Plano</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Funcionalidade</th>
                        {moduleData.tiers.map((tier, index) => (
                          <th key={index} className="px-4 py-3 text-center text-sm font-medium text-gray-500">
                            <div>{tier.name}</div>
                            <div className="font-normal text-gray-400">{tier.price > 0 ? `R$ ${tier.price}/mês` : 'Gratuito'}</div>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        "Gestão de pedidos",
                        "Cadastro de produtos",
                        "Etiquetas de envio",
                        "Rastreabilidade",
                        "Notificações",
                        "Integrações com transportadoras",
                        "API para integrações",
                        "Relatórios avançados",
                        "Gestão de estoque",
                        "Múltiplas lojas"
                      ].map((feature, i) => (
                        <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                          <td className="px-4 py-3 text-sm text-gray-700">{feature}</td>
                          {moduleData.tiers.map((tier, j) => {
                            const included = 
                              j === 0 ? (i < 6 ? true : false) : 
                              j === 1 ? (i < 8 ? true : false) : 
                              true;
                            
                            return (
                              <td key={j} className="px-4 py-3 text-center">
                                {included ? (
                                  <Check className="h-5 w-5 text-green-600 mx-auto" />
                                ) : (
                                  <X className="h-5 w-5 text-gray-300 mx-auto" />
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="organizations" className="space-y-6 mt-6">
          <div className="flex flex-col sm:flex-row justify-between gap-4">
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input 
                placeholder="Buscar organizações..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Exportar Lista
            </Button>
          </div>
          
          <Card>
            <CardContent className="p-0">
              <div className="rounded-lg border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Organização</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Tipo</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Plano</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Contato</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Desde</th>
                        <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {isLoading ? (
                        [...Array(3)].map((_, i) => (
                          <tr key={i} className="animate-pulse bg-white">
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-32"></div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-20"></div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-24"></div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-32"></div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-20"></div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-16 ml-auto"></div>
                            </td>
                          </tr>
                        ))
                      ) : filteredOrganizations.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                            Nenhuma organização encontrada
                          </td>
                        </tr>
                      ) : (
                        filteredOrganizations.map((org, i) => (
                          <tr key={org.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-3">
                                <Avatar className="h-8 w-8">
                                  <AvatarFallback className="bg-primary/10 text-primary">
                                    {org.name.substring(0, 2).toUpperCase()}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-sm font-medium">{org.name}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700">{org.type}</td>
                            <td className="px-4 py-3">
                              <Badge className={org.plan === "Gratuito" ? "bg-blue-100 text-blue-800" : "bg-purple-100 text-purple-800"}>
                                {org.plan}
                              </Badge>
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700">{org.contact_name}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{org.since}</td>
                            <td className="px-4 py-3 text-right">
                              <Badge className="bg-green-100 text-green-800">
                                {org.status}
                              </Badge>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do Módulo</CardTitle>
              <CardDescription>
                Configurações gerais do módulo de Vendas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <Label htmlFor="module-active">Módulo ativo</Label>
                  <Switch id="module-active" defaultChecked />
                </div>
                <p className="text-sm text-gray-500">
                  Quando desativado, nenhuma organização poderá acessar este módulo
                </p>
              </div>
              
              <Separator />
              
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <Label htmlFor="free-plan">Plano gratuito disponível</Label>
                  <Switch id="free-plan" defaultChecked />
                </div>
                <p className="text-sm text-gray-500">
                  Permite que novas organizações utilizem o plano gratuito deste módulo
                </p>
              </div>
              
              <Separator />
              
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <Label htmlFor="auto-activate">Ativação automática para novas organizações</Label>
                  <Switch id="auto-activate" defaultChecked />
                </div>
                <p className="text-sm text-gray-500">
                  Ativa automaticamente este módulo para novas organizações criadas na plataforma
                </p>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label>Limite de pedidos mensais (plano gratuito)</Label>
                <Input type="number" defaultValue="100" min="1" />
                <p className="text-sm text-gray-500">
                  Número máximo de pedidos que uma organização pode processar no plano gratuito
                </p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-4">
              <Button variant="outline">Cancelar</Button>
              <Button 
                onClick={() => {
                  toast({
                    title: "Configurações salvas",
                    description: "As configurações do módulo foram atualizadas com sucesso."
                  });
                }}
              >
                Salvar Configurações
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Integrações</CardTitle>
              <CardDescription>
                Configure as integrações disponíveis para este módulo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Correios</Label>
                    <p className="text-sm text-gray-500">Integração para cálculo de frete e geração de etiquetas</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>
              
              <Separator />
              
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Transportadoras Parceiras</Label>
                    <p className="text-sm text-gray-500">Integrações com transportadoras parceiras</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>
              
              <Separator />
              
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>API Pública</Label>
                    <p className="text-sm text-gray-500">Disponibiliza API para integrações externas</p>
                  </div>
                  <Switch />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-4">
              <Button variant="outline">Cancelar</Button>
              <Button>Salvar Integrações</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}