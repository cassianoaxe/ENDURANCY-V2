import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Truck, 
  Search, 
  Package, 
  MapPin, 
  Clock, 
  FileText, 
  Mail, 
  MessageSquare,
  CheckCircle,
  Calendar,
  AlertTriangle,
  ArrowRight,
  ArrowRightCircle,
  ExternalLink,
  Copy
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";

// Dados mockados para demonstração
const pedidosComRastreio = [
  {
    id: 'P12346',
    cliente: 'João Pereira',
    email: 'joao.pereira@example.com',
    data: '22/07/2023',
    status: 'em_transporte',
    metodo_envio: 'Correios - SEDEX',
    rastreio: 'BR987654321',
    destino: 'São Paulo, SP',
    valor: 124.50,
    produtos: ['Óleo CBD 5%'],
    historico_rastreio: [
      { data: '23/07/2023 10:30', status: 'Objeto postado', local: 'Rio de Janeiro, RJ' },
      { data: '23/07/2023 16:45', status: 'Objeto em trânsito', local: 'Rio de Janeiro, RJ' },
      { data: '24/07/2023 08:15', status: 'Objeto em trânsito', local: 'São Paulo, SP' },
      { data: '24/07/2023 14:20', status: 'Saiu para entrega', local: 'São Paulo, SP' }
    ]
  },
  {
    id: 'P12342',
    cliente: 'Ana Silva',
    email: 'ana.silva@example.com',
    data: '20/07/2023',
    status: 'entregue',
    metodo_envio: 'Correios - PAC',
    rastreio: 'BR123987456',
    destino: 'Belo Horizonte, MG',
    valor: 256.70,
    produtos: ['Óleo CBD 10%', 'Creme Tópico CBD'],
    historico_rastreio: [
      { data: '21/07/2023 09:20', status: 'Objeto postado', local: 'Rio de Janeiro, RJ' },
      { data: '21/07/2023 17:30', status: 'Objeto em trânsito', local: 'Rio de Janeiro, RJ' },
      { data: '22/07/2023 10:45', status: 'Objeto em trânsito', local: 'Juiz de Fora, MG' },
      { data: '23/07/2023 08:10', status: 'Objeto em trânsito', local: 'Belo Horizonte, MG' },
      { data: '23/07/2023 13:45', status: 'Saiu para entrega', local: 'Belo Horizonte, MG' },
      { data: '23/07/2023 16:30', status: 'Objeto entregue ao destinatário', local: 'Belo Horizonte, MG' }
    ]
  },
  {
    id: 'P12340',
    cliente: 'Carlos Mendes',
    email: 'carlos.mendes@example.com',
    data: '19/07/2023',
    status: 'entregue',
    metodo_envio: 'Transportadora',
    rastreio: 'TRP456789',
    destino: 'Curitiba, PR',
    valor: 345.90,
    produtos: ['Extrato Full Spectrum', 'Cápsulas CBD 20mg'],
    historico_rastreio: [
      { data: '20/07/2023 08:30', status: 'Pedido processado', local: 'Rio de Janeiro, RJ' },
      { data: '20/07/2023 14:15', status: 'Em rota de entrega', local: 'Rio de Janeiro, RJ' },
      { data: '21/07/2023 09:40', status: 'Em trânsito', local: 'São Paulo, SP' },
      { data: '22/07/2023 12:30', status: 'Em trânsito', local: 'Curitiba, PR' },
      { data: '22/07/2023 15:20', status: 'Saiu para entrega', local: 'Curitiba, PR' },
      { data: '22/07/2023 17:45', status: 'Entregue', local: 'Curitiba, PR' }
    ]
  },
  {
    id: 'P12335',
    cliente: 'Fernanda Lima',
    email: 'fernanda.lima@example.com',
    data: '17/07/2023',
    status: 'problema_entrega',
    metodo_envio: 'Correios - SEDEX',
    rastreio: 'BR456123789',
    destino: 'Salvador, BA',
    valor: 189.90,
    produtos: ['Óleo CBD 15%'],
    historico_rastreio: [
      { data: '18/07/2023 10:40', status: 'Objeto postado', local: 'Rio de Janeiro, RJ' },
      { data: '18/07/2023 16:20', status: 'Objeto em trânsito', local: 'Rio de Janeiro, RJ' },
      { data: '19/07/2023 09:15', status: 'Objeto em trânsito', local: 'Salvador, BA' },
      { data: '20/07/2023 10:30', status: 'Tentativa de entrega não efetuada', local: 'Salvador, BA' },
      { data: '20/07/2023 10:35', status: 'Motivo: Endereço incorreto', local: 'Salvador, BA' },
      { data: '20/07/2023 15:45', status: 'Objeto aguardando retirada', local: 'Salvador, BA' }
    ]
  }
];

export default function Rastreamento() {
  const [tabAtiva, setTabAtiva] = useState('em_transporte');
  const [pedidoSelecionado, setPedidoSelecionado] = useState(null);
  const [numeroRastreio, setNumeroRastreio] = useState('');
  const [termoBusca, setTermoBusca] = useState('');
  const [pedidosFiltrados, setPedidosFiltrados] = useState([]);
  const [notificacoesEmail, setNotificacoesEmail] = useState(true);
  const [notificacoesSMS, setNotificacoesSMS] = useState(false);

  useEffect(() => {
    filtrarPedidos();
  }, [tabAtiva, termoBusca]);

  const filtrarPedidos = () => {
    let resultados = pedidosComRastreio;
    
    // Filtrar por status
    if (tabAtiva !== 'todos') {
      resultados = resultados.filter(pedido => pedido.status === tabAtiva);
    }
    
    // Filtrar por termo de busca
    if (termoBusca) {
      resultados = resultados.filter(pedido => 
        pedido.id.toLowerCase().includes(termoBusca.toLowerCase()) ||
        pedido.cliente.toLowerCase().includes(termoBusca.toLowerCase()) ||
        pedido.rastreio.toLowerCase().includes(termoBusca.toLowerCase())
      );
    }
    
    setPedidosFiltrados(resultados);
    
    // Se houver apenas um resultado, seleciona automaticamente
    if (resultados.length === 1 && !pedidoSelecionado) {
      setPedidoSelecionado(resultados[0]);
    }
  };

  const buscarRastreio = () => {
    if (!numeroRastreio) {
      toast({
        title: "Erro na busca",
        description: "Digite um número de rastreamento válido.",
        variant: "destructive"
      });
      return;
    }
    
    const pedidoEncontrado = pedidosComRastreio.find(p => p.rastreio === numeroRastreio);
    
    if (pedidoEncontrado) {
      setPedidoSelecionado(pedidoEncontrado);
      toast({
        title: "Rastreamento encontrado",
        description: `Pedido #${pedidoEncontrado.id} encontrado com sucesso.`
      });
    } else {
      toast({
        title: "Código não encontrado",
        description: "Nenhum pedido encontrado com este código de rastreamento.",
        variant: "destructive"
      });
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'entregue':
        return <Badge className="bg-green-100 text-green-800">Entregue</Badge>;
      case 'em_transporte':
        return <Badge className="bg-blue-100 text-blue-800">Em Transporte</Badge>;
      case 'problema_entrega':
        return <Badge className="bg-red-100 text-red-800">Problema na Entrega</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  // Formatar moeda em reais
  const formatarMoeda = (valor) => {
    return valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  };

  const copiarRastreio = (codigo) => {
    navigator.clipboard.writeText(codigo);
    toast({
      title: "Código copiado",
      description: "Código de rastreamento copiado para a área de transferência."
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Rastreamento de Pedidos</h1>
          <p className="text-gray-500 mt-1">
            Acompanhe o status dos seus envios
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Buscar Rastreamento</CardTitle>
              <CardDescription>
                Digite o código de rastreamento para encontrar um pedido específico
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-3">
                <div className="flex-1">
                  <Input 
                    placeholder="Digite o código de rastreamento..." 
                    value={numeroRastreio}
                    onChange={(e) => setNumeroRastreio(e.target.value)}
                  />
                </div>
                <Button onClick={buscarRastreio}>
                  Buscar
                </Button>
              </div>
            </CardContent>
          </Card>

          <div>
            <Tabs value={tabAtiva} onValueChange={setTabAtiva}>
              <div className="flex justify-between items-center mb-4">
                <TabsList>
                  <TabsTrigger value="todos">Todos</TabsTrigger>
                  <TabsTrigger value="em_transporte">Em Transporte</TabsTrigger>
                  <TabsTrigger value="entregue">Entregues</TabsTrigger>
                  <TabsTrigger value="problema_entrega">Com Problemas</TabsTrigger>
                </TabsList>
                
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
                  <Input 
                    placeholder="Buscar pedido..." 
                    value={termoBusca}
                    onChange={(e) => setTermoBusca(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
              </div>
              
              <Card>
                <CardContent className="p-0">
                  {pedidosFiltrados.length === 0 ? (
                    <div className="p-8 text-center">
                      <Truck className="w-12 h-12 mx-auto text-gray-300 mb-3" />
                      <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhum pedido encontrado</h3>
                      <p className="text-gray-500">
                        Nenhum pedido corresponde aos filtros aplicados.
                      </p>
                      <Button variant="outline" className="mt-4" onClick={() => { setTabAtiva('todos'); setTermoBusca(''); }}>
                        Limpar filtros
                      </Button>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-gray-50">
                            <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Pedido</th>
                            <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Cliente</th>
                            <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Rastreio</th>
                            <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Destino</th>
                            <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">Status</th>
                            <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Ações</th>
                          </tr>
                        </thead>
                        <tbody>
                          {pedidosFiltrados.map((pedido) => (
                            <tr 
                              key={pedido.id} 
                              className={`border-b cursor-pointer hover:bg-gray-50 ${pedidoSelecionado?.id === pedido.id ? 'bg-blue-50' : ''}`}
                              onClick={() => setPedidoSelecionado(pedido)}
                            >
                              <td className="px-4 py-3 text-sm font-medium">#{pedido.id}</td>
                              <td className="px-4 py-3 text-sm text-gray-700">{pedido.cliente}</td>
                              <td className="px-4 py-3 text-sm text-gray-700 font-mono">{pedido.rastreio}</td>
                              <td className="px-4 py-3 text-sm text-gray-700">{pedido.destino}</td>
                              <td className="px-4 py-3 text-center">
                                {getStatusBadge(pedido.status)}
                              </td>
                              <td className="px-4 py-3 text-right">
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="gap-2"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setPedidoSelecionado(pedido);
                                  }}
                                >
                                  <ArrowRightCircle className="w-4 h-4" />
                                  <span className="hidden sm:inline">Detalhes</span>
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </Tabs>
          </div>
        </div>
        
        <div>
          {pedidoSelecionado ? (
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardDescription>Detalhes do Rastreamento</CardDescription>
                    <CardTitle className="flex items-center gap-2">
                      #{pedidoSelecionado.id}
                      {getStatusBadge(pedidoSelecionado.status)}
                    </CardTitle>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      title="Copiar código de rastreio"
                      onClick={() => copiarRastreio(pedidoSelecionado.rastreio)}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      title="Abrir rastreamento externo"
                      onClick={() => window.open(`https://rastreamento.correios.com.br/app/index.php`, '_blank')}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-xs text-gray-500">Código de Rastreio</p>
                      <p className="text-sm font-mono font-medium">{pedidoSelecionado.rastreio}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Data do Pedido</p>
                      <p className="text-sm">{pedidoSelecionado.data}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Cliente</p>
                      <p className="text-sm">{pedidoSelecionado.cliente}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Valor</p>
                      <p className="text-sm">{formatarMoeda(pedidoSelecionado.valor)}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-xs text-gray-500">Método de Envio</p>
                      <p className="text-sm">{pedidoSelecionado.metodo_envio}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-xs text-gray-500">Produtos</p>
                      <p className="text-sm">{pedidoSelecionado.produtos.join(', ')}</p>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-sm font-medium mb-3">Histórico de Rastreamento</h3>
                    <div className="space-y-4">
                      {pedidoSelecionado.historico_rastreio.map((evento, index) => (
                        <div key={index} className="relative pl-6">
                          {index < pedidoSelecionado.historico_rastreio.length - 1 && (
                            <div className="absolute top-5 left-[9px] w-[2px] h-full bg-gray-200"></div>
                          )}
                          <div className="flex gap-3">
                            <div className="absolute left-0 top-[6px] w-[18px] h-[18px] rounded-full bg-blue-100 border-2 border-blue-500 flex items-center justify-center">
                              {index === 0 && <Package className="w-3 h-3 text-blue-500" />}
                              {index === pedidoSelecionado.historico_rastreio.length - 1 && (
                                pedidoSelecionado.status === 'entregue' ? 
                                  <CheckCircle className="w-3 h-3 text-green-500" /> : 
                                  pedidoSelecionado.status === 'problema_entrega' ?
                                    <AlertTriangle className="w-3 h-3 text-red-500" /> :
                                    <Truck className="w-3 h-3 text-blue-500" />
                              )}
                            </div>
                            <div className="space-y-1">
                              <p className="text-sm font-medium">
                                {evento.status}
                              </p>
                              <div className="flex items-center gap-2 text-xs text-gray-500">
                                <Clock className="w-3 h-3" />
                                <span>{evento.data}</span>
                              </div>
                              <div className="flex items-center gap-2 text-xs text-gray-500">
                                <MapPin className="w-3 h-3" />
                                <span>{evento.local}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-4 flex-col items-start">
                <h3 className="text-sm font-medium mb-2">Notificações</h3>
                <div className="w-full space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="email-notif" className="flex items-center gap-2 text-sm">
                      <Mail className="w-4 h-4 text-gray-500" />
                      Notificações por email
                    </Label>
                    <Switch 
                      id="email-notif" 
                      checked={notificacoesEmail}
                      onCheckedChange={setNotificacoesEmail}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="sms-notif" className="flex items-center gap-2 text-sm">
                      <MessageSquare className="w-4 h-4 text-gray-500" />
                      Notificações por SMS
                    </Label>
                    <Switch 
                      id="sms-notif" 
                      checked={notificacoesSMS}
                      onCheckedChange={setNotificacoesSMS}
                    />
                  </div>
                </div>
              </CardFooter>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <Truck className="w-16 h-16 mx-auto text-gray-300 mb-3" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Selecione um pedido</h3>
                <p className="text-gray-500 mb-4">
                  Selecione um pedido da lista para ver os detalhes de rastreamento ou busque pelo código de rastreio.
                </p>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100 text-blue-800 text-sm">
                  <p>Você pode buscar qualquer pedido digitando o código de rastreamento no campo de busca acima.</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}