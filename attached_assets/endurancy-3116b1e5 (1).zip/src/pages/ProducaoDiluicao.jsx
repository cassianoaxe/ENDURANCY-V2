import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import {
  Droplets,
  Thermometer,
  Clock,
  Timer,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  FileText,
  User,
  Calendar,
  FlaskConical,
  BarChart,
  Clipboard,
  ClipboardCheck,
  Scale,
  Beaker,
  Search,
  FilterX,
  Plus,
  Trash2,
  Save,
  PlayCircle,
  PauseCircle,
  StopCircle,
  RefreshCw
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ProducaoDiluicao() {
  const [loading, setLoading] = useState(false);
  const [ordensProducao, setOrdensProducao] = useState([]);
  const [loteAtivo, setLoteAtivo] = useState(null);
  const [temperatura, setTemperatura] = useState(25);
  const [velocidadeAgitacao, setVelocidadeAgitacao] = useState(60);
  const [tempoRestante, setTempoRestante] = useState(0);
  const [emProcesso, setEmProcesso] = useState(false);
  const [estadoEquipamento, setEstadoEquipamento] = useState('standby');

  useEffect(() => {
    // Simulação de carregamento de dados
    setLoading(true);
    setTimeout(() => {
      setOrdensProducao([
        {
          id: "OP-2023-125",
          produto: "Óleo CBD 5% 30ml",
          lote: "LOT-CBD-072",
          etapa: "Diluição",
          status: "pendente",
          quantidade: 500,
          insumos: [
            { nome: "Extrato CBD Full Spectrum", quantidade: "250g", lote: "EXT-056" },
            { nome: "Óleo MCT", quantidade: "15L", lote: "MCT-123" }
          ],
          prioridade: "alta"
        },
        {
          id: "OP-2023-127",
          produto: "Óleo CBD 10% 30ml",
          lote: "LOT-CBD-073",
          etapa: "Diluição",
          status: "pendente",
          quantidade: 300,
          insumos: [
            { nome: "Extrato CBD Full Spectrum", quantidade: "300g", lote: "EXT-057" },
            { nome: "Óleo MCT", quantidade: "10L", lote: "MCT-123" }
          ],
          prioridade: "média"
        },
        {
          id: "OP-2023-130",
          produto: "Óleo CBD 2% 30ml",
          lote: "LOT-CBD-075",
          etapa: "Diluição",
          status: "em_andamento",
          quantidade: 1000,
          insumos: [
            { nome: "Extrato CBD Full Spectrum", quantidade: "200g", lote: "EXT-058" },
            { nome: "Óleo MCT", quantidade: "30L", lote: "MCT-124" }
          ],
          prioridade: "baixa"
        }
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const iniciarProcesso = (ordemProducao) => {
    setLoteAtivo(ordemProducao);
    setEstadoEquipamento('preparando');
    
    // Simular preparação do equipamento
    setTimeout(() => {
      setEstadoEquipamento('pronto');
    }, 2000);
  };

  const iniciarDiluicao = () => {
    setEmProcesso(true);
    setEstadoEquipamento('processando');
    setTempoRestante(30); // 30 minutos de processo

    // Simular contagem regressiva
    const interval = setInterval(() => {
      setTempoRestante(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setEmProcesso(false);
          setEstadoEquipamento('concluido');
          return 0;
        }
        return prev - 1;
      });
    }, 1000); // Atualiza a cada segundo (na vida real seria a cada minuto)
  };

  const pausarProcesso = () => {
    setEmProcesso(false);
    setEstadoEquipamento('pausado');
  };

  const continuarProcesso = () => {
    setEmProcesso(true);
    setEstadoEquipamento('processando');
  };

  const finalizarProcesso = () => {
    setEmProcesso(false);
    setEstadoEquipamento('concluido');
    setTempoRestante(0);
  };

  const reiniciarEquipamento = () => {
    setEstadoEquipamento('standby');
    setLoteAtivo(null);
    setTemperatura(25);
    setVelocidadeAgitacao(60);
    setTempoRestante(0);
  };

  const registrarResultados = () => {
    alert("Resultados registrados com sucesso!");
    reiniciarEquipamento();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Controle de Diluição</h1>
          <p className="text-gray-500">Gerenciamento do processo de diluição de ativos</p>
        </div>
        <div className="flex gap-2">
          <Badge variant={estadoEquipamento === 'standby' ? 'outline' : 'secondary'} className="text-sm py-1 px-3">
            {estadoEquipamento === 'standby' && 'Em Espera'}
            {estadoEquipamento === 'preparando' && 'Preparando Equipamento'}
            {estadoEquipamento === 'pronto' && 'Pronto para Iniciar'}
            {estadoEquipamento === 'processando' && 'Processando'}
            {estadoEquipamento === 'pausado' && 'Pausado'}
            {estadoEquipamento === 'concluido' && 'Concluído'}
          </Badge>
          <Button size="sm" variant="outline" onClick={reiniciarEquipamento} disabled={['standby', 'preparando'].includes(estadoEquipamento)}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Reiniciar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {!loteAtivo ? (
            <Card>
              <CardHeader>
                <CardTitle>Ordens de Produção - Diluição</CardTitle>
                <CardDescription>Selecione uma ordem de produção para iniciar o processo de diluição</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <svg className="animate-spin h-8 w-8 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>OP</TableHead>
                        <TableHead>Produto</TableHead>
                        <TableHead>Lote</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Prioridade</TableHead>
                        <TableHead>Ação</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {ordensProducao.map((ordem) => (
                        <TableRow key={ordem.id}>
                          <TableCell className="font-medium">{ordem.id}</TableCell>
                          <TableCell>{ordem.produto}</TableCell>
                          <TableCell>{ordem.lote}</TableCell>
                          <TableCell>{ordem.quantidade} {ordem.unidade || 'un'}</TableCell>
                          <TableCell>
                            <Badge className={
                              ordem.prioridade === 'alta' ? 'bg-red-100 text-red-800' : 
                              ordem.prioridade === 'média' ? 'bg-yellow-100 text-yellow-800' : 
                              'bg-blue-100 text-blue-800'
                            }>
                              {ordem.prioridade}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button size="sm" onClick={() => iniciarProcesso(ordem)}>
                              Iniciar
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Processo de Diluição - {loteAtivo.produto}</CardTitle>
                    <Badge>{loteAtivo.lote}</Badge>
                  </div>
                  <CardDescription>
                    Ordem de Produção: {loteAtivo.id} | Quantidade: {loteAtivo.quantidade} {loteAtivo.unidade || 'unidades'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="text-sm font-medium">Temperatura</h3>
                        <Badge variant="outline" className="text-sm">
                          <Thermometer className="w-3 h-3 mr-1" />
                          {temperatura}°C
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4">
                        <Slider
                          value={[temperatura]}
                          min={20}
                          max={80}
                          step={1}
                          onValueChange={(value) => setTemperatura(value[0])}
                          disabled={emProcesso}
                        />
                        <Input
                          className="w-16"
                          type="number"
                          value={temperatura}
                          onChange={(e) => setTemperatura(Number(e.target.value))}
                          min={20}
                          max={80}
                          disabled={emProcesso}
                        />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="text-sm font-medium">Velocidade de Agitação</h3>
                        <Badge variant="outline" className="text-sm">
                          <RotateCcw className="w-3 h-3 mr-1" />
                          {velocidadeAgitacao} RPM
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4">
                        <Slider
                          value={[velocidadeAgitacao]}
                          min={0}
                          max={150}
                          step={5}
                          onValueChange={(value) => setVelocidadeAgitacao(value[0])}
                          disabled={emProcesso}
                        />
                        <Input
                          className="w-16"
                          type="number"
                          value={velocidadeAgitacao}
                          onChange={(e) => setVelocidadeAgitacao(Number(e.target.value))}
                          min={0}
                          max={150}
                          step={5}
                          disabled={emProcesso}
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Tempo de Processo</h3>
                    <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Clock className="w-5 h-5 text-gray-500" />
                        <span className="text-2xl font-bold">{tempoRestante} min</span>
                      </div>
                      <div className="flex gap-2">
                        {estadoEquipamento === 'pronto' && (
                          <Button onClick={iniciarDiluicao}>
                            <PlayCircle className="w-4 h-4 mr-2" />
                            Iniciar
                          </Button>
                        )}
                        {estadoEquipamento === 'processando' && (
                          <>
                            <Button variant="outline" onClick={pausarProcesso}>
                              <PauseCircle className="w-4 h-4 mr-2" />
                              Pausar
                            </Button>
                            <Button variant="outline" onClick={finalizarProcesso}>
                              <StopCircle className="w-4 h-4 mr-2" />
                              Finalizar
                            </Button>
                          </>
                        )}
                        {estadoEquipamento === 'pausado' && (
                          <Button onClick={continuarProcesso}>
                            <PlayCircle className="w-4 h-4 mr-2" />
                            Continuar
                          </Button>
                        )}
                        {estadoEquipamento === 'concluido' && (
                          <Button onClick={registrarResultados} className="bg-green-600 hover:bg-green-700">
                            <CheckCircle2 className="w-4 h-4 mr-2" />
                            Registrar Resultados
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Insumos</CardTitle>
                  <CardDescription>Insumos necessários para este processo</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Insumo</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Lote</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loteAtivo.insumos.map((insumo, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{insumo.nome}</TableCell>
                          <TableCell>{insumo.quantidade}</TableCell>
                          <TableCell>{insumo.lote}</TableCell>
                          <TableCell>
                            <Badge className="bg-green-100 text-green-800">Disponível</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Instruções de Diluição</CardTitle>
              <CardDescription>Procedimento padrão para diluição de CBD</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Badge className="mb-2">Procedimento</Badge>
                <ol className="list-decimal list-inside space-y-2 text-sm">
                  <li>Verificar e calibrar a balança analítica</li>
                  <li>Pesar o extrato CBD conforme especificação do lote</li>
                  <li>Preparar o reator e aquecer o óleo MCT a 60°C (±5°C)</li>
                  <li>Adicionar o extrato lentamente sob agitação constante</li>
                  <li>Manter agitação por 30 minutos (60-75 RPM)</li>
                  <li>Verificar visualmente a homogeneidade</li>
                  <li>Coletar amostra para análise de controle</li>
                  <li>Transferir para o tanque de armazenamento temporário</li>
                </ol>
              </div>

              <Separator />

              <div className="space-y-2">
                <Badge className="mb-2">Parâmetros Críticos</Badge>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium">Temperatura:</p>
                    <p>60°C (±5°C)</p>
                  </div>
                  <div>
                    <p className="font-medium">Agitação:</p>
                    <p>60-75 RPM</p>
                  </div>
                  <div>
                    <p className="font-medium">Tempo:</p>
                    <p>30 minutos</p>
                  </div>
                  <div>
                    <p className="font-medium">pH Final:</p>
                    <p>6.0-7.0</p>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <Badge className="mb-2">Controle de Qualidade</Badge>
                <div className="space-y-2 text-sm">
                  <p>• Verificar ausência de partículas em suspensão</p>
                  <p>• Verificar homogeneidade da solução</p>
                  <p>• Conferir concentração final por HPLC</p>
                  <p>• Registrar todos os parâmetros no sistema</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Status do Equipamento</CardTitle>
              <CardDescription>Reator de Diluição #01</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Temperatura Atual</p>
                  <div className="flex items-center">
                    <Thermometer className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{emProcesso ? temperatura : '---'}°C</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Agitação</p>
                  <div className="flex items-center">
                    <RotateCcw className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{emProcesso ? velocidadeAgitacao : '---'} RPM</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Pressão</p>
                  <div className="flex items-center">
                    <Beaker className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{emProcesso ? '1.02' : '---'} bar</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Status</p>
                  <div className="flex items-center">
                    {estadoEquipamento === 'standby' && (
                      <Badge variant="outline" className="mt-1">Standby</Badge>
                    )}
                    {estadoEquipamento === 'preparando' && (
                      <Badge variant="outline" className="mt-1">Preparando</Badge>
                    )}
                    {estadoEquipamento === 'pronto' && (
                      <Badge className="bg-yellow-100 text-yellow-800 mt-1">Pronto para Iniciar</Badge>
                    )}
                    {estadoEquipamento === 'processando' && (
                      <Badge className="bg-blue-100 text-blue-800 mt-1">Em Processamento</Badge>
                    )}
                    {estadoEquipamento === 'pausado' && (
                      <Badge className="bg-orange-100 text-orange-800 mt-1">Pausado</Badge>
                    )}
                    {estadoEquipamento === 'concluido' && (
                      <Badge className="bg-green-100 text-green-800 mt-1">Concluído</Badge>
                    )}
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Histórico de Manutenção</h3>
                <div className="text-sm">
                  <p>• Última calibração: 15/07/2023</p>
                  <p>• Próxima manutenção: 15/10/2023</p>
                  <p>• Status: Operacional</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}