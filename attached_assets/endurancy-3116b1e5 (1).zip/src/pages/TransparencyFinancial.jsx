import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Calendar } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export default function TransparencyFinancial() {
  const [period, setPeriod] = useState("2023");
  const [activeTab, setActiveTab] = useState("geral");
  const [expandedReport, setExpandedReport] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [financialData, setFinancialData] = useState(null);

  useEffect(() => {
    loadFinancialData();
  }, [period]);

  const loadFinancialData = () => {
    // Simulando carregamento de dados
    setIsLoading(true);
    setTimeout(() => {
      setFinancialData({
        geral: {
          receitas: 1245000,
          despesas: 1128000,
          saldo: 117000,
          dados_mensais: [
            { mes: 'Jan', receitas: 95000, despesas: 92000 },
            { mes: 'Fev', receitas: 98000, despesas: 90000 },
            { mes: 'Mar', receitas: 104000, despesas: 96000 },
            { mes: 'Abr', receitas: 102000, despesas: 93000 },
            { mes: 'Mai', receitas: 108000, despesas: 96000 },
            { mes: 'Jun', receitas: 110000, despesas: 95000 },
            { mes: 'Jul', receitas: 106000, despesas: 92000 },
            { mes: 'Ago', receitas: 104000, despesas: 94000 },
            { mes: 'Set', receitas: 105000, despesas: 90000 },
            { mes: 'Out', receitas: 103000, despesas: 98000 },
            { mes: 'Nov', receitas: 106000, despesas: 97000 },
            { mes: 'Dez', receitas: 104000, despesas: 95000 }
          ],
          distribuicao_despesas: [
            { nome: 'Administrativo', valor: 350000, porcentagem: 31 },
            { nome: 'Operacional', valor: 290000, porcentagem: 26 },
            { nome: 'Atendimento', valor: 246000, porcentagem: 22 },
            { nome: 'Pessoal', valor: 190000, porcentagem: 17 },
            { nome: 'Outros', valor: 52000, porcentagem: 4 }
          ]
        },
        social: {
          receitas: 310000,
          despesas: 298000,
          saldo: 12000,
          beneficiarios: 145,
          custo_medio: 2055,
          dados_mensais: [
            { mes: 'Jan', receitas: 24000, despesas: 23000 },
            { mes: 'Fev', receitas: 25000, despesas: 24000 },
            { mes: 'Mar', receitas: 26000, despesas: 25000 },
            { mes: 'Abr', receitas: 25000, despesas: 24500 },
            { mes: 'Mai', receitas: 27000, despesas: 25500 },
            { mes: 'Jun', receitas: 26000, despesas: 25000 },
            { mes: 'Jul', receitas: 26500, despesas: 25000 },
            { mes: 'Ago', receitas: 26000, despesas: 25300 },
            { mes: 'Set', receitas: 26200, despesas: 25100 },
            { mes: 'Out', receitas: 26000, despesas: 25000 },
            { mes: 'Nov', receitas: 26300, despesas: 25200 },
            { mes: 'Dez', receitas: 26000, despesas: 25400 }
          ],
          distribuicao_beneficios: [
            { tipo: 'Isenção Total', quantidade: 45, valor: 120000, porcentagem: 40 },
            { tipo: 'Isenção 75%', quantidade: 37, valor: 90000, porcentagem: 30 },
            { tipo: 'Isenção 50%', quantidade: 42, valor: 63000, porcentagem: 21 },
            { tipo: 'Isenção 25%', quantidade: 21, valor: 25000, porcentagem: 9 }
          ],
          origem_recursos: [
            { fonte: 'Doações', valor: 130000, porcentagem: 42 },
            { fonte: 'Receita Operacional', valor: 90000, porcentagem: 29 },
            { fonte: 'Parcerias', valor: 60000, porcentagem: 19 },
            { fonte: 'Eventos', valor: 30000, porcentagem: 10 }
          ],
          impacto_social: {
            familias_atendidas: 145,
            economia_medicamentos: 298000,
            consultas_realizadas: 560,
            reducao_sintomas: 87
          }
        }
      });
      setIsLoading(false);
    }, 800);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

  const renderFinancialReports = () => {
    if (!financialData) return null;

    const data = activeTab === "geral" ? financialData.geral : financialData.social;

    return (
      <div className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Receitas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {formatCurrency(data.receitas)}
              </div>
              <p className="text-xs text-muted-foreground">
                {period}
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Despesas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">
                {formatCurrency(data.despesas)}
              </div>
              <p className="text-xs text-muted-foreground">
                {period}
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Saldo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${data.saldo >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {formatCurrency(data.saldo)}
              </div>
              <p className="text-xs text-muted-foreground">
                {period}
              </p>
            </CardContent>
          </Card>
        </div>

        {activeTab === "social" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Beneficiários Atendidos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-center my-4">
                  {data.beneficiarios}
                </div>
                <div className="text-center text-sm text-muted-foreground">
                  Custo médio por beneficiário: {formatCurrency(data.custo_medio)}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Impacto Social</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-xl font-bold">{data.impacto_social.familias_atendidas}</div>
                    <div className="text-xs text-muted-foreground">Famílias</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold">{formatCurrency(data.impacto_social.economia_medicamentos)}</div>
                    <div className="text-xs text-muted-foreground">Economia</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold">{data.impacto_social.consultas_realizadas}</div>
                    <div className="text-xs text-muted-foreground">Consultas</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold">{data.impacto_social.reducao_sintomas}%</div>
                    <div className="text-xs text-muted-foreground">Melhora</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Evolução Financeira Mensal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={data.dados_mensais}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                  <Legend />
                  <Bar dataKey="receitas" fill="#4ade80" name="Receitas" />
                  <Bar dataKey="despesas" fill="#f87171" name="Despesas" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {activeTab === "geral" && (
          <Card>
            <CardHeader>
              <CardTitle>Distribuição de Despesas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={data.distribuicao_despesas}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="valor"
                        nameKey="nome"
                        label={({ nome, porcentagem }) => `${nome}: ${porcentagem}%`}
                      >
                        {data.distribuicao_despesas.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(value)} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div>
                  {data.distribuicao_despesas.map((item, index) => (
                    <div key={index} className="mb-4">
                      <div className="flex justify-between items-center mb-1">
                        <div className="flex items-center">
                          <div 
                            className="w-3 h-3 rounded-full mr-2" 
                            style={{ backgroundColor: COLORS[index % COLORS.length] }}
                          ></div>
                          <span>{item.nome}</span>
                        </div>
                        <span className="font-medium">{formatCurrency(item.valor)}</span>
                      </div>
                      <Progress value={item.porcentagem} className="h-2" />
                      <div className="text-xs text-right mt-1">{item.porcentagem}%</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === "social" && (
          <>
            <Card>
              <CardHeader>
                <CardTitle>Distribuição de Benefícios</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={data.distribuicao_beneficios}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="valor"
                          nameKey="tipo"
                          label={({ tipo, porcentagem }) => `${tipo}: ${porcentagem}%`}
                        >
                          {data.distribuicao_beneficios.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => formatCurrency(value)} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div>
                    {data.distribuicao_beneficios.map((item, index) => (
                      <div key={index} className="mb-4">
                        <div className="flex justify-between items-center mb-1">
                          <div className="flex items-center">
                            <div 
                              className="w-3 h-3 rounded-full mr-2" 
                              style={{ backgroundColor: COLORS[index % COLORS.length] }}
                            ></div>
                            <span>{item.tipo} ({item.quantidade} beneficiários)</span>
                          </div>
                          <span className="font-medium">{formatCurrency(item.valor)}</span>
                        </div>
                        <Progress value={item.porcentagem} className="h-2" />
                        <div className="text-xs text-right mt-1">{item.porcentagem}%</div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Origem dos Recursos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={data.origem_recursos}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="valor"
                          nameKey="fonte"
                          label={({ fonte, porcentagem }) => `${fonte}: ${porcentagem}%`}
                        >
                          {data.origem_recursos.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => formatCurrency(value)} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div>
                    {data.origem_recursos.map((item, index) => (
                      <div key={index} className="mb-4">
                        <div className="flex justify-between items-center mb-1">
                          <div className="flex items-center">
                            <div 
                              className="w-3 h-3 rounded-full mr-2" 
                              style={{ backgroundColor: COLORS[index % COLORS.length] }}
                            ></div>
                            <span>{item.fonte}</span>
                          </div>
                          <span className="font-medium">{formatCurrency(item.valor)}</span>
                        </div>
                        <Progress value={item.porcentagem} className="h-2" />
                        <div className="text-xs text-right mt-1">{item.porcentagem}%</div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Relatórios Disponíveis</CardTitle>
            <CardDescription>
              Relatórios financeiros e de atividades detalhados para download
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-gray-500" />
                  <div>
                    <div className="font-medium">Relatório Financeiro {period} - Completo</div>
                    <div className="text-sm text-muted-foreground">PDF, 2.4MB</div>
                  </div>
                </div>
                <Button>Download</Button>
              </div>
              
              {activeTab === "social" && (
                <>
                  <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-gray-500" />
                      <div>
                        <div className="font-medium">Relatório do Programa Social {period}</div>
                        <div className="text-sm text-muted-foreground">PDF, 3.1MB</div>
                      </div>
                    </div>
                    <Button>Download</Button>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-gray-500" />
                      <div>
                        <div className="font-medium">Indicadores de Impacto Social {period}</div>
                        <div className="text-sm text-muted-foreground">PDF, 1.8MB</div>
                      </div>
                    </div>
                    <Button>Download</Button>
                  </div>
                </>
              )}
              
              <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-gray-500" />
                  <div>
                    <div className="font-medium">Demonstrativo de Resultados {period}</div>
                    <div className="text-sm text-muted-foreground">PDF, 1.5MB</div>
                  </div>
                </div>
                <Button>Download</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="container mx-auto p-6">
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-2xl font-bold">Relatórios Financeiros</h1>
            <p className="text-gray-500">
              Transparência na gestão de recursos da nossa organização
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Selecione o período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2023">2023</SelectItem>
                <SelectItem value="2022">2022</SelectItem>
                <SelectItem value="2021">2021</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-8">
            <TabsTrigger value="geral">Financeiro Geral</TabsTrigger>
            <TabsTrigger value="social">Programa Social</TabsTrigger>
          </TabsList>
          
          <TabsContent value="geral">
            {isLoading ? (
              <div className="flex justify-center items-center h-40">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              </div>
            ) : (
              renderFinancialReports()
            )}
          </TabsContent>
          
          <TabsContent value="social">
            {isLoading ? (
              <div className="flex justify-center items-center h-40">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              </div>
            ) : (
              renderFinancialReports()
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}