
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Calendar as CalendarIcon,
  Clock,
  Search,
  Filter,
  Plus,
  MoreHorizontal,
  User,
  ChevronLeft,
  ChevronRight,
  Video,
  MapPin,
  ArrowUpRight,
  FileText,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Eye
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format, parseISO, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addDays, addMonths, subMonths, getDay, startOfWeek, endOfWeek } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Spinner } from "@/components/ui/spinner";
import { toast } from "@/components/ui/use-toast";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function ConsultasMedicas() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [currentView, setCurrentView] = useState("month"); // month, week, day, list
  const [consultations, setConsultations] = useState([]);
  const [filteredConsultations, setFilteredConsultations] = useState([]);
  const [selectedConsultation, setSelectedConsultation] = useState(null);
  const [showConsultationDialog, setShowConsultationDialog] = useState(false);
  const [showNewConsultationDialog, setShowNewConsultationDialog] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  
  // Estados para nova consulta
  const [newConsultation, setNewConsultation] = useState({
    paciente_id: "",
    paciente_nome: "",
    medico_id: "",
    tipo_consulta: "presencial",
    data_hora: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
    duracao: 30,
    observacoes_paciente: "",
    status: "agendada"
  });
  
  // Simulação de médicos
  useEffect(() => {
    const mockDoctors = [
      { id: "med1", nome_completo: "Dra. Ana Silva", especialidade: "Neurologia" },
      { id: "med2", nome_completo: "Dr. Carlos Santos", especialidade: "Psiquiatria" },
      { id: "med3", nome_completo: "Dr. Ricardo Oliveira", especialidade: "Clínica Geral" }
    ];
    setDoctors(mockDoctors);
  }, []);
  
  // Simulação de consultas
  useEffect(() => {
    const loadConsultations = async () => {
      setLoading(true);
      try {
        // Simulação de API
        setTimeout(() => {
          const mockConsultations = [
            {
              id: "cons1",
              medico_id: "med1",
              medico_nome: "Dra. Ana Silva",
              paciente_id: "pac1",
              paciente_nome: "João Pereira",
              tipo_paciente: "associado",
              data_hora: "2025-01-15T09:30:00",
              duracao: 30,
              tipo_consulta: "presencial",
              status: "agendada",
              valor: 350,
              local_id: "local1",
              local_nome: "Consultório Principal"
            },
            {
              id: "cons2",
              medico_id: "med2",
              medico_nome: "Dr. Carlos Santos",
              paciente_id: "pac2",
              paciente_nome: "Maria Oliveira",
              tipo_paciente: "cliente",
              data_hora: "2025-01-15T14:00:00",
              duracao: 60,
              tipo_consulta: "telemedicina",
              status: "confirmada",
              valor: 300,
              link_telemedicina: "https://meet.example.com/abc123"
            },
            {
              id: "cons3",
              medico_id: "med1",
              medico_nome: "Dra. Ana Silva",
              paciente_id: "pac3",
              paciente_nome: "Roberto Silva",
              tipo_paciente: "associado",
              data_hora: "2025-01-16T10:30:00",
              duracao: 30,
              tipo_consulta: "presencial",
              status: "realizada",
              valor: 350,
              local_id: "local1",
              local_nome: "Consultório Principal",
              prescricao_id: "pres123"
            },
            {
              id: "cons4",
              medico_id: "med3",
              medico_nome: "Dr. Ricardo Oliveira",
              paciente_id: "pac4",
              paciente_nome: "Fernanda Costa",
              tipo_paciente: "cliente",
              data_hora: "2025-01-16T15:30:00",
              duracao: 30,
              tipo_consulta: "telemedicina",
              status: "cancelada",
              valor: 280,
              link_telemedicina: "https://meet.example.com/def456"
            }
          ];
          
          setConsultations(mockConsultations);
          filterConsultations(mockConsultations, selectedDoctor, statusFilter, searchTerm);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error("Erro ao carregar consultas:", error);
        toast({
          title: "Erro ao carregar consultas",
          description: "Não foi possível carregar as consultas. Tente novamente mais tarde.",
          variant: "destructive"
        });
        setLoading(false);
      }
    };
    
    loadConsultations();
  }, []);
  
  // Filtrar consultas
  const filterConsultations = (consultations, doctorFilter, statusFilter, searchTerm) => {
    let filtered = [...consultations];
    
    if (doctorFilter !== "all") {
      filtered = filtered.filter(cons => cons.medico_id === doctorFilter);
    }
    
    if (statusFilter !== "all") {
      filtered = filtered.filter(cons => cons.status === statusFilter);
    }
    
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(cons => 
        cons.paciente_nome.toLowerCase().includes(term) ||
        cons.medico_nome.toLowerCase().includes(term)
      );
    }
    
    setFilteredConsultations(filtered);
  };
  
  useEffect(() => {
    filterConsultations(consultations, selectedDoctor, statusFilter, searchTerm);
  }, [selectedDoctor, statusFilter, searchTerm, consultations]);
  
  // Navegação do calendário
  const goToPreviousMonth = () => {
    if (currentView === "month") {
      setCurrentDate(subMonths(currentDate, 1));
    } else if (currentView === "week") {
      setCurrentDate(addDays(currentDate, -7));
    } else if (currentView === "day") {
      setCurrentDate(addDays(currentDate, -1));
    }
  };
  
  const goToNextMonth = () => {
    if (currentView === "month") {
      setCurrentDate(addMonths(currentDate, 1));
    } else if (currentView === "week") {
      setCurrentDate(addDays(currentDate, 7));
    } else if (currentView === "day") {
      setCurrentDate(addDays(currentDate, 1));
    }
  };
  
  const goToToday = () => {
    setCurrentDate(new Date());
  };
  
  // Renderização do calendário mensal
  const renderMonthCalendar = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);
    const startDate = startOfWeek(monthStart, { locale: ptBR });
    const endDate = endOfWeek(monthEnd, { locale: ptBR });
    
    const days = eachDayOfInterval({ start: startDate, end: endDate });
    
    const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
    
    return (
      <div className="bg-white rounded-lg shadow">
        <div className="grid grid-cols-7 gap-px bg-gray-200">
          {weekDays.map((day, index) => (
            <div key={index} className="bg-white p-2 text-center text-sm font-medium text-gray-500">
              {day}
            </div>
          ))}
          
          {days.map((day, dayIndex) => {
            const formattedDate = format(day, "yyyy-MM-dd");
            const dayConsultations = filteredConsultations.filter(cons => {
              const consDate = parseISO(cons.data_hora);
              return isSameDay(consDate, day);
            });
            
            const isCurrentMonth = day.getMonth() === currentDate.getMonth();
            const isToday = isSameDay(day, new Date());
            
            return (
              <div
                key={dayIndex}
                className={`min-h-24 bg-white p-1 border-t ${
                  !isCurrentMonth ? "text-gray-400" : ""
                } ${isToday ? "bg-blue-50" : ""}`}
              >
                <div className="flex flex-col h-full">
                  <div className="flex justify-between">
                    <span className={`text-sm font-medium ${isToday ? "bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center" : ""}`}>
                      {format(day, "d")}
                    </span>
                    {dayConsultations.length > 0 && (
                      <Badge variant="outline" className="text-xs">
                        {dayConsultations.length}
                      </Badge>
                    )}
                  </div>
                  
                  <div className="flex-1 overflow-y-auto max-h-32">
                    {dayConsultations.slice(0, 3).map((cons, i) => (
                      <div
                        key={i}
                        className={`mt-1 px-1 py-0.5 text-xs rounded cursor-pointer ${
                          getConsultationColor(cons.status)
                        }`}
                        onClick={() => {
                          setSelectedConsultation(cons);
                          setShowConsultationDialog(true);
                        }}
                      >
                        <div className="font-medium truncate">{format(parseISO(cons.data_hora), "HH:mm")}</div>
                        <div className="truncate">{cons.paciente_nome}</div>
                      </div>
                    ))}
                    {dayConsultations.length > 3 && (
                      <div className="mt-1 text-xs text-gray-500">
                        + {dayConsultations.length - 3} mais
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };
  
  // Renderização do calendário semanal
  const renderWeekCalendar = () => {
    const startDate = startOfWeek(currentDate, { locale: ptBR });
    const endDate = endOfWeek(currentDate, { locale: ptBR });
    const days = eachDayOfInterval({ start: startDate, end: endDate });
    
    const hours = Array.from({ length: 13 }, (_, i) => i + 8); // 8:00 - 20:00
    
    return (
      <div className="bg-white rounded-lg shadow overflow-auto max-h-[70vh]">
        <div className="min-w-[800px]">
          <div className="grid grid-cols-8 gap-px bg-gray-200">
            <div className="bg-white p-2 text-center text-sm font-medium text-gray-500">
              Hora
            </div>
            
            {days.map((day, index) => {
              const isToday = isSameDay(day, new Date());
              return (
                <div 
                  key={index} 
                  className={`bg-white p-2 text-center ${isToday ? "bg-blue-50" : ""}`}
                >
                  <div className="text-sm font-medium text-gray-500">
                    {format(day, "EEE", { locale: ptBR })}
                  </div>
                  <div className={`text-sm font-bold ${isToday ? "text-blue-600" : ""}`}>
                    {format(day, "d MMM", { locale: ptBR })}
                  </div>
                </div>
              );
            })}
            
            {hours.map((hour) => (
              <React.Fragment key={hour}>
                <div className="bg-white p-2 text-center border-t text-sm text-gray-500">
                  {hour}:00
                </div>
                
                {days.map((day, dayIndex) => {
                  const dayHourConsultations = filteredConsultations.filter(cons => {
                    const consDate = parseISO(cons.data_hora);
                    return (
                      isSameDay(consDate, day) &&
                      consDate.getHours() === hour
                    );
                  });
                  
                  const isToday = isSameDay(day, new Date());
                  
                  return (
                    <div
                      key={`${hour}-${dayIndex}`}
                      className={`bg-white p-1 border-t relative min-h-16 ${
                        isToday ? "bg-blue-50" : ""
                      }`}
                    >
                      {dayHourConsultations.map((cons, i) => (
                        <div
                          key={i}
                          className={`mt-1 px-2 py-1 text-xs rounded cursor-pointer ${
                            getConsultationColor(cons.status)
                          }`}
                          onClick={() => {
                            setSelectedConsultation(cons);
                            setShowConsultationDialog(true);
                          }}
                        >
                          <div className="font-medium">
                            {format(parseISO(cons.data_hora), "HH:mm")} - {cons.paciente_nome}
                          </div>
                          <div className="text-xs flex items-center gap-1">
                            {cons.tipo_consulta === "telemedicina" ? (
                              <Video className="h-3 w-3" />
                            ) : (
                              <MapPin className="h-3 w-3" />
                            )}
                            <span>{cons.tipo_consulta === "telemedicina" ? "Telemedicina" : cons.local_nome}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    );
  };
  
  // Renderização da lista de consultas
  const renderConsultationsList = () => {
    return (
      <div className="space-y-4">
        {filteredConsultations.length === 0 ? (
          <div className="text-center py-8">
            <CalendarIcon className="h-12 w-12 mx-auto text-gray-300" />
            <h3 className="mt-2 text-lg font-medium">Nenhuma consulta encontrada</h3>
            <p className="text-gray-500">
              Não há consultas correspondentes aos filtros selecionados.
            </p>
          </div>
        ) : (
          filteredConsultations.map((consultation) => (
            <Card 
              key={consultation.id} 
              className="hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => {
                setSelectedConsultation(consultation);
                setShowConsultationDialog(true);
              }}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-blue-100 text-blue-700">
                        {consultation.paciente_nome.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div>
                      <h3 className="font-medium">{consultation.paciente_nome}</h3>
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <CalendarIcon className="h-3 w-3" />
                        <span>
                          {format(parseISO(consultation.data_hora), "dd/MM/yyyy 'às' HH:mm")}
                        </span>
                        <span>•</span>
                        <span>{consultation.duracao} min</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col items-end gap-2">
                    <Badge variant={getStatusVariant(consultation.status)}>
                      {getStatusLabel(consultation.status)}
                    </Badge>
                    <div className="flex items-center gap-1 text-sm">
                      {consultation.tipo_consulta === "telemedicina" ? (
                        <Video className="h-3 w-3 text-blue-500" />
                      ) : (
                        <MapPin className="h-3 w-3 text-green-500" />
                      )}
                      <span>
                        {consultation.tipo_consulta === "telemedicina" 
                          ? "Telemedicina" 
                          : consultation.local_nome
                        }
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    );
  };
  
  // Cores para status de consulta
  const getConsultationColor = (status) => {
    switch (status) {
      case "agendada":
        return "bg-blue-100 text-blue-800";
      case "confirmada":
        return "bg-green-100 text-green-800";
      case "realizada":
        return "bg-purple-100 text-purple-800";
      case "cancelada":
        return "bg-gray-100 text-gray-800";
      case "faltou":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  
  // Variant de badge para status
  const getStatusVariant = (status) => {
    switch (status) {
      case "agendada":
        return "outline";
      case "confirmada":
        return "success";
      case "realizada":
        return "secondary";
      case "cancelada":
        return "destructive";
      case "faltou":
        return "destructive";
      default:
        return "outline";
    }
  };
  
  // Label para status
  const getStatusLabel = (status) => {
    switch (status) {
      case "agendada":
        return "Agendada";
      case "confirmada":
        return "Confirmada";
      case "realizada":
        return "Realizada";
      case "cancelada":
        return "Cancelada";
      case "faltou":
        return "Faltou";
      default:
        return status;
    }
  };
  
  // Obter ícone para status
  const getStatusIcon = (status) => {
    switch (status) {
      case "agendada":
        return <AlertCircle className="h-4 w-4" />;
      case "confirmada":
        return <CheckCircle2 className="h-4 w-4" />;
      case "realizada":
        return <CheckCircle2 className="h-4 w-4" />;
      case "cancelada":
        return <XCircle className="h-4 w-4" />;
      case "faltou":
        return <XCircle className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };
  
  // Ações para consulta selecionada
  const handleStartConsultation = () => {
    if (selectedConsultation.tipo_consulta === "telemedicina") {
      // Redirecionar para a sala de telemedicina
      navigate(`${createPageUrl("TelemedicinaMedico")}?id=${selectedConsultation.id}`);
    } else {
      // Simular início de consulta presencial
      toast({
        title: "Consulta iniciada",
        description: `Consulta com ${selectedConsultation.paciente_nome} iniciada.`,
        duration: 3000
      });
      setShowConsultationDialog(false);
    }
  };
  
  const handleCancelConsultation = () => {
    setShowConsultationDialog(false);
    setShowCancelDialog(true);
  };
  
  const confirmCancelConsultation = () => {
    // Simulação de cancelamento
    toast({
      title: "Consulta cancelada",
      description: `A consulta com ${selectedConsultation.paciente_nome} foi cancelada.`,
      duration: 3000
    });
    setShowCancelDialog(false);
    
    // Atualizando o estado local para refletir o cancelamento
    const updatedConsultations = consultations.map(cons => 
      cons.id === selectedConsultation.id ? {...cons, status: "cancelada"} : cons
    );
    setConsultations(updatedConsultations);
    filterConsultations(updatedConsultations, selectedDoctor, statusFilter, searchTerm);
  };
  
  // Criação de nova consulta
  const handleCreateConsultation = () => {
    toast({
      title: "Consulta agendada",
      description: "A nova consulta foi agendada com sucesso.",
      duration: 3000
    });
    
    // Simulação de criação
    const newId = `cons${consultations.length + 1}`;
    const selectedDoctorObj = doctors.find(doc => doc.id === newConsultation.medico_id);
    
    const createdConsultation = {
      id: newId,
      medico_id: newConsultation.medico_id,
      medico_nome: selectedDoctorObj?.nome_completo || "Médico",
      paciente_id: "pac_new",
      paciente_nome: newConsultation.paciente_nome,
      tipo_paciente: "associado",
      data_hora: newConsultation.data_hora,
      duracao: newConsultation.duracao,
      tipo_consulta: newConsultation.tipo_consulta,
      status: "agendada",
      valor: 350,
      observacoes_paciente: newConsultation.observacoes_paciente,
      local_id: "local1",
      local_nome: "Consultório Principal",
      link_telemedicina: newConsultation.tipo_consulta === "telemedicina" ? "https://meet.example.com/xyz789" : ""
    };
    
    const updatedConsultations = [...consultations, createdConsultation];
    setConsultations(updatedConsultations);
    filterConsultations(updatedConsultations, selectedDoctor, statusFilter, searchTerm);
    
    setShowNewConsultationDialog(false);
    
    // Resetar formulário
    setNewConsultation({
      paciente_id: "",
      paciente_nome: "",
      medico_id: "",
      tipo_consulta: "presencial",
      data_hora: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
      duracao: 30,
      observacoes_paciente: "",
      status: "agendada"
    });
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Spinner className="mx-auto" />
          <p className="mt-4 text-muted-foreground">Carregando consultas...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Agendamento de Consultas</h1>
          <p className="text-muted-foreground">
            Gerencie consultas médicas presenciais e por telemedicina
          </p>
        </div>
        
        <Button onClick={() => setShowNewConsultationDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Consulta
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-6">
        {/* Filtros (Sidebar) */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Médico</Label>
                <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um médico" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os médicos</SelectItem>
                    {doctors.map((doctor) => (
                      <SelectItem key={doctor.id} value={doctor.id}>
                        {doctor.nome_completo}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filtrar por status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os status</SelectItem>
                    <SelectItem value="agendada">Agendada</SelectItem>
                    <SelectItem value="confirmada">Confirmada</SelectItem>
                    <SelectItem value="realizada">Realizada</SelectItem>
                    <SelectItem value="cancelada">Cancelada</SelectItem>
                    <SelectItem value="faltou">Faltou</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Buscar</Label>
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Nome do paciente"
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Resumo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span>Total de consultas:</span>
                <span className="font-medium">{filteredConsultations.length}</span>
              </div>
              <div className="flex justify-between">
                <span>Agendadas:</span>
                <span className="font-medium">
                  {filteredConsultations.filter(c => c.status === "agendada").length}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Confirmadas:</span>
                <span className="font-medium">
                  {filteredConsultations.filter(c => c.status === "confirmada").length}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Realizadas:</span>
                <span className="font-medium">
                  {filteredConsultations.filter(c => c.status === "realizada").length}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Canceladas:</span>
                <span className="font-medium">
                  {filteredConsultations.filter(c => c.status === "cancelada").length}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Calendário principal */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={goToPreviousMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" onClick={goToToday}>Hoje</Button>
              <Button variant="outline" size="icon" onClick={goToNextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
              
              <h2 className="text-xl font-semibold ml-2">
                {currentView === "month" && format(currentDate, "MMMM yyyy", { locale: ptBR })}
                {currentView === "week" && (
                  <>
                    {format(startOfWeek(currentDate, { locale: ptBR }), "d", { locale: ptBR })} - {
                      format(endOfWeek(currentDate, { locale: ptBR }), "d 'de' MMMM", { locale: ptBR })
                    }
                  </>
                )}
                {currentView === "day" && format(currentDate, "d 'de' MMMM", { locale: ptBR })}
                {currentView === "list" && "Lista de Consultas"}
              </h2>
            </div>
            
            <div className="flex gap-2">
              <Tabs 
                defaultValue="month" 
                value={currentView} 
                onValueChange={setCurrentView}
                className="mr-2"
              >
                <TabsList>
                  <TabsTrigger value="month">Mês</TabsTrigger>
                  <TabsTrigger value="week">Semana</TabsTrigger>
                  <TabsTrigger value="list">Lista</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>
          
          <div>
            {currentView === "month" && renderMonthCalendar()}
            {currentView === "week" && renderWeekCalendar()}
            {currentView === "list" && renderConsultationsList()}
          </div>
        </div>
      </div>
      
      {/* Diálogo de detalhes da consulta */}
      <Dialog open={showConsultationDialog} onOpenChange={setShowConsultationDialog}>
        {selectedConsultation && (
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Detalhes da Consulta</DialogTitle>
              <DialogDescription>
                Consulta {getStatusLabel(selectedConsultation.status).toLowerCase()} com {selectedConsultation.paciente_nome}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12">
                  <AvatarFallback className="bg-blue-100 text-blue-700">
                    {selectedConsultation.paciente_nome.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </AvatarFallback>
                </Avatar>
                
                <div>
                  <h3 className="font-medium">{selectedConsultation.paciente_nome}</h3>
                  <Badge variant={getStatusVariant(selectedConsultation.status)}>
                    {getStatusIcon(selectedConsultation.status)}
                    <span className="ml-1">{getStatusLabel(selectedConsultation.status)}</span>
                  </Badge>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Data e Hora</p>
                  <p className="font-medium flex items-center gap-1">
                    <CalendarIcon className="h-4 w-4" />
                    {format(parseISO(selectedConsultation.data_hora), "dd/MM/yyyy")}
                  </p>
                  <p className="font-medium flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {format(parseISO(selectedConsultation.data_hora), "HH:mm")}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-500">Médico</p>
                  <p className="font-medium">{selectedConsultation.medico_nome}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Tipo de Consulta</p>
                <div className="flex items-center gap-2 font-medium">
                  {selectedConsultation.tipo_consulta === "telemedicina" ? (
                    <>
                      <Video className="h-4 w-4 text-blue-500" />
                      <span>Telemedicina</span>
                    </>
                  ) : (
                    <>
                      <MapPin className="h-4 w-4 text-green-500" />
                      <span>Presencial - {selectedConsultation.local_nome}</span>
                    </>
                  )}
                </div>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Duração</p>
                <p className="font-medium">{selectedConsultation.duracao} minutos</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Valor</p>
                <p className="font-medium">R$ {selectedConsultation.valor.toFixed(2)}</p>
              </div>
              
              {selectedConsultation.prescricao_id && (
                <div>
                  <p className="text-sm text-gray-500">Prescrição</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-1"
                    onClick={() => navigate(`${createPageUrl("Prescricao")}?id=${selectedConsultation.prescricao_id}`)}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Ver Prescrição
                  </Button>
                </div>
              )}
            </div>
            
            <DialogFooter className="flex justify-between">
              <div>
                {(selectedConsultation.status === "agendada" || selectedConsultation.status === "confirmada") && (
                  <Button variant="destructive" onClick={handleCancelConsultation}>
                    Cancelar Consulta
                  </Button>
                )}
              </div>
              
              <div className="space-x-2">
                <Button variant="outline" onClick={() => setShowConsultationDialog(false)}>
                  Fechar
                </Button>
                
                {(selectedConsultation.status === "agendada" || selectedConsultation.status === "confirmada") && (
                  <Button onClick={handleStartConsultation}>
                    {selectedConsultation.tipo_consulta === "telemedicina" ? (
                      <>
                        <Video className="h-4 w-4 mr-2" />
                        Iniciar Telemedicina
                      </>
                    ) : (
                      <>
                        <ArrowUpRight className="h-4 w-4 mr-2" />
                        Iniciar Consulta
                      </>
                    )}
                  </Button>
                )}
                
                {selectedConsultation.status === "realizada" && (
                  <Button
                    onClick={() => {
                      setShowConsultationDialog(false);
                      navigate(`${createPageUrl("HistoricoMedico")}?id=${selectedConsultation.paciente_id}`);
                    }}
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    Ver Prontuário
                  </Button>
                )}
              </div>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
      
      {/* Diálogo de cancelamento de consulta */}
      <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        {selectedConsultation && (
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Cancelar Consulta</DialogTitle>
              <DialogDescription>
                Tem certeza que deseja cancelar a consulta com {selectedConsultation.paciente_nome}?
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <CalendarIcon className="h-5 w-5 text-gray-500" />
                <div>
                  <p className="font-medium">
                    {format(parseISO(selectedConsultation.data_hora), "dd/MM/yyyy 'às' HH:mm")}
                  </p>
                  <p className="text-sm text-gray-500">
                    {selectedConsultation.tipo_consulta === "telemedicina" ? "Telemedicina" : selectedConsultation.local_nome}
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="cancel-reason">Motivo do Cancelamento</Label>
                <Textarea
                  id="cancel-reason"
                  placeholder="Informe o motivo do cancelamento"
                  rows={3}
                />
              </div>
              
              <p className="text-sm text-yellow-600">
                O paciente será notificado sobre o cancelamento.
              </p>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCancelDialog(false)}>
                Voltar
              </Button>
              <Button variant="destructive" onClick={confirmCancelConsultation}>
                Confirmar Cancelamento
              </Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
      
      {/* Diálogo de nova consulta */}
      <Dialog open={showNewConsultationDialog} onOpenChange={setShowNewConsultationDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Agendar Nova Consulta</DialogTitle>
            <DialogDescription>
              Preencha os dados para agendar uma nova consulta médica
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="patient-name">Nome do Paciente</Label>
              <Input
                id="patient-name"
                placeholder="Nome completo do paciente"
                value={newConsultation.paciente_nome}
                onChange={(e) => setNewConsultation({...newConsultation, paciente_nome: e.target.value})}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="doctor">Médico</Label>
              <Select
                value={newConsultation.medico_id}
                onValueChange={(value) => setNewConsultation({...newConsultation, medico_id: value})}
              >
                <SelectTrigger id="doctor">
                  <SelectValue placeholder="Selecione o médico" />
                </SelectTrigger>
                <SelectContent>
                  {doctors.map((doctor) => (
                    <SelectItem key={doctor.id} value={doctor.id}>
                      {doctor.nome_completo} - {doctor.especialidade}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="consultation-type">Tipo de Consulta</Label>
              <Select
                value={newConsultation.tipo_consulta}
                onValueChange={(value) => setNewConsultation({...newConsultation, tipo_consulta: value})}
              >
                <SelectTrigger id="consultation-type">
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="presencial">Presencial</SelectItem>
                  <SelectItem value="telemedicina">Telemedicina</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="datetime">Data e Hora</Label>
                <Input
                  id="datetime"
                  type="datetime-local"
                  value={newConsultation.data_hora}
                  onChange={(e) => setNewConsultation({...newConsultation, data_hora: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="duration">Duração (minutos)</Label>
                <Input
                  id="duration"
                  type="number"
                  min="15"
                  step="15"
                  value={newConsultation.duracao}
                  onChange={(e) => setNewConsultation({...newConsultation, duracao: parseInt(e.target.value)})}
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                placeholder="Observações adicionais"
                value={newConsultation.observacoes_paciente}
                onChange={(e) => setNewConsultation({...newConsultation, observacoes_paciente: e.target.value})}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewConsultationDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreateConsultation}>
              Agendar Consulta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
