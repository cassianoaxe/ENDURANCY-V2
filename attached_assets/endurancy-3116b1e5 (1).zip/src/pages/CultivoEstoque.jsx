
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { 
  Scale, 
  Search, 
  Filter, 
  Tag, 
  AlertTriangle, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Trash2, 
  Download, 
  FileText, 
  Printer,
  Plus,
  Calendar,
  ArrowRight,
  ArrowDownUp,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  CheckCircle2,
  XCircle,
  Leaf,
  FlaskConical,
  Box,
  PackageOpen,
  Sprout,
  Beaker
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Inventory } from "@/api/entities";
import { Batch } from "@/api/entities";
import { format } from 'date-fns';

// Dados mockados para inventário
const mockInventory = [
  {
    id: "inv1",
    inventory_id: "INV-FL-0123",
    batch_id: "LOTE-2023-0142",
    type: "flor",
    strain: "Charlotte's Web",
    quantity: 2500,
    unit: "g",
    location: "Cofre de Armazenamento A",
    production_date: "2023-07-15",
    expiry_date: "2024-07-15",
    thc_content: 0.6,
    cbd_content: 18.2,
    status: "disponível",
    lab_test_id: "LAB-0045"
  },
  {
    id: "inv2",
    inventory_id: "INV-OL-0085",
    batch_id: "LOTE-2023-0140",
    type: "óleo",
    strain: "Cannatonic",
    quantity: 1250,
    unit: "ml",
    location: "Cofre de Armazenamento B",
    production_date: "2023-06-10",
    expiry_date: "2024-06-10",
    thc_content: 0.3,
    cbd_content: 10.5,
    status: "disponível",
    lab_test_id: "LAB-0039"
  },
  {
    id: "inv3",
    inventory_id: "INV-FL-0124",
    batch_id: "LOTE-2023-0143",
    type: "flor",
    strain: "ACDC",
    quantity: 1800,
    unit: "g",
    location: "Cofre de Armazenamento A",
    production_date: "2023-07-10",
    expiry_date: "2024-07-10",
    thc_content: 0.4,
    cbd_content: 16.8,
    status: "disponível",
    lab_test_id: "LAB-0044"
  },
  {
    id: "inv4",
    inventory_id: "INV-EX-0056",
    batch_id: "LOTE-2023-0138",
    type: "extrato",
    strain: "Harlequin",
    quantity: 500,
    unit: "ml",
    location: "Cofre de Armazenamento B",
    production_date: "2023-05-20",
    expiry_date: "2024-05-20",
    thc_content: 0.7,
    cbd_content: 14.2,
    status: "em quarentena",
    lab_test_id: "LAB-0033"
  },
  {
    id: "inv5",
    inventory_id: "INV-FL-0125",
    batch_id: "LOTE-2023-0144",
    type: "flor",
    strain: "CBD Skunk",
    quantity: 0,
    unit: "g",
    location: "Transferido",
    production_date: "2023-07-05",
    expiry_date: "2024-07-05",
    thc_content: 0.5,
    cbd_content: 15.5,
    status: "em transferência",
    lab_test_id: "LAB-0043"
  },
  {
    id: "inv6",
    inventory_id: "INV-SE-0015",
    batch_id: "LOTE-2023-0130",
    type: "semente",
    strain: "Charlotte's Web",
    quantity: 250,
    unit: "unidades",
    location: "Sala de Armazenamento C",
    production_date: "2023-03-01",
    expiry_date: "2025-03-01",
    thc_content: null,
    cbd_content: null,
    status: "disponível",
    lab_test_id: null
  }
];

// Componente para filtros
const InventoryFilters = ({ activeFilters, setActiveFilters, onFilterChange }) => {
  const handleFilterChange = (filterType, value) => {
    const newFilters = { ...activeFilters, [filterType]: value };
    setActiveFilters(newFilters);
    if (onFilterChange) onFilterChange(newFilters);
  };
  
  return (
    <div className="flex flex-wrap gap-4 mb-6">
      <div className="relative flex-grow max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Buscar por ID, strain ou lote..."
          className="pl-10"
          value={activeFilters.searchTerm}
          onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
        />
      </div>
      
      <Select 
        value={activeFilters.type} 
        onValueChange={(value) => handleFilterChange('type', value)}
      >
        <SelectTrigger className="w-40">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            <SelectValue placeholder="Tipo" />
          </div>
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todos Tipos</SelectItem>
          <SelectItem value="flor">Flor</SelectItem>
          <SelectItem value="óleo">Óleo</SelectItem>
          <SelectItem value="extrato">Extrato</SelectItem>
          <SelectItem value="semente">Semente</SelectItem>
          <SelectItem value="resina">Resina</SelectItem>
          <SelectItem value="folha">Folha</SelectItem>
          <SelectItem value="descarte">Descarte</SelectItem>
        </SelectContent>
      </Select>
      
      <Select 
        value={activeFilters.status} 
        onValueChange={(value) => handleFilterChange('status', value)}
      >
        <SelectTrigger className="w-40">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            <SelectValue placeholder="Status" />
          </div>
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todos Status</SelectItem>
          <SelectItem value="disponível">Disponível</SelectItem>
          <SelectItem value="em quarentena">Em Quarentena</SelectItem>
          <SelectItem value="em transferência">Em Transferência</SelectItem>
          <SelectItem value="reservado">Reservado</SelectItem>
          <SelectItem value="expirado">Expirado</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};

// Componente da tabela principal
const InventoryTable = ({ inventory, onViewItem, onEditItem, onDeleteItem, onTransferItem }) => {
  const [sortColumn, setSortColumn] = useState(null);
  const [sortDirection, setSortDirection] = useState('asc');
  
  const handleSort = (column) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };
  
  const sortedInventory = [...inventory].sort((a, b) => {
    if (!sortColumn) return 0;
    
    let valueA = a[sortColumn];
    let valueB = b[sortColumn];
    
    // Handle special cases
    if (sortColumn === 'quantity') {
      valueA = a.quantity || 0;
      valueB = b.quantity || 0;
    }
    
    // Handle string comparison
    if (typeof valueA === 'string' && typeof valueB === 'string') {
      return sortDirection === 'asc'
        ? valueA.localeCompare(valueB)
        : valueB.localeCompare(valueA);
    }
    
    // Handle number comparison
    return sortDirection === 'asc'
      ? (valueA || 0) - (valueB || 0)
      : (valueB || 0) - (valueA || 0);
  });
  
  const renderSortableHeader = (column, label) => (
    <div
      className="flex items-center gap-1 cursor-pointer hover:text-gray-900"
      onClick={() => handleSort(column)}
    >
      {label}
      {sortColumn === column ? (
        sortDirection === 'asc' ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />
      ) : (
        <ArrowUpDown className="w-3 h-3 opacity-50" />
      )}
    </div>
  );
  
  const getTypeIcon = (type) => {
    switch (type) {
      case 'flor': return <Leaf className="w-4 h-4 text-green-600" />;
      case 'óleo': return <FlaskConical className="w-4 h-4 text-amber-600" />;
      case 'extrato': return <Beaker className="w-4 h-4 text-purple-600" />;
      case 'semente': return <Sprout className="w-4 h-4 text-blue-600" />;
      case 'resina': return <Beaker className="w-4 h-4 text-orange-600" />;
      case 'folha': return <Leaf className="w-4 h-4 text-emerald-600" />;
      case 'descarte': return <Trash2 className="w-4 h-4 text-red-600" />;
      default: return <Box className="w-4 h-4 text-gray-600" />;
    }
  };
  
  return (
    <div className="rounded-md border overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>{renderSortableHeader('inventory_id', 'ID')}</TableHead>
            <TableHead>{renderSortableHeader('type', 'Tipo')}</TableHead>
            <TableHead>{renderSortableHeader('strain', 'Strain')}</TableHead>
            <TableHead>{renderSortableHeader('batch_id', 'Lote')}</TableHead>
            <TableHead>{renderSortableHeader('quantity', 'Quantidade')}</TableHead>
            <TableHead>{renderSortableHeader('location', 'Localização')}</TableHead>
            <TableHead>{renderSortableHeader('expiry_date', 'Validade')}</TableHead>
            <TableHead>{renderSortableHeader('status', 'Status')}</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedInventory.length === 0 ? (
            <TableRow>
              <TableCell colSpan={9} className="h-24 text-center">
                <div className="flex flex-col items-center justify-center text-gray-500">
                  <Box className="h-10 w-10 mb-2 text-gray-400" />
                  <p>Nenhum item de inventário encontrado</p>
                  <p className="text-sm">Adicione itens ao inventário ou ajuste os filtros</p>
                </div>
              </TableCell>
            </TableRow>
          ) : (
            sortedInventory.map((item) => (
              <TableRow key={item.id}>
                <TableCell className="font-medium">
                  {item.inventory_id}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {getTypeIcon(item.type)}
                    <span className="capitalize">{item.type}</span>
                  </div>
                </TableCell>
                <TableCell>{item.strain}</TableCell>
                <TableCell>{item.batch_id}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Scale className="w-4 h-4 text-gray-500" />
                    <span>{item.quantity} {item.unit}</span>
                  </div>
                </TableCell>
                <TableCell>{item.location}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span>{format(new Date(item.expiry_date), 'dd/MM/yyyy')}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge 
                    className={
                      item.status === "disponível" ? "bg-green-100 text-green-800" :
                      item.status === "em quarentena" ? "bg-amber-100 text-amber-800" :
                      item.status === "em transferência" ? "bg-blue-100 text-blue-800" :
                      item.status === "reservado" ? "bg-purple-100 text-purple-800" :
                      "bg-red-100 text-red-800"
                    }
                  >
                    {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                  </Badge>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Ações</DropdownMenuLabel>
                      <DropdownMenuItem onClick={() => onViewItem(item)}>
                        <Eye className="mr-2 h-4 w-4" />
                        <span>Ver Detalhes</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onEditItem(item)}>
                        <Edit className="mr-2 h-4 w-4" />
                        <span>Editar</span>
                      </DropdownMenuItem>
                      
                      {item.status === "disponível" && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => onTransferItem(item)}>
                            <ArrowRight className="mr-2 h-4 w-4" />
                            <span>Criar Transferência</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <AlertTriangle className="mr-2 h-4 w-4 text-amber-500" />
                            <span>Colocar em Quarentena</span>
                          </DropdownMenuItem>
                        </>
                      )}
                      
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <FileText className="mr-2 h-4 w-4" />
                        <span>Ver Laudo</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Printer className="mr-2 h-4 w-4" />
                        <span>Imprimir Etiqueta</span>
                      </DropdownMenuItem>
                      
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => onDeleteItem(item)} className="text-red-600">
                        <Trash2 className="mr-2 h-4 w-4" />
                        <span>Excluir</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};

// Diálogo de detalhes do item
const InventoryDetailDialog = ({ item, open, onOpenChange }) => {
  if (!item) return null;
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {item.type === 'flor' ? <Leaf className="h-5 w-5" /> :
             item.type === 'óleo' ? <FlaskConical className="h-5 w-5" /> :
             item.type === 'extrato' ? <Beaker className="h-5 w-5" /> :
             <Box className="h-5 w-5" />}
            Detalhes do Item {item.inventory_id}
          </DialogTitle>
          <DialogDescription>
            Informações detalhadas sobre o item de inventário
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-md">
              <h3 className="font-medium mb-3">Informações Gerais</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">ID:</span>
                  <span className="font-medium">{item.inventory_id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">Tipo:</span>
                  <div className="flex items-center gap-2">
                    {item.type === 'flor' ? <Leaf className="w-4 h-4 text-green-600" /> :
                     item.type === 'óleo' ? <FlaskConical className="w-4 h-4 text-amber-600" /> :
                     item.type === 'extrato' ? <Beaker className="w-4 h-4 text-purple-600" /> :
                     <Box className="w-4 h-4 text-gray-600" />}
                    <span className="capitalize">{item.type}</span>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">Strain:</span>
                  <span>{item.strain}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">Lote de Origem:</span>
                  <span>{item.batch_id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">Status:</span>
                  <Badge className={
                    item.status === "disponível" ? "bg-green-100 text-green-800" :
                    item.status === "em quarentena" ? "bg-amber-100 text-amber-800" :
                    item.status === "em transferência" ? "bg-blue-100 text-blue-800" :
                    item.status === "reservado" ? "bg-purple-100 text-purple-800" :
                    "bg-red-100 text-red-800"
                  }>
                    {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                  </Badge>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-md">
              <h3 className="font-medium mb-3">Quantidades e Localização</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">Quantidade:</span>
                  <span>{item.quantity} {item.unit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">Localização:</span>
                  <span>{item.location}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">Data de Produção:</span>
                  <span>{format(new Date(item.production_date), 'dd/MM/yyyy')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">Data de Validade:</span>
                  <span>{format(new Date(item.expiry_date), 'dd/MM/yyyy')}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-md">
              <h3 className="font-medium mb-3">Perfil Canabinoide</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">THC:</span>
                  <span>{item.thc_content !== null ? `${item.thc_content}%` : 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">CBD:</span>
                  <span>{item.cbd_content !== null ? `${item.cbd_content}%` : 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium text-gray-500">ID Laudo:</span>
                  <span>{item.lab_test_id || 'N/A'}</span>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-md">
              <h3 className="font-medium mb-3">Ações Disponíveis</h3>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" className="w-full flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Ver Laudo
                </Button>
                <Button variant="outline" size="sm" className="w-full flex items-center gap-2">
                  <Printer className="w-4 h-4" />
                  Imprimir Etiqueta
                </Button>
                <Button variant="outline" size="sm" className="w-full flex items-center gap-2">
                  <ArrowRight className="w-4 h-4" />
                  Transferir
                </Button>
                <Button variant="outline" size="sm" className="w-full flex items-center gap-2">
                  <Edit className="w-4 h-4" />
                  Editar
                </Button>
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-md">
              <h3 className="font-medium mb-3">Histórico de Transações</h3>
              <div className="text-center text-sm text-gray-500 py-2">
                <Button variant="link" size="sm">Ver histórico completo</Button>
              </div>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Fechar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// Diálogo de transferência
const TransferDialog = ({ item, open, onOpenChange, onTransfer }) => {
  const [transferData, setTransferData] = useState({
    destination: '',
    quantity: '',
    notes: ''
  });
  
  React.useEffect(() => {
    if (item) {
      setTransferData({
        destination: '',
        quantity: item.quantity.toString(),
        notes: ''
      });
    }
  }, [item]);
  
  if (!item) return null;
  
  const handleInputChange = (field, value) => {
    setTransferData({
      ...transferData,
      [field]: value
    });
  };
  
  const isValid = transferData.destination && 
                 transferData.quantity && 
                 parseFloat(transferData.quantity) > 0 && 
                 parseFloat(transferData.quantity) <= item.quantity;
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowRight className="h-5 w-5" />
            Criar Transferência
          </DialogTitle>
          <DialogDescription>
            Transferir material para outra localização ou entidade
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="item-info">Item a ser transferido</Label>
            <div className="p-3 border rounded-md bg-gray-50">
              <div className="flex justify-between items-center">
                <div>
                  <div className="font-medium flex items-center gap-2">
                    {item.type === 'flor' ? <Leaf className="w-4 h-4 text-green-600" /> :
                     item.type === 'óleo' ? <FlaskConical className="w-4 h-4 text-amber-600" /> :
                     item.type === 'extrato' ? <Beaker className="w-4 h-4 text-purple-600" /> :
                     <Box className="w-4 h-4 text-gray-600" />}
                    <span>{item.inventory_id} - {item.strain}</span>
                  </div>
                  <div className="text-sm text-gray-500">
                    Disponível: {item.quantity} {item.unit}
                  </div>
                </div>
                <Badge className="bg-green-100 text-green-800">
                  {item.status}
                </Badge>
              </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="destination">Destino da Transferência</Label>
            <Select 
              value={transferData.destination}
              onValueChange={(value) => handleInputChange('destination', value)}
            >
              <SelectTrigger id="destination">
                <SelectValue placeholder="Selecione o destino" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="laboratory">Laboratório de Análise</SelectItem>
                <SelectItem value="production">Produção</SelectItem>
                <SelectItem value="partner">Entidade Parceira</SelectItem>
                <SelectItem value="other_location">Outra Localização</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="quantity">Quantidade a Transferir ({item.unit})</Label>
            <Input
              id="quantity"
              type="number"
              value={transferData.quantity}
              onChange={(e) => handleInputChange('quantity', e.target.value)}
              max={item.quantity}
              min="0"
            />
            {parseFloat(transferData.quantity) > item.quantity && (
              <p className="text-red-500 text-sm">
                A quantidade não pode exceder {item.quantity} {item.unit}
              </p>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="notes">Observações (opcional)</Label>
            <Input
              id="notes"
              value={transferData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              placeholder="Adicione informações adicionais sobre esta transferência"
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button 
            onClick={() => onTransfer(item, transferData)}
            disabled={!isValid}
          >
            <ArrowRight className="mr-2 h-4 w-4" />
            Criar Transferência
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// Componente para adicionar novo item ao inventário
const AddInventoryDialog = ({ open, onOpenChange, onAdd }) => {
  const [formData, setFormData] = useState({
    batch_id: '',
    type: '',
    quantity: '',
    unit: 'g',
    location: '',
    thc_content: '',
    cbd_content: '',
    production_date: format(new Date(), 'yyyy-MM-dd'),
    expiry_date: format(new Date(new Date().setFullYear(new Date().getFullYear() + 1)), 'yyyy-MM-dd')
  });
  
  const handleInputChange = (field, value) => {
    setFormData({
      ...formData,
      [field]: value
    });
  };
  
  const isValid = formData.batch_id && 
                 formData.type && 
                 formData.quantity && 
                 parseFloat(formData.quantity) > 0 &&
                 formData.location &&
                 formData.production_date &&
                 formData.expiry_date;
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Adicionar Item ao Inventário
          </DialogTitle>
          <DialogDescription>
            Registre um novo item no estoque de matéria vegetal
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="processed">
          <TabsList className="mb-4">
            <TabsTrigger value="processed">Produto Processado</TabsTrigger>
            <TabsTrigger value="batch">De Lote de Cultivo</TabsTrigger>
          </TabsList>
          
          <TabsContent value="processed" className="space-y-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="batch_id">Lote de Origem (Opcional)</Label>
                <Input
                  id="batch_id"
                  value={formData.batch_id}
                  onChange={(e) => handleInputChange('batch_id', e.target.value)}
                  placeholder="ID do lote de origem"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="type">Tipo de Material <span className="text-red-500">*</span></Label>
                <Select 
                  value={formData.type}
                  onValueChange={(value) => handleInputChange('type', value)}
                >
                  <SelectTrigger id="type">
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="flor">Flor</SelectItem>
                    <SelectItem value="óleo">Óleo</SelectItem>
                    <SelectItem value="extrato">Extrato</SelectItem>
                    <SelectItem value="resina">Resina</SelectItem>
                    <SelectItem value="folha">Folha</SelectItem>
                    <SelectItem value="semente">Semente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="strain">Strain <span className="text-red-500">*</span></Label>
                <Select>
                  <SelectTrigger id="strain">
                    <SelectValue placeholder="Selecione a strain" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="charlotte">Charlotte's Web</SelectItem>
                    <SelectItem value="acdc">ACDC</SelectItem>
                    <SelectItem value="harlequin">Harlequin</SelectItem>
                    <SelectItem value="cannatonic">Cannatonic</SelectItem>
                    <SelectItem value="skunk">CBD Skunk</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex gap-2">
                <div className="space-y-2 flex-grow">
                  <Label htmlFor="quantity">Quantidade <span className="text-red-500">*</span></Label>
                  <Input
                    id="quantity"
                    type="number"
                    value={formData.quantity}
                    onChange={(e) => handleInputChange('quantity', e.target.value)}
                    min="0"
                  />
                </div>
                
                <div className="space-y-2 w-24">
                  <Label htmlFor="unit">Unidade</Label>
                  <Select 
                    value={formData.unit}
                    onValueChange={(value) => handleInputChange('unit', value)}
                  >
                    <SelectTrigger id="unit">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="g">g</SelectItem>
                      <SelectItem value="kg">kg</SelectItem>
                      <SelectItem value="ml">ml</SelectItem>
                      <SelectItem value="l">l</SelectItem>
                      <SelectItem value="unidades">un</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="location">Localização <span className="text-red-500">*</span></Label>
                <Select 
                  value={formData.location}
                  onValueChange={(value) => handleInputChange('location', value)}
                >
                  <SelectTrigger id="location">
                    <SelectValue placeholder="Selecione a localização" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cofre_a">Cofre de Armazenamento A</SelectItem>
                    <SelectItem value="cofre_b">Cofre de Armazenamento B</SelectItem>
                    <SelectItem value="sala_c">Sala de Armazenamento C</SelectItem>
                    <SelectItem value="laboratorio">Laboratório</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="production_date">Data de Produção <span className="text-red-500">*</span></Label>
                <Input
                  id="production_date"
                  type="date"
                  value={formData.production_date}
                  onChange={(e) => handleInputChange('production_date', e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="expiry_date">Data de Validade <span className="text-red-500">*</span></Label>
                <Input
                  id="expiry_date"
                  type="date"
                  value={formData.expiry_date}
                  onChange={(e) => handleInputChange('expiry_date', e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="thc">THC (%)</Label>
                <Input
                  id="thc"
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  value={formData.thc_content}
                  onChange={(e) => handleInputChange('thc_content', e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="cbd">CBD (%)</Label>
                <Input
                  id="cbd"
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  value={formData.cbd_content}
                  onChange={(e) => handleInputChange('cbd_content', e.target.value)}
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="batch" className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="batch_select">Selecione o Lote de Cultivo <span className="text-red-500">*</span></Label>
              <Select>
                <SelectTrigger id="batch_select">
                  <SelectValue placeholder="Selecione o lote" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lote1">LOTE-2023-0142 (Charlotte's Web)</SelectItem>
                  <SelectItem value="lote2">LOTE-2023-0143 (ACDC)</SelectItem>
                  <SelectItem value="lote3">LOTE-2023-0144 (CBD Skunk)</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-gray-500 mt-1">
                Os detalhes do lote (strain, tipo de material) serão preenchidos automaticamente
              </p>
            </div>
            
            <div className="p-4 border rounded-md bg-gray-50">
              <h3 className="font-medium mb-2">Detalhes do Lote Selecionado</h3>
              <p className="text-gray-500 text-sm">
                Selecione um lote para ver seus detalhes
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex gap-2">
                <div className="space-y-2 flex-grow">
                  <Label htmlFor="wet_weight">Peso Úmido (g) <span className="text-red-500">*</span></Label>
                  <Input
                    id="wet_weight"
                    type="number"
                    min="0"
                  />
                </div>
                
                <div className="space-y-2 flex-grow">
                  <Label htmlFor="dry_weight">Peso Seco (g) <span className="text-red-500">*</span></Label>
                  <Input
                    id="dry_weight"
                    type="number"
                    min="0"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="location_batch">Localização <span className="text-red-500">*</span></Label>
                <Select>
                  <SelectTrigger id="location_batch">
                    <SelectValue placeholder="Selecione a localização" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cofre_a">Cofre de Armazenamento A</SelectItem>
                    <SelectItem value="cofre_b">Cofre de Armazenamento B</SelectItem>
                    <SelectItem value="sala_c">Sala de Armazenamento C</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="expiry_date_batch">Data de Validade <span className="text-red-500">*</span></Label>
                <Input
                  id="expiry_date_batch"
                  type="date"
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button 
            onClick={() => onAdd(formData)}
            disabled={!isValid}
          >
            <Plus className="mr-2 h-4 w-4" />
            Adicionar ao Inventário
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// Componente principal
export default function CultivoEstoque() {
  const [inventory, setInventory] = useState([]);
  const [filteredInventory, setFilteredInventory] = useState([]);
  const [activeFilters, setActiveFilters] = useState({
    searchTerm: '',
    type: 'all',
    status: 'all'
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Estados para diálogos
  const [selectedItem, setSelectedItem] = useState(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [showTransferDialog, setShowTransferDialog] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  
  // Efeitos
  useEffect(() => {
    loadInventory();
  }, []);
  
  useEffect(() => {
    applyFilters();
  }, [inventory, activeFilters]);
  
  // Funções
  const loadInventory = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Em um app real, carregaríamos do backend
      // const loadedInventory = await Inventory.list();
      
      // Usando dados mock para demonstração
      setTimeout(() => {
        setInventory(mockInventory);
        setIsLoading(false);
      }, 800);
      
    } catch (err) {
      console.error("Erro ao carregar inventário:", err);
      setError("Ocorreu um erro ao carregar o inventário.");
      setIsLoading(false);
    }
  };
  
  const applyFilters = () => {
    let filtered = [...inventory];
    
    // Filtrar por termo de busca
    if (activeFilters.searchTerm) {
      const term = activeFilters.searchTerm.toLowerCase();
      filtered = filtered.filter(item => 
        item.inventory_id.toLowerCase().includes(term) ||
        item.strain.toLowerCase().includes(term) ||
        item.batch_id.toLowerCase().includes(term)
      );
    }
    
    // Filtrar por tipo
    if (activeFilters.type !== 'all') {
      filtered = filtered.filter(item => item.type === activeFilters.type);
    }
    
    // Filtrar por status
    if (activeFilters.status !== 'all') {
      filtered = filtered.filter(item => item.status === activeFilters.status);
    }
    
    setFilteredInventory(filtered);
  };
  
  const handleViewItem = (item) => {
    setSelectedItem(item);
    setShowDetailDialog(true);
  };
  
  const handleEditItem = (item) => {
    // Aqui você poderia abrir um diálogo de edição ou redirecionar para uma página de edição
    alert(`Editar item ${item.inventory_id} (implementação futura)`);
  };
  
  const handleDeleteItem = (item) => {
    if (confirm(`Tem certeza que deseja excluir o item ${item.inventory_id}?`)) {
      // Em um app real, excluiríamos do backend
      
      // Atualizar estado local para simular exclusão
      setInventory(inventory.filter(i => i.id !== item.id));
      
      // Mostrar mensagem de sucesso
      alert(`Item ${item.inventory_id} excluído com sucesso.`);
    }
  };
  
  const handleTransferItem = (item) => {
    setSelectedItem(item);
    setShowTransferDialog(true);
  };
  
  const handleTransfer = (item, transferData) => {
    // Em um app real, atualizaríamos o backend
    // e então atualizaríamos o estado local
    
    const updatedInventory = inventory.map(i => {
      if (i.id === item.id) {
        return {
          ...i,
          status: "em transferência",
          quantity: parseFloat(i.quantity) - parseFloat(transferData.quantity)
        };
      }
      return i;
    });
    
    setInventory(updatedInventory);
    setShowTransferDialog(false);
    
    // Mostrar mensagem de sucesso
    alert(`Transferência de ${transferData.quantity} ${item.unit} de ${item.inventory_id} criada com sucesso!`);
  };
  
  const handleAddItem = (formData) => {
    // Em um app real, criaríamos no backend
    // e então atualizaríamos o estado local
    
    const newItem = {
      id: `inv${inventory.length + 1}`,
      inventory_id: `INV-${formData.type.charAt(0).toUpperCase()}${formData.type.charAt(1)}-${Math.floor(Math.random() * 9000) + 1000}`,
      batch_id: formData.batch_id || "MANUAL-ENTRY",
      type: formData.type,
      strain: "Charlotte's Web", // Simplificando para o exemplo
      quantity: parseFloat(formData.quantity),
      unit: formData.unit,
      location: formData.location,
      production_date: formData.production_date,
      expiry_date: formData.expiry_date,
      thc_content: formData.thc_content ? parseFloat(formData.thc_content) : null,
      cbd_content: formData.cbd_content ? parseFloat(formData.cbd_content) : null,
      status: "disponível",
      lab_test_id: null
    };
    
    setInventory([...inventory, newItem]);
    setShowAddDialog(false);
    
    // Mostrar mensagem de sucesso
    alert(`Item ${newItem.inventory_id} adicionado ao inventário com sucesso!`);
  };
  
  // Renderização
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Estoque de Matéria Vegetal</h1>
          <p className="text-gray-500 mt-1">
            Gerencie todo o estoque de matéria vegetal da sua organização
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <FileText className="w-4 h-4" />
            Relatórios
          </Button>
          
          <Button onClick={() => setShowAddDialog(true)} className="gap-2">
            <Plus className="w-4 h-4" />
            Adicionar ao Estoque
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle>Inventário</CardTitle>
              <CardDescription>Todos os itens em estoque</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <InventoryFilters 
            activeFilters={activeFilters}
            setActiveFilters={setActiveFilters}
            onFilterChange={applyFilters}
          />
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
              <p className="ml-2">Carregando inventário...</p>
            </div>
          ) : error ? (
            <div className="flex items-center justify-center text-red-500 p-8">
              <AlertTriangle className="w-8 h-8 mr-2" />
              <p>{error}</p>
            </div>
          ) : (
            <InventoryTable 
              inventory={filteredInventory}
              onViewItem={handleViewItem}
              onEditItem={handleEditItem}
              onDeleteItem={handleDeleteItem}
              onTransferItem={handleTransferItem}
            />
          )}
        </CardContent>
      </Card>
      
      {/* Diálogos */}
      <InventoryDetailDialog 
        item={selectedItem}
        open={showDetailDialog}
        onOpenChange={setShowDetailDialog}
      />
      
      <TransferDialog
        item={selectedItem}
        open={showTransferDialog}
        onOpenChange={setShowTransferDialog}
        onTransfer={handleTransfer}
      />
      
      <AddInventoryDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        onAdd={handleAddItem}
      />
    </div>
  );
}
