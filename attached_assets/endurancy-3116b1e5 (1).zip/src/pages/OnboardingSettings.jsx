import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Settings, Save } from 'lucide-react';

export default function OnboardingSettings() {
  const [settings, setSettings] = useState({
    autoEnroll: true,
    notifyCompletion: true,
    reminderFrequency: 'weekly',
    deadlineDays: 30,
    certificateEnabled: true
  });

  const handleSave = () => {
    // Implement save functionality
    console.log('Saving settings:', settings);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Configurações de Onboarding</h1>
          <p className="text-gray-500 mt-1">Personalize as configurações do sistema de onboarding</p>
        </div>
        <Button onClick={handleSave}>
          <Save className="w-4 h-4 mr-2" />
          Salvar Alterações
        </Button>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Configurações Gerais</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Auto-inscrição</h3>
                <p className="text-sm text-gray-500">
                  Inscrever automaticamente novos usuários nos treinamentos obrigatórios
                </p>
              </div>
              <Switch 
                checked={settings.autoEnroll}
                onCheckedChange={(checked) => 
                  setSettings({...settings, autoEnroll: checked})
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Notificações de Conclusão</h3>
                <p className="text-sm text-gray-500">
                  Enviar notificações quando um usuário conclui um módulo
                </p>
              </div>
              <Switch 
                checked={settings.notifyCompletion}
                onCheckedChange={(checked) => 
                  setSettings({...settings, notifyCompletion: checked})
                }
              />
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">Frequência de Lembretes</h3>
              <Select 
                value={settings.reminderFrequency}
                onValueChange={(value) => 
                  setSettings({...settings, reminderFrequency: value})
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a frequência" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Diário</SelectItem>
                  <SelectItem value="weekly">Semanal</SelectItem>
                  <SelectItem value="biweekly">Quinzenal</SelectItem>
                  <SelectItem value="monthly">Mensal</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">Prazo para Conclusão (dias)</h3>
              <Input 
                type="number"
                value={settings.deadlineDays}
                onChange={(e) => 
                  setSettings({...settings, deadlineDays: parseInt(e.target.value)})
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Certificados</h3>
                <p className="text-sm text-gray-500">
                  Emitir certificados após conclusão do treinamento
                </p>
              </div>
              <Switch 
                checked={settings.certificateEnabled}
                onCheckedChange={(checked) => 
                  setSettings({...settings, certificateEnabled: checked})
                }
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}