
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Mail,
  Users,
  Send,
  Archive,
  Clock,
  Calendar,
  BarChart2,
  Edit,
  Trash2,
  Copy,
  Search,
  Filter,
  Plus,
  CheckCircle2,
  AlertTriangle,
  Eye,
  MousePointerClick,
  Tag,
  ArrowUpRight,
  PlusCircle,
  MoreHorizontal
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Spinner } from '@/components/ui/spinner';
import { toast } from '@/components/ui/use-toast';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function CampanhasEmail() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [campaigns, setCampaigns] = useState([]);
  const [filteredCampaigns, setFilteredCampaigns] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [showCampaignDetails, setShowCampaignDetails] = useState(false);
  
  const [recipientGroups, setRecipientGroups] = useState([]);

  useEffect(() => {
    const loadCampaigns = async () => {
      setLoading(true);
      try {
        setTimeout(() => {
          const mockCampaigns = [
            {
              id: '1',
              titulo: 'Novidades sobre produtos CBD',
              assunto: 'Confira as novidades de CBD para 2025',
              conteudo_html: '<h1>Novidades CBD 2025</h1><p>Apresentamos os novos produtos que estarão disponíveis no início de 2025...</p>',
              remetente_nome: 'Endurancy',
              remetente_email: 'noticias@endurancy.com.br',
              data_criacao: '2024-12-15T14:30:00',
              data_agendamento: '2025-01-05T09:00:00',
              status: 'agendada',
              total_destinatarios: 156,
              total_enviados: 0,
              total_aberturas: 0,
              total_cliques: 0,
              segmentacao: {
                tipo_publico: ['clientes']
              }
            },
            {
              id: '2',
              titulo: 'Webinar Benefícios Medicinais',
              assunto: 'Convite: Webinar sobre Cannabis Medicinal',
              conteudo_html: '<h1>Webinar Exclusivo</h1><p>Convidamos você para participar do nosso webinar sobre os benefícios medicinais...</p>',
              remetente_nome: 'Endurancy Educacional',
              remetente_email: 'educacao@endurancy.com.br',
              data_criacao: '2024-12-10T16:20:00',
              data_inicio_envio: '2024-12-12T10:00:00',
              data_fim_envio: '2024-12-12T10:15:00',
              status: 'concluida',
              total_destinatarios: 432,
              total_enviados: 428,
              total_aberturas: 312,
              total_cliques: 198,
              segmentacao: {
                tipo_publico: ['associados', 'clientes']
              }
            },
            {
              id: '3',
              titulo: 'Lançamento Linha Pets',
              assunto: 'Novos produtos para seu pet 🐾',
              conteudo_html: '<h1>Produtos Para Pets</h1><p>Conheça nossa nova linha de produtos para o bem-estar dos pets...</p>',
              remetente_nome: 'Endurancy Pets',
              remetente_email: 'pets@endurancy.com.br',
              data_criacao: '2024-12-05T09:45:00',
              status: 'rascunho',
              total_destinatarios: 0,
              total_enviados: 0,
              total_aberturas: 0,
              total_cliques: 0,
              segmentacao: {
                tipo_publico: ['clientes']
              }
            },
            {
              id: '4',
              titulo: 'Pesquisa de Satisfação',
              assunto: 'Sua opinião é importante para nós',
              conteudo_html: '<h1>Pesquisa Anual</h1><p>Participe da nossa pesquisa anual de satisfação e ajude-nos a melhorar...</p>',
              remetente_nome: 'Endurancy Feedback',
              remetente_email: 'feedback@endurancy.com.br',
              data_criacao: '2024-11-20T11:30:00',
              data_inicio_envio: '2024-11-25T14:00:00',
              data_fim_envio: '2024-11-25T14:20:00',
              status: 'concluida',
              total_destinatarios: 578,
              total_enviados: 575,
              total_aberturas: 289,
              total_cliques: 156,
              segmentacao: {
                tipo_publico: ['associados']
              }
            }
          ];

          const mockRecipientGroups = [
            {
              id: '1',
              name: 'Todos os Clientes Ativos',
              count: 427,
              type: 'clientes',
              criteria: {
                status: 'ativo'
              }
            },
            {
              id: '2',
              name: 'Associados Premium',
              count: 128,
              type: 'associados',
              criteria: {
                tipo: 'premium'
              }
            },
            {
              id: '3',
              name: 'Pacientes Crônicos',
              count: 215,
              type: 'clientes',
              criteria: {
                categoria: 'cronico'
              }
            },
            {
              id: '4',
              name: 'Newsletter Mensal',
              count: 589,
              type: 'inscritos',
              criteria: {
                newsletter: true
              }
            }
          ];
          
          setCampaigns(mockCampaigns);
          setFilteredCampaigns(mockCampaigns);
          setRecipientGroups(mockRecipientGroups);
          setLoading(false);
        }, 800);
      } catch (error) {
        console.error("Erro ao carregar as campanhas:", error);
        toast({
          title: "Erro ao carregar campanhas",
          description: "Não foi possível obter a lista de campanhas.",
          variant: "destructive"
        });
        setLoading(false);
      }
    };
    
    loadCampaigns();
  }, []);

  useEffect(() => {
    let result = [...campaigns];
    
    if (searchQuery) {
      result = result.filter(campaign => 
        campaign.titulo.toLowerCase().includes(searchQuery.toLowerCase()) ||
        campaign.assunto.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    if (statusFilter !== 'all') {
      result = result.filter(campaign => campaign.status === statusFilter);
    }
    
    setFilteredCampaigns(result);
  }, [campaigns, searchQuery, statusFilter]);

  const deleteCampaign = async () => {
    if (!selectedCampaign) return;
    
    try {
      const updatedCampaigns = campaigns.filter(c => c.id !== selectedCampaign.id);
      setCampaigns(updatedCampaigns);
      setShowConfirmDelete(false);
      
      toast({
        title: "Campanha excluída",
        description: "A campanha foi excluída com sucesso.",
      });
    } catch (error) {
      console.error("Erro ao excluir campanha:", error);
      toast({
        title: "Erro ao excluir",
        description: "Não foi possível excluir a campanha.",
        variant: "destructive"
      });
    }
  };

  const duplicateCampaign = (campaign) => {
    try {
      const newCampaign = {
        ...campaign,
        id: `new-${Date.now()}`,
        titulo: `Cópia de ${campaign.titulo}`,
        status: 'rascunho',
        data_criacao: new Date().toISOString(),
        data_agendamento: null,
        data_inicio_envio: null,
        data_fim_envio: null,
        total_enviados: 0,
        total_aberturas: 0,
        total_cliques: 0
      };
      
      setCampaigns([...campaigns, newCampaign]);
      
      toast({
        title: "Campanha duplicada",
        description: "Uma cópia da campanha foi criada como rascunho.",
      });
    } catch (error) {
      console.error("Erro ao duplicar campanha:", error);
      toast({
        title: "Erro ao duplicar",
        description: "Não foi possível duplicar a campanha.",
        variant: "destructive"
      });
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'rascunho':
        return <Badge variant="outline" className="bg-slate-50 text-slate-700 border-slate-200">Rascunho</Badge>;
      case 'agendada':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Agendada</Badge>;
      case 'em_andamento':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Em Andamento</Badge>;
      case 'concluida':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Concluída</Badge>;
      case 'cancelada':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Cancelada</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Campanhas de Email</h1>
          <p className="text-muted-foreground">
            Gerencie e envie campanhas de email para seus clientes e associados
          </p>
        </div>
        <Button onClick={() => navigate(createPageUrl('NovaCampanhaEmail'))}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Campanha
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative w-full sm:w-96">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar campanhas..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Filtrar por status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="rascunho">Rascunho</SelectItem>
              <SelectItem value="agendada">Agendada</SelectItem>
              <SelectItem value="em_andamento">Em andamento</SelectItem>
              <SelectItem value="concluida">Concluída</SelectItem>
              <SelectItem value="cancelada">Cancelada</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Spinner className="mx-auto" />
            <p className="mt-4 text-muted-foreground">Carregando campanhas...</p>
          </div>
        </div>
      ) : filteredCampaigns.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center h-64">
            <Mail className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">Nenhuma campanha encontrada</h3>
            <p className="text-muted-foreground mt-2 text-center max-w-md">
              {searchQuery || statusFilter !== 'all' 
                ? "Nenhuma campanha corresponde aos filtros de busca aplicados. Tente ajustar os filtros."
                : "Você ainda não criou nenhuma campanha de email. Clique em 'Nova Campanha' para começar."}
            </p>
            {(searchQuery || statusFilter !== 'all') && (
              <Button 
                variant="link" 
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('all');
                }}
              >
                Limpar filtros
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Campanha</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Destinatários</TableHead>
                <TableHead>Desempenho</TableHead>
                <TableHead>Data</TableHead>
                <TableHead className="w-[100px]">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCampaigns.map((campaign) => (
                <TableRow key={campaign.id}>
                  <TableCell>
                    <div className="font-medium truncate max-w-xs" onClick={() => {
                      setSelectedCampaign(campaign);
                      setShowCampaignDetails(true);
                    }} className="cursor-pointer hover:text-blue-600">
                      {campaign.titulo}
                    </div>
                    <div className="text-sm text-muted-foreground truncate max-w-xs">
                      {campaign.assunto}
                    </div>
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(campaign.status)}
                  </TableCell>
                  <TableCell>
                    {campaign.status === 'rascunho' ? (
                      <span className="text-sm text-muted-foreground">Não definido</span>
                    ) : (
                      <div className="flex items-center">
                        <Users className="h-4 w-4 mr-1 text-muted-foreground" />
                        <span>{campaign.total_destinatarios}</span>
                      </div>
                    )}
                  </TableCell>
                  <TableCell>
                    {campaign.status === 'concluida' ? (
                      <div className="space-y-1">
                        <div className="flex items-center text-xs">
                          <Eye className="h-3 w-3 mr-1 text-muted-foreground" />
                          <span>
                            {campaign.total_aberturas} aberturas ({Math.round((campaign.total_aberturas / campaign.total_enviados) * 100)}%)
                          </span>
                        </div>
                        <div className="flex items-center text-xs">
                          <MousePointerClick className="h-3 w-3 mr-1 text-muted-foreground" />
                          <span>
                            {campaign.total_cliques} cliques ({Math.round((campaign.total_cliques / campaign.total_aberturas) * 100)}%)
                          </span>
                        </div>
                      </div>
                    ) : campaign.status === 'agendada' ? (
                      <div className="flex items-center text-sm">
                        <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
                        <span>
                          {format(parseISO(campaign.data_agendamento), 'dd/MM/yyyy HH:mm')}
                        </span>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1 text-muted-foreground" />
                        <span>
                          {format(parseISO(campaign.data_criacao), 'dd/MM/yyyy')}
                        </span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => {
                          setSelectedCampaign(campaign);
                          setShowCampaignDetails(true);
                        }}>
                          <Eye className="h-4 w-4 mr-2" />
                          Ver detalhes
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => navigate(createPageUrl(`EditarCampanhaEmail?id=${campaign.id}`))}>
                          <Edit className="h-4 w-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => duplicateCampaign(campaign)}>
                          <Copy className="h-4 w-4 mr-2" />
                          Duplicar
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="text-red-600"
                          onClick={() => {
                            setSelectedCampaign(campaign);
                            setShowConfirmDelete(true);
                          }}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={showConfirmDelete} onOpenChange={setShowConfirmDelete}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir a campanha "{selectedCampaign?.titulo}"? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="sm:justify-start">
            <div className="flex gap-2 w-full justify-end">
              <Button variant="outline" onClick={() => setShowConfirmDelete(false)}>
                Cancelar
              </Button>
              <Button variant="destructive" onClick={deleteCampaign}>
                Excluir
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showCampaignDetails} onOpenChange={setShowCampaignDetails}>
        <DialogContent className="sm:max-w-2xl">
          {selectedCampaign && (
            <>
              <DialogHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <DialogTitle>{selectedCampaign.titulo}</DialogTitle>
                    <p className="text-sm text-muted-foreground mt-1">{selectedCampaign.assunto}</p>
                  </div>
                  {getStatusBadge(selectedCampaign.status)}
                </div>
              </DialogHeader>
              
              <Tabs defaultValue="overview">
                <TabsList className="w-full">
                  <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                  <TabsTrigger value="content">Conteúdo</TabsTrigger>
                  <TabsTrigger value="recipients">Destinatários</TabsTrigger>
                  {selectedCampaign.status === 'concluida' && (
                    <TabsTrigger value="analytics">Analytics</TabsTrigger>
                  )}
                </TabsList>
                
                <TabsContent value="overview" className="space-y-4 mt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-medium">Informações</h3>
                      <div className="mt-2 space-y-2">
                        <div className="flex items-center">
                          <Mail className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="text-sm">
                            De: {selectedCampaign.remetente_nome} <span className="text-muted-foreground">&lt;{selectedCampaign.remetente_email}&gt;</span>
                          </span>
                        </div>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="text-sm">
                            Criada em: {format(parseISO(selectedCampaign.data_criacao), 'PPP', { locale: ptBR })}
                          </span>
                        </div>
                        
                        {selectedCampaign.data_agendamento && (
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                            <span className="text-sm">
                              Agendada para: {format(parseISO(selectedCampaign.data_agendamento), 'PPp', { locale: ptBR })}
                            </span>
                          </div>
                        )}
                        
                        {selectedCampaign.data_inicio_envio && (
                          <div className="flex items-center">
                            <Send className="h-4 w-4 mr-2 text-muted-foreground" />
                            <span className="text-sm">
                              Enviada em: {format(parseISO(selectedCampaign.data_inicio_envio), 'PPp', { locale: ptBR })}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium">Destinatários</h3>
                      <div className="mt-2 space-y-2">
                        <div className="flex items-center">
                          <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="text-sm">
                            Total: {selectedCampaign.total_destinatarios || 'Não definido'}
                          </span>
                        </div>
                        
                        {selectedCampaign.segmentacao?.tipo_publico && (
                          <div className="flex items-start">
                            <Tag className="h-4 w-4 mr-2 text-muted-foreground mt-1" />
                            <div>
                              <span className="text-sm block">Segmentação:</span>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {selectedCampaign.segmentacao.tipo_publico.map(tipo => (
                                  <Badge key={tipo} variant="outline" className="text-xs">
                                    {tipo === 'clientes' && 'Clientes'}
                                    {tipo === 'associados' && 'Associados'}
                                    {tipo === 'inscritos' && 'Inscritos'}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {selectedCampaign.status === 'concluida' && (
                    <>
                      <Separator />
                      <div>
                        <h3 className="text-sm font-medium mb-3">Estatísticas</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          <Card>
                            <CardContent className="pt-6">
                              <div className="text-center">
                                <Send className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                                <div className="text-2xl font-bold">{selectedCampaign.total_enviados || 0}</div>
                                <p className="text-sm text-muted-foreground">Enviados</p>
                                <p className="text-xs text-muted-foreground mt-1">
                                  ({Math.round((selectedCampaign.total_enviados / selectedCampaign.total_destinatarios) * 100)}% do total)
                                </p>
                              </div>
                            </CardContent>
                          </Card>
                          
                          <Card>
                            <CardContent className="pt-6">
                              <div className="text-center">
                                <Eye className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                                <div className="text-2xl font-bold">{selectedCampaign.total_aberturas || 0}</div>
                                <p className="text-sm text-muted-foreground">Aberturas</p>
                                <p className="text-xs text-muted-foreground mt-1">
                                  ({Math.round((selectedCampaign.total_aberturas / selectedCampaign.total_enviados) * 100)}% dos envios)
                                </p>
                              </div>
                            </CardContent>
                          </Card>
                          
                          <Card>
                            <CardContent className="pt-6">
                              <div className="text-center">
                                <MousePointerClick className="h-8 w-8 text-green-500 mx-auto mb-2" />
                                <div className="text-2xl font-bold">{selectedCampaign.total_cliques || 0}</div>
                                <p className="text-sm text-muted-foreground">Cliques</p>
                                <p className="text-xs text-muted-foreground mt-1">
                                  ({Math.round((selectedCampaign.total_cliques / selectedCampaign.total_aberturas) * 100)}% das aberturas)
                                </p>
                              </div>
                            </CardContent>
                          </Card>
                        </div>
                      </div>
                    </>
                  )}
                </TabsContent>
                
                <TabsContent value="content" className="mt-4">
                  <div className="border rounded-lg p-4">
                    <div className="border-b pb-2 mb-4">
                      <div className="text-sm text-muted-foreground">De: {selectedCampaign.remetente_nome} &lt;{selectedCampaign.remetente_email}&gt;</div>
                      <div className="text-sm">Assunto: <span className="font-medium">{selectedCampaign.assunto}</span></div>
                    </div>
                    
                    <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: selectedCampaign.conteudo_html }} />
                  </div>
                </TabsContent>
                
                <TabsContent value="recipients" className="mt-4">
                  {selectedCampaign.total_destinatarios > 0 ? (
                    <div className="space-y-4">
                      <div className="bg-muted/20 rounded-lg p-4">
                        <div className="flex items-start">
                          <Users className="h-5 w-5 mr-2 text-muted-foreground mt-0.5" />
                          <div>
                            <h3 className="font-medium">Total de Destinatários: {selectedCampaign.total_destinatarios}</h3>
                            <p className="text-sm text-muted-foreground mt-1">
                              Segmentação aplicada às seguintes listas:
                            </p>
                          </div>
                        </div>
                        
                        <div className="mt-3 space-y-2">
                          {selectedCampaign.segmentacao?.tipo_publico.map(tipo => {
                            const grupoPorTipo = recipientGroups.filter(g => g.type === tipo);
                            
                            return (
                              <div key={tipo}>
                                <Badge className="mb-2">{tipo === 'clientes' ? 'Clientes' : tipo === 'associados' ? 'Associados' : 'Inscritos'}</Badge>
                                <div className="pl-2 space-y-1 border-l-2 border-muted ml-1">
                                  {grupoPorTipo.map(grupo => (
                                    <div key={grupo.id} className="text-sm flex items-center">
                                      <div className="w-2 h-2 rounded-full bg-muted-foreground mr-2"></div>
                                      {grupo.name} <span className="text-muted-foreground ml-1">({grupo.count})</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 bg-muted/10 rounded-lg">
                      <Users className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
                      <h3 className="text-lg font-medium">Nenhum destinatário definido</h3>
                      <p className="text-muted-foreground mt-1">
                        Esta campanha ainda não tem destinatários definidos.
                      </p>
                    </div>
                  )}
                </TabsContent>
                
                {selectedCampaign.status === 'concluida' && (
                  <TabsContent value="analytics" className="mt-4">
                    <div className="space-y-6">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">Desempenho da Campanha</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="h-80">
                            <div className="w-full h-full flex items-center justify-center bg-muted/20 rounded-lg">
                              <div className="text-center">
                                <BarChart2 className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                                <p className="text-muted-foreground">
                                  Dados detalhados de estatísticas seriam exibidos aqui
                                </p>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Principais Links Clicados</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <ArrowUpRight className="h-4 w-4 mr-2 text-blue-500" />
                                  <span className="text-sm truncate max-w-[200px]">https://exemplo.com/produto</span>
                                </div>
                                <Badge variant="outline">78 cliques</Badge>
                              </div>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <ArrowUpRight className="h-4 w-4 mr-2 text-blue-500" />
                                  <span className="text-sm truncate max-w-[200px]">https://exemplo.com/webinar</span>
                                </div>
                                <Badge variant="outline">53 cliques</Badge>
                              </div>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <ArrowUpRight className="h-4 w-4 mr-2 text-blue-500" />
                                  <span className="text-sm truncate max-w-[200px]">https://exemplo.com/artigo</span>
                                </div>
                                <Badge variant="outline">42 cliques</Badge>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Dispositivos Utilizados</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <span className="text-sm">Dispositivos Móveis</span>
                                </div>
                                <div className="text-sm">67% <span className="text-muted-foreground">(208)</span></div>
                              </div>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <span className="text-sm">Desktop</span>
                                </div>
                                <div className="text-sm">28% <span className="text-muted-foreground">(86)</span></div>
                              </div>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <span className="text-sm">Tablet</span>
                                </div>
                                <div className="text-sm">5% <span className="text-muted-foreground">(18)</span></div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </TabsContent>
                )}
              </Tabs>
              
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setShowCampaignDetails(false)}>
                  Fechar
                </Button>
                
                {selectedCampaign.status === 'rascunho' && (
                  <Button onClick={() => navigate(createPageUrl(`EditarCampanhaEmail?id=${selectedCampaign.id}`))}>
                    <Edit className="mr-2 h-4 w-4" />
                    Editar Campanha
                  </Button>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
