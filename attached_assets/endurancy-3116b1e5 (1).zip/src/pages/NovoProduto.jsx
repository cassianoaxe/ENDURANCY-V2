import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, 
  Save, 
  Plus, 
  Trash2, 
  Image, 
  Upload, 
  Leaf, 
  Beaker, 
  AlertTriangle, 
  Info, 
  DollarSign, 
  Tag, 
  Calendar, 
  Package,
  Clipboard,
  FileText,
  MessageSquare
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Select, 
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { toast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function NovoProduto() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("informacoes");
  const [imagePreview, setImagePreview] = useState(null);
  
  const [formData, setFormData] = useState({
    nome: "",
    codigo_sku: "",
    descricao: "",
    categoria: "",
    subcategoria: "",
    preco: "",
    preco_promocional: "",
    estoque_inicial: "",
    unidade_medida: "unidade",
    peso: "",
    altura: "",
    largura: "",
    comprimento: "",
    marca: "",
    controlled_substance: true,
    prescription_required: true,
    status: "ativo",
    thc_content: "",
    cbd_content: "",
    other_cannabinoids: "",
    terpenes: "",
    dose_recomendada: "",
    via_administracao: "",
    contraindicacoes: "",
    efeitos_colaterais: "",
    condicoes_uso: "",
    categoria_regulatoria: "medicamento",
    lab_results_url: "",
    documentos_regulatorios: [],
    imagens: [],
    tags: []
  });
  
  const [tagInput, setTagInput] = useState("");

  // Função para lidar com mudanças nos inputs
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  // Função para lidar com imagens
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Criar uma URL para preview da imagem
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
      
      // Aqui você faria o upload real da imagem para seu servidor
      // E então adicionaria a URL ao formData
      // Simulando apenas o nome do arquivo para o exemplo
      setFormData({
        ...formData,
        imagens: [...formData.imagens, file.name]
      });
    }
  };

  // Função para adicionar tags
  const handleAddTag = (e) => {
    e.preventDefault();
    if (tagInput.trim() !== "" && !formData.tags.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, tagInput.trim()]
      });
      setTagInput("");
    }
  };

  // Função para remover tags
  const handleRemoveTag = (tag) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter(t => t !== tag)
    });
  };

  // Função para salvar o produto
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Aqui você faria a chamada API para salvar o produto
      // Simulando um delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast({
        title: "Produto criado com sucesso!",
        description: `O produto "${formData.nome}" foi cadastrado.`,
      });
      
      // Redirecionar para a lista de produtos
      navigate(createPageUrl("Produtos"));
    } catch (error) {
      console.error("Erro ao criar produto:", error);
      toast({
        title: "Erro ao criar produto",
        description: "Ocorreu um erro ao tentar cadastrar o produto. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate(createPageUrl("Produtos"))}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold">Novo Produto</h1>
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => navigate(createPageUrl("Produtos"))}
          >
            Cancelar
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={isLoading}
          >
            {isLoading ? (
              <>Salvando...</>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Salvar Produto
              </>
            )}
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 w-full max-w-3xl">
          <TabsTrigger value="informacoes">Informações Básicas</TabsTrigger>
          <TabsTrigger value="detalhes">Detalhes Técnicos</TabsTrigger>
          <TabsTrigger value="imagens">Imagens</TabsTrigger>
          <TabsTrigger value="regulatorio">Regulatório</TabsTrigger>
        </TabsList>
        
        <div className="mt-6">
          <TabsContent value="informacoes">
            <Card>
              <CardHeader>
                <CardTitle>Informações Básicas</CardTitle>
                <CardDescription>
                  Preencha as informações essenciais do produto.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nome">Nome do Produto *</Label>
                    <Input 
                      id="nome"
                      name="nome"
                      value={formData.nome}
                      onChange={handleChange}
                      placeholder="Ex: Óleo CBD Full Spectrum 30ml"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="codigo_sku">Código SKU *</Label>
                    <Input 
                      id="codigo_sku"
                      name="codigo_sku"
                      value={formData.codigo_sku}
                      onChange={handleChange}
                      placeholder="Ex: CBD-OIL-FS-30"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="descricao">Descrição</Label>
                  <Textarea 
                    id="descricao"
                    name="descricao"
                    value={formData.descricao}
                    onChange={handleChange}
                    placeholder="Descreva o produto em detalhes"
                    rows={4}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="categoria">Categoria *</Label>
                    <Select 
                      name="categoria" 
                      value={formData.categoria}
                      onValueChange={(value) => setFormData({...formData, categoria: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="óleo">Óleo</SelectItem>
                        <SelectItem value="cápsula">Cápsula</SelectItem>
                        <SelectItem value="flor">Flor</SelectItem>
                        <SelectItem value="extrato">Extrato</SelectItem>
                        <SelectItem value="tópico">Tópico</SelectItem>
                        <SelectItem value="comestível">Comestível</SelectItem>
                        <SelectItem value="tinturas">Tinturas</SelectItem>
                        <SelectItem value="outro">Outro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="subcategoria">Subcategoria</Label>
                    <Input 
                      id="subcategoria"
                      name="subcategoria"
                      value={formData.subcategoria}
                      onChange={handleChange}
                      placeholder="Ex: Full Spectrum"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="marca">Marca</Label>
                    <Input 
                      id="marca"
                      name="marca"
                      value={formData.marca}
                      onChange={handleChange}
                      placeholder="Ex: CannaMed"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="estoque_inicial">Estoque Inicial</Label>
                    <Input 
                      id="estoque_inicial"
                      name="estoque_inicial"
                      type="number"
                      value={formData.estoque_inicial}
                      onChange={handleChange}
                      placeholder="Ex: 100"
                      min="0"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="preco">Preço (R$) *</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                      <Input 
                        id="preco"
                        name="preco"
                        type="number"
                        step="0.01"
                        value={formData.preco}
                        onChange={handleChange}
                        placeholder="0.00"
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="preco_promocional">Preço Promocional (R$)</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                      <Input 
                        id="preco_promocional"
                        name="preco_promocional"
                        type="number"
                        step="0.01"
                        value={formData.preco_promocional}
                        onChange={handleChange}
                        placeholder="0.00"
                        className="pl-10"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Tags do Produto</Label>
                  <div className="flex gap-2">
                    <Input 
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      placeholder="Adicione tags para categorizar o produto"
                      onKeyDown={(e) => e.key === 'Enter' && handleAddTag(e)}
                    />
                    <Button type="button" onClick={handleAddTag}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="flex items-center gap-1">
                        {tag}
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-4 w-4 rounded-full" 
                          onClick={() => handleRemoveTag(tag)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Switch 
                      id="controlled_substance"
                      name="controlled_substance"
                      checked={formData.controlled_substance}
                      onCheckedChange={(checked) => setFormData({...formData, controlled_substance: checked})}
                    />
                    <Label htmlFor="controlled_substance">Substância controlada</Label>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Switch 
                      id="prescription_required"
                      name="prescription_required"
                      checked={formData.prescription_required}
                      onCheckedChange={(checked) => setFormData({...formData, prescription_required: checked})}
                    />
                    <Label htmlFor="prescription_required">Requer prescrição médica</Label>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    name="status" 
                    value={formData.status}
                    onValueChange={(value) => setFormData({...formData, status: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                      <SelectItem value="esgotado">Esgotado</SelectItem>
                      <SelectItem value="rascunho">Rascunho</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="detalhes">
            <Card>
              <CardHeader>
                <CardTitle>Detalhes Técnicos</CardTitle>
                <CardDescription>
                  Informações técnicas e composição do produto.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="thc_content">Conteúdo de THC (%)</Label>
                    <Input 
                      id="thc_content"
                      name="thc_content"
                      type="number"
                      step="0.01"
                      value={formData.thc_content}
                      onChange={handleChange}
                      placeholder="Ex: 0.2"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="cbd_content">Conteúdo de CBD (%)</Label>
                    <Input 
                      id="cbd_content"
                      name="cbd_content"
                      type="number"
                      step="0.01"
                      value={formData.cbd_content}
                      onChange={handleChange}
                      placeholder="Ex: 10.0"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="unidade_medida">Unidade de Medida</Label>
                    <Select 
                      name="unidade_medida" 
                      value={formData.unidade_medida}
                      onValueChange={(value) => setFormData({...formData, unidade_medida: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma unidade" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="unidade">Unidade</SelectItem>
                        <SelectItem value="ml">ml</SelectItem>
                        <SelectItem value="g">g</SelectItem>
                        <SelectItem value="mg">mg</SelectItem>
                        <SelectItem value="cápsula">Cápsula</SelectItem>
                        <SelectItem value="frasco">Frasco</SelectItem>
                        <SelectItem value="pote">Pote</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="other_cannabinoids">Outros Canabinóides</Label>
                  <Textarea 
                    id="other_cannabinoids"
                    name="other_cannabinoids"
                    value={formData.other_cannabinoids}
                    onChange={handleChange}
                    placeholder="Ex: CBG: 2%, CBN: 0.5%"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="terpenes">Terpenos</Label>
                  <Textarea 
                    id="terpenes"
                    name="terpenes"
                    value={formData.terpenes}
                    onChange={handleChange}
                    placeholder="Liste os terpenos presentes"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="dose_recomendada">Dose Recomendada</Label>
                    <Input 
                      id="dose_recomendada"
                      name="dose_recomendada"
                      value={formData.dose_recomendada}
                      onChange={handleChange}
                      placeholder="Ex: 1ml, duas vezes ao dia"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="via_administracao">Via de Administração</Label>
                    <Select 
                      name="via_administracao" 
                      value={formData.via_administracao}
                      onValueChange={(value) => setFormData({...formData, via_administracao: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="oral">Oral</SelectItem>
                        <SelectItem value="sublingual">Sublingual</SelectItem>
                        <SelectItem value="tópica">Tópica</SelectItem>
                        <SelectItem value="inalatória">Inalatória</SelectItem>
                        <SelectItem value="nasal">Nasal</SelectItem>
                        <SelectItem value="ocular">Ocular</SelectItem>
                        <SelectItem value="retal">Retal</SelectItem>
                        <SelectItem value="vaginal">Vaginal</SelectItem>
                        <SelectItem value="outro">Outro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="contraindicacoes">Contraindicações</Label>
                  <Textarea 
                    id="contraindicacoes"
                    name="contraindicacoes"
                    value={formData.contraindicacoes}
                    onChange={handleChange}
                    placeholder="Liste as contraindicações do produto"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="efeitos_colaterais">Possíveis Efeitos Colaterais</Label>
                  <Textarea 
                    id="efeitos_colaterais"
                    name="efeitos_colaterais"
                    value={formData.efeitos_colaterais}
                    onChange={handleChange}
                    placeholder="Liste os possíveis efeitos colaterais"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="peso">Peso (g)</Label>
                    <Input 
                      id="peso"
                      name="peso"
                      type="number"
                      step="0.01"
                      value={formData.peso}
                      onChange={handleChange}
                      placeholder="Ex: 100"
                    />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-2">
                      <Label htmlFor="altura">Altura (cm)</Label>
                      <Input 
                        id="altura"
                        name="altura"
                        type="number"
                        step="0.1"
                        value={formData.altura}
                        onChange={handleChange}
                        placeholder="Ex: 10"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="largura">Largura (cm)</Label>
                      <Input 
                        id="largura"
                        name="largura"
                        type="number"
                        step="0.1"
                        value={formData.largura}
                        onChange={handleChange}
                        placeholder="Ex: 5"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="comprimento">Comprimento (cm)</Label>
                      <Input 
                        id="comprimento"
                        name="comprimento"
                        type="number"
                        step="0.1"
                        value={formData.comprimento}
                        onChange={handleChange}
                        placeholder="Ex: 5"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="imagens">
            <Card>
              <CardHeader>
                <CardTitle>Imagens do Produto</CardTitle>
                <CardDescription>
                  Adicione imagens de alta qualidade para o produto.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center">
                      <Image className="w-10 h-10 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500 text-center mb-2">
                        Arraste e solte imagens ou clique para fazer upload
                      </p>
                      <input
                        type="file"
                        id="image-upload"
                        className="hidden"
                        accept="image/*"
                        onChange={handleImageUpload}
                      />
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => document.getElementById('image-upload').click()}
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Selecionar Imagem
                      </Button>
                      <p className="text-xs text-gray-400 mt-2">
                        PNG, JPG ou WEBP (max. 5MB)
                      </p>
                    </div>
                    
                    <div className="space-y-4">
                      <Label>Imagens Enviadas</Label>
                      {formData.imagens.length > 0 ? (
                        <div className="grid grid-cols-2 gap-3">
                          {formData.imagens.map((img, index) => (
                            <div key={index} className="relative border rounded-md overflow-hidden group">
                              <div className="h-20 bg-gray-100 flex items-center justify-center text-sm text-gray-500">
                                {img}
                              </div>
                              <Button 
                                variant="destructive" 
                                size="icon" 
                                className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 h-6 w-6"
                                onClick={() => setFormData({
                                  ...formData,
                                  imagens: formData.imagens.filter((_, i) => i !== index)
                                })}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-gray-500">
                          Nenhuma imagem enviada ainda.
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <Label>Preview</Label>
                    <div className="border rounded-lg overflow-hidden bg-white aspect-square flex items-center justify-center">
                      {imagePreview ? (
                        <img 
                          src={imagePreview} 
                          alt="Preview" 
                          className="max-h-full max-w-full object-contain" 
                        />
                      ) : (
                        <div className="text-center p-6">
                          <Package className="h-16 w-16 text-gray-200 mx-auto mb-3" />
                          <p className="text-gray-400">
                            Preview da imagem aparecerá aqui
                          </p>
                        </div>
                      )}
                    </div>
                    
                    <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 flex gap-3">
                      <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm text-yellow-800 font-medium">Recomendações para imagens</p>
                        <ul className="text-xs text-yellow-700 list-disc ml-4 mt-1 space-y-1">
                          <li>Use fundo branco ou neutro</li>
                          <li>Resolução mínima de 1000x1000 pixels</li>
                          <li>Inclua diferentes ângulos do produto</li>
                          <li>Evite incluir pessoas nas imagens</li>
                          <li>Certifique-se que imagens estão conformes com regulamentações</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="regulatorio">
            <Card>
              <CardHeader>
                <CardTitle>Informações Regulatórias</CardTitle>
                <CardDescription>
                  Documentação e informações regulatórias do produto.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="categoria_regulatoria">Categoria Regulatória</Label>
                  <Select 
                    name="categoria_regulatoria" 
                    value={formData.categoria_regulatoria}
                    onValueChange={(value) => setFormData({...formData, categoria_regulatoria: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="medicamento">Medicamento</SelectItem>
                      <SelectItem value="suplemento">Suplemento</SelectItem>
                      <SelectItem value="cosmético">Cosmético</SelectItem>
                      <SelectItem value="alimento">Alimento</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="condicoes_uso">Condições de Uso</Label>
                  <Textarea 
                    id="condicoes_uso"
                    name="condicoes_uso"
                    value={formData.condicoes_uso}
                    onChange={handleChange}
                    placeholder="Descreva as condições de uso do produto"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="lab_results_url">URL dos Resultados Laboratoriais</Label>
                  <Input 
                    id="lab_results_url"
                    name="lab_results_url"
                    value={formData.lab_results_url}
                    onChange={handleChange}
                    placeholder="Ex: https://example.com/lab-results.pdf"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Documentos Regulatórios</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center">
                    <FileText className="w-10 h-10 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500 text-center mb-2">
                      Adicione documentos regulatórios como aprovações, certificações, etc.
                    </p>
                    <Button variant="outline" size="sm">
                      <Upload className="w-4 h-4 mr-2" />
                      Selecionar Documentos
                    </Button>
                    <p className="text-xs text-gray-400 mt-2">
                      PDF, DOC, ou DOCX (max. 10MB)
                    </p>
                  </div>
                </div>
                
                <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                  <div className="flex gap-3">
                    <Info className="h-5 w-5 text-blue-600 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-blue-800 font-medium">Lembrete de Conformidade Regulatória</p>
                      <p className="text-xs text-blue-700 mt-1">
                        Certifique-se de que este produto atende a todas as regulamentações aplicáveis da 
                        ANVISA. Produtos à base de cannabis devem ter documentação completa e atualizada 
                        para estar em conformidade com a legislação vigente.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}