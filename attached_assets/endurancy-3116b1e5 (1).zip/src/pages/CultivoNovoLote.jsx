import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Leaf, 
  Plant, 
  ArrowLeft,
  Check,
  Calendar, 
  Clipboard, 
  Info,
  Sprout,
  AlertTriangle,
  Building2,
  Clock,
  Save
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Batch } from "@/api/entities";
import { Strain } from "@/api/entities";
import { GrowRoom } from "@/api/entities";

// Dados mock para strains
const mockStrains = [
  { id: "strain1", name: "Charlotte's Web", type: "CBD", thc_content: 0.3, cbd_content: 17.5, current_mother_plant_count: 4 },
  { id: "strain2", name: "CBD Skunk", type: "híbrida", thc_content: 2.0, cbd_content: 12.0, current_mother_plant_count: 4 },
  { id: "strain3", name: "Cannatonic", type: "híbrida", thc_content: 3.5, cbd_content: 12.5, current_mother_plant_count: 2 },
  { id: "strain4", name: "Harlequin", type: "híbrida", thc_content: 5.0, cbd_content: 8.5, current_mother_plant_count: 2 },
  { id: "strain5", name: "ACDC", type: "CBD", thc_content: 1.5, cbd_content: 19.0, current_mother_plant_count: 3 },
  { id: "strain6", name: "Harle-Tsu", type: "híbrida", thc_content: 1.0, cbd_content: 22.0, current_mother_plant_count: 2 }
];

// Dados mock para plantas madres
const mockMotherPlants = [
  { id: "mother1", strain_id: "strain1", plant_id: "CW-001", age_days: 150, health_status: "saudável" },
  { id: "mother2", strain_id: "strain1", plant_id: "CW-002", age_days: 180, health_status: "saudável" },
  { id: "mother3", strain_id: "strain1", plant_id: "CW-003", age_days: 200, health_status: "saudável" },
  { id: "mother4", strain_id: "strain1", plant_id: "CW-004", age_days: 170, health_status: "saudável" },
  { id: "mother5", strain_id: "strain2", plant_id: "SK-001", age_days: 140, health_status: "saudável" },
  { id: "mother6", strain_id: "strain2", plant_id: "SK-002", age_days: 160, health_status: "saudável" },
  { id: "mother7", strain_id: "strain2", plant_id: "SK-003", age_days: 190, health_status: "saudável" },
  { id: "mother8", strain_id: "strain2", plant_id: "SK-004", age_days: 200, health_status: "saudável" },
  { id: "mother9", strain_id: "strain3", plant_id: "CT-001", age_days: 130, health_status: "saudável" },
  { id: "mother10", strain_id: "strain3", plant_id: "CT-002", age_days: 145, health_status: "saudável" },
  { id: "mother11", strain_id: "strain4", plant_id: "HL-001", age_days: 160, health_status: "saudável" },
  { id: "mother12", strain_id: "strain4", plant_id: "HL-002", age_days: 175, health_status: "saudável" },
  { id: "mother13", strain_id: "strain5", plant_id: "AC-001", age_days: 155, health_status: "saudável" },
  { id: "mother14", strain_id: "strain5", plant_id: "AC-002", age_days: 140, health_status: "saudável" },
  { id: "mother15", strain_id: "strain5", plant_id: "AC-003", age_days: 165, health_status: "saudável" }
];

// Dados mock para salas
const mockRooms = [
  { id: "room1", name: "Sala de Propagação 1", type: "propagação", capacity: { plant_capacity: 200, used_capacity: 50 }, status: "ativa" },
  { id: "room2", name: "Sala de Propagação 2", type: "propagação", capacity: { plant_capacity: 200, used_capacity: 120 }, status: "ativa" },
  { id: "room3", name: "Sala de Vegetativo A", type: "vegetativo", capacity: { plant_capacity: 100, used_capacity: 65 }, status: "ativa" },
  { id: "room4", name: "Sala de Vegetativo B", type: "vegetativo", capacity: { plant_capacity: 100, used_capacity: 38 }, status: "ativa" },
  { id: "room5", name: "Sala de Mães", type: "mães", capacity: { plant_capacity: 20, used_capacity: 14 }, status: "ativa" }
];

// Componente para o formulário de novo lote
const BatchForm = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    strain_id: "",
    origin: "clone",
    mother_plant_id: "",
    initial_plant_count: "",
    location: "",
    notes: "",
    expected_harvest_date: "",
    batch_prefix: "LOTE",
    batch_number: ""
  });
  const [strains, setStrains] = useState([]);
  const [motherPlants, setMotherPlants] = useState([]);
  const [filteredMotherPlants, setFilteredMotherPlants] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [nextBatchNumber, setNextBatchNumber] = useState("2023-0146");
  
  // Simulando carregamento de dados do backend
  useEffect(() => {
    loadData();
  }, []);
  
  useEffect(() => {
    // Filtrar plantas madres baseado na strain selecionada
    if (formData.strain_id) {
      const filtered = motherPlants.filter(
        plant => plant.strain_id === formData.strain_id
      );
      setFilteredMotherPlants(filtered);
      
      // Se trocou de strain, limpar mother_plant_id selecionada
      if (filtered.length && !filtered.find(p => p.id === formData.mother_plant_id)) {
        setFormData(prev => ({...prev, mother_plant_id: ""}));
      }
      
      // Atualizar nome com base na strain selecionada
      const strain = strains.find(s => s.id === formData.strain_id);
      if (strain) {
        setFormData(prev => ({
          ...prev,
          name: `${strain.name} - Lote ${nextBatchNumber.split('-')[1]}`
        }));
      }
    } else {
      setFilteredMotherPlants([]);
    }
  }, [formData.strain_id, motherPlants]);
  
  const loadData = async () => {
    try {
      setIsLoading(true);
      
      // Em um app real, buscaríamos dados do backend
      // const loadedStrains = await Strain.list();
      // const loadedMotherPlants = await PlantEntity.filter({ status: "madre" });
      // const loadedRooms = await GrowRoom.list();
      
      // Usando dados mock para demonstração
      setTimeout(() => {
        setStrains(mockStrains);
        setMotherPlants(mockMotherPlants);
        setRooms(mockRooms);
        setIsLoading(false);
        
        // Configurar batch number
        const today = new Date();
        const year = today.getFullYear();
        setFormData(prev => ({
          ...prev,
          batch_prefix: "LOTE",
          batch_number: nextBatchNumber
        }));
      }, 800);
      
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
      setIsLoading(false);
    }
  };
  
  const handleInputChange = (field, value) => {
    // Limpar erro do campo modificado
    setErrors(prev => ({...prev, [field]: undefined}));
    
    // Atualizar valor do campo
    setFormData(prev => ({...prev, [field]: value}));
  };
  
  const validateStep = (currentStep) => {
    const newErrors = {};
    
    if (currentStep === 1) {
      if (!formData.strain_id) newErrors.strain_id = "Selecione uma strain";
      if (formData.origin === "clone" && !formData.mother_plant_id) newErrors.mother_plant_id = "Selecione uma planta madre";
      if (!formData.initial_plant_count || parseInt(formData.initial_plant_count) <= 0) {
        newErrors.initial_plant_count = "Insira um número válido de plantas";
      }
    }
    
    if (currentStep === 2) {
      if (!formData.name.trim()) newErrors.name = "Insira um nome para o lote";
      if (!formData.location) newErrors.location = "Selecione uma localização";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleNextStep = () => {
    if (validateStep(step)) {
      setStep(prev => prev + 1);
    }
  };
  
  const handlePrevStep = () => {
    setStep(prev => prev - 1);
  };
  
  const handleSubmit = async () => {
    if (!validateStep(step)) return;
    
    try {
      setIsLoading(true);
      
      // Preparar dados do lote para submissão
      const batchData = {
        batch_id: `${formData.batch_prefix}-${formData.batch_number}`,
        name: formData.name,
        strain: strains.find(s => s.id === formData.strain_id)?.name,
        origin: formData.origin,
        mother_plant_id: formData.mother_plant_id,
        status: "ativo",
        current_phase: "propagação",
        location: formData.location,
        creation_date: new Date().toISOString().split('T')[0],
        phase_start_date: new Date().toISOString().split('T')[0],
        expected_harvest_date: formData.expected_harvest_date,
        initial_plant_count: parseInt(formData.initial_plant_count),
        current_plant_count: parseInt(formData.initial_plant_count),
        harvested_plant_count: 0,
        discarded_plant_count: 0,
        notes: formData.notes,
        tracking_events: [
          {
            date: new Date().toISOString(),
            type: "fase",
            details: "Lote criado na fase de propagação",
            user_id: "current_user_id" // Seria o ID real do usuário em produção
          }
        ]
      };
      
      console.log("Dados do lote a ser criado:", batchData);
      
      // Em um app real, enviaríamos dados para o backend
      // const createdBatch = await Batch.create(batchData);
      
      // Simulando criação no backend
      setTimeout(() => {
        setIsLoading(false);
        
        // Navegar para a página do lote criado
        alert("Lote criado com sucesso!");
        window.location.href = createPageUrl("CultivoLotes");
      }, 1000);
      
    } catch (error) {
      console.error("Erro ao criar lote:", error);
      setIsLoading(false);
      alert("Erro ao criar lote: " + error.message);
    }
  };
  
  // Renderizar campos do Step 1
  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="strain">Strain (Variedade) <span className="text-red-500">*</span></Label>
        <Select
          value={formData.strain_id}
          onValueChange={(value) => handleInputChange('strain_id', value)}
        >
          <SelectTrigger id="strain" className={errors.strain_id ? "border-red-500" : ""}>
            <SelectValue placeholder="Selecione uma strain" />
          </SelectTrigger>
          <SelectContent>
            {strains.map(strain => (
              <SelectItem key={strain.id} value={strain.id}>
                {strain.name} ({strain.type}) - THC: {strain.thc_content}% / CBD: {strain.cbd_content}%
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.strain_id && <p className="text-red-500 text-sm">{errors.strain_id}</p>}
      </div>
      
      <div className="space-y-2">
        <Label>Origem das Plantas <span className="text-red-500">*</span></Label>
        <RadioGroup 
          value={formData.origin} 
          onValueChange={(value) => handleInputChange('origin', value)}
          className="flex flex-col space-y-1"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="clone" id="clone" />
            <Label htmlFor="clone" className="flex items-center gap-2">
              <Plant className="w-4 h-4 text-green-600" />
              Clones (de planta madre)
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="semente" id="semente" />
            <Label htmlFor="semente" className="flex items-center gap-2">
              <Sprout className="w-4 h-4 text-amber-600" />
              Sementes
            </Label>
          </div>
        </RadioGroup>
      </div>
      
      {formData.origin === "clone" && (
        <div className="space-y-2">
          <Label htmlFor="mother_plant">Planta Madre <span className="text-red-500">*</span></Label>
          <Select
            value={formData.mother_plant_id}
            onValueChange={(value) => handleInputChange('mother_plant_id', value)}
            disabled={!formData.strain_id || filteredMotherPlants.length === 0}
          >
            <SelectTrigger id="mother_plant" className={errors.mother_plant_id ? "border-red-500" : ""}>
              <SelectValue placeholder={formData.strain_id ? "Selecione uma planta madre" : "Selecione uma strain primeiro"} />
            </SelectTrigger>
            <SelectContent>
              {filteredMotherPlants.map(plant => (
                <SelectItem key={plant.id} value={plant.id}>
                  {plant.plant_id} - {plant.age_days} dias
                </SelectItem>
              ))}
              {formData.strain_id && filteredMotherPlants.length === 0 && (
                <SelectItem value="none" disabled>
                  Nenhuma planta madre disponível para esta strain
                </SelectItem>
              )}
            </SelectContent>
          </Select>
          {errors.mother_plant_id && <p className="text-red-500 text-sm">{errors.mother_plant_id}</p>}
          
          {formData.strain_id && filteredMotherPlants.length === 0 && (
            <Alert className="mt-2 bg-amber-50 text-amber-800 border-amber-200">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Atenção</AlertTitle>
              <AlertDescription>
                Não há plantas madres cadastradas para a strain selecionada. Você precisa adicionar uma planta madre antes de criar clones.
              </AlertDescription>
            </Alert>
          )}
        </div>
      )}
      
      <div className="space-y-2">
        <Label htmlFor="initial_plant_count">Número de Plantas <span className="text-red-500">*</span></Label>
        <Input
          id="initial_plant_count"
          type="number"
          min="1"
          placeholder={formData.origin === "clone" ? "Número de clones" : "Número de sementes"}
          value={formData.initial_plant_count}
          onChange={(e) => handleInputChange('initial_plant_count', e.target.value)}
          className={errors.initial_plant_count ? "border-red-500" : ""}
        />
        {errors.initial_plant_count && <p className="text-red-500 text-sm">{errors.initial_plant_count}</p>}
      </div>
      
      <Alert className="bg-blue-50 text-blue-800 border-blue-200">
        <Info className="h-4 w-4" />
        <AlertTitle>Dica</AlertTitle>
        <AlertDescription>
          Para melhores resultados, mantenha um número de plantas adequado à sua capacidade de cultivo.
          {formData.origin === "clone" ? " Certifique-se de que a planta madre escolhida está saudável." : " Sementes devem ser germinadas em condições controladas para maximizar a taxa de sucesso."}
        </AlertDescription>
      </Alert>
    </div>
  );
  
  // Renderizar campos do Step 2
  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="batch_id_prefix">Prefixo do ID <span className="text-red-500">*</span></Label>
          <Input
            id="batch_id_prefix"
            value={formData.batch_prefix}
            onChange={(e) => handleInputChange('batch_prefix', e.target.value)}
            placeholder="Ex: LOTE"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="batch_id_number">Número do Lote <span className="text-red-500">*</span></Label>
          <Input
            id="batch_id_number"
            value={formData.batch_number}
            onChange={(e) => handleInputChange('batch_number', e.target.value)}
            placeholder="Ex: 2023-0001"
          />
          <p className="text-xs text-gray-500">ID completo: {formData.batch_prefix}-{formData.batch_number}</p>
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="name">Nome do Lote <span className="text-red-500">*</span></Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => handleInputChange('name', e.target.value)}
          placeholder="Ex: Charlotte's Web - Lote 01"
          className={errors.name ? "border-red-500" : ""}
        />
        {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="location">Localização Inicial <span className="text-red-500">*</span></Label>
        <Select
          value={formData.location}
          onValueChange={(value) => handleInputChange('location', value)}
        >
          <SelectTrigger id="location" className={errors.location ? "border-red-500" : ""}>
            <SelectValue placeholder="Selecione a localização" />
          </SelectTrigger>
          <SelectContent>
            {rooms
              .filter(room => {
                const isAppropriateRoom = 
                  (formData.origin === "clone" && ["propagação"].includes(room.type)) ||
                  (formData.origin === "semente" && ["propagação"].includes(room.type));
                return isAppropriateRoom && room.status === "ativa";
              })
              .map(room => {
                const usedCapacity = room.capacity.used_capacity;
                const totalCapacity = room.capacity.plant_capacity;
                const availableCapacity = totalCapacity - usedCapacity;
                const plantCount = parseInt(formData.initial_plant_count) || 0;
                const isEnoughSpace = availableCapacity >= plantCount;
                
                return (
                  <SelectItem 
                    key={room.id} 
                    value={room.name}
                    disabled={!isEnoughSpace}
                  >
                    {room.name} ({availableCapacity} disponíveis)
                  </SelectItem>
                );
              })}
          </SelectContent>
        </Select>
        {errors.location && <p className="text-red-500 text-sm">{errors.location}</p>}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="expected_harvest_date">Data Prevista de Colheita</Label>
        <Input
          id="expected_harvest_date"
          type="date"
          value={formData.expected_harvest_date}
          onChange={(e) => handleInputChange('expected_harvest_date', e.target.value)}
        />
        <p className="text-xs text-gray-500">
          Data estimada para a colheita deste lote (pode ser ajustada posteriormente).
        </p>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="notes">Notas</Label>
        <Textarea
          id="notes"
          placeholder="Observações sobre este lote"
          value={formData.notes}
          onChange={(e) => handleInputChange('notes', e.target.value)}
          rows={4}
        />
      </div>
    </div>
  );
  
  // Renderizar review final
  const renderReview = () => (
    <div className="space-y-6">
      <Alert className="bg-green-50 border-green-200">
        <Check className="h-4 w-4 text-green-600" />
        <AlertTitle>Confira os Dados</AlertTitle>
        <AlertDescription>
          Verifique todas as informações antes de criar o lote. Após a criação, algumas informações básicas não poderão ser alteradas.
        </AlertDescription>
      </Alert>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Informações Gerais</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-500">ID do Lote</p>
              <p className="font-medium">{formData.batch_prefix}-{formData.batch_number}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Nome do Lote</p>
              <p className="font-medium">{formData.name}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Strain</p>
              <p className="font-medium">{strains.find(s => s.id === formData.strain_id)?.name}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Origem</p>
              <p className="font-medium capitalize">{formData.origin}</p>
            </div>
            {formData.origin === "clone" && (
              <div>
                <p className="text-sm font-medium text-gray-500">Planta Madre</p>
                <p className="font-medium">
                  {motherPlants.find(m => m.id === formData.mother_plant_id)?.plant_id || "Não selecionada"}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Detalhes do Cultivo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-500">Número de Plantas</p>
              <p className="font-medium">{formData.initial_plant_count}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Localização Inicial</p>
              <p className="font-medium">{formData.location}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Data de Criação</p>
              <p className="font-medium">{new Date().toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Data Prevista de Colheita</p>
              <p className="font-medium">{formData.expected_harvest_date || "Não definida"}</p>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {formData.notes && (
        <Card>
          <CardHeader>
            <CardTitle>Notas</CardTitle>
          </CardHeader>
          <CardContent>
            <p>{formData.notes}</p>
          </CardContent>
        </Card>
      )}
      
      <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
        <div className="flex items-start gap-2">
          <Info className="w-5 h-5 text-blue-600 mt-0.5" />
          <div>
            <h3 className="text-blue-800 font-medium">Próximos Passos</h3>
            <p className="text-sm text-blue-700 mt-1">
              Após criar o lote, você poderá:
            </p>
            <ul className="text-sm text-blue-700 mt-1 list-disc list-inside ml-1 space-y-1">
              <li>Registrar plantas individuais dentro deste lote</li>
              <li>Acompanhar o desenvolvimento do lote em cada fase</li>
              <li>Gerar etiquetas com QR codes para rastreabilidade</li>
              <li>Registrar eventos como aplicação de nutrientes, problemas encontrados, etc.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  // Renderização do formulário baseado no step atual
  return (
    <div className="space-y-8">
      <div className="relative flex items-center justify-center">
        <div className="flex items-center w-full max-w-xs mx-auto">
          <div 
            className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
              step >= 1 ? 'bg-green-50 border-green-600 text-green-600' : 'bg-gray-100 border-gray-300 text-gray-500'
            }`}
          >
            1
          </div>
          <div 
            className={`flex-1 h-1 mx-2 ${
              step >= 2 ? 'bg-green-500' : 'bg-gray-200'
            }`}
          ></div>
          <div 
            className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
              step >= 2 ? 'bg-green-50 border-green-600 text-green-600' : 'bg-gray-100 border-gray-300 text-gray-500'
            }`}
          >
            2
          </div>
          <div 
            className={`flex-1 h-1 mx-2 ${
              step >= 3 ? 'bg-green-500' : 'bg-gray-200'
            }`}
          ></div>
          <div 
            className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
              step >= 3 ? 'bg-green-50 border-green-600 text-green-600' : 'bg-gray-100 border-gray-300 text-gray-500'
            }`}
          >
            3
          </div>
        </div>
        <div className="absolute top-14 left-0 right-0 flex justify-between px-4">
          <span className="text-xs font-medium text-gray-500">Plantas</span>
          <span className="text-xs font-medium text-gray-500">Detalhes</span>
          <span className="text-xs font-medium text-gray-500">Revisão</span>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>
            {step === 1 && "Selecione a Strain e Origem das Plantas"}
            {step === 2 && "Detalhes do Lote"}
            {step === 3 && "Revisar e Confirmar"}
          </CardTitle>
          <CardDescription>
            {step === 1 && "Escolha a variedade genética e a origem das plantas para este lote"}
            {step === 2 && "Informe detalhes como localização, nome e datas"}
            {step === 3 && "Verifique todas as informações antes de criar o lote"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {step === 1 && renderStep1()}
          {step === 2 && renderStep2()}
          {step === 3 && renderReview()}
        </CardContent>
        <CardFooter className="flex justify-between">
          {step > 1 ? (
            <Button variant="outline" onClick={handlePrevStep}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          ) : (
            <Link to={createPageUrl("CultivoLotes")}>
              <Button variant="outline">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Cancelar
              </Button>
            </Link>
          )}
          
          {step < 3 ? (
            <Button onClick={handleNextStep}>
              Próximo
            </Button>
          ) : (
            <Button 
              onClick={handleSubmit} 
              disabled={isLoading}
              className="bg-green-600 hover:bg-green-700"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full"></div>
                  Criando Lote...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Criar Lote
                </>
              )}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

export default function CultivoNovoLote() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Novo Lote de Cultivo</h1>
          <p className="text-gray-500 mt-1">
            Inicie um novo lote de plantas para cultivo
          </p>
        </div>
        
        <Link to={createPageUrl("CultivoLotes")}>
          <Button variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para Lotes
          </Button>
        </Link>
      </div>
      
      <BatchForm />
    </div>
  );
}