
import React, { useState, useEffect } from 'react';
import { ContaBancaria } from '@/api/entities';
import { 
  Wallet, 
  Building2, 
  Plus, 
  Edit, 
  Trash2, 
  Search, 
  RefreshCw,
  Check, 
  X, 
  ArrowLeftRight, 
  MoreHorizontal, 
  Clock, 
  FileText, 
  Download, 
  Upload, 
  AlertTriangle,
  CreditCard,
  ListFilter,
  CalendarIcon,
  DollarSign,
  Loader2,
  Eye,
  Filter,
  ArrowUpRight,
  ArrowDownRight,
  BarChart4
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { toast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function GestaoContas() {
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('resumo');
  const [contas, setContas] = useState([]);
  const [transacoes, setTransacoes] = useState([]);
  const [periodoSelecionado, setPeriodoSelecionado] = useState('30dias');
  const [contaSelecionada, setContaSelecionada] = useState(null);
  const [showAddTransacaoDialog, setShowAddTransacaoDialog] = useState(false);
  const [showReconciliacaoDialog, setShowReconciliacaoDialog] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        await loadContas();
        await loadTransacoes();
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
        toast({
          title: "Erro ao carregar dados",
          description: "Não foi possível carregar todas as informações de contas bancárias.",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [periodoSelecionado]);

  const loadContas = async () => {
    const mockContas = [
      {
        id: "conta1",
        nome: "Conta Principal",
        banco: "Banco do Brasil",
        codigo_banco: "001",
        tipo_conta: "corrente",
        numero_agencia: "1234",
        digito_agencia: "5",
        numero_conta: "67890",
        digito_conta: "1",
        titular: "Empresa ACME Ltda",
        documento_titular: "12.345.678/0001-90",
        saldo_atual: 12580.45,
        saldo_pendente: 1450.80,
        saldo_disponivel: 11129.65,
        ativa: true,
        padrao: true,
        cor: "#4CAF50",
        chave_pix: "empresa@acme.com.br",
        tipo_chave_pix: "email",
        ultima_conciliacao: "2023-10-15T10:30:00Z",
        ultimo_extrato: "2023-10-20T08:45:00Z"
      },
      {
        id: "conta2",
        nome: "Conta Reserva",
        banco: "Itaú",
        codigo_banco: "341",
        tipo_conta: "poupanca",
        numero_agencia: "5678",
        digito_agencia: "",
        numero_conta: "12345",
        digito_conta: "6",
        titular: "Empresa ACME Ltda",
        documento_titular: "12.345.678/0001-90",
        saldo_atual: 45760.12,
        saldo_pendente: 0,
        saldo_disponivel: 45760.12,
        ativa: true,
        padrao: false,
        cor: "#2196F3",
        chave_pix: "12345678000190",
        tipo_chave_pix: "cnpj",
        ultima_conciliacao: "2023-10-10T14:20:00Z",
        ultimo_extrato: "2023-10-18T09:15:00Z"
      },
      {
        id: "conta3",
        nome: "Cartão Corporativo",
        banco: "Nubank",
        codigo_banco: "260",
        tipo_conta: "cartao",
        numero_agencia: "",
        digito_agencia: "",
        numero_conta: "",
        digito_conta: "",
        titular: "João Silva",
        documento_titular: "123.456.789-00",
        saldo_atual: -2450.78,
        saldo_pendente: 550.00,
        saldo_disponivel: -3000.78,
        ativa: true,
        padrao: false,
        cor: "#9C27B0",
        chave_pix: "",
        tipo_chave_pix: "",
        ultima_conciliacao: "2023-10-05T16:40:00Z",
        ultimo_extrato: "2023-10-15T11:30:00Z"
      }
    ];

    setContas(mockContas);
    
    if (!contaSelecionada && mockContas.length > 0) {
      setContaSelecionada(mockContas[0]);
    }
  };

  const loadTransacoes = async () => {
    const mockTransacoes = [
      {
        id: "trx1",
        conta_id: "conta1",
        data: "2023-10-20T14:30:00Z",
        tipo: "entrada",
        categoria: "vendas",
        descricao: "Recebimento Cliente XYZ",
        valor: 3500.00,
        conciliado: true,
        forma_pagamento: "pix",
        numero_documento: "PIX123456",
        contra_parte: "XYZ Ltda",
        centro_custo: "Vendas",
        observacao: "Pagamento referente à NF 1234"
      },
      {
        id: "trx2",
        conta_id: "conta1",
        data: "2023-10-18T11:15:00Z",
        tipo: "saida",
        categoria: "fornecedores",
        descricao: "Pagamento Fornecedor ABC",
        valor: 1875.50,
        conciliado: true,
        forma_pagamento: "transferencia",
        numero_documento: "TED987654",
        contra_parte: "ABC Suprimentos",
        centro_custo: "Compras",
        observacao: "Pagamento referente à compra de material"
      },
      {
        id: "trx3",
        conta_id: "conta1",
        data: "2023-10-16T09:45:00Z",
        tipo: "saida",
        categoria: "despesas_administrativas",
        descricao: "Aluguel Escritório",
        valor: 3200.00,
        conciliado: true,
        forma_pagamento: "transferencia",
        numero_documento: "TED123789",
        contra_parte: "Imobiliária Silva",
        centro_custo: "Administrativo",
        observacao: "Aluguel referente ao mês de outubro"
      },
      {
        id: "trx4",
        conta_id: "conta1",
        data: "2023-10-15T08:30:00Z",
        tipo: "saida",
        categoria: "impostos",
        descricao: "Pagamento DARF",
        valor: 1450.80,
        conciliado: false,
        forma_pagamento: "boleto",
        numero_documento: "DARF123456",
        contra_parte: "Receita Federal",
        centro_custo: "Impostos",
        observacao: "DARF referente a setembro"
      },
      {
        id: "trx5",
        conta_id: "conta2",
        data: "2023-10-19T15:45:00Z",
        tipo: "entrada",
        categoria: "investimentos",
        descricao: "Rendimento Aplicação",
        valor: 760.12,
        conciliado: true,
        forma_pagamento: "credito_automatico",
        numero_documento: "",
        contra_parte: "Banco Itaú",
        centro_custo: "Financeiro",
        observacao: "Rendimento mensal de aplicação"
      },
      {
        id: "trx6",
        conta_id: "conta3",
        data: "2023-10-17T12:20:00Z",
        tipo: "saida",
        categoria: "despesas_operacionais",
        descricao: "Combustível",
        valor: 250.75,
        conciliado: true,
        forma_pagamento: "cartao",
        numero_documento: "FAT654321",
        contra_parte: "Posto ABC",
        centro_custo: "Logística",
        observacao: "Abastecimento carro empresa"
      },
      {
        id: "trx7",
        conta_id: "conta3",
        data: "2023-10-16T19:30:00Z",
        tipo: "saida",
        categoria: "refeicoes",
        descricao: "Jantar com Cliente",
        valor: 385.90,
        conciliado: true,
        forma_pagamento: "cartao",
        numero_documento: "FAT789456",
        contra_parte: "Restaurante Gourmet",
        centro_custo: "Comercial",
        observacao: "Jantar com cliente potencial"
      },
      {
        id: "trx8",
        conta_id: "conta3",
        data: "2023-10-15T10:15:00Z",
        tipo: "saida",
        categoria: "assinaturas",
        descricao: "Assinatura Software",
        valor: 550.00,
        conciliado: false,
        forma_pagamento: "cartao",
        numero_documento: "ASS123456",
        contra_parte: "Software Inc",
        centro_custo: "TI",
        observacao: "Assinatura mensal"
      }
    ];

    setTransacoes(mockTransacoes);
  };

  const handleAddTransacao = async (data) => {
    try {
      const newTransaction = {
        id: `trx${Date.now()}`,
        conta_id: contaSelecionada.id,
        data: new Date().toISOString(),
        ...data,
        conciliado: false
      };
      
      setTransacoes(prev => [...prev, newTransaction]);
      
      setContas(prev => 
        prev.map(conta => {
          if (conta.id === contaSelecionada.id) {
            const valorNumerico = parseFloat(data.valor);
            const novoSaldo = data.tipo === 'entrada' 
              ? conta.saldo_atual + valorNumerico 
              : conta.saldo_atual - valorNumerico;
            
            const novoSaldoPendente = !data.conciliado
              ? conta.saldo_pendente + valorNumerico
              : conta.saldo_pendente;
            
            const novoSaldoDisponivel = novoSaldo - novoSaldoPendente;
            
            return {
              ...conta,
              saldo_atual: novoSaldo,
              saldo_pendente: novoSaldoPendente,
              saldo_disponivel: novoSaldoDisponivel
            };
          }
          return conta;
        })
      );
      
      setShowAddTransacaoDialog(false);
      
      toast({
        title: "Transação adicionada",
        description: `A transação foi registrada com sucesso.`
      });
    } catch (error) {
      toast({
        title: "Erro ao adicionar transação",
        description: error.message || "Ocorreu um erro ao registrar a transação.",
        variant: "destructive"
      });
    }
  };

  const getSaldoTotal = () => {
    return contas.reduce((total, conta) => total + conta.saldo_atual, 0);
  };

  const getTransacoesConta = (contaId) => {
    return transacoes.filter(tx => tx.conta_id === contaId);
  };

  const getTransacoesPendentes = (contaId) => {
    return transacoes.filter(tx => tx.conta_id === contaId && !tx.conciliado);
  };

  const getTransacoesRecentes = (contaId, limit = 5) => {
    return transacoes
      .filter(tx => tx.conta_id === contaId)
      .sort((a, b) => new Date(b.data) - new Date(a.data))
      .slice(0, limit);
  };

  const handleConciliarTransacao = (transacaoId) => {
    setTransacoes(prev => 
      prev.map(tx => {
        if (tx.id === transacaoId) {
          return { ...tx, conciliado: true };
        }
        return tx;
      })
    );
    
    toast({
      title: "Transação conciliada",
      description: "A transação foi marcada como conciliada com sucesso."
    });
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return format(date, 'dd/MM/yyyy - HH:mm', { locale: ptBR });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gestão de Contas Bancárias</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Acompanhe suas contas bancárias, saldos e movimentações
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => {
            setShowAddTransacaoDialog(true);
          }}>
            <Plus className="mr-2 h-4 w-4" />
            Nova Transação
          </Button>
          <Button variant="outline" onClick={() => {}}>
            <Upload className="mr-2 h-4 w-4" />
            Importar Extrato
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Saldo Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? (
                <div className="animate-pulse bg-gray-200 h-8 w-32 rounded"></div>
              ) : (
                <span className={getSaldoTotal() >= 0 ? 'text-green-600' : 'text-red-600'}>
                  {formatCurrency(getSaldoTotal())}
                </span>
              )}
            </div>
            <p className="text-xs text-gray-500 mt-1">Somatório de todas as contas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Entradas (30 dias)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {loading ? (
                <div className="animate-pulse bg-gray-200 h-8 w-32 rounded"></div>
              ) : (
                formatCurrency(
                  transacoes
                    .filter(tx => tx.tipo === 'entrada')
                    .reduce((sum, tx) => sum + tx.valor, 0)
                )
              )}
            </div>
            <p className="text-xs text-gray-500 mt-1">Total de entradas no período</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Saídas (30 dias)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {loading ? (
                <div className="animate-pulse bg-gray-200 h-8 w-32 rounded"></div>
              ) : (
                formatCurrency(
                  transacoes
                    .filter(tx => tx.tipo === 'saida')
                    .reduce((sum, tx) => sum + tx.valor, 0)
                )
              )}
            </div>
            <p className="text-xs text-gray-500 mt-1">Total de saídas no período</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {contas.map(conta => (
          <Card 
            key={conta.id}
            className={`cursor-pointer overflow-hidden transition-all ${contaSelecionada?.id === conta.id ? 'ring-2 ring-primary' : 'hover:shadow-md'}`}
            onClick={() => setContaSelecionada(conta)}
          >
            <CardHeader className="pb-2 bg-gray-50 dark:bg-gray-800 border-b">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: conta.cor || '#999' }}></div>
                  <CardTitle className="text-base">{conta.nome}</CardTitle>
                </div>
                {conta.padrao && (
                  <Badge variant="secondary" className="text-xs">Padrão</Badge>
                )}
              </div>
              <CardDescription className="text-xs">
                {conta.banco} ({conta.codigo_banco})
                {conta.tipo_conta !== 'cartao' && conta.tipo_conta !== 'dinheiro' && (
                  <span className="ml-1">
                    • Ag: {conta.numero_agencia}{conta.digito_agencia ? `-${conta.digito_agencia}` : ''}
                    • CC: {conta.numero_conta}{conta.digito_conta ? `-${conta.digito_conta}` : ''}
                  </span>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-3 pt-3">
              <div className="space-y-1">
                <p className="text-xs text-gray-500 dark:text-gray-400">Saldo Atual</p>
                <p className={`text-lg font-bold ${conta.saldo_atual >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                  {formatCurrency(conta.saldo_atual)}
                </p>
              </div>
              {conta.saldo_pendente > 0 && (
                <div className="text-xs text-gray-500 mt-1">
                  <span className="inline-flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    Pendente: {formatCurrency(conta.saldo_pendente)}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {contaSelecionada && (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full">
            <TabsTrigger value="resumo">
              <BarChart4 className="w-4 h-4 mr-2" />
              Resumo
            </TabsTrigger>
            <TabsTrigger value="extrato">
              <FileText className="w-4 h-4 mr-2" />
              Extrato
            </TabsTrigger>
            <TabsTrigger value="pendentes">
              <Clock className="w-4 h-4 mr-2" />
              Pendentes
            </TabsTrigger>
            <TabsTrigger value="conciliacao">
              <Check className="w-4 h-4 mr-2" />
              Conciliação
            </TabsTrigger>
          </TabsList>

          <TabsContent value="resumo" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <ArrowLeftRight className="h-5 w-5" />
                    Transações Recentes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                    </div>
                  ) : getTransacoesRecentes(contaSelecionada.id).length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <FileText className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                      <p>Nenhuma transação encontrada para esta conta.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {getTransacoesRecentes(contaSelecionada.id).map(tx => (
                        <div key={tx.id} className="flex items-center justify-between border-b pb-3">
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-full ${tx.tipo === 'entrada' ? 'bg-green-100' : 'bg-red-100'}`}>
                              {tx.tipo === 'entrada' ? (
                                <ArrowUpRight className={`h-4 w-4 ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`} />
                              ) : (
                                <ArrowDownRight className={`h-4 w-4 ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`} />
                              )}
                            </div>
                            <div>
                              <p className="font-medium text-sm">{tx.descricao}</p>
                              <p className="text-xs text-gray-500">{formatDate(tx.data)}</p>
                            </div>
                          </div>
                          <div className={`font-medium ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`}>
                            {tx.tipo === 'entrada' ? '+' : '-'}{formatCurrency(tx.valor)}
                          </div>
                        </div>
                      ))}
                      
                      <Button variant="outline" className="w-full mt-4" onClick={() => setActiveTab('extrato')}>
                        Ver Todas as Transações
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Transações Pendentes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                    </div>
                  ) : getTransacoesPendentes(contaSelecionada.id).length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Check className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                      <p>Não há transações pendentes para conciliação.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {getTransacoesPendentes(contaSelecionada.id).map(tx => (
                        <div key={tx.id} className="flex items-center justify-between border-b pb-3">
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-full ${tx.tipo === 'entrada' ? 'bg-green-100' : 'bg-red-100'}`}>
                              {tx.tipo === 'entrada' ? (
                                <ArrowUpRight className={`h-4 w-4 ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`} />
                              ) : (
                                <ArrowDownRight className={`h-4 w-4 ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`} />
                              )}
                            </div>
                            <div>
                              <p className="font-medium text-sm">{tx.descricao}</p>
                              <p className="text-xs text-gray-500">{formatDate(tx.data)}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className={`font-medium ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`}>
                              {tx.tipo === 'entrada' ? '+' : '-'}{formatCurrency(tx.valor)}
                            </div>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              className="text-green-600"
                              onClick={() => handleConciliarTransacao(tx.id)}
                            >
                              <Check className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                      
                      <Button variant="outline" className="w-full mt-4" onClick={() => setActiveTab('pendentes')}>
                        Ver Todas as Pendências
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Info className="h-5 w-5" />
                  Informações da Conta
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Saldo Atual</p>
                  <p className={`text-xl font-bold ${contaSelecionada.saldo_atual >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                    {formatCurrency(contaSelecionada.saldo_atual)}
                  </p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Última Conciliação</p>
                  <p className="text-xl font-medium">{formatDate(contaSelecionada.ultima_conciliacao)}</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Último Extrato</p>
                  <p className="text-xl font-medium">{formatDate(contaSelecionada.ultimo_extrato)}</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Pendente de Conciliação</p>
                  <p className="text-xl font-bold text-yellow-600 dark:text-yellow-400">
                    {formatCurrency(contaSelecionada.saldo_pendente)}
                  </p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Saldo Disponível</p>
                  <p className={`text-xl font-bold ${contaSelecionada.saldo_disponivel >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                    {formatCurrency(contaSelecionada.saldo_disponivel)}
                  </p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Transações no Período</p>
                  <p className="text-xl font-medium">
                    {getTransacoesConta(contaSelecionada.id).length}
                  </p>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4 flex justify-between">
                <Button variant="outline" onClick={() => {}}>
                  <Download className="mr-2 h-4 w-4" />
                  Baixar Extrato
                </Button>
                <Button variant="outline" onClick={() => setShowReconciliacaoDialog(true)}>
                  <Check className="mr-2 h-4 w-4" />
                  Conciliar Conta
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="extrato" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Extrato da Conta</CardTitle>
                  <CardDescription>
                    Transações da conta {contaSelecionada.nome}
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Select value={periodoSelecionado} onValueChange={setPeriodoSelecionado}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Selecione o período" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7dias">Últimos 7 dias</SelectItem>
                      <SelectItem value="15dias">Últimos 15 dias</SelectItem>
                      <SelectItem value="30dias">Últimos 30 dias</SelectItem>
                      <SelectItem value="90dias">Últimos 90 dias</SelectItem>
                      <SelectItem value="ano">Este ano</SelectItem>
                      <SelectItem value="personalizado">Período personalizado</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Button variant="outline" size="icon">
                    <Download className="h-4 w-4" />
                  </Button>
                  
                  <Button variant="outline" size="icon">
                    <Filter className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                  </div>
                ) : getTransacoesConta(contaSelecionada.id).length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                    <p>Nenhuma transação encontrada para esta conta no período selecionado.</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Data</TableHead>
                        <TableHead>Descrição</TableHead>
                        <TableHead>Categoria</TableHead>
                        <TableHead className="text-right">Valor</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getTransacoesConta(contaSelecionada.id)
                        .sort((a, b) => new Date(b.data) - new Date(a.data))
                        .map(tx => (
                          <TableRow key={tx.id}>
                            <TableCell>{format(new Date(tx.data), 'dd/MM/yyyy')}</TableCell>
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-2">
                                <div className={`p-1.5 rounded-full ${tx.tipo === 'entrada' ? 'bg-green-100' : 'bg-red-100'}`}>
                                  {tx.tipo === 'entrada' ? (
                                    <ArrowUpRight className={`h-3 w-3 ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`} />
                                  ) : (
                                    <ArrowDownRight className={`h-3 w-3 ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`} />
                                  )}
                                </div>
                                {tx.descricao}
                              </div>
                              <p className="text-xs text-gray-500 mt-1">
                                {tx.contra_parte && `${tx.contra_parte} • `}
                                {tx.numero_documento}
                              </p>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">
                                {tx.categoria === 'vendas' && 'Vendas'}
                                {tx.categoria === 'fornecedores' && 'Fornecedores'}
                                {tx.categoria === 'despesas_administrativas' && 'Despesas Adm.'}
                                {tx.categoria === 'impostos' && 'Impostos'}
                                {tx.categoria === 'investimentos' && 'Investimentos'}
                                {tx.categoria === 'despesas_operacionais' && 'Desp. Operacionais'}
                                {tx.categoria === 'refeicoes' && 'Refeições'}
                                {tx.categoria === 'assinaturas' && 'Assinaturas'}
                              </Badge>
                            </TableCell>
                            <TableCell className={`text-right font-medium ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`}>
                              {tx.tipo === 'entrada' ? '+' : '-'}{formatCurrency(tx.valor)}
                            </TableCell>
                            <TableCell className="text-center">
                              {tx.conciliado ? (
                                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                  Conciliado
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                                  Pendente
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>
                                    <Eye className="mr-2 h-4 w-4" />
                                    <span>Ver Detalhes</span>
                                  </DropdownMenuItem>
                                  
                                  <DropdownMenuItem>
                                    <Edit className="mr-2 h-4 w-4" />
                                    <span>Editar</span>
                                  </DropdownMenuItem>
                                  
                                  {!tx.conciliado && (
                                    <DropdownMenuItem onClick={() => handleConciliarTransacao(tx.id)}>
                                      <Check className="mr-2 h-4 w-4" />
                                      <span>Conciliar</span>
                                    </DropdownMenuItem>
                                  )}
                                  
                                  <DropdownMenuSeparator />
                                  
                                  <DropdownMenuItem className="text-red-600 dark:text-red-400">
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    <span>Excluir</span>
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pendentes" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Transações Pendentes</CardTitle>
                  <CardDescription>
                    Transações da conta {contaSelecionada.nome} que ainda não foram conciliadas
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowReconciliacaoDialog(true)}
                  >
                    <Check className="mr-2 h-4 w-4" />
                    Conciliar Todas
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                  </div>
                ) : getTransacoesPendentes(contaSelecionada.id).length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Check className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                    <p>Não há transações pendentes para conciliação.</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Data</TableHead>
                        <TableHead>Descrição</TableHead>
                        <TableHead>Categoria</TableHead>
                        <TableHead className="text-right">Valor</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getTransacoesPendentes(contaSelecionada.id)
                        .sort((a, b) => new Date(b.data) - new Date(a.data))
                        .map(tx => (
                          <TableRow key={tx.id}>
                            <TableCell>{format(new Date(tx.data), 'dd/MM/yyyy')}</TableCell>
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-2">
                                <div className={`p-1.5 rounded-full ${tx.tipo === 'entrada' ? 'bg-green-100' : 'bg-red-100'}`}>
                                  {tx.tipo === 'entrada' ? (
                                    <ArrowUpRight className={`h-3 w-3 ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`} />
                                  ) : (
                                    <ArrowDownRight className={`h-3 w-3 ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`} />
                                  )}
                                </div>
                                {tx.descricao}
                              </div>
                              <p className="text-xs text-gray-500 mt-1">
                                {tx.contra_parte && `${tx.contra_parte} • `}
                                {tx.numero_documento}
                              </p>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">
                                {tx.categoria === 'vendas' && 'Vendas'}
                                {tx.categoria === 'fornecedores' && 'Fornecedores'}
                                {tx.categoria === 'despesas_administrativas' && 'Despesas Adm.'}
                                {tx.categoria === 'impostos' && 'Impostos'}
                                {tx.categoria === 'investimentos' && 'Investimentos'}
                                {tx.categoria === 'despesas_operacionais' && 'Desp. Operacionais'}
                                {tx.categoria === 'refeicoes' && 'Refeições'}
                                {tx.categoria === 'assinaturas' && 'Assinaturas'}
                              </Badge>
                            </TableCell>
                            <TableCell className={`text-right font-medium ${tx.tipo === 'entrada' ? 'text-green-600' : 'text-red-600'}`}>
                              {tx.tipo === 'entrada' ? '+' : '-'}{formatCurrency(tx.valor)}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  className="text-green-600"
                                  onClick={() => handleConciliarTransacao(tx.id)}
                                >
                                  <Check className="h-4 w-4 mr-2" />
                                  Conciliar
                                </Button>
                                <Button variant="ghost" size="icon">
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="conciliacao" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Conciliação Bancária</CardTitle>
                  <CardDescription>
                    Compare os registros internos com o extrato bancário
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline">
                    <Upload className="mr-2 h-4 w-4" />
                    Importar Extrato
                  </Button>
                  <Button onClick={() => setShowReconciliacaoDialog(true)}>
                    <Check className="mr-2 h-4 w-4" />
                    Conciliar Conta
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Saldo no Sistema</p>
                      <p className={`text-2xl font-bold ${contaSelecionada.saldo_atual >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                        {formatCurrency(contaSelecionada.saldo_atual)}
                      </p>
                    </div>
                    
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Saldo no Banco</p>
                      <p className="text-2xl font-bold text-gray-700 dark:text-gray-300">
                        {formatCurrency(contaSelecionada.saldo_atual - 230.45)}
                      </p>
                    </div>
                    
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Diferença</p>
                      <p className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                        {formatCurrency(230.45)}
                      </p>
                    </div>
                  </div>
                </div>

                <Alert className="mb-6">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Conciliação Pendente</AlertTitle>
                  <AlertDescription>
                    Existem transações pendentes de conciliação. Importe o extrato bancário para identificar as diferenças.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Últimas Conciliações</h3>
                  
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Data</TableHead>
                        <TableHead>Usuário</TableHead>
                        <TableHead>Saldo Sistema</TableHead>
                        <TableHead>Saldo Banco</TableHead>
                        <TableHead>Diferença</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell>{format(new Date('2023-10-15T10:30:00Z'), 'dd/MM/yyyy')}</TableCell>
                        <TableCell>Maria Silva</TableCell>
                        <TableCell>{formatCurrency(12350.20)}</TableCell>
                        <TableCell>{formatCurrency(12350.20)}</TableCell>
                        <TableCell>{formatCurrency(0)}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Conciliado
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>{format(new Date('2023-09-30T16:45:00Z'), 'dd/MM/yyyy')}</TableCell>
                        <TableCell>João Costa</TableCell>
                        <TableCell>{formatCurrency(10780.35)}</TableCell>
                        <TableCell>{formatCurrency(10580.35)}</TableCell>
                        <TableCell>{formatCurrency(200)}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                            Ajustado
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      <Dialog open={showAddTransacaoDialog} onOpenChange={setShowAddTransacaoDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Adicionar Transação</DialogTitle>
            <DialogDescription>
              Registre uma nova transação na conta {contaSelecionada?.nome}.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tipo">Tipo</Label>
                <Select defaultValue="saida" id="tipo">
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="entrada">Entrada</SelectItem>
                    <SelectItem value="saida">Saída</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="valor">Valor</Label>
                <Input id="valor" type="number" step="0.01" min="0" placeholder="0,00" />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="descricao">Descrição</Label>
              <Input id="descricao" placeholder="Descrição da transação" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="categoria">Categoria</Label>
              <Select defaultValue="despesas_operacionais" id="categoria">
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a categoria" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="vendas">Vendas</SelectItem>
                  <SelectItem value="investimentos">Investimentos</SelectItem>
                  <SelectItem value="fornecedores">Fornecedores</SelectItem>
                  <SelectItem value="despesas_administrativas">Despesas Administrativas</SelectItem>
                  <SelectItem value="despesas_operacionais">Despesas Operacionais</SelectItem>
                  <SelectItem value="impostos">Impostos</SelectItem>
                  <SelectItem value="refeicoes">Refeições</SelectItem>
                  <SelectItem value="assinaturas">Assinaturas</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="contra_parte">Contraparte</Label>
              <Input id="contra_parte" placeholder="Nome do pagador/beneficiário" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="forma_pagamento">Forma de Pagamento</Label>
              <Select defaultValue="transferencia" id="forma_pagamento">
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a forma de pagamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pix">PIX</SelectItem>
                  <SelectItem value="transferencia">Transferência</SelectItem>
                  <SelectItem value="cartao">Cartão</SelectItem>
                  <SelectItem value="boleto">Boleto</SelectItem>
                  <SelectItem value="dinheiro">Dinheiro</SelectItem>
                  <SelectItem value="credito_automatico">Crédito Automático</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="numero_documento">Número do Documento</Label>
              <Input id="numero_documento" placeholder="Ex.: número de fatura, ordem, etc." />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="observacao">Observações</Label>
              <Input id="observacao" placeholder="Observações adicionais" />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddTransacaoDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={() => {
              handleAddTransacao({
                tipo: document.getElementById('tipo').value,
                valor: parseFloat(document.getElementById('valor').value || 0),
                descricao: document.getElementById('descricao').value,
                categoria: document.getElementById('categoria').value,
                contra_parte: document.getElementById('contra_parte').value,
                forma_pagamento: document.getElementById('forma_pagamento').value,
                numero_documento: document.getElementById('numero_documento').value,
                observacao: document.getElementById('observacao').value,
              });
            }}>
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showReconciliacaoDialog} onOpenChange={setShowReconciliacaoDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Conciliar Conta</DialogTitle>
            <DialogDescription>
              Confirme o saldo atual da conta no banco.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="saldo_sistema">Saldo no Sistema</Label>
              <Input id="saldo_sistema" value={contaSelecionada?.saldo_atual.toFixed(2)} disabled />
              <p className="text-xs text-gray-500 mt-1">
                Este é o saldo atual registrado no sistema.
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="saldo_banco">Saldo no Banco</Label>
              <Input id="saldo_banco" type="number" step="0.01" placeholder="Informe o saldo no extrato bancário" />
              <p className="text-xs text-gray-500 mt-1">
                Digite o saldo conforme aparece no extrato ou aplicativo do banco.
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="data_conciliacao">Data do Extrato</Label>
              <Input id="data_conciliacao" type="date" defaultValue={format(new Date(), 'yyyy-MM-dd')} />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="observacao_conciliacao">Observações</Label>
              <Input id="observacao_conciliacao" placeholder="Observações sobre a conciliação" />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReconciliacaoDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={() => {
              toast({
                title: "Conta conciliada",
                description: "A conta foi conciliada com sucesso."
              });
              setShowReconciliacaoDialog(false);
            }}>
              Conciliar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
  
  function Info(props) {
    return <div {...props} />;
  }
}
