
import React, { useState, useEffect } from 'react';
import { LegalDocument } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  FileText,
  Plus,
  Edit,
  Trash2,
  AlertTriangle,
  Undo2,
  History,
  Calendar,
  CheckCircle,
  Info,
  Shield,
  Eye,
  Lock
} from "lucide-react";
import ReactQuill from 'react-quill';
import { format } from 'date-fns';
import { toast } from "@/components/ui/use-toast";

// Estilos do editor Quill
const editorModules = {
  toolbar: [
    [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ 'list': 'ordered'}, { 'list': 'bullet' }],
    [{ 'indent': '-1'}, { 'indent': '+1' }],
    [{ 'align': [] }],
    ['link'],
    ['clean']
  ],
};

export default function LegalDocuments() {
  const [activeTab, setActiveTab] = useState("terms");
  const [documents, setDocuments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [showHistoryDialog, setShowHistoryDialog] = useState(false);
  const [currentDocument, setCurrentDocument] = useState(null);
  const [documentHistory, setDocumentHistory] = useState([]);
  const [error, setError] = useState(null);
  
  // Formulário para criar/editar documento
  const [formData, setFormData] = useState({
    title: "",
    type: "terms",
    content: "",
    version: "1.0",
    effective_date: new Date().toISOString().split('T')[0],
    required_acceptance: true,
    is_active: true
  });

  // Dados simulados para evitar problemas de timeout com a API
  const mockDocuments = [
    {
      id: "doc1",
      title: "Termos de Serviço",
      type: "terms",
      content: "<h2>Termos de Serviço da Endurancy</h2><p>Bem-vindo à plataforma Endurancy. Ao utilizar nossos serviços, você concorda com estes termos.</p><h3>1. Aceitação dos Termos</h3><p>Ao acessar ou usar nossa plataforma, você concorda com estes Termos de Serviço e com nossa Política de Privacidade.</p><h3>2. Descrição do Serviço</h3><p>A Endurancy oferece uma plataforma de gestão para organizações canábicas, incluindo ferramentas para controle de pacientes, prescrições, produtos e rastreabilidade.</p><h3>3. Elegibilidade</h3><p>Para utilizar a plataforma, você deve ser uma organização legalmente constituída e autorizada a operar no setor de cannabis medicinal ou um paciente com prescrição válida.</p>",
      version: "1.2",
      effective_date: "2023-06-15",
      required_acceptance: true,
      is_active: true,
      created_date: "2023-01-10T09:00:00Z",
      updated_date: "2023-06-10T14:30:00Z"
    },
    {
      id: "doc2",
      title: "Política de Privacidade",
      type: "privacy",
      content: "<h2>Política de Privacidade da Endurancy</h2><p>A Endurancy está comprometida em proteger sua privacidade. Esta política descreve como coletamos, usamos e protegemos suas informações.</p><h3>1. Coleta de Informações</h3><p>Coletamos informações que você nos fornece diretamente, como nome, e-mail, telefone e dados comerciais de sua organização.</p><h3>2. Uso das Informações</h3><p>Utilizamos suas informações para fornecer e melhorar nossos serviços, enviar comunicações relevantes e cumprir obrigações legais.</p><h3>3. Proteção de Dados</h3><p>Implementamos medidas de segurança técnicas e organizacionais para proteger suas informações contra acesso não autorizado.</p>",
      version: "1.1",
      effective_date: "2023-05-20",
      required_acceptance: true,
      is_active: true,
      created_date: "2023-01-15T10:20:00Z",
      updated_date: "2023-05-18T11:45:00Z"
    },
    {
      id: "doc3",
      title: "Política de Cookies",
      type: "cookies",
      content: "<h2>Política de Cookies</h2><p>Esta política explica como a Endurancy utiliza cookies e tecnologias semelhantes em nosso site e aplicativo.</p><h3>1. O que são Cookies</h3><p>Cookies são pequenos arquivos de texto que são armazenados no seu dispositivo quando você visita nosso site.</p><h3>2. Como Utilizamos Cookies</h3><p>Utilizamos cookies para melhorar sua experiência, analisar o tráfego do site e personalizar conteúdos.</p>",
      version: "1.0",
      effective_date: "2023-03-10",
      required_acceptance: false,
      is_active: true,
      created_date: "2023-03-05T08:30:00Z",
      updated_date: "2023-03-05T08:30:00Z"
    },
    {
      id: "doc4",
      title: "Termos de Serviço",
      type: "terms",
      content: "<h2>Termos de Serviço da Endurancy (versão anterior)</h2><p>Versão desatualizada dos termos.</p>",
      version: "1.1",
      effective_date: "2023-01-15",
      required_acceptance: true,
      is_active: false,
      created_date: "2022-12-20T15:00:00Z",
      updated_date: "2023-01-10T09:00:00Z",
      previous_version_id: null
    },
    {
      id: "doc5",
      title: "Termos de Serviço",
      type: "terms",
      content: "<h2>Termos de Serviço da Endurancy (versão inicial)</h2><p>Versão inicial dos termos.</p>",
      version: "1.0",
      effective_date: "2022-11-01",
      required_acceptance: true,
      is_active: false,
      created_date: "2022-10-25T11:20:00Z",
      updated_date: "2022-10-25T11:20:00Z",
      previous_version_id: null
    }
  ];

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Usando dados simulados para evitar problemas de timeout
      setDocuments(mockDocuments);
      
      // Em um ambiente real, usaríamos:
      // const docs = await LegalDocument.list('-updated_date');
      // setDocuments(docs);
    } catch (error) {
      console.error("Error loading legal documents", error);
      setError("Erro ao carregar documentos legais. Usando dados de demonstração.");
      setDocuments(mockDocuments);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTabChange = (value) => {
    setActiveTab(value);
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleEditorChange = (content) => {
    setFormData({
      ...formData,
      content
    });
  };

  const handleSwitchChange = (name, checked) => {
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const createNewDocument = async () => {
    try {
      // Em um ambiente real, salvaríamos no banco:
      // await LegalDocument.create(formData);
      
      // Simulando criação
      const newDoc = {
        ...formData,
        id: `doc${documents.length + 1}`,
        created_date: new Date().toISOString(),
        updated_date: new Date().toISOString()
      };
      
      setDocuments([newDoc, ...documents]);
      setShowCreateDialog(false);
      resetForm();
      
      toast({
        title: "Documento criado com sucesso",
        description: `${formData.title} v${formData.version} foi adicionado.`,
      });
    } catch (error) {
      console.error("Error creating document", error);
      toast({
        variant: "destructive",
        title: "Erro ao criar documento",
        description: "Ocorreu um erro ao criar o documento legal.",
      });
    }
  };

  const updateDocument = async () => {
    if (!currentDocument) return;
    
    try {
      // Em um ambiente real, atualizaríamos no banco:
      // await LegalDocument.update(currentDocument.id, formData);
      
      // Simulando atualização
      const updatedDocs = documents.map(doc => 
        doc.id === currentDocument.id 
          ? { ...formData, id: doc.id, created_date: doc.created_date, updated_date: new Date().toISOString() } 
          : doc
      );
      
      setDocuments(updatedDocs);
      setShowEditDialog(false);
      resetForm();
      
      toast({
        title: "Documento atualizado com sucesso",
        description: `${formData.title} v${formData.version} foi atualizado.`,
      });
    } catch (error) {
      console.error("Error updating document", error);
      toast({
        variant: "destructive",
        title: "Erro ao atualizar documento",
        description: "Ocorreu um erro ao atualizar o documento legal.",
      });
    }
  };

  const deleteDocument = async () => {
    if (!currentDocument) return;
    
    try {
      // Em um ambiente real, excluiríamos do banco:
      // await LegalDocument.delete(currentDocument.id);
      
      // Simulando exclusão
      const filteredDocs = documents.filter(doc => doc.id !== currentDocument.id);
      setDocuments(filteredDocs);
      setShowDeleteDialog(false);
      
      toast({
        title: "Documento excluído com sucesso",
        description: `${currentDocument.title} v${currentDocument.version} foi removido.`,
      });
    } catch (error) {
      console.error("Error deleting document", error);
      toast({
        variant: "destructive",
        title: "Erro ao excluir documento",
        description: "Ocorreu um erro ao excluir o documento legal.",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      type: "terms",
      content: "",
      version: "1.0",
      effective_date: new Date().toISOString().split('T')[0],
      required_acceptance: true,
      is_active: true
    });
  };

  const openEditDialog = (document) => {
    setCurrentDocument(document);
    setFormData({
      title: document.title,
      type: document.type,
      content: document.content,
      version: document.version,
      effective_date: document.effective_date,
      required_acceptance: document.required_acceptance,
      is_active: document.is_active
    });
    setShowEditDialog(true);
  };

  const openDeleteDialog = (document) => {
    setCurrentDocument(document);
    setShowDeleteDialog(true);
  };

  const openViewDialog = (document) => {
    setCurrentDocument(document);
    setShowViewDialog(true);
  };

  const openHistoryDialog = (documentType) => {
    // Filtramos os documentos pelo tipo e ordenamos por versão (decrescente)
    const history = documents
      .filter(doc => doc.type === documentType)
      .sort((a, b) => {
        const versionA = parseFloat(a.version);
        const versionB = parseFloat(b.version);
        return versionB - versionA;
      });
    
    setDocumentHistory(history);
    setShowHistoryDialog(true);
  };

  const createNewVersion = (document) => {
    // Para criar uma nova versão, incrementamos o número da versão
    const currentVersion = parseFloat(document.version);
    const newVersion = (currentVersion + 0.1).toFixed(1);
    
    setFormData({
      title: document.title,
      type: document.type,
      content: document.content,
      version: newVersion,
      effective_date: new Date().toISOString().split('T')[0],
      required_acceptance: document.required_acceptance,
      is_active: true,
      previous_version_id: document.id
    });
    
    setShowCreateDialog(true);
  };

  const filteredDocuments = documents.filter(doc => 
    doc.type === activeTab && doc.is_active
  );

  const typeLabels = {
    terms: "Termos de Serviço",
    privacy: "Política de Privacidade",
    cookies: "Política de Cookies",
    other: "Outros Documentos"
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Documentos Legais</h1>
          <p className="text-gray-500 mt-1">
            Gerencie os termos de serviço, políticas de privacidade e outros documentos legais
          </p>
        </div>
        <Button 
          onClick={() => {
            resetForm();
            setShowCreateDialog(true);
          }}
          className="gap-2 bg-green-600 hover:bg-green-700"
        >
          <Plus className="w-4 h-4" />
          Novo Documento
        </Button>
      </div>

      {error && (
        <Alert variant="warning">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Atenção</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Tabs 
        defaultValue="terms" 
        value={activeTab} 
        onValueChange={handleTabChange}
        className="w-full"
      >
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="terms" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            <span>Termos de Serviço</span>
          </TabsTrigger>
          <TabsTrigger value="privacy" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            <span>Privacidade</span>
          </TabsTrigger>
          <TabsTrigger value="cookies" className="flex items-center gap-2">
            <Info className="w-4 h-4" />
            <span>Cookies</span>
          </TabsTrigger>
          <TabsTrigger value="other" className="flex items-center gap-2">
            <Lock className="w-4 h-4" />
            <span>Outros</span>
          </TabsTrigger>
        </TabsList>

        {["terms", "privacy", "cookies", "other"].map((type) => (
          <TabsContent key={type} value={type} className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-xl font-semibold">{typeLabels[type]}</h2>
                <p className="text-gray-500 text-sm">
                  Gerencie as versões do documento {typeLabels[type].toLowerCase()}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  onClick={() => openHistoryDialog(type)}
                >
                  <History className="w-4 h-4" />
                  Histórico de Versões
                </Button>
              </div>
            </div>

            {isLoading ? (
              <div className="space-y-4">
                {[1, 2].map((i) => (
                  <div key={i} className="bg-white border rounded-lg p-6 animate-pulse">
                    <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/4 mb-8"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-full"></div>
                      <div className="h-4 bg-gray-200 rounded w-5/6"></div>
                      <div className="h-4 bg-gray-200 rounded w-4/6"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredDocuments.length === 0 ? (
              <Card>
                <CardContent className="pt-6 pb-4 text-center">
                  <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <h3 className="text-lg font-medium">Nenhum documento encontrado</h3>
                  <p className="text-gray-500 mt-1 max-w-md mx-auto">
                    Não há nenhum documento {typeLabels[type].toLowerCase()} ativo no momento.
                    Crie um novo documento usando o botão acima.
                  </p>
                  <Button
                    className="mt-4"
                    onClick={() => {
                      resetForm();
                      setFormData(prev => ({...prev, type}));
                      setShowCreateDialog(true);
                    }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Criar {typeLabels[type]}
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredDocuments.map((document) => (
                <Card key={document.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <CardTitle>{document.title}</CardTitle>
                          <Badge className="bg-green-100 text-green-800">
                            v{document.version}
                          </Badge>
                        </div>
                        <CardDescription className="flex items-center gap-3 mt-1">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5" />
                            Vigente desde {format(new Date(document.effective_date), 'dd/MM/yyyy')}
                          </span>
                          {document.required_acceptance && (
                            <span className="flex items-center gap-1 text-amber-600">
                              <Info className="w-3.5 h-3.5" />
                              Aceite obrigatório no registro
                            </span>
                          )}
                        </CardDescription>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="gap-1"
                          onClick={() => openViewDialog(document)}
                        >
                          <Eye className="w-4 h-4" />
                          Visualizar
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="gap-1"
                          onClick={() => openEditDialog(document)}
                        >
                          <Edit className="w-4 h-4" />
                          Editar
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="gap-1"
                          onClick={() => createNewVersion(document)}
                        >
                          <Plus className="w-4 h-4" />
                          Nova Versão
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="mt-4 text-sm text-gray-500 max-h-20 overflow-hidden relative">
                      <div dangerouslySetInnerHTML={{ __html: document.content.substring(0, 250) + '...' }} />
                      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white to-transparent"></div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        ))}
      </Tabs>

      {/* Create Document Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Novo Documento Legal</DialogTitle>
            <DialogDescription>
              Crie um novo documento legal para a plataforma
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Título do Documento</Label>
                <Input
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="Ex: Termos de Serviço da Endurancy"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="type">Tipo de Documento</Label>
                <select
                  id="type"
                  name="type"
                  value={formData.type}
                  onChange={handleInputChange}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <option value="terms">Termos de Serviço</option>
                  <option value="privacy">Política de Privacidade</option>
                  <option value="cookies">Política de Cookies</option>
                  <option value="other">Outro Documento</option>
                </select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="version">Versão</Label>
                <Input
                  id="version"
                  name="version"
                  value={formData.version}
                  onChange={handleInputChange}
                  placeholder="Ex: 1.0"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="effective_date">Data de Vigência</Label>
                <Input
                  id="effective_date"
                  name="effective_date"
                  type="date"
                  value={formData.effective_date}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="content">Conteúdo do Documento</Label>
              <div className="min-h-[400px] border rounded-md">
                <ReactQuill
                  theme="snow"
                  modules={editorModules}
                  value={formData.content}
                  onChange={handleEditorChange}
                  className="h-96"
                />
              </div>
            </div>
            
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-between">
              <div className="flex items-center space-x-2">
                <Switch
                  id="required_acceptance"
                  checked={formData.required_acceptance}
                  onCheckedChange={(checked) => handleSwitchChange("required_acceptance", checked)}
                />
                <Label htmlFor="required_acceptance">Exigir aceite durante o registro</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => handleSwitchChange("is_active", checked)}
                />
                <Label htmlFor="is_active">Tornar documento ativo imediatamente</Label>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCreateDialog(false)}
            >
              Cancelar
            </Button>
            <Button onClick={createNewDocument}>
              Criar Documento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Document Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Editar Documento Legal</DialogTitle>
            <DialogDescription>
              Atualize as informações do documento legal
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-title">Título do Documento</Label>
                <Input
                  id="edit-title"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="Ex: Termos de Serviço da Endurancy"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-type">Tipo de Documento</Label>
                <select
                  id="edit-type"
                  name="type"
                  value={formData.type}
                  onChange={handleInputChange}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <option value="terms">Termos de Serviço</option>
                  <option value="privacy">Política de Privacidade</option>
                  <option value="cookies">Política de Cookies</option>
                  <option value="other">Outro Documento</option>
                </select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-version">Versão</Label>
                <Input
                  id="edit-version"
                  name="version"
                  value={formData.version}
                  onChange={handleInputChange}
                  placeholder="Ex: 1.0"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit-effective_date">Data de Vigência</Label>
                <Input
                  id="edit-effective_date"
                  name="effective_date"
                  type="date"
                  value={formData.effective_date}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="edit-content">Conteúdo do Documento</Label>
              <div className="min-h-[400px] border rounded-md">
                <ReactQuill
                  theme="snow"
                  modules={editorModules}
                  value={formData.content}
                  onChange={handleEditorChange}
                  className="h-96"
                />
              </div>
            </div>
            
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-between">
              <div className="flex items-center space-x-2">
                <Switch
                  id="edit-required_acceptance"
                  checked={formData.required_acceptance}
                  onCheckedChange={(checked) => handleSwitchChange("required_acceptance", checked)}
                />
                <Label htmlFor="edit-required_acceptance">Exigir aceite durante o registro</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="edit-is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) => handleSwitchChange("is_active", checked)}
                />
                <Label htmlFor="edit-is_active">Manter documento ativo</Label>
              </div>
            </div>
          </div>
          
          <DialogFooter className="flex justify-between sm:justify-between">
            <Button
              variant="destructive"
              onClick={() => {
                setShowEditDialog(false);
                openDeleteDialog(currentDocument);
              }}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Excluir
            </Button>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowEditDialog(false)}
              >
                Cancelar
              </Button>
              <Button onClick={updateDocument}>
                Salvar Alterações
              </Button>
            </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Document Dialog */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              {currentDocument?.title}
              <Badge className="ml-2 bg-green-100 text-green-800">
                v{currentDocument?.version}
              </Badge>
            </DialogTitle>
            <DialogDescription>
              Vigente desde {currentDocument && format(new Date(currentDocument.effective_date), 'dd/MM/yyyy')}
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4 overflow-y-auto prose prose-sm max-w-none">
            {currentDocument && (
              <div dangerouslySetInnerHTML={{ __html: currentDocument.content }} />
            )}
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowViewDialog(false)}
            >
              Fechar
            </Button>
            <Button onClick={() => {
              setShowViewDialog(false);
              openEditDialog(currentDocument);
            }}>
              <Edit className="w-4 h-4 mr-2" />
              Editar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Confirmar exclusão
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>
              Tem certeza que deseja excluir o documento <strong>{currentDocument?.title} v{currentDocument?.version}</strong>?
            </p>
            <Alert variant="destructive" className="mt-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Atenção!</AlertTitle>
              <AlertDescription>
                Esta ação não pode ser desfeita. Se este documento está atualmente vinculado ao processo de registro, 
                certifique-se de criar uma nova versão ou substituí-lo antes de excluir.
              </AlertDescription>
            </Alert>
          </div>
          <DialogFooter className="flex space-x-2">
            <Button 
              variant="outline" 
              onClick={() => setShowDeleteDialog(false)}
            >
              Cancelar
            </Button>
            <Button 
              variant="destructive"
              onClick={deleteDocument}
            >
              Excluir Permanentemente
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Version History Dialog */}
      <Dialog open={showHistoryDialog} onOpenChange={setShowHistoryDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="w-5 h-5" />
              Histórico de Versões
            </DialogTitle>
            <DialogDescription>
              Veja todas as versões anteriores deste documento
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Versão</TableHead>
                  <TableHead>Título</TableHead>
                  <TableHead>Data de Vigência</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {documentHistory.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-6 text-gray-500">
                      Nenhuma versão encontrada para este tipo de documento
                    </TableCell>
                  </TableRow>
                ) : (
                  documentHistory.map((doc) => (
                    <TableRow key={doc.id}>
                      <TableCell className="font-medium">v{doc.version}</TableCell>
                      <TableCell>{doc.title}</TableCell>
                      <TableCell>{format(new Date(doc.effective_date), 'dd/MM/yyyy')}</TableCell>
                      <TableCell>
                        {doc.is_active ? (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Ativo
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-gray-500">
                            Inativo
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => {
                              setShowHistoryDialog(false);
                              openViewDialog(doc);
                            }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {!doc.is_active && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0"
                              onClick={() => {
                                setShowHistoryDialog(false);
                                // Reativar esta versão (desativando as outras)
                                const updatedDocs = documents.map(d => 
                                  d.type === doc.type 
                                    ? { ...d, is_active: d.id === doc.id } 
                                    : d
                                );
                                setDocuments(updatedDocs);
                                toast({
                                  title: "Versão reativada",
                                  description: `${doc.title} v${doc.version} agora é a versão ativa.`,
                                });
                              }}
                            >
                              <Undo2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowHistoryDialog(false)}
            >
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
