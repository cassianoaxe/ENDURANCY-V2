
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Building2, 
  Users, 
  Clock, 
  UserCheck, 
  TrendingUp, 
  Bell, 
  FileEdit,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  MessageSquare,
  Calendar,
  UserPlus,
  ShoppingBag,
  Leaf,
  FilePlus,
  CreditCard,
  MoreHorizontal
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';

// Dados simulados de organizações para evitar chamadas à API que estão causando timeout
const mockOrganizations = [
  {
    id: "org1",
    name: "MediCannabis Farma",
    type: "Empresa",
    plan: "Empresarial Pro",
    contact_name: "João Silva",
    contact_email: "joao@medicannabis.com.br",
    status: "Ativo",
    created_date: "2023-07-15T14:30:00Z"
  },
  {
    id: "org2",
    name: "Associação Médica Verde",
    type: "Associação",
    plan: "Associação Premium",
    contact_name: "Maria Oliveira",
    contact_email: "maria@amv.org.br",
    status: "Ativo",
    created_date: "2023-07-12T10:15:00Z"
  },
  {
    id: "org3",
    name: "CannaPesquisa Instituto",
    type: "Associação",
    plan: "Associação Plus",
    contact_name: "Pedro Almeida",
    contact_email: "pedro@cannapesquisa.org",
    status: "Pendente",
    created_date: "2023-07-21T09:45:00Z"
  },
  {
    id: "org4",
    name: "Green Medical Brasil",
    type: "Empresa",
    plan: "Empresarial Básico",
    contact_name: "Ana Sousa",
    contact_email: "ana@greenmedical.com.br",
    status: "Pendente",
    created_date: "2023-07-20T16:20:00Z"
  },
  {
    id: "org5",
    name: "Cannabis Brasil Sul",
    type: "Empresa",
    plan: "Empresarial Pro",
    contact_name: "Carlos Mendes",
    contact_email: "carlos@cannabisbrasil.com.br",
    status: "Rejeitado",
    created_date: "2023-07-10T11:30:00Z"
  },
  {
    id: "org6",
    name: "Cultivo Sustentável Ltda",
    type: "Empresa",
    plan: "Empresarial Básico",
    contact_name: "Ana Costa",
    contact_email: "ana@cultivosustentavel.com.br",
    status: "Ativo",
    created_date: "2023-06-28T14:45:00Z"
  }
];

// Sample data for recent activities
const recentActivities = [
  {
    id: 1,
    user: {
      name: "João Silva",
      avatar: "JS"
    },
    action: "approved",
    entity: "MediCannabis Farma",
    time: "2h atrás"
  },
  {
    id: 2,
    user: {
      name: "Maria Oliveira",
      avatar: "MO"
    },
    action: "created",
    entity: "Associação Médica Verde",
    time: "5h atrás"
  },
  {
    id: 3,
    user: {
      name: "Carlos Mendes",
      avatar: "CM"
    },
    action: "rejected",
    entity: "Cannabis Brasil Sul",
    time: "ontem"
  },
  {
    id: 4,
    user: {
      name: "Ana Costa",
      avatar: "AC"
    },
    action: "updated",
    entity: "Cultivo Sustentável Ltda",
    time: "ontem"
  }
];

// Sample data for pending requests
const pendingRequests = [
  {
    id: 1,
    name: "CannaPesquisa Instituto",
    type: "Associação",
    date: "21/07/2023",
    status: "Pendente"
  },
  {
    id: 2,
    name: "Green Medical Brasil",
    type: "Empresa",
    date: "20/07/2023",
    status: "Pendente"
  }
];

// Sample data for notifications
const notifications = [
  {
    id: 1,
    type: "request",
    message: "Nova solicitação de organização: CannaPesquisa Instituto",
    time: "2h atrás",
    read: false
  },
  {
    id: 2,
    type: "alert",
    message: "Tentativa de login suspeita detectada",
    time: "5h atrás",
    read: false
  },
  {
    id: 3,
    type: "message",
    message: "Nova mensagem de suporte da MediCannabis Farma",
    time: "ontem",
    read: true
  },
  {
    id: 4,
    type: "update",
    message: "Atualização do sistema programada para amanhã",
    time: "2 dias atrás",
    read: true
  }
];

// Sales data for charts
const salesData = [
  { month: 'Jan', total: 12000 },
  { month: 'Fev', total: 18000 },
  { month: 'Mar', total: 15000 },
  { month: 'Abr', total: 22000 },
  { month: 'Mai', total: 28000 },
  { month: 'Jun', total: 32000 },
  { month: 'Jul', total: 40000 }
];

// New users data for charts
const newUserData = [
  { month: 'Jan', count: 10 },
  { month: 'Fev', count: 15 },
  { month: 'Mar', count: 18 },
  { month: 'Abr', count: 25 },
  { month: 'Mai', count: 30 },
  { month: 'Jun', count: 35 },
  { month: 'Jul', count: 42 }
];

export default function Dashboard() {
  const [organizations, setOrganizations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [userType, setUserType] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [error, setError] = useState(null);

  useEffect(() => {
    loadCurrentUser();
    loadOrganizations();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = {
        id: "user1",
        full_name: "Admin",
        email: "admin@endurancy.com",
        role: "admin",
        user_type: "superadmin"
      };
      setCurrentUser(user);
      setUserType(user.user_type || "superadmin");
    } catch (error) {
      console.error("Error loading current user", error);
      setUserType("superadmin");
    }
  };

  const loadOrganizations = async () => {
    try {
      setIsLoading(true);
      setTimeout(() => {
        setOrganizations(mockOrganizations);
        setIsLoading(false);
      }, 500);
    } catch (error) {
      console.error("Error loading organizations", error);
      setError("Erro ao carregar organizações. Usando dados de demonstração.");
      setOrganizations(mockOrganizations);
      setIsLoading(false);
    }
  };

  const countsByStatus = {
    total: organizations.length,
    active: organizations.filter(org => org.status === "Ativo").length,
    pending: organizations.filter(org => org.status === "Pendente").length,
    rejected: organizations.filter(org => org.status === "Rejeitado").length
  };

  const getActionIcon = (action) => {
    switch (action) {
      case "approved": return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case "created": return <UserPlus className="w-5 h-5 text-blue-500" />;
      case "rejected": return <XCircle className="w-5 h-5 text-red-500" />;
      case "updated": return <FileEdit className="w-5 h-5 text-yellow-500" />;
      default: return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case "request": return <UserPlus className="w-5 h-5 text-blue-500" />;
      case "alert": return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case "message": return <MessageSquare className="w-5 h-5 text-purple-500" />;
      case "update": return <Bell className="w-5 h-5 text-yellow-500" />;
      default: return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };

  // Render CPLY (Super Admin) Dashboard
  const renderSuperAdminDashboard = () => {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            Gerencie todas as organizações e usuários da plataforma Endurancy.
          </p>
        </div>

        {error && (
          <div className="bg-yellow-50 dark:bg-yellow-900/30 border border-yellow-200 dark:border-yellow-800 text-yellow-800 dark:text-yellow-200 px-4 py-3 rounded-lg mb-4">
            <div className="flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2" />
              <span>{error}</span>
            </div>
          </div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="dark:border-gray-800">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardDescription>Total de Organizações</CardDescription>
                  <CardTitle className="text-3xl font-bold">{countsByStatus.total}</CardTitle>
                </div>
                <div className="p-3 bg-green-50 dark:bg-green-900/30 rounded-lg">
                  <Building2 className="w-5 h-5 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-green-600 dark:text-green-400 mt-2">
                <TrendingUp className="w-4 h-4 mr-1" />
                +2 novas organizações no último mês
              </div>
            </CardContent>
          </Card>

          <Card className="dark:border-gray-800">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardDescription>Organizações Ativas</CardDescription>
                  <CardTitle className="text-3xl font-bold">{countsByStatus.active}</CardTitle>
                </div>
                <div className="p-3 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
                  <UserCheck className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-blue-600 dark:text-blue-400 mt-2">
                <TrendingUp className="w-4 h-4 mr-1" />
                +20% este mês
              </div>
            </CardContent>
          </Card>

          <Card className="dark:border-gray-800">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardDescription>Solicitações Pendentes</CardDescription>
                  <CardTitle className="text-3xl font-bold">{countsByStatus.pending}</CardTitle>
                </div>
                <div className="p-3 bg-yellow-50 dark:bg-yellow-900/30 rounded-lg">
                  <Clock className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-yellow-600 dark:text-yellow-400 mt-2">
                <Clock className="w-4 h-4 mr-1" />
                2 novas solicitações esta semana
              </div>
            </CardContent>
          </Card>

          <Card className="dark:border-gray-800">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardDescription>Total de Usuários</CardDescription>
                  <CardTitle className="text-3xl font-bold">47</CardTitle>
                </div>
                <div className="p-3 bg-purple-50 dark:bg-purple-900/30 rounded-lg">
                  <Users className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-purple-600 dark:text-purple-400 mt-2">
                <TrendingUp className="w-4 h-4 mr-1" />
                +15% este mês
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Organizations */}
          <Card className="dark:border-gray-800">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Organizações Recentes</CardTitle>
                <Link to={createPageUrl("Organizations")}>
                  <Button variant="ghost" size="sm">Ver todas</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex justify-between items-center animate-pulse">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
                          <div>
                            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-32 mb-2"></div>
                            <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-24"></div>
                          </div>
                        </div>
                        <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-16"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  organizations.slice(0, 4).map((org) => (
                    <div key={org.id} className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                            {org.name.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{org.name}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{org.contact_email}</p>
                        </div>
                      </div>
                      <Badge className={
                        org.status === 'Ativo' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 
                        org.status === 'Pendente' ? 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200' : 
                        'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                      }>
                        {org.status}
                      </Badge>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Pending Requests */}
          <Card className="dark:border-gray-800">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Solicitações Pendentes</CardTitle>
                <Link to={createPageUrl("Requests")}>
                  <Button variant="ghost" size="sm">Ver todas</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingRequests.map((request) => (
                  <Link key={request.id} to={`${createPageUrl("Request")}?id=${request.id}`}>
                    <div className="flex justify-between items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-yellow-50 dark:bg-yellow-900/30 rounded-lg">
                          <Clock className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                        </div>
                        <div>
                          <p className="font-medium">{request.name}</p>
                          <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 gap-2">
                            <Badge variant="outline" className="text-xs font-normal dark:border-gray-700">
                              {request.type}
                            </Badge>
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {request.date}
                            </span>
                          </div>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">Revisar</Button>
                    </div>
                  </Link>
                ))}
                
                {pendingRequests.length === 0 && (
                  <div className="text-center py-6 text-gray-500 dark:text-gray-400">
                    <CheckCircle2 className="w-12 h-12 mx-auto text-green-200 dark:text-green-800 mb-2" />
                    <p>Não há solicitações pendentes no momento</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activities */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Atividades Recentes</CardTitle>
                <Link to={createPageUrl("Activities")}>
                  <Button variant="ghost" size="sm">Ver todas</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex gap-3">
                    <Avatar className="mt-0.5">
                      <AvatarFallback>{activity.user.avatar}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{activity.user.name}</span>
                        <span className="text-sm text-gray-500">•</span>
                        <span className="text-sm text-gray-500">{activity.time}</span>
                      </div>
                      <p className="text-gray-700 flex items-center gap-1.5 mt-1">
                        {getActionIcon(activity.action)}
                        <span>
                          {activity.action === "approved" && "Aprovou solicitação de "}
                          {activity.action === "created" && "Criou organização "}
                          {activity.action === "rejected" && "Rejeitou solicitação de "}
                          {activity.action === "updated" && "Atualizou informações de "}
                          <span className="font-medium">{activity.entity}</span>
                        </span>
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Notificações</CardTitle>
                <Link to={createPageUrl("Notifications")}>
                  <Button variant="ghost" size="sm">Ver todas</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div 
                    key={notification.id} 
                    className={`flex gap-3 p-2 -mx-2 rounded-lg ${notification.read ? '' : 'bg-blue-50'}`}
                  >
                    <div className="rounded-full p-2 bg-white shadow-sm flex-shrink-0">
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="flex-1">
                      <p className="text-gray-700">{notification.message}</p>
                      <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <span className="sr-only">Abrir menu</span>
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>Marcar como lida</DropdownMenuItem>
                        <DropdownMenuItem>Ocultar</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>Desativar notificações</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Render Organization Owner Dashboard
  const renderOrgOwnerDashboard = () => {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-gray-500 mt-1">
            Bem-vindo à plataforma Endurancy. Gerencie sua organização, pacientes e produtos.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="patients">Pacientes</TabsTrigger>
            <TabsTrigger value="products">Produtos</TabsTrigger>
            <TabsTrigger value="prescriptions">Prescrições</TabsTrigger>
            <TabsTrigger value="orders">Pedidos</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardDescription>Total de Pacientes</CardDescription>
                      <CardTitle className="text-3xl font-bold">128</CardTitle>
                    </div>
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <Users className="w-5 h-5 text-blue-600" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-blue-600 mt-2">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    +8 novos pacientes este mês
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardDescription>Produtos Ativos</CardDescription>
                      <CardTitle className="text-3xl font-bold">24</CardTitle>
                    </div>
                    <div className="p-3 bg-green-50 rounded-lg">
                      <Leaf className="w-5 h-5 text-green-600" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-green-600 mt-2">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    +3 novos produtos adicionados
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardDescription>Prescrições Pendentes</CardDescription>
                      <CardTitle className="text-3xl font-bold">12</CardTitle>
                    </div>
                    <div className="p-3 bg-yellow-50 rounded-lg">
                      <FilePlus className="w-5 h-5 text-yellow-600" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-yellow-600 mt-2">
                    <Clock className="w-4 h-4 mr-1" />
                    5 novas nas últimas 24h
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardDescription>Faturamento Mensal</CardDescription>
                      <CardTitle className="text-3xl font-bold">R$ 42.580</CardTitle>
                    </div>
                    <div className="p-3 bg-purple-50 rounded-lg">
                      <CreditCard className="w-5 h-5 text-purple-600" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-purple-600 mt-2">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    +12% comparado ao mês anterior
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <Card>
                <CardHeader>
                  <CardTitle>Vendas Mensais</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={salesData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip 
                          formatter={(value) => [`R$ ${value.toLocaleString()}`, 'Total']}
                          labelFormatter={(label) => `Mês: ${label}`}
                        />
                        <Legend />
                        <Bar dataKey="total" name="Vendas (R$)" fill="#4CAF50" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Novos Pacientes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={newUserData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="count" 
                          name="Novos Pacientes" 
                          stroke="#2196F3" 
                          activeDot={{ r: 8 }} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Orders and Activities */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Pedidos Recentes</CardTitle>
                    <Link to={createPageUrl("Orders")}>
                      <Button variant="ghost" size="sm">Ver todos</Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((id) => (
                      <div key={id} className="flex justify-between items-center p-3 hover:bg-gray-50 rounded-lg cursor-pointer">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-blue-50 rounded-lg">
                            <ShoppingBag className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium">Pedido #{10000 + id}</p>
                            <div className="flex items-center text-sm text-gray-500 gap-2">
                              <span>Maria Silva</span>
                              <span>•</span>
                              <span>R$ {(Math.random() * 1000).toFixed(2)}</span>
                            </div>
                          </div>
                        </div>
                        <Badge className="bg-green-100 text-green-800">Entregue</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Prescrições para Aprovação</CardTitle>
                    <Link to={createPageUrl("Prescriptions")}>
                      <Button variant="ghost" size="sm">Ver todas</Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((id) => (
                      <div key={id} className="flex justify-between items-center p-3 hover:bg-gray-50 rounded-lg cursor-pointer">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-yellow-50 rounded-lg">
                            <FilePlus className="w-5 h-5 text-yellow-600" />
                          </div>
                          <div>
                            <p className="font-medium">Prescrição #{2000 + id}</p>
                            <div className="flex items-center text-sm text-gray-500 gap-2">
                              <span>Dr. Carlos Santos</span>
                              <span>•</span>
                              <span>{new Date().toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                        <Button size="sm">Revisar</Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="patients">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Pacientes Recentes</CardTitle>
                  <Link to={createPageUrl("Patients")}>
                    <Button>Ver todos os pacientes</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Clique em "Ver todos os pacientes" para gerenciar todos os seus pacientes.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Produtos</CardTitle>
                  <Link to={createPageUrl("Products")}>
                    <Button>Gerenciar produtos</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Clique em "Gerenciar produtos" para ver e editar seu catálogo de produtos.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="prescriptions">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Prescrições</CardTitle>
                  <Link to={createPageUrl("Prescriptions")}>
                    <Button>Todas as prescrições</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Clique em "Todas as prescrições" para gerenciar as prescrições médicas.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Pedidos</CardTitle>
                  <Link to={createPageUrl("Orders")}>
                    <Button>Todos os pedidos</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Clique em "Todos os pedidos" para gerenciar os pedidos dos seus pacientes.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    );
  }

  return userType === "superadmin" || userType === null 
    ? renderSuperAdminDashboard() 
    : renderOrgOwnerDashboard();
}
