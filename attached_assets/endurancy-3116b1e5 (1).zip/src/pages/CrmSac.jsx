import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  MessageSquare, 
  Search, 
  Filter, 
  Plus, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  FileText, 
  MoreHorizontal, 
  Phone, 
  Mail, 
  MessageCircle, 
  ThumbsUp, 
  AlertTriangle,
  Send,
  Download,
  RefreshCw,
  HelpCircle,
  User
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/components/ui/use-toast";

export default function CrmSac() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [tipoAtendimento, setTipoAtendimento] = useState("all");
  const [statusAtendimento, setStatusAtendimento] = useState("all");
  const [atendimentos, setAtendimentos] = useState([]);
  const [showNovoAtendimento, setShowNovoAtendimento] = useState(false);
  const [novoAtendimento, setNovoAtendimento] = useState({
    nome: "",
    contato: "",
    email: "",
    tipo: "reclamacao",
    descricao: "",
    origem: "telefone",
    produto: "",
    lote: "",
    validade: "",
    pedido: ""
  });

  // Mock data para atendimentos
  const mockAtendimentos = [
    {
      id: "SAC-2023-001",
      data: "2023-11-10T14:35:22Z",
      nome: "Maria Silva",
      contato: "(11) 98765-4321",
      email: "maria.silva@email.com",
      tipo: "reclamacao",
      status: "em_andamento",
      descricao: "Frasco do Óleo de CBD 5% veio com vazamento",
      produto: "Óleo de CBD 5%",
      lote: "LOT-2023-001",
      pedido: "PED-2023-056",
      atendente: "João Oliveira",
      acoes: "Entrei em contato com a paciente e estamos enviando um novo frasco",
      requer_farmacovigilancia: false
    },
    {
      id: "SAC-2023-002",
      data: "2023-11-11T09:20:15Z",
      nome: "Carlos Mendes",
      contato: "(21) 99876-5432",
      email: "carlos.mendes@email.com",
      tipo: "duvida",
      status: "concluido",
      descricao: "Dúvida sobre posologia do óleo para criança de 8 anos",
      produto: "Óleo de CBD 3%",
      lote: "LOT-2023-003",
      pedido: "PED-2023-078",
      atendente: "Ana Costa",
      acoes: "Fornecidas orientações conforme prescrição médica e encaminhado material explicativo por e-mail",
      requer_farmacovigilancia: false
    },
    {
      id: "SAC-2023-003",
      data: "2023-11-12T15:45:30Z",
      nome: "Luciana Ferreira",
      contato: "(31) 98765-1234",
      email: "luciana.ferreira@email.com",
      tipo: "reacao_adversa",
      status: "em_andamento",
      descricao: "Paciente relatou tontura e náusea após uso do medicamento",
      produto: "Óleo de CBD 10%",
      lote: "LOT-2023-005",
      pedido: "PED-2023-092",
      atendente: "Pedro Santos",
      acoes: "Registrado no sistema de farmacovigilância. Médico foi notificado. Aguardando mais informações do paciente.",
      requer_farmacovigilancia: true
    },
    {
      id: "SAC-2023-004",
      data: "2023-11-13T10:30:00Z",
      nome: "Roberto Almeida",
      contato: "(41) 99999-8888",
      email: "roberto.almeida@email.com",
      tipo: "elogio",
      status: "concluido",
      descricao: "Elogio à qualidade do produto e rapidez na entrega",
      produto: "Cápsulas de CBD 25mg",
      lote: "LOT-2023-007",
      pedido: "PED-2023-105",
      atendente: "Maria Oliveira",
      acoes: "Agradecimento registrado e enviado para o departamento de marketing",
      requer_farmacovigilancia: false
    },
    {
      id: "SAC-2023-005",
      data: "2023-11-14T14:20:10Z",
      nome: "Sandra Vieira",
      contato: "(51) 98765-4321",
      email: "sandra.vieira@email.com",
      tipo: "ineficacia",
      status: "pendente",
      descricao: "Paciente relata que não percebeu efeito terapêutico após 30 dias de uso",
      produto: "Óleo de CBD 5%",
      lote: "LOT-2023-002",
      pedido: "PED-2023-115",
      atendente: "",
      acoes: "",
      requer_farmacovigilancia: true
    }
  ];

  useEffect(() => {
    // Simula carregamento de dados
    setIsLoading(true);
    setTimeout(() => {
      setAtendimentos(mockAtendimentos);
      setIsLoading(false);
    }, 1000);
  }, []);

  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSelect = (field, value) => {
    if (field === 'tipo') {
      setTipoAtendimento(value);
    } else if (field === 'status') {
      setStatusAtendimento(value);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNovoAtendimento({
      ...novoAtendimento,
      [name]: value
    });
  };

  const handleRadioChange = (name, value) => {
    setNovoAtendimento({
      ...novoAtendimento,
      [name]: value
    });
  };

  const handleSubmitAtendimento = (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulando envio para API
    setTimeout(() => {
      const newId = `SAC-2023-${(atendimentos.length + 1).toString().padStart(3, '0')}`;
      const newAtendimento = {
        id: newId,
        data: new Date().toISOString(),
        nome: novoAtendimento.nome,
        contato: novoAtendimento.contato,
        email: novoAtendimento.email,
        tipo: novoAtendimento.tipo,
        status: "pendente",
        descricao: novoAtendimento.descricao,
        produto: novoAtendimento.produto,
        lote: novoAtendimento.lote,
        pedido: novoAtendimento.pedido,
        atendente: "",
        acoes: "",
        requer_farmacovigilancia: novoAtendimento.tipo === "reacao_adversa" || novoAtendimento.tipo === "ineficacia"
      };
      
      setAtendimentos([newAtendimento, ...atendimentos]);
      
      toast({
        title: "Atendimento registrado com sucesso",
        description: `Atendimento ${newId} foi criado e está aguardando análise.`,
      });
      
      // Se for caso de farmacovigilância, exibir alerta
      if (newAtendimento.requer_farmacovigilancia) {
        toast({
          title: "Atenção: Caso de Farmacovigilância",
          description: "Este atendimento requer análise da equipe de Farmacovigilância.",
          variant: "destructive",
        });
      }
      
      setShowNovoAtendimento(false);
      setNovoAtendimento({
        nome: "",
        contato: "",
        email: "",
        tipo: "reclamacao",
        descricao: "",
        origem: "telefone",
        produto: "",
        lote: "",
        validade: "",
        pedido: ""
      });
      
      setIsLoading(false);
    }, 1500);
  };

  const filteredAtendimentos = atendimentos.filter(atendimento => {
    const matchesSearch = 
      atendimento.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      atendimento.nome.toLowerCase().includes(searchQuery.toLowerCase()) ||
      atendimento.produto.toLowerCase().includes(searchQuery.toLowerCase()) ||
      atendimento.descricao.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesTipo = tipoAtendimento === "all" || atendimento.tipo === tipoAtendimento;
    const matchesStatus = statusAtendimento === "all" || atendimento.status === statusAtendimento;
    
    return matchesSearch && matchesTipo && matchesStatus;
  });

  const encaminharFarmacovigilancia = (atendimento) => {
    navigate(createPageUrl("CrmFarmacovigilancia") + "?id=" + atendimento.id);
  };

  const getStatusBadge = (status) => {
    switch(status) {
      case 'pendente':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Pendente</Badge>;
      case 'em_andamento':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Em Andamento</Badge>;
      case 'concluido':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Concluído</Badge>;
      case 'cancelado':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Cancelado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTipoBadge = (tipo) => {
    switch(tipo) {
      case 'reclamacao':
        return <Badge className="bg-red-100 text-red-800">Reclamação</Badge>;
      case 'duvida':
        return <Badge className="bg-blue-100 text-blue-800">Dúvida</Badge>;
      case 'elogio':
        return <Badge className="bg-green-100 text-green-800">Elogio</Badge>;
      case 'sugestao':
        return <Badge className="bg-purple-100 text-purple-800">Sugestão</Badge>;
      case 'reacao_adversa':
        return <Badge className="bg-amber-100 text-amber-800">Reação Adversa</Badge>;
      case 'ineficacia':
        return <Badge className="bg-orange-100 text-orange-800">Ineficácia Terapêutica</Badge>;
      default:
        return <Badge>{tipo}</Badge>;
    }
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">SAC - Serviço de Atendimento ao Cliente</h1>
          <p className="text-gray-500 mt-1">
            Gerenciamento de reclamações, dúvidas, sugestões e casos de farmacovigilância
          </p>
        </div>
        <Button onClick={() => setShowNovoAtendimento(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Novo Atendimento
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filtros</CardTitle>
          <CardDescription>Refine os atendimentos por tipo, status ou busca</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Buscar</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por ID, paciente, produto..."
                  value={searchQuery}
                  onChange={handleSearch}
                  className="pl-8"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Tipo de Atendimento</Label>
              <Select value={tipoAtendimento} onValueChange={(value) => handleSelect('tipo', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os tipos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os tipos</SelectItem>
                  <SelectItem value="reclamacao">Reclamações</SelectItem>
                  <SelectItem value="duvida">Dúvidas</SelectItem>
                  <SelectItem value="elogio">Elogios</SelectItem>
                  <SelectItem value="sugestao">Sugestões</SelectItem>
                  <SelectItem value="reacao_adversa">Reações Adversas</SelectItem>
                  <SelectItem value="ineficacia">Ineficácia Terapêutica</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={statusAtendimento} onValueChange={(value) => handleSelect('status', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="pendente">Pendente</SelectItem>
                  <SelectItem value="em_andamento">Em Andamento</SelectItem>
                  <SelectItem value="concluido">Concluído</SelectItem>
                  <SelectItem value="cancelado">Cancelado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Lista de Atendimentos</CardTitle>
            <Badge>{filteredAtendimentos.length} atendimentos</Badge>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <RefreshCw className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredAtendimentos.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64">
              <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-medium">Nenhum atendimento encontrado</p>
              <p className="text-muted-foreground text-center mt-2">
                Não existem atendimentos que correspondam aos critérios de filtro selecionados.
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Paciente</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Produto/Lote</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAtendimentos.map((atendimento) => (
                    <TableRow key={atendimento.id}>
                      <TableCell className="font-medium">{atendimento.id}</TableCell>
                      <TableCell>{formatDate(atendimento.data)}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{atendimento.nome}</span>
                          <span className="text-xs text-muted-foreground">{atendimento.contato}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getTipoBadge(atendimento.tipo)}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{atendimento.produto}</span>
                          <span className="text-xs text-muted-foreground">Lote: {atendimento.lote}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(atendimento.status)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Ações</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => navigate(createPageUrl("CrmSacDetalhes") + "?id=" + atendimento.id)}>
                              <FileText className="h-4 w-4 mr-2" />
                              Ver Detalhes
                            </DropdownMenuItem>
                            {(atendimento.tipo === 'reacao_adversa' || atendimento.tipo === 'ineficacia') && (
                              <DropdownMenuItem onClick={() => encaminharFarmacovigilancia(atendimento)}>
                                <AlertTriangle className="h-4 w-4 mr-2" />
                                Farmacovigilância
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Send className="h-4 w-4 mr-2" />
                              Enviar Email
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showNovoAtendimento} onOpenChange={setShowNovoAtendimento}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Registrar Novo Atendimento</DialogTitle>
            <DialogDescription>
              Preencha todos os dados do atendimento. Casos de reações adversas ou ineficácia terapêutica serão automaticamente encaminhados para a Farmacovigilância.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmitAtendimento}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="space-y-2">
                <Label htmlFor="nome">Nome do Paciente *</Label>
                <Input 
                  id="nome" 
                  name="nome" 
                  value={novoAtendimento.nome} 
                  onChange={handleInputChange} 
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contato">Telefone *</Label>
                <Input 
                  id="contato" 
                  name="contato" 
                  value={novoAtendimento.contato} 
                  onChange={handleInputChange} 
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  name="email" 
                  type="email" 
                  value={novoAtendimento.email} 
                  onChange={handleInputChange} 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="produto">Produto *</Label>
                <Input 
                  id="produto" 
                  name="produto" 
                  value={novoAtendimento.produto} 
                  onChange={handleInputChange} 
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lote">Lote *</Label>
                <Input 
                  id="lote" 
                  name="lote" 
                  value={novoAtendimento.lote} 
                  onChange={handleInputChange} 
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pedido">Número do Pedido</Label>
                <Input 
                  id="pedido" 
                  name="pedido" 
                  value={novoAtendimento.pedido} 
                  onChange={handleInputChange} 
                />
              </div>
            </div>
            
            <div className="space-y-2 mb-4">
              <Label>Tipo de Atendimento *</Label>
              <RadioGroup 
                value={novoAtendimento.tipo} 
                onValueChange={(value) => handleRadioChange('tipo', value)}
                className="flex flex-col space-y-1"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="reclamacao" id="reclamacao" />
                  <Label htmlFor="reclamacao">Reclamação</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="duvida" id="duvida" />
                  <Label htmlFor="duvida">Dúvida/Informação</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="elogio" id="elogio" />
                  <Label htmlFor="elogio">Elogio</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="sugestao" id="sugestao" />
                  <Label htmlFor="sugestao">Sugestão</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="reacao_adversa" id="reacao_adversa" />
                  <Label htmlFor="reacao_adversa">Reação Adversa</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="ineficacia" id="ineficacia" />
                  <Label htmlFor="ineficacia">Ineficácia Terapêutica</Label>
                </div>
              </RadioGroup>
            </div>
            
            <div className="space-y-2 mb-4">
              <Label>Origem do Contato *</Label>
              <RadioGroup 
                value={novoAtendimento.origem} 
                onValueChange={(value) => handleRadioChange('origem', value)}
                className="flex space-x-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="telefone" id="telefone" />
                  <Label htmlFor="telefone">Telefone</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="email" id="email-origem" />
                  <Label htmlFor="email-origem">Email</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="rede_social" id="rede_social" />
                  <Label htmlFor="rede_social">Rede Social</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="presencial" id="presencial" />
                  <Label htmlFor="presencial">Presencial</Label>
                </div>
              </RadioGroup>
            </div>
            
            <div className="space-y-2 mb-4">
              <Label htmlFor="descricao">Descrição do Atendimento *</Label>
              <Textarea 
                id="descricao" 
                name="descricao" 
                value={novoAtendimento.descricao} 
                onChange={handleInputChange} 
                required 
                rows={5}
                placeholder="Descreva detalhadamente o relato do paciente..."
              />
            </div>
            
            {(novoAtendimento.tipo === 'reacao_adversa' || novoAtendimento.tipo === 'ineficacia') && (
              <div className="bg-amber-50 p-4 rounded-md border border-amber-200 mb-4">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-amber-800">Caso de Farmacovigilância</h4>
                    <p className="text-sm text-amber-700 mt-1">
                      Este atendimento será automaticamente encaminhado para o setor de Farmacovigilância para análise e notificação à ANVISA, se necessário.
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setShowNovoAtendimento(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : null}
                Registrar Atendimento
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}