
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  AlertTriangle, 
  AlertCircle, 
  ShieldAlert, 
  Lock, 
  Mail, 
  Send, 
  Clock, 
  Check, 
  CheckCircle2, 
  Fingerprint,
  PanelLeft,
  Ban,
  Undo,
  HardDrive,
  Globe,
  Server,
  Database,
  Bell,
  PhoneCall,
  Plus
} from "lucide-react";

// Emergency contacts data
const emergencyContactsData = [
  { 
    id: 1, 
    name: 'João Silva', 
    role: 'CTO', 
    email: 'joao.silva@endurancy.com', 
    phone: '+55 11 98765-4321', 
    isActive: true 
  },
  { 
    id: 2, 
    name: 'Maria Oliveira', 
    role: 'CISO', 
    email: 'maria@endurancy.com', 
    phone: '+55 11 91234-5678', 
    isActive: true 
  },
  { 
    id: 3, 
    name: 'Carlos Santos', 
    role: 'SRE Lead', 
    email: 'carlos@endurancy.com', 
    phone: '+55 11 97654-3210', 
    isActive: true 
  },
  { 
    id: 4,
    name: 'Ana Costa',
    role: 'Security Engineer',
    email: 'ana@endurancy.com',
    phone: '+55 11 98877-6655',
    isActive: false
  }
];

const emergencyActionsData = [
  { 
    id: 'lockdown', 
    name: 'Bloqueio Total do Sistema', 
    description: 'Ativa o modo de manutenção para todos os usuários e impede qualquer operação', 
    severity: 'critical',
    icon: <Lock className="w-5 h-5" />,
    status: 'available',
    requiresConfirmation: true,
    additionalInfo: 'Apenas usuários Super Admin poderão acessar o sistema após esta ação'
  },
  { 
    id: 'readonly', 
    name: 'Modo Somente Leitura', 
    description: 'Coloca todo o sistema em modo somente leitura para prevenir modificações', 
    severity: 'high',
    icon: <Ban className="w-5 h-5" />,
    status: 'available',
    requiresConfirmation: true,
    additionalInfo: 'Todas as operações de escrita serão bloqueadas, incluindo uploads e modificações'
  },
  { 
    id: 'restore_backup', 
    name: 'Restaurar Último Backup', 
    description: 'Restaura o sistema para o último ponto de backup válido', 
    severity: 'high',
    icon: <Undo className="w-5 h-5" />,
    status: 'available',
    requiresConfirmation: true,
    additionalInfo: 'Esta operação substituirá todos os dados atuais pelos dados do backup'
  },
  { 
    id: 'notify_all', 
    name: 'Notificar Todos Usuários', 
    description: 'Envia notificação de emergência para todos os usuários', 
    severity: 'medium',
    icon: <Bell className="w-5 h-5" />,
    status: 'available',
    requiresConfirmation: false,
    additionalInfo: 'A mensagem será enviada como alerta prioritário para todos os usuários logados'
  },
  { 
    id: 'disable_api', 
    name: 'Desativar APIs Externas', 
    description: 'Desativa temporariamente todas as APIs e integrações externas', 
    severity: 'medium',
    icon: <Globe className="w-5 h-5" />,
    status: 'available',
    requiresConfirmation: true,
    additionalInfo: 'Todas as integrações e webhooks serão suspensos até reativação'
  }
];

const systemStatusData = {
  database: { status: 'operational', latency: 15, uptime: 99.99 },
  application: { status: 'operational', latency: 120, uptime: 99.98 },
  storage: { status: 'degraded', latency: 350, uptime: 99.5 },
  security: { status: 'operational', latency: 80, uptime: 100 }
};

export default function Emergencies() {
  const [emergencyContacts, setEmergencyContacts] = useState(emergencyContactsData);
  const [emergencyActions, setEmergencyActions] = useState(emergencyActionsData);
  const [systemStatus, setSystemStatus] = useState(systemStatusData);
  const [lockdownEnabled, setLockdownEnabled] = useState(false);
  const [showContactDialog, setShowContactDialog] = useState(false);
  const [showActionDialog, setShowActionDialog] = useState(false);
  const [currentContact, setCurrentContact] = useState(null);
  const [currentAction, setCurrentAction] = useState(null);
  const [confirmText, setConfirmText] = useState('');
  const [notificationMessage, setNotificationMessage] = useState('');
  
  const handleAddContact = () => {
    setCurrentContact({
      id: null,
      name: '',
      role: '',
      email: '',
      phone: '',
      isActive: true
    });
    setShowContactDialog(true);
  };
  
  const handleEditContact = (contact) => {
    setCurrentContact({...contact});
    setShowContactDialog(true);
  };
  
  const handleSaveContact = () => {
    if (currentContact.id) {
      // Update existing contact
      setEmergencyContacts(emergencyContacts.map(c => 
        c.id === currentContact.id ? currentContact : c
      ));
    } else {
      // Add new contact
      setEmergencyContacts([...emergencyContacts, {
        ...currentContact,
        id: Math.max(0, ...emergencyContacts.map(c => c.id)) + 1
      }]);
    }
    setShowContactDialog(false);
  };
  
  const handleExecuteAction = (action) => {
    setCurrentAction(action);
    setConfirmText('');
    setShowActionDialog(true);
  };
  
  const handleConfirmAction = () => {
    // Simulate action execution
    setTimeout(() => {
      if (currentAction.id === 'lockdown') {
        setLockdownEnabled(true);
      }
      // Update action status to show it was executed
      setEmergencyActions(emergencyActions.map(a => 
        a.id === currentAction.id 
          ? {...a, status: 'executed', lastExecuted: new Date().toISOString()} 
          : a
      ));
      setShowActionDialog(false);
    }, 1000);
  };
  
  const handleSendNotification = () => {
    if (!notificationMessage.trim()) return;
    
    // Simulate sending notification
    setTimeout(() => {
      alert(`Notificação enviada: ${notificationMessage}`);
      setNotificationMessage('');
    }, 1000);
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'operational':
        return 'bg-green-500';
      case 'degraded':
        return 'bg-yellow-500';
      case 'critical':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };
  
  const getActionSeverityColor = (severity) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Centro de Emergências</h1>
          <p className="text-gray-500 mt-1">
            Ações de emergência e controle de incidentes do sistema
          </p>
        </div>
      </div>

      {lockdownEnabled && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Atenção: Sistema em Bloqueio de Segurança</AlertTitle>
          <AlertDescription>
            O sistema está atualmente em modo de bloqueio. Todas as operações estão restritas.
            <Button 
              variant="outline" 
              size="sm"
              className="mt-2 ml-2 border-red-800 text-red-800"
              onClick={() => setLockdownEnabled(false)}
            >
              Desativar Bloqueio
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Ações de Emergência</CardTitle>
              <CardDescription>
                Procedimentos para lidar com situações críticas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {emergencyActions.map(action => (
                <div 
                  key={action.id} 
                  className="p-4 border rounded-lg flex flex-col md:flex-row justify-between gap-4"
                >
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded-full ${getActionSeverityColor(action.severity)}`}>
                        {action.icon}
                      </div>
                      <div>
                        <h3 className="font-medium">{action.name}</h3>
                        <Badge className={getActionSeverityColor(action.severity)}>
                          {action.severity === 'critical' && 'Crítico'}
                          {action.severity === 'high' && 'Alto'}
                          {action.severity === 'medium' && 'Médio'}
                          {action.severity === 'low' && 'Baixo'}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-gray-600">{action.description}</p>
                    {action.lastExecuted && (
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <Clock className="w-3 h-3" />
                        <span>Última execução: {new Date(action.lastExecuted).toLocaleString()}</span>
                      </div>
                    )}
                  </div>
                  <div className="mt-2 md:mt-0">
                    <Button 
                      variant={action.severity === 'critical' ? 'destructive' : 'default'}
                      onClick={() => handleExecuteAction(action)}
                    >
                      {action.severity === 'critical' ? 'Executar com Cautela' : 'Executar'}
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Notificação de Emergência</CardTitle>
              <CardDescription>
                Enviar mensagem para todos os administradores e contatos de emergência
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Textarea 
                  placeholder="Digite a mensagem de emergência..."
                  rows={4}
                  value={notificationMessage}
                  onChange={(e) => setNotificationMessage(e.target.value)}
                />
                <div className="flex items-center gap-3">
                  <Button 
                    className="gap-2"
                    onClick={handleSendNotification}
                    disabled={!notificationMessage.trim()}
                  >
                    <Send className="w-4 h-4" />
                    Enviar Notificação
                  </Button>
                  <div className="flex items-center space-x-2">
                    <Switch id="email-notification" />
                    <Label htmlFor="email-notification">Enviar por email</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="sms-notification" />
                    <Label htmlFor="sms-notification">Enviar por SMS</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Status do Sistema</CardTitle>
                <Button variant="outline" size="sm" className="gap-1 h-8">
                  <PanelLeft className="w-4 h-4" />
                  Detalhes
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-gray-500" />
                    <span className="font-medium">Banco de Dados</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`h-2 w-2 rounded-full ${getStatusColor(systemStatus.database.status)}`}></div>
                    <span className="text-sm">
                      {systemStatus.database.status === 'operational' ? 'Operacional' : 
                       systemStatus.database.status === 'degraded' ? 'Degradado' : 'Crítico'}
                    </span>
                  </div>
                </div>
                <div className="text-sm flex justify-between">
                  <span>Latência: {systemStatus.database.latency}ms</span>
                  <span>Uptime: {systemStatus.database.uptime}%</span>
                </div>
                <Progress value={systemStatus.database.uptime} className="h-1" />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Server className="w-4 h-4 text-gray-500" />
                    <span className="font-medium">Aplicação</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`h-2 w-2 rounded-full ${getStatusColor(systemStatus.application.status)}`}></div>
                    <span className="text-sm">
                      {systemStatus.application.status === 'operational' ? 'Operacional' : 
                       systemStatus.application.status === 'degraded' ? 'Degradado' : 'Crítico'}
                    </span>
                  </div>
                </div>
                <div className="text-sm flex justify-between">
                  <span>Latência: {systemStatus.application.latency}ms</span>
                  <span>Uptime: {systemStatus.application.uptime}%</span>
                </div>
                <Progress value={systemStatus.application.uptime} className="h-1" />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-gray-500" />
                    <span className="font-medium">Armazenamento</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`h-2 w-2 rounded-full ${getStatusColor(systemStatus.storage.status)}`}></div>
                    <span className="text-sm">
                      {systemStatus.storage.status === 'operational' ? 'Operacional' : 
                       systemStatus.storage.status === 'degraded' ? 'Degradado' : 'Crítico'}
                    </span>
                  </div>
                </div>
                <div className="text-sm flex justify-between">
                  <span>Latência: {systemStatus.storage.latency}ms</span>
                  <span>Uptime: {systemStatus.storage.uptime}%</span>
                </div>
                <Progress value={systemStatus.storage.uptime} className="h-1" />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-gray-500" />
                    <span className="font-medium">Segurança</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`h-2 w-2 rounded-full ${getStatusColor(systemStatus.security.status)}`}></div>
                    <span className="text-sm">
                      {systemStatus.security.status === 'operational' ? 'Operacional' : 
                       systemStatus.security.status === 'degraded' ? 'Degradado' : 'Crítico'}
                    </span>
                  </div>
                </div>
                <div className="text-sm flex justify-between">
                  <span>Integridade: 100%</span>
                  <span>Ataques: 0</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Contatos de Emergência</CardTitle>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="gap-1 h-8"
                  onClick={handleAddContact}
                >
                  <Plus className="w-4 h-4" />
                  Adicionar
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {emergencyContacts.map(contact => (
                  <div 
                    key={contact.id} 
                    className={`p-3 border rounded-lg flex items-center justify-between ${!contact.isActive && 'opacity-60'}`}
                  >
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback>
                          {contact.name.split(' ').map(name => name[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-medium">{contact.name}</h3>
                        <p className="text-sm text-gray-500">{contact.role}</p>
                        <div className="flex items-center gap-4 mt-1">
                          <div className="flex items-center gap-1 text-xs">
                            <Mail className="w-3 h-3 text-gray-400" />
                            <span>{contact.email}</span>
                          </div>
                          <div className="flex items-center gap-1 text-xs">
                            <PhoneCall className="w-3 h-3 text-gray-400" />
                            <span>{contact.phone}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEditContact(contact)}
                    >
                      Editar
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Contact Edit Dialog */}
      <Dialog open={showContactDialog} onOpenChange={setShowContactDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{currentContact?.id ? 'Editar Contato' : 'Adicionar Contato'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome</Label>
              <Input
                id="name"
                value={currentContact?.name || ''}
                onChange={(e) => setCurrentContact({...currentContact, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">Cargo</Label>
              <Input
                id="role"
                value={currentContact?.role || ''}
                onChange={(e) => setCurrentContact({...currentContact, role: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={currentContact?.email || ''}
                onChange={(e) => setCurrentContact({...currentContact, email: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                value={currentContact?.phone || ''}
                onChange={(e) => setCurrentContact({...currentContact, phone: e.target.value})}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch 
                id="active"
                checked={currentContact?.isActive || false}
                onCheckedChange={(checked) => setCurrentContact({...currentContact, isActive: checked})}
              />
              <Label htmlFor="active">Contato Ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowContactDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveContact}>
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Action Confirmation Dialog */}
      <Dialog open={showActionDialog} onOpenChange={setShowActionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-yellow-500" />
              Confirmar Ação de Emergência
            </DialogTitle>
            <DialogDescription>
              Você está prestes a executar uma ação de emergência que pode afetar o sistema
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="p-4 border rounded-lg mb-4">
              <h3 className="font-medium mb-1">{currentAction?.name}</h3>
              <p className="text-sm text-gray-600">{currentAction?.description}</p>
              {currentAction?.additionalInfo && (
                <Alert className="mt-3">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    {currentAction.additionalInfo}
                  </AlertDescription>
                </Alert>
              )}
            </div>
            
            {currentAction?.requiresConfirmation && (
              <div className="space-y-2">
                <Label htmlFor="confirm-text">
                  Digite "CONFIRMAR" para continuar:
                </Label>
                <Input
                  id="confirm-text"
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value)}
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowActionDialog(false)}>
              Cancelar
            </Button>
            <Button 
              variant="destructive"
              onClick={handleConfirmAction}
              disabled={currentAction?.requiresConfirmation && confirmText !== "CONFIRMAR"}
            >
              Executar Ação
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
