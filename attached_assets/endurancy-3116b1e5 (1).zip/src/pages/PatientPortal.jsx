import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from 'react-router-dom';
import { User } from '@/api/entities';
import { toast } from '@/components/ui/use-toast';
import { AlertCircle, Heart, TabletSmartphone } from 'lucide-react';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

export default function PatientPortal() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [patientCode, setPatientCode] = useState('');
  const [loginMethod, setLoginMethod] = useState('email');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLoginWithEmail = async (e) => {
    e.preventDefault();
    
    if (!email || !password) {
      setError('Por favor, preencha todos os campos');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      // Para fins de demonstração, vamos usar credenciais mockadas
      // Em produção, isso seria substituído por uma chamada real de autenticação
      
      if (email === 'paciente@endurancy.com' && password === 'paciente123') {
        // Login bem-sucedido
        localStorage.setItem('mockUserType', 'patient');
        localStorage.setItem('mockUserEmail', email);
        localStorage.setItem('mockUserName', 'Ana Silva');
        localStorage.setItem('mockNeedsOrg', 'true'); // Flag para indicar que o usuário precisa selecionar uma organização
        
        toast({
          title: "Login realizado com sucesso",
          description: "Bem-vindo ao portal do paciente Endurancy",
        });
        
        // Forçar redirecionamento para a dashboard do paciente
        window.location.href = window.location.origin + createPageUrl("PatientDashboard");
      } else {
        throw new Error('Credenciais inválidas');
      }
    } catch (error) {
      console.error("Login error:", error);
      setError('Email ou senha incorretos. Por favor, tente novamente.');
      
      toast({
        variant: "destructive",
        title: "Erro no login",
        description: "Credenciais inválidas. Tente novamente.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoginWithCode = async (e) => {
    e.preventDefault();
    
    if (!patientCode) {
      setError('Por favor, preencha o código do paciente');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      // Para fins de demonstração, vamos usar um código mockado
      // Em produção, isso seria validado no backend
      
      if (patientCode === '123456') {
        // Login bem-sucedido
        localStorage.setItem('mockUserType', 'patient');
        localStorage.setItem('mockUserEmail', 'paciente@endurancy.com');
        localStorage.setItem('mockUserName', 'Ana Silva');
        localStorage.setItem('mockNeedsOrg', 'true'); // Flag para indicar que o usuário precisa selecionar uma organização
        
        toast({
          title: "Login realizado com sucesso",
          description: "Bem-vindo ao portal do paciente Endurancy",
        });
        
        // Forçar redirecionamento para a dashboard do paciente
        window.location.href = window.location.origin + createPageUrl("PatientDashboard");
      } else {
        throw new Error('Código inválido');
      }
    } catch (error) {
      console.error("Login error:", error);
      setError('Código de paciente inválido. Por favor, tente novamente.');
      
      toast({
        variant: "destructive",
        title: "Erro no login",
        description: "Código inválido. Tente novamente.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-green-50 to-blue-50">
      <header className="bg-white shadow-sm p-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link to={createPageUrl("Index")} className="flex items-center gap-2">
            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
              <span className="text-green-600 font-bold text-xl">E</span>
            </div>
            <span className="font-semibold text-xl">Endurancy</span>
          </Link>
          <div className="flex space-x-4">
            <Link to={createPageUrl("Access")} className="text-green-600 hover:text-green-800">
              Portal Administrativo
            </Link>
            <Link to={createPageUrl("DoctorPortal")} className="text-green-600 hover:text-green-800">
              Portal do Médico
            </Link>
          </div>
        </div>
      </header>

      <div className="flex-1 flex flex-col justify-center items-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center pb-2">
            <div className="mx-auto bg-green-100 w-16 h-16 flex items-center justify-center rounded-full mb-4">
              <Heart className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl font-bold">Portal do Paciente</CardTitle>
            <CardDescription>
              Acesse seu portal para acompanhar seu tratamento
            </CardDescription>
          </CardHeader>
          
          <CardContent className="pt-6">
            <Tabs defaultValue="email" onValueChange={setLoginMethod}>
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="email">Acessar com Email</TabsTrigger>
                <TabsTrigger value="code">Acessar com Código</TabsTrigger>
              </TabsList>
              
              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <TabsContent value="email">
                <form onSubmit={handleLoginWithEmail} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      placeholder="seu@email.com" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="password">Senha</Label>
                    <Input 
                      id="password" 
                      type="password" 
                      placeholder="••••••••" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-green-600 hover:bg-green-700"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Entrando...' : 'Entrar'}
                  </Button>
                  
                  <div className="text-center mt-2">
                    <Link to="#" className="text-sm text-green-600 hover:text-green-700">
                      Esqueceu sua senha?
                    </Link>
                  </div>
                </form>
              </TabsContent>
              
              <TabsContent value="code">
                <form onSubmit={handleLoginWithCode} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="patientCode">Código do Paciente</Label>
                    <Input 
                      id="patientCode" 
                      type="text" 
                      placeholder="Insira seu código de paciente" 
                      value={patientCode}
                      onChange={(e) => setPatientCode(e.target.value)}
                      required
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-green-600 hover:bg-green-700"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Entrando...' : 'Entrar com Código'}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
          
          <CardFooter className="flex flex-col space-y-4 pt-2">
            <div className="w-full text-center text-sm text-gray-500">
              <span>Novo paciente? </span>
              <Link to="#" className="text-green-600 hover:text-green-700 font-medium">
                Clique aqui para se registrar
              </Link>
            </div>
            
            <div className="w-full text-center">
              <Button variant="outline" className="text-sm flex items-center gap-2">
                <TabletSmartphone className="h-4 w-4" />
                Baixar aplicativo para celular
              </Button>
            </div>
          </CardFooter>
        </Card>
        
        <p className="mt-8 text-center text-sm text-gray-500">
          Para demonstração, use:
          <br/>
          Email: paciente@endurancy.com | Senha: paciente123
          <br/>
          ou Código: 123456
        </p>
      </div>
    </div>
  );
}