import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Headphones, 
  Search, 
  Plus, 
  Filter, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  Calendar, 
  User, 
  MessageSquare, 
  MoreHorizontal,
  Phone,
  Mail,
  History,
  Heart,
  ChevronDown,
  ArrowUpDown,
  Eye,
  RefreshCw,
  Archive,
  Send,
  UserPlus,
  ListFilter,
  UserCheck
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";

// Dados simulados para atendimentos
const mockTickets = [
  {
    id: "ticket001",
    numero: "AT-2023-0156",
    paciente: {
      id: "pac001",
      nome: "Maria Silva Oliveira",
      cpf: "123.456.789-00",
      telefone: "(11) 98765-4321",
      email: "maria.silva@email.com"
    },
    assunto: "Dúvida sobre posologia",
    status: "aberto",
    prioridade: "média",
    tipo: "suporte",
    data_abertura: "2023-07-15T14:30:00Z",
    ultima_atualizacao: "2023-07-15T16:30:00Z",
    atribuido_para: "Ana Costa",
    mensagens: [
      {
        id: "msg001",
        remetente: "Maria Silva Oliveira",
        remetente_tipo: "paciente",
        conteudo: "Olá, estou com dúvida sobre a posologia do Óleo CBD 5%. Posso aumentar a dosagem para 10 gotas?",
        data: "2023-07-15T14:30:00Z"
      },
      {
        id: "msg002",
        remetente: "Ana Costa",
        remetente_tipo: "atendente",
        conteudo: "Olá Maria, entendo sua dúvida. Vou consultar sua prescrição e entrar em contato com seu médico para verificar a possibilidade de ajuste na dosagem. Retorno em breve.",
        data: "2023-07-15T15:15:00Z"
      },
      {
        id: "msg003",
        remetente: "Ana Costa",
        remetente_tipo: "atendente",
        conteudo: "Maria, consultei o Dr. João e ele orientou manter a dosagem atual por mais uma semana e depois aumentar gradualmente até 8 gotas, se necessário. Ele ressaltou a importância de registrar os efeitos.",
        data: "2023-07-15T16:30:00Z"
      }
    ]
  },
  {
    id: "ticket002",
    numero: "AT-2023-0157",
    paciente: {
      id: "pac002",
      nome: "José Pereira Souza",
      cpf: "987.654.321-00",
      telefone: "(11) 97654-3210",
      email: "jose.pereira@email.com"
    },
    assunto: "Atraso na entrega",
    status: "pendente",
    prioridade: "alta",
    tipo: "reclamação",
    data_abertura: "2023-07-14T10:15:00Z",
    ultima_atualizacao: "2023-07-15T11:20:00Z",
    atribuido_para: "Carlos Mendes",
    mensagens: [
      {
        id: "msg004",
        remetente: "José Pereira Souza",
        remetente_tipo: "paciente",
        conteudo: "Bom dia, minha encomenda (pedido #5432) deveria ter sido entregue ontem, mas até agora não chegou. Preciso urgente da medicação.",
        data: "2023-07-14T10:15:00Z"
      },
      {
        id: "msg005",
        remetente: "Carlos Mendes",
        remetente_tipo: "atendente",
        conteudo: "Bom dia Sr. José, lamento pelo ocorrido. Estou verificando com o setor de logística o status da sua entrega. Retorno em breve com mais informações.",
        data: "2023-07-14T10:45:00Z"
      },
      {
        id: "msg006",
        remetente: "Carlos Mendes",
        remetente_tipo: "atendente",
        conteudo: "Sr. José, identifiquei que houve um problema com a transportadora. Consegui priorizar sua entrega para hoje até às 18h. Enviei os contatos do entregador por SMS. Acompanharemos a entrega até a conclusão.",
        data: "2023-07-14T11:20:00Z"
      }
    ]
  },
  {
    id: "ticket003",
    numero: "AT-2023-0158",
    paciente: {
      id: "pac003",
      nome: "Antônio Carlos Ferreira",
      cpf: "456.789.123-00",
      telefone: "(11) 96543-2109",
      email: "antonio.ferreira@email.com"
    },
    assunto: "Renovação de prescrição",
    status: "resolvido",
    prioridade: "média",
    tipo: "solicitação",
    data_abertura: "2023-07-10T09:00:00Z",
    ultima_atualizacao: "2023-07-12T14:30:00Z",
    data_resolucao: "2023-07-12T14:30:00Z",
    atribuido_para: "Ana Costa",
    mensagens: [
      {
        id: "msg007",
        remetente: "Antônio Carlos Ferreira",
        remetente_tipo: "paciente",
        conteudo: "Preciso renovar minha prescrição que vence na próxima semana. Como devo proceder?",
        data: "2023-07-10T09:00:00Z"
      },
      {
        id: "msg008",
        remetente: "Ana Costa",
        remetente_tipo: "atendente",
        conteudo: "Bom dia Sr. Antônio, para renovar sua prescrição é necessário agendar uma consulta de acompanhamento com o Dr. Roberto. Posso verificar a agenda dele e sugerir horários disponíveis. O senhor tem preferência de dia/horário?",
        data: "2023-07-10T09:30:00Z"
      },
      {
        id: "msg009",
        remetente: "Antônio Carlos Ferreira",
        remetente_tipo: "paciente",
        conteudo: "Prefiro pela manhã, se possível nas segundas ou quartas.",
        data: "2023-07-10T10:15:00Z"
      },
      {
        id: "msg010",
        remetente: "Ana Costa",
        remetente_tipo: "atendente",
        conteudo: "Sr. Antônio, consegui um horário para quarta-feira (12/07) às 9h. Confirma esse agendamento?",
        data: "2023-07-10T11:00:00Z"
      },
      {
        id: "msg011",
        remetente: "Antônio Carlos Ferreira",
        remetente_tipo: "paciente",
        conteudo: "Confirmado. Obrigado pela atenção.",
        data: "2023-07-10T11:15:00Z"
      },
      {
        id: "msg012",
        remetente: "Ana Costa",
        remetente_tipo: "atendente",
        conteudo: "Sr. Antônio, sua consulta foi realizada com sucesso e sua prescrição já foi renovada. O documento está disponível em sua área do paciente. Podemos considerar esta solicitação atendida?",
        data: "2023-07-12T14:00:00Z"
      },
      {
        id: "msg013",
        remetente: "Antônio Carlos Ferreira",
        remetente_tipo: "paciente",
        conteudo: "Sim, muito obrigado pela ajuda!",
        data: "2023-07-12T14:20:00Z"
      }
    ]
  },
  {
    id: "ticket004",
    numero: "AT-2023-0159",
    paciente: {
      id: "pac004",
      nome: "Camila Rodrigues Lima",
      cpf: "123.789.456-00",
      telefone: "(11) 95432-1098",
      email: "camila.lima@email.com"
    },
    assunto: "Efeitos colaterais",
    status: "aguardando_resposta",
    prioridade: "alta",
    tipo: "suporte",
    data_abertura: "2023-07-15T10:00:00Z",
    ultima_atualizacao: "2023-07-15T11:30:00Z",
    atribuido_para: "Pedro Santos",
    mensagens: [
      {
        id: "msg014",
        remetente: "Camila Rodrigues Lima",
        remetente_tipo: "paciente",
        conteudo: "Comecei a usar o óleo CBD ontem e estou sentindo tontura e sonolência. Isso é normal? Devo continuar?",
        data: "2023-07-15T10:00:00Z"
      },
      {
        id: "msg015",
        remetente: "Pedro Santos",
        remetente_tipo: "atendente",
        conteudo: "Olá Camila, alguns pacientes podem apresentar esses efeitos inicialmente. Vou consultar sua ficha e falar com o Dr. Paulo sobre seu caso. Enquanto isso, poderia me informar em qual horário está tomando a medicação e se está tomando junto com alimentos?",
        data: "2023-07-15T10:30:00Z"
      }
    ]
  },
  {
    id: "ticket005",
    numero: "AT-2023-0155",
    paciente: {
      id: "pac005",
      nome: "Roberto Alves da Silva",
      cpf: "321.456.789-00",
      telefone: "(11) 94321-0987",
      email: "roberto.alves@email.com"
    },
    assunto: "Agendamento de consulta",
    status: "resolvido",
    prioridade: "baixa",
    tipo: "solicitação",
    data_abertura: "2023-07-08T14:00:00Z",
    ultima_atualizacao: "2023-07-09T10:30:00Z",
    data_resolucao: "2023-07-09T10:30:00Z",
    atribuido_para: "Ana Costa",
    mensagens: [
      {
        id: "msg016",
        remetente: "Roberto Alves da Silva",
        remetente_tipo: "paciente",
        conteudo: "Gostaria de agendar uma consulta com a Dra. Ana Paula para a próxima semana.",
        data: "2023-07-08T14:00:00Z"
      },
      {
        id: "msg017",
        remetente: "Ana Costa",
        remetente_tipo: "atendente",
        conteudo: "Olá Roberto, verificarei a agenda da Dra. Ana Paula. Você tem preferência de dia e horário?",
        data: "2023-07-08T14:30:00Z"
      },
      {
        id: "msg018",
        remetente: "Roberto Alves da Silva",
        remetente_tipo: "paciente",
        conteudo: "Prefiro no período da tarde, de segunda a quinta.",
        data: "2023-07-08T15:00:00Z"
      },
      {
        id: "msg019",
        remetente: "Ana Costa",
        remetente_tipo: "atendente",
        conteudo: "Roberto, a Dra. Ana Paula tem disponibilidade na terça-feira (11/07) às 15h. Esse horário serve para você?",
        data: "2023-07-09T09:30:00Z"
      },
      {
        id: "msg020",
        remetente: "Roberto Alves da Silva",
        remetente_tipo: "paciente",
        conteudo: "Perfeito! Confirmo o agendamento. Obrigado!",
        data: "2023-07-09T10:00:00Z"
      },
      {
        id: "msg021",
        remetente: "Ana Costa",
        remetente_tipo: "atendente",
        conteudo: "Agendamento confirmado para terça-feira (11/07) às 15h com a Dra. Ana Paula. Enviei um e-mail com todas as informações e lembretes. Mais alguma dúvida?",
        data: "2023-07-09T10:15:00Z"
      },
      {
        id: "msg022",
        remetente: "Roberto Alves da Silva",
        remetente_tipo: "paciente",
        conteudo: "Não, está tudo certo. Obrigado pela atenção!",
        data: "2023-07-09T10:30:00Z"
      }
    ]
  }
];

export default function CrmAtendimento() {
  const navigate = useNavigate();
  const [tickets, setTickets] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [showTicketDialog, setShowTicketDialog] = useState(false);
  const [replyMessage, setReplyMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [showNewTicketDialog, setShowNewTicketDialog] = useState(false);
  
  useEffect(() => {
    loadTickets();
  }, []);
  
  const loadTickets = async () => {
    setIsLoading(true);
    try {
      // Simular busca dos atendimentos da API
      await new Promise(resolve => setTimeout(resolve, 1000));
      setTickets(mockTickets);
    } catch (error) {
      console.error("Erro ao carregar atendimentos:", error);
      toast({
        variant: "destructive",
        title: "Erro ao carregar atendimentos",
        description: "Não foi possível obter os atendimentos no momento.",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };
  
  const handleViewTicket = (ticket) => {
    setSelectedTicket(ticket);
    setShowTicketDialog(true);
  };
  
  const handleSendReply = async () => {
    if (!replyMessage.trim()) {
      toast({
        variant: "destructive",
        title: "Mensagem vazia",
        description: "Por favor, digite uma mensagem para enviar.",
      });
      return;
    }
    
    setIsSending(true);
    
    try {
      // Simulação de envio da resposta
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Criar nova mensagem
      const newMessage = {
        id: `msg${Date.now()}`,
        remetente: "Ana Costa", // Usuário atual simulado
        remetente_tipo: "atendente",
        conteudo: replyMessage,
        data: new Date().toISOString()
      };
      
      // Atualizar o ticket selecionado com a nova mensagem
      const updatedTicket = {
        ...selectedTicket,
        mensagens: [...selectedTicket.mensagens, newMessage],
        ultima_atualizacao: new Date().toISOString(),
        status: "aguardando_resposta"
      };
      
      // Atualizar a lista de tickets
      const updatedTickets = tickets.map(t => 
        t.id === selectedTicket.id ? updatedTicket : t
      );
      
      setSelectedTicket(updatedTicket);
      setTickets(updatedTickets);
      setReplyMessage("");
      
      toast({
        title: "Resposta enviada",
        description: "Sua mensagem foi enviada com sucesso.",
      });
    } catch (error) {
      console.error("Erro ao enviar resposta:", error);
      toast({
        variant: "destructive",
        title: "Erro ao enviar resposta",
        description: "Não foi possível enviar sua resposta. Tente novamente.",
      });
    } finally {
      setIsSending(false);
    }
  };
  
  const handleCloseTicket = async () => {
    try {
      // Simulação de fechamento do ticket
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Atualizar o ticket selecionado
      const updatedTicket = {
        ...selectedTicket,
        status: "resolvido",
        data_resolucao: new Date().toISOString(),
        ultima_atualizacao: new Date().toISOString()
      };
      
      // Atualizar a lista de tickets
      const updatedTickets = tickets.map(t => 
        t.id === selectedTicket.id ? updatedTicket : t
      );
      
      setSelectedTicket(updatedTicket);
      setTickets(updatedTickets);
      
      toast({
        title: "Atendimento fechado",
        description: "O atendimento foi marcado como resolvido.",
      });
    } catch (error) {
      console.error("Erro ao fechar atendimento:", error);
      toast({
        variant: "destructive",
        title: "Erro ao fechar atendimento",
        description: "Não foi possível fechar o atendimento. Tente novamente.",
      });
    }
  };
  
  const formatDateTime = (dateTimeString) => {
    const date = new Date(dateTimeString);
    return date.toLocaleString('pt-BR');
  };
  
  const getStatusBadge = (status) => {
    switch (status) {
      case "aberto":
        return (
          <Badge className="bg-blue-100 text-blue-800 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Aberto
          </Badge>
        );
      case "pendente":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Pendente
          </Badge>
        );
      case "aguardando_resposta":
        return (
          <Badge className="bg-purple-100 text-purple-800 flex items-center gap-1">
            <RefreshCw className="w-3 h-3" />
            Aguardando Resposta
          </Badge>
        );
      case "resolvido":
        return (
          <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" />
            Resolvido
          </Badge>
        );
      case "cancelado":
        return (
          <Badge className="bg-red-100 text-red-800 flex items-center gap-1">
            <XCircle className="w-3 h-3" />
            Cancelado
          </Badge>
        );
      default:
        return (
          <Badge className="bg-gray-100 text-gray-800">
            {status}
          </Badge>
        );
    }
  };
  
  const getPriorityBadge = (priority) => {
    switch (priority) {
      case "baixa":
        return <Badge className="bg-blue-100 text-blue-800">Baixa</Badge>;
      case "média":
        return <Badge className="bg-yellow-100 text-yellow-800">Média</Badge>;
      case "alta":
        return <Badge className="bg-red-100 text-red-800">Alta</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{priority}</Badge>;
    }
  };
  
  const filteredTickets = tickets.filter(ticket => {
    // Filtro por status
    if (statusFilter !== "all" && ticket.status !== statusFilter) {
      return false;
    }
    
    // Filtro por prioridade
    if (priorityFilter !== "all" && ticket.prioridade !== priorityFilter) {
      return false;
    }
    
    // Filtro por tipo
    if (typeFilter !== "all" && ticket.tipo !== typeFilter) {
      return false;
    }
    
    // Filtro por termo de busca
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      return (
        ticket.numero.toLowerCase().includes(searchLower) ||
        ticket.paciente.nome.toLowerCase().includes(searchLower) ||
        ticket.paciente.cpf.toLowerCase().includes(searchLower) ||
        ticket.assunto.toLowerCase().includes(searchLower)
      );
    }
    
    return true;
  });
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Atendimento ao Paciente</h1>
          <p className="text-gray-500 mt-1">
            Gerencie e acompanhe os atendimentos aos pacientes
          </p>
        </div>
        <Button onClick={() => setShowNewTicketDialog(true)} className="gap-2">
          <Plus className="w-4 h-4" />
          Novo Atendimento
        </Button>
      </div>
      
      {/* Filtros e busca */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar atendimentos..."
            className="pl-10"
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>
        
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full md:w-[180px]">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <SelectValue placeholder="Status" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os status</SelectItem>
            <SelectItem value="aberto">Abertos</SelectItem>
            <SelectItem value="pendente">Pendentes</SelectItem>
            <SelectItem value="aguardando_resposta">Aguardando Resposta</SelectItem>
            <SelectItem value="resolvido">Resolvidos</SelectItem>
            <SelectItem value="cancelado">Cancelados</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-full md:w-[180px]">
            <div className="flex items-center gap-2">
              <ListFilter className="w-4 h-4" />
              <SelectValue placeholder="Prioridade" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as prioridades</SelectItem>
            <SelectItem value="baixa">Baixa</SelectItem>
            <SelectItem value="média">Média</SelectItem>
            <SelectItem value="alta">Alta</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-full md:w-[180px]">
            <div className="flex items-center gap-2">
              <ListFilter className="w-4 h-4" />
              <SelectValue placeholder="Tipo" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os tipos</SelectItem>
            <SelectItem value="suporte">Suporte</SelectItem>
            <SelectItem value="reclamação">Reclamação</SelectItem>
            <SelectItem value="solicitação">Solicitação</SelectItem>
            <SelectItem value="informação">Informação</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {/* Tabela de atendimentos */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="py-32 flex justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
            </div>
          ) : filteredTickets.length === 0 ? (
            <div className="py-20 text-center">
              <Headphones className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-900">Nenhum atendimento encontrado</h3>
              <p className="text-gray-500 mt-1 max-w-md mx-auto">
                {searchTerm 
                  ? `Não encontramos atendimentos correspondentes a "${searchTerm}"`
                  : "Não há atendimentos com os filtros selecionados."}
              </p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => {
                  setSearchTerm("");
                  setStatusFilter("all");
                  setPriorityFilter("all");
                  setTypeFilter("all");
                }}
              >
                Limpar filtros
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[150px]">Número</TableHead>
                    <TableHead>Paciente</TableHead>
                    <TableHead>Assunto</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Prioridade</TableHead>
                    <TableHead>Última Atualização</TableHead>
                    <TableHead>Atribuído Para</TableHead>
                    <TableHead className="text-right"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTickets.map((ticket) => (
                    <TableRow key={ticket.id}>
                      <TableCell className="font-medium">{ticket.numero}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{ticket.paciente.nome}</span>
                          <span className="text-xs text-gray-500">{ticket.paciente.cpf}</span>
                        </div>
                      </TableCell>
                      <TableCell>{ticket.assunto}</TableCell>
                      <TableCell>{getStatusBadge(ticket.status)}</TableCell>
                      <TableCell>{getPriorityBadge(ticket.prioridade)}</TableCell>
                      <TableCell>{formatDateTime(ticket.ultima_atualizacao)}</TableCell>
                      <TableCell>{ticket.atribuido_para}</TableCell>
                      <TableCell className="text-right">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleViewTicket(ticket)}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Visualizar
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Modal de visualização de atendimento */}
      {selectedTicket && (
        <Dialog open={showTicketDialog} onOpenChange={setShowTicketDialog}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Atendimento {selectedTicket.numero}
              </DialogTitle>
              <DialogDescription>
                {selectedTicket.assunto}
              </DialogDescription>
            </DialogHeader>
            
            <div className="flex justify-between items-center py-2">
              {getStatusBadge(selectedTicket.status)}
              {getPriorityBadge(selectedTicket.prioridade)}
              
              <div className="flex items-center gap-1 text-sm text-gray-500">
                <Calendar className="w-4 h-4" />
                <span>Aberto em: {formatDateTime(selectedTicket.data_abertura)}</span>
              </div>
            </div>
            
            <Separator />
            
            {/* Dados do paciente */}
            <div className="mb-4">
              <h3 className="font-medium flex items-center gap-2 mb-2">
                <User className="w-4 h-4 text-gray-500" />
                Dados do Paciente
              </h3>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Avatar>
                      <AvatarFallback className="bg-blue-100 text-blue-800">
                        {selectedTicket.paciente.nome.split(' ').map(n => n[0]).join('').substring(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium">{selectedTicket.paciente.nome}</p>
                      <p className="text-sm text-gray-500">{selectedTicket.paciente.cpf}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="gap-1">
                        <Phone className="w-4 h-4" />
                        Ligar
                      </Button>
                      <Button variant="outline" size="sm" className="gap-1">
                        <Mail className="w-4 h-4" />
                        Email
                      </Button>
                      <Button variant="outline" size="sm" className="gap-1">
                        <History className="w-4 h-4" />
                        Histórico
                      </Button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-gray-500" />
                        {selectedTicket.paciente.telefone}
                      </p>
                    </div>
                    <div>
                      <p className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-gray-500" />
                        {selectedTicket.paciente.email}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Histórico de mensagens */}
            <div className="flex-1 overflow-y-auto mb-4 max-h-[40vh]">
              <h3 className="font-medium flex items-center gap-2 mb-2">
                <MessageSquare className="w-4 h-4 text-gray-500" />
                Histórico de Mensagens
              </h3>
              <div className="space-y-4">
                {selectedTicket.mensagens.map((mensagem) => (
                  <div 
                    key={mensagem.id} 
                    className={`flex gap-3 ${mensagem.remetente_tipo === 'atendente' ? 'justify-end' : ''}`}
                  >
                    {mensagem.remetente_tipo !== 'atendente' && (
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-blue-100 text-blue-800">
                          {mensagem.remetente.split(' ').map(n => n[0]).join('').substring(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                    )}
                    
                    <div className={`max-w-[70%] ${mensagem.remetente_tipo === 'atendente' ? 'items-end' : ''}`}>
                      <div className={`rounded-lg p-3 ${
                        mensagem.remetente_tipo === 'atendente' 
                          ? 'bg-green-100 text-green-900' 
                          : 'bg-gray-100 text-gray-900'
                      }`}>
                        <p>{mensagem.conteudo}</p>
                      </div>
                      <div className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                        <span>{mensagem.remetente}</span>
                        <span>•</span>
                        <span>{formatDateTime(mensagem.data)}</span>
                      </div>
                    </div>
                    
                    {mensagem.remetente_tipo === 'atendente' && (
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-green-100 text-green-800">
                          {mensagem.remetente.split(' ').map(n => n[0]).join('').substring(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            {/* Área de resposta */}
            {selectedTicket.status !== 'resolvido' && selectedTicket.status !== 'cancelado' && (
              <div className="mt-4">
                <Label htmlFor="reply" className="font-medium flex items-center gap-2 mb-2">
                  <Send className="w-4 h-4 text-gray-500" />
                  Responder
                </Label>
                <div className="flex gap-3">
                  <Textarea
                    id="reply"
                    placeholder="Digite sua resposta..."
                    value={replyMessage}
                    onChange={(e) => setReplyMessage(e.target.value)}
                    className="flex-1"
                  />
                </div>
              </div>
            )}
            
            {/* Rodapé */}
            <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:gap-0 mt-4">
              <Button variant="outline" className="gap-2" onClick={() => setShowTicketDialog(false)}>
                Fechar
              </Button>
              
              {selectedTicket.status !== 'resolvido' && selectedTicket.status !== 'cancelado' && (
                <>
                  <Button 
                    variant="outline" 
                    className="gap-2"
                    onClick={handleCloseTicket}
                  >
                    <CheckCircle className="w-4 h-4" />
                    Marcar como Resolvido
                  </Button>
                  
                  <Button 
                    className="gap-2" 
                    onClick={handleSendReply}
                    disabled={isSending || !replyMessage.trim()}
                  >
                    {isSending ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Enviar Resposta
                      </>
                    )}
                  </Button>
                </>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Modal de novo atendimento */}
      <Dialog open={showNewTicketDialog} onOpenChange={setShowNewTicketDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5" />
              Novo Atendimento
            </DialogTitle>
            <DialogDescription>
              Registre um novo atendimento ao paciente
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="patient" className="font-medium">Paciente</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="patient"
                    placeholder="Buscar paciente pelo nome ou CPF..."
                    className="pl-10"
                  />
                </div>
                <Button variant="outline" size="sm" className="gap-1">
                  <UserPlus className="w-4 h-4" />
                  Cadastrar Novo Paciente
                </Button>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="subject" className="font-medium">Assunto</Label>
                <Input id="subject" placeholder="Digite o assunto do atendimento" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="message" className="font-medium">Descrição</Label>
                <Textarea 
                  id="message" 
                  placeholder="Digite a descrição detalhada do atendimento..."
                  rows={4}
                />
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="type" className="font-medium">Tipo</Label>
                  <Select defaultValue="suporte">
                    <SelectTrigger id="type">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="suporte">Suporte</SelectItem>
                      <SelectItem value="reclamação">Reclamação</SelectItem>
                      <SelectItem value="solicitação">Solicitação</SelectItem>
                      <SelectItem value="informação">Informação</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="priority" className="font-medium">Prioridade</Label>
                  <Select defaultValue="média">
                    <SelectTrigger id="priority">
                      <SelectValue placeholder="Selecione a prioridade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="baixa">Baixa</SelectItem>
                      <SelectItem value="média">Média</SelectItem>
                      <SelectItem value="alta">Alta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="assign" className="font-medium">Atribuir Para</Label>
                <Select defaultValue="auto">
                  <SelectTrigger id="assign">
                    <SelectValue placeholder="Selecione o responsável" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Atribuição Automática</SelectItem>
                    <SelectItem value="ana">Ana Costa</SelectItem>
                    <SelectItem value="carlos">Carlos Mendes</SelectItem>
                    <SelectItem value="pedro">Pedro Santos</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewTicketDialog(false)}>
              Cancelar
            </Button>
            <Button className="gap-2">
              <MessageSquare className="w-4 h-4" />
              Criar Atendimento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}