import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Heart,
  Hand,
  UserCheck,
  BarChart4,
  FileText,
  Users,
  HelpCircle,
  DollarSign,
  FileSearch,
  Calendar,
  Building2
} from "lucide-react";

export default function Menu() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <Link to={createPageUrl("AssistenciaSocial")} className="flex items-center p-4 bg-white rounded-lg shadow hover:shadow-md transition-shadow">
        <Heart className="w-6 h-6 text-red-500 mr-3" />
        <div>
          <h3 className="font-medium">Assistência Social</h3>
          <p className="text-sm text-gray-500">Gerenciar programa social</p>
        </div>
      </Link>
      
      <Link to={createPageUrl("FinanceiroAssociacao")} className="flex items-center p-4 bg-white rounded-lg shadow hover:shadow-md transition-shadow">
        <DollarSign className="w-6 h-6 text-green-500 mr-3" />
        <div>
          <h3 className="font-medium">Financeiro</h3>
          <p className="text-sm text-gray-500">Gestão financeira completa</p>
        </div>
      </Link>
      
      <Link to={createPageUrl("CalendarioReunioes")} className="flex items-center p-4 bg-white rounded-lg shadow hover:shadow-md transition-shadow">
        <Calendar className="w-6 h-6 text-blue-500 mr-3" />
        <div>
          <h3 className="font-medium">Reuniões e Eventos</h3>
          <p className="text-sm text-gray-500">Calendário e atas</p>
        </div>
      </Link>
      
      <Link to={createPageUrl("PlanejamentoEstrategico")} className="flex items-center p-4 bg-white rounded-lg shadow hover:shadow-md transition-shadow">
        <FileSearch className="w-6 h-6 text-purple-500 mr-3" />
        <div>
          <h3 className="font-medium">Planejamento Estratégico</h3>
          <p className="text-sm text-gray-500">Metas e objetivos</p>
        </div>
      </Link>
      
      <Link to={createPageUrl("Associados")} className="flex items-center p-4 bg-white rounded-lg shadow hover:shadow-md transition-shadow">
        <Users className="w-6 h-6 text-indigo-500 mr-3" />
        <div>
          <h3 className="font-medium">Associados</h3>
          <p className="text-sm text-gray-500">Gestão de membros</p>
        </div>
      </Link>
      
      <Link to={createPageUrl("TransparencyDocuments")} className="flex items-center p-4 bg-white rounded-lg shadow hover:shadow-md transition-shadow">
        <Building2 className="w-6 h-6 text-amber-500 mr-3" />
        <div>
          <h3 className="font-medium">Transparência</h3>
          <p className="text-sm text-gray-500">Portal e documentos públicos</p>
        </div>
      </Link>
    </div>
  );
}