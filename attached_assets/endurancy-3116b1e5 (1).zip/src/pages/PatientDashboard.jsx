
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "@/components/ui/use-toast";
import { 
  Calendar, 
  FileText, 
  Heart, 
  MessageSquare, 
  Pill, 
  User as UserIcon, 
  Bell, 
  Settings, 
  LogOut,
  ChevronRight,
  Plus,
  Package,
  Truck,
  CreditCard,
  ArrowUpRight,
  Clock,
  Check,
  Upload,
  AlertTriangle,
  ShoppingBag,
  Search,
  CalendarClock,
  Leaf,
  BarChart,
  Award,
  ShieldAlert,
  FileUp,
  Filter
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function PatientDashboard() {
  const navigate = useNavigate();
  const [patientData, setPatientData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [pedidos, setPedidos] = useState([]);
  const [prescricoes, setPrescricoes] = useState([]);
  const [documentos, setDocumentos] = useState([]);
  const [anuidade, setAnuidade] = useState(null);
  const [mensagens, setMensagens] = useState([]);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [uploadType, setUploadType] = useState("");
  const [produtos, setProdutos] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showPurchaseConfirm, setShowPurchaseConfirm] = useState(false);

  useEffect(() => {
    loadPatientData();
    loadPedidos();
    loadPrescricoes();
    loadDocumentos();
    loadAnuidade();
    loadMensagens();
    loadProdutos();
  }, []);

  const loadPatientData = () => {
    setTimeout(() => {
      setPatientData({
        name: localStorage.getItem('mockUserName') || "Ana Silva",
        email: localStorage.getItem('mockUserEmail') || "ana.silva@email.com",
        organization: localStorage.getItem('mockOrgName') || "MediCannabis Farma",
        prescription: {
          product: "CBD Oil 5%",
          dosage: "20mg 2x daily",
          doctor: "Dr. João Mendes",
          expiry: "2024-05-19"
        },
        nextAppointment: {
          doctor: "Dr. João Mendes",
          type: "Follow-up",
          date: "2023-08-15",
          time: "14:30",
          isVirtual: true
        },
        medications: [
          { id: 1, name: "CBD Oil 5%", time: "08:00", taken: true },
          { id: 2, name: "CBD Oil 5%", time: "20:00", taken: false }
        ],
        membership: {
          status: "Ativo",
          expiryDate: "2023-12-31",
          memberSince: "2022-01-15"
        }
      });
      setIsLoading(false);
    }, 500);
  };

  const loadPedidos = () => {
    const mockPedidos = [
      {
        id: "ped-001",
        numero: "PED-20240715-001",
        data: "2024-07-15",
        status: "entregue",
        valorTotal: 275.90,
        itens: [
          { nome: "Óleo CBD 5% 30ml", quantidade: 1, preco: 195.90 },
          { nome: "Cápsulas CBD 10mg", quantidade: 2, preco: 40.00 }
        ],
        rastreio: {
          codigo: "BR123456789LE",
          status: "entregue",
          dataAtualizacao: "2024-07-20",
          historico: [
            { data: "2024-07-15", status: "pedido_recebido", descricao: "Pedido recebido" },
            { data: "2024-07-16", status: "em_separacao", descricao: "Em separação" },
            { data: "2024-07-17", status: "em_transporte", descricao: "Em transporte" },
            { data: "2024-07-20", status: "entregue", descricao: "Entregue" }
          ]
        }
      },
      {
        id: "ped-002",
        numero: "PED-20240802-002",
        data: "2024-08-02",
        status: "em_transporte",
        valorTotal: 195.90,
        itens: [
          { nome: "Óleo CBD 5% 30ml", quantidade: 1, preco: 195.90 }
        ],
        rastreio: {
          codigo: "BR987654321LE",
          status: "em_transporte",
          dataAtualizacao: "2024-08-04",
          historico: [
            { data: "2024-08-02", status: "pedido_recebido", descricao: "Pedido recebido" },
            { data: "2024-08-03", status: "em_separacao", descricao: "Em separação" },
            { data: "2024-08-04", status: "em_transporte", descricao: "Em transporte" }
          ]
        }
      }
    ];
    setPedidos(mockPedidos);
  };

  const loadPrescricoes = () => {
    const mockPrescricoes = [
      {
        id: "pres-001",
        medico: "Dr. João Mendes",
        data: "2024-07-01",
        validade: "2024-10-01",
        status: "aprovada",
        produtos: [
          { nome: "Óleo CBD 5% 30ml", dosagem: "20mg 2x ao dia" }
        ],
        observacoes: "Continuar o tratamento conforme resposta positiva aos sintomas."
      },
      {
        id: "pres-002",
        medico: "Dra. Maria Santos",
        data: "2024-08-01",
        validade: "2024-11-01",
        status: "em_analise",
        produtos: [
          { nome: "Óleo CBD 5% 30ml", dosagem: "15mg 2x ao dia" },
          { nome: "Cápsulas CBD 10mg", dosagem: "1 cápsula ao dia" }
        ],
        observacoes: "Ajuste na dosagem do óleo e adição de cápsulas para melhor controle."
      }
    ];
    setPrescricoes(mockPrescricoes);
  };

  const loadDocumentos = () => {
    const mockDocumentos = [
      {
        id: "doc-001",
        nome: "Documento de Identidade",
        tipo: "documento_pessoal",
        dataUpload: "2024-01-15",
        status: "valido"
      },
      {
        id: "doc-002",
        nome: "Comprovante de Residência",
        tipo: "documento_pessoal",
        dataUpload: "2024-01-15",
        status: "vencido"
      },
      {
        id: "doc-003",
        nome: "Laudo Médico",
        tipo: "laudo_medico",
        dataUpload: "2024-06-10",
        status: "valido"
      }
    ];
    setDocumentos(mockDocumentos);
  };

  const loadAnuidade = () => {
    const mockAnuidade = {
      ano: "2024",
      valor: 120.00,
      dataVencimento: "2024-03-15",
      status: "pago",
      dataPagamento: "2024-03-10",
      comprovante: "#12345"
    };
    setAnuidade(mockAnuidade);
  };

  const loadMensagens = () => {
    const mockMensagens = [
      {
        id: "msg-001",
        remetente: "Dr. João Mendes",
        assunto: "Acompanhamento do tratamento",
        data: "2024-08-01",
        lida: true,
        conteudo: "Olá Ana, como está se sentindo com o tratamento atual? Precisamos agendar uma consulta de acompanhamento."
      },
      {
        id: "msg-002",
        remetente: "Farmácia MediCannabis",
        assunto: "Renovação de prescrição",
        data: "2024-08-05",
        lida: false,
        conteudo: "Prezada Ana, sua prescrição atual vencerá em breve. Por favor, agende uma consulta para renovação."
      }
    ];
    setMensagens(mockMensagens);
  };

  const loadProdutos = () => {
    const mockProdutos = [
      {
        id: "prod-001",
        nome: "Óleo CBD 5% 30ml",
        categoria: "óleo",
        descricao: "Óleo de CBD 5% para uso sublingual, frasco de 30ml com conta-gotas.",
        preco: 195.90,
        imagem: "https://images.unsplash.com/photo-1616478495639-5dabc4b64544?q=80&w=2070&auto=format&fit=crop",
        disponivel: true
      },
      {
        id: "prod-002",
        nome: "Cápsulas CBD 10mg",
        categoria: "cápsula",
        descricao: "Cápsulas de CBD 10mg, embalagem com 30 unidades.",
        preco: 150.00,
        imagem: "https://images.unsplash.com/photo-1585435557343-3b348031e799?q=80&w=2070&auto=format&fit=crop",
        disponivel: true
      },
      {
        id: "prod-003",
        nome: "Pomada Tópica CBD 300mg",
        categoria: "tópico",
        descricao: "Pomada tópica com 300mg de CBD, para alívio localizado.",
        preco: 120.00,
        imagem: "https://images.unsplash.com/photo-1617942798505-4d5c72de1992?q=80&w=2070&auto=format&fit=crop",
        disponivel: true
      }
    ];
    setProdutos(mockProdutos);
  };

  const handleLogout = () => {
    localStorage.removeItem('mockUserType');
    localStorage.removeItem('mockUserEmail');
    localStorage.removeItem('mockUserName');
    localStorage.removeItem('mockOrgId');
    localStorage.removeItem('mockOrgName');
    window.location.href = `${window.location.origin}/Index`;
  };

  const handleUpload = (type) => {
    setUploadType(type);
    setShowUploadDialog(true);
  };

  const handleBuyNow = (product) => {
    setSelectedProduct(product);
    setShowPurchaseConfirm(true);
  };

  const confirmPurchase = () => {
    const newOrder = {
      id: `ped-00${pedidos.length + 1}`,
      numero: `PED-${format(new Date(), 'yyyyMMdd')}-00${pedidos.length + 1}`,
      data: format(new Date(), 'yyyy-MM-dd'),
      status: "pendente",
      valorTotal: selectedProduct.preco,
      itens: [
        { nome: selectedProduct.nome, quantidade: 1, preco: selectedProduct.preco }
      ],
      rastreio: {
        codigo: `BR${Math.floor(Math.random() * 900000000) + 100000000}LE`,
        status: "processando",
        dataAtualizacao: format(new Date(), 'yyyy-MM-dd'),
        historico: [
          { data: format(new Date(), 'yyyy-MM-dd'), status: "pedido_recebido", descricao: "Pedido recebido" }
        ]
      }
    };
    
    setPedidos([newOrder, ...pedidos]);
    setShowPurchaseConfirm(false);
    setSelectedProduct(null);
    setActiveTab("pedidos");
    toast({
      title: "Pedido realizado com sucesso",
      description: `Seu pedido de ${selectedProduct.nome} foi recebido e está sendo processado.`,
    });
  };

  const cancelPurchase = () => {
    setShowPurchaseConfirm(false);
    setSelectedProduct(null);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "aprovada":
        return "bg-green-100 text-green-800";
      case "em_analise":
        return "bg-yellow-100 text-yellow-800";
      case "rejeitada":
        return "bg-red-100 text-red-800";
      case "vencida":
        return "bg-gray-100 text-gray-800";
      case "pago":
        return "bg-green-100 text-green-800";
      case "pendente":
        return "bg-yellow-100 text-yellow-800";
      case "vencido":
        return "bg-red-100 text-red-800";
      case "em_transporte":
        return "bg-blue-100 text-blue-800";
      case "entregue":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleQuickAction = (action) => {
    switch(action) {
      case 'fazer_pedido':
        setActiveTab('produtos');
        break;
      case 'nova_prescricao':
        setShowUploadDialog(true);
        setUploadType('prescricao');
        break;
      case 'agendar_consulta':
        alert('Em breve: Agendamento de consultas');
        break;
      case 'contatar_medico':
        setActiveTab('mensagens');
        break;
      default:
        break;
    }
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link to={createPageUrl("Index")} className="flex items-center gap-2">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <span className="text-green-600 font-bold">E</span>
                </div>
                <span className="text-xl font-semibold">Portal do Paciente</span>
              </Link>
            </div>

            <div className="flex items-center gap-4">
              <button className="p-2 rounded-full hover:bg-gray-100 relative">
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-100">
                  <Avatar>
                    <AvatarFallback>{patientData.name.substring(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="text-left hidden sm:block">
                    <div className="text-sm font-medium">{patientData.name}</div>
                    <div className="text-xs text-gray-500">{patientData.organization}</div>
                  </div>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Minha conta</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Settings className="w-4 h-4 mr-2" /> Configurações
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-red-600" onClick={handleLogout}>
                    <LogOut className="w-4 h-4 mr-2" /> Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Prescrição Atual</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-xl font-semibold">{patientData.prescription.product}</div>
                  <div className="text-gray-500">{patientData.prescription.dosage}</div>
                </div>
                <div className="text-sm text-gray-500">
                  Médico: {patientData.prescription.doctor}
                </div>
                <div className="text-sm text-gray-500">
                  Válido até: {patientData.prescription.expiry}
                </div>
                <Badge className="bg-green-100 text-green-800">Ativa</Badge>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Próxima Consulta</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-xl font-semibold">{patientData.nextAppointment.doctor}</div>
                  <div className="text-gray-500">{patientData.nextAppointment.type}</div>
                </div>
                <div className="text-sm text-gray-500">
                  Data: {patientData.nextAppointment.date}
                </div>
                <div className="text-sm text-gray-500">
                  Horário: {patientData.nextAppointment.time}
                </div>
                <Badge className="bg-blue-100 text-blue-800">
                  {patientData.nextAppointment.isVirtual ? 'Telemedicina' : 'Presencial'}
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Status da Anuidade</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-xl font-semibold">Anuidade {anuidade?.ano}</div>
                  <div className="text-gray-500">R$ {anuidade?.valor.toFixed(2)}</div>
                </div>
                <div className="text-sm text-gray-500">
                  Vencimento: {anuidade?.dataVencimento}
                </div>
                {anuidade?.dataPagamento && (
                  <div className="text-sm text-gray-500">
                    Pago em: {anuidade?.dataPagamento}
                  </div>
                )}
                <Badge className={getStatusColor(anuidade?.status)}>
                  {anuidade?.status === "pago" ? "Pago" : "Pendente"}
                </Badge>
              </div>
              {anuidade?.status !== "pago" && (
                <Button className="w-full mt-4">
                  <CreditCard className="w-4 h-4 mr-2" /> Realizar Pagamento
                </Button>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="mt-8">
          <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-6 md:w-fit">
              <TabsTrigger value="overview">Visão Geral</TabsTrigger>
              <TabsTrigger value="produtos">Produtos</TabsTrigger>
              <TabsTrigger value="pedidos">Meus Pedidos</TabsTrigger>
              <TabsTrigger value="prescricoes">Prescrições</TabsTrigger>
              <TabsTrigger value="documentos">Documentos</TabsTrigger>
              <TabsTrigger value="mensagens">Mensagens</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Ações Rápidas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Button 
                        className="w-full justify-start" 
                        variant="outline"
                        onClick={() => handleQuickAction('fazer_pedido')}
                      >
                        <ShoppingBag className="w-4 h-4 mr-2" /> 
                        Fazer um Pedido
                      </Button>
                      <Button 
                        className="w-full justify-start" 
                        variant="outline"
                        onClick={() => handleQuickAction('nova_prescricao')}
                      >
                        <FileUp className="w-4 h-4 mr-2" /> 
                        Enviar Nova Prescrição
                      </Button>
                      <Button 
                        className="w-full justify-start" 
                        variant="outline"
                        onClick={() => handleQuickAction('agendar_consulta')}
                      >
                        <CalendarClock className="w-4 h-4 mr-2" /> 
                        Agendar Consulta
                      </Button>
                      <Button 
                        className="w-full justify-start" 
                        variant="outline"
                        onClick={() => handleQuickAction('contatar_medico')}
                      >
                        <MessageSquare className="w-4 h-4 mr-2" /> 
                        Contatar Médico
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Status do Tratamento</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <Heart className="w-5 h-5 text-red-500" />
                        <span>Acompanhamento ativo - <span className="text-green-600 font-medium">6 meses</span></span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Pill className="w-5 h-5 text-blue-500" />
                        <span>2 medicações ativas</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-green-500" />
                        <span>Próxima consulta em 3 dias</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Truck className="w-5 h-5 text-purple-500" />
                        <span>1 pedido em trânsito</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Seus Medicamentos Hoje</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {patientData.medications.map(med => (
                        <div key={med.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="bg-green-100 p-2 rounded-full">
                              <Leaf className="w-5 h-5 text-green-600" />
                            </div>
                            <div>
                              <div className="font-medium">{med.name}</div>
                              <div className="text-sm text-gray-500">{med.time}</div>
                            </div>
                          </div>
                          <Badge className={med.taken ? 
                            "bg-green-100 text-green-800" : 
                            "bg-yellow-100 text-yellow-800"
                          }>
                            {med.taken ? 'Tomado' : 'Pendente'}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="produtos" className="mt-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Produtos Aprovados na Sua Prescrição</CardTitle>
                  <div className="flex gap-2 items-center">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                      <Input
                        placeholder="Buscar produtos..."
                        className="pl-8 w-[250px]"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {produtos
                      .filter(p => p.nome.toLowerCase().includes(searchTerm.toLowerCase()))
                      .map(produto => (
                        <Card key={produto.id} className="overflow-hidden">
                          <div className="aspect-video w-full overflow-hidden">
                            <img 
                              src={produto.imagem} 
                              alt={produto.nome}
                              className="w-full h-full object-cover transition-transform hover:scale-105" 
                            />
                          </div>
                          <CardHeader className="p-4">
                            <div className="flex justify-between items-start">
                              <div>
                                <p className="text-xs text-blue-600 font-medium">{produto.categoria}</p>
                                <CardTitle className="text-lg">{produto.nome}</CardTitle>
                              </div>
                              <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">
                                R$ {produto.preco.toFixed(2)}
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent className="p-4 pt-0">
                            <p className="text-sm text-gray-500 line-clamp-2">{produto.descricao}</p>
                          </CardContent>
                          <CardFooter className="p-4 pt-0">
                            <Button 
                              className="w-full" 
                              onClick={() => handleBuyNow(produto)}
                            >
                              Fazer Pedido
                            </Button>
                          </CardFooter>
                        </Card>
                      ))}
                  </div>
                </CardContent>
              </Card>

              {showPurchaseConfirm && selectedProduct && (
                <Dialog open={showPurchaseConfirm} onOpenChange={setShowPurchaseConfirm}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Confirmar Pedido</DialogTitle>
                      <DialogDescription>
                        Você está prestes a fazer um pedido do seguinte produto:
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-lg overflow-hidden">
                          <img 
                            src={selectedProduct.imagem} 
                            alt={selectedProduct.nome} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="font-medium">{selectedProduct.nome}</h3>
                          <p className="text-sm text-gray-500">{selectedProduct.categoria}</p>
                          <p className="font-medium text-green-600">R$ {selectedProduct.preco.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={cancelPurchase}>Cancelar</Button>
                      <Button onClick={confirmPurchase}>Confirmar Pedido</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              )}
            </TabsContent>

            <TabsContent value="pedidos" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Meus Pedidos</CardTitle>
                </CardHeader>
                <CardContent>
                  {pedidos.length === 0 ? (
                    <div className="text-center py-8">
                      <Package className="w-12 h-12 mx-auto text-gray-300" />
                      <h3 className="mt-4 text-lg font-medium">Nenhum pedido encontrado</h3>
                      <p className="mt-1 text-gray-500">Você ainda não fez nenhum pedido.</p>
                      <Button className="mt-4">Fazer meu primeiro pedido</Button>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {pedidos.map(pedido => (
                        <Card key={pedido.id} className="overflow-hidden">
                          <div className="p-4 border-b bg-gray-50">
                            <div className="flex flex-wrap justify-between items-center gap-2">
                              <div>
                                <p className="text-sm text-gray-500">Pedido #{pedido.numero}</p>
                                <p className="font-medium">Data: {pedido.data}</p>
                              </div>
                              <Badge className={getStatusColor(pedido.status)}>
                                {pedido.status === "em_transporte" ? "Em Transporte" : 
                                 pedido.status === "entregue" ? "Entregue" : 
                                 pedido.status === "pendente" ? "Pendente" : pedido.status}
                              </Badge>
                            </div>
                          </div>
                          <div className="p-4">
                            <h4 className="text-sm font-medium mb-2">Itens do pedido:</h4>
                            <div className="space-y-2">
                              {pedido.itens.map((item, index) => (
                                <div key={index} className="flex justify-between items-center text-sm">
                                  <span>{item.quantidade}x {item.nome}</span>
                                  <span>R$ {item.preco.toFixed(2)}</span>
                                </div>
                              ))}
                              <Separator />
                              <div className="flex justify-between items-center font-medium">
                                <span>Total</span>
                                <span>R$ {pedido.valorTotal.toFixed(2)}</span>
                              </div>
                            </div>
                          </div>
                          <div className="p-4 border-t">
                            <div className="flex flex-col md:flex-row gap-4">
                              <div className="flex-1">
                                <h4 className="text-sm font-medium flex items-center gap-2 mb-2">
                                  <Truck className="w-4 h-4" /> Status da entrega
                                </h4>
                                <div className="space-y-2">
                                  <div className="flex justify-between text-sm">
                                    <span>Código de rastreio:</span>
                                    <span className="font-medium">{pedido.rastreio.codigo}</span>
                                  </div>
                                  <div className="flex justify-between text-sm">
                                    <span>Última atualização:</span>
                                    <span>{pedido.rastreio.dataAtualizacao}</span>
                                  </div>
                                </div>
                              </div>
                              <Separator orientation="vertical" className="hidden md:block" />
                              <div className="flex-1">
                                <h4 className="text-sm font-medium mb-2">Progresso da entrega</h4>
                                <div className="relative">
                                  <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                                    <div
                                      style={{ width: pedido.status === 'entregue' ? '100%' : '75%' }}
                                      className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-500"
                                    ></div>
                                  </div>
                                  <div className="mt-2 flex justify-between text-xs text-gray-500">
                                    <span>Pedido realizado</span>
                                    <span>Em trânsito</span>
                                    <span>Entregue</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="p-4 bg-gray-50 border-t flex justify-end gap-2">
                            <Button variant="outline" size="sm">
                              Detalhes completos
                            </Button>
                            <Button size="sm">
                              Rastrear entrega
                            </Button>
                          </div>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="prescricoes" className="mt-6">
              <div className="flex justify-between mb-4">
                <h3 className="text-lg font-semibold">Minhas Prescrições</h3>
                <Button onClick={() => handleUpload("prescricao")}>
                  <Upload className="mr-2 h-4 w-4" /> Enviar Nova Prescrição
                </Button>
              </div>
              
              <div className="grid gap-4">
                {prescricoes.map(prescricao => (
                  <Card key={prescricao.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{prescricao.medico}</CardTitle>
                          <p className="text-sm text-gray-500">Data: {prescricao.data}</p>
                        </div>
                        <Badge className={getStatusColor(prescricao.status)}>
                          {prescricao.status === "aprovada" ? "Aprovada" :
                           prescricao.status === "em_analise" ? "Em Análise" :
                           prescricao.status === "rejeitada" ? "Rejeitada" : "Vencida"}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm font-medium">Medicamentos prescritos:</p>
                          <ul className="ml-5 mt-1 space-y-1 list-disc text-sm">
                            {prescricao.produtos.map((produto, idx) => (
                              <li key={idx}>
                                <span className="font-medium">{produto.nome}</span> - {produto.dosagem}
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <p className="text-sm font-medium">Observações médicas:</p>
                          <p className="text-sm text-gray-600 mt-1">{prescricao.observacoes}</p>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="text-sm">
                            <span className="text-gray-500">Validade: </span>
                            <span className="font-medium">{prescricao.validade}</span>
                          </div>
                          
                          <Button variant="outline" size="sm">
                            <FileText className="mr-2 h-4 w-4" /> Ver Detalhes
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="documentos" className="mt-6">
              <div className="flex justify-between mb-4">
                <h3 className="text-lg font-semibold">Meus Documentos</h3>
                <Button onClick={() => handleUpload("documento")}>
                  <Upload className="mr-2 h-4 w-4" /> Enviar Documento
                </Button>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Documentos Enviados</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-2 font-medium">Documento</th>
                          <th className="text-left py-3 px-2 font-medium">Tipo</th>
                          <th className="text-left py-3 px-2 font-medium">Data de Envio</th>
                          <th className="text-left py-3 px-2 font-medium">Status</th>
                          <th className="text-left py-3 px-2 font-medium">Ações</th>
                        </tr>
                      </thead>
                      <tbody>
                        {documentos.map(doc => (
                          <tr key={doc.id} className="border-b hover:bg-gray-50">
                            <td className="py-3 px-2">{doc.nome}</td>
                            <td className="py-3 px-2">
                              {doc.tipo === "documento_pessoal" ? "Documento Pessoal" : 
                               doc.tipo === "laudo_medico" ? "Laudo Médico" : doc.tipo}
                            </td>
                            <td className="py-3 px-2">{doc.dataUpload}</td>
                            <td className="py-3 px-2">
                              <Badge className={getStatusColor(doc.status)}>
                                {doc.status === "valido" ? "Válido" : "Vencido"}
                              </Badge>
                            </td>
                            <td className="py-3 px-2">
                              <div className="flex gap-2">
                                <Button variant="outline" size="sm">Visualizar</Button>
                                {doc.status === "vencido" && (
                                  <Button size="sm">Atualizar</Button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Documentos Necessários</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                      <div className="shrink-0">
                        <AlertTriangle className="h-6 w-6 text-yellow-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">Comprovante de Residência</h4>
                        <p className="text-sm text-gray-600 mt-1">Seu documento está vencido. Por favor, envie uma versão atualizada.</p>
                        <Button size="sm" className="mt-2">Enviar Atualização</Button>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                      <div className="shrink-0">
                        <Check className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">Documento de Identidade</h4>
                        <p className="text-sm text-gray-600 mt-1">Documento válido e atualizado.</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="mensagens" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Mensagens</CardTitle>
                  <CardDescription>Suas comunicações com médicos e equipe</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    <div className="space-y-4">
                      {mensagens.map(mensagem => (
                        <div key={mensagem.id} className={`p-4 rounded-lg border ${mensagem.lida ? 'bg-white' : 'bg-blue-50 border-blue-200'}`}>
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium">{mensagem.assunto}</h4>
                              <p className="text-sm text-gray-500">De: {mensagem.remetente}</p>
                            </div>
                            <div className="text-sm text-gray-500">{mensagem.data}</div>
                          </div>
                          <p className="mt-2 text-sm">{mensagem.conteudo}</p>
                          <div className="mt-3 flex gap-2 justify-end">
                            {!mensagem.lida && (
                              <Badge className="bg-blue-100 text-blue-800">Nova</Badge>
                            )}
                            <Button variant="outline" size="sm">
                              <MessageSquare className="mr-2 h-3 w-3" /> Responder
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
                <CardFooter className="justify-between">
                  <Button variant="outline">Ver todas</Button>
                  <Button>
                    <MessageSquare className="mr-2 h-4 w-4" /> Nova Mensagem
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {uploadType === 'prescricao' ? 'Enviar Nova Prescrição' : 'Upload de Documento'}
            </DialogTitle>
            <DialogDescription>
              {uploadType === 'prescricao' 
                ? 'Faça o upload da sua prescrição médica para análise.'
                : 'Faça o upload do documento solicitado.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 text-center">
              <div className="flex flex-col items-center space-y-2">
                <Upload className="h-8 w-8 text-gray-400" />
                <div className="text-sm text-gray-600">
                  <label htmlFor="file-upload" className="relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500">
                    <span>Clique para fazer upload</span>
                    <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                  </label>
                  <p className="pl-1">ou arraste e solte</p>
                </div>
                <p className="text-xs text-gray-500">
                  PDF, JPG ou PNG até 10MB
                </p>
              </div>
            </div>
            <div className="flex space-x-2 text-sm text-gray-600">
              <AlertTriangle className="h-4 w-4" />
              <p>
                Certifique-se que todos os dados estejam legíveis na imagem.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUploadDialog(false)}>
              Cancelar
            </Button>
            <Button type="submit">
              Enviar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {showPurchaseConfirm && selectedProduct && (
        <Dialog open={showPurchaseConfirm} onOpenChange={setShowPurchaseConfirm}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirmar Pedido</DialogTitle>
              <DialogDescription>
                Você está prestes a fazer um pedido do seguinte produto:
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-lg overflow-hidden">
                  <img 
                    src={selectedProduct.imagem} 
                    alt={selectedProduct.nome} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-medium">{selectedProduct.nome}</h3>
                  <p className="text-sm text-gray-500">{selectedProduct.categoria}</p>
                  <p className="font-medium text-green-600">R$ {selectedProduct.preco.toFixed(2)}</p>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={cancelPurchase}>Cancelar</Button>
              <Button onClick={confirmPurchase}>Confirmar Pedido</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
