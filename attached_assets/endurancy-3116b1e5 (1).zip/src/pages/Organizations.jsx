
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Building2, 
  Users, 
  Mail, 
  Phone, 
  Calendar, 
  MapPin, 
  Tag, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Plus,
  MoreHorizontal,
  Heart,
  Leaf,
  Scale,
  Briefcase,
  Factory,
  Glasses,
  Layers,
  AlertTriangle,
  Search,
  Filter
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

// Dados simulados para evitar problemas de timeout com a API
const mockOrganizations = [
  {
    id: "org1",
    name: "MediCannabis Farma",
    type: "Empresa",
    plan: "Empresarial Pro",
    contact_name: "João Silva",
    contact_email: "joao@medicannabis.com.br",
    contact_phone: "+55 11 98765-4321",
    status: "Ativo",
    created_date: "2023-07-15T14:30:00Z"
  },
  {
    id: "org2",
    name: "Associação Médica Verde",
    type: "Associação",
    plan: "Associação Premium",
    contact_name: "Maria Oliveira",
    contact_email: "maria@amv.org.br",
    contact_phone: "+55 21 99876-5432",
    status: "Ativo",
    created_date: "2023-07-12T10:15:00Z"
  },
  {
    id: "org3",
    name: "CannaPesquisa Instituto",
    type: "Associação",
    plan: "Associação Plus",
    contact_name: "Pedro Almeida",
    contact_email: "pedro@cannapesquisa.org",
    contact_phone: "+55 31 98887-6655",
    status: "Pendente",
    created_date: "2023-07-21T09:45:00Z"
  },
  {
    id: "org4",
    name: "Green Medical Brasil",
    type: "Empresa",
    plan: "Empresarial Básico",
    contact_name: "Ana Sousa",
    contact_email: "ana@greenmedical.com.br",
    contact_phone: "+55 41 99998-7766",
    status: "Pendente",
    created_date: "2023-07-20T16:20:00Z"
  },
  {
    id: "org5",
    name: "Cannabis Brasil Sul",
    type: "Empresa",
    plan: "Empresarial Pro",
    contact_name: "Carlos Mendes",
    contact_email: "carlos@cannabisbrasil.com.br",
    contact_phone: "+55 51 98765-1234",
    status: "Rejeitado",
    created_date: "2023-07-10T11:30:00Z"
  },
  {
    id: "org6",
    name: "Cultivo Sustentável Ltda",
    type: "Empresa",
    plan: "Empresarial Básico",
    contact_name: "Ana Costa",
    contact_email: "ana@cultivosustentavel.com.br",
    contact_phone: "+55 19 99887-6655",
    status: "Ativo",
    created_date: "2023-06-28T14:45:00Z"
  }
];

export default function Organizations() {
  const [organizations, setOrganizations] = useState([]);
  const [filteredOrgs, setFilteredOrgs] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [isLoading, setIsLoading] = useState(true);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [organizationToDelete, setOrganizationToDelete] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadOrganizations();
  }, []);
  
  useEffect(() => {
    filterOrganizations();
  }, [organizations, searchTerm, statusFilter, typeFilter]);
  
  const loadOrganizations = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Simular carregamento de dados
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Usar dados simulados
      setOrganizations(mockOrganizations);
    } catch (error) {
      console.error("Error loading organizations", error);
      setError("Erro ao carregar organizações. Usando dados de demonstração.");
      setOrganizations(mockOrganizations);
    } finally {
      setIsLoading(false);
    }
  };
  
  const filterOrganizations = () => {
    let filtered = [...organizations];
    
    if (searchTerm.trim() !== "") {
      filtered = filtered.filter(org => 
        org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        org.contact_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        org.contact_email?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (statusFilter !== "all") {
      filtered = filtered.filter(org => org.status === statusFilter);
    }
    
    if (typeFilter !== "all") {
      filtered = filtered.filter(org => org.type === typeFilter);
    }
    
    setFilteredOrgs(filtered);
  };
  
  const handleDeleteClick = (organization) => {
    setOrganizationToDelete(organization);
    setShowDeleteDialog(true);
  };
  
  const confirmDelete = async () => {
    if (!organizationToDelete) return;
    
    try {
      // Simular exclusão
      setOrganizations(organizations.filter(org => org.id !== organizationToDelete.id));
      setShowDeleteDialog(false);
      setOrganizationToDelete(null);
    } catch (error) {
      console.error("Error deleting organization", error);
    }
  };
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  const statusStyles = {
    "Ativo": "bg-green-100 text-green-800",
    "Pendente": "bg-yellow-100 text-yellow-800",
    "Rejeitado": "bg-red-100 text-red-800"
  };
  
  const typeStyles = {
    "Empresa": "bg-blue-100 text-blue-800",
    "Associação": "bg-purple-100 text-purple-800"
  };
  
  const statusIcons = {
    "Ativo": <CheckCircle2 className="w-3 h-3 mr-1" />,
    "Pendente": <Clock className="w-3 h-3 mr-1" />,
    "Rejeitado": <XCircle className="w-3 h-3 mr-1" />
  };

  const ViewOrganizationPage = ({ selectedOrg, onBack }) => {
    const [activeTab, setActiveTab] = useState("details");
    const [modules, setModules] = useState([]);
    const [availableModules, setAvailableModules] = useState([]);
    const [showAddModuleDialog, setShowAddModuleDialog] = useState(false);
    const [selectedModuleId, setSelectedModuleId] = useState("");

    useEffect(() => {
      // Simular carga de módulos da organização
      setTimeout(() => {
        setModules([
          { id: 'crm', name: 'CRM', active: true, price: 299, icon: Heart },
          { id: 'cultivo', name: 'Cultivo', active: true, price: 399, icon: Leaf }
        ]);
        
        setAvailableModules([
          { id: 'juridico', name: 'Jurídico', price: 199, icon: Scale, description: 'Gestão de ações judiciais' },
          { id: 'rh', name: 'RH', price: 249, icon: Briefcase, description: 'Gestão de recursos humanos' },
          { id: 'producao', name: 'Produção', price: 349, icon: Factory, description: 'Controle de produção' },
          { id: 'transparencia', name: 'Transparência', price: 149, icon: Glasses, description: 'Portal de transparência' }
        ]);
      }, 500);
    }, []);

    const addModuleToOrganization = () => {
      if (selectedModuleId) {
        const moduleToAdd = availableModules.find(m => m.id === selectedModuleId);
        if (moduleToAdd) {
          setModules([...modules, {...moduleToAdd, active: true}]);
          setAvailableModules(availableModules.filter(m => m.id !== selectedModuleId));
          setShowAddModuleDialog(false);
          setSelectedModuleId("");
        }
      }
    };

    return (
      <div>
        <h2 className="text-xl font-bold">{selectedOrg.name}</h2>
        <Button onClick={onBack} variant="outline">Voltar</Button>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="details">Detalhes</TabsTrigger>
            <TabsTrigger value="users">Usuários</TabsTrigger>
            <TabsTrigger value="modules">Módulos</TabsTrigger>
            <TabsTrigger value="activity">Atividade</TabsTrigger>
          </TabsList>
          
          <TabsContent value="modules" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Módulos Ativos</CardTitle>
                  <CardDescription>
                    Módulos atualmente ativados para esta organização
                  </CardDescription>
                </div>
                <Button variant="outline" onClick={() => setShowAddModuleDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Módulo
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {modules.length > 0 ? (
                    modules.map((module) => {
                      const Icon = module.icon;
                      return (
                        <div key={module.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-blue-50 rounded-lg">
                              <Icon className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                              <p className="font-medium">{module.name}</p>
                              <p className="text-sm text-gray-500">R$ {module.price}/mês</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge className={module.active ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                              {module.active ? "Ativo" : "Inativo"}
                            </Badge>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>
                                  {module.active ? "Desativar" : "Ativar"}
                                </DropdownMenuItem>
                                <DropdownMenuItem>Configurar</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">
                                  Remover
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center py-6">
                      <Layers className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                      <h3 className="text-lg font-medium">Nenhum módulo ativo</h3>
                      <p className="text-gray-500 mt-1">Adicione módulos para expandir as funcionalidades</p>
                      <Button className="mt-4" onClick={() => setShowAddModuleDialog(true)}>
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar Módulo
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
        </Tabs>
        
        {showAddModuleDialog && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
            <Card className="w-full max-w-md mx-auto">
              <CardHeader>
                <CardTitle>Adicionar Módulo</CardTitle>
                <CardDescription>
                  Selecione um módulo para adicionar à organização
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {availableModules.map((module) => {
                    const Icon = module.icon;
                    return (
                      <div 
                        key={module.id} 
                        className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                          selectedModuleId === module.id ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                        }`}
                        onClick={() => setSelectedModuleId(module.id)}
                      >
                        <div className={`p-2 rounded-lg ${
                          selectedModuleId === module.id ? 'bg-blue-100' : 'bg-gray-100'
                        }`}>
                          <Icon className={`w-5 h-5 ${
                            selectedModuleId === module.id ? 'text-blue-600' : 'text-gray-600'
                          }`} />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-medium">{module.name}</p>
                            <p className="font-medium">R$ {module.price}/mês</p>
                          </div>
                          <p className="text-sm text-gray-500 mt-1">{module.description}</p>
                        </div>
                      </div>
                    );
                  })}

                  {availableModules.length === 0 && (
                    <div className="text-center py-6">
                      <p className="text-gray-500">Não há módulos adicionais disponíveis</p>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => {
                  setShowAddModuleDialog(false);
                  setSelectedModuleId("");
                }}>
                  Cancelar
                </Button>
                <Button 
                  onClick={addModuleToOrganization}
                  disabled={!selectedModuleId}
                >
                  Adicionar
                </Button>
              </CardFooter>
            </Card>
          </div>
        )}
      </div>
    );
  };

  // Adicionar esta função para ir para a página de detalhes da organização
  const handleViewOrganization = (orgId) => {
    window.location.href = createPageUrl(`Organization?id=${orgId}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Organizações</h1>
          <p className="text-gray-500 mt-1">
            Gerencie todas as organizações cadastradas na plataforma
          </p>
        </div>
        <Link to={createPageUrl("NewOrganization")}>
          <Button className="gap-2 bg-green-600 hover:bg-green-700">
            <Plus className="w-4 h-4" />
            Nova Organização
          </Button>
        </Link>
      </div>

      {error && (
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg mb-4">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2" />
            <span>{error}</span>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div className="w-full md:w-auto flex flex-col md:flex-row gap-4">
          <div className="relative max-w-sm w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar organizações..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-40">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4" />
                <SelectValue placeholder="Status" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="Ativo">Ativos</SelectItem>
              <SelectItem value="Pendente">Pendentes</SelectItem>
              <SelectItem value="Rejeitado">Rejeitados</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-full md:w-40">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                <SelectValue placeholder="Tipo" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="Empresa">Empresas</SelectItem>
              <SelectItem value="Associação">Associações</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card className="overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Plano</TableHead>
                <TableHead>Contato</TableHead>
                <TableHead>Criado em</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <TableRow key={i} className="animate-pulse">
                    <TableCell>
                      <div className="h-5 bg-gray-200 rounded w-32"></div>
                    </TableCell>
                    <TableCell>
                      <div className="h-5 bg-gray-200 rounded w-24"></div>
                    </TableCell>
                    <TableCell>
                      <div className="h-5 bg-gray-200 rounded w-28"></div>
                    </TableCell>
                    <TableCell>
                      <div className="h-5 bg-gray-200 rounded w-36"></div>
                    </TableCell>
                    <TableCell>
                      <div className="h-5 bg-gray-200 rounded w-24"></div>
                    </TableCell>
                    <TableCell>
                      <div className="h-5 bg-gray-200 rounded w-20"></div>
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end">
                        <div className="h-8 bg-gray-200 rounded w-8"></div>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : filteredOrgs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    <Building2 className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                    <h3 className="text-lg font-medium">Nenhuma organização encontrada</h3>
                    <p className="text-gray-500 mt-1">
                      {searchTerm || statusFilter !== "all" || typeFilter !== "all" 
                        ? "Tente ajustar os filtros de busca" 
                        : "Adicione sua primeira organização clicando no botão acima"}
                    </p>
                  </TableCell>
                </TableRow>
              ) : (
                filteredOrgs.map((org) => (
                  <TableRow key={org.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-gray-400" />
                        <span>{org.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={typeStyles[org.type]}>
                        {org.type}
                      </Badge>
                    </TableCell>
                    <TableCell>{org.plan}</TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div className="flex items-center gap-1 text-gray-700">
                          <span className="font-medium">{org.contact_name}</span>
                        </div>
                        <div className="flex items-center gap-1 text-gray-500">
                          <Mail className="w-3 h-3" />
                          <span>{org.contact_email}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 text-sm">
                        <Calendar className="w-3 h-3 text-gray-400" />
                        {formatDate(org.created_date)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={statusStyles[org.status]}>
                        {statusIcons[org.status]}
                        {org.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleViewOrganization(org.id)}>Ver detalhes</DropdownMenuItem>
                          <DropdownMenuItem>Editar</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>Gerenciar usuários</DropdownMenuItem>
                          <DropdownMenuItem>Gerenciar módulos</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteClick(org)}>
                            Desativar
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Confirmar exclusão
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>
              Tem certeza que deseja excluir a organização <strong>{organizationToDelete?.name}</strong>?
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Esta ação não pode ser desfeita e removerá todos os dados associados a esta organização.
            </p>
          </div>
          <DialogFooter className="flex space-x-2">
            <Button 
              variant="outline" 
              onClick={() => setShowDeleteDialog(false)}
            >
              Cancelar
            </Button>
            <Button 
              variant="destructive"
              onClick={confirmDelete}
            >
              Excluir Organização
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
