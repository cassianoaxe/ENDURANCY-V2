import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Filter, 
  Clock, 
  Activity, 
  User, 
  Building2, 
  Settings, 
  FileText, 
  UserPlus, 
  FileEdit, 
  Archive, 
  Shield, 
  MessageSquare,
  Download
} from "lucide-react";

const activitiesData = [
  {
    id: 1,
    user: {
      name: "João Silva",
      avatar: "JS",
      role: "Admin"
    },
    action: "organization_create",
    entity: "Associação Médica Verde",
    timestamp: "2023-07-21T14:30:00Z",
    details: "Criou uma nova organização"
  },
  {
    id: 2,
    user: {
      name: "Maria Oliveira",
      avatar: "MO",
      role: "Super Admin"
    },
    action: "request_approve",
    entity: "Cannabis Brasil Medicinal",
    timestamp: "2023-07-21T13:15:00Z",
    details: "Aprovou solicitação de organização"
  },
  {
    id: 3,
    user: {
      name: "Carlos Mendes",
      avatar: "CM",
      role: "Admin"
    },
    action: "user_invite",
    entity: "Apoio Médico Cannabis",
    timestamp: "2023-07-21T11:45:00Z",
    details: "Convidou 3 novos usuários"
  },
  {
    id: 4,
    user: {
      name: "Ana Costa",
      avatar: "AC",
      role: "Admin"
    },
    action: "setting_change",
    entity: "Sistema",
    timestamp: "2023-07-21T10:20:00Z",
    details: "Alterou configurações de segurança"
  },
  {
    id: 5,
    user: {
      name: "Pedro Santos",
      avatar: "PS",
      role: "Support"
    },
    action: "ticket_reply",
    entity: "Suporte",
    timestamp: "2023-07-21T09:30:00Z",
    details: "Respondeu ticket #1234"
  },
  {
    id: 6,
    user: {
      name: "Lúcia Mendes",
      avatar: "LM",
      role: "Admin"
    },
    action: "document_upload",
    entity: "Cultivo Sustentável Ltda",
    timestamp: "2023-07-20T16:45:00Z",
    details: "Enviou novos documentos"
  },
  {
    id: 7,
    user: {
      name: "João Silva",
      avatar: "JS",
      role: "Admin"
    },
    action: "request_reject",
    entity: "Cannabis Terapêutica Sul",
    timestamp: "2023-07-20T15:10:00Z",
    details: "Rejeitou solicitação de organização"
  },
  {
    id: 8,
    user: {
      name: "Ana Costa",
      avatar: "AC",
      role: "Admin"
    },
    action: "report_generate",
    entity: "Relatórios",
    timestamp: "2023-07-20T14:25:00Z",
    details: "Gerou relatório mensal de atividades"
  },
  {
    id: 9,
    user: {
      name: "Carlos Mendes",
      avatar: "CM",
      role: "Admin"
    },
    action: "organization_edit",
    entity: "MediCannabis Farma",
    timestamp: "2023-07-20T13:05:00Z",
    details: "Atualizou informações da organização"
  },
  {
    id: 10,
    user: {
      name: "Maria Oliveira",
      avatar: "MO",
      role: "Super Admin"
    },
    action: "user_role_change",
    entity: "Usuários",
    timestamp: "2023-07-20T11:30:00Z",
    details: "Alterou permissões de usuário"
  }
];

const actionIcons = {
  organization_create: <Building2 className="w-4 h-4" />,
  request_approve: <Shield className="w-4 h-4" />,
  user_invite: <UserPlus className="w-4 h-4" />,
  setting_change: <Settings className="w-4 h-4" />,
  ticket_reply: <MessageSquare className="w-4 h-4" />,
  document_upload: <FileText className="w-4 h-4" />,
  request_reject: <Shield className="w-4 h-4" />,
  report_generate: <FileText className="w-4 h-4" />,
  organization_edit: <FileEdit className="w-4 h-4" />,
  user_role_change: <User className="w-4 h-4" />
};

const actionColors = {
  organization_create: "bg-green-100 text-green-800",
  request_approve: "bg-green-100 text-green-800",
  user_invite: "bg-blue-100 text-blue-800",
  setting_change: "bg-yellow-100 text-yellow-800",
  ticket_reply: "bg-purple-100 text-purple-800",
  document_upload: "bg-blue-100 text-blue-800",
  request_reject: "bg-red-100 text-red-800",
  report_generate: "bg-indigo-100 text-indigo-800",
  organization_edit: "bg-yellow-100 text-yellow-800",
  user_role_change: "bg-orange-100 text-orange-800"
};

const entityIcons = {
  Sistema: <Settings className="w-4 h-4 text-gray-400" />,
  Suporte: <MessageSquare className="w-4 h-4 text-gray-400" />,
  Relatórios: <FileText className="w-4 h-4 text-gray-400" />,
  Usuários: <User className="w-4 h-4 text-gray-400" />
};

export default function Activities() {
  const [activityFilter, setActivityFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("today");
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    
    // Format time (HH:MM)
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const timeString = `${hours}:${minutes}`;
    
    // Check if it's today
    const today = new Date();
    if (date.getDate() === today.getDate() && 
        date.getMonth() === today.getMonth() && 
        date.getFullYear() === today.getFullYear()) {
      return `Hoje, ${timeString}`;
    }
    
    // Check if it's yesterday
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.getDate() === yesterday.getDate() && 
        date.getMonth() === yesterday.getMonth() && 
        date.getFullYear() === yesterday.getFullYear()) {
      return `Ontem, ${timeString}`;
    }
    
    // Otherwise, show full date
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  const filterActivities = () => {
    let filtered = [...activitiesData];
    
    // Filter by action type
    if (activityFilter !== "all") {
      if (activityFilter === "organization") {
        filtered = filtered.filter(a => 
          a.action === "organization_create" || 
          a.action === "organization_edit" ||
          a.action === "request_approve" ||
          a.action === "request_reject"
        );
      } else if (activityFilter === "user") {
        filtered = filtered.filter(a => 
          a.action === "user_invite" || 
          a.action === "user_role_change"
        );
      } else if (activityFilter === "system") {
        filtered = filtered.filter(a => 
          a.action === "setting_change" || 
          a.action === "report_generate"
        );
      } else if (activityFilter === "support") {
        filtered = filtered.filter(a => 
          a.action === "ticket_reply" || 
          a.action === "document_upload"
        );
      }
    }
    
    // Filter by date
    const now = new Date();
    if (dateFilter === "today") {
      filtered = filtered.filter(a => {
        const date = new Date(a.timestamp);
        return date.getDate() === now.getDate() && 
               date.getMonth() === now.getMonth() && 
               date.getFullYear() === now.getFullYear();
      });
    } else if (dateFilter === "yesterday") {
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      filtered = filtered.filter(a => {
        const date = new Date(a.timestamp);
        return date.getDate() === yesterday.getDate() && 
               date.getMonth() === yesterday.getMonth() && 
               date.getFullYear() === yesterday.getFullYear();
      });
    } else if (dateFilter === "week") {
      const weekAgo = new Date(now);
      weekAgo.setDate(weekAgo.getDate() - 7);
      filtered = filtered.filter(a => new Date(a.timestamp) >= weekAgo);
    }
    
    return filtered;
  };
  
  const filteredActivities = filterActivities();
  
  const getActivityGroups = () => {
    const groups = {};
    
    filteredActivities.forEach(activity => {
      const date = new Date(activity.timestamp);
      const dateKey = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
      
      if (!groups[dateKey]) {
        groups[dateKey] = {
          dateLabel: formatDateGroup(date),
          activities: []
        };
      }
      
      groups[dateKey].activities.push(activity);
    });
    
    return Object.values(groups);
  };
  
  const formatDateGroup = (date) => {
    const today = new Date();
    if (date.getDate() === today.getDate() && 
        date.getMonth() === today.getMonth() && 
        date.getFullYear() === today.getFullYear()) {
      return "Hoje";
    }
    
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.getDate() === yesterday.getDate() && 
        date.getMonth() === yesterday.getMonth() && 
        date.getFullYear() === yesterday.getFullYear()) {
      return "Ontem";
    }
    
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  const activityGroups = getActivityGroups();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Registro de Atividades</h1>
          <p className="text-gray-500 mt-1">
            Histórico de ações realizadas no sistema
          </p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          Exportar
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <Select value={activityFilter} onValueChange={setActivityFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <SelectValue placeholder="Tipo de Atividade" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas Atividades</SelectItem>
            <SelectItem value="organization">Organizações</SelectItem>
            <SelectItem value="user">Usuários</SelectItem>
            <SelectItem value="system">Sistema</SelectItem>
            <SelectItem value="support">Suporte</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={dateFilter} onValueChange={setDateFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <SelectValue placeholder="Período" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Hoje</SelectItem>
            <SelectItem value="yesterday">Ontem</SelectItem>
            <SelectItem value="week">Última Semana</SelectItem>
            <SelectItem value="all">Todo Período</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {activityGroups.length === 0 ? (
        <Card className="p-8 text-center">
          <Activity className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <h3 className="text-lg font-medium text-gray-900">Nenhuma atividade registrada</h3>
          <p className="text-gray-500 mt-1">
            Não há atividades registradas para o período e filtros selecionados.
          </p>
        </Card>
      ) : (
        <div className="space-y-8">
          {activityGroups.map((group, groupIndex) => (
            <div key={groupIndex} className="space-y-4">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-200"></div>
                </div>
                <div className="relative flex justify-center">
                  <span className="bg-gray-100 px-4 py-1 text-sm font-medium text-gray-500 rounded-full">
                    {group.dateLabel}
                  </span>
                </div>
              </div>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    {group.activities.map((activity) => (
                      <div key={activity.id} className="flex gap-4">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-blue-100 text-blue-800">
                            {activity.user.avatar}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{activity.user.name}</span>
                            <Badge className={actionColors[activity.action]}>
                              <div className="flex items-center gap-1">
                                {actionIcons[activity.action]}
                                <span className="capitalize">
                                  {activity.action.replace(/_/g, ' ')}
                                </span>
                              </div>
                            </Badge>
                          </div>
                          
                          <p className="text-gray-700">{activity.details}</p>
                          
                          <div className="flex items-center gap-2 text-sm text-gray-500">
                            <div className="flex items-center gap-1">
                              {entityIcons[activity.entity] || <Building2 className="w-4 h-4 text-gray-400" />}
                              <span>{activity.entity}</span>
                            </div>
                            <span>•</span>
                            <div className="flex items-center gap-1">
                              <Clock className="w-4 h-4 text-gray-400" />
                              <span>{formatDate(activity.timestamp)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}