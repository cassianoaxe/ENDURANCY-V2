import React, { useState } from 'react';
import { 
  FilePlus2, 
  Save, 
  XCircle, 
  Plus, 
  Trash2, 
  Calendar,
  Users,
  FileText,
  Tag,
  BookOpen,
  Brain,
  Target,
  Microscope,
  UserPlus,
  FileCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar as CalendarPicker } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function NovaPesquisa() {
  const [activeTab, setActiveTab] = useState("informacoes");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [tiposPesquisa] = useState([
    "Estudo clínico",
    "Estudo observacional",
    "Pesquisa básica",
    "Ensaio controlado",
    "Estudo de caso",
    "Meta-análise"
  ]);
  const [areas] = useState([
    "Neurologia",
    "Psiquiatria",
    "Dor crônica",
    "Oncologia",
    "Autismo",
    "Epilepsia",
    "Farmacologia",
    "Outro"
  ]);

  const [criteriosInclusao, setCriteriosInclusao] = useState(['']);
  const [criteriosExclusao, setCriteriosExclusao] = useState(['']);
  const [membrosEquipe, setMembrosEquipe] = useState([
    { nome: '', funcao: '', instituicao: '' }
  ]);

  const addCriterio = (tipo) => {
    if (tipo === 'inclusao') {
      setCriteriosInclusao([...criteriosInclusao, '']);
    } else {
      setCriteriosExclusao([...criteriosExclusao, '']);
    }
  };

  const removeCriterio = (tipo, index) => {
    if (tipo === 'inclusao') {
      const newCriterios = [...criteriosInclusao];
      newCriterios.splice(index, 1);
      setCriteriosInclusao(newCriterios);
    } else {
      const newCriterios = [...criteriosExclusao];
      newCriterios.splice(index, 1);
      setCriteriosExclusao(newCriterios);
    }
  };

  const updateCriterio = (tipo, index, value) => {
    if (tipo === 'inclusao') {
      const newCriterios = [...criteriosInclusao];
      newCriterios[index] = value;
      setCriteriosInclusao(newCriterios);
    } else {
      const newCriterios = [...criteriosExclusao];
      newCriterios[index] = value;
      setCriteriosExclusao(newCriterios);
    }
  };

  const addMembroEquipe = () => {
    setMembrosEquipe([...membrosEquipe, { nome: '', funcao: '', instituicao: '' }]);
  };

  const removeMembroEquipe = (index) => {
    const newMembros = [...membrosEquipe];
    newMembros.splice(index, 1);
    setMembrosEquipe(newMembros);
  };

  const updateMembroEquipe = (index, field, value) => {
    const newMembros = [...membrosEquipe];
    newMembros[index][field] = value;
    setMembrosEquipe(newMembros);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Nova Pesquisa</h1>
          <p className="text-muted-foreground">Cadastre uma nova pesquisa científica</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <XCircle className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button className="bg-green-600 hover:bg-green-700">
            <Save className="w-4 h-4 mr-2" />
            Salvar
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="informacoes" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Informações Básicas
          </TabsTrigger>
          <TabsTrigger value="metodologia" className="flex items-center gap-2">
            <Microscope className="w-4 h-4" />
            Metodologia
          </TabsTrigger>
          <TabsTrigger value="equipe" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Equipe
          </TabsTrigger>
          <TabsTrigger value="documentos" className="flex items-center gap-2">
            <FileCheck className="w-4 h-4" />
            Documentos
          </TabsTrigger>
        </TabsList>

        <TabsContent value="informacoes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Informações Básicas</CardTitle>
              <CardDescription>Preencha as informações básicas da pesquisa</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Título da Pesquisa</label>
                <Input placeholder="Digite o título da pesquisa" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Tipo de Pesquisa</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {tiposPesquisa.map((tipo) => (
                        <SelectItem key={tipo} value={tipo}>{tipo}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Área Principal</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a área" />
                    </SelectTrigger>
                    <SelectContent>
                      {areas.map((area) => (
                        <SelectItem key={area} value={area}>{area}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Descrição</label>
                <Textarea 
                  placeholder="Descreva os objetivos e o contexto da pesquisa"
                  className="min-h-[100px]"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Data de Início</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        {format(selectedDate, "PPP", { locale: ptBR })}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarPicker
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        locale={ptBR}
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Previsão de Conclusão</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        {format(selectedDate, "PPP", { locale: ptBR })}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarPicker
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        locale={ptBR}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="metodologia" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Metodologia</CardTitle>
              <CardDescription>Defina a metodologia e os critérios da pesquisa</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Metodologia Detalhada</label>
                <Textarea 
                  placeholder="Descreva a metodologia que será utilizada na pesquisa"
                  className="min-h-[150px]"
                />
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-medium">Critérios de Inclusão</label>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => addCriterio('inclusao')}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar
                  </Button>
                </div>
                <div className="space-y-2">
                  {criteriosInclusao.map((criterio, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        value={criterio}
                        onChange={(e) => updateCriterio('inclusao', index, e.target.value)}
                        placeholder="Digite o critério de inclusão"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeCriterio('inclusao', index)}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-medium">Critérios de Exclusão</label>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => addCriterio('exclusao')}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar
                  </Button>
                </div>
                <div className="space-y-2">
                  {criteriosExclusao.map((criterio, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        value={criterio}
                        onChange={(e) => updateCriterio('exclusao', index, e.target.value)}
                        placeholder="Digite o critério de exclusão"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeCriterio('exclusao', index)}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="equipe" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Equipe de Pesquisa</CardTitle>
              <CardDescription>Adicione os membros da equipe de pesquisa</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <Button 
                variant="outline"
                onClick={addMembroEquipe}
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Adicionar Membro
              </Button>

              <div className="space-y-4">
                {membrosEquipe.map((membro, index) => (
                  <div key={index} className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 border rounded-lg relative">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 right-2"
                      onClick={() => removeMembroEquipe(index)}
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Nome</label>
                      <Input
                        value={membro.nome}
                        onChange={(e) => updateMembroEquipe(index, 'nome', e.target.value)}
                        placeholder="Nome do pesquisador"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Função</label>
                      <Input
                        value={membro.funcao}
                        onChange={(e) => updateMembroEquipe(index, 'funcao', e.target.value)}
                        placeholder="Função na pesquisa"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Instituição</label>
                      <Input
                        value={membro.instituicao}
                        onChange={(e) => updateMembroEquipe(index, 'instituicao', e.target.value)}
                        placeholder="Instituição vinculada"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documentos" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Documentos</CardTitle>
              <CardDescription>Faça upload dos documentos relacionados à pesquisa</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border-2 border-dashed rounded-lg p-6 text-center">
                  <FilePlus2 className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <h3 className="text-sm font-medium mb-1">Projeto de Pesquisa</h3>
                  <p className="text-sm text-gray-500 mb-2">Upload do projeto detalhado</p>
                  <Button variant="outline" size="sm">Selecionar Arquivo</Button>
                </div>

                <div className="border-2 border-dashed rounded-lg p-6 text-center">
                  <FilePlus2 className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <h3 className="text-sm font-medium mb-1">Aprovação do Comitê de Ética</h3>
                  <p className="text-sm text-gray-500 mb-2">Upload do documento de aprovação</p>
                  <Button variant="outline" size="sm">Selecionar Arquivo</Button>
                </div>

                <div className="border-2 border-dashed rounded-lg p-6 text-center">
                  <FilePlus2 className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <h3 className="text-sm font-medium mb-1">Termo de Consentimento</h3>
                  <p className="text-sm text-gray-500 mb-2">Upload do TCLE</p>
                  <Button variant="outline" size="sm">Selecionar Arquivo</Button>
                </div>

                <div className="border-2 border-dashed rounded-lg p-6 text-center">
                  <FilePlus2 className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <h3 className="text-sm font-medium mb-1">Outros Documentos</h3>
                  <p className="text-sm text-gray-500 mb-2">Upload de documentos adicionais</p>
                  <Button variant="outline" size="sm">Selecionar Arquivo</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}