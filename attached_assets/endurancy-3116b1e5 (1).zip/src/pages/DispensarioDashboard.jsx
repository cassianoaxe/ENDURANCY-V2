
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { toast } from "@/components/ui/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ShoppingBag, Package, BarChart, FileText, 
  AlertTriangle, TrendingUp, Users, Calendar, DollarSign, 
  ChevronRight, BarChart2, ArrowUp, ArrowDown
} from 'lucide-react';

export default function DispensarioDashboard() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [resumo, setResumo] = useState({
    vendasHoje: 0,
    valorVendasHoje: 0,
    totalProdutos: 0,
    produtosEmEstoqueBaixo: 0,
    receitasAtendidas: 0,
    clientesAtendidos: 0
  });

  useEffect(() => {
    const loadData = () => {
      try {
        const userType = localStorage.getItem('mockUserType');
        if (!userType) {
          console.log("User not authenticated, redirecting to login");
          navigate(createPageUrl("Access"));
          return;
        }

        // Load mock data with more realistic values
        setResumo({
          vendasHoje: 12,
          valorVendasHoje: 3458.90,
          totalProdutos: 87,
          produtosEmEstoqueBaixo: 5,
          receitasAtendidas: 8,
          clientesAtendidos: 15
        });
        
        setIsLoading(false);
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar os dados do dashboard.",
          variant: "destructive",
        });
      }
    };

    loadData();
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-green-200 border-t-green-600"></div>
          <p className="text-sm text-gray-500">Carregando informações do módulo...</p>
        </div>
      </div>
    );
  }

  const menuItems = [
    { 
      title: "Ponto de Venda (PDV)", 
      description: "Realizar vendas e dispensação de medicamentos",
      icon: ShoppingBag,
      url: "PDV",
      color: "bg-green-100 text-green-800"
    },
    { 
      title: "Estoque", 
      description: "Gerenciar produtos, lotes e movimentações",
      icon: Package,
      url: "EstoqueDispensario",
      color: "bg-blue-100 text-blue-800"
    },
    { 
      title: "Receituário", 
      description: "Gerenciar receitas médicas",
      icon: FileText,
      url: "GerenciarReceituario",
      color: "bg-purple-100 text-purple-800"
    },
    { 
      title: "Caixa", 
      description: "Gerenciar operações de caixa",
      icon: DollarSign,
      url: "DispensarioCaixa",
      color: "bg-yellow-100 text-yellow-800"
    },
    { 
      title: "Relatórios", 
      description: "Relatórios de vendas e operações",
      icon: BarChart,
      url: "RelatorioDispensario",
      color: "bg-indigo-100 text-indigo-800"
    },
    { 
      title: "SNGPC", 
      description: "Relatórios para o Sistema Nacional de Gerenciamento de Produtos Controlados",
      icon: FileText,
      url: "RelatorioSNGPC",
      color: "bg-red-100 text-red-800"
    }
  ];

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Dashboard do Dispensário</h1>
          <p className="text-gray-500">Visão geral da operação de dispensário da sua organização</p>
        </div>
        <Button 
          onClick={() => navigate(createPageUrl("PDV"))}
          className="bg-green-600 hover:bg-green-700"
        >
          <ShoppingBag className="mr-2 h-4 w-4" />
          Abrir PDV
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Vendas de Hoje</CardTitle>
            <DollarSign className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{resumo.vendasHoje}</div>
            <p className="text-xs text-gray-500">
              Total: R$ {resumo.valorVendasHoje.toFixed(2)}
            </p>
            <div className="mt-4 flex items-center text-xs text-green-500">
              <ArrowUp className="mr-1 h-4 w-4" />
              <span>12% em relação a ontem</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Produtos em Estoque</CardTitle>
            <Package className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{resumo.totalProdutos}</div>
            <p className="text-xs text-gray-500">
              {resumo.produtosEmEstoqueBaixo} em estoque baixo
            </p>
            {resumo.produtosEmEstoqueBaixo > 0 && (
              <div className="mt-4 flex items-center text-xs text-amber-500">
                <AlertTriangle className="mr-1 h-4 w-4" />
                <span>Produtos precisam de reposição</span>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Receitas Atendidas</CardTitle>
            <FileText className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{resumo.receitasAtendidas}</div>
            <p className="text-xs text-gray-500">
              {resumo.clientesAtendidos} clientes atendidos
            </p>
            <div className="mt-4 flex items-center text-xs text-green-500">
              <TrendingUp className="mr-1 h-4 w-4" />
              <span>5% de aumento nesta semana</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Acesso Rápido</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {menuItems.map((item, index) => (
            <Card 
              key={index}
              className="hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => navigate(createPageUrl(item.url))}
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-lg ${item.color}`}>
                    <item.icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium">{item.title}</h3>
                    <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Tabs defaultValue="vendas" className="mt-6">
        <TabsList className="mb-6">
          <TabsTrigger value="vendas" className="flex items-center">
            <ShoppingBag className="mr-2 h-4 w-4" />
            Vendas
          </TabsTrigger>
          <TabsTrigger value="estoque" className="flex items-center">
            <Package className="mr-2 h-4 w-4" />
            Estoque
          </TabsTrigger>
          <TabsTrigger value="receitas" className="flex items-center">
            <FileText className="mr-2 h-4 w-4" />
            Receituário
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="vendas">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Vendas</CardTitle>
              <CardDescription>Acompanhe as vendas mais recentes</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="p-6">
                <Button
                  onClick={() => navigate(createPageUrl("PDV"))}
                  className="w-full"
                >
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  Abrir PDV para Nova Venda
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="estoque">
          <Card>
            <CardHeader>
              <CardTitle>Produtos em Estoque Baixo</CardTitle>
              <CardDescription>
                Produtos que necessitam de reposição em breve
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="p-6">
                <Button
                  onClick={() => navigate(createPageUrl("EstoqueDispensario"))}
                  className="w-full"
                >
                  <Package className="mr-2 h-4 w-4" />
                  Gerenciar Estoque
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="receitas">
          <Card>
            <CardHeader>
              <CardTitle>Receituários Pendentes</CardTitle>
              <CardDescription>
                Receituários que precisam ser enviados ao SNGPC
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="p-6">
                <Button
                  onClick={() => navigate(createPageUrl("GerenciarReceituario"))}
                  className="w-full"
                >
                  <FileText className="mr-2 h-4 w-4" />
                  Gerenciar Receituário
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
