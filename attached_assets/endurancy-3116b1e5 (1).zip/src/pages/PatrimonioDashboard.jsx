import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Landmark, 
  Building2, 
  FileBox, 
  Wrench, 
  Calendar, 
  ClipboardList, 
  TrendingUp,
  ArrowDownUp,
  Search,
  Filter,
  AlertTriangle,
  Clock,
  Settings,
  MoreHorizontal,
  CheckCircle2,
  Ban,
  Activity,
  Hammer,
  ListChecks,
  Tag,
  Banknote
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

// Dados mockados para o dashboard
const mockStats = {
  instalacoes: 5,
  equipamentos: 128,
  manutencoesPendentes: 7,
  manutencoesConcluidas: 18,
  valorPatrimonio: 2540000
};

const mockInstalacoes = [
  { 
    id: 'inst1',
    nome: 'Sede São Paulo',
    tipo: 'escritorio',
    endereco: 'Av. Paulista, 1000, São Paulo, SP',
    area: 450,
    ocupacao: 85,
    status: 'ativo',
    valor_aquisicao: 1200000,
    data_aquisicao: '2021-05-10',
    despesas_mensais: 28000
  },
  { 
    id: 'inst2',
    nome: 'Centro de Cultivo A',
    tipo: 'cultivo',
    endereco: 'Rod. Raposo Tavares, km 30, Cotia, SP',
    area: 1500,
    ocupacao: 70,
    status: 'ativo',
    valor_aquisicao: 800000,
    data_aquisicao: '2022-03-15',
    despesas_mensais: 42000
  },
  { 
    id: 'inst3',
    nome: 'Laboratório e Produção',
    tipo: 'producao',
    endereco: 'Rua das Indústrias, 500, Guarulhos, SP',
    area: 750,
    ocupacao: 90,
    status: 'ativo',
    valor_aquisicao: 450000,
    data_aquisicao: '2022-08-20',
    despesas_mensais: 35000
  },
  { 
    id: 'inst4',
    nome: 'Centro de Pesquisa',
    tipo: 'pesquisa',
    endereco: 'Rua dos Laboratórios, 200, Campinas, SP',
    area: 320,
    ocupacao: 65,
    status: 'ativo',
    valor_aquisicao: 280000,
    data_aquisicao: '2023-01-10',
    despesas_mensais: 18000
  },
  { 
    id: 'inst5',
    nome: 'Armazém Logístico',
    tipo: 'armazem',
    endereco: 'Av. Industrial, 800, Barueri, SP',
    area: 600,
    ocupacao: 50,
    status: 'ativo',
    valor_aquisicao: 350000,
    data_aquisicao: '2023-04-05',
    despesas_mensais: 12000
  }
];

const mockEquipamentosCategorias = [
  { 
    categoria: 'Cultivo',
    quantidade: 42,
    valor_total: 680000,
    manutencoes_pendentes: 3
  },
  { 
    categoria: 'Laboratório',
    quantidade: 35,
    valor_total: 850000,
    manutencoes_pendentes: 2
  },
  { 
    categoria: 'Produção',
    quantidade: 28,
    valor_total: 520000,
    manutencoes_pendentes: 1
  },
  { 
    categoria: 'TI',
    quantidade: 18,
    valor_total: 120000,
    manutencoes_pendentes: 1
  },
  { 
    categoria: 'Mobiliário',
    quantidade: 5,
    valor_total: 50000,
    manutencoes_pendentes: 0
  }
];

const mockManutencoes = [
  {
    id: 'man1',
    tipo: 'preventiva',
    equipamento_id: 'eq23',
    equipamento_nome: 'Sistema de Irrigação - Cultivo A',
    prioridade: 'media',
    status: 'pendente',
    data_agendada: '2023-08-10',
    responsavel: 'Técnico Especializado Externo',
    custo_estimado: 1800,
    descricao: 'Manutenção preventiva do sistema de irrigação automatizado'
  },
  {
    id: 'man2',
    tipo: 'corretiva',
    equipamento_id: 'eq15',
    equipamento_nome: 'Cromatógrafo HPLC',
    prioridade: 'alta',
    status: 'pendente',
    data_agendada: '2023-08-05',
    responsavel: 'Suporte Técnico do Fabricante',
    custo_estimado: 3500,
    descricao: 'Falha na calibração automática, necessário reparo urgente'
  },
  {
    id: 'man3',
    tipo: 'preventiva',
    equipamento_id: 'eq42',
    equipamento_nome: 'Gerador de Energia - Sede',
    prioridade: 'baixa',
    status: 'pendente',
    data_agendada: '2023-08-18',
    responsavel: 'Equipe de Manutenção Interna',
    custo_estimado: 800,
    descricao: 'Manutenção preventiva semestral do gerador'
  },
  {
    id: 'man4',
    tipo: 'corretiva',
    equipamento_id: 'eq31',
    equipamento_nome: 'Sistema de Climatização - Cultivo A',
    prioridade: 'alta',
    status: 'pendente',
    data_agendada: '2023-08-07',
    responsavel: 'ServiceClima Ltda',
    custo_estimado: 2200,
    descricao: 'Falha no sistema de controle de temperatura da sala de vegetação'
  },
  {
    id: 'man5',
    tipo: 'preventiva',
    equipamento_id: 'eq08',
    equipamento_nome: 'Máquina de Envase',
    prioridade: 'media',
    status: 'pendente',
    data_agendada: '2023-08-15',
    responsavel: 'Equipe de Manutenção Interna',
    custo_estimado: 600,
    descricao: 'Manutenção preventiva mensal da máquina de envase'
  }
];

const mockDespesasMensais = [
  { 
    mes: 'Jan', 
    manutencao: 18500, 
    energia: 32000, 
    agua: 8500, 
    outros: 15000
  },
  { 
    mes: 'Fev', 
    manutencao: 12800, 
    energia: 30000, 
    agua: 9000, 
    outros: 14000
  },
  { 
    mes: 'Mar', 
    manutencao: 22000, 
    energia: 31500, 
    agua: 8800, 
    outros: 15500
  },
  { 
    mes: 'Abr', 
    manutencao: 15000, 
    energia: 33000, 
    agua: 9200, 
    outros: 16000
  },
  { 
    mes: 'Mai', 
    manutencao: 17500, 
    energia: 34000, 
    agua: 9500, 
    outros: 15800
  },
  { 
    mes: 'Jun', 
    manutencao: 19200, 
    energia: 35500, 
    agua: 10000, 
    outros: 16500
  },
  { 
    mes: 'Jul', 
    manutencao: 21000, 
    energia: 36000, 
    agua: 10200, 
    outros: 17000
  }
];

const mockValorPorCategoria = [
  { nome: 'Instalações', valor: 3080000 },
  { nome: 'Equipamentos', valor: 2220000 },
  { nome: 'Veículos', valor: 320000 },
  { nome: 'Outros', valor: 120000 }
];

const mockStatusEquipamentos = [
  { nome: 'Operacional', valor: 110 },
  { nome: 'Em Manutenção', valor: 12 },
  { nome: 'Inativo', valor: 6 }
];

// Componente de Estatísticas
const StatsSection = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-6">
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Instalações</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.instalacoes}</CardTitle>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Building2 className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-blue-600 mt-2">
            <TrendingUp className="w-4 h-4 mr-1" />
            <span>5 locais ativos</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Equipamentos</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.equipamentos}</CardTitle>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <FileBox className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-green-600 mt-2">
            <CheckCircle2 className="w-4 h-4 mr-1" />
            <span>110 operacionais</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Manutenções Pendentes</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.manutencoesPendentes}</CardTitle>
            </div>
            <div className="p-3 bg-amber-50 rounded-lg">
              <Clock className="w-5 h-5 text-amber-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-amber-600 mt-2">
            <AlertTriangle className="w-4 h-4 mr-1" />
            <span>2 de alta prioridade</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Manutenções Realizadas</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.manutencoesConcluidas}</CardTitle>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <Wrench className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-purple-600 mt-2">
            <ClipboardList className="w-4 h-4 mr-1" />
            <span>No último mês</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Valor do Patrimônio</CardDescription>
              <CardTitle className="text-3xl font-bold">R$ {(stats.valorPatrimonio / 1000000).toFixed(2)}M</CardTitle>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <Banknote className="w-5 h-5 text-red-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-red-600 mt-2">
            <TrendingUp className="w-4 h-4 mr-1" />
            <span>+5.2% este ano</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Gráfico de Barras Empilhadas - Despesas Mensais
const DespesasMensaisChart = ({ data }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Despesas Mensais</CardTitle>
        <CardDescription>Principais despesas operacionais</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="mes" />
              <YAxis />
              <Tooltip formatter={(value) => `R$ ${value.toLocaleString()}`} />
              <Legend />
              <Bar dataKey="manutencao" name="Manutenção" stackId="a" fill="#8884d8" />
              <Bar dataKey="energia" name="Energia" stackId="a" fill="#4CAF50" />
              <Bar dataKey="agua" name="Água" stackId="a" fill="#2196F3" />
              <Bar dataKey="outros" name="Outros" stackId="a" fill="#FFC107" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Gráfico de Pizza - Valor por Categoria
const ValorPorCategoriaChart = ({ data }) => {
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Distribuição do Patrimônio</CardTitle>
        <CardDescription>Valor por categoria de ativo</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="valor"
                label={({ nome, percent }) => `${nome} ${(percent * 100).toFixed(0)}%`}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value) => `R$ ${(value / 1000000).toFixed(2)}M`}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Gráfico de Status dos Equipamentos
const StatusEquipamentosChart = ({ data }) => {
  const COLORS = ['#4CAF50', '#FFC107', '#F44336'];
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Status dos Equipamentos</CardTitle>
        <CardDescription>Distribuição por estado operacional</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="valor"
                label={({ nome, percent }) => `${nome} ${(percent * 100).toFixed(0)}%`}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Instalações
const InstalacoesSection = ({ instalacoes }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Instalações</CardTitle>
            <CardDescription>Unidades e propriedades da empresa</CardDescription>
          </div>
          <Link to={createPageUrl("PatrimonioInstalacoes")}>
            <Button variant="outline" size="sm">Ver Todas</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {instalacoes.map((instalacao, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">{instalacao.nome}</p>
                  <p className="text-sm text-gray-500">{instalacao.endereco}</p>
                </div>
                <Badge 
                  className={
                    instalacao.tipo === 'cultivo' ? 'bg-green-100 text-green-800' :
                    instalacao.tipo === 'producao' ? 'bg-blue-100 text-blue-800' :
                    instalacao.tipo === 'escritorio' ? 'bg-purple-100 text-purple-800' :
                    instalacao.tipo === 'pesquisa' ? 'bg-amber-100 text-amber-800' :
                    'bg-gray-100 text-gray-800'
                  }
                >
                  <span className="capitalize">{instalacao.tipo}</span>
                </Badge>
              </div>
              
              <div className="mt-3">
                <div className="flex justify-between items-center text-sm mb-2">
                  <span className="text-gray-600">Área: {instalacao.area} m²</span>
                  <span className="text-gray-600">Ocupação: {instalacao.ocupacao}%</span>
                </div>
                <Progress value={instalacao.ocupacao} className="h-2" />
              </div>
              
              <div className="mt-3 flex justify-between text-sm">
                <div className="flex items-center">
                  <Tag className="w-3.5 h-3.5 mr-1 text-gray-500" />
                  <span className="text-gray-600">Valor: R$ {instalacao.valor_aquisicao.toLocaleString()}</span>
                </div>
                <div className="flex items-center">
                  <Banknote className="w-3.5 h-3.5 mr-1 text-gray-500" />
                  <span className="text-gray-600">Despesa: R$ {instalacao.despesas_mensais.toLocaleString()}/mês</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Equipamentos por Categoria
const EquipamentosCategoriaSection = ({ categorias }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Equipamentos por Categoria</CardTitle>
            <CardDescription>Distribuição e valor por tipo</CardDescription>
          </div>
          <Link to={createPageUrl("PatrimonioEquipamentos")}>
            <Button variant="outline" size="sm">Ver Todos</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {categorias.map((categoria, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">{categoria.categoria}</p>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <FileBox className="w-3.5 h-3.5 mr-1" />
                    <span>{categoria.quantidade} equipamentos</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium">R$ {(categoria.valor_total / 1000).toFixed(0)}k</p>
                  <p className="text-sm text-gray-500">Valor total</p>
                </div>
              </div>
              
              {categoria.manutencoes_pendentes > 0 && (
                <div className="mt-3 bg-amber-50 text-amber-800 p-2 rounded-lg text-sm flex items-center">
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  <span>{categoria.manutencoes_pendentes} manutenções pendentes</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Manutenções Pendentes
const ManutencoesSection = ({ manutencoes }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Manutenções Pendentes</CardTitle>
            <CardDescription>Serviços programados e emergenciais</CardDescription>
          </div>
          <Link to={createPageUrl("PatrimonioManutencoes")}>
            <Button variant="outline" size="sm">Ver Todas</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {manutencoes.map((manutencao, index) => (
            <div 
              key={index} 
              className={`border rounded-lg p-4 ${
                manutencao.prioridade === 'alta' ? 'border-red-200' :
                manutencao.prioridade === 'media' ? 'border-amber-200' :
                'border-gray-200'
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">{manutencao.equipamento_nome}</p>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <Wrench className="w-3.5 h-3.5 mr-1" />
                    <span className="capitalize">{manutencao.tipo}</span>
                    <span className="mx-2">•</span>
                    <span>ID: {manutencao.equipamento_id}</span>
                  </div>
                </div>
                <Badge 
                  className={
                    manutencao.prioridade === 'alta' ? 'bg-red-100 text-red-800' :
                    manutencao.prioridade === 'media' ? 'bg-amber-100 text-amber-800' :
                    'bg-green-100 text-green-800'
                  }
                >
                  <span className="capitalize">{manutencao.prioridade} prioridade</span>
                </Badge>
              </div>
              
              <div className="mt-3 text-sm text-gray-600">
                <p>{manutencao.descricao}</p>
              </div>
              
              <div className="mt-3 flex justify-between text-sm">
                <div className="flex items-center">
                  <Calendar className="w-3.5 h-3.5 mr-1 text-gray-500" />
                  <span className="text-gray-600">Agendada: {new Date(manutencao.data_agendada).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center">
                  <Banknote className="w-3.5 h-3.5 mr-1 text-gray-500" />
                  <span className="text-gray-600">Custo: R$ {manutencao.custo_estimado.toLocaleString()}</span>
                </div>
              </div>
              
              <div className="mt-3 flex justify-between">
                <span className="text-sm text-gray-600">Responsável: {manutencao.responsavel}</span>
                <Button size="sm">Detalhes</Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Principal
export default function PatrimonioDashboard() {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({});
  const [instalacoes, setInstalacoes] = useState([]);
  const [equipamentosCategorias, setEquipamentosCategorias] = useState([]);
  const [manutencoes, setManutencoes] = useState([]);
  const [despesasMensais, setDespesasMensais] = useState([]);
  const [valorPorCategoria, setValorPorCategoria] = useState([]);
  const [statusEquipamentos, setStatusEquipamentos] = useState([]);
  const [periodFilter, setPeriodFilter] = useState('month');
  
  useEffect(() => {
    loadDashboardData();
  }, [periodFilter]);
  
  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      
      // Em produção, aqui seriam chamadas para as APIs reais
      // Simulando carregamento
      setTimeout(() => {
        setStats(mockStats);
        setInstalacoes(mockInstalacoes);
        setEquipamentosCategorias(mockEquipamentosCategorias);
        setManutencoes(mockManutencoes);
        setDespesasMensais(mockDespesasMensais);
        setValorPorCategoria(mockValorPorCategoria);
        setStatusEquipamentos(mockStatusEquipamentos);
        setIsLoading(false);
      }, 800);
      
    } catch (error) {
      console.error("Erro ao carregar dados do dashboard:", error);
      setIsLoading(false);
    }
  };
  
  const handleRefresh = () => {
    loadDashboardData();
  };
  
  const handlePeriodChange = (value) => {
    setPeriodFilter(value);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Dashboard Patrimônio</h1>
          <p className="text-gray-500 mt-1">
            Gestão de instalações, equipamentos e manutenções
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <Select value={periodFilter} onValueChange={handlePeriodChange}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Última Semana</SelectItem>
              <SelectItem value="month">Último Mês</SelectItem>
              <SelectItem value="quarter">Último Trimestre</SelectItem>
              <SelectItem value="year">Último Ano</SelectItem>
            </SelectContent>
          </Select>
          
          <Button onClick={handleRefresh} variant="outline" className="gap-2">
            <ArrowDownUp className="w-4 h-4" />
            Atualizar
          </Button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
          <p className="ml-2">Carregando dados do dashboard...</p>
        </div>
      ) : (
        <>
          <StatsSection stats={stats} />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <DespesasMensaisChart data={despesasMensais} />
            </div>
            <ValorPorCategoriaChart data={valorPorCategoria} />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <InstalacoesSection instalacoes={instalacoes} />
            </div>
            <StatusEquipamentosChart data={statusEquipamentos} />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <EquipamentosCategoriaSection categorias={equipamentosCategorias} />
            <ManutencoesSection manutencoes={manutencoes} />
          </div>
        </>
      )}
    </div>
  );
}