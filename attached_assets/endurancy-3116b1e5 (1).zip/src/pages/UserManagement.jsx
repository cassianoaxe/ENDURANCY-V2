import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Plus, 
  Search, 
  UserPlus, 
  User, 
  Mail, 
  Key, 
  Lock, 
  Shield, 
  CheckCircle, 
  XCircle, 
  MoreHorizontal, 
  Calendar 
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Sample users data
const users = [
  {
    id: 1,
    name: 'João Silva',
    email: 'joao.silva@cannabismed.com',
    role: 'admin',
    organization: 'Cannabis Brasil Medicinal',
    status: 'active',
    last_login: '2023-07-21T10:30:00Z',
    created_at: '2023-03-15T14:30:00Z'
  },
  {
    id: 2,
    name: 'Maria Oliveira',
    email: 'maria@medverde.org',
    role: 'manager',
    organization: 'Associação Médica Verde',
    status: 'active',
    last_login: '2023-07-20T09:15:00Z',
    created_at: '2023-04-10T11:45:00Z'
  },
  {
    id: 3,
    name: 'Carlos Santos',
    email: 'carlos@apoiomedico.com.br',
    role: 'user',
    organization: 'Apoio Médico Cannabis',
    status: 'active',
    last_login: '2023-07-19T16:20:00Z',
    created_at: '2023-05-05T10:30:00Z'
  },
  {
    id: 4,
    name: 'Ana Costa',
    email: 'ana@cannabismed.com',
    role: 'pharmacist',
    organization: 'Cannabis Brasil Medicinal',
    status: 'active',
    last_login: '2023-07-18T14:45:00Z',
    created_at: '2023-03-20T09:15:00Z'
  },
  {
    id: 5,
    name: 'Pedro Almeida',
    email: 'pedro@cultivo.com.br',
    role: 'admin',
    organization: 'Cultivo Sustentável Ltda',
    status: 'suspended',
    last_login: '2023-07-15T11:30:00Z',
    created_at: '2023-06-01T15:20:00Z'
  },
  {
    id: 6,
    name: 'Lúcia Mendes',
    email: 'lucia@terapiacannabia.org',
    role: 'doctor',
    organization: 'Terapia Cannábica Sociedade',
    status: 'pending',
    last_login: null,
    created_at: '2023-07-19T13:10:00Z'
  }
];

// Sample organizations
const organizations = [
  { id: 1, name: 'Cannabis Brasil Medicinal' },
  { id: 2, name: 'Associação Médica Verde' },
  { id: 3, name: 'Apoio Médico Cannabis' },
  { id: 4, name: 'Cultivo Sustentável Ltda' },
  { id: 5, name: 'Terapia Cannábica Sociedade' }
];

const roleStyles = {
  admin: "bg-purple-100 text-purple-800",
  manager: "bg-blue-100 text-blue-800",
  user: "bg-gray-100 text-gray-800",
  doctor: "bg-green-100 text-green-800",
  pharmacist: "bg-yellow-100 text-yellow-800"
};

const statusStyles = {
  active: "bg-green-100 text-green-800",
  suspended: "bg-red-100 text-red-800",
  pending: "bg-yellow-100 text-yellow-800"
};

const roleLabels = {
  admin: "Administrador",
  manager: "Gerente",
  user: "Usuário",
  doctor: "Médico",
  pharmacist: "Farmacêutico"
};

export default function UserManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [organizationFilter, setOrganizationFilter] = useState("all");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: 'user',
    organization: '',
    sendInvite: true
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewUser(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAddUser = () => {
    // In a real app, you would add the user to the database
    alert(`Usuário ${newUser.name} adicionado com sucesso!`);
    setShowAddDialog(false);
    setNewUser({
      name: '',
      email: '',
      role: 'user',
      organization: '',
      sendInvite: true
    });
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.organization.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || user.status === statusFilter;
    const matchesOrganization = organizationFilter === "all" || user.organization === organizationFilter;
    
    return matchesSearch && matchesStatus && matchesOrganization;
  });

  const getInitials = (name) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gerenciamento de Usuários</h1>
          <p className="text-gray-500 mt-1">
            Gerencie os usuários das organizações
          </p>
        </div>
        <Button 
          className="gap-2 bg-green-600 hover:bg-green-700"
          onClick={() => setShowAddDialog(true)}
        >
          <UserPlus className="w-4 h-4" />
          Novo Usuário
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div className="w-full md:w-auto flex flex-col md:flex-row gap-4">
          <div className="relative max-w-sm w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar usuários..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-32">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="active">Ativos</SelectItem>
              <SelectItem value="suspended">Suspensos</SelectItem>
              <SelectItem value="pending">Pendentes</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={organizationFilter} onValueChange={setOrganizationFilter}>
            <SelectTrigger className="w-full md:w-56">
              <SelectValue placeholder="Organização" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as Organizações</SelectItem>
              {organizations.map(org => (
                <SelectItem key={org.id} value={org.name}>
                  {org.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Função</TableHead>
                <TableHead>Organização</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Último Acesso</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                      </Avatar>
                      <span>{user.name}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-400" />
                      {user.email}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={roleStyles[user.role]}>
                      {roleLabels[user.role]}
                    </Badge>
                  </TableCell>
                  <TableCell>{user.organization}</TableCell>
                  <TableCell>
                    {user.status === 'active' && (
                      <Badge className={statusStyles.active}>
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Ativo
                      </Badge>
                    )}
                    {user.status === 'suspended' && (
                      <Badge className={statusStyles.suspended}>
                        <XCircle className="w-3 h-3 mr-1" />
                        Suspenso
                      </Badge>
                    )}
                    {user.status === 'pending' && (
                      <Badge className={statusStyles.pending}>
                        <Calendar className="w-3 h-3 mr-1" />
                        Pendente
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {formatDate(user.last_login)}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Ações</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <User className="w-4 h-4 mr-2" />
                          Editar Perfil
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Lock className="w-4 h-4 mr-2" />
                          Alterar Permissões
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Key className="w-4 h-4 mr-2" />
                          Resetar Senha
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        {user.status === 'active' ? (
                          <DropdownMenuItem className="text-red-600">
                            <XCircle className="w-4 h-4 mr-2" />
                            Suspender Usuário
                          </DropdownMenuItem>
                        ) : user.status === 'suspended' ? (
                          <DropdownMenuItem className="text-green-600">
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Reativar Usuário
                          </DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem>
                            <Mail className="w-4 h-4 mr-2" />
                            Reenviar Convite
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Add User Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <UserPlus className="w-5 h-5" />
              Adicionar Novo Usuário
            </DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome Completo</Label>
              <Input
                id="name"
                name="name"
                value={newUser.name}
                onChange={handleInputChange}
                placeholder="Nome do usuário"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={newUser.email}
                onChange={handleInputChange}
                placeholder="email@exemplo.com"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="role">Função</Label>
              <Select 
                value={newUser.role} 
                onValueChange={(value) => setNewUser({...newUser, role: value})}
              >
                <SelectTrigger id="role">
                  <SelectValue placeholder="Selecione a função" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Administrador</SelectItem>
                  <SelectItem value="manager">Gerente</SelectItem>
                  <SelectItem value="doctor">Médico</SelectItem>
                  <SelectItem value="pharmacist">Farmacêutico</SelectItem>
                  <SelectItem value="user">Usuário</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="organization">Organização</Label>
              <Select 
                value={newUser.organization} 
                onValueChange={(value) => setNewUser({...newUser, organization: value})}
              >
                <SelectTrigger id="organization">
                  <SelectValue placeholder="Selecione a organização" />
                </SelectTrigger>
                <SelectContent>
                  {organizations.map(org => (
                    <SelectItem key={org.id} value={org.name}>
                      {org.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="sendInvite"
                checked={newUser.sendInvite}
                onChange={() => setNewUser({...newUser, sendInvite: !newUser.sendInvite})}
                className="rounded border-gray-300"
              />
              <Label htmlFor="sendInvite">Enviar convite por email</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddUser} className="bg-green-600 hover:bg-green-700">
              Adicionar Usuário
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}