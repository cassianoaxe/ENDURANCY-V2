import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Heart, 
  Users, 
  FileText, 
  ShoppingBag, 
  Calendar, 
  TrendingUp, 
  ArrowUp, 
  ArrowDown, 
  User, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Phone, 
  Mail,
  PieChart,
  BarChart,
  FileCheck2,
  CalendarClock,
  FileSearch,
  Search
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RechartsPieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { Input } from "@/components/ui/input";

// Dados simulados para o dashboard
const summaryData = {
  pacientes_total: 128,
  pacientes_novos_mes: 12,
  perc_pacientes_mes: 10.3,
  prescricoes_ativas: 94,
  prescricoes_novas_mes: 18,
  perc_prescricoes_mes: 8.2,
  pedidos_total_mes: 86,
  perc_pedidos_mes: 12.5,
  valor_total_mes: 42350.0,
  perc_valor_mes: 15.8
};

// Dados para o gráfico de vendas mensais
const salesData = [
  { month: 'Jan', total: 28500 },
  { month: 'Fev', total: 32400 },
  { month: 'Mar', total: 30900 },
  { month: 'Abr', total: 33800 },
  { month: 'Mai', total: 35600 },
  { month: 'Jun', total: 36500 },
  { month: 'Jul', total: 42350 }
];

// Dados para o gráfico de novos pacientes
const newPatientsData = [
  { month: 'Jan', count: 8 },
  { month: 'Fev', count: 10 },
  { month: 'Mar', count: 7 },
  { month: 'Abr', count: 9 },
  { month: 'Mai', count: 11 },
  { month: 'Jun', count: 10 },
  { month: 'Jul', count: 12 }
];

// Dados para o gráfico de produtos mais vendidos
const topProductsData = [
  { name: 'Óleo CBD 5% 30ml', value: 32 },
  { name: 'Óleo CBD 10% 10ml', value: 28 },
  { name: 'Cápsulas CBD 20mg', value: 22 },
  { name: 'Óleo CBD 15% 20ml', value: 14 },
  { name: 'Spray CBD 2.5% 30ml', value: 10 }
];

// Cores para o gráfico de pizza
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#A44CD3'];

// Últimos pacientes adicionados
const recentPatients = [
  {
    id: "pac001",
    nome_completo: "Laura Cristina Alves",
    data_registro: "2023-07-01",
    telefone: "(11) 93210-9876",
    email: "laura.alves@email.com",
    status: "ativo",
    condicoes_medicas: ["Fibromialgia", "Insônia"]
  },
  {
    id: "pac002",
    nome_completo: "Carlos Eduardo Santos",
    data_registro: "2023-06-28",
    telefone: "(11) 94321-0987",
    email: "carlos.santos@email.com",
    status: "ativo",
    condicoes_medicas: ["Esclerose Múltipla"]
  },
  {
    id: "pac003",
    nome_completo: "Juliana Ferreira Dias",
    data_registro: "2023-06-25",
    telefone: "(11) 91098-7654",
    email: "juliana.dias@email.com",
    status: "ativo",
    condicoes_medicas: ["Ansiedade", "Depressão"]
  },
  {
    id: "pac004",
    nome_completo: "Roberto Mendes Costa",
    data_registro: "2023-06-22",
    telefone: "(11) 92109-8765",
    email: "roberto.costa@email.com",
    status: "ativo",
    condicoes_medicas: ["Alzheimer", "Hipertensão"]
  }
];

// Últimas prescrições emitidas
const recentPrescriptions = [
  {
    id: "presc001",
    paciente: "Maria Silva Oliveira",
    medico: "Dr. João Carlos Santos",
    data_emissao: "2023-07-05",
    data_validade: "2024-07-05",
    produtos: ["Óleo CBD 5% 30ml", "Spray CBD 2.5% 30ml"]
  },
  {
    id: "presc002",
    paciente: "José Pereira Souza",
    medico: "Dra. Ana Paula Mendes",
    data_emissao: "2023-07-03",
    data_validade: "2024-07-03",
    produtos: ["Óleo CBD 10% 10ml"]
  },
  {
    id: "presc003",
    paciente: "Antônio Carlos Ferreira",
    medico: "Dr. Roberto Almeida",
    data_emissao: "2023-07-01",
    data_validade: "2024-07-01",
    produtos: ["Óleo CBD 15% 20ml", "Creme CBD tópico 50g"]
  },
  {
    id: "presc004",
    paciente: "Laura Cristina Alves",
    medico: "Dra. Sandra Gomes",
    data_emissao: "2023-06-29",
    data_validade: "2024-06-29",
    produtos: ["Gel CBD para dores 100g"]
  }
];

// Últimos pedidos realizados
const recentOrders = [
  {
    id: "ped001",
    paciente: "Maria Silva Oliveira",
    data_pedido: "2023-07-06",
    status: "entregue",
    total: 380.00,
    produtos: ["Óleo CBD 5% 30ml (2x)", "Spray CBD 2.5% 30ml (1x)"]
  },
  {
    id: "ped002",
    paciente: "José Pereira Souza",
    data_pedido: "2023-07-05",
    status: "em_andamento",
    total: 240.00,
    produtos: ["Óleo CBD 10% 10ml (2x)"]
  },
  {
    id: "ped003",
    paciente: "Antônio Carlos Ferreira",
    data_pedido: "2023-07-03",
    status: "entregue",
    total: 530.00,
    produtos: ["Óleo CBD 15% 20ml (2x)", "Creme CBD tópico 50g (1x)"]
  },
  {
    id: "ped004",
    paciente: "Laura Cristina Alves",
    data_pedido: "2023-07-01",
    status: "entregue",
    total: 220.00,
    produtos: ["Gel CBD para dores 100g (2x)"]
  }
];

export default function CrmDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [quickSearchTerm, setQuickSearchTerm] = useState("");

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Dashboard CRM</h1>
          <p className="text-gray-500 mt-1">
            Visão geral de pacientes, prescrições e pedidos
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <FileText className="h-4 w-4" />
            Relatórios
          </Button>
          <Link to={createPageUrl("CrmPacientes")}>
            <Button className="gap-2">
              <Users className="h-4 w-4" />
              Ver Pacientes
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <CardDescription>Pacientes</CardDescription>
                <CardTitle className="text-3xl font-bold">{summaryData.pacientes_total}</CardTitle>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <Users className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm mt-2">
              <div className={`flex items-center ${summaryData.perc_pacientes_mes >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {summaryData.perc_pacientes_mes >= 0 ? (
                  <ArrowUp className="w-4 h-4 mr-1" />
                ) : (
                  <ArrowDown className="w-4 h-4 mr-1" />
                )}
                <span>{Math.abs(summaryData.perc_pacientes_mes)}% este mês</span>
              </div>
              <span className="text-gray-400 mx-2">•</span>
              <div className="text-gray-500">{summaryData.pacientes_novos_mes} novos</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <CardDescription>Prescrições Ativas</CardDescription>
                <CardTitle className="text-3xl font-bold">{summaryData.prescricoes_ativas}</CardTitle>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg">
                <FileCheck2 className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm mt-2">
              <div className={`flex items-center ${summaryData.perc_prescricoes_mes >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {summaryData.perc_prescricoes_mes >= 0 ? (
                  <ArrowUp className="w-4 h-4 mr-1" />
                ) : (
                  <ArrowDown className="w-4 h-4 mr-1" />
                )}
                <span>{Math.abs(summaryData.perc_prescricoes_mes)}% este mês</span>
              </div>
              <span className="text-gray-400 mx-2">•</span>
              <div className="text-gray-500">{summaryData.prescricoes_novas_mes} novas</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <CardDescription>Pedidos (Este Mês)</CardDescription>
                <CardTitle className="text-3xl font-bold">{summaryData.pedidos_total_mes}</CardTitle>
              </div>
              <div className="p-3 bg-amber-50 rounded-lg">
                <ShoppingBag className="w-5 h-5 text-amber-600" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm mt-2">
              <div className={`flex items-center ${summaryData.perc_pedidos_mes >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {summaryData.perc_pedidos_mes >= 0 ? (
                  <ArrowUp className="w-4 h-4 mr-1" />
                ) : (
                  <ArrowDown className="w-4 h-4 mr-1" />
                )}
                <span>{Math.abs(summaryData.perc_pedidos_mes)}% de aumento</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <CardDescription>Faturamento (Este Mês)</CardDescription>
                <CardTitle className="text-3xl font-bold">{formatCurrency(summaryData.valor_total_mes)}</CardTitle>
              </div>
              <div className="p-3 bg-purple-50 rounded-lg">
                <TrendingUp className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm mt-2">
              <div className={`flex items-center ${summaryData.perc_valor_mes >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {summaryData.perc_valor_mes >= 0 ? (
                  <ArrowUp className="w-4 h-4 mr-1" />
                ) : (
                  <ArrowDown className="w-4 h-4 mr-1" />
                )}
                <span>{Math.abs(summaryData.perc_valor_mes)}% de aumento</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 gap-4 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <Input
            placeholder="Busca rápida de pacientes, prescrições ou pedidos..."
            className="pl-10 w-full"
            value={quickSearchTerm}
            onChange={(e) => setQuickSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" asChild>
            <Link to={createPageUrl("CrmPacientes")}>
              <User className="h-4 w-4" />
              Novo Paciente
            </Link>
          </Button>
          <Button variant="outline" className="gap-2" asChild>
            <Link to={createPageUrl("CrmPrescricoes")}>
              <FileSearch className="h-4 w-4" />
              Nova Prescrição
            </Link>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="patients">Pacientes</TabsTrigger>
          <TabsTrigger value="prescriptions">Prescrições</TabsTrigger>
          <TabsTrigger value="orders">Pedidos</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Vendas Mensais</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [formatCurrency(value), 'Total']}
                        labelFormatter={(label) => `Mês: ${label}`}
                      />
                      <Legend />
                      <Bar dataKey="total" name="Vendas" fill="#4CAF50" />
                    </RechartsBarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Produtos Mais Vendidos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={topProductsData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {topProductsData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value, name) => [`${value} unidades`, name]} />
                      <Legend />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Pacientes Recentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {recentPatients.map((patient) => (
                    <div key={patient.id} className="flex items-start space-x-4">
                      <Avatar className="mt-1">
                        <AvatarFallback className="bg-green-100 text-green-800">
                          {patient.nome_completo.split(' ').map(part => part.charAt(0)).join('').substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="space-y-1">
                        <div className="flex items-center">
                          <h4 className="font-medium">{patient.nome_completo}</h4>
                          <span className="ml-2 text-xs text-gray-500">{formatDate(patient.data_registro)}</span>
                        </div>
                        <div className="text-sm text-gray-500 flex items-center">
                          <Phone className="h-3 w-3 mr-1" />
                          <span>{patient.telefone}</span>
                        </div>
                        <div className="text-sm text-gray-500 flex items-center">
                          <Mail className="h-3 w-3 mr-1" />
                          <span>{patient.email}</span>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {patient.condicoes_medicas.map((condicao, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs bg-purple-50">
                              {condicao}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 pt-4 border-t">
                  <Button variant="outline" className="w-full" asChild>
                    <Link to={createPageUrl("CrmPacientes")}>
                      Ver Todos os Pacientes
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Prescrições Recentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {recentPrescriptions.map((prescription) => (
                    <div key={prescription.id} className="space-y-2">
                      <div className="flex justify-between">
                        <h4 className="font-medium">{prescription.paciente}</h4>
                        <Badge className="bg-green-100 text-green-800">Ativa</Badge>
                      </div>
                      <div className="text-sm text-gray-500">
                        <div className="flex items-center">
                          <User className="h-3 w-3 mr-1" />
                          <span>{prescription.medico}</span>
                        </div>
                        <div className="flex items-center mt-1">
                          <CalendarClock className="h-3 w-3 mr-1" />
                          <span>Emitida: {formatDate(prescription.data_emissao)}</span>
                          <span className="mx-1">•</span>
                          <span>Válida até: {formatDate(prescription.data_validade)}</span>
                        </div>
                      </div>
                      <div className="mt-1">
                        {prescription.produtos.map((produto, idx) => (
                          <div key={idx} className="text-sm flex items-center">
                            <CheckCircle2 className="h-3 w-3 mr-1 text-green-600" />
                            <span>{produto}</span>
                          </div>
                        ))}
                      </div>
                      <Separator className="my-2" />
                    </div>
                  ))}
                </div>
                <div className="mt-2">
                  <Button variant="outline" className="w-full" asChild>
                    <Link to={createPageUrl("CrmPrescricoes")}>
                      Ver Todas as Prescrições
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pedidos Recentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {recentOrders.map((order) => (
                    <div key={order.id} className="space-y-2">
                      <div className="flex justify-between">
                        <h4 className="font-medium">Pedido #{order.id}</h4>
                        <Badge className={
                          order.status === 'entregue' ? 'bg-green-100 text-green-800' :
                          order.status === 'em_andamento' ? 'bg-blue-100 text-blue-800' :
                          'bg-gray-100 text-gray-800'
                        }>
                          {order.status === 'entregue' ? 'Entregue' : 
                           order.status === 'em_andamento' ? 'Em andamento' : 
                           order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-500">
                        <div className="flex items-center">
                          <User className="h-3 w-3 mr-1" />
                          <span>{order.paciente}</span>
                        </div>
                        <div className="flex items-center mt-1">
                          <Calendar className="h-3 w-3 mr-1" />
                          <span>{formatDate(order.data_pedido)}</span>
                          <span className="mx-1">•</span>
                          <span className="font-medium">{formatCurrency(order.total)}</span>
                        </div>
                      </div>
                      <div className="mt-1">
                        {order.produtos.map((produto, idx) => (
                          <div key={idx} className="text-sm flex items-center">
                            <ShoppingBag className="h-3 w-3 mr-1 text-blue-600" />
                            <span>{produto}</span>
                          </div>
                        ))}
                      </div>
                      <Separator className="my-2" />
                    </div>
                  ))}
                </div>
                <div className="mt-2">
                  <Button variant="outline" className="w-full" asChild>
                    <Link to={createPageUrl("CrmPedidos")}>
                      Ver Todos os Pedidos
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="patients" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Novos Pacientes por Mês</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={newPatientsData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="count"
                        name="Novos Pacientes"
                        stroke="#8884d8" 
                        activeDot={{ r: 8 }} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pacientes por Condição</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Epilepsia</span>
                    <Badge className="bg-blue-100 text-blue-800">24</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Dor Crônica</span>
                    <Badge className="bg-blue-100 text-blue-800">36</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Ansiedade</span>
                    <Badge className="bg-blue-100 text-blue-800">29</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Insônia</span>
                    <Badge className="bg-blue-100 text-blue-800">18</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Parkinson</span>
                    <Badge className="bg-blue-100 text-blue-800">12</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Esclerose Múltipla</span>
                    <Badge className="bg-blue-100 text-blue-800">9</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Outras</span>
                    <Badge className="bg-blue-100 text-blue-800">14</Badge>
                  </div>
                </div>
                <Separator className="my-4" />
                <div className="flex justify-between items-center">
                  <span className="font-medium">Total</span>
                  <Badge className="bg-green-100 text-green-800">142</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <div className="flex justify-between">
                <CardTitle>Pacientes Recentes</CardTitle>
                <Button variant="outline" asChild>
                  <Link to={createPageUrl("CrmPacientes")}>Ver Todos</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {recentPatients.map((patient) => (
                  <Card key={patient.id} className="border hover:shadow-md transition-shadow">
                    <CardContent className="pt-6">
                      <div className="flex flex-col items-center mb-4">
                        <Avatar className="h-16 w-16 mb-3">
                          <AvatarFallback className="bg-green-100 text-green-800">
                            {patient.nome_completo.split(' ').map(part => part.charAt(0)).join('').substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <h3 className="font-semibold text-center">{patient.nome_completo}</h3>
                        <p className="text-sm text-gray-500 mt-1">Desde {formatDate(patient.data_registro)}</p>
                      </div>
                      <Separator className="my-3" />
                      <div className="space-y-3">
                        <div className="text-sm text-gray-500 flex items-center">
                          <Phone className="h-3 w-3 mr-2" />
                          <span>{patient.telefone}</span>
                        </div>
                        <div className="text-sm text-gray-500 flex items-center">
                          <Mail className="h-3 w-3 mr-2" />
                          <span>{patient.email}</span>
                        </div>
                        <div className="text-sm text-gray-500 mt-2">
                          <span className="font-medium">Condições:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {patient.condicoes_medicas.map((condicao, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs bg-purple-50">
                                {condicao}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 pt-3 border-t">
                        <Button variant="outline" size="sm" className="w-full" asChild>
                          <Link to={`${createPageUrl("CrmPacienteDetalhes")}?id=${patient.id}`}>
                            Ver Detalhes
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="prescriptions" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Prescrições por Médico</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart
                      layout="vertical"
                      data={[
                        { name: "Dr. João Carlos Santos", count: 28 },
                        { name: "Dra. Ana Paula Mendes", count: 22 },
                        { name: "Dr. Roberto Almeida", count: 18 },
                        { name: "Dra. Sandra Gomes", count: 15 },
                        { name: "Dr. Antônio Silveira", count: 12 }
                      ]}
                      margin={{ top: 20, right: 30, left: 100, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="count" name="Prescrições" fill="#82ca9d" />
                    </RechartsBarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Produtos Prescritos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={[
                          { name: "Óleo CBD 5% 30ml", value: 42 },
                          { name: "Óleo CBD 10% 10ml", value: 35 },
                          { name: "Cápsulas CBD 20mg", value: 30 },
                          { name: "Óleo CBD 15% 20ml", value: 25 },
                          { name: "Outros", value: 20 }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {COLORS.map((color, index) => (
                          <Cell key={`cell-${index}`} fill={color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <div className="flex justify-between">
                <CardTitle>Prescrições Recentes</CardTitle>
                <Button variant="outline" asChild>
                  <Link to={createPageUrl("CrmPrescricoes")}>Ver Todas</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="pb-3 font-medium">Paciente</th>
                      <th className="pb-3 font-medium">Médico</th>
                      <th className="pb-3 font-medium">Emissão</th>
                      <th className="pb-3 font-medium">Validade</th>
                      <th className="pb-3 font-medium">Status</th>
                      <th className="pb-3 font-medium">Produtos</th>
                      <th className="pb-3 font-medium text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentPrescriptions.map((prescription) => (
                      <tr key={prescription.id} className="border-b hover:bg-gray-50">
                        <td className="py-4">{prescription.paciente}</td>
                        <td className="py-4">{prescription.medico}</td>
                        <td className="py-4">{formatDate(prescription.data_emissao)}</td>
                        <td className="py-4">{formatDate(prescription.data_validade)}</td>
                        <td className="py-4">
                          <Badge className="bg-green-100 text-green-800">Ativa</Badge>
                        </td>
                        <td className="py-4">
                          <div className="flex flex-wrap gap-1">
                            {prescription.produtos.slice(0, 2).map((produto, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {produto}
                              </Badge>
                            ))}
                            {prescription.produtos.length > 2 && (
                              <Badge variant="outline" className="text-xs bg-gray-50">
                                +{prescription.produtos.length - 2}
                              </Badge>
                            )}
                          </div>
                        </td>
                        <td className="py-4 text-right">
                          <Button variant="ghost" size="sm" asChild>
                            <Link to={`${createPageUrl("CrmPrescricaoDetalhes")}?id=${prescription.id}`}>
                              Ver Detalhes
                            </Link>
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Vendas Mensais por Produto</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart
                      data={[
                        { month: 'Jan', produto1: 12000, produto2: 8500, produto3: 5000 },
                        { month: 'Fev', produto1: 15000, produto2: 9200, produto3: 4700 },
                        { month: 'Mar', produto1: 14000, produto2: 9800, produto3: 5200 },
                        { month: 'Abr', produto1: 16500, produto2: 10300, produto3: 4900 },
                        { month: 'Mai', produto1: 17800, produto2: 11200, produto3: 5300 },
                        { month: 'Jun', produto1: 18900, produto2: 11800, produto3: 4800 },
                        { month: 'Jul', produto1: 22000, produto2: 13500, produto3: 5800 }
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => [formatCurrency(value), '']} />
                      <Legend />
                      <Bar dataKey="produto1" name="Óleo CBD 5%" fill="#8884d8" />
                      <Bar dataKey="produto2" name="Óleo CBD 10%" fill="#82ca9d" />
                      <Bar dataKey="produto3" name="Cápsulas CBD" fill="#ffc658" />
                    </RechartsBarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Status dos Pedidos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={[
                          { name: "Entregue", value: 56 },
                          { name: "Em Andamento", value: 18 },
                          { name: "Preparando", value: 8 },
                          { name: "Pendente", value: 4 }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {[
                          '#4CAF50', // Verde para entregue
                          '#2196F3', // Azul para em andamento
                          '#FFC107', // Amarelo para preparando
                          '#FF5722'  // Laranja para pendente
                        ].map((color, index) => (
                          <Cell key={`cell-${index}`} fill={color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <div className="flex justify-between">
                <CardTitle>Pedidos Recentes</CardTitle>
                <Button variant="outline" asChild>
                  <Link to={createPageUrl("CrmPedidos")}>Ver Todos</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="pb-3 font-medium">ID Pedido</th>
                      <th className="pb-3 font-medium">Paciente</th>
                      <th className="pb-3 font-medium">Data</th>
                      <th className="pb-3 font-medium">Total</th>
                      <th className="pb-3 font-medium">Status</th>
                      <th className="pb-3 font-medium">Produtos</th>
                      <th className="pb-3 font-medium text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentOrders.map((order) => (
                      <tr key={order.id} className="border-b hover:bg-gray-50">
                        <td className="py-4 font-medium">{order.id}</td>
                        <td className="py-4">{order.paciente}</td>
                        <td className="py-4">{formatDate(order.data_pedido)}</td>
                        <td className="py-4">{formatCurrency(order.total)}</td>
                        <td className="py-4">
                          <Badge className={
                            order.status === 'entregue' ? 'bg-green-100 text-green-800' :
                            order.status === 'em_andamento' ? 'bg-blue-100 text-blue-800' :
                            'bg-gray-100 text-gray-800'
                          }>
                            {order.status === 'entregue' ? 'Entregue' : 
                             order.status === 'em_andamento' ? 'Em andamento' : 
                             order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                          </Badge>
                        </td>
                        <td className="py-4">
                          <div className="flex flex-wrap gap-1">
                            {order.produtos.slice(0, 1).map((produto, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {produto}
                              </Badge>
                            ))}
                            {order.produtos.length > 1 && (
                              <Badge variant="outline" className="text-xs bg-gray-50">
                                +{order.produtos.length - 1}
                              </Badge>
                            )}
                          </div>
                        </td>
                        <td className="py-4 text-right">
                          <Button variant="ghost" size="sm" asChild>
                            <Link to={`${createPageUrl("CrmPedidoDetalhes")}?id=${order.id}`}>
                              Ver Detalhes
                            </Link>
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}