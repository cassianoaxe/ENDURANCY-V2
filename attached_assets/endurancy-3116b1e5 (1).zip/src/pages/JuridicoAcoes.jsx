import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Scale, 
  FileText, 
  Filter, 
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileCheck,
  ArrowUpDown,
  MoreHorizontal,
  Search,
  Plus
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function JuridicoAcoes() {
  const [searchParams] = useState(null);
  const organizationId = searchParams ? searchParams.get('organization_id') : null;
  
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [tipoFilter, setTipoFilter] = useState("all");
  const [organizationFilter, setOrganizationFilter] = useState(organizationId || "all");
  const [isLoading, setIsLoading] = useState(true);
  const [acoes, setAcoes] = useState([]);
  const [organizations, setOrganizations] = useState([]);
  
  useEffect(() => {
    // Simulação de carregamento de dados
    setTimeout(() => {
      setIsLoading(false);
      
      setOrganizations([
        { id: "1", name: "Associação CannaVida" },
        { id: "2", name: "MediCanna Brasil" },
        { id: "3", name: "Instituto Cannabis Medicinal" },
        { id: "4", name: "PharmaCann" },
        { id: "5", name: "Verde Esperança" }
      ]);
      
      setAcoes([
        {
          id: "1",
          numero_processo: "1000123-45.2023.8.26.0100",
          titulo: "Fornecimento de Óleo CBD 3%",
          organization_id: "1",
          organization_name: "Associação CannaVida",
          cliente: "Maria Silva Santos",
          data_entrada: "2023-06-15",
          status: "em_andamento",
          resultado: "pendente",
          tipo: "fornecimento_medicamento",
          tribunal: "TJSP",
          comarca: "São Paulo",
          advogado: "Dr. Carlos Mendes",
          proxima_audiencia: "2023-08-25",
          proximo_prazo: "2023-08-12"
        },
        {
          id: "2",
          numero_processo: "1000456-78.2023.8.26.0100",
          titulo: "Autorização importação Epidiolex",
          organization_id: "2",
          organization_name: "MediCanna Brasil",
          cliente: "João Pereira Lima",
          data_entrada: "2023-05-20",
          status: "liminar_concedida",
          resultado: "pendente",
          tipo: "autorizacao_anvisa",
          tribunal: "TJSP",
          comarca: "São Paulo",
          advogado: "Dra. Patrícia Souza",
          proxima_audiencia: "2023-09-10",
          proximo_prazo: "2023-08-15"
        },
        {
          id: "3",
          numero_processo: "1000789-12.2023.8.26.0100",
          titulo: "Cobertura tratamento com cannabis",
          organization_id: "4",
          organization_name: "PharmaCann",
          cliente: "Roberto Almeida Costa",
          data_entrada: "2023-07-05",
          status: "julgamento_primeira_instancia",
          resultado: "procedente",
          tipo: "cobertura_plano",
          tribunal: "TJSP",
          comarca: "São Paulo",
          advogado: "Dr. Nelson Ferreira",
          proxima_audiencia: "",
          proximo_prazo: "2023-08-30"
        },
        {
          id: "4",
          numero_processo: "1000321-65.2023.8.26.0100",
          titulo: "Fornecimento de Extrato THC/CBD 1:1",
          organization_id: "5",
          organization_name: "Verde Esperança",
          cliente: "Antônia Soares Neves",
          data_entrada: "2023-04-12",
          status: "recurso",
          resultado: "pendente",
          tipo: "fornecimento_medicamento",
          tribunal: "TJSP",
          comarca: "São Paulo",
          advogado: "Dra. Juliana Matos",
          proxima_audiencia: "",
          proximo_prazo: "2023-09-05"
        },
        {
          id: "5",
          numero_processo: "1000987-32.2023.8.26.0100",
          titulo: "Fornecimento de Óleo CBD 5%",
          organization_id: "1",
          organization_name: "Associação CannaVida",
          cliente: "Pedro Henrique Santos",
          data_entrada: "2023-03-25",
          status: "transitado_julgado",
          resultado: "procedente",
          tipo: "fornecimento_medicamento",
          tribunal: "TJSP",
          comarca: "São Paulo",
          advogado: "Dr. Carlos Mendes",
          proxima_audiencia: "",
          proximo_prazo: ""
        }
      ]);
    }, 1500);
  }, [organizationId]);
  
  const getStatusBadge = (status) => {
    switch (status) {
      case 'inicial':
        return <Badge className="bg-gray-100 text-gray-800">Inicial</Badge>;
      case 'em_andamento':
        return <Badge className="bg-blue-100 text-blue-800">Em andamento</Badge>;
      case 'liminar_concedida':
        return <Badge className="bg-green-100 text-green-800">Liminar concedida</Badge>;
      case 'liminar_negada':
        return <Badge className="bg-red-100 text-red-800">Liminar negada</Badge>;
      case 'julgamento_primeira_instancia':
        return <Badge className="bg-purple-100 text-purple-800">Julgamento 1ª instância</Badge>;
      case 'recurso':
        return <Badge className="bg-yellow-100 text-yellow-800">Recurso</Badge>;
      case 'transitado_julgado':
        return <Badge className="bg-emerald-100 text-emerald-800">Transitado em julgado</Badge>;
      case 'arquivado':
        return <Badge className="bg-gray-100 text-gray-800">Arquivado</Badge>;
      case 'suspenso':
        return <Badge className="bg-orange-100 text-orange-800">Suspenso</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  const getResultadoBadge = (resultado) => {
    switch (resultado) {
      case 'pendente':
        return <Badge variant="outline">Pendente</Badge>;
      case 'procedente':
        return <Badge className="bg-green-100 text-green-800">Procedente</Badge>;
      case 'procedente_parcial':
        return <Badge className="bg-blue-100 text-blue-800">Procedente parcial</Badge>;
      case 'improcedente':
        return <Badge className="bg-red-100 text-red-800">Improcedente</Badge>;
      case 'acordo':
        return <Badge className="bg-purple-100 text-purple-800">Acordo</Badge>;
      case 'extinto':
        return <Badge className="bg-gray-100 text-gray-800">Extinto</Badge>;
      default:
        return <Badge>{resultado}</Badge>;
    }
  };
  
  const getTipoBadge = (tipo) => {
    switch (tipo) {
      case 'fornecimento_medicamento':
        return <Badge className="bg-indigo-100 text-indigo-800">Fornecimento</Badge>;
      case 'autorizacao_anvisa':
        return <Badge className="bg-cyan-100 text-cyan-800">ANVISA</Badge>;
      case 'cobertura_plano':
        return <Badge className="bg-pink-100 text-pink-800">Plano de saúde</Badge>;
      case 'outro':
        return <Badge className="bg-gray-100 text-gray-800">Outro</Badge>;
      default:
        return <Badge>{tipo}</Badge>;
    }
  };
  
  const filteredAcoes = acoes.filter(acao => {
    const matchesSearch = 
      acao.numero_processo.toLowerCase().includes(searchTerm.toLowerCase()) || 
      acao.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      acao.cliente.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || acao.status === statusFilter;
    const matchesTipo = tipoFilter === "all" || acao.tipo === tipoFilter;
    const matchesOrg = organizationFilter === "all" || acao.organization_id === organizationFilter;
    
    return matchesSearch && matchesStatus && matchesTipo && matchesOrg;
  });
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Scale className="w-6 h-6 text-emerald-600" />
            Ações Judiciais
          </h1>
          <p className="text-gray-500 mt-1">
            Gerenciamento de ações judiciais de medicamentos
          </p>
        </div>
        
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Nova Ação Judicial
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar por processo, título ou cliente..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="inicial">Inicial</SelectItem>
                <SelectItem value="em_andamento">Em andamento</SelectItem>
                <SelectItem value="liminar_concedida">Liminar concedida</SelectItem>
                <SelectItem value="liminar_negada">Liminar negada</SelectItem>
                <SelectItem value="julgamento_primeira_instancia">Julgamento 1ª instância</SelectItem>
                <SelectItem value="recurso">Recurso</SelectItem>
                <SelectItem value="transitado_julgado">Transitado em julgado</SelectItem>
                <SelectItem value="arquivado">Arquivado</SelectItem>
                <SelectItem value="suspenso">Suspenso</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={tipoFilter} onValueChange={setTipoFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                <SelectItem value="fornecimento_medicamento">Fornecimento</SelectItem>
                <SelectItem value="autorizacao_anvisa">Autorização ANVISA</SelectItem>
                <SelectItem value="cobertura_plano">Cobertura plano</SelectItem>
                <SelectItem value="outro">Outro</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={organizationFilter} onValueChange={setOrganizationFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Organização" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as organizações</SelectItem>
                {organizations.map(org => (
                  <SelectItem key={org.id} value={org.id}>{org.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Lista de Ações Judiciais</CardTitle>
          <CardDescription>
            {filteredAcoes.length} ações encontradas
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="py-16 flex items-center justify-center">
              <div className="space-y-4 text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-emerald-500 mx-auto"></div>
                <p className="text-gray-500">Carregando ações judiciais...</p>
              </div>
            </div>
          ) : filteredAcoes.length === 0 ? (
            <div className="py-16 flex items-center justify-center">
              <div className="space-y-4 text-center">
                <FileText className="h-16 w-16 text-gray-300 mx-auto" />
                <div>
                  <p className="text-xl font-medium">Nenhuma ação encontrada</p>
                  <p className="text-gray-500 mt-1">Tente ajustar os filtros ou adicione uma nova ação</p>
                </div>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Ação Judicial
                </Button>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Processo / Título</TableHead>
                    <TableHead>Organização</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Resultado</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Próximos Eventos</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAcoes.map((acao) => (
                    <TableRow key={acao.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{acao.numero_processo}</p>
                          <p className="text-gray-500 text-sm">{acao.titulo}</p>
                          <p className="text-gray-500 text-sm">
                            <strong>Cliente:</strong> {acao.cliente}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span>{acao.organization_name}</span>
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(acao.status)}
                      </TableCell>
                      <TableCell>
                        {getResultadoBadge(acao.resultado)}
                      </TableCell>
                      <TableCell>
                        {getTipoBadge(acao.tipo)}
                      </TableCell>
                      <TableCell>
                        {acao.proxima_audiencia && (
                          <div className="flex items-center text-sm gap-1">
                            <Calendar className="h-3 w-3 text-gray-500" />
                            <span>{new Date(acao.proxima_audiencia).toLocaleDateString()}</span>
                          </div>
                        )}
                        {acao.proximo_prazo && (
                          <div className="flex items-center text-sm gap-1 mt-1">
                            <Clock className="h-3 w-3 text-gray-500" />
                            <span>{new Date(acao.proximo_prazo).toLocaleDateString()}</span>
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Ações</DropdownMenuLabel>
                            <DropdownMenuItem>Ver detalhes</DropdownMenuItem>
                            <DropdownMenuItem>Editar</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>Adicionar evento</DropdownMenuItem>
                            <DropdownMenuItem>Registrar audiência</DropdownMenuItem>
                            <DropdownMenuItem>Adicionar documento</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600">Arquivar</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}