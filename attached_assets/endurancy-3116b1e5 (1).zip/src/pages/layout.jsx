import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { 
  Bell, 
  LogOut, 
  Monitor, 
  LayoutGrid, 
  TrendingUp, 
  ClipboardList, 
  Database, 
  AlertTriangle, 
  Layers, 
  Users, 
  Building2, 
  DollarSign, 
  Mail, 
  UserCog, 
  Settings, 
  Sun, 
  Moon, 
  Menu, 
  Send,
  Leaf,
  FlaskConical,
  Scale,
  Sprout,
  BarChart4,
  FileBox,
  Beaker,
  ArrowLeftRight,
  UploadCloud,
  FileText,
  Factory,
  Heart,
  Briefcase,
  Landmark,
  CheckSquare,
  Warehouse,
  BadgePercent,
  Truck,
  Receipt,
  Smartphone,
  Headphones,
  UserPlus,
  FolderOpen,
  Clipboard,
  Calendar,
  LineChart,
  Eye,
  ShieldCheck,
  Globe,
  Glasses,
  FileBadge,
  Award,
  ChevronLeft,
  ChevronRight,
  X,
  ShoppingBag,
  ShoppingCart,
  Package,
  Tag,
  CreditCard,
  FileCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";

// Menu items for Super Admin
const superAdminMenuSections = [
  {
    title: "VISÃO GERAL",
    items: [
      { icon: LayoutGrid, label: 'Dashboard', path: 'Dashboard' },
      { icon: BarChart4, label: 'Analytics', path: 'Analytics' }
    ]
  },
  {
    title: "GESTÃO",
    items: [
      { icon: Building2, label: 'Organizações', path: 'Organizations' },
      { icon: Building2, label: 'Solicitações', path: 'Requests' },
      { icon: Layers, label: 'Planos', path: 'Plans' },
      { icon: UserCog, label: 'Administradores', path: 'Admins' }
    ]
  },
  {
    title: "MÓDULOS",
    items: [
      { icon: ShieldCheck, label: 'Gestão de Módulos', path: 'ModuleManagement' },
      { icon: Leaf, label: 'Cultivo', path: 'ModuloCultivo' },
      { icon: Factory, label: 'Produção', path: 'ModuloProducao' },
      { icon: Heart, label: 'CRM', path: 'ModuloCRM' },
      { icon: Briefcase, label: 'RH', path: 'ModuloRH' },
      { icon: Glasses, label: 'Transparência', path: 'TransparencySettings' }
    ]
  },
  {
    title: "FINANCEIRO",
    items: [
      { icon: DollarSign, label: 'Financeiro', path: 'Financial' },
      { icon: Receipt, label: 'Faturamento', path: 'Billing' }
    ]
  },
  {
    title: "COMUNICAÇÃO",
    items: [
      { icon: Mail, label: 'Templates de Email', path: 'EmailTemplates' },
      { icon: Send, label: 'Newsletter', path: 'Newsletter' }
    ]
  },
  {
    title: "AUDITORIA",
    items: [
      { icon: ClipboardList, label: 'Registro de Atividades', path: 'Activities' },
      { icon: TrendingUp, label: 'Analytics', path: 'Analytics' }
    ]
  },
  {
    title: "SISTEMA",
    items: [
      { icon: Settings, label: 'Configurações', path: 'Settings' },
      { icon: Database, label: 'Backups', path: 'Backups' },
      { icon: AlertTriangle, label: 'Emergências', path: 'Emergencies' }
    ]
  }
];

// Menu items for Organization Admin
const orgAdminMenuSections = [
  {
    title: "VISÃO GERAL",
    items: [
      { icon: LayoutGrid, label: 'Dashboard', path: 'OrgDashboard' },
      { icon: BarChart4, label: 'Analytics', path: 'Analytics' }
    ]
  },
  {
    title: "ASSOCIADOS",
    items: [
      { icon: Users, label: 'Quadro de Associados', path: 'Associados' },
      { icon: FileText, label: 'Documentos', path: 'DocumentosAssociados' },
      { icon: CreditCard, label: 'Anuidades', path: 'Anuidades' },
      { icon: FileCheck, label: 'Prescrições', path: 'PrescricoesAssociados' }
    ],
    showFor: "Associação"
  },
  {
    title: "CLIENTES",
    items: [
      { icon: Users, label: 'Clientes', path: 'Clientes' },
      { icon: FileText, label: 'Documentos', path: 'DocumentosClientes' },
      { icon: ShieldCheck, label: 'Autorizações ANVISA', path: 'AutorizacoesAnvisa' },
      { icon: FileCheck, label: 'Prescrições', path: 'PrescricoesClientes' }
    ],
    showFor: "Empresa"
  },
  {
    title: "VENDAS",
    items: [
      { icon: ShoppingBag, label: 'Dashboard Vendas', path: 'VendasDashboard' },
      { icon: ShoppingCart, label: 'Pedidos', path: 'Pedidos' },
      { icon: Package, label: 'Produtos', path: 'Produtos' },
      { icon: Tag, label: 'Etiquetas', path: 'Etiquetas' },
      { icon: Truck, label: 'Rastreamento', path: 'Rastreamento' }
    ]
  },
  {
    title: "CULTIVO",
    items: [
      { icon: Leaf, label: 'Dashboard Cultivo', path: 'CultivoDashboard' },
      { icon: Sprout, label: 'Plantas', path: 'CultivoPlantas' },
      { icon: ClipboardList, label: 'Lotes', path: 'CultivoLotes' },
      { icon: ArrowLeftRight, label: 'Transferências', path: 'CultivoTransferencias' },
      { icon: Scale, label: 'Estoque', path: 'CultivoEstoque' },
      { icon: Beaker, label: 'Testes Laboratoriais', path: 'CultivoTestes' },
      { icon: Leaf, label: 'Strains', path: 'CultivoStrains' },
      { icon: FileText, label: 'Relatórios', path: 'CultivoRelatorios' }
    ]
  },
  {
    title: "PRODUÇÃO",
    items: [
      { icon: Factory, label: 'Dashboard Produção', path: 'ProducaoDashboard' },
      { icon: CheckSquare, label: 'Controle de Qualidade', path: 'ProducaoQualidade' },
      { icon: Truck, label: 'Fornecedores', path: 'ProducaoFornecedores' },
      { icon: Warehouse, label: 'Matérias-primas', path: 'ProducaoMateriasPrimas' },
      { icon: Receipt, label: 'Ordens de Produção', path: 'ProducaoOrdens' }
    ]
  },
  {
    title: "CRM",
    items: [
      { icon: Heart, label: 'Dashboard CRM', path: 'CrmDashboard' },
      { icon: Users, label: 'Pacientes', path: 'CrmPacientes' },
      { icon: Smartphone, label: 'Prescrições', path: 'CrmPrescricoes' },
      { icon: Headphones, label: 'Atendimento', path: 'CrmAtendimento' },
      { icon: BadgePercent, label: 'Campanhas', path: 'CrmCampanhas' }
    ]
  },
  {
    title: "TRANSPARÊNCIA",
    items: [
      { icon: Globe, label: 'Portal de Transparência', path: 'AssociacaoTransparencia' },
      { icon: FileBadge, label: 'Documentos Públicos', path: 'TransparencyDocuments' },
      { icon: Award, label: 'Certificações', path: 'TransparencyCertifications' },
      { icon: LineChart, label: 'Relatórios Financeiros', path: 'TransparencyFinancial' },
      { icon: Users, label: 'Membros e Governança', path: 'TransparencyMembers' }
    ]
  },
  {
    title: "RH",
    items: [
      { icon: Briefcase, label: 'Dashboard RH', path: 'RhDashboard' },
      { icon: UserPlus, label: 'Recrutamento', path: 'RhRecrutamento' },
      { icon: Users, label: 'Colaboradores', path: 'RhColaboradores' },
      { icon: FolderOpen, label: 'Documentos', path: 'RhDocumentos' },
      { icon: Calendar, label: 'Escalas', path: 'RhEscalas' }
    ]
  },
  {
    title: "PATRIMÔNIO",
    items: [
      { icon: Landmark, label: 'Dashboard Patrimônio', path: 'PatrimonioDashboard' },
      { icon: Building2, label: 'Instalações', path: 'PatrimonioInstalacoes' },
      { icon: FileBox, label: 'Equipamentos', path: 'PatrimonioEquipamentos' },
      { icon: Clipboard, label: 'Manutenções', path: 'PatrimonioManutencoes' }
    ]
  },
  {
    title: "CONFIGURAÇÕES",
    items: [
      { icon: Users, label: 'Usuários', path: 'OrgUsuarios' },
      { icon: Settings, label: 'Configurações', path: 'OrgConfiguracoes' }
    ]
  }
];

export default function Layout({ children, currentPageName }) {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [userType, setUserType] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [organizationType, setOrganizationType] = useState(null);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
      if (window.innerWidth < 1024) {
        setIsSidebarOpen(false);
        setIsSidebarCollapsed(false);
      } else {
        setIsSidebarOpen(true);
      }
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => {
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  useEffect(() => {
    loadCurrentUser();
    determineOrgType();
  }, []);

  const isAuthPage = [
    "Access", 
    "RecoverPassword", 
    "RegisterPage", 
    "ForgotPassword", 
    "Index",
    "Landing"
  ].includes(currentPageName);

  if (isAuthPage) {
    return <div className={isDarkMode ? 'dark' : ''}>{children}</div>;
  }

  const menuSections = userType === "orgadmin" ? orgAdminMenuSections : superAdminMenuSections;

  const determineOrgType = () => {
    const savedOrgType = localStorage.getItem('mockOrgType');
    if (savedOrgType) {
      setOrganizationType(savedOrgType);
    } else {
      setOrganizationType("Associação");
    }
  };

  const loadCurrentUser = async () => {
    try {
      const mockUserType = localStorage.getItem('mockUserType');
      const mockUserEmail = localStorage.getItem('mockUserEmail');
      const mockUserName = localStorage.getItem('mockUserName');
      
      if (mockUserType && mockUserEmail) {
        setCurrentUser({
          id: "mock-user-1",
          full_name: mockUserName || "Usuário Demonstração",
          email: mockUserEmail,
          role: "admin",
          user_type: mockUserType
        });
        setUserType(mockUserType);
        setIsAuthenticated(true);
        return;
      }
      
      setCurrentUser({
        id: "superuser-1",
        full_name: "Administrador",
        email: "admin@endurancy.com",
        role: "admin",
        user_type: "superadmin"
      });
      setUserType("superadmin");
      setIsAuthenticated(true);
      
    } catch (error) {
      console.error("Error loading current user", error);
      
      setCurrentUser({
        id: "fallback-user",
        full_name: "Administrador Padrão",
        email: "admin@endurancy.com",
        role: "admin",
        user_type: "superadmin"
      });
      setUserType("superadmin");
      setIsAuthenticated(true);
      
    }
  };

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };
  
  const toggleSidebar = () => {
    if (isMobile) {
      setIsSidebarOpen(!isSidebarOpen);
    } else {
      setIsSidebarCollapsed(!isSidebarCollapsed);
    }
  };
  
  const handleLogout = async () => {
    try {
      localStorage.removeItem('mockUserType');
      localStorage.removeItem('mockUserEmail');
      localStorage.removeItem('mockUserName');
      
      try {
        await User.logout();
      } catch (e) {
        console.log("Regular logout failed, but we still proceed with local logout");
      }
      
      setIsAuthenticated(false);
      setCurrentUser(null);
      
      toast({
        title: "Logout realizado com sucesso",
        description: "Você será redirecionado para a página inicial.",
      });
      
      navigate(createPageUrl("Access"));
    } catch (error) {
      console.error("Erro ao fazer logout:", error);
      toast({
        title: "Erro ao fazer logout",
        description: "Ocorreu um erro ao tentar sair. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const closeSidebarOnMobile = () => {
    if (isMobile) {
      setIsSidebarOpen(false);
    }
  };

  if (!isAuthenticated) {
    return <div className={isDarkMode ? 'dark' : ''}>{children}</div>;
  }

  const renderSidebarMenu = () => {
    return (
      <nav className="flex-1 p-4 space-y-5 overflow-y-auto">
        {menuSections.map((section, index) => {
          if (section.showFor && section.showFor !== organizationType) {
            return null;
          }
          
          return (
            <div key={index} className="space-y-1">
              {!isSidebarCollapsed && (
                <p className="text-xs font-medium text-gray-400 mb-2 px-4">{section.title}</p>
              )}
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentPageName === item.path;
                return (
                  <Link
                    key={item.path}
                    to={createPageUrl(item.path)}
                    className={`flex items-center gap-3 ${isSidebarCollapsed ? 'justify-center' : ''} 
                      px-4 py-3 rounded-lg transition-colors ${
                        isActive
                          ? 'bg-green-50 text-green-600'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    onClick={closeSidebarOnMobile}
                    title={isSidebarCollapsed ? item.label : ''}
                  >
                    <Icon className="w-5 h-5 flex-shrink-0" />
                    {!isSidebarCollapsed && <span>{item.label}</span>}
                  </Link>
                );
              })}
            </div>
          );
        })}
      </nav>
    );
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark' : ''}`}>
      <div className="flex min-h-screen bg-gray-50">
        {isMobile && isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-30"
            onClick={() => setIsSidebarOpen(false)}
          ></div>
        )}
        
        <aside 
          className={`fixed top-0 left-0 z-40 h-screen transition-all duration-300 bg-white border-r border-gray-200
            ${isMobile 
              ? isSidebarOpen ? 'translate-x-0' : '-translate-x-full' 
              : isSidebarCollapsed ? 'w-20' : 'w-64'}`}
        >
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between p-4 border-b">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <span className="text-green-600 font-semibold">E</span>
                </div>
                {!isSidebarCollapsed && <span className="font-semibold text-xl">Endurancy</span>}
              </div>
              
              {isMobile && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setIsSidebarOpen(false)}
                  className="lg:hidden"
                >
                  <X className="w-5 h-5" />
                </Button>
              )}
              
              {!isMobile && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={toggleSidebar}
                  className="hidden lg:flex"
                >
                  {isSidebarCollapsed ? (
                    <ChevronRight className="w-5 h-5" />
                  ) : (
                    <ChevronLeft className="w-5 h-5" />
                  )}
                </Button>
              )}
            </div>

            {renderSidebarMenu()}

            <div className={`p-4 border-t ${isSidebarCollapsed ? 'flex flex-col items-center' : ''}`}>
              {!isSidebarCollapsed && (
                <Button
                  variant="outline"
                  className="w-full justify-start gap-2 mb-2"
                  onClick={() => {}}
                >
                  <Monitor className="w-4 h-4" />
                  Captura de Tela
                </Button>
              )}
              
              <Button
                variant={isSidebarCollapsed ? "ghost" : "outline"}
                size={isSidebarCollapsed ? "icon" : "default"}
                className={isSidebarCollapsed ? "text-red-600 hover:text-red-700 mb-2" : "w-full justify-start gap-2 text-red-600 hover:text-red-700"}
                onClick={handleLogout}
                title={isSidebarCollapsed ? "Sair" : ''}
              >
                <LogOut className="w-4 h-4" />
                {!isSidebarCollapsed && "Sair"}
              </Button>
              
              {isSidebarCollapsed && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {}}
                  title="Captura de Tela"
                >
                  <Monitor className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        </aside>

        <div className={`flex-1 transition-all duration-300 ${isMobile ? '' : isSidebarCollapsed ? 'lg:ml-20' : 'lg:ml-64'}`}>
          <header className="bg-white border-b sticky top-0 z-30">
            <div className="flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={toggleSidebar}
                >
                  <Menu className="w-5 h-5" />
                </Button>
                <nav className="flex items-center gap-2 text-sm text-gray-500">
                  <Link to={userType === "orgadmin" ? createPageUrl("OrgDashboard") : createPageUrl("Dashboard")}>Início</Link>
                  <span>/</span>
                  <span>{userType === "orgadmin" ? "Organização" : "Super-admin"}</span>
                  <span>/</span>
                  <span className="text-gray-900">{currentPageName}</span>
                </nav>
              </div>

              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={toggleTheme}
                  className="text-gray-500"
                >
                  {isDarkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                </Button>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="relative">
                      <Bell className="w-5 h-5 text-gray-500" />
                      <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center bg-green-500">
                        2
                      </Badge>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-80">
                    <DropdownMenuLabel className="flex items-center justify-between">
                      <span>Notificações</span>
                      <Link to={createPageUrl("Notifications")} className="text-xs text-blue-600 hover:underline">
                        Ver todas
                      </Link>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <div className="max-h-80 overflow-y-auto">
                      <DropdownMenuItem className="p-3 hover:bg-gray-50 cursor-pointer flex gap-3 items-start">
                        <div className="bg-blue-100 p-2 rounded-full">
                          <UserPlus className="w-4 h-4 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">Nova solicitação de organização</p>
                          <p className="text-xs text-gray-500 mt-1">CannaPesquisa Instituto enviou uma solicitação</p>
                          <p className="text-xs text-gray-400 mt-1">2 horas atrás</p>
                        </div>
                      </DropdownMenuItem>
                      <DropdownMenuItem className="p-3 hover:bg-gray-50 cursor-pointer flex gap-3 items-start">
                        <div className="bg-yellow-100 p-2 rounded-full">
                          <AlertTriangle className="w-4 h-4 text-yellow-600" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">Alerta de segurança</p>
                          <p className="text-xs text-gray-500 mt-1">Tentativa de login suspeita detectada</p>
                          <p className="text-xs text-gray-400 mt-1">5 horas atrás</p>
                        </div>
                      </DropdownMenuItem>
                    </div>
                  </DropdownMenuContent>
                </DropdownMenu>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <div className="flex items-center gap-3 cursor-pointer p-1 rounded-lg hover:bg-gray-100">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback>
                          {userType === "orgadmin" ? "OA" : "SA"}
                        </AvatarFallback>
                      </Avatar>
                      <div className="hidden md:block">
                        <p className="text-sm font-medium">
                          {currentUser?.full_name || (userType === "orgadmin" ? "Org Admin" : "Admin")}
                        </p>
                        <p className="text-xs text-gray-500">
                          {userType === "orgadmin" ? "Administrador da Organização" : "Super Admin"}
                        </p>
                      </div>
                    </div>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <div className="p-2 border-b">
                      <p className="font-medium">{currentUser?.full_name || "Usuário Demonstração"}</p>
                      <p className="text-sm text-gray-500">{currentUser?.email || "usuario@exemplo.com"}</p>
                    </div>
                    <DropdownMenuItem className="p-3 cursor-pointer" onClick={() => navigate(createPageUrl("UserProfile"))}>
                      <UserCog className="w-4 h-4 mr-2" />
                      Meu Perfil
                    </DropdownMenuItem>
                    <DropdownMenuItem className="p-3 cursor-pointer" onClick={() => navigate(createPageUrl("Settings"))}>
                      <Settings className="w-4 h-4 mr-2" />
                      Configurações
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="p-3 cursor-pointer text-red-600" onClick={handleLogout}>
                      <LogOut className="w-4 h-4 mr-2" />
                      Sair
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </header>

          <main className="p-6">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
}