import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { NotificationPreference } from '@/api/entities';
import { toast } from '@/components/ui/use-toast';
import {
  Bell, 
  Mail, 
  Smartphone,
  Clock,
  Save,
  FileText,
  Pill,
  MessageSquare,
  Calendar,
  Info,
  ArrowLeft,
  CheckCircle2 as CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Spinner } from '@/components/ui/spinner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from '@/components/ui/tabs';
import {
  Alert,
  AlertDescription,
  AlertTitle
} from '@/components/ui/alert';

export default function NotificationPreferencesPage() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('general');
  const [userType, setUserType] = useState('paciente'); // paciente, farmaceutico, medico, admin
  const [showSuccessAlert, setShowSuccessAlert] = useState(false);
  const [preferences, setPreferences] = useState(null);

  useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      
      // Determine user type from user data
      // For demo, we'll just use a simple role check
      if (user.role === 'admin') {
        setUserType('farmaceutico');
      } else {
        setUserType('paciente');
      }
      
      await loadPreferences(user.id);
    } catch (error) {
      console.error("Erro ao carregar usuário", error);
      toast({
        title: "Erro de autenticação",
        description: "Você precisa estar logado para acessar esta página.",
        variant: "destructive",
      });
      navigate(createPageUrl("Access"));
    }
  };

  const loadPreferences = async (userId) => {
    try {
      // In a real app, fetch user's notification preferences
      // const userPreferences = await NotificationPreference.filter({ user_id: userId });
      
      // For demo, we'll use default values
      const defaultPreferences = {
        user_id: userId,
        general: {
          email_enabled: true,
          push_enabled: true,
          sms_enabled: false,
          sound_alerts: true,
          quiet_hours_enabled: false,
          quiet_hours_start: "22:00",
          quiet_hours_end: "07:00",
          daily_digest_enabled: false,
          preferred_time: "08:00"
        },
        prescricoes: {
          status_change: true,
          submitted: true,
          under_review: true,
          approved: true,
          rejected: true,
          needs_revision: true,
          expiring_soon: true,
          expiring_days_before: 7,
          new_comments: true
        },
        medicamentos: {
          intake_reminders: true,
          reminder_frequency: "once",
          reminder_advance_minutes: 15,
          missed_reminders: true,
          refill_reminders: true,
          refill_days_before: 3
        },
        farmaceutico: {
          new_prescription_submissions: true,
          prescription_reviews_required: true,
          high_priority_notifications: true,
          daily_report_enabled: true,
          daily_report_time: "17:00"
        }
      };
      
      setPreferences(defaultPreferences);
      setLoading(false);
    } catch (error) {
      console.error("Erro ao carregar preferências", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar suas preferências de notificação.",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  const handleSavePreferences = async () => {
    if (!preferences) return;
    
    setSaving(true);
    try {
      // In a real app, save to the database
      // if existing preferences, update them
      // const existingPrefs = await NotificationPreference.filter({ user_id: currentUser.id });
      // if (existingPrefs && existingPrefs.length > 0) {
      //   await NotificationPreference.update(existingPrefs[0].id, preferences);
      // } else {
      //   await NotificationPreference.create(preferences);
      // }
      
      // For demo, just simulate a delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setShowSuccessAlert(true);
      setTimeout(() => setShowSuccessAlert(false), 5000);
      
      toast({
        title: "Preferências salvas",
        description: "Suas configurações de notificação foram atualizadas com sucesso.",
      });
    } catch (error) {
      console.error("Erro ao salvar preferências", error);
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar suas preferências. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const updatePreference = (category, key, value) => {
    if (!preferences) return;
    
    setPreferences(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
  };

  if (loading) {
    return (
      <div className="container mx-auto py-12 flex justify-center items-center">
        <Spinner className="mr-2" />
        <span>Carregando preferências de notificação...</span>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center mb-6 gap-3">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate(-1)}
          className="mr-1"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold">Preferências de Notificação</h1>
          <p className="text-gray-500 mt-1">
            Personalize como e quando você deseja receber notificações
          </p>
        </div>
        <Button
          onClick={handleSavePreferences}
          disabled={saving}
        >
          {saving ? (
            <>
              <Spinner className="mr-2 h-4 w-4" />
              Salvando...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Salvar Preferências
            </>
          )}
        </Button>
      </div>

      {showSuccessAlert && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-500" />
          <AlertTitle className="text-green-800">Preferências salvas</AlertTitle>
          <AlertDescription className="text-green-700">
            Suas configurações de notificação foram atualizadas com sucesso.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <div className="bg-white border rounded-lg p-1">
          <TabsList className="grid grid-cols-3 md:grid-cols-3 h-auto">
            <TabsTrigger value="general" className="py-2 data-[state=active]:bg-gray-100">
              <Bell className="h-4 w-4 mr-2" />
              <span className="hidden md:inline">Geral</span>
            </TabsTrigger>
            <TabsTrigger value="prescricoes" className="py-2 data-[state=active]:bg-gray-100">
              <FileText className="h-4 w-4 mr-2" />
              <span className="hidden md:inline">Prescrições</span>
            </TabsTrigger>
            <TabsTrigger value="medicamentos" className="py-2 data-[state=active]:bg-gray-100">
              <Pill className="h-4 w-4 mr-2" />
              <span className="hidden md:inline">Medicamentos</span>
            </TabsTrigger>
          </TabsList>
        </div>

        {/* General Settings */}
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <Bell className="h-5 w-5 mr-2 text-gray-500" />
                Configurações Básicas
              </CardTitle>
              <CardDescription>
                Configure como você quer receber notificações
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Notificações por Email</Label>
                  <p className="text-sm text-muted-foreground">Receber notificações por email</p>
                </div>
                <Switch
                  checked={preferences.general.email_enabled}
                  onCheckedChange={(value) => updatePreference('general', 'email_enabled', value)}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Notificações Push</Label>
                  <p className="text-sm text-muted-foreground">Receber notificações no navegador e dispositivos</p>
                </div>
                <Switch
                  checked={preferences.general.push_enabled}
                  onCheckedChange={(value) => updatePreference('general', 'push_enabled', value)}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Notificações por SMS</Label>
                  <p className="text-sm text-muted-foreground">Receber notificações por mensagem de texto</p>
                </div>
                <Switch
                  checked={preferences.general.sms_enabled}
                  onCheckedChange={(value) => updatePreference('general', 'sms_enabled', value)}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Alertas Sonoros</Label>
                  <p className="text-sm text-muted-foreground">Tocar som ao receber notificações</p>
                </div>
                <Switch
                  checked={preferences.general.sound_alerts}
                  onCheckedChange={(value) => updatePreference('general', 'sound_alerts', value)}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Modo Silencioso</Label>
                  <p className="text-sm text-muted-foreground">Não enviar notificações durante certos horários</p>
                </div>
                <Switch
                  checked={preferences.general.quiet_hours_enabled}
                  onCheckedChange={(value) => updatePreference('general', 'quiet_hours_enabled', value)}
                />
              </div>

              {preferences.general.quiet_hours_enabled && (
                <div className="grid grid-cols-2 gap-4 mt-2 pl-4">
                  <div>
                    <Label htmlFor="quiet-start">Hora inicial</Label>
                    <Select
                      value={preferences.general.quiet_hours_start}
                      onValueChange={(value) => updatePreference('general', 'quiet_hours_start', value)}
                    >
                      <SelectTrigger id="quiet-start">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 24 }).map((_, i) => (
                          <SelectItem key={i} value={`${String(i).padStart(2, '0')}:00`}>
                            {`${String(i).padStart(2, '0')}:00`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="quiet-end">Hora final</Label>
                    <Select
                      value={preferences.general.quiet_hours_end}
                      onValueChange={(value) => updatePreference('general', 'quiet_hours_end', value)}
                    >
                      <SelectTrigger id="quiet-end">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 24 }).map((_, i) => (
                          <SelectItem key={i} value={`${String(i).padStart(2, '0')}:00`}>
                            {`${String(i).padStart(2, '0')}:00`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Resumo Diário</Label>
                  <p className="text-sm text-muted-foreground">Receber um resumo diário de todas as notificações</p>
                </div>
                <Switch
                  checked={preferences.general.daily_digest_enabled}
                  onCheckedChange={(value) => updatePreference('general', 'daily_digest_enabled', value)}
                />
              </div>

              {preferences.general.daily_digest_enabled && (
                <div className="mt-2 pl-4">
                  <Label htmlFor="digest-time">Horário de envio</Label>
                  <Select
                    value={preferences.general.preferred_time}
                    onValueChange={(value) => updatePreference('general', 'preferred_time', value)}
                  >
                    <SelectTrigger id="digest-time">
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 24 }).map((_, i) => (
                        <SelectItem key={i} value={`${String(i).padStart(2, '0')}:00`}>
                          {`${String(i).padStart(2, '0')}:00`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Prescription Settings */}
        <TabsContent value="prescricoes">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <FileText className="h-5 w-5 mr-2 text-gray-500" />
                Notificações de Prescrições
              </CardTitle>
              <CardDescription>
                Configure como você quer ser notificado sobre suas prescrições médicas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Alterações de Status</Label>
                    <p className="text-sm text-muted-foreground">Notificar sobre alterações de status</p>
                  </div>
                  <Switch
                    checked={preferences.prescricoes.status_change}
                    onCheckedChange={(value) => updatePreference('prescricoes', 'status_change', value)}
                  />
                </div>
                
                {preferences.prescricoes.status_change && (
                  <div className="pl-4 pt-2 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Prescrição Enviada</Label>
                        <p className="text-xs text-muted-foreground">Quando você envia uma prescrição</p>
                      </div>
                      <Switch
                        checked={preferences.prescricoes.submitted}
                        onCheckedChange={(value) => updatePreference('prescricoes', 'submitted', value)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Em Análise</Label>
                        <p className="text-xs text-muted-foreground">Quando a prescrição está sendo analisada</p>
                      </div>
                      <Switch
                        checked={preferences.prescricoes.under_review}
                        onCheckedChange={(value) => updatePreference('prescricoes', 'under_review', value)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Aprovada</Label>
                        <p className="text-xs text-muted-foreground">Quando a prescrição é aprovada</p>
                      </div>
                      <Switch
                        checked={preferences.prescricoes.approved}
                        onCheckedChange={(value) => updatePreference('prescricoes', 'approved', value)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Rejeitada</Label>
                        <p className="text-xs text-muted-foreground">Quando a prescrição é rejeitada</p>
                      </div>
                      <Switch
                        checked={preferences.prescricoes.rejected}
                        onCheckedChange={(value) => updatePreference('prescricoes', 'rejected', value)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Necessita Revisão</Label>
                        <p className="text-xs text-muted-foreground">Quando são solicitadas alterações</p>
                      </div>
                      <Switch
                        checked={preferences.prescricoes.needs_revision}
                        onCheckedChange={(value) => updatePreference('prescricoes', 'needs_revision', value)}
                      />
                    </div>
                  </div>
                )}
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Prescrições Expirando</Label>
                    <p className="text-sm text-muted-foreground">Alertar quando suas prescrições estão para expirar</p>
                  </div>
                  <Switch
                    checked={preferences.prescricoes.expiring_soon}
                    onCheckedChange={(value) => updatePreference('prescricoes', 'expiring_soon', value)}
                  />
                </div>
                
                {preferences.prescricoes.expiring_soon && (
                  <div className="pl-4 pt-2">
                    <Label htmlFor="expiring-days">Dias antes de expirar</Label>
                    <Select
                      value={preferences.prescricoes.expiring_days_before.toString()}
                      onValueChange={(value) => updatePreference('prescricoes', 'expiring_days_before', parseInt(value))}
                    >
                      <SelectTrigger id="expiring-days" className="w-full">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 3, 5, 7, 10, 14, 30].map((days) => (
                          <SelectItem key={days} value={days.toString()}>
                            {days} {days === 1 ? 'dia' : 'dias'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Novos Comentários</Label>
                    <p className="text-sm text-muted-foreground">Notificar sobre novos comentários em prescrições</p>
                  </div>
                  <Switch
                    checked={preferences.prescricoes.new_comments}
                    onCheckedChange={(value) => updatePreference('prescricoes', 'new_comments', value)}
                  />
                </div>
                
                {userType === 'farmaceutico' && (
                  <>
                    <Separator className="my-6" />
                    
                    <div className="bg-blue-50 p-4 rounded-lg mb-4">
                      <h3 className="font-medium text-blue-800 mb-2">Configurações para Farmacêuticos</h3>
                      
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label className="text-base">Novas Prescrições</Label>
                            <p className="text-sm text-blue-700">Notificar sobre novos envios de prescrições</p>
                          </div>
                          <Switch
                            checked={preferences.farmaceutico.new_prescription_submissions}
                            onCheckedChange={(value) => updatePreference('farmaceutico', 'new_prescription_submissions', value)}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label className="text-base">Análises Pendentes</Label>
                            <p className="text-sm text-blue-700">Lembrar sobre prescrições que precisam de revisão</p>
                          </div>
                          <Switch
                            checked={preferences.farmaceutico.prescription_reviews_required}
                            onCheckedChange={(value) => updatePreference('farmaceutico', 'prescription_reviews_required', value)}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label className="text-base">Alta Prioridade</Label>
                            <p className="text-sm text-blue-700">Receber alertas para prescrições urgentes</p>
                          </div>
                          <Switch
                            checked={preferences.farmaceutico.high_priority_notifications}
                            onCheckedChange={(value) => updatePreference('farmaceutico', 'high_priority_notifications', value)}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label className="text-base">Relatório Diário</Label>
                            <p className="text-sm text-blue-700">Receber resumo de atividades do dia</p>
                          </div>
                          <Switch
                            checked={preferences.farmaceutico.daily_report_enabled}
                            onCheckedChange={(value) => updatePreference('farmaceutico', 'daily_report_enabled', value)}
                          />
                        </div>
                        
                        {preferences.farmaceutico.daily_report_enabled && (
                          <div className="pl-2 pt-2">
                            <Label htmlFor="report-time">Horário do relatório</Label>
                            <Select
                              value={preferences.farmaceutico.daily_report_time}
                              onValueChange={(value) => updatePreference('farmaceutico', 'daily_report_time', value)}
                            >
                              <SelectTrigger id="report-time" className="w-full">
                                <SelectValue placeholder="Selecione" />
                              </SelectTrigger>
                              <SelectContent>
                                {Array.from({ length: 24 }).map((_, i) => (
                                  <SelectItem key={i} value={`${String(i).padStart(2, '0')}:00`}>
                                    {`${String(i).padStart(2, '0')}:00`}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Medication Settings */}
        <TabsContent value="medicamentos">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <Pill className="h-5 w-5 mr-2 text-gray-500" />
                Notificações de Medicamentos
              </CardTitle>
              <CardDescription>
                Configure como você quer ser lembrado sobre seus medicamentos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Lembretes de Tomar Medicação</Label>
                    <p className="text-sm text-muted-foreground">Receber lembretes para tomar seus medicamentos</p>
                  </div>
                  <Switch
                    checked={preferences.medicamentos.intake_reminders}
                    onCheckedChange={(value) => updatePreference('medicamentos', 'intake_reminders', value)}
                  />
                </div>
                
                {preferences.medicamentos.intake_reminders && (
                  <div className="space-y-4 pl-4 pt-2">
                    <div>
                      <Label htmlFor="reminder-frequency">Frequência de lembretes</Label>
                      <Select
                        value={preferences.medicamentos.reminder_frequency}
                        onValueChange={(value) => updatePreference('medicamentos', 'reminder_frequency', value)}
                      >
                        <SelectTrigger id="reminder-frequency" className="w-full">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="once">Uma vez</SelectItem>
                          <SelectItem value="twice">Duas vezes</SelectItem>
                          <SelectItem value="until_confirmed">Até confirmar</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="reminder-time">Antecipar lembrete em</Label>
                      <Select
                        value={preferences.medicamentos.reminder_advance_minutes.toString()}
                        onValueChange={(value) => updatePreference('medicamentos', 'reminder_advance_minutes', parseInt(value))}
                      >
                        <SelectTrigger id="reminder-time" className="w-full">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">No momento exato</SelectItem>
                          <SelectItem value="5">5 minutos antes</SelectItem>
                          <SelectItem value="10">10 minutos antes</SelectItem>
                          <SelectItem value="15">15 minutos antes</SelectItem>
                          <SelectItem value="30">30 minutos antes</SelectItem>
                          <SelectItem value="60">1 hora antes</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Medicação Esquecida</Label>
                    <p className="text-sm text-muted-foreground">Notificar quando você esquecer de tomar medicamentos</p>
                  </div>
                  <Switch
                    checked={preferences.medicamentos.missed_reminders}
                    onCheckedChange={(value) => updatePreference('medicamentos', 'missed_reminders', value)}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Lembretes de Reabastecimento</Label>
                    <p className="text-sm text-muted-foreground">Lembrar sobre medicamentos acabando</p>
                  </div>
                  <Switch
                    checked={preferences.medicamentos.refill_reminders}
                    onCheckedChange={(value) => updatePreference('medicamentos', 'refill_reminders', value)}
                  />
                </div>
                
                {preferences.medicamentos.refill_reminders && (
                  <div className="pl-4 pt-2">
                    <Label htmlFor="refill-days">Dias antes de acabar</Label>
                    <Select
                      value={preferences.medicamentos.refill_days_before.toString()}
                      onValueChange={(value) => updatePreference('medicamentos', 'refill_days_before', parseInt(value))}
                    >
                      <SelectTrigger id="refill-days" className="w-full">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 5, 7, 10].map((days) => (
                          <SelectItem key={days} value={days.toString()}>
                            {days} {days === 1 ? 'dia' : 'dias'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}