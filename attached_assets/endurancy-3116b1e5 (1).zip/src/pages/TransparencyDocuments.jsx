import React, { useState, useEffect } from 'react';
import { 
  FileBadge, 
  FileText, 
  Download, 
  Calendar, 
  Search, 
  Plus, 
  Filter, 
  ChevronDown, 
  UploadCloud,
  Eye,
  Trash2,
  FileEdit,
  Building2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// Exemplo de dados de documentos
const sampleDocuments = [
  {
    id: "doc1",
    title: "Estatuto Social",
    description: "Estatuto social da organização atualizado em 2023",
    category: "legal",
    file_type: "pdf",
    file_size: 2458000,
    date: "2023-06-15",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    is_public: true
  },
  {
    id: "doc2",
    title: "Relatório Financeiro 2022",
    description: "Relatório financeiro anual de 2022",
    category: "financial",
    file_type: "pdf",
    file_size: 4125000,
    date: "2023-02-28",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    is_public: true
  },
  {
    id: "doc3",
    title: "Certificado de Boas Práticas",
    description: "Certificado de Boas Práticas de Fabricação",
    category: "certification",
    file_type: "pdf",
    file_size: 1254000,
    date: "2022-11-10",
    organization_id: "org1",
    organization_name: "MediCannabis Farma",
    is_public: true
  },
  {
    id: "doc4",
    title: "Ata da Assembleia Geral",
    description: "Ata da Assembleia Geral Ordinária de 2023",
    category: "governance",
    file_type: "pdf",
    file_size: 3210000,
    date: "2023-04-12",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    is_public: true
  },
  {
    id: "doc5",
    title: "Lista de Associados",
    description: "Lista atualizada de associados ativos",
    category: "members",
    file_type: "xlsx",
    file_size: 1845000,
    date: "2023-07-01",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    is_public: false
  },
  {
    id: "doc6",
    title: "Certificação ANVISA",
    description: "Certificação da ANVISA para operação",
    category: "certification",
    file_type: "pdf",
    file_size: 967000,
    date: "2022-08-15",
    organization_id: "org1",
    organization_name: "MediCannabis Farma",
    is_public: true
  },
  {
    id: "doc7",
    title: "Política de Transparência",
    description: "Política de transparência e governança",
    category: "governance",
    file_type: "docx",
    file_size: 520000,
    date: "2023-01-20",
    organization_id: "org5",
    organization_name: "Cannabis Brasil Sul",
    is_public: true
  }
];

export default function TransparencyDocuments() {
  const [documents, setDocuments] = useState([]);
  const [filteredDocs, setFilteredDocs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [organizationFilter, setOrganizationFilter] = useState("");
  const [publicFilter, setPublicFilter] = useState("");

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setDocuments(sampleDocuments);
      setFilteredDocs(sampleDocuments);
      setIsLoading(false);
    }, 800);
  }, []);

  useEffect(() => {
    let filtered = documents;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(doc => 
        doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doc.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doc.organization_name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply category filter
    if (categoryFilter) {
      filtered = filtered.filter(doc => doc.category === categoryFilter);
    }

    // Apply organization filter
    if (organizationFilter) {
      filtered = filtered.filter(doc => doc.organization_id === organizationFilter);
    }

    // Apply public/private filter
    if (publicFilter === "public") {
      filtered = filtered.filter(doc => doc.is_public);
    } else if (publicFilter === "private") {
      filtered = filtered.filter(doc => !doc.is_public);
    }

    setFilteredDocs(filtered);
  }, [searchTerm, categoryFilter, organizationFilter, publicFilter, documents]);

  const formatFileSize = (sizeInBytes) => {
    if (sizeInBytes < 1024) {
      return `${sizeInBytes} B`;
    } else if (sizeInBytes < 1024 * 1024) {
      return `${(sizeInBytes / 1024).toFixed(1)} KB`;
    } else {
      return `${(sizeInBytes / (1024 * 1024)).toFixed(1)} MB`;
    }
  };

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), 'dd MMM yyyy', { locale: ptBR });
    } catch {
      return dateString;
    }
  };

  const getCategoryLabel = (category) => {
    const categories = {
      legal: { label: "Legal", color: "bg-blue-100 text-blue-800" },
      financial: { label: "Financeiro", color: "bg-green-100 text-green-800" },
      certification: { label: "Certificação", color: "bg-purple-100 text-purple-800" },
      governance: { label: "Governança", color: "bg-orange-100 text-orange-800" },
      members: { label: "Membros", color: "bg-indigo-100 text-indigo-800" }
    };
    
    return categories[category] || { label: category, color: "bg-gray-100 text-gray-800" };
  };

  const getFileIcon = (fileType) => {
    switch (fileType) {
      case 'pdf': return <FileText className="w-5 h-5 text-red-500" />;
      case 'xlsx': return <FileText className="w-5 h-5 text-green-500" />;
      case 'docx': return <FileText className="w-5 h-5 text-blue-500" />;
      default: return <FileText className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Documentos de Transparência</h1>
          <p className="text-gray-500 mt-1">
            Gerencie os documentos públicos de transparência das organizações
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button className="gap-2">
            <UploadCloud className="w-4 h-4" />
            Enviar Documento
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar documentos..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex flex-wrap gap-2 w-full md:w-auto justify-end">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Todas as categorias</SelectItem>
              <SelectItem value="legal">Legal</SelectItem>
              <SelectItem value="financial">Financeiro</SelectItem>
              <SelectItem value="certification">Certificação</SelectItem>
              <SelectItem value="governance">Governança</SelectItem>
              <SelectItem value="members">Membros</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={organizationFilter} onValueChange={setOrganizationFilter}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Organização" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Todas as organizações</SelectItem>
              <SelectItem value="org1">MediCannabis Farma</SelectItem>
              <SelectItem value="org2">Associação Médica Verde</SelectItem>
              <SelectItem value="org5">Cannabis Brasil Sul</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={publicFilter} onValueChange={setPublicFilter}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Visibilidade" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Todos</SelectItem>
              <SelectItem value="public">Públicos</SelectItem>
              <SelectItem value="private">Privados</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Documentos</CardTitle>
          <CardDescription>
            {filteredDocs.length} documentos encontrados
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-16 bg-gray-100 rounded-md"></div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Documento</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Organização</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Visibilidade</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDocs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                        Nenhum documento encontrado com os filtros selecionados
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredDocs.map(doc => (
                      <TableRow key={doc.id}>
                        <TableCell>
                          <div className="flex items-start gap-3">
                            <div className="pt-1">
                              {getFileIcon(doc.file_type)}
                            </div>
                            <div>
                              <div className="font-medium">{doc.title}</div>
                              <div className="text-sm text-gray-500">{doc.description}</div>
                              <div className="text-xs text-gray-400 mt-1">
                                {doc.file_type.toUpperCase()} • {formatFileSize(doc.file_size)}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getCategoryLabel(doc.category).color}>
                            {getCategoryLabel(doc.category).label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Building2 className="w-4 h-4 text-gray-400" />
                            <span>{doc.organization_name}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-gray-600">
                            <Calendar className="w-4 h-4" />
                            {formatDate(doc.date)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={doc.is_public ? "default" : "outline"} className={doc.is_public ? "bg-green-100 text-green-800" : ""}>
                            {doc.is_public ? "Público" : "Privado"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <ChevronDown className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem className="cursor-pointer">
                                <Eye className="w-4 h-4 mr-2" />
                                Visualizar
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <Download className="w-4 h-4 mr-2" />
                                Download
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <FileEdit className="w-4 h-4 mr-2" />
                                Editar
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="cursor-pointer text-red-600">
                                <Trash2 className="w-4 h-4 mr-2" />
                                Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}