
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  FileText, 
  UserCheck, 
  Calendar, 
  Clock, 
  BarChart, 
  Search, 
  Filter, 
  Plus, 
  MoreHorizontal, 
  ChevronDown, 
  Clipboard, 
  BookOpen, 
  FileCheck, 
  FileWarning, 
  Eye, 
  Edit, 
  Download, 
  Printer, 
  ChevronRight,
  Users,
  Building,
  Scale,
  BookOpen as BookOpenIcon,
  FileCheck as FileCheckIcon,
  Lock,
  ClipboardList,
  Share2
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

// Dados simulados de compliance
const mockChecklist = [
  {
    id: "check-001",
    titulo: "Cadastro ANVISA",
    categoria: "Regulatório",
    status: "conforme",
    prazo: "2024-07-15",
    responsavel: "Carlos Mendes",
    prioridade: "alta",
    descricao: "Manutenção do cadastro ativo junto à ANVISA para operação com produtos controlados",
    evidencias: ["Certificado ANVISA 2023.pdf", "Comprovante de Taxa 2023.pdf"],
    ultimaVerificacao: "2023-06-10",
    proximaVerificacao: "2023-09-10"
  },
  {
    id: "check-002",
    titulo: "Boas Práticas de Fabricação (BPF)",
    categoria: "Qualidade",
    status: "conforme",
    prazo: "2023-12-31",
    responsavel: "Maria Silva",
    prioridade: "alta",
    descricao: "Conformidade com as diretrizes de Boas Práticas de Fabricação da ANVISA (RDC 301/2019)",
    evidencias: ["Relatório de Auditoria BPF 2023-05.pdf", "Plano de Ação BPF 2023.xlsx"],
    ultimaVerificacao: "2023-05-22",
    proximaVerificacao: "2023-11-22"
  },
  {
    id: "check-003",
    titulo: "Licenças Ambientais",
    categoria: "Ambiental",
    status: "em_andamento",
    prazo: "2023-08-30",
    responsavel: "Pedro Santos",
    prioridade: "média",
    descricao: "Obtenção e manutenção das licenças ambientais necessárias para operação",
    evidencias: ["Protocolo Renovação Licença Ambiental.pdf"],
    ultimaVerificacao: "2023-06-05",
    proximaVerificacao: "2023-07-15"
  },
  {
    id: "check-004",
    titulo: "Controle de Acesso e Segurança",
    categoria: "Segurança",
    status: "conforme",
    prazo: "2023-12-31",
    responsavel: "Roberto Alves",
    prioridade: "alta",
    descricao: "Sistemas de controle de acesso e segurança para áreas restritas de cultivo e produção",
    evidencias: ["Relatório CFTV Junho 2023.pdf", "Registro de Acesso Jun 2023.xlsx"],
    ultimaVerificacao: "2023-06-30",
    proximaVerificacao: "2023-07-31"
  },
  {
    id: "check-005",
    titulo: "Treinamento de Colaboradores",
    categoria: "RH",
    status: "nao_conforme",
    prazo: "2023-07-31",
    responsavel: "Ana Costa",
    prioridade: "alta",
    descricao: "Treinamento periódico dos colaboradores sobre regulamentações e procedimentos de compliance",
    evidencias: ["Plano de Treinamento 2023.pdf"],
    ultimaVerificacao: "2023-06-15",
    proximaVerificacao: "2023-07-15"
  },
  {
    id: "check-006",
    titulo: "Política de Prevenção à Lavagem de Dinheiro",
    categoria: "Financeiro",
    status: "conforme",
    prazo: "2023-12-31",
    responsavel: "Juliana Freitas",
    prioridade: "média",
    descricao: "Implementação e manutenção de políticas de prevenção à lavagem de dinheiro",
    evidencias: ["Política PLD 2023.pdf", "Treinamento PLD Junho 2023.pdf"],
    ultimaVerificacao: "2023-06-20",
    proximaVerificacao: "2023-09-20"
  },
  {
    id: "check-007",
    titulo: "Rastreabilidade de Produtos",
    categoria: "Produção",
    status: "conforme",
    prazo: "2023-12-31",
    responsavel: "Carlos Mendes",
    prioridade: "alta",
    descricao: "Sistema de rastreabilidade do plantio à comercialização dos produtos",
    evidencias: ["Sistema TrackCannabis - Relatório 2023-06.pdf"],
    ultimaVerificacao: "2023-06-30",
    proximaVerificacao: "2023-07-31"
  },
  {
    id: "check-008",
    titulo: "LGPD - Proteção de Dados",
    categoria: "TI",
    status: "em_andamento",
    prazo: "2023-09-30",
    responsavel: "Fernando Gomes",
    prioridade: "alta",
    descricao: "Adequação e conformidade com a Lei Geral de Proteção de Dados",
    evidencias: ["Relatório Gap Analysis LGPD.pdf", "Plano de Ação LGPD 2023.xlsx"],
    ultimaVerificacao: "2023-05-15",
    proximaVerificacao: "2023-07-15"
  }
];

const mockPoliticas = [
  {
    id: "pol-001",
    titulo: "Código de Conduta Ética",
    versao: "2.1",
    dataPublicacao: "2023-01-10",
    responsavel: "Comitê de Ética e Compliance",
    status: "ativo",
    categorias: ["ética", "conduta"],
    descricao: "Diretrizes éticas e comportamentais esperadas de todos os colaboradores e parceiros da organização.",
    documentoUrl: "#",
    obrigatoriedade: "todos"
  },
  {
    id: "pol-002",
    titulo: "Política Anticorrupção",
    versao: "1.3",
    dataPublicacao: "2023-02-15",
    responsavel: "Departamento Jurídico",
    status: "ativo",
    categorias: ["anticorrupção", "ética"],
    descricao: "Diretrizes e procedimentos para prevenção e combate à corrupção em todas as operações da empresa.",
    documentoUrl: "#",
    obrigatoriedade: "todos"
  },
  {
    id: "pol-003",
    titulo: "Política de Segurança da Informação",
    versao: "2.0",
    dataPublicacao: "2023-03-20",
    responsavel: "Departamento de TI",
    status: "ativo",
    categorias: ["segurança", "informação", "TI"],
    descricao: "Diretrizes para garantir a confidencialidade, integridade e disponibilidade das informações da empresa.",
    documentoUrl: "#",
    obrigatoriedade: "todos"
  },
  {
    id: "pol-004",
    titulo: "Política de Prevenção à Lavagem de Dinheiro",
    versao: "1.1",
    dataPublicacao: "2023-04-05",
    responsavel: "Departamento Financeiro",
    status: "ativo",
    categorias: ["financeiro", "PLD"],
    descricao: "Procedimentos para identificação e prevenção de operações suspeitas de lavagem de dinheiro.",
    documentoUrl: "#",
    obrigatoriedade: "financeiro"
  },
  {
    id: "pol-005",
    titulo: "Política de Relacionamento com Órgãos Reguladores",
    versao: "1.2",
    dataPublicacao: "2023-02-28",
    responsavel: "Departamento Jurídico",
    status: "ativo",
    categorias: ["regulatório", "relacionamento institucional"],
    descricao: "Diretrizes para o relacionamento transparente e ético com órgãos reguladores e fiscalizadores.",
    documentoUrl: "#",
    obrigatoriedade: "diretoria,regulatorio,juridico"
  },
  {
    id: "pol-006",
    titulo: "Política de Controle de Acesso e Segurança",
    versao: "2.2",
    dataPublicacao: "2023-05-10",
    responsavel: "Segurança Patrimonial",
    status: "ativo",
    categorias: ["segurança", "acesso"],
    descricao: "Procedimentos de controle de acesso às instalações, especialmente áreas restritas de cultivo e produção.",
    documentoUrl: "#",
    obrigatoriedade: "todos"
  },
  {
    id: "pol-007",
    titulo: "Política de Brindes, Presentes e Hospitalidades",
    versao: "1.0",
    dataPublicacao: "2023-03-15",
    responsavel: "Comitê de Ética e Compliance",
    status: "ativo",
    categorias: ["ética", "relacionamento"],
    descricao: "Diretrizes sobre o oferecimento e recebimento de brindes, presentes e hospitalidades.",
    documentoUrl: "#",
    obrigatoriedade: "todos"
  },
  {
    id: "pol-008",
    titulo: "Política de Privacidade e Proteção de Dados",
    versao: "1.5",
    dataPublicacao: "2023-04-20",
    responsavel: "Departamento Jurídico",
    status: "ativo",
    categorias: ["privacidade", "LGPD", "dados pessoais"],
    descricao: "Diretrizes para tratamento de dados pessoais em conformidade com a LGPD e outras legislações aplicáveis.",
    documentoUrl: "#",
    obrigatoriedade: "todos"
  }
];

const mockTreinamentos = [
  {
    id: "trein-001",
    titulo: "Treinamento de Compliance e Código de Conduta",
    status: "concluído",
    dataInicio: "2023-05-15",
    dataFim: "2023-05-15",
    cargaHoraria: 4,
    modalidade: "presencial",
    participantes: 42,
    instrutor: "Dra. Maria Oliveira",
    departamentos: ["Todos"],
    avaliacao: 4.8,
    certificados: 42
  },
  {
    id: "trein-002",
    titulo: "Workshop de Prevenção à Lavagem de Dinheiro",
    status: "concluído",
    dataInicio: "2023-06-10",
    dataFim: "2023-06-10",
    cargaHoraria: 6,
    modalidade: "presencial",
    participantes: 15,
    instrutor: "Dr. Fernando Gomes",
    departamentos: ["Financeiro", "Comercial", "Jurídico"],
    avaliacao: 4.7,
    certificados: 15
  },
  {
    id: "trein-003",
    titulo: "Curso Online de LGPD",
    status: "em andamento",
    dataInicio: "2023-07-01",
    dataFim: "2023-07-15",
    cargaHoraria: 8,
    modalidade: "online",
    participantes: 68,
    instrutor: "DataPrivacy Consultoria",
    departamentos: ["Todos"],
    avaliacao: null,
    certificados: 23
  },
  {
    id: "trein-004",
    titulo: "Treinamento de Segurança da Informação",
    status: "agendado",
    dataInicio: "2023-08-05",
    dataFim: "2023-08-05",
    cargaHoraria: 4,
    modalidade: "híbrido",
    participantes: 0,
    instrutor: "Equipe TI",
    departamentos: ["Todos"],
    avaliacao: null,
    certificados: 0
  },
  {
    id: "trein-005",
    titulo: "Seminário de Regulação de Cannabis Medicinal",
    status: "concluído",
    dataInicio: "2023-04-20",
    dataFim: "2023-04-21",
    cargaHoraria: 16,
    modalidade: "presencial",
    participantes: 12,
    instrutor: "Dr. Carlos Mendes / Convidados Externos",
    departamentos: ["Regulatório", "Jurídico", "P&D", "Diretoria"],
    avaliacao: 4.9,
    certificados: 12
  }
];

const mockIncidentes = [
  {
    id: "inc-001",
    titulo: "Atraso na renovação da licença ambiental",
    categoria: "regulatório",
    status: "resolvido",
    dataOcorrencia: "2023-02-15",
    dataResolucao: "2023-03-10",
    responsavel: "Pedro Santos",
    gravidade: "média",
    descricao: "Atraso no processo de renovação da licença ambiental devido a documentação incompleta.",
    acaoTomada: "Protocolo emergencial com documentação complementar e pagamento de taxa de urgência.",
    impacto: "Operação em situação irregular por 23 dias, sem autuações.",
    recomendacoes: "Implementar sistema de alerta para vencimento de licenças com 90 dias de antecedência."
  },
  {
    id: "inc-002",
    titulo: "Falha no controle de acesso à área restrita",
    categoria: "segurança",
    status: "resolvido",
    dataOcorrencia: "2023-04-05",
    dataResolucao: "2023-04-05",
    responsavel: "Roberto Alves",
    gravidade: "alta",
    descricao: "Visitante sem credencial adequada teve acesso à área de cultivo sem acompanhamento.",
    acaoTomada: "Retirada imediata do visitante, auditoria completa do sistema de controle de acesso e reforço do procedimento com equipe de segurança.",
    impacto: "Sem impacto material, porém com risco de violação regulatória.",
    recomendacoes: "Retreinamento da equipe de segurança, revisão do procedimento de emissão de crachás temporários."
  },
  {
    id: "inc-003",
    titulo: "Envio de relatório ANVISA com informações inconsistentes",
    categoria: "regulatório",
    status: "resolvido",
    dataOcorrencia: "2023-05-20",
    dataResolucao: "2023-05-25",
    responsavel: "Carlos Mendes",
    gravidade: "alta",
    descricao: "Relatório mensal enviado à ANVISA continha inconsistências nos dados de rastreabilidade de lotes.",
    acaoTomada: "Contato imediato com ANVISA, envio de retificação com esclarecimentos e auditoria interna no sistema de rastreabilidade.",
    impacto: "Advertência formal da ANVISA, sem outras penalidades.",
    recomendacoes: "Implementar processo de verificação dupla antes do envio de relatórios regulatórios."
  },
  {
    id: "inc-004",
    titulo: "Vazamento de e-mail com dados sensíveis de clientes",
    categoria: "LGPD",
    status: "em andamento",
    dataOcorrencia: "2023-07-10",
    dataResolucao: null,
    responsavel: "Fernando Gomes",
    gravidade: "alta",
    descricao: "E-mail contendo lista de pacientes e condições médicas enviado acidentalmente para múltiplos destinatários.",
    acaoTomada: "Notificação aos afetados, solicitação de exclusão do e-mail aos destinatários, comunicação ao comitê de privacidade.",
    impacto: "Em avaliação - potencial exposição de dados sensíveis de 17 pacientes.",
    recomendacoes: "Pendente conclusão da investigação."
  },
  {
    id: "inc-005",
    titulo: "Fornecedor sem documentação completa",
    categoria: "compliance",
    status: "resolvido",
    dataOcorrencia: "2023-03-30",
    dataResolucao: "2023-04-15",
    responsavel: "Juliana Freitas",
    gravidade: "média",
    descricao: "Identificado fornecedor de insumos operando sem toda documentação de due diligence requerida pela política interna.",
    acaoTomada: "Suspensão temporária do fornecedor até regularização completa da documentação.",
    impacto: "Atraso de 2 semanas na entrega de insumos não-críticos.",
    recomendacoes: "Revisar processo de homologação de fornecedores e implementar verificações periódicas."
  }
];

export default function JuridicoCompliance() {
  const [activeTab, setActiveTab] = useState("checklist");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategoria, setFilterCategoria] = useState("todas");
  const [filterStatus, setFilterStatus] = useState("todos");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  // Filtrar itens baseado nos filtros e busca
  const getFilteredItems = (items, type) => {
    if (!items) return [];
    
    return items.filter(item => {
      const matchesTermo = item.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (item.descricao && item.descricao.toLowerCase().includes(searchTerm.toLowerCase()));
      
      let matchesCategoria = true;
      if (type === 'checklist' && filterCategoria !== 'todas') {
        matchesCategoria = item.categoria === filterCategoria;
      } else if (type === 'politicas' && filterCategoria !== 'todas') {
        matchesCategoria = item.categorias && item.categorias.includes(filterCategoria);
      }
      
      let matchesStatus = true;
      if (type === 'checklist' && filterStatus !== 'todos') {
        matchesStatus = item.status === filterStatus;
      } else if (type === 'treinamentos' && filterStatus !== 'todos') {
        matchesStatus = item.status === filterStatus;
      } else if (type === 'incidentes' && filterStatus !== 'todos') {
        matchesStatus = item.status === filterStatus;
      }
      
      return matchesTermo && matchesCategoria && matchesStatus;
    });
  };
  
  const filteredChecklist = getFilteredItems(mockChecklist, 'checklist');
  const filteredPoliticas = getFilteredItems(mockPoliticas, 'politicas');
  const filteredTreinamentos = getFilteredItems(mockTreinamentos, 'treinamentos');
  const filteredIncidentes = getFilteredItems(mockIncidentes, 'incidentes');
  
  // Calcular estatísticas 
  const statsChecklist = {
    total: mockChecklist.length,
    conforme: mockChecklist.filter(item => item.status === 'conforme').length,
    naoConforme: mockChecklist.filter(item => item.status === 'nao_conforme').length,
    emAndamento: mockChecklist.filter(item => item.status === 'em_andamento').length,
    highPriority: mockChecklist.filter(item => item.prioridade === 'alta').length,
  };
  
  const conformidadeRate = statsChecklist.total > 0 
    ? Math.round((statsChecklist.conforme / statsChecklist.total) * 100) 
    : 0;
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Compliance Jurídico</h1>
        <p className="text-gray-500 mt-1">
          Gestão de compliance, políticas corporativas e conformidade legal
        </p>
      </div>
      
      {/* Cards de estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Índice de Conformidade</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-2xl font-bold">{conformidadeRate}%</span>
                <Progress value={conformidadeRate} className="h-2 w-24" />
              </div>
              <div className={`p-3 rounded-full ${
                conformidadeRate >= 90 ? 'bg-green-100' : 
                conformidadeRate >= 70 ? 'bg-yellow-100' : 'bg-red-100'
              }`}>
                <ShieldCheck className={`w-5 h-5 ${
                  conformidadeRate >= 90 ? 'text-green-600' : 
                  conformidadeRate >= 70 ? 'text-yellow-600' : 'text-red-600'
                }`} />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Status dos Requisitos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-2 w-full">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">Conformes</span>
                  <Badge className="bg-green-100 text-green-800 hover:bg-green-100">{statsChecklist.conforme}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">Não Conformes</span>
                  <Badge className="bg-red-100 text-red-800 hover:bg-red-100">{statsChecklist.naoConforme}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">Em Andamento</span>
                  <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">{statsChecklist.emAndamento}</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Próximas Verificações</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-2xl font-bold">3</span>
                <p className="text-xs text-gray-500">Nos próximos 7 dias</p>
              </div>
              <div className="p-3 bg-blue-100 rounded-full">
                <Calendar className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Incidentes Abertos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-2xl font-bold">1</span>
                <p className="text-xs text-gray-500">Requer atenção</p>
              </div>
              <div className="p-3 bg-red-100 rounded-full">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Tabs de conteúdo */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="checklist" className="flex items-center gap-2">
              <ClipboardList className="w-4 h-4" />
              <span>Checklist</span>
            </TabsTrigger>
            <TabsTrigger value="politicas" className="flex items-center gap-2">
              <FileCheck className="w-4 h-4" />
              <span>Políticas</span>
            </TabsTrigger>
            <TabsTrigger value="treinamentos" className="flex items-center gap-2">
              <BookOpenIcon className="w-4 h-4" />
              <span>Treinamentos</span>
            </TabsTrigger>
            <TabsTrigger value="incidentes" className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              <span>Incidentes</span>
            </TabsTrigger>
          </TabsList>
          
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar..."
                className="w-64 pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Novo Item
            </Button>
          </div>
        </div>
        
        {/* Filtros */}
        <div className="flex flex-wrap gap-4 mb-6">
          {(activeTab === "checklist" || activeTab === "politicas") && (
            <Select value={filterCategoria} onValueChange={setFilterCategoria}>
              <SelectTrigger className="w-[180px]">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  <SelectValue placeholder="Categoria" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas Categorias</SelectItem>
                {activeTab === "checklist" ? (
                  <>
                    <SelectItem value="Regulatório">Regulatório</SelectItem>
                    <SelectItem value="Qualidade">Qualidade</SelectItem>
                    <SelectItem value="Ambiental">Ambiental</SelectItem>
                    <SelectItem value="Segurança">Segurança</SelectItem>
                    <SelectItem value="RH">RH</SelectItem>
                    <SelectItem value="Financeiro">Financeiro</SelectItem>
                    <SelectItem value="Produção">Produção</SelectItem>
                    <SelectItem value="TI">TI</SelectItem>
                  </>
                ) : (
                  <>
                    <SelectItem value="ética">Ética</SelectItem>
                    <SelectItem value="conduta">Conduta</SelectItem>
                    <SelectItem value="anticorrupção">Anticorrupção</SelectItem>
                    <SelectItem value="segurança">Segurança</SelectItem>
                    <SelectItem value="privacidade">Privacidade</SelectItem>
                    <SelectItem value="LGPD">LGPD</SelectItem>
                    <SelectItem value="PLD">PLD</SelectItem>
                  </>
                )}
              </SelectContent>
            </Select>
          )}
          
          {(activeTab === "checklist" || activeTab === "treinamentos" || activeTab === "incidentes") && (
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[180px]">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  <SelectValue placeholder="Status" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos Status</SelectItem>
                {activeTab === "checklist" ? (
                  <>
                    <SelectItem value="conforme">Conforme</SelectItem>
                    <SelectItem value="nao_conforme">Não Conforme</SelectItem>
                    <SelectItem value="em_andamento">Em Andamento</SelectItem>
                  </>
                ) : activeTab === "treinamentos" ? (
                  <>
                    <SelectItem value="concluído">Concluído</SelectItem>
                    <SelectItem value="em andamento">Em Andamento</SelectItem>
                    <SelectItem value="agendado">Agendado</SelectItem>
                  </>
                ) : (
                  <>
                    <SelectItem value="resolvido">Resolvido</SelectItem>
                    <SelectItem value="em andamento">Em Andamento</SelectItem>
                  </>
                )}
              </SelectContent>
            </Select>
          )}
        </div>
        
        <TabsContent value="checklist">
          <Card>
            <CardHeader>
              <CardTitle>Checklist de Compliance</CardTitle>
              <CardDescription>
                Acompanhamento dos requisitos legais e normativos aplicáveis à operação
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[300px]">Item</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Responsável</TableHead>
                    <TableHead>Próxima Verificação</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredChecklist.length > 0 ? (
                    filteredChecklist.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.titulo}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{item.categoria}</Badge>
                        </TableCell>
                        <TableCell>
                          {item.status === 'conforme' && (
                            <Badge className="bg-green-100 text-green-800">Conforme</Badge>
                          )}
                          {item.status === 'nao_conforme' && (
                            <Badge className="bg-red-100 text-red-800">Não Conforme</Badge>
                          )}
                          {item.status === 'em_andamento' && (
                            <Badge className="bg-yellow-100 text-yellow-800">Em Andamento</Badge>
                          )}
                        </TableCell>
                        <TableCell>{item.responsavel}</TableCell>
                        <TableCell>{new Date(item.proximaVerificacao).toLocaleDateString()}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem className="cursor-pointer">
                                <Eye className="w-4 h-4 mr-2" />
                                Ver Detalhes
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <Edit className="w-4 h-4 mr-2" />
                                Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <FileText className="w-4 h-4 mr-2" />
                                Ver Evidências
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="cursor-pointer">
                                <Download className="w-4 h-4 mr-2" />
                                Exportar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-6 text-gray-500">
                        Nenhum item encontrado para os filtros atuais.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="politicas">
          <Card>
            <CardHeader>
              <CardTitle>Políticas e Normas</CardTitle>
              <CardDescription>
                Documentos normativos que orientam a conduta e procedimentos da organização
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredPoliticas.length > 0 ? (
                  filteredPoliticas.map((politica) => (
                    <Card key={politica.id} className="border border-gray-200">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-base">{politica.titulo}</CardTitle>
                            <CardDescription>V{politica.versao} • Publicada em {new Date(politica.dataPublicacao).toLocaleDateString()}</CardDescription>
                          </div>
                          <Badge className="bg-blue-100 text-blue-800">
                            <FileCheck className="w-3 h-3 mr-1" />
                            Ativo
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <p className="text-sm text-gray-600 mb-3">{politica.descricao}</p>
                        <div className="flex flex-wrap gap-1.5 mb-3">
                          {politica.categorias.map((cat, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">{cat}</Badge>
                          ))}
                        </div>
                        <div className="flex justify-between items-center text-xs text-gray-500">
                          <span>Responsável: {politica.responsavel}</span>
                          <span>
                            {politica.obrigatoriedade === 'todos' ? 'Para todos' : `Para ${politica.obrigatoriedade}`}
                          </span>
                        </div>
                      </CardContent>
                      <CardFooter className="pt-0 flex justify-between">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          Visualizar
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="cursor-pointer">
                              <Download className="w-4 h-4 mr-2" />
                              Baixar PDF
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer">
                              <Printer className="w-4 h-4 mr-2" />
                              Imprimir
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer">
                              <Share2 className="w-4 h-4 mr-2" />
                              Compartilhar
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="cursor-pointer">
                              <Edit className="w-4 h-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </CardFooter>
                    </Card>
                  ))
                ) : (
                  <Card className="p-8 text-center md:col-span-2">
                    <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <h3 className="text-lg font-medium text-gray-900">Nenhuma política encontrada</h3>
                    <p className="text-gray-500 mt-1 max-w-md mx-auto">
                      {searchTerm 
                        ? `Não encontramos políticas correspondentes a "${searchTerm}"`
                        : "Não há políticas para os filtros atuais."}
                    </p>
                    {searchTerm && (
                      <Button 
                        variant="outline" 
                        className="mt-4"
                        onClick={() => setSearchTerm("")}
                      >
                        Limpar busca
                      </Button>
                    )}
                  </Card>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="treinamentos">
          <Card>
            <CardHeader>
              <CardTitle>Treinamentos de Compliance</CardTitle>
              <CardDescription>
                Capacitações realizadas e programadas sobre temas de compliance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[300px]">Treinamento</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Participantes</TableHead>
                    <TableHead>Carga Horária</TableHead>
                    <TableHead>Avaliação</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTreinamentos.length > 0 ? (
                    filteredTreinamentos.map((treinamento) => (
                      <TableRow key={treinamento.id}>
                        <TableCell className="font-medium">{treinamento.titulo}</TableCell>
                        <TableCell>
                          {treinamento.status === 'concluído' && (
                            <Badge className="bg-green-100 text-green-800">Concluído</Badge>
                          )}
                          {treinamento.status === 'em andamento' && (
                            <Badge className="bg-blue-100 text-blue-800">Em Andamento</Badge>
                          )}
                          {treinamento.status === 'agendado' && (
                            <Badge className="bg-yellow-100 text-yellow-800">Agendado</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {new Date(treinamento.dataInicio).toLocaleDateString()}
                          {treinamento.dataInicio !== treinamento.dataFim && 
                            ` a ${new Date(treinamento.dataFim).toLocaleDateString()}`}
                        </TableCell>
                        <TableCell>{treinamento.participantes}</TableCell>
                        <TableCell>{treinamento.cargaHoraria}h</TableCell>
                        <TableCell>
                          {treinamento.avaliacao ? (
                            <div className="flex items-center">
                              <span className="mr-1">{treinamento.avaliacao}</span>
                              <div className="bg-yellow-100 text-yellow-800 w-5 h-5 rounded-full flex items-center justify-center text-xs">★</div>
                            </div>
                          ) : (
                            <span className="text-gray-400">N/A</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem className="cursor-pointer">
                                <Eye className="w-4 h-4 mr-2" />
                                Ver Detalhes
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <Users className="w-4 h-4 mr-2" />
                                Ver Participantes
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <FileCheck className="w-4 h-4 mr-2" />
                                Certificados
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="cursor-pointer">
                                <Download className="w-4 h-4 mr-2" />
                                Exportar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-6 text-gray-500">
                        Nenhum treinamento encontrado para os filtros atuais.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="incidentes">
          <Card>
            <CardHeader>
              <CardTitle>Incidentes de Compliance</CardTitle>
              <CardDescription>
                Registro e gerenciamento de violações e incidentes de compliance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredIncidentes.length > 0 ? (
                  filteredIncidentes.map((incidente) => (
                    <Collapsible key={incidente.id} className="border rounded-lg">
                      <CollapsibleTrigger className="flex justify-between items-center w-full p-4 text-left">
                        <div className="flex items-center gap-4">
                          {incidente.status === 'resolvido' ? (
                            <div className="bg-green-100 p-2 rounded-full">
                              <CheckCircle2 className="w-5 h-5 text-green-600" />
                            </div>
                          ) : (
                            <div className="bg-red-100 p-2 rounded-full">
                              <AlertTriangle className="w-5 h-5 text-red-600" />
                            </div>
                          )}
                          <div>
                            <h3 className="font-medium">{incidente.titulo}</h3>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline">{incidente.categoria}</Badge>
                              {incidente.status === 'resolvido' ? (
                                <Badge className="bg-green-100 text-green-800">Resolvido</Badge>
                              ) : (
                                <Badge className="bg-red-100 text-red-800">Em andamento</Badge>
                              )}
                              <span className="text-xs text-gray-500">
                                Reportado em {new Date(incidente.dataOcorrencia).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        </div>
                        <ChevronDown className="h-5 w-5 text-gray-500 shrink-0" />
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <div className="px-4 pb-4 pt-0 border-t">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
                            <div className="space-y-3">
                              <h4 className="text-sm font-medium">Detalhes do Incidente</h4>
                              <p className="text-sm">{incidente.descricao}</p>
                              
                              <div>
                                <h5 className="text-xs font-medium text-gray-500 mb-1">Gravidade</h5>
                                {incidente.gravidade === 'alta' && (
                                  <Badge className="bg-red-100 text-red-800">Alta</Badge>
                                )}
                                {incidente.gravidade === 'média' && (
                                  <Badge className="bg-yellow-100 text-yellow-800">Média</Badge>
                                )}
                                {incidente.gravidade === 'baixa' && (
                                  <Badge className="bg-green-100 text-green-800">Baixa</Badge>
                                )}
                              </div>
                              
                              <div>
                                <h5 className="text-xs font-medium text-gray-500 mb-1">Responsável</h5>
                                <p className="text-sm">{incidente.responsavel}</p>
                              </div>
                            </div>
                            
                            <div className="space-y-3">
                              <h4 className="text-sm font-medium">Ação Tomada</h4>
                              <p className="text-sm">{incidente.acaoTomada}</p>
                              
                              <div>
                                <h5 className="text-xs font-medium text-gray-500 mb-1">Impacto</h5>
                                <p className="text-sm">{incidente.impacto}</p>
                              </div>
                              
                              {incidente.dataResolucao && (
                                <div>
                                  <h5 className="text-xs font-medium text-gray-500 mb-1">Data de Resolução</h5>
                                  <p className="text-sm">{new Date(incidente.dataResolucao).toLocaleDateString()}</p>
                                </div>
                              )}
                            </div>
                            
                            <div className="space-y-3">
                              <h4 className="text-sm font-medium">Recomendações</h4>
                              <p className="text-sm">{incidente.recomendacoes}</p>
                              
                              <div className="flex justify-end mt-6 gap-2">
                                <Button variant="outline" size="sm">
                                  <FileText className="w-4 h-4 mr-2" />
                                  Relatório
                                </Button>
                                <Button size="sm">
                                  <Eye className="w-4 h-4 mr-2" />
                                  Ver Detalhes
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  ))
                ) : (
                  <Card className="p-8 text-center">
                    <ShieldCheck className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <h3 className="text-lg font-medium text-gray-900">Nenhum incidente encontrado</h3>
                    <p className="text-gray-500 mt-1 max-w-md mx-auto">
                      {searchTerm 
                        ? `Não encontramos incidentes correspondentes a "${searchTerm}"`
                        : "Não há incidentes para os filtros atuais."}
                    </p>
                    {searchTerm && (
                      <Button 
                        variant="outline" 
                        className="mt-4"
                        onClick={() => setSearchTerm("")}
                      >
                        Limpar busca
                      </Button>
                    )}
                  </Card>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Diálogo para adicionar novo item */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Adicionar Novo Item de Compliance</DialogTitle>
            <DialogDescription>
              Preencha as informações abaixo para adicionar um novo item ao sistema.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="item-type">Tipo de Item</Label>
              <Select defaultValue="checklist">
                <SelectTrigger id="item-type">
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="checklist">Item de Checklist</SelectItem>
                  <SelectItem value="politica">Política/Norma</SelectItem>
                  <SelectItem value="treinamento">Treinamento</SelectItem>
                  <SelectItem value="incidente">Incidente</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="titulo">Título</Label>
              <Input id="titulo" placeholder="Digite o título do item" />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="categoria">Categoria</Label>
                <Select>
                  <SelectTrigger id="categoria">
                    <SelectValue placeholder="Selecione a categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="regulatorio">Regulatório</SelectItem>
                    <SelectItem value="qualidade">Qualidade</SelectItem>
                    <SelectItem value="ambiental">Ambiental</SelectItem>
                    <SelectItem value="seguranca">Segurança</SelectItem>
                    <SelectItem value="rh">RH</SelectItem>
                    <SelectItem value="financeiro">Financeiro</SelectItem>
                    <SelectItem value="producao">Produção</SelectItem>
                    <SelectItem value="ti">TI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select>
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="conforme">Conforme</SelectItem>
                    <SelectItem value="nao_conforme">Não Conforme</SelectItem>
                    <SelectItem value="em_andamento">Em Andamento</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="descricao">Descrição</Label>
              <Input id="descricao" placeholder="Digite uma descrição detalhada" />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="responsavel">Responsável</Label>
                <Input id="responsavel" placeholder="Nome do responsável" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="prazo">Prazo</Label>
                <Input id="prazo" type="date" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancelar</Button>
            <Button onClick={() => setIsAddDialogOpen(false)}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
