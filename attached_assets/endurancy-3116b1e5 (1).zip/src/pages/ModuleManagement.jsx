
import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Leaf, 
  Factory, 
  Heart, 
  Briefcase, 
  Glasses, 
  Plus, 
  Info, 
  Settings,
  Check,
  Truck,
  Package,
  ShoppingBag,
  Tag,
  QrCode,
  AlertTriangle,
  BadgePercent,
  BadgeDollarSign,
  Search,
  Users,
  Scale
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

const modules = [
  {
    id: "cultivo",
    name: "Cultivo",
    description: "Gestão completa do cultivo de cannabis medicinal",
    icon: Leaf,
    color: "green",
    active: true,
    activeOrganizations: 15,
    hasFreeVersion: false,
    features: [
      { name: "Gestão de plantas", included: true },
      { name: "Rastreabilidade", included: true },
      { name: "Controle de lotes", included: true },
      { name: "Análises laboratoriais", included: true }
    ]
  },
  {
    id: "producao",
    name: "Produção",
    description: "Controle de produção e qualidade",
    icon: Factory,
    color: "yellow",
    active: true,
    activeOrganizations: 12,
    hasFreeVersion: false,
    features: [
      { name: "Controle de qualidade", included: true },
      { name: "Gestão de fornecedores", included: true },
      { name: "Ordens de produção", included: true },
      { name: "Matérias-primas", included: true }
    ]
  },
  {
    id: "crm",
    name: "CRM",
    description: "Gestão de pacientes e prescrições",
    icon: Heart,
    color: "purple",
    active: true,
    activeOrganizations: 18,
    hasFreeVersion: false,
    features: [
      { name: "Cadastro de pacientes", included: true },
      { name: "Gestão de prescrições", included: true },
      { name: "Atendimento", included: true },
      { name: "Campanhas", included: true }
    ]
  },
  {
    id: "associados",
    name: "Associados",
    description: "Gestão completa de associados e anuidades",
    icon: Users,
    color: "blue",
    active: true,
    activeOrganizations: 25,
    hasFreeVersion: true,
    features: [
      { name: "Cadastro de associados", included: true },
      { name: "Controle de anuidades", included: true },
      { name: "Documentos", included: true },
      { name: "Histórico completo", included: true }
    ]
  },
  {
    id: "vendas",
    name: "Vendas",
    description: "Gestão de pedidos, produtos e envios",
    icon: ShoppingBag,
    color: "green",
    active: true,
    activeOrganizations: 22,
    hasFreeVersion: true,
    features: [
      { name: "Gestão de pedidos", included: true },
      { name: "Cadastro de produtos", included: true },
      { name: "Etiquetas de envio", included: true },
      { name: "Rastreabilidade de pedidos", included: true }
    ]
  },
  {
    id: "rh",
    name: "RH",
    description: "Gestão de recursos humanos",
    icon: Briefcase,
    color: "indigo",
    active: true,
    activeOrganizations: 10,
    hasFreeVersion: false,
    features: [
      { name: "Cadastro de colaboradores", included: true },
      { name: "Recrutamento", included: true },
      { name: "Documentos", included: true },
      { name: "Escalas", included: true }
    ]
  },
  {
    id: "transparencia",
    name: "Transparência",
    description: "Portal de transparência para associações",
    icon: Glasses,
    color: "blue",
    active: true,
    activeOrganizations: 8,
    hasFreeVersion: false,
    features: [
      { name: "Portal público", included: true },
      { name: "Documentos públicos", included: true },
      { name: "Relatórios financeiros", included: true },
      { name: "Membros e governança", included: true }
    ]
  },
  {
    id: "juridico",
    name: "Jurídico",
    description: "Gestão de ações judiciais para fornecimento de medicamentos e autorizações ANVISA",
    icon: Scale,
    price: 199,
    features: [
      { name: "Acompanhamento de processos judiciais", included: true },
      { name: "Controle de liminares e decisões judiciais", included: true },
      { name: "Gestão de documentos processuais", included: true },
      { name: "Calendário de audiências e prazos", included: true },
      { name: "Relatórios e estatísticas de processos", included: true }
    ]
  }
];

export default function ModuleManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedModule, setSelectedModule] = useState(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [filteredModules, setFilteredModules] = useState(modules);
  const [showFreeModulesOnly, setShowFreeModulesOnly] = useState(false);

  useEffect(() => {
    let filtered = modules;
    
    if (searchTerm.trim() !== "") {
      filtered = filtered.filter(module => 
        module.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        module.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (showFreeModulesOnly) {
      filtered = filtered.filter(module => module.hasFreeVersion);
    }
    
    setFilteredModules(filtered);
  }, [searchTerm, showFreeModulesOnly]);

  const handleModuleSelect = (module) => {
    setSelectedModule(module);
    setShowAddDialog(true);
  };

  const getModuleStatusBadge = (module) => {
    if (module.active) {
      return <Badge className="bg-green-100 text-green-800">Ativo</Badge>
    } else {
      return <Badge variant="outline" className="text-gray-500">Inativo</Badge>
    }
  };

  const getModuleColorClass = (color) => {
    switch (color) {
      case 'green': return 'bg-green-100 text-green-800';
      case 'yellow': return 'bg-yellow-100 text-yellow-800';
      case 'purple': return 'bg-purple-100 text-purple-800';
      case 'indigo': return 'bg-indigo-100 text-indigo-800';
      case 'blue': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleAddModule = () => {
    toast({
      title: "Módulo adicionado",
      description: `O módulo ${selectedModule.name} foi adicionado com sucesso.`,
    });
    setShowAddDialog(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gestão de Módulos</h1>
          <p className="text-gray-500 mt-1">
            Configure os módulos disponíveis para as organizações
          </p>
        </div>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Novo Módulo
        </Button>
      </div>

      <Card className="mb-6">
        <CardHeader className="pb-4">
          <CardTitle>Destaque - Novo Módulo Gratuito</CardTitle>
          <CardDescription>
            Módulo de Vendas disponível gratuitamente para todas as organizações
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-green-50 p-4 rounded-lg border border-green-100">
            <div className="flex items-start gap-4">
              <div className="bg-green-100 p-3 rounded-full">
                <ShoppingBag className="h-6 w-6 text-green-600" />
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium text-lg">Módulo de Vendas Gratuito</h3>
                  <Badge className="bg-green-100 text-green-800">Novo</Badge>
                  <Badge className="bg-blue-100 text-blue-800">Gratuito</Badge>
                </div>
                <p className="text-gray-600">
                  Disponibilizamos um módulo gratuito para todas as organizações que permite a gestão completa de pedidos, 
                  produtos, impressão de etiquetas de envio e rastreabilidade. Ideal para organizações que estão começando.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-3">
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Gestão de pedidos</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Cadastro de produtos</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Etiquetas de envio</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Rastreabilidade de pedidos</span>
                  </div>
                </div>
                <div className="pt-2">
                  <Link to={createPageUrl("ModuloVendas")}>
                    <Button variant="outline" className="gap-2">
                      <Info className="h-4 w-4" />
                      Ver detalhes do módulo
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col md:flex-row gap-4 justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input 
            placeholder="Buscar módulos..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex items-center gap-2">
          <Label htmlFor="free-modules" className="cursor-pointer">Mostrar apenas módulos gratuitos</Label>
          <Switch 
            id="free-modules" 
            checked={showFreeModulesOnly}
            onCheckedChange={setShowFreeModulesOnly}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredModules.map((module) => (
          <Card key={module.id} className="overflow-hidden">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${getModuleColorClass(module.color)}`}>
                    <module.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <CardTitle>{module.name}</CardTitle>
                    <CardDescription>{module.description}</CardDescription>
                  </div>
                </div>
                <div className="flex gap-2">
                  {getModuleStatusBadge(module)}
                  {module.hasFreeVersion && (
                    <Badge className="bg-blue-100 text-blue-800">Gratuito</Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="space-y-2 mt-1">
                {module.features.slice(0, 4).map((feature, index) => (
                  <div key={index} className="flex items-center text-sm">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    <span>{feature.name}</span>
                  </div>
                ))}
              </div>
              <div className="text-sm text-gray-500 mt-3">
                {module.activeOrganizations} organizações ativas
              </div>
            </CardContent>
            <CardFooter className="flex justify-between pt-2 pb-4">
              <Link to={`${createPageUrl(`Modulo${module.name}`)}`}>
                <Button variant="outline" size="sm">Ver detalhes</Button>
              </Link>
              <Button size="sm" onClick={() => handleModuleSelect(module)}>
                Adicionar a organização
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {selectedModule 
                ? `Adicionar Módulo ${selectedModule.name}`
                : 'Adicionar Novo Módulo'}
            </DialogTitle>
            <DialogDescription>
              {selectedModule 
                ? `Configure o módulo ${selectedModule.name} para uma organização`
                : 'Crie um novo módulo na plataforma'}
            </DialogDescription>
          </DialogHeader>
          
          {selectedModule ? (
            <>
              <div className="space-y-4 py-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${getModuleColorClass(selectedModule.color)}`}>
                    <selectedModule.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-medium">{selectedModule.name}</h4>
                    <p className="text-sm text-gray-500">{selectedModule.description}</p>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Label>Organização</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma organização" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="org1">MediCannabis Farma</SelectItem>
                      <SelectItem value="org2">Associação Médica Verde</SelectItem>
                      <SelectItem value="org3">CannaPesquisa Instituto</SelectItem>
                      <SelectItem value="org4">Green Medical Brasil</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Plano</Label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {selectedModule.hasFreeVersion && (
                      <div className="flex items-center space-x-2">
                        <input type="radio" id="plan-free" name="plan" className="form-radio" defaultChecked />
                        <label htmlFor="plan-free" className="cursor-pointer">
                          <div className="font-medium">Gratuito</div>
                          <div className="text-xs text-gray-500">Básico</div>
                        </label>
                      </div>
                    )}
                    <div className="flex items-center space-x-2">
                      <input type="radio" id="plan-basic" name="plan" className="form-radio" defaultChecked={!selectedModule.hasFreeVersion} />
                      <label htmlFor="plan-basic" className="cursor-pointer">
                        <div className="font-medium">Básico</div>
                        <div className="text-xs text-gray-500">R$ 399/mês</div>
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="radio" id="plan-pro" name="plan" className="form-radio" />
                      <label htmlFor="plan-pro" className="cursor-pointer">
                        <div className="font-medium">Profissional</div>
                        <div className="text-xs text-gray-500">R$ 799/mês</div>
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="radio" id="plan-enterprise" name="plan" className="form-radio" />
                      <label htmlFor="plan-enterprise" className="cursor-pointer">
                        <div className="font-medium">Enterprise</div>
                        <div className="text-xs text-gray-500">R$ 1299/mês</div>
                      </label>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="module-active">Ativar módulo imediatamente</Label>
                    <Switch id="module-active" defaultChecked />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancelar</Button>
                </DialogClose>
                <Button onClick={handleAddModule}>Adicionar Módulo</Button>
              </DialogFooter>
            </>
          ) : (
            <div className="space-y-4 py-4">
              <p>Formulário para criar um novo módulo na plataforma.</p>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancelar</Button>
                </DialogClose>
                <Button>Criar Módulo</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
