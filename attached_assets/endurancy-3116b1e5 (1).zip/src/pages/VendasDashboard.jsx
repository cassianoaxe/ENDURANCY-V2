import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ShoppingBag, 
  TrendingUp, 
  Package, 
  Tag, 
  Truck,
  ShoppingCart,
  Plus,
  BarChart,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  AlertTriangle,
  CheckCircle,
  Clock3,
  Search,
  Calendar,
  Download,
  FileText,
  Filter
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

// Dados mockados para demonstração
const vendasMensais = [
  { mes: 'Jan', valor: 12800 },
  { mes: 'Fev', valor: 14500 },
  { mes: 'Mar', valor: 18200 },
  { mes: 'Abr', valor: 16900 },
  { mes: 'Mai', valor: 21300 },
  { mes: 'Jun', valor: 25600 },
  { mes: 'Jul', valor: 28400 }
];

const pedidosPorStatus = [
  { nome: 'Aguardando pagamento', valor: 12, cor: '#f59e0b' },
  { nome: 'Em preparação', valor: 18, cor: '#3b82f6' },
  { nome: 'Em transporte', valor: 24, cor: '#8b5cf6' },
  { nome: 'Entregue', valor: 45, cor: '#10b981' },
  { nome: 'Cancelado', valor: 5, cor: '#ef4444' }
];

const CORES = ['#f59e0b', '#3b82f6', '#8b5cf6', '#10b981', '#ef4444'];

const pedidosRecentes = [
  {
    id: 'P12345',
    cliente: 'Maria Silva',
    data: '21/07/2023',
    valor: 356.80,
    status: 'entregue',
    produtos: ['Óleo CBD 10%', 'Cápsulas CBD 20mg']
  },
  {
    id: 'P12346',
    cliente: 'João Pereira',
    data: '22/07/2023',
    valor: 124.50,
    status: 'em_transporte',
    produtos: ['Óleo CBD 5%']
  },
  {
    id: 'P12347',
    cliente: 'Ana Costa',
    data: '22/07/2023',
    valor: 289.90,
    status: 'preparando',
    produtos: ['Extrato Full Spectrum', 'Creme Tópico CBD']
  },
  {
    id: 'P12348',
    cliente: 'Carlos Santos',
    data: '23/07/2023',
    valor: 432.15,
    status: 'aguardando_pagamento',
    produtos: ['Óleo CBD 15%', 'Spray Sublingual THC/CBD']
  },
  {
    id: 'P12349',
    cliente: 'Fernanda Lima',
    data: '23/07/2023',
    valor: 178.90,
    status: 'cancelado',
    produtos: ['Óleo CBD 10%']
  }
];

const produtosMaisVendidos = [
  {
    id: 'prod1',
    nome: 'Óleo CBD 10% 30ml',
    imagem: 'OC',
    vendas: 145,
    valor: 22980,
    estoque: 32
  },
  {
    id: 'prod2',
    nome: 'Cápsulas CBD 20mg',
    imagem: 'CC',
    vendas: 98,
    valor: 12740,
    estoque: 120
  },
  {
    id: 'prod3',
    nome: 'Extrato Full Spectrum 10ml',
    imagem: 'EF',
    vendas: 76,
    valor: 15960,
    estoque: 18
  },
  {
    id: 'prod4',
    nome: 'Spray Sublingual THC/CBD',
    imagem: 'SS',
    vendas: 59,
    valor: 9440,
    estoque: 45
  }
];

export default function VendasDashboard() {
  const [periodoFiltro, setPeriodoFiltro] = useState('mes');
  const [isLoading, setIsLoading] = useState(false);

  // Formatar moeda em reais
  const formatarMoeda = (valor) => {
    return valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  };

  // Badge para status do pedido
  const getStatusBadge = (status) => {
    switch (status) {
      case 'entregue':
        return <Badge className="bg-green-100 text-green-800">Entregue</Badge>;
      case 'em_transporte':
        return <Badge className="bg-purple-100 text-purple-800">Em transporte</Badge>;
      case 'preparando':
        return <Badge className="bg-blue-100 text-blue-800">Preparando</Badge>;
      case 'aguardando_pagamento':
        return <Badge className="bg-yellow-100 text-yellow-800">Aguardando pagamento</Badge>;
      case 'cancelado':
        return <Badge className="bg-red-100 text-red-800">Cancelado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Dashboard de Vendas</h1>
          <p className="text-gray-500 mt-1">
            Gerencie seus pedidos, produtos e envios
          </p>
        </div>
        
        <div className="flex gap-2">
          <Link to={createPageUrl("Pedidos")}>
            <Button variant="outline" className="gap-2">
              <ShoppingCart className="w-4 h-4" />
              Ver Pedidos
            </Button>
          </Link>
          <Link to={createPageUrl("Produtos")}>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Novo Produto
            </Button>
          </Link>
        </div>
      </div>

      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total de Vendas</CardDescription>
            <CardTitle className="text-3xl font-bold">
              {formatarMoeda(65890)}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-green-600">
              <ArrowUpRight className="w-4 h-4 mr-1" />
              +12% em relação ao mês anterior
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Pedidos no Mês</CardDescription>
            <CardTitle className="text-3xl font-bold">324</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-green-600">
              <ArrowUpRight className="w-4 h-4 mr-1" />
              +8% em relação ao mês anterior
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Ticket Médio</CardDescription>
            <CardTitle className="text-3xl font-bold">
              {formatarMoeda(203.36)}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-red-600">
              <ArrowDownRight className="w-4 h-4 mr-1" />
              -3% em relação ao mês anterior
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Taxa de Entregas no Prazo</CardDescription>
            <CardTitle className="text-3xl font-bold">92%</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-green-600">
              <ArrowUpRight className="w-4 h-4 mr-1" />
              +2% em relação ao mês anterior
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos e Painéis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Vendas Mensais</CardTitle>
              <Select value={periodoFiltro} onValueChange={setPeriodoFiltro}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mes">Últimos 7 meses</SelectItem>
                  <SelectItem value="semana">Últimas 4 semanas</SelectItem>
                  <SelectItem value="dia">Últimos 14 dias</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart data={vendasMensais}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip 
                    formatter={(valor) => formatarMoeda(valor)}
                    labelFormatter={(mes) => `Mês: ${mes}`}
                  />
                  <Legend />
                  <Bar dataKey="valor" name="Vendas" fill="#3b82f6" />
                </RechartsBarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Status dos Pedidos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pedidosPorStatus}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="valor"
                    nameKey="nome"
                    label={({ nome, percent }) => `${nome}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {pedidosPorStatus.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={CORES[index % CORES.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(valor) => `${valor} pedidos`} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pedidos">
        <TabsList className="mb-4">
          <TabsTrigger value="pedidos">Pedidos Recentes</TabsTrigger>
          <TabsTrigger value="produtos">Produtos Mais Vendidos</TabsTrigger>
        </TabsList>
        
        <TabsContent value="pedidos">
          <Card>
            <CardHeader className="pb-0">
              <div className="flex justify-between items-center">
                <CardTitle>Pedidos Recentes</CardTitle>
                <Link to={createPageUrl("Pedidos")}>
                  <Button variant="ghost" size="sm" className="gap-2">
                    <ShoppingCart className="w-4 h-4" />
                    Ver Todos
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Pedido</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Cliente</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Data</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Valor</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Produtos</th>
                        <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {isLoading ? (
                        [...Array(3)].map((_, i) => (
                          <tr key={i} className="animate-pulse bg-white">
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-16"></div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-32"></div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-20"></div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-20"></div>
                            </td>
                            <td className="px-4 py-3">
                              <div className="h-5 bg-gray-200 rounded w-40"></div>
                            </td>
                            <td className="px-4 py-3 text-right">
                              <div className="h-5 bg-gray-200 rounded w-24 ml-auto"></div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        pedidosRecentes.map((pedido, i) => (
                          <tr key={pedido.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                            <td className="px-4 py-3 text-sm font-medium">#{pedido.id}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{pedido.cliente}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{pedido.data}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">
                              {formatarMoeda(pedido.valor)}
                            </td>
                            <td className="px-4 py-3 text-sm text-gray-700">
                              {pedido.produtos.map((p, index) => (
                                <span key={index}>
                                  {p}{index < pedido.produtos.length - 1 ? ', ' : ''}
                                </span>
                              ))}
                            </td>
                            <td className="px-4 py-3 text-right">
                              {getStatusBadge(pedido.status)}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="produtos">
          <Card>
            <CardHeader className="pb-0">
              <div className="flex justify-between items-center">
                <CardTitle>Produtos Mais Vendidos</CardTitle>
                <Link to={createPageUrl("Produtos")}>
                  <Button variant="ghost" size="sm" className="gap-2">
                    <Package className="w-4 h-4" />
                    Ver Todos
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Produto</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Vendas</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Valor Total</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Estoque</th>
                        <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {produtosMaisVendidos.map((produto, i) => (
                        <tr key={produto.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback className="bg-primary/10 text-primary">
                                  {produto.imagem}
                                </AvatarFallback>
                              </Avatar>
                              <span className="text-sm font-medium">{produto.nome}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-700">{produto.vendas} unidades</td>
                          <td className="px-4 py-3 text-sm text-gray-700">
                            {formatarMoeda(produto.valor)}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <span className="text-sm text-gray-700">{produto.estoque} un.</span>
                              {produto.estoque < 20 && (
                                <Badge className="bg-red-100 text-red-800">Baixo</Badge>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <Button variant="ghost" size="sm">Detalhes</Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Alertas e Notificações</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3 p-3 bg-yellow-50 border border-yellow-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                <div>
                  <h4 className="font-medium">Produtos com Estoque Baixo</h4>
                  <p className="text-sm text-gray-600">3 produtos estão com estoque crítico. Verifique o estoque.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 bg-blue-50 border border-blue-100 rounded-lg">
                <Clock className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <h4 className="font-medium">Pedidos Aguardando Processamento</h4>
                  <p className="text-sm text-gray-600">8 pedidos aguardam processamento há mais de 24h.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 bg-green-50 border border-green-100 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <h4 className="font-medium">Novos Pedidos Hoje</h4>
                  <p className="text-sm text-gray-600">12 novos pedidos foram recebidos hoje.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <Link to={createPageUrl("Pedidos")}>
                <Button variant="outline" className="w-full justify-start gap-2 p-4 h-auto">
                  <ShoppingCart className="w-5 h-5 text-blue-600" />
                  <div className="text-left">
                    <div className="font-medium">Gerenciar Pedidos</div>
                    <div className="text-xs text-gray-500">Ver e atualizar pedidos</div>
                  </div>
                </Button>
              </Link>
              <Link to={createPageUrl("Produtos")}>
                <Button variant="outline" className="w-full justify-start gap-2 p-4 h-auto">
                  <Package className="w-5 h-5 text-green-600" />
                  <div className="text-left">
                    <div className="font-medium">Cadastrar Produtos</div>
                    <div className="text-xs text-gray-500">Adicionar novos produtos</div>
                  </div>
                </Button>
              </Link>
              <Link to={createPageUrl("Etiquetas")}>
                <Button variant="outline" className="w-full justify-start gap-2 p-4 h-auto">
                  <Tag className="w-5 h-5 text-purple-600" />
                  <div className="text-left">
                    <div className="font-medium">Emitir Etiquetas</div>
                    <div className="text-xs text-gray-500">Gerar etiquetas de envio</div>
                  </div>
                </Button>
              </Link>
              <Link to={createPageUrl("Relatorios")}>
                <Button variant="outline" className="w-full justify-start gap-2 p-4 h-auto">
                  <FileText className="w-5 h-5 text-orange-600" />
                  <div className="text-left">
                    <div className="font-medium">Ver Relatórios</div>
                    <div className="text-xs text-gray-500">Análise de vendas</div>
                  </div>
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}