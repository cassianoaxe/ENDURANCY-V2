import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  FileText, 
  Download, 
  Printer, 
  Search, 
  Filter, 
  Calendar, 
  Clock, 
  BarChart2, 
  PieChart, 
  LineChart, 
  ArrowUpRight, 
  TrendingUp, 
  TrendingDown, 
  MoreHorizontal, 
  Leaf, 
  Sprout, 
  CheckCircle2, 
  XCircle, 
  Tag,
  AlertTriangle,
  Clipboard,
  Share,
  Save,
  Eye,
  FilePlus
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Dados simulados de relatórios
const mockRelatorios = [
  {
    id: "rel-001",
    titulo: "Relatório de Produtividade - Cultivo Q2 2023",
    tipo: "produtividade",
    categoria: "trimestral",
    dataCriacao: "2023-07-05",
    autor: "Pedro Santos",
    formato: "pdf",
    tamanho: 1.2, // MB
    status: "publicado",
    acessos: 23,
    destinatarios: ["Diretoria", "Gerentes", "Equipe de Cultivo"],
    descricao: "Análise detalhada da produtividade do setor de cultivo no segundo trimestre de 2023, incluindo métricas de rendimento e comparações com períodos anteriores.",
    indicadores: {
      plantasPorM2: 4.3,
      rendimentoMedio: "150g/planta",
      taxaSobrevivencia: "95%",
      tempoCiclo: "110 dias",
      consumoAgua: "2.5L/planta/semana"
    }
  },
  {
    id: "rel-002",
    titulo: "Análise de Variedades - Junho 2023",
    tipo: "analise",
    categoria: "mensal",
    dataCriacao: "2023-07-02",
    autor: "Ana Sousa",
    formato: "pdf",
    tamanho: 2.8, // MB
    status: "publicado",
    acessos: 17,
    destinatarios: ["Equipe de Cultivo", "Controle de Qualidade", "P&D"],
    descricao: "Análise comparativa das diferentes variedades cultivadas em junho de 2023, incluindo desempenho, resistência a pragas e doenças, e resultados laboratoriais.",
    indicadores: {
      variedadesTestadas: 6,
      melhorDesempenho: "Harlequin",
      maiorConcentracaoCBD: "ACDC - 18%",
      melhorResistenciaPragas: "Charlotte's Web"
    }
  },
  {
    id: "rel-003",
    titulo: "Relatório de Lotes em Cultivo - Julho 2023",
    tipo: "inventario",
    categoria: "mensal",
    dataCriacao: "2023-07-10",
    autor: "Pedro Santos",
    formato: "xlsx",
    tamanho: 0.9, // MB
    status: "publicado",
    acessos: 12,
    destinatarios: ["Equipe de Cultivo", "Planejamento de Produção"],
    descricao: "Inventário detalhado de todos os lotes atualmente em cultivo, incluindo fases, quantidades, datas previstas de colheita e necessidades de insumos.",
    indicadores: {
      lotesAtivos: 14,
      plantasTotal: 840,
      faseVegetativa: 320,
      faseFloracao: 420,
      faseSecagem: 100
    }
  },
  {
    id: "rel-004",
    titulo: "Rastreabilidade de Cultivo - Lote CL-2023-42",
    tipo: "rastreabilidade",
    categoria: "lote",
    dataCriacao: "2023-06-28",
    autor: "Marcos Lima",
    formato: "pdf",
    tamanho: 1.5, // MB
    status: "publicado",
    acessos: 9,
    destinatarios: ["Controle de Qualidade", "Garantia da Qualidade", "Regulatório"],
    descricao: "Documento completo de rastreabilidade do lote CL-2023-42, desde a semente até a colheita, incluindo todos os parâmetros ambientais, tratamentos e intervenções.",
    indicadores: {
      numeroLote: "CL-2023-42",
      dataPlantio: "2023-03-15",
      dataColheita: "2023-06-25",
      quantidadePlantada: 60,
      quantidadeColhida: 57
    }
  },
  {
    id: "rel-005",
    titulo: "Planejamento de Cultivo - Q3 2023",
    tipo: "planejamento",
    categoria: "trimestral",
    dataCriacao: "2023-06-20",
    autor: "Maria Silva",
    formato: "pdf",
    tamanho: 2.1, // MB
    status: "rascunho",
    acessos: 4,
    destinatarios: ["Diretoria", "Gerentes", "Equipe de Cultivo"],
    descricao: "Planejamento estratégico para o cultivo no terceiro trimestre de 2023, incluindo variedades selecionadas, estimativas de produção e necessidades de recursos.",
    indicadores: {
      variedadesProjetadas: 8,
      lotesEstimados: 16,
      necessidadeMudas: 1200,
      recursosHumanos: "12 colaboradores"
    }
  },
  {
    id: "rel-006",
    titulo: "Ocorrências Fitossanitárias - Junho 2023",
    tipo: "fitossanidade",
    categoria: "mensal",
    dataCriacao: "2023-07-03",
    autor: "Ana Sousa",
    formato: "pdf",
    tamanho: 1.8, // MB
    status: "publicado",
    acessos: 15,
    destinatarios: ["Equipe de Cultivo", "Controle de Qualidade"],
    descricao: "Relatório de ocorrências fitossanitárias no mês de junho, incluindo identificação de pragas e doenças, medidas de controle aplicadas e resultados obtidos.",
    indicadores: {
      ocorrenciasTotal: 5,
      principalProblema: "Oídio",
      lotesAfetados: 3,
      eficaciaTratamento: "87%"
    }
  }
];

export default function CultivoRelatorios() {
  const [relatorios, setRelatorios] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filteredRelatorios, setFilteredRelatorios] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterTipo, setFilterTipo] = useState("todos");
  const [filterCategoria, setFilterCategoria] = useState("todos");
  const [currentTab, setCurrentTab] = useState("todos");

  useEffect(() => {
    // Simulando carregamento de dados
    setTimeout(() => {
      setRelatorios(mockRelatorios);
      setFilteredRelatorios(mockRelatorios);
      setIsLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    applyFilters();
  }, [searchQuery, filterTipo, filterCategoria, currentTab]);

  const applyFilters = () => {
    let filtered = [...relatorios];

    // Filtro por pesquisa
    if (searchQuery) {
      filtered = filtered.filter(rel => 
        rel.titulo.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rel.descricao.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filtro por tipo
    if (filterTipo !== "todos") {
      filtered = filtered.filter(rel => rel.tipo === filterTipo);
    }

    // Filtro por categoria
    if (filterCategoria !== "todos") {
      filtered = filtered.filter(rel => rel.categoria === filterCategoria);
    }

    // Filtro por aba (status)
    if (currentTab === "publicados") {
      filtered = filtered.filter(rel => rel.status === "publicado");
    } else if (currentTab === "rascunhos") {
      filtered = filtered.filter(rel => rel.status === "rascunho");
    }

    setFilteredRelatorios(filtered);
  };

  const formatFileSize = (sizeInMB) => {
    return `${sizeInMB.toFixed(1)} MB`;
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('pt-BR', options);
  };

  const getStatusBadge = (status) => {
    if (status === "publicado") {
      return <Badge className="bg-green-100 text-green-800">Publicado</Badge>;
    } else if (status === "rascunho") {
      return <Badge className="bg-yellow-100 text-yellow-800">Rascunho</Badge>;
    }
    return null;
  };

  const getTipoIcon = (tipo) => {
    switch (tipo) {
      case "produtividade":
        return <BarChart2 className="w-4 h-4 text-blue-500" />;
      case "analise":
        return <LineChart className="w-4 h-4 text-purple-500" />;
      case "inventario":
        return <Clipboard className="w-4 h-4 text-amber-500" />;
      case "rastreabilidade":
        return <Tag className="w-4 h-4 text-green-500" />;
      case "planejamento":
        return <Calendar className="w-4 h-4 text-indigo-500" />;
      case "fitossanidade":
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default:
        return <FileText className="w-4 h-4 text-gray-500" />;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Relatórios de Cultivo</h1>
          <p className="text-gray-500 mt-1">
            Acesse, gerencie e crie relatórios detalhados sobre o cultivo
          </p>
        </div>
        <div className="flex gap-2">
          <Button>
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Button variant="default">
            <FilePlus className="mr-2 h-4 w-4" />
            Novo Relatório
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar relatórios..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <Select value={filterTipo} onValueChange={setFilterTipo}>
          <SelectTrigger className="w-full md:w-48">
            <SelectValue placeholder="Tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os tipos</SelectItem>
            <SelectItem value="produtividade">Produtividade</SelectItem>
            <SelectItem value="analise">Análise</SelectItem>
            <SelectItem value="inventario">Inventário</SelectItem>
            <SelectItem value="rastreabilidade">Rastreabilidade</SelectItem>
            <SelectItem value="planejamento">Planejamento</SelectItem>
            <SelectItem value="fitossanidade">Fitossanidade</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterCategoria} onValueChange={setFilterCategoria}>
          <SelectTrigger className="w-full md:w-48">
            <SelectValue placeholder="Categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todas as categorias</SelectItem>
            <SelectItem value="mensal">Mensal</SelectItem>
            <SelectItem value="trimestral">Trimestral</SelectItem>
            <SelectItem value="lote">Por Lote</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs value={currentTab} onValueChange={setCurrentTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="todos">
            Todos os Relatórios
          </TabsTrigger>
          <TabsTrigger value="publicados">
            Publicados
          </TabsTrigger>
          <TabsTrigger value="rascunhos">
            Rascunhos
          </TabsTrigger>
        </TabsList>

        <TabsContent value={currentTab}>
          {filteredRelatorios.length === 0 ? (
            <Card className="p-8 text-center">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-900">Nenhum relatório encontrado</h3>
              <p className="text-gray-500 mt-1">
                Não encontramos relatórios correspondentes aos critérios de busca.
              </p>
              <Button onClick={() => {
                setSearchQuery("");
                setFilterTipo("todos");
                setFilterCategoria("todos");
              }} variant="outline" className="mt-4">
                Limpar filtros
              </Button>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredRelatorios.map((relatorio) => (
                <Card key={relatorio.id} className="overflow-hidden">
                  <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
                    <div className="flex flex-col space-y-1">
                      <CardTitle className="text-lg font-medium">
                        {relatorio.titulo}
                      </CardTitle>
                      <CardDescription>
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-gray-400" />
                          <span>{formatDate(relatorio.dataCriacao)}</span>
                        </div>
                      </CardDescription>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Abrir menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Eye className="mr-2 h-4 w-4" />
                          <span>Visualizar</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="mr-2 h-4 w-4" />
                          <span>Download</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Printer className="mr-2 h-4 w-4" />
                          <span>Imprimir</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Share className="mr-2 h-4 w-4" />
                          <span>Compartilhar</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-2 mb-3">
                      <Badge className="bg-blue-100 text-blue-800 flex items-center gap-1.5">
                        {getTipoIcon(relatorio.tipo)}
                        <span className="capitalize">{relatorio.tipo}</span>
                      </Badge>
                      <Badge className="bg-purple-100 text-purple-800 capitalize">
                        {relatorio.categoria}
                      </Badge>
                      {getStatusBadge(relatorio.status)}
                    </div>
                    <p className="text-gray-500 text-sm line-clamp-3 mb-4">
                      {relatorio.descricao}
                    </p>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <FileText className="w-3.5 h-3.5" />
                        <span className="uppercase">{relatorio.formato}</span>
                        <span className="mx-1">•</span>
                        <span>{formatFileSize(relatorio.tamanho)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Eye className="w-3.5 h-3.5" />
                        <span>{relatorio.acessos} visualizações</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="bg-gray-50 py-2 px-4 flex justify-between">
                    <span className="text-xs text-gray-500">Por {relatorio.autor}</span>
                    <Button variant="ghost" size="sm" className="h-7 px-2">
                      <Download className="h-3.5 w-3.5 mr-1" />
                      Download
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}