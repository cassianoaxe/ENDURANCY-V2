import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { AssistenciaBeneficiario } from '@/api/entities';
import {
  Users,
  ChartBar,
  Heart,
  Plus,
  Search,
  Share2,
  Download,
  Filter,
  BarChart3,
  PieChart,
  DollarSign,
  UserPlus,
  QrCode
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RePieChart, Pie, Cell } from 'recharts';

export default function Social() {
  const [beneficiarios, setBeneficiarios] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("dashboard");
  const [stats, setStats] = useState({
    total_beneficiarios: 0,
    total_investido: 0,
    media_isencao: 0,
    beneficiarios_ativos: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await AssistenciaBeneficiario.list();
      setBeneficiarios(data);
      
      // Calculate stats
      const stats = {
        total_beneficiarios: data.length,
        total_investido: data.reduce((acc, curr) => acc + curr.valor_subsidio, 0),
        media_isencao: data.reduce((acc, curr) => acc + curr.percentual_isencao, 0) / data.length,
        beneficiarios_ativos: data.filter(b => b.situacao === 'ativo').length
      };
      
      setStats(stats);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Assistência Social</h1>
          <p className="text-gray-500">Gestão do programa de assistência social</p>
        </div>
        <div className="flex gap-2">
          <Link to={createPageUrl("PortalSocial")} target="_blank">
            <Button variant="outline" className="gap-2">
              <Share2 className="w-4 h-4" />
              Portal Social
            </Button>
          </Link>
          <Link to={createPageUrl("NovoBeneficiario")}>
            <Button className="gap-2">
              <UserPlus className="w-4 h-4" />
              Novo Beneficiário
            </Button>
          </Link>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="beneficiarios">Beneficiários</TabsTrigger>
          <TabsTrigger value="campanhas">Campanhas</TabsTrigger>
          <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
          <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total de Beneficiários
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total_beneficiarios}</div>
                <p className="text-xs text-muted-foreground">
                  {stats.beneficiarios_ativos} ativos
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Investido
                </CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  R$ {stats.total_investido.toLocaleString('pt-BR')}
                </div>
                <p className="text-xs text-muted-foreground">
                  Acumulado no ano
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Média de Isenção
                </CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {stats.media_isencao.toFixed(1)}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Percentual médio
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  QR Code PIX
                </CardTitle>
                <QrCode className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full">
                  Gerar QR Code
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Distribuição por Faixa de Isenção</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: '0-25%', value: 30 },
                          { name: '26-50%', value: 40 },
                          { name: '51-75%', value: 20 },
                          { name: '76-100%', value: 10 },
                        ]}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        fill="#8884d8"
                        label
                      />
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Evolução Mensal de Beneficiários</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        { month: 'Jan', total: 65 },
                        { month: 'Fev', total: 75 },
                        { month: 'Mar', total: 85 },
                        { month: 'Abr', total: 90 },
                        { month: 'Mai', total: 100 },
                        { month: 'Jun', total: 120 },
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="total" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="beneficiarios">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex gap-2">
                <div className="relative w-64">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Buscar beneficiário..." className="pl-8" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                </div>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Filtros
                </Button>
              </div>
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Exportar
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3">Nome</th>
                      <th className="text-left p-3">CPF</th>
                      <th className="text-left p-3">Condição</th>
                      <th className="text-left p-3">Isenção</th>
                      <th className="text-left p-3">Valor Subsídio</th>
                      <th className="text-left p-3">Situação</th>
                      <th className="text-left p-3">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {isLoading ? (
                      <tr>
                        <td colSpan={7} className="text-center p-4">Carregando...</td>
                      </tr>
                    ) : beneficiarios.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center p-4">Nenhum beneficiário encontrado</td>
                      </tr>
                    ) : (
                      beneficiarios
                        .filter(b => 
                          b.nome.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          b.cpf.includes(searchTerm)
                        )
                        .map(beneficiario => (
                          <tr key={beneficiario.id} className="border-b hover:bg-gray-50">
                            <td className="p-3">{beneficiario.nome}</td>
                            <td className="p-3">{beneficiario.cpf}</td>
                            <td className="p-3">{beneficiario.condicao_medica}</td>
                            <td className="p-3">{beneficiario.percentual_isencao}%</td>
                            <td className="p-3">R$ {beneficiario.valor_subsidio.toLocaleString('pt-BR')}</td>
                            <td className="p-3">
                              <span className={`px-2 py-1 rounded-full text-xs 
                                ${beneficiario.situacao === 'ativo' ? 'bg-green-100 text-green-800' : 
                                  beneficiario.situacao === 'pendente_reavaliacao' ? 'bg-yellow-100 text-yellow-800' : 
                                  'bg-red-100 text-red-800'}`}>
                                {beneficiario.situacao === 'ativo' ? 'Ativo' : 
                                  beneficiario.situacao === 'pendente_reavaliacao' ? 'Pendente' : 'Inativo'}
                              </span>
                            </td>
                            <td className="p-3">
                              <Button variant="ghost" size="sm">Editar</Button>
                            </td>
                          </tr>
                        ))
                    )}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="campanhas">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Campanhas de Arrecadação</h2>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Nova Campanha
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Campanha de Natal</CardTitle>
                  <div className="text-sm text-muted-foreground">Encerra em 30 dias</div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Arrecadado</span>
                        <span className="text-sm font-medium">R$ 15.000 / R$ 30.000</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '50%' }}></div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">10 doadores</span>
                      <Button variant="outline" size="sm">Gerenciar</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Medicamentos Infantis</CardTitle>
                  <div className="text-sm text-muted-foreground">Encerra em 60 dias</div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Arrecadado</span>
                        <span className="text-sm font-medium">R$ 8.000 / R$ 20.000</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '40%' }}></div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">5 doadores</span>
                      <Button variant="outline" size="sm">Gerenciar</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Atendimento de Emergência</CardTitle>
                  <div className="text-sm text-muted-foreground">Permanente</div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Arrecadado este mês</span>
                        <span className="text-sm font-medium">R$ 3.200</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '32%' }}></div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">3 doadores</span>
                      <Button variant="outline" size="sm">Gerenciar</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Configurações de Doação</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Chaves PIX</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">CNPJ</div>
                          <div className="text-sm text-muted-foreground">12.345.678/0001-90</div>
                        </div>
                        <Button variant="outline" size="sm">Copiar</Button>
                      </div>
                      <div className="flex items-center p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Email</div>
                          <div className="text-sm text-muted-foreground">doacoes@entidade.org</div>
                        </div>
                        <Button variant="outline" size="sm">Copiar</Button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">QR Code PIX</h3>
                    <div className="flex gap-4">
                      <div className="bg-white p-4 border rounded-md">
                        <div className="w-[150px] h-[150px] bg-gray-100 flex items-center justify-center">
                          [QR Code]
                        </div>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-gray-600 mb-4">
                          Configure um QR Code PIX estático para facilitar doações. Você pode compartilhar este QR Code em suas redes sociais, materiais impressos e portal.
                        </p>
                        <Button>Gerar QR Code</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="relatorios">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Relatórios do Programa Social</h2>
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Exportar Dados
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Distribuição de Beneficiários</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={[
                            { name: 'Isenção Total', value: 45 },
                            { name: 'Isenção 75%', value: 37 },
                            { name: 'Isenção 50%', value: 42 },
                            { name: 'Isenção 25%', value: 21 },
                          ]}
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {[
                            { name: 'Isenção Total', value: 45 },
                            { name: 'Isenção 75%', value: 37 },
                            { name: 'Isenção 50%', value: 42 },
                            { name: 'Isenção 25%', value: 21 },
                          ].map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={['#0088FE', '#00C49F', '#FFBB28', '#FF8042'][index % 4]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Investimento Mensal</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={[
                          { mes: 'Jan', valor: 23000 },
                          { mes: 'Fev', valor: 24000 },
                          { mes: 'Mar', valor: 25000 },
                          { mes: 'Abr', valor: 24500 },
                          { mes: 'Mai', valor: 25500 },
                          { mes: 'Jun', valor: 25000 },
                        ]}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="mes" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`R$ ${value.toLocaleString('pt-BR')}`, 'Valor']} />
                        <Bar dataKey="valor" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Métricas de Impacto Social</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white p-4 rounded-lg border">
                    <div className="text-sm text-muted-foreground">Famílias Atendidas</div>
                    <div className="text-2xl font-bold">145</div>
                  </div>
                  <div className="bg-white p-4 rounded-lg border">
                    <div className="text-sm text-muted-foreground">Economia Gerada</div>
                    <div className="text-2xl font-bold">R$ 298.000</div>
                  </div>
                  <div className="bg-white p-4 rounded-lg border">
                    <div className="text-sm text-muted-foreground">Consultas Realizadas</div>
                    <div className="text-2xl font-bold">560</div>
                  </div>
                  <div className="bg-white p-4 rounded-lg border">
                    <div className="text-sm text-muted-foreground">Redução de Sintomas</div>
                    <div className="text-2xl font-bold">87%</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Relatórios Disponíveis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-3 border rounded-md hover:bg-gray-50">
                    <div>
                      <div className="font-medium">Relatório de Beneficiários</div>
                      <div className="text-sm text-muted-foreground">Lista completa de beneficiários com detalhes</div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Exportar
                    </Button>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-md hover:bg-gray-50">
                    <div>
                      <div className="font-medium">Relatório Financeiro</div>
                      <div className="text-sm text-muted-foreground">Detalhamento dos custos do programa social</div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Exportar
                    </Button>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-md hover:bg-gray-50">
                    <div>
                      <div className="font-medium">Relatório de Impacto</div>
                      <div className="text-sm text-muted-foreground">Métricas de impacto social</div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Exportar
                    </Button>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-md hover:bg-gray-50">
                    <div>
                      <div className="font-medium">Relatório de Doações</div>
                      <div className="text-sm text-muted-foreground">Histórico de doações recebidas</div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Exportar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="configuracoes">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Configurações do Programa Social</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Categorias de Isenção</h3>
                    <div className="space-y-3">
                      <div className="flex items-center p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Isenção Total (100%)</div>
                          <div className="text-sm text-muted-foreground">Para famílias com renda até 1 salário mínimo</div>
                        </div>
                        <Button variant="outline" size="sm">Editar</Button>
                      </div>
                      <div className="flex items-center p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Isenção Parcial (75%)</div>
                          <div className="text-sm text-muted-foreground">Para famílias com renda até 2 salários mínimos</div>
                        </div>
                        <Button variant="outline" size="sm">Editar</Button>
                      </div>
                      <div className="flex items-center p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Isenção Parcial (50%)</div>
                          <div className="text-sm text-muted-foreground">Para famílias com renda até 3 salários mínimos</div>
                        </div>
                        <Button variant="outline" size="sm">Editar</Button>
                      </div>
                      <div className="flex items-center p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Isenção Parcial (25%)</div>
                          <div className="text-sm text-muted-foreground">Para famílias com renda até 4 salários mínimos</div>
                        </div>
                        <Button variant="outline" size="sm">Editar</Button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Critérios de Elegibilidade</h3>
                    <div className="space-y-2">
                      <div className="flex items-center bg-white p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Comprovação de Renda</div>
                          <div className="text-sm text-muted-foreground">Exigir documentos comprobatórios de renda familiar</div>
                        </div>
                        <div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" value="" className="sr-only peer" defaultChecked />
                            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                          </label>
                        </div>
                      </div>
                      <div className="flex items-center bg-white p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Laudo Médico</div>
                          <div className="text-sm text-muted-foreground">Exigir laudo médico atualizado</div>
                        </div>
                        <div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" value="" className="sr-only peer" defaultChecked />
                            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                          </label>
                        </div>
                      </div>
                      <div className="flex items-center bg-white p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Cadastro Único</div>
                          <div className="text-sm text-muted-foreground">Exigir inscrição no Cadastro Único (CadÚnico)</div>
                        </div>
                        <div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" value="" className="sr-only peer" defaultChecked />
                            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                          </label>
                        </div>
                      </div>
                      <div className="flex items-center bg-white p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Entrevista Social</div>
                          <div className="text-sm text-muted-foreground">Realizar entrevista com assistente social</div>
                        </div>
                        <div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" value="" className="sr-only peer" defaultChecked />
                            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Equipe Responsável</h3>
                    <div className="space-y-2">
                      <div className="flex items-center p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Assistente Social Responsável</div>
                          <div className="flex">
                            <Input className="max-w-md" placeholder="Nome do assistente social" defaultValue="Maria Silva" />
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center p-3 border rounded-md">
                        <div className="flex-1">
                          <div className="font-medium">Email para Notificações</div>
                          <div className="flex">
                            <Input className="max-w-md" placeholder="Email para receber notificações" defaultValue="social@entidade.org" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <Button>Salvar Configurações</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}