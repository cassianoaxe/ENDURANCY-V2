import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Mail, 
  Plus, 
  Search, 
  Edit, 
  Copy, 
  Trash2, 
  Eye, 
  Save, 
  FileText, 
  Send, 
  User, 
  UserPlus, 
  ShieldAlert, 
  CreditCard, 
  CheckCircle2,
  AlertTriangle,
  RotateCw
} from "lucide-react";

// Sample email templates
const emailTemplatesData = [
  {
    id: 1,
    name: 'Boas-vindas',
    description: 'Email enviado após o primeiro cadastro',
    category: 'onboarding',
    subject: 'Bem-vindo à Plataforma Endurancy',
    body: `<p>Olá {user.name},</p>
<p>Bem-vindo à Plataforma Endurancy! Estamos felizes em tê-lo conosco.</p>
<p>Para começar, acesse sua conta e complete seu perfil:</p>
<p><a href="{login_url}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Acessar Minha Conta</a></p>
<p>Se precisar de ajuda, nossa equipe de suporte está disponível através do email <a href="mailto:suporte@endurancy.com">suporte@endurancy.com</a>.</p>
<p>Atenciosamente,<br>Equipe Endurancy</p>`,
    lastUpdated: '2023-06-15T10:30:00Z'
  },
  {
    id: 2,
    name: 'Convite de Usuário',
    description: 'Email enviado ao convidar um novo usuário',
    category: 'onboarding',
    subject: 'Convite para a Plataforma Endurancy',
    body: `<p>Olá,</p>
<p>Você foi convidado para se juntar à Plataforma Endurancy por {inviter.name}.</p>
<p>Para aceitar o convite e configurar sua conta, clique no botão abaixo:</p>
<p><a href="{invite_url}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Aceitar Convite</a></p>
<p>Este convite expira em 7 dias.</p>
<p>Se você tiver alguma dúvida, entre em contato conosco.</p>
<p>Atenciosamente,<br>Equipe Endurancy</p>`,
    lastUpdated: '2023-06-20T14:15:00Z'
  },
  {
    id: 3,
    name: 'Solicitação Aprovada',
    description: 'Email enviado quando uma solicitação é aprovada',
    category: 'organization',
    subject: 'Sua solicitação foi aprovada',
    body: `<p>Olá {user.name},</p>
<p>Temos o prazer de informar que sua solicitação para a organização {organization.name} foi <strong>aprovada</strong>.</p>
<p>Você já pode acessar a plataforma e começar a utilizar todos os recursos disponíveis para sua organização.</p>
<p><a href="{login_url}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Acessar Plataforma</a></p>
<p>Se precisar de ajuda, nossa equipe de suporte está disponível.</p>
<p>Atenciosamente,<br>Equipe Endurancy</p>`,
    lastUpdated: '2023-07-05T09:30:00Z'
  },
  {
    id: 4,
    name: 'Solicitação Rejeitada',
    description: 'Email enviado quando uma solicitação é rejeitada',
    category: 'organization',
    subject: 'Informações sobre sua solicitação',
    body: `<p>Olá {user.name},</p>
<p>Agradecemos pelo seu interesse na Plataforma Endurancy.</p>
<p>Após análise cuidadosa, não podemos aprovar sua solicitação neste momento pelos seguintes motivos:</p>
<p>{rejection_reason}</p>
<p>Se você acredita que houve um erro ou deseja fornecer informações adicionais, por favor responda a este email.</p>
<p>Atenciosamente,<br>Equipe Endurancy</p>`,
    lastUpdated: '2023-07-05T09:45:00Z'
  },
  {
    id: 5,
    name: 'Redefinição de Senha',
    description: 'Email para redefinir senha',
    category: 'security',
    subject: 'Redefinição de senha solicitada',
    body: `<p>Olá {user.name},</p>
<p>Recebemos uma solicitação para redefinir a senha da sua conta.</p>
<p>Para redefinir sua senha, clique no botão abaixo:</p>
<p><a href="{reset_url}" style="background-color: #2196F3; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Redefinir Senha</a></p>
<p>Se você não solicitou esta redefinição, por favor ignore este email ou entre em contato com nosso suporte.</p>
<p>Este link expira em 24 horas.</p>
<p>Atenciosamente,<br>Equipe Endurancy</p>`,
    lastUpdated: '2023-06-18T11:20:00Z'
  },
  {
    id: 6,
    name: 'Alerta de Segurança',
    description: 'Email enviado quando há atividade suspeita',
    category: 'security',
    subject: 'Alerta de Segurança - Atividade Suspeita',
    body: `<p>Olá {user.name},</p>
<p><strong>Detectamos uma atividade potencialmente suspeita em sua conta.</strong></p>
<p>Detalhes:</p>
<ul>
  <li>Data e Hora: {timestamp}</li>
  <li>Localização: {location}</li>
  <li>Endereço IP: {ip_address}</li>
  <li>Dispositivo: {device}</li>
</ul>
<p>Se foi você, pode ignorar este email. Caso contrário, recomendamos que:</p>
<p><a href="{change_password_url}" style="background-color: #F44336; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Altere sua senha imediatamente</a></p>
<p>Por segurança, também recomendamos ativar a autenticação de dois fatores.</p>
<p>Atenciosamente,<br>Equipe de Segurança Endurancy</p>`,
    lastUpdated: '2023-07-10T16:45:00Z'
  },
  {
    id: 7,
    name: 'Fatura Gerada',
    description: 'Email enviado quando uma nova fatura é gerada',
    category: 'billing',
    subject: 'Sua fatura está disponível',
    body: `<p>Olá {user.name},</p>
<p>Sua fatura mensal está disponível.</p>
<p><strong>Detalhes da fatura:</strong></p>
<ul>
  <li>Número: {invoice.number}</li>
  <li>Data: {invoice.date}</li>
  <li>Valor: {invoice.amount}</li>
  <li>Vencimento: {invoice.due_date}</li>
</ul>
<p><a href="{invoice_url}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Visualizar Fatura</a></p>
<p>Caso já tenha efetuado o pagamento, por favor desconsidere este email.</p>
<p>Atenciosamente,<br>Equipe Financeira Endurancy</p>`,
    lastUpdated: '2023-07-01T09:30:00Z'
  },
  {
    id: 8,
    name: 'Lembrete de Fatura',
    description: 'Email de lembrete para faturas próximas do vencimento',
    category: 'billing',
    subject: 'Lembrete: Sua fatura vence em breve',
    body: `<p>Olá {user.name},</p>
<p>Este é um lembrete de que sua fatura {invoice.number} vence em {days_until_due} dias.</p>
<p><strong>Detalhes da fatura:</strong></p>
<ul>
  <li>Número: {invoice.number}</li>
  <li>Data: {invoice.date}</li>
  <li>Valor: {invoice.amount}</li>
  <li>Vencimento: {invoice.due_date}</li>
</ul>
<p><a href="{invoice_url}" style="background-color: #FF9800; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Pagar Agora</a></p>
<p>Se você já efetuou o pagamento, por favor desconsidere este email.</p>
<p>Atenciosamente,<br>Equipe Financeira Endurancy</p>`,
    lastUpdated: '2023-07-01T09:45:00Z'
  }
];

export default function EmailTemplates() {
  const [templates, setTemplates] = useState(emailTemplatesData);
  const [filteredTemplates, setFilteredTemplates] = useState(emailTemplatesData);
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showPreviewDialog, setShowPreviewDialog] = useState(false);
  const [showTestDialog, setShowTestDialog] = useState(false);
  const [currentTemplate, setCurrentTemplate] = useState(null);
  const [testEmail, setTestEmail] = useState('');
  const [isSending, setIsSending] = useState(false);
  
  React.useEffect(() => {
    filterTemplates();
  }, [activeCategory, searchTerm, templates]);
  
  const filterTemplates = () => {
    let filtered = [...templates];
    
    // Apply category filter
    if (activeCategory !== 'all') {
      filtered = filtered.filter(template => template.category === activeCategory);
    }
    
    // Apply search filter
    if (searchTerm.trim() !== '') {
      filtered = filtered.filter(template => 
        template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        template.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        template.subject.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    setFilteredTemplates(filtered);
  };
  
  const handleEditTemplate = (template) => {
    setCurrentTemplate({ ...template });
    setShowEditDialog(true);
  };
  
  const handleDeleteTemplate = (template) => {
    setCurrentTemplate(template);
    setShowDeleteDialog(true);
  };
  
  const handlePreviewTemplate = (template) => {
    setCurrentTemplate(template);
    setShowPreviewDialog(true);
  };
  
  const handleSendTestEmail = (template) => {
    setCurrentTemplate(template);
    setTestEmail('');
    setShowTestDialog(true);
  };
  
  const handleAddTemplate = () => {
    setCurrentTemplate({
      id: null,
      name: '',
      description: '',
      category: 'onboarding',
      subject: '',
      body: '',
      lastUpdated: new Date().toISOString()
    });
    setShowEditDialog(true);
  };
  
  const handleSaveTemplate = () => {
    if (currentTemplate.id) {
      // Update existing template
      setTemplates(templates.map(template => 
        template.id === currentTemplate.id 
          ? { ...currentTemplate, lastUpdated: new Date().toISOString() } 
          : template
      ));
    } else {
      // Add new template
      setTemplates([
        ...templates,
        {
          ...currentTemplate,
          id: Math.max(0, ...templates.map(t => t.id)) + 1,
          lastUpdated: new Date().toISOString()
        }
      ]);
    }
    setShowEditDialog(false);
  };
  
  const handleConfirmDelete = () => {
    setTemplates(templates.filter(template => template.id !== currentTemplate.id));
    setShowDeleteDialog(false);
  };
  
  const handleSendTest = () => {
    if (!testEmail.trim()) return;
    
    setIsSending(true);
    
    // Simulate sending test email
    setTimeout(() => {
      setIsSending(false);
      setShowTestDialog(false);
      alert(`Email de teste enviado para ${testEmail}`);
    }, 1500);
  };
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  const getCategoryIcon = (category) => {
    switch (category) {
      case 'onboarding':
        return <User className="w-4 h-4" />;
      case 'organization':
        return <FileText className="w-4 h-4" />;
      case 'security':
        return <ShieldAlert className="w-4 h-4" />;
      case 'billing':
        return <CreditCard className="w-4 h-4" />;
      default:
        return <Mail className="w-4 h-4" />;
    }
  };
  
  const getCategoryLabel = (category) => {
    switch (category) {
      case 'onboarding':
        return 'Onboarding';
      case 'organization':
        return 'Organização';
      case 'security':
        return 'Segurança';
      case 'billing':
        return 'Faturamento';
      default:
        return category;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Templates de Email</h1>
          <p className="text-gray-500 mt-1">
            Gerencie os modelos de email enviados pela plataforma
          </p>
        </div>
        <Button 
          className="gap-2 bg-green-600 hover:bg-green-700"
          onClick={handleAddTemplate}
        >
          <Plus className="w-4 h-4" />
          Novo Template
        </Button>
      </div>

      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div className="relative max-w-sm w-full">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar templates..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <Tabs defaultValue="all" onValueChange={setActiveCategory}>
          <TabsList>
            <TabsTrigger value="all">Todos</TabsTrigger>
            <TabsTrigger value="onboarding">Onboarding</TabsTrigger>
            <TabsTrigger value="organization">Organização</TabsTrigger>
            <TabsTrigger value="security">Segurança</TabsTrigger>
            <TabsTrigger value="billing">Faturamento</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.length === 0 ? (
          <div className="col-span-full">
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Mail className="w-12 h-12 text-gray-300 mb-3" />
                <h3 className="text-lg font-medium text-gray-900">Nenhum template encontrado</h3>
                <p className="text-gray-500 mt-1">
                  {searchTerm || activeCategory !== 'all' 
                    ? 'Tente ajustar os critérios de busca' 
                    : 'Adicione seu primeiro template clicando no botão acima'}
                </p>
              </CardContent>
            </Card>
          </div>
        ) : (
          filteredTemplates.map(template => (
            <Card key={template.id} className="overflow-hidden">
              <CardHeader className="pb-3">
                <CardTitle>{template.name}</CardTitle>
                <CardDescription className="line-clamp-2">
                  {template.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-sm">
                    {getCategoryIcon(template.category)}
                    <span>{getCategoryLabel(template.category)}</span>
                  </div>
                  <div className="text-xs text-gray-500">
                    Atualizado: {formatDate(template.lastUpdated)}
                  </div>
                </div>
                
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="font-medium truncate text-sm">
                    Assunto: {template.subject}
                  </p>
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 border-t justify-end gap-2 py-3">
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="h-8 gap-1"
                  onClick={() => handlePreviewTemplate(template)}
                >
                  <Eye className="w-3 h-3" />
                  Visualizar
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="h-8 gap-1"
                  onClick={() => handleSendTestEmail(template)}
                >
                  <Send className="w-3 h-3" />
                  Testar
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="h-8 gap-1"
                  onClick={() => handleEditTemplate(template)}
                >
                  <Edit className="w-3 h-3" />
                  Editar
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="h-8 gap-1 text-red-600 hover:text-red-700"
                  onClick={() => handleDeleteTemplate(template)}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </CardFooter>
            </Card>
          ))
        )}
      </div>

      {/* Edit Template Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{currentTemplate?.id ? 'Editar Template' : 'Novo Template'}</DialogTitle>
            <DialogDescription>
              {currentTemplate?.id ? 'Modifique os detalhes do template de email' : 'Configure um novo template de email'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="template-name">Nome do Template</Label>
                <Input 
                  id="template-name" 
                  value={currentTemplate?.name || ''} 
                  onChange={(e) => setCurrentTemplate({...currentTemplate, name: e.target.value})}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="template-category">Categoria</Label>
                <Select 
                  value={currentTemplate?.category || 'onboarding'} 
                  onValueChange={(value) => setCurrentTemplate({...currentTemplate, category: value})}
                >
                  <SelectTrigger id="template-category">
                    <SelectValue placeholder="Selecione uma categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="onboarding">Onboarding</SelectItem>
                    <SelectItem value="organization">Organização</SelectItem>
                    <SelectItem value="security">Segurança</SelectItem>
                    <SelectItem value="billing">Faturamento</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="template-description">Descrição</Label>
              <Input 
                id="template-description" 
                value={currentTemplate?.description || ''} 
                onChange={(e) => setCurrentTemplate({...currentTemplate, description: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="template-subject">Assunto do Email</Label>
              <Input 
                id="template-subject" 
                value={currentTemplate?.subject || ''} 
                onChange={(e) => setCurrentTemplate({...currentTemplate, subject: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="template-body">Conteúdo do Email</Label>
                <span className="text-xs text-gray-500">HTML é suportado</span>
              </div>
              <Textarea 
                id="template-body" 
                rows={15}
                value={currentTemplate?.body || ''} 
                onChange={(e) => setCurrentTemplate({...currentTemplate, body: e.target.value})}
                className="font-mono text-sm"
              />
            </div>
            
            <div className="bg-blue-50 p-3 rounded-md text-sm text-blue-800">
              <h4 className="font-medium mb-1">Variáveis Disponíveis</h4>
              <p>Use estas variáveis para personalizar o email:</p>
              <ul className="mt-2 space-y-1">
                <li><code>{'{user.name}'}</code> - Nome do usuário</li>
                <li><code>{'{user.email}'}</code> - Email do usuário</li>
                <li><code>{'{organization.name}'}</code> - Nome da organização</li>
                <li><code>{'{login_url}'}</code> - URL de login</li>
                <li><code>{'{reset_url}'}</code> - URL para redefinição de senha</li>
                <li><code>{'{invite_url}'}</code> - URL para aceitar convite</li>
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleSaveTemplate}
              disabled={!currentTemplate?.name || !currentTemplate?.subject || !currentTemplate?.body}
              className="gap-2"
            >
              <Save className="w-4 h-4" />
              Salvar Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Excluir Template
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>
              Tem certeza que deseja excluir o template <strong>{currentTemplate?.name}</strong>?
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Esta ação não pode ser desfeita.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancelar
            </Button>
            <Button 
              variant="destructive"
              onClick={handleConfirmDelete}
            >
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={showPreviewDialog} onOpenChange={setShowPreviewDialog}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Pré-visualização: {currentTemplate?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="bg-gray-100 p-2 rounded-md">
              <p className="font-medium">Assunto: {currentTemplate?.subject}</p>
            </div>
            
            <div className="border rounded-md overflow-hidden">
              <div className="bg-white p-4" dangerouslySetInnerHTML={{__html: currentTemplate?.body}} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPreviewDialog(false)}>
              Fechar
            </Button>
            <Button 
              onClick={() => {
                setShowPreviewDialog(false);
                handleSendTestEmail(currentTemplate);
              }}
              className="gap-2"
            >
              <Send className="w-4 h-4" />
              Enviar Teste
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Test Email Dialog */}
      <Dialog open={showTestDialog} onOpenChange={setShowTestDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Enviar Email de Teste</DialogTitle>
            <DialogDescription>
              Envie uma cópia deste template para qualquer endereço de email
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <p className="text-sm font-medium mb-1">Template: {currentTemplate?.name}</p>
              <p className="text-sm text-gray-500">Assunto: {currentTemplate?.subject}</p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="test-email">Email de Destino</Label>
              <Input 
                id="test-email" 
                type="email"
                placeholder="Digite o email para envio"
                value={testEmail}
                onChange={(e) => setTestEmail(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTestDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleSendTest}
              disabled={!testEmail.trim() || isSending}
              className="gap-2"
            >
              {isSending ? (
                <>
                  <RotateCw className="w-4 h-4 animate-spin" />
                  Enviando...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Enviar Teste
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}