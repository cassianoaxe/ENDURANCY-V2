import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  DollarSign,
  Calendar,
  ArrowDownCircle,
  ArrowUpCircle,
  BarChart4,
  PieChart,
  FileText,
  PlusCircle,
  Download,
  ReceiptIcon,
  CreditCard,
  TrendingUp,
  TrendingDown,
  Activity,
  Wallet,
  Landmark,
  Briefcase
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

// Componente para o gráfico de linha (simplificado)
const LineChart = ({ data, height = 100 }) => {
  return (
    <div className="w-full h-full min-h-[100px]">
      <div style={{ height: `${height}px` }} className="w-full bg-gray-50 rounded-md border flex items-end">
        {data.map((value, index) => (
          <div 
            key={index} 
            className="h-full flex-1 flex flex-col justify-end px-1"
          >
            <div 
              style={{ height: `${value}%` }} 
              className={`w-full rounded-t-sm ${value > 50 ? 'bg-green-500' : 'bg-blue-500'}`}
            ></div>
            <div className="text-[10px] text-center mt-1 text-gray-500">
              {index + 1}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function FinanceiroDashboard() {
  const navigate = useNavigate();
  const [periodoSelecionado, setPeriodoSelecionado] = useState("current-month");
  const [tipoRelatorio, setTipoRelatorio] = useState("completo");
  
  // Dados simulados para os gráficos
  const dadosFluxoCaixa = [40, 65, 75, 55, 80, 65, 90, 85, 75, 85, 90, 95];
  const dadosReceitas = [30, 50, 70, 40, 60, 55, 85, 75, 65, 80, 85, 90];
  const dadosDespesas = [45, 55, 65, 50, 70, 60, 75, 65, 55, 65, 70, 75];
  
  // Função para exportar relatórios
  const exportarRelatorio = () => {
    toast({
      title: "Exportando relatório",
      description: `O relatório ${tipoRelatorio} do período selecionado será baixado em breve.`
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Dashboard Financeiro</h1>
          <p className="text-gray-500 mt-1">
            Visão geral da saúde financeira da sua organização
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={periodoSelecionado} onValueChange={setPeriodoSelecionado}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Selecione o período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current-month">Mês Atual</SelectItem>
              <SelectItem value="last-month">Mês Anterior</SelectItem>
              <SelectItem value="quarter">Trimestre Atual</SelectItem>
              <SelectItem value="year">Ano Atual</SelectItem>
              <SelectItem value="custom">Período Personalizado</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="flex gap-2" onClick={() => navigate(createPageUrl("NovoLancamento"))}>
            <PlusCircle className="w-4 h-4" />
            Novo Lançamento
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Receitas (Mês Atual)</CardTitle>
            <CardDescription>Valor total recebido</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">R$ 85.425,00</div>
            <div className="flex items-center text-sm text-gray-500 mt-1">
              <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
              <span className="text-green-600 font-medium">+12%</span>
              <span className="ml-1">em relação ao mês anterior</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Despesas (Mês Atual)</CardTitle>
            <CardDescription>Valor total despendido</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">R$ 72.350,00</div>
            <div className="flex items-center text-sm text-gray-500 mt-1">
              <TrendingDown className="w-4 h-4 text-red-600 mr-1" />
              <span className="text-red-600 font-medium">+8%</span>
              <span className="ml-1">em relação ao mês anterior</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Resultado (Mês Atual)</CardTitle>
            <CardDescription>Receitas - Despesas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">R$ 13.075,00</div>
            <div className="flex items-center text-sm text-gray-500 mt-1">
              <Activity className="w-4 h-4 text-blue-600 mr-1" />
              <span className="text-blue-600 font-medium">Margem: 15.3%</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="visao-geral">
        <TabsList className="flex flex-wrap">
          <TabsTrigger value="visao-geral" className="flex items-center gap-2">
            <BarChart4 className="w-4 h-4" />
            <span>Visão Geral</span>
          </TabsTrigger>
          <TabsTrigger value="fluxo-caixa" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span>Fluxo de Caixa</span>
          </TabsTrigger>
          <TabsTrigger value="contas" className="flex items-center gap-2">
            <DollarSign className="w-4 h-4" />
            <span>Contas Pendentes</span>
          </TabsTrigger>
          <TabsTrigger value="dre" className="flex items-center gap-2">
            <PieChart className="w-4 h-4" />
            <span>DRE Simplificado</span>
          </TabsTrigger>
        </TabsList>

        {/* Conteúdo da aba Visão Geral */}
        <TabsContent value="visao-geral" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Evolução Financeira</CardTitle>
                <CardDescription>
                  Comparativo de receitas e despesas do ano atual
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex flex-col justify-center">
                  {/* Gráfico simulado */}
                  <div className="w-full h-full bg-gradient-to-r from-gray-50 to-gray-100 rounded-md border flex flex-col justify-center items-center relative">
                    <div className="absolute inset-0 p-4">
                      <div className="w-full h-full relative">
                        {/* Linha Receitas */}
                        <div className="absolute left-0 right-0 top-1/4 border-t border-dashed border-green-300"></div>
                        {/* Linha Despesas */}
                        <div className="absolute left-0 right-0 top-1/2 border-t border-dashed border-red-300"></div>
                        {/* Linha Zero */}
                        <div className="absolute left-0 right-0 top-3/4 border-t border-dashed border-gray-300"></div>
                        
                        {/* Linhas de gráfico simuladas */}
                        <div className="absolute left-0 right-0 top-1/4 h-1/2 bg-gradient-to-r from-green-100 to-green-200 opacity-20 rounded"></div>
                        <div className="absolute left-0 right-0 top-1/2 h-1/4 bg-gradient-to-r from-red-100 to-red-200 opacity-20 rounded"></div>
                      </div>
                    </div>
                    
                    <div className="relative z-10 flex items-center gap-6">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-sm font-medium">Receitas</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <span className="text-sm font-medium">Despesas</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                        <span className="text-sm font-medium">Resultado</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => navigate(createPageUrl("RelatoriosFinanceiros"))}>
                  Ver Relatório Completo
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Resumo por Categoria</CardTitle>
                <CardDescription>
                  Distribuição de receitas e despesas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium text-green-600 mb-2">Top Receitas</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span>Vendas</span>
                        <div className="flex items-center gap-2">
                          <span className="text-green-600 font-medium">R$ 42.800,00</span>
                          <Badge className="bg-green-100 text-green-800">50%</Badge>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Serviços</span>
                        <div className="flex items-center gap-2">
                          <span className="text-green-600 font-medium">R$ 25.500,00</span>
                          <Badge className="bg-green-100 text-green-800">30%</Badge>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Anuidades</span>
                        <div className="flex items-center gap-2">
                          <span className="text-green-600 font-medium">R$ 12.750,00</span>
                          <Badge className="bg-green-100 text-green-800">15%</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="font-medium text-red-600 mb-2">Top Despesas</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span>Pessoal</span>
                        <div className="flex items-center gap-2">
                          <span className="text-red-600 font-medium">R$ 38.500,00</span>
                          <Badge className="bg-red-100 text-red-800">53%</Badge>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Operacional</span>
                        <div className="flex items-center gap-2">
                          <span className="text-red-600 font-medium">R$ 18.750,00</span>
                          <Badge className="bg-red-100 text-red-800">26%</Badge>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Insumos</span>
                        <div className="flex items-center gap-2">
                          <span className="text-red-600 font-medium">R$ 9.800,00</span>
                          <Badge className="bg-red-100 text-red-800">14%</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => navigate(createPageUrl("CategoriasFinanceiras"))}>
                  Ver Detalhamento
                </Button>
              </CardFooter>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Saldo em Contas</CardTitle>
                <CardDescription>Saldo atual por conta bancária</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Wallet className="w-4 h-4 text-blue-600" />
                      <span>Conta Principal</span>
                    </div>
                    <span className="font-medium">R$ 78.450,00</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Landmark className="w-4 h-4 text-purple-600" />
                      <span>Conta Reserva</span>
                    </div>
                    <span className="font-medium">R$ 125.000,00</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-amber-600" />
                      <span>Aplicações</span>
                    </div>
                    <span className="font-medium">R$ 350.000,00</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <div className="w-full pt-2 border-t">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Total</span>
                    <span className="font-bold">R$ 553.450,00</span>
                  </div>
                </div>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Contas a Receber</CardTitle>
                <CardDescription>Próximos 30 dias</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-3">
                  <div className="text-2xl font-bold text-blue-600">R$ 45.800,00</div>
                  <div className="space-y-1">
                    <div className="flex justify-between items-center text-sm">
                      <span>Vencidas</span>
                      <span className="text-red-600 font-medium">R$ 8.750,00</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span>A vencer (15 dias)</span>
                      <span className="font-medium">R$ 22.300,00</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span>A vencer (30 dias)</span>
                      <span className="font-medium">R$ 14.750,00</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full text-sm" 
                  onClick={() => navigate(createPageUrl("ContasReceber"))}
                >
                  <ArrowDownCircle className="w-4 h-4 mr-2 text-green-600" />
                  Gerenciar Contas a Receber
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">Contas a Pagar</CardTitle>
                <CardDescription>Próximos 30 dias</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-3">
                  <div className="text-2xl font-bold text-red-600">R$ 38.450,00</div>
                  <div className="space-y-1">
                    <div className="flex justify-between items-center text-sm">
                      <span>Vencidas</span>
                      <span className="text-red-600 font-medium">R$ 3.200,00</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span>A vencer (15 dias)</span>
                      <span className="font-medium">R$ 18.750,00</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span>A vencer (30 dias)</span>
                      <span className="font-medium">R$ 16.500,00</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full text-sm" 
                  onClick={() => navigate(createPageUrl("ContasPagar"))}
                >
                  <ArrowUpCircle className="w-4 h-4 mr-2 text-red-600" />
                  Gerenciar Contas a Pagar
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        {/* Conteúdo da aba Fluxo de Caixa */}
        <TabsContent value="fluxo-caixa" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Fluxo de Caixa</CardTitle>
                  <CardDescription>
                    Análise de entradas e saídas ao longo do tempo
                  </CardDescription>
                </div>
                <Select value={tipoRelatorio} onValueChange={setTipoRelatorio}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Tipo de relatório" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="completo">Relatório Completo</SelectItem>
                    <SelectItem value="receitas">Apenas Receitas</SelectItem>
                    <SelectItem value="despesas">Apenas Despesas</SelectItem>
                    <SelectItem value="resultado">Apenas Resultado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-sm text-gray-500">Total de Receitas</p>
                  <p className="text-xl font-bold text-green-600">R$ 750.350,00</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-500">Total de Despesas</p>
                  <p className="text-xl font-bold text-red-600">R$ 632.180,00</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-500">Resultado</p>
                  <p className="text-xl font-bold text-blue-600">R$ 118.170,00</p>
                </div>
              </div>
              
              <div className="pt-4">
                <div className="mb-3 flex items-center gap-8">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm">Receitas</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span className="text-sm">Despesas</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span className="text-sm">Fluxo Líquido</span>
                  </div>
                </div>
                
                <div className="h-64 flex flex-col justify-center">
                  {/* Gráfico simplificado de fluxo */}
                  <div className="w-full h-full rounded-md border grid grid-cols-12 gap-1 p-4">
                    {dadosFluxoCaixa.map((value, index) => (
                      <div key={index} className="flex flex-col h-full">
                        <div 
                          style={{ height: `${value}%` }} 
                          className="w-full bg-blue-500 rounded-t-sm mt-auto"
                        ></div>
                        <div className="text-[10px] text-center mt-1 text-gray-500">
                          {index + 1}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-between text-xs text-gray-500 mt-2">
                  <span>Jan</span>
                  <span>F</span>
                  <span>M</span>
                  <span>A</span>
                  <span>M</span>
                  <span>J</span>
                  <span>J</span>
                  <span>A</span>
                  <span>S</span>
                  <span>O</span>
                  <span>N</span>
                  <span>Dez</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button 
                variant="outline" 
                onClick={() => navigate(createPageUrl("FluxoCaixa"))}
              >
                Ver Detalhes
              </Button>
              <Button 
                variant="outline" 
                onClick={exportarRelatorio}
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar
              </Button>
            </CardFooter>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Receitas Mensais</CardTitle>
                <CardDescription>
                  Histórico de receitas dos últimos 12 meses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <LineChart data={dadosReceitas} height={150} />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Despesas Mensais</CardTitle>
                <CardDescription>
                  Histórico de despesas dos últimos 12 meses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <LineChart data={dadosDespesas} height={150} />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Conteúdo da aba Contas Pendentes */}
        <TabsContent value="contas" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Próximas Contas a Pagar</CardTitle>
                <CardDescription>
                  Pagamentos pendentes dos próximos 30 dias
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Folha de Pagamento</p>
                      <p className="text-sm text-gray-500">Vencimento: 05/08/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-amber-100 text-amber-800">Em 5 dias</Badge>
                      <div className="font-medium">R$ 18.500,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Aluguel</p>
                      <p className="text-sm text-gray-500">Vencimento: 10/08/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-amber-100 text-amber-800">Em 10 dias</Badge>
                      <div className="font-medium">R$ 5.200,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Fornecedor XYZ</p>
                      <p className="text-sm text-gray-500">Vencimento: 15/08/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-amber-100 text-amber-800">Em 15 dias</Badge>
                      <div className="font-medium">R$ 3.750,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Impostos</p>
                      <p className="text-sm text-gray-500">Vencimento: 20/08/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-amber-100 text-amber-800">Em 20 dias</Badge>
                      <div className="font-medium">R$ 4.280,00</div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => navigate(createPageUrl("ContasPagar"))}
                >
                  <ArrowUpCircle className="w-4 h-4 mr-2 text-red-600" />
                  Ver todas as contas a pagar
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Próximas Contas a Receber</CardTitle>
                <CardDescription>
                  Recebimentos previstos dos próximos 30 dias
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Cliente ABC</p>
                      <p className="text-sm text-gray-500">Vencimento: 03/08/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-100 text-blue-800">Em 3 dias</Badge>
                      <div className="font-medium">R$ 7.400,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Pagamento de Serviços</p>
                      <p className="text-sm text-gray-500">Vencimento: 08/08/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-100 text-blue-800">Em 8 dias</Badge>
                      <div className="font-medium">R$ 12.650,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Anuidades (10 membros)</p>
                      <p className="text-sm text-gray-500">Vencimento: 15/08/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-100 text-blue-800">Em 15 dias</Badge>
                      <div className="font-medium">R$ 12.000,00</div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Venda de Produtos</p>
                      <p className="text-sm text-gray-500">Vencimento: 22/08/2023</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-100 text-blue-800">Em 22 dias</Badge>
                      <div className="font-medium">R$ 8.250,00</div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => navigate(createPageUrl("ContasReceber"))}
                >
                  <ArrowDownCircle className="w-4 h-4 mr-2 text-green-600" />
                  Ver todas as contas a receber
                </Button>
              </CardFooter>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Contas Vencidas</CardTitle>
              <CardDescription>
                Pagamentos e recebimentos em atraso
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium text-red-600 mb-3">Contas a Pagar Vencidas</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Fornecedor ABC</p>
                        <p className="text-sm text-gray-500">Vencido em: 25/07/2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-red-100 text-red-800">5 dias de atraso</Badge>
                        <div className="font-medium text-red-600">R$ 2.150,00</div>
                      </div>
                    </div>
                    <Separator />
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Serviço de Manutenção</p>
                        <p className="text-sm text-gray-500">Vencido em: 20/07/2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-red-100 text-red-800">10 dias de atraso</Badge>
                        <div className="font-medium text-red-600">R$ 1.050,00</div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium text-amber-600 mb-3">Contas a Receber Vencidas</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Cliente XYZ</p>
                        <p className="text-sm text-gray-500">Vencido em: 28/07/2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-amber-100 text-amber-800">2 dias de atraso</Badge>
                        <div className="font-medium text-amber-600">R$ 4.750,00</div>
                      </div>
                    </div>
                    <Separator />
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Associado João Silva</p>
                        <p className="text-sm text-gray-500">Vencido em: 15/07/2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-amber-100 text-amber-800">15 dias de atraso</Badge>
                        <div className="font-medium text-amber-600">R$ 1.200,00</div>
                      </div>
                    </div>
                    <Separator />
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Cliente ABC</p>
                        <p className="text-sm text-gray-500">Vencido em: 10/07/2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-amber-100 text-amber-800">20 dias de atraso</Badge>
                        <div className="font-medium text-amber-600">R$ 2.800,00</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex gap-4">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => navigate(createPageUrl("ContasVencidas"))}
              >
                <FileText className="w-4 h-4 mr-2" />
                Ver Relatório Completo
              </Button>
              <Button 
                className="flex-1"
                onClick={() => navigate(createPageUrl("NovaCobranca"))}
              >
                <CreditCard className="w-4 h-4 mr-2" />
                Registrar Cobrança
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Conteúdo da aba DRE Simplificado */}
        <TabsContent value="dre" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Demonstração de Resultado do Exercício</CardTitle>
                  <CardDescription>
                    DRE Simplificado do ano atual
                  </CardDescription>
                </div>
                <Button variant="outline" onClick={exportarRelatorio}>
                  <Download className="w-4 h-4 mr-2" />
                  Exportar
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium text-lg">Receitas</h3>
                  <Separator className="my-2" />
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Vendas de Produtos</span>
                      <span className="font-medium">R$ 425.000,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Prestação de Serviços</span>
                      <span className="font-medium">R$ 210.000,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Anuidades e Contribuições</span>
                      <span className="font-medium">R$ 115.350,00</span>
                    </div>
                    <div className="flex justify-between text-lg font-medium">
                      <span>Total de Receitas</span>
                      <span className="text-green-600">R$ 750.350,00</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium text-lg">Custos</h3>
                  <Separator className="my-2" />
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Custo dos Produtos Vendidos</span>
                      <span className="font-medium">R$ 212.500,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Custo dos Serviços Prestados</span>
                      <span className="font-medium">R$ 105.000,00</span>
                    </div>
                    <div className="flex justify-between text-lg font-medium">
                      <span>Total de Custos</span>
                      <span className="text-red-600">R$ 317.500,00</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium text-lg">Lucro Bruto</h3>
                  <Separator className="my-2" />
                  <div className="flex justify-between text-lg font-medium">
                    <span>Lucro Bruto</span>
                    <span className="text-blue-600">R$ 432.850,00</span>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium text-lg">Despesas Operacionais</h3>
                  <Separator className="my-2" />
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Despesas com Pessoal</span>
                      <span className="font-medium">R$ 185.000,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Despesas Administrativas</span>
                      <span className="font-medium">R$ 87.400,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Despesas Comerciais</span>
                      <span className="font-medium">R$ 42.280,00</span>
                    </div>
                    <div className="flex justify-between text-lg font-medium">
                      <span>Total de Despesas Operacionais</span>
                      <span className="text-red-600">R$ 314.680,00</span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex justify-between text-xl font-bold">
                  <span>Resultado Operacional</span>
                  <span className="text-blue-600">R$ 118.170,00</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => navigate(createPageUrl("RelatoriosDRE"))}
              >
                <FileText className="w-4 h-4 mr-2" />
                Ver DRE Detalhado
              </Button>
            </CardFooter>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Comparativo com Exercício Anterior</CardTitle>
                <CardDescription>
                  Análise comparativa com o mesmo período do ano anterior
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Receitas</span>
                    <div className="flex items-center gap-2">
                      <span className="text-green-600 font-medium">+15%</span>
                      <div className="flex items-center gap-2">
                        <span>R$ 750.350,00</span>
                        <span className="text-sm text-gray-500">(R$ 652.500,00)</span>
                      </div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <span>Custos</span>
                    <div className="flex items-center gap-2">
                      <span className="text-red-600 font-medium">+12%</span>
                      <div className="flex items-center gap-2">
                        <span>R$ 317.500,00</span>
                        <span className="text-sm text-gray-500">(R$ 283.500,00)</span>
                      </div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <span>Despesas Operacionais</span>
                    <div className="flex items-center gap-2">
                      <span className="text-red-600 font-medium">+8%</span>
                      <div className="flex items-center gap-2">
                        <span>R$ 314.680,00</span>
                        <span className="text-sm text-gray-500">(R$ 291.370,00)</span>
                      </div>
                    </div>
                  </div>
                  <Separator />
                  
                  <div className="flex justify-between items-center font-medium">
                    <span>Resultado Operacional</span>
                    <div className="flex items-center gap-2">
                      <span className="text-green-600 font-medium">+52%</span>
                      <div className="flex items-center gap-2">
                        <span>R$ 118.170,00</span>
                        <span className="text-sm text-gray-500">(R$ 77.630,00)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Indicadores de Desempenho</CardTitle>
                <CardDescription>
                  Principais indicadores financeiros
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span>Margem Bruta</span>
                      <span className="font-medium">57,7%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: "57.7%" }}></div>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Indica a eficiência operacional básica</p>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span>Margem Operacional</span>
                      <span className="font-medium">15,7%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-500 h-2 rounded-full" style={{ width: "15.7%" }}></div>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Lucro operacional em relação às vendas</p>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span>Rentabilidade do Ativo</span>
                      <span className="font-medium">8,2%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-purple-500 h-2 rounded-full" style={{ width: "8.2%" }}></div>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Retorno sobre ativos totais</p>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span>Crescimento de Receitas</span>
                      <span className="font-medium">15,0%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-amber-500 h-2 rounded-full" style={{ width: "15.0%" }}></div>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Comparado ao ano anterior</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}