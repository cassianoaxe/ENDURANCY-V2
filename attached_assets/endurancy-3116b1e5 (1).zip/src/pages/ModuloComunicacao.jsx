import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ModuloComunicacao } from '@/api/entities';
import {
  Calendar,
  Mail,
  Bell,
  MessageSquare,
  Send,
  Settings,
  Database,
  Cloud,
  Lock,
  Users,
  Plus,
  Info,
  CheckCircle2,
  AlertTriangle,
  ClipboardList,
  BarChart4,
  Image,
  Smartphone,
  Zap,
  FileText,
  Key,
  Upload
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Spinner } from '@/components/ui/spinner';

export default function ModuloComunicacaoPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [moduleData, setModuleData] = useState(null);

  useEffect(() => {
    const loadModule = async () => {
      setLoading(true);
      try {
        // Simulate loading module data
        setTimeout(() => {
          setModuleData({
            isActive: true,
            plan: "free",
            features: {
              calendar: true,
              emailCampaigns: true,
              notifications: true,
              whatsapp: true,
              cloudIntegration: true,
              credentials: true
            }
          });
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error("Error loading module data:", error);
        setLoading(false);
      }
    };

    loadModule();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Spinner size="large" className="text-primary" />
          <p className="mt-4 text-muted-foreground">Carregando módulo de comunicação...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Módulo de Comunicação</h1>
          <p className="text-muted-foreground">
            Gerencie todas as suas comunicações em um único lugar
          </p>
        </div>
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
          Gratuito
        </Badge>
      </div>

      <Alert>
        <CheckCircle2 className="h-4 w-4" />
        <AlertTitle>Módulo ativo</AlertTitle>
        <AlertDescription>
          O módulo de comunicação está ativo e pronto para ser utilizado. Este módulo é gratuito e está disponível para todos os planos.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="principais">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="principais">Recursos Principais</TabsTrigger>
          <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
        </TabsList>
        
        <TabsContent value="principais" className="space-y-4 pt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center text-lg">
                  <Calendar className="mr-2 h-5 w-5 text-indigo-500" />
                  Calendário de Eventos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Gerencie eventos, campanhas e agende notificações para clientes e associados.
                </p>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => navigate(createPageUrl('CalendarioComunicacao'))}
                >
                  Acessar Calendário
                </Button>
              </CardFooter>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center text-lg">
                  <Mail className="mr-2 h-5 w-5 text-indigo-500" />
                  Campanhas de Email
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Crie e envie campanhas de email para seus clientes e associados com rastreamento.
                </p>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => navigate(createPageUrl('CampanhasEmail'))}
                >
                  Gerenciar Campanhas
                </Button>
              </CardFooter>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center text-lg">
                  <Bell className="mr-2 h-5 w-5 text-indigo-500" />
                  Notificações
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Configure notificações automatizadas para diferentes eventos do sistema.
                </p>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => navigate(createPageUrl('NotificacoesComunicacao'))}
                >
                  Configurar Notificações
                </Button>
              </CardFooter>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center text-lg">
                  <MessageSquare className="mr-2 h-5 w-5 text-indigo-500" />
                  WhatsApp
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Integre seu WhatsApp Business para enviar mensagens automatizadas.
                </p>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => navigate(createPageUrl('WhatsAppIntegracao'))}
                >
                  Configurar WhatsApp
                </Button>
              </CardFooter>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center text-lg">
                  <Cloud className="mr-2 h-5 w-5 text-indigo-500" />
                  Mídias e Arquivos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Integre com Google Drive ou Dropbox para gerenciar arquivos e imagens.
                </p>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => navigate(createPageUrl('ArquivosComunicacao'))}
                >
                  Gerenciar Arquivos
                </Button>
              </CardFooter>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center text-lg">
                  <Lock className="mr-2 h-5 w-5 text-indigo-500" />
                  Credenciais de Serviços
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Armazene e gerencie credenciais de serviços como redes sociais e ferramentas.
                </p>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => navigate(createPageUrl('CredenciaisServicos'))}
                >
                  Gerenciar Credenciais
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="configuracoes" className="space-y-4 pt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Configurações de Email</CardTitle>
                <CardDescription>Configure seu servidor SMTP para envio de emails</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Servidor SMTP</span>
                    <Badge variant="outline">Não configurado</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Email do remetente</span>
                    <Badge variant="outline">Não configurado</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Assinatura padrão</span>
                    <Badge variant="outline">Não configurado</Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full"
                  onClick={() => navigate(createPageUrl('ConfiguracoesEmail'))}
                >
                  Configurar Email
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Integração WhatsApp</CardTitle>
                <CardDescription>Configure a API do WhatsApp Business</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">API WhatsApp</span>
                    <Badge variant="outline" className="text-yellow-600 bg-yellow-50 border-yellow-200">
                      Pendente
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Número verificado</span>
                    <Badge variant="outline">Não configurado</Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full"
                  onClick={() => navigate(createPageUrl('WhatsAppIntegracao'))}
                >
                  Configurar WhatsApp
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Integração Cloud</CardTitle>
                <CardDescription>Conecte com Google Drive ou Dropbox</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Serviço</span>
                    <Badge variant="outline">Não configurado</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Pasta principal</span>
                    <Badge variant="outline">Não definida</Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full"
                  onClick={() => navigate(createPageUrl('CloudIntegracao'))}
                >
                  Configurar Cloud
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Configurações de Notificação</CardTitle>
                <CardDescription>Defina preferências de notificação</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Email</span>
                    <Badge variant="outline" className="text-green-600 bg-green-50 border-green-200">
                      Ativado
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">WhatsApp</span>
                    <Badge variant="outline">Desativado</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Push</span>
                    <Badge variant="outline" className="text-green-600 bg-green-50 border-green-200">
                      Ativado
                    </Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full"
                  onClick={() => navigate(createPageUrl('ConfiguracoesNotificacao'))}
                >
                  Configurar Notificações
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <Separator />

      <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-lg">
        <h3 className="font-medium mb-2">Recursos incluídos gratuitamente</h3>
        <ul className="grid gap-2 md:grid-cols-2">
          <li className="flex items-center">
            <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
            <span className="text-sm">Calendário de eventos ilimitado</span>
          </li>
          <li className="flex items-center">
            <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
            <span className="text-sm">Notificações por email</span>
          </li>
          <li className="flex items-center">
            <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
            <span className="text-sm">Notificações push no portal</span>
          </li>
          <li className="flex items-center">
            <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
            <span className="text-sm">Campanhas de email básicas</span>
          </li>
          <li className="flex items-center">
            <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
            <span className="text-sm">Gerenciador de credenciais</span>
          </li>
          <li className="flex items-center">
            <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
            <span className="text-sm">Integração com cloud storage</span>
          </li>
        </ul>
      </div>
    </div>
  );
}