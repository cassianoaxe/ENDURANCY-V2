import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { toast } from '@/components/ui/use-toast';
import {
  FileIcon,
  FolderIcon,
  Image,
  File,
  FilePlus,
  FolderPlus,
  Search,
  Upload,
  Download,
  Trash2,
  MoreHorizontal,
  Share2,
  Edit,
  Copy,
  ArrowUpRight,
  Star,
  Clock,
  Filter,
  Grid,
  List
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator
} from '@/components/ui/breadcrumb';
import { Spinner } from '@/components/ui/spinner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function ArquivosComunicacao() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [files, setFiles] = useState([]);
  const [folders, setFolders] = useState([]);
  const [currentPath, setCurrentPath] = useState('/');
  const [breadcrumbs, setBreadcrumbs] = useState([{ name: 'Início', path: '/' }]);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState('grid');
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('asc');
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [showNewFolderDialog, setShowNewFolderDialog] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [activeTab, setActiveTab] = useState('all');
  const [fileTypeFilter, setFileTypeFilter] = useState('all');

  useEffect(() => {
    loadCurrentUser();
    loadFilesAndFolders();
  }, [currentPath]);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error loading user", error);
      toast({
        title: "Erro de autenticação",
        description: "Você precisa estar logado para acessar esta página.",
        variant: "destructive",
      });
      navigate(createPageUrl("Access"));
    }
  };

  const loadFilesAndFolders = async () => {
    setLoading(true);
    try {
      // In a real app, you would fetch from the database or API
      // const response = await fetch(`/api/files?path=${currentPath}`);
      // const data = await response.json();
      
      // Using mock data for demonstration
      setTimeout(() => {
        setFolders(mockFolders.filter(folder => folder.parent === currentPath));
        setFiles(mockFiles.filter(file => file.path === currentPath));
        setLoading(false);
      }, 500);
    } catch (error) {
      console.error("Error loading files and folders", error);
      toast({
        title: "Erro ao carregar arquivos",
        description: "Não foi possível carregar os arquivos e pastas.",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  const navigateToFolder = (folder) => {
    const newPath = folder.path;
    setCurrentPath(newPath);
    
    // Update breadcrumbs
    const parts = newPath.split('/').filter(Boolean);
    const newBreadcrumbs = [{ name: 'Início', path: '/' }];
    
    let currentFullPath = '';
    parts.forEach(part => {
      currentFullPath += `/${part}`;
      newBreadcrumbs.push({
        name: part,
        path: currentFullPath,
      });
    });
    
    setBreadcrumbs(newBreadcrumbs);
    setSelectedFiles([]);
    setSelectedFolder(null);
  };

  const handleBreadcrumbClick = (breadcrumb) => {
    setCurrentPath(breadcrumb.path);
    
    // Update breadcrumbs
    const index = breadcrumbs.findIndex(b => b.path === breadcrumb.path);
    if (index !== -1) {
      setBreadcrumbs(breadcrumbs.slice(0, index + 1));
    }
    
    setSelectedFiles([]);
    setSelectedFolder(null);
  };

  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSortChange = (value) => {
    if (value === sortBy) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(value);
      setSortOrder('asc');
    }
  };

  const handleFileTypeChange = (value) => {
    setFileTypeFilter(value);
  };

  const handleFileSelection = (file, isSelected) => {
    if (isSelected) {
      setSelectedFiles(prevSelectedFiles => prevSelectedFiles.filter(f => f.id !== file.id));
    } else {
      setSelectedFiles(prevSelectedFiles => [...prevSelectedFiles, file]);
    }
  };

  const handleFolderSelection = (folder) => {
    if (selectedFolder && selectedFolder.id === folder.id) {
      setSelectedFolder(null);
    } else {
      setSelectedFolder(folder);
      setSelectedFiles([]);
    }
  };

  const handleFileUpload = (event) => {
    const files = event.target.files;
    if (files.length === 0) return;

    setIsUploading(true);
    
    // Simulate file upload with progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 5;
      setUploadProgress(progress);
      
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsUploading(false);
          setUploadProgress(0);
          setShowUploadDialog(false);
          
          toast({
            title: "Upload concluído",
            description: `${files.length} arquivo(s) enviado(s) com sucesso.`,
          });
          
          loadFilesAndFolders();
        }, 500);
      }
    }, 200);
  };

  const handleCreateFolder = () => {
    if (!newFolderName.trim()) {
      toast({
        title: "Nome inválido",
        description: "O nome da pasta não pode estar em branco.",
        variant: "destructive",
      });
      return;
    }
    
    // In a real app, send a request to create the folder
    // const response = await fetch('/api/folders', {
    //   method: 'POST',
    //   body: JSON.stringify({ name: newFolderName, parent: currentPath }),
    //   headers: { 'Content-Type': 'application/json' },
    // });
    
    toast({
      title: "Pasta criada",
      description: `A pasta "${newFolderName}" foi criada com sucesso.`,
    });
    
    setNewFolderName('');
    setShowNewFolderDialog(false);
    loadFilesAndFolders();
  };

  const handleDeleteSelected = () => {
    if (selectedFiles.length === 0 && !selectedFolder) return;
    
    const filesToDelete = selectedFiles.length;
    const folderToDelete = selectedFolder ? 1 : 0;
    
    // In a real app, send a request to delete the files/folders
    // const response = await fetch('/api/files', {
    //   method: 'DELETE',
    //   body: JSON.stringify({
    //     files: selectedFiles.map(f => f.id),
    //     folders: selectedFolder ? [selectedFolder.id] : []
    //   }),
    //   headers: { 'Content-Type': 'application/json' },
    // });
    
    toast({
      title: "Itens excluídos",
      description: `${filesToDelete} arquivo(s) e ${folderToDelete} pasta(s) excluído(s) com sucesso.`,
    });
    
    setSelectedFiles([]);
    setSelectedFolder(null);
    loadFilesAndFolders();
  };

  const getFileTypeIcon = (file) => {
    const extension = file.name.split('.').pop().toLowerCase();
    
    switch (extension) {
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return <Image className="w-6 h-6 text-blue-500" />;
      case 'pdf':
        return <File className="w-6 h-6 text-red-500" />;
      case 'doc':
      case 'docx':
        return <File className="w-6 h-6 text-blue-700" />;
      case 'xls':
      case 'xlsx':
        return <File className="w-6 h-6 text-green-600" />;
      case 'ppt':
      case 'pptx':
        return <File className="w-6 h-6 text-orange-500" />;
      default:
        return <FileIcon className="w-6 h-6 text-gray-500" />;
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const filteredFolders = folders.filter(folder => 
    folder.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredFiles = files.filter(file => {
    if (!file.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    if (fileTypeFilter === 'all') {
      return true;
    }
    
    const extension = file.name.split('.').pop().toLowerCase();
    switch (fileTypeFilter) {
      case 'images':
        return ['jpg', 'jpeg', 'png', 'gif'].includes(extension);
      case 'documents':
        return ['pdf', 'doc', 'docx', 'txt'].includes(extension);
      case 'spreadsheets':
        return ['xls', 'xlsx', 'csv'].includes(extension);
      case 'presentations':
        return ['ppt', 'pptx'].includes(extension);
      default:
        return true;
    }
  });

  const sortedFolders = [...filteredFolders].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return sortOrder === 'asc'
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      case 'date':
        return sortOrder === 'asc'
          ? new Date(a.modified) - new Date(b.modified)
          : new Date(b.modified) - new Date(a.modified);
      case 'size':
        return 0; // Folders don't have size
      default:
        return 0;
    }
  });

  const sortedFiles = [...filteredFiles].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return sortOrder === 'asc'
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      case 'date':
        return sortOrder === 'asc'
          ? new Date(a.modified) - new Date(b.modified)
          : new Date(b.modified) - new Date(a.modified);
      case 'size':
        return sortOrder === 'asc'
          ? a.size - b.size
          : b.size - a.size;
      default:
        return 0;
    }
  });

  const filteredItemsByTab = (items) => {
    switch (activeTab) {
      case 'recent':
        return items.filter(item => {
          const itemDate = new Date(item.modified);
          const weekAgo = new Date();
          weekAgo.setDate(weekAgo.getDate() - 7);
          return itemDate >= weekAgo;
        });
      case 'starred':
        return items.filter(item => item.starred);
      case 'shared':
        return items.filter(item => item.shared);
      default:
        return items;
    }
  };

  const finalFolders = filteredItemsByTab(sortedFolders);
  const finalFiles = filteredItemsByTab(sortedFiles);

  // Mock data
  const mockFolders = [
    { id: 'folder-1', name: 'Campanhas', path: '/', parent: '/', modified: '2023-07-15T14:00:00', starred: true, shared: true },
    { id: 'folder-2', name: 'Documentos', path: '/', parent: '/', modified: '2023-08-20T10:30:00', starred: false, shared: false },
    { id: 'folder-3', name: 'Imagens', path: '/', parent: '/', modified: '2023-06-05T09:15:00', starred: true, shared: true },
    { id: 'folder-4', name: 'Relatórios', path: '/', parent: '/', modified: '2023-09-01T16:45:00', starred: false, shared: true },
    { id: 'folder-5', name: 'Email Marketing', path: '/Campanhas', parent: '/Campanhas', modified: '2023-07-18T11:20:00', starred: false, shared: false },
    { id: 'folder-6', name: 'Redes Sociais', path: '/Campanhas', parent: '/Campanhas', modified: '2023-07-20T13:10:00', starred: true, shared: true },
    { id: 'folder-7', name: 'Whatsapp', path: '/Campanhas', parent: '/Campanhas', modified: '2023-07-22T15:30:00', starred: false, shared: false },
  ];

  const mockFiles = [
    { id: 'file-1', name: 'Relatório Anual 2023.pdf', path: '/', size: 2500000, modified: '2023-09-05T11:30:00', starred: true, shared: true },
    { id: 'file-2', name: 'Logo Endurancy.png', path: '/', size: 350000, modified: '2023-08-15T09:45:00', starred: false, shared: true },
    { id: 'file-3', name: 'Presentação Institucional.pptx', path: '/', size: 4200000, modified: '2023-07-20T14:20:00', starred: true, shared: false },
    { id: 'file-4', name: 'Orçamento 2023.xlsx', path: '/', size: 1800000, modified: '2023-06-10T10:00:00', starred: false, shared: false },
    { id: 'file-5', name: 'Manual do Usuário.docx', path: '/', size: 950000, modified: '2023-09-02T15:40:00', starred: false, shared: true },
    { id: 'file-6', name: 'Banner Campanha Julho.jpg', path: '/Campanhas', size: 1200000, modified: '2023-07-01T08:30:00', starred: true, shared: true },
    { id: 'file-7', name: 'Email Template.html', path: '/Campanhas', size: 50000, modified: '2023-07-12T16:15:00', starred: false, shared: false },
    { id: 'file-8', name: 'Resultados_Campanha_Q2.pdf', path: '/Campanhas', size: 3100000, modified: '2023-07-18T13:20:00', starred: true, shared: true },
    { id: 'file-9', name: 'Cronograma de Posts.xlsx', path: '/Campanhas/Redes Sociais', size: 890000, modified: '2023-07-25T11:45:00', starred: false, shared: true },
    { id: 'file-10', name: 'Design Stories Instagram.psd', path: '/Campanhas/Redes Sociais', size: 15000000, modified: '2023-08-02T09:30:00', starred: true, shared: false },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[80vh]">
        <Spinner size="large" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold">Arquivos e Mídias</h1>
            <p className="text-gray-500">Gerenciar arquivos de mídia e documentos para comunicação</p>
          </div>

          <div className="flex flex-wrap gap-2">
            <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Upload className="w-4 h-4" />
                  Fazer Upload
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Fazer Upload de Arquivo</DialogTitle>
                  <DialogDescription>
                    Selecione os arquivos que deseja enviar para a pasta atual.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <Input
                      type="file"
                      className="hidden"
                      id="file-upload"
                      multiple
                      onChange={handleFileUpload}
                    />
                    <label
                      htmlFor="file-upload"
                      className="cursor-pointer flex flex-col items-center justify-center"
                    >
                      <Upload className="w-10 h-10 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500">
                        Arraste e solte arquivos aqui ou clique para selecionar
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        Tamanho máximo: 50MB
                      </p>
                    </label>
                  </div>
                  
                  {isUploading && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progresso</span>
                        <span>{uploadProgress}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full" 
                          style={{ width: `${uploadProgress}%` }} 
                        />
                      </div>
                    </div>
                  )}
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowUploadDialog(false)}>
                    Cancelar
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            
            <Dialog open={showNewFolderDialog} onOpenChange={setShowNewFolderDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <FolderPlus className="w-4 h-4" />
                  Nova Pasta
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Criar Nova Pasta</DialogTitle>
                  <DialogDescription>
                    Digite o nome da nova pasta que deseja criar.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <label htmlFor="folder-name" className="text-sm font-medium">
                      Nome da Pasta
                    </label>
                    <Input
                      id="folder-name"
                      placeholder="Minha Nova Pasta"
                      value={newFolderName}
                      onChange={(e) => setNewFolderName(e.target.value)}
                    />
                  </div>
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowNewFolderDialog(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleCreateFolder}>
                    Criar Pasta
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            
            {(selectedFiles.length > 0 || selectedFolder) && (
              <Button variant="outline" className="gap-2 text-red-500" onClick={handleDeleteSelected}>
                <Trash2 className="w-4 h-4" />
                Excluir
              </Button>
            )}
          </div>
        </div>
        
        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Buscar arquivos..."
              className="pl-8"
              value={searchQuery}
              onChange={handleSearch}
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <Select defaultValue="all" onValueChange={handleFileTypeChange}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Tipo de Arquivo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Tipos</SelectItem>
                <SelectItem value="images">Imagens</SelectItem>
                <SelectItem value="documents">Documentos</SelectItem>
                <SelectItem value="spreadsheets">Planilhas</SelectItem>
                <SelectItem value="presentations">Apresentações</SelectItem>
              </SelectContent>
            </Select>
            
            <Select defaultValue="name" onValueChange={handleSortChange}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Nome {sortBy === 'name' && (sortOrder === 'asc' ? '↑' : '↓')}</SelectItem>
                <SelectItem value="date">Data {sortBy === 'date' && (sortOrder === 'asc' ? '↑' : '↓')}</SelectItem>
                <SelectItem value="size">Tamanho {sortBy === 'size' && (sortOrder === 'asc' ? '↑' : '↓')}</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="flex items-center border rounded-md">
              <Button
                variant="ghost"
                size="icon"
                className={`rounded-none ${viewMode === 'grid' ? 'bg-gray-100' : ''}`}
                onClick={() => setViewMode('grid')}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Separator orientation="vertical" className="h-5" />
              <Button
                variant="ghost"
                size="icon"
                className={`rounded-none ${viewMode === 'list' ? 'bg-gray-100' : ''}`}
                onClick={() => setViewMode('list')}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Breadcrumbs */}
        <div>
          <Breadcrumb>
            <BreadcrumbList>
              {breadcrumbs.map((breadcrumb, index) => (
                <React.Fragment key={index}>
                  {index === breadcrumbs.length - 1 ? (
                    <BreadcrumbItem>
                      <BreadcrumbPage>{breadcrumb.name}</BreadcrumbPage>
                    </BreadcrumbItem>
                  ) : (
                    <BreadcrumbItem>
                      <BreadcrumbLink onClick={() => handleBreadcrumbClick(breadcrumb)}>
                        {breadcrumb.name}
                      </BreadcrumbLink>
                    </BreadcrumbItem>
                  )}
                  {index < breadcrumbs.length - 1 && <BreadcrumbSeparator />}
                </React.Fragment>
              ))}
            </BreadcrumbList>
          </Breadcrumb>
        </div>
        
        {/* Tabs */}
        <Tabs defaultValue="all" onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="all">Todos</TabsTrigger>
            <TabsTrigger value="recent">Recentes</TabsTrigger>
            <TabsTrigger value="starred">Favoritos</TabsTrigger>
            <TabsTrigger value="shared">Compartilhados</TabsTrigger>
          </TabsList>
        </Tabs>
        
        {/* Empty State */}
        {finalFolders.length === 0 && finalFiles.length === 0 && (
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-12 text-center">
            <FolderIcon className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-4 text-lg font-medium text-gray-900 dark:text-gray-100">Nenhum arquivo encontrado</h3>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              Não existem arquivos ou pastas neste local ou com os filtros selecionados.
            </p>
            <div className="mt-6 flex justify-center gap-3">
              <Button onClick={() => setShowUploadDialog(true)} className="gap-2">
                <Upload className="h-4 w-4" />
                Fazer Upload
              </Button>
              <Button variant="outline" onClick={() => setShowNewFolderDialog(true)} className="gap-2">
                <FolderPlus className="h-4 w-4" />
                Nova Pasta
              </Button>
            </div>
          </div>
        )}
        
        {/* Grid View */}
        {viewMode === 'grid' && (finalFolders.length > 0 || finalFiles.length > 0) && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {/* Folders */}
            {finalFolders.map((folder) => (
              <Card 
                key={folder.id} 
                className={`cursor-pointer transition-colors ${
                  selectedFolder?.id === folder.id ? 'bg-gray-100 dark:bg-gray-800 border-blue-300' : ''
                }`}
                onClick={() => handleFolderSelection(folder)}
                onDoubleClick={() => navigateToFolder(folder)}
              >
                <CardContent className="p-4 flex flex-col items-center text-center">
                  <div className="relative mt-2 mb-3">
                    <FolderIcon className="h-16 w-16 text-yellow-400" />
                    {folder.starred && (
                      <Star className="absolute top-0 right-0 h-5 w-5 text-yellow-500 fill-yellow-500" />
                    )}
                  </div>
                  <h3 className="font-medium text-sm truncate w-full">{folder.name}</h3>
                  <p className="text-xs text-gray-500 mt-1">
                    {format(new Date(folder.modified), 'dd/MM/yyyy HH:mm')}
                  </p>
                </CardContent>
              </Card>
            ))}
            
            {/* Files */}
            {finalFiles.map((file) => (
              <Card 
                key={file.id} 
                className={`cursor-pointer transition-colors ${
                  selectedFiles.some(f => f.id === file.id) ? 'bg-gray-100 dark:bg-gray-800 border-blue-300' : ''
                }`}
                onClick={() => handleFileSelection(file, selectedFiles.some(f => f.id === file.id))}
              >
                <CardContent className="p-4 flex flex-col items-center text-center">
                  <div className="relative mt-2 mb-3">
                    {getFileTypeIcon(file)}
                    {file.starred && (
                      <Star className="absolute top-0 right-0 h-5 w-5 text-yellow-500 fill-yellow-500" />
                    )}
                  </div>
                  <h3 className="font-medium text-sm truncate w-full">{file.name}</h3>
                  <p className="text-xs text-gray-500 mt-1">
                    {formatFileSize(file.size)}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        
        {/* List View */}
        {viewMode === 'list' && (finalFolders.length > 0 || finalFiles.length > 0) && (
          <div className="overflow-hidden rounded-md border border-gray-200">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Nome
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Modificado
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Tamanho
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {/* Folders */}
                {finalFolders.map((folder) => (
                  <tr 
                    key={folder.id} 
                    className={`hover:bg-gray-50 cursor-pointer ${
                      selectedFolder?.id === folder.id ? 'bg-gray-100' : ''
                    }`}
                    onClick={() => handleFolderSelection(folder)}
                    onDoubleClick={() => navigateToFolder(folder)}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 flex mr-3">
                          <FolderIcon className="h-5 w-5 text-yellow-400" />
                          {folder.starred && (
                            <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 -mt-1 -ml-1" />
                          )}
                        </div>
                        <div className="ml-1">
                          <div className="text-sm font-medium text-gray-900">{folder.name}</div>
                          <div className="text-xs text-gray-500">Pasta</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {format(new Date(folder.modified), 'dd/MM/yyyy HH:mm')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      -
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={(e) => {
                            e.stopPropagation();
                            navigateToFolder(folder);
                          }}>
                            <ArrowUpRight className="mr-2 h-4 w-4" />
                            Abrir
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Share2 className="mr-2 h-4 w-4" />
                            Compartilhar
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Renomear
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Star className="mr-2 h-4 w-4" />
                            {folder.starred ? 'Remover dos Favoritos' : 'Adicionar aos Favoritos'}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600" onClick={(e) => {
                            e.stopPropagation();
                            handleFolderSelection(folder);
                            handleDeleteSelected();
                          }}>
                            <Trash2 className="mr-2 h-4 w-4" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
                
                {/* Files */}
                {finalFiles.map((file) => (
                  <tr 
                    key={file.id} 
                    className={`hover:bg-gray-50 cursor-pointer ${
                      selectedFiles.some(f => f.id === file.id) ? 'bg-gray-100' : ''
                    }`}
                    onClick={() => handleFileSelection(file, selectedFiles.some(f => f.id === file.id))}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 flex mr-3">
                          {getFileTypeIcon(file)}
                          {file.starred && (
                            <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 -mt-1 -ml-1" />
                          )}
                        </div>
                        <div className="ml-1">
                          <div className="text-sm font-medium text-gray-900">{file.name}</div>
                          <div className="text-xs text-gray-500">
                            {file.name.split('.').pop().toUpperCase()}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {format(new Date(file.modified), 'dd/MM/yyyy HH:mm')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatFileSize(file.size)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Share2 className="mr-2 h-4 w-4" />
                            Compartilhar
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Copy className="mr-2 h-4 w-4" />
                            Copiar Link
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Star className="mr-2 h-4 w-4" />
                            {file.starred ? 'Remover dos Favoritos' : 'Adicionar aos Favoritos'}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600" onClick={(e) => {
                            e.stopPropagation();
                            handleFileSelection(file, false);
                            handleDeleteSelected();
                          }}>
                            <Trash2 className="mr-2 h-4 w-4" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}