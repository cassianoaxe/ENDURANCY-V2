
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Package, 
  Search, 
  Filter, 
  ArrowRightLeft, 
  Truck, 
  ShoppingBag, 
  AlertTriangle, 
  Clock, 
  MoreHorizontal, 
  Plus, 
  FileText, 
  Download, 
  Printer, 
  BarChart2, 
  RefreshCw,
  Calendar,
  Factory,
  Warehouse,
  XCircle,
  CheckCircle2,
  Eye,
  PlusCircle,
  ArrowRight,
  RotateCcw,
  QrCode,
  DollarSign
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "@/components/ui/use-toast";

// Dados simulados de produtos no estoque de distribuição
const mockDistribuicao = [
  {
    id: "dist-001",
    codigo: "CBD-OIL-30ML",
    nome: "Óleo de CBD 30ml (3%)",
    descricao: "Óleo de CBD 3% em frasco de 30ml com conta-gotas",
    categoria: "Óleo",
    lote: "OIL-2023-056",
    producao_id: "prod-235",
    quantidade_atual: 250,
    unidade_medida: "frasco",
    data_fabricacao: "2023-05-15",
    data_validade: "2024-05-15",
    data_entrada: "2023-05-20T10:30:00Z",
    localizacao: "Área A / Estante 3 / Prateleira 2",
    status: "disponivel",
    preco_unitario: 120.50,
    destino_reservado: "nenhum"
  },
  {
    id: "dist-002",
    codigo: "CBD-CAPS-30",
    nome: "Cápsulas de CBD 10mg",
    descricao: "Cápsulas de CBD 10mg - Embalagem com 30 unidades",
    categoria: "Cápsulas",
    lote: "CAPS-2023-112",
    producao_id: "prod-240",
    quantidade_atual: 180,
    unidade_medida: "caixa",
    data_fabricacao: "2023-06-10",
    data_validade: "2024-12-10",
    data_entrada: "2023-06-15T14:20:00Z",
    localizacao: "Área B / Estante 1 / Prateleira 4",
    status: "disponivel",
    preco_unitario: 150.00,
    destino_reservado: "nenhum"
  },
  {
    id: "dist-003",
    codigo: "CBD-CREAM-50G",
    nome: "Creme de CBD 50g",
    descricao: "Creme tópico com CBD 1% - Tubo de 50g",
    categoria: "Tópicos",
    lote: "CREAM-2023-078",
    producao_id: "prod-228",
    quantidade_atual: 120,
    unidade_medida: "tubo",
    data_fabricacao: "2023-05-05",
    data_validade: "2025-05-05",
    data_entrada: "2023-05-10T09:45:00Z",
    localizacao: "Área B / Estante 2 / Prateleira 1",
    status: "disponivel",
    preco_unitario: 85.90,
    destino_reservado: "nenhum"
  },
  {
    id: "dist-004",
    codigo: "CBD-OIL-10ML",
    nome: "Óleo de CBD 10ml (5%)",
    descricao: "Óleo de CBD 5% em frasco de 10ml com conta-gotas",
    categoria: "Óleo",
    lote: "OIL-2023-062",
    producao_id: "prod-237",
    quantidade_atual: 100,
    unidade_medida: "frasco",
    data_fabricacao: "2023-05-20",
    data_validade: "2024-05-20",
    data_entrada: "2023-05-25T11:15:00Z",
    localizacao: "Área A / Estante 3 / Prateleira 1",
    status: "reservado",
    preco_unitario: 80.00,
    destino_reservado: "estoque_envio",
    data_reserva: "2023-06-28T09:30:00Z"
  },
  {
    id: "dist-005",
    codigo: "CBD-SPRAY-30ML",
    nome: "Spray Bucal de CBD 30ml",
    descricao: "Spray bucal de CBD 2.5% - Frasco 30ml",
    categoria: "Spray",
    lote: "SPRAY-2023-035",
    producao_id: "prod-220",
    quantidade_atual: 85,
    unidade_medida: "frasco",
    data_fabricacao: "2023-04-10",
    data_validade: "2024-10-10",
    data_entrada: "2023-04-15T13:40:00Z",
    localizacao: "Área A / Estante 2 / Prateleira 3",
    status: "em_quarentena",
    preco_unitario: 95.50,
    destino_reservado: "nenhum"
  },
  {
    id: "dist-006",
    codigo: "CBD-SLEEP-CAPS",
    nome: "Cápsulas Sleep de CBD+Melatonina",
    descricao: "Cápsulas com CBD 5mg e Melatonina 1mg - Embalagem com 30 unidades",
    categoria: "Cápsulas",
    lote: "SLEEP-2023-028",
    producao_id: "prod-245",
    quantidade_atual: 90,
    unidade_medida: "caixa",
    data_fabricacao: "2023-06-20",
    data_validade: "2024-12-20",
    data_entrada: "2023-06-25T10:10:00Z",
    localizacao: "Área B / Estante 1 / Prateleira 3",
    status: "disponivel",
    preco_unitario: 165.00,
    destino_reservado: "nenhum"
  },
  {
    id: "dist-007",
    codigo: "CBD-FULLSP-OIL",
    nome: "Óleo Full Spectrum CBD 30ml",
    descricao: "Óleo Full Spectrum CBD 5% - Frasco 30ml",
    categoria: "Óleo",
    lote: "FULL-2023-042",
    producao_id: "prod-248",
    quantidade_atual: 70,
    unidade_medida: "frasco",
    data_fabricacao: "2023-06-22",
    data_validade: "2024-06-22",
    data_entrada: "2023-06-27T15:20:00Z",
    localizacao: "Área A / Estante 3 / Prateleira 2",
    status: "reservado",
    preco_unitario: 180.00,
    destino_reservado: "farmacia",
    data_reserva: "2023-07-01T14:45:00Z"
  },
  {
    id: "dist-008",
    codigo: "CBD-PET-OIL",
    nome: "Óleo de CBD para Pets 30ml",
    descricao: "Óleo de CBD 1% para animais - Frasco 30ml",
    categoria: "Pet",
    lote: "PET-2023-019",
    producao_id: "prod-230",
    quantidade_atual: 45,
    unidade_medida: "frasco",
    data_fabricacao: "2023-05-02",
    data_validade: "2024-05-02",
    data_entrada: "2023-05-07T09:50:00Z",
    localizacao: "Área C / Estante 1 / Prateleira 1",
    status: "disponivel",
    preco_unitario: 90.00,
    destino_reservado: "nenhum"
  }
];

// Dados simulados de movimentações
const mockMovimentacoes = [
  {
    id: "mov-001",
    codigo_movimentacao: "DIST-MOV-0001",
    produto_id: "dist-001",
    lote: "OIL-2023-056",
    tipo_movimentacao: "entrada_producao",
    quantidade: 300,
    unidade_medida: "frasco",
    data_movimentacao: "2023-05-20T10:30:00Z",
    origem: "produção",
    destino: "distribuição",
    responsavel_nome: "Lucas Santos",
    motivo: "Finalização da produção",
    documento_relacionado: {
      tipo: "ordem_producao",
      numero: "OP-2023-235",
      id: "prod-235"
    },
    status_confirmacao: "confirmado"
  },
  {
    id: "mov-002",
    codigo_movimentacao: "DIST-MOV-0002",
    produto_id: "dist-001",
    lote: "OIL-2023-056",
    tipo_movimentacao: "saida_farmacia",
    quantidade: 50,
    unidade_medida: "frasco",
    data_movimentacao: "2023-06-10T11:15:00Z",
    origem: "distribuição",
    destino: "farmácia",
    responsavel_nome: "Ana Costa",
    motivo: "Abastecimento da farmácia",
    documento_relacionado: {
      tipo: "transferencia",
      numero: "TRF-2023-042",
      id: "trf-042"
    },
    status_confirmacao: "confirmado"
  },
  {
    id: "mov-003",
    codigo_movimentacao: "DIST-MOV-0003",
    produto_id: "dist-002",
    lote: "CAPS-2023-112",
    tipo_movimentacao: "entrada_producao",
    quantidade: 200,
    unidade_medida: "caixa",
    data_movimentacao: "2023-06-15T14:20:00Z",
    origem: "produção",
    destino: "distribuição",
    responsavel_nome: "Lucas Santos",
    motivo: "Finalização da produção",
    documento_relacionado: {
      tipo: "ordem_producao",
      numero: "OP-2023-240",
      id: "prod-240"
    },
    status_confirmacao: "confirmado"
  },
  {
    id: "mov-004",
    codigo_movimentacao: "DIST-MOV-0004",
    produto_id: "dist-002",
    lote: "CAPS-2023-112",
    tipo_movimentacao: "saida_envio",
    quantidade: 20,
    unidade_medida: "caixa",
    data_movimentacao: "2023-06-25T10:45:00Z",
    origem: "distribuição",
    destino: "envio",
    responsavel_nome: "Roberto Almeida",
    motivo: "Pedido #12345",
    documento_relacionado: {
      tipo: "pedido",
      numero: "PED-2023-12345",
      id: "ped-12345"
    },
    status_confirmacao: "confirmado"
  },
  {
    id: "mov-005",
    codigo_movimentacao: "DIST-MOV-0005",
    produto_id: "dist-004",
    lote: "OIL-2023-062",
    tipo_movimentacao: "reserva",
    quantidade: 100,
    unidade_medida: "frasco",
    data_movimentacao: "2023-06-28T09:30:00Z",
    origem: "distribuição",
    destino: "estoque_envio",
    responsavel_nome: "Roberto Almeida",
    motivo: "Preparação para envio",
    status_confirmacao: "pendente"
  },
  {
    id: "mov-006",
    codigo_movimentacao: "DIST-MOV-0006",
    produto_id: "dist-007",
    lote: "FULL-2023-042",
    tipo_movimentacao: "reserva",
    quantidade: 70,
    unidade_medida: "frasco",
    data_movimentacao: "2023-07-01T14:45:00Z",
    origem: "distribuição",
    destino: "farmacia",
    responsavel_nome: "Ana Costa",
    motivo: "Reserva para farmácia",
    status_confirmacao: "pendente"
  },
  {
    id: "mov-007",
    codigo_movimentacao: "DIST-MOV-0007",
    produto_id: "dist-005",
    lote: "SPRAY-2023-035",
    tipo_movimentacao: "ajuste",
    quantidade: -15,
    unidade_medida: "frasco",
    data_movimentacao: "2023-06-20T11:30:00Z",
    origem: "distribuição",
    destino: "quarentena",
    responsavel_nome: "Paulo Silva",
    motivo: "Problemas de qualidade identificados",
    status_confirmacao: "confirmado"
  }
];

export default function ProducaoDistribuicao() {
  const navigate = useNavigate();
  const [produtos, setProdutos] = useState([]);
  const [movimentacoes, setMovimentacoes] = useState([]);
  const [activeTab, setActiveTab] = useState("produtos");
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [categoriaFilter, setCategoriaFilter] = useState("todas");
  const [destinoFilter, setDestinoFilter] = useState("todos");
  const [dialogTransferencia, setDialogTransferencia] = useState(false);
  const [produtoSelecionado, setProdutoSelecionado] = useState(null);
  const [tipoTransferencia, setTipoTransferencia] = useState("saida_envio");
  const [quantidadeTransferencia, setQuantidadeTransferencia] = useState(1);
  const [observacoesTransferencia, setObservacoesTransferencia] = useState("");
  const [motivoTransferencia, setMotivoTransferencia] = useState("");
  
  // Carregar dados simulados
  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setProdutos(mockDistribuicao);
      setMovimentacoes(mockMovimentacoes);
      setLoading(false);
    }, 1000);
  }, []);
  
  // Filtragem de produtos
  const produtosFiltrados = produtos.filter(produto => {
    const matchesSearch = 
      produto.codigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      produto.lote.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesStatus = statusFilter === "todos" || produto.status === statusFilter;
    const matchesCategoria = categoriaFilter === "todas" || produto.categoria === categoriaFilter;
    const matchesDestino = 
      destinoFilter === "todos" || 
      (destinoFilter === "reservado" && produto.destino_reservado !== "nenhum") ||
      produto.destino_reservado === destinoFilter;
      
    return matchesSearch && matchesStatus && matchesCategoria && matchesDestino;
  });
  
  // Filtragem de movimentações
  const movimentacoesFiltradas = movimentacoes.filter(movimentacao => {
    const matchesSearch = 
      movimentacao.codigo_movimentacao.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movimentacao.lote.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (movimentacao.motivo && movimentacao.motivo.toLowerCase().includes(searchTerm.toLowerCase()));
      
    return matchesSearch;
  });
  
  // Categorias únicas para o filtro
  const categorias = [...new Set(produtos.map(p => p.categoria))];
  
  // Função para formatar data
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  // Função para formatar data e hora
  const formatDateTime = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  // Função para formatar moeda
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };
  
  // Abrir diálogo de transferência
  const abrirDialogTransferencia = (produto, tipo) => {
    setProdutoSelecionado(produto);
    setTipoTransferencia(tipo);
    setQuantidadeTransferencia(1);
    setObservacoesTransferencia("");
    setMotivoTransferencia("");
    setDialogTransferencia(true);
  };
  
  // Realizar transferência
  const realizarTransferencia = () => {
    // Validar quantidade
    if (quantidadeTransferencia <= 0) {
      toast({
        title: "Erro de validação",
        description: "A quantidade deve ser maior que zero.",
        variant: "destructive"
      });
      return;
    }
    
    if (quantidadeTransferencia > produtoSelecionado.quantidade_atual) {
      toast({
        title: "Erro de validação",
        description: "A quantidade não pode ser maior que a disponível no estoque.",
        variant: "destructive"
      });
      return;
    }
    
    if (!motivoTransferencia) {
      toast({
        title: "Erro de validação",
        description: "Informe o motivo da transferência.",
        variant: "destructive"
      });
      return;
    }
    
    // Determinar destino com base no tipo
    let destino = "";
    if (tipoTransferencia === "saida_envio") destino = "estoque_envio";
    else if (tipoTransferencia === "saida_farmacia") destino = "farmacia";
    else if (tipoTransferencia === "devolucao") destino = "devolucao";
    
    // Criar nova movimentação
    const novaMovimentacao = {
      id: `mov-${movimentacoes.length + 1}`,
      codigo_movimentacao: `DIST-MOV-${String(movimentacoes.length + 1).padStart(4, '0')}`,
      produto_id: produtoSelecionado.id,
      lote: produtoSelecionado.lote,
      tipo_movimentacao: tipoTransferencia,
      quantidade: parseInt(quantidadeTransferencia),
      unidade_medida: produtoSelecionado.unidade_medida,
      data_movimentacao: new Date().toISOString(),
      origem: "distribuição",
      destino: destino,
      responsavel_nome: "Usuário Atual",
      motivo: motivoTransferencia,
      observacao: observacoesTransferencia,
      status_confirmacao: "pendente"
    };
    
    // Atualizar produto
    const novosProdutos = produtos.map(p => {
      if (p.id === produtoSelecionado.id) {
        return {
          ...p,
          quantidade_atual: p.quantidade_atual - parseInt(quantidadeTransferencia),
          status: parseInt(quantidadeTransferencia) === p.quantidade_atual ? "reservado" : p.status,
          destino_reservado: parseInt(quantidadeTransferencia) === p.quantidade_atual ? destino : p.destino_reservado
        };
      }
      return p;
    });
    
    // Atualizar estados
    setMovimentacoes([novaMovimentacao, ...movimentacoes]);
    setProdutos(novosProdutos);
    
    // Fechar diálogo e mostrar toast
    setDialogTransferencia(false);
    toast({
      title: "Transferência realizada com sucesso",
      description: `${quantidadeTransferencia} ${produtoSelecionado.unidade_medida}(s) de ${produtoSelecionado.nome} transferido(s) para ${destino}.`
    });
  };
  
  // Função para renderizar badge de status
  const renderStatusBadge = (status) => {
    switch (status) {
      case "disponivel":
        return <Badge className="bg-green-100 text-green-800">Disponível</Badge>;
      case "reservado":
        return <Badge className="bg-blue-100 text-blue-800">Reservado</Badge>;
      case "em_quarentena":
        return <Badge className="bg-yellow-100 text-yellow-800">Em Quarentena</Badge>;
      case "em_transito":
        return <Badge className="bg-purple-100 text-purple-800">Em Trânsito</Badge>;
      case "expirado":
        return <Badge className="bg-red-100 text-red-800">Expirado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  // Função para renderizar badge de tipo de movimentação
  const renderTipoMovimentacaoBadge = (tipo) => {
    switch (tipo) {
      case "entrada_producao":
        return <Badge className="bg-green-100 text-green-800">Entrada da Produção</Badge>;
      case "saida_farmacia":
        return <Badge className="bg-blue-100 text-blue-800">Saída p/ Farmácia</Badge>;
      case "saida_envio":
        return <Badge className="bg-purple-100 text-purple-800">Saída p/ Envio</Badge>;
      case "devolucao":
        return <Badge className="bg-red-100 text-red-800">Devolução</Badge>;
      case "ajuste":
        return <Badge className="bg-yellow-100 text-yellow-800">Ajuste</Badge>;
      case "descarte":
        return <Badge className="bg-red-100 text-red-800">Descarte</Badge>;
      case "reserva":
        return <Badge className="bg-blue-100 text-blue-800">Reserva</Badge>;
      case "cancelamento_reserva":
        return <Badge className="bg-gray-100 text-gray-800">Cancelamento de Reserva</Badge>;
      default:
        return <Badge variant="outline">{tipo}</Badge>;
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Distribuição</h1>
          <p className="text-gray-500 mt-1">
            Gerencie o estoque de produtos acabados prontos para distribuição
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Exportar
          </Button>
          <Button variant="outline" className="gap-2">
            <Printer className="w-4 h-4" />
            Imprimir
          </Button>
          <Button variant="outline" className="gap-2">
            <BarChart2 className="w-4 h-4" />
            Relatórios
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="produtos">Produtos</TabsTrigger>
          <TabsTrigger value="movimentacoes">Movimentações</TabsTrigger>
        </TabsList>
        
        <TabsContent value="produtos" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <CardTitle>Produtos em Estoque</CardTitle>
                
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Buscar por código, nome, lote..."
                      className="pl-10 w-full"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <div className="flex items-center gap-2">
                        <Filter className="h-4 w-4" />
                        <SelectValue placeholder="Status" />
                      </div>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos os Status</SelectItem>
                      <SelectItem value="disponivel">Disponível</SelectItem>
                      <SelectItem value="reservado">Reservado</SelectItem>
                      <SelectItem value="em_quarentena">Em Quarentena</SelectItem>
                      <SelectItem value="em_transito">Em Trânsito</SelectItem>
                      <SelectItem value="expirado">Expirado</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select value={categoriaFilter} onValueChange={setCategoriaFilter}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <div className="flex items-center gap-2">
                        <Filter className="h-4 w-4" />
                        <SelectValue placeholder="Categoria" />
                      </div>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todas">Todas as Categorias</SelectItem>
                      {categorias.map((categoria) => (
                        <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select value={destinoFilter} onValueChange={setDestinoFilter}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <div className="flex items-center gap-2">
                        <Filter className="h-4 w-4" />
                        <SelectValue placeholder="Destino" />
                      </div>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos os Destinos</SelectItem>
                      <SelectItem value="nenhum">Sem Reserva</SelectItem>
                      <SelectItem value="reservado">Reservados</SelectItem>
                      <SelectItem value="estoque_envio">Estoque de Envio</SelectItem>
                      <SelectItem value="farmacia">Farmácia</SelectItem>
                      <SelectItem value="devolucao">Devolução</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="py-10 text-center">
                  <RefreshCw className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                  <p className="mt-2 text-gray-500">Carregando produtos...</p>
                </div>
              ) : produtosFiltrados.length === 0 ? (
                <div className="py-10 text-center">
                  <Package className="h-8 w-8 mx-auto text-gray-400" />
                  <p className="mt-2 text-gray-500">Nenhum produto encontrado</p>
                  <p className="text-gray-400 text-sm mt-1">Tente ajustar os filtros de busca</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Código</TableHead>
                        <TableHead>Nome</TableHead>
                        <TableHead>Lote</TableHead>
                        <TableHead>Categoria</TableHead>
                        <TableHead className="text-center">Quantidade</TableHead>
                        <TableHead>Data Fabricação</TableHead>
                        <TableHead>Data Validade</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {produtosFiltrados.map((produto) => (
                        <TableRow key={produto.id}>
                          <TableCell className="font-medium">{produto.codigo}</TableCell>
                          <TableCell>{produto.nome}</TableCell>
                          <TableCell>{produto.lote}</TableCell>
                          <TableCell>{produto.categoria}</TableCell>
                          <TableCell className="text-center">
                            {produto.quantidade_atual} {produto.unidade_medida}
                          </TableCell>
                          <TableCell>{formatDate(produto.data_fabricacao)}</TableCell>
                          <TableCell>{formatDate(produto.data_validade)}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {renderStatusBadge(produto.status)}
                              {produto.destino_reservado !== "nenhum" && (
                                <Badge variant="outline" className="bg-blue-50">
                                  {produto.destino_reservado === "estoque_envio" ? "Envio" : 
                                   produto.destino_reservado === "farmacia" ? "Farmácia" : 
                                   "Devolução"}
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                <DropdownMenuItem onClick={() => { /* Implementar visualização */ }}>
                                  <Eye className="h-4 w-4 mr-2" />
                                  Visualizar Detalhes
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => { /* Implementar geração */ }}>
                                  <QrCode className="h-4 w-4 mr-2" />
                                  Gerar QR Code
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuLabel>Transferir para</DropdownMenuLabel>
                                <DropdownMenuItem 
                                  onClick={() => abrirDialogTransferencia(produto, "saida_envio")} 
                                  disabled={produto.status !== "disponivel"}
                                >
                                  <Truck className="h-4 w-4 mr-2" />
                                  Estoque de Envio
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={() => abrirDialogTransferencia(produto, "saida_farmacia")} 
                                  disabled={produto.status !== "disponivel"}
                                >
                                  <ShoppingBag className="h-4 w-4 mr-2" />
                                  Farmácia
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={() => abrirDialogTransferencia(produto, "devolucao")} 
                                  disabled={produto.status !== "disponivel"}
                                >
                                  <RotateCcw className="h-4 w-4 mr-2" />
                                  Devolução
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Total de Produtos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-3xl font-bold">
                      {produtos.reduce((acc, p) => acc + p.quantidade_atual, 0)}
                    </p>
                    <p className="text-sm text-gray-500">unidades em estoque</p>
                  </div>
                  <div className="p-2 bg-green-50 rounded-lg">
                    <Package className="h-8 w-8 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Valor em Estoque</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-3xl font-bold">
                      {formatCurrency(produtos.reduce((acc, p) => acc + (p.quantidade_atual * p.preco_unitario), 0))}
                    </p>
                    <p className="text-sm text-gray-500">valor total</p>
                  </div>
                  <div className="p-2 bg-purple-50 rounded-lg">
                    <DollarSign className="h-8 w-8 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Produtos Próximos ao Vencimento</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-3xl font-bold">
                      {produtos.filter(p => {
                        const today = new Date();
                        const expiry = new Date(p.data_validade);
                        const diffTime = Math.abs(expiry - today);
                        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                        return diffDays <= 90;
                      }).length}
                    </p>
                    <p className="text-sm text-gray-500">expirando em 90 dias</p>
                  </div>
                  <div className="p-2 bg-yellow-50 rounded-lg">
                    <Clock className="h-8 w-8 text-yellow-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="movimentacoes">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <CardTitle>Histórico de Movimentações</CardTitle>
                
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Buscar por código, lote, motivo..."
                      className="pl-10 w-full"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="py-10 text-center">
                  <RefreshCw className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                  <p className="mt-2 text-gray-500">Carregando movimentações...</p>
                </div>
              ) : movimentacoesFiltradas.length === 0 ? (
                <div className="py-10 text-center">
                  <ArrowRightLeft className="h-8 w-8 mx-auto text-gray-400" />
                  <p className="mt-2 text-gray-500">Nenhuma movimentação encontrada</p>
                  <p className="text-gray-400 text-sm mt-1">Tente ajustar os termos de busca</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Código</TableHead>
                        <TableHead>Lote</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Origem</TableHead>
                        <TableHead>Destino</TableHead>
                        <TableHead className="text-center">Quantidade</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead>Responsável</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {movimentacoesFiltradas.map((movimentacao) => {
                        // Encontrar produto relacionado
                        const produto = produtos.find(p => p.id === movimentacao.produto_id);
                        
                        return (
                          <TableRow key={movimentacao.id}>
                            <TableCell className="font-medium">{movimentacao.codigo_movimentacao}</TableCell>
                            <TableCell>{movimentacao.lote}</TableCell>
                            <TableCell>
                              {renderTipoMovimentacaoBadge(movimentacao.tipo_movimentacao)}
                            </TableCell>
                            <TableCell>{movimentacao.origem}</TableCell>
                            <TableCell>{movimentacao.destino}</TableCell>
                            <TableCell className="text-center">
                              {Math.abs(movimentacao.quantidade)} {movimentacao.unidade_medida}
                              {produto && (
                                <div className="text-xs text-gray-500">
                                  {produto.nome}
                                </div>
                              )}
                            </TableCell>
                            <TableCell>{formatDateTime(movimentacao.data_movimentacao)}</TableCell>
                            <TableCell>{movimentacao.responsavel_nome}</TableCell>
                            <TableCell>
                              {movimentacao.status_confirmacao === "confirmado" ? (
                                <Badge className="bg-green-100 text-green-800">Confirmado</Badge>
                              ) : movimentacao.status_confirmacao === "rejeitado" ? (
                                <Badge className="bg-red-100 text-red-800">Rejeitado</Badge>
                              ) : (
                                <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Diálogo de Transferência */}
      {produtoSelecionado && (
        <Dialog open={dialogTransferencia} onOpenChange={setDialogTransferencia}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>
                {tipoTransferencia === "saida_envio" ? "Transferir para Estoque de Envio" :
                 tipoTransferencia === "saida_farmacia" ? "Transferir para Farmácia" :
                 "Registrar Devolução"}
              </DialogTitle>
              <DialogDescription>
                Informe os detalhes para realizar a transferência do produto.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="bg-gray-50 p-3 rounded-lg">
                <h4 className="font-medium">{produtoSelecionado.nome}</h4>
                <div className="flex items-center gap-2 mt-1 text-sm text-gray-600">
                  <span>Código: {produtoSelecionado.codigo}</span>
                  <span>•</span>
                  <span>Lote: {produtoSelecionado.lote}</span>
                </div>
                <div className="flex items-center gap-2 mt-1 text-sm text-gray-600">
                  <span>Disponível: {produtoSelecionado.quantidade_atual} {produtoSelecionado.unidade_medida}</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Quantidade a transferir</label>
                  <Input
                    type="number"
                    min="1"
                    max={produtoSelecionado.quantidade_atual}
                    value={quantidadeTransferencia}
                    onChange={(e) => setQuantidadeTransferencia(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Destino</label>
                  <Input
                    type="text"
                    value={tipoTransferencia === "saida_envio" ? "Estoque de Envio" :
                           tipoTransferencia === "saida_farmacia" ? "Farmácia" :
                           "Devolução"}
                    disabled
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Motivo da transferência</label>
                <Input
                  type="text"
                  placeholder="Ex: Abastecimento da farmácia, Preparação para envio..."
                  value={motivoTransferencia}
                  onChange={(e) => setMotivoTransferencia(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Observações (opcional)</label>
                <Input
                  type="text"
                  placeholder="Observações adicionais..."
                  value={observacoesTransferencia}
                  onChange={(e) => setObservacoesTransferencia(e.target.value)}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogTransferencia(false)}>
                Cancelar
              </Button>
              <Button onClick={realizarTransferencia}>
                {tipoTransferencia === "devolucao" ? "Registrar Devolução" : "Realizar Transferência"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
