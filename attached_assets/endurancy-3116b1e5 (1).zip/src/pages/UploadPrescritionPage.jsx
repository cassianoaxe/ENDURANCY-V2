import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { PrescricaoFarmaceutica } from '@/api/entities';
import { toast } from '@/components/ui/use-toast';
import { UploadFile } from "@/api/integrations";
import {
  ArrowLeft,
  Upload,
  FileText,
  AlertCircle,
  CheckCircle,
  Clock,
  X,
  Calendar,
  User as UserIcon,
  Info,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from '@/components/ui/tabs';
import {
  Alert,
  AlertDescription,
  AlertTitle
} from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';
import { Spinner } from '@/components/ui/spinner';
import { format, parseISO, addDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function UploadPrescriptionPage() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [fileUploading, setFileUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [viewMode, setViewMode] = useState('upload'); // 'upload', 'history'
  const [recentPrescriptions, setRecentPrescriptions] = useState([]);
  
  const fileInputRef = useRef(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [fileUrl, setFileUrl] = useState('');
  
  // Simulate loading user and existing prescriptions
  React.useEffect(() => {
    const loadData = async () => {
      try {
        // In a real app, would fetch the real user
        // const user = await User.me();
        
        // Mock data
        setCurrentUser({
          id: "user_123",
          full_name: "Maria da Silva",
          email: "maria@example.com"
        });
        
        // Mock prescriptions
        setRecentPrescriptions([
          {
            id: "presc_1",
            data_envio: new Date(Date.now() - 15 * 86400000).toISOString(), // 15 days ago
            status: "aprovada",
            data_analise: new Date(Date.now() - 14 * 86400000).toISOString(), // 14 days ago
            arquivo_url: "https://example.com/prescription1.pdf",
            validade_prescricao: addDays(new Date(), 45).toISOString(),
            farmaceutico_nome: "Dr. João Farmacêutico",
            produtos_prescritos: [
              {
                nome: "Óleo CBD 5%",
                dosagem: "20mg/ml",
                posologia: "10 gotas, 2x ao dia",
                quantidade: 1
              }
            ]
          },
          {
            id: "presc_2",
            data_envio: new Date(Date.now() - 45 * 86400000).toISOString(), // 45 days ago
            status: "rejeitada",
            data_analise: new Date(Date.now() - 44 * 86400000).toISOString(), // 44 days ago
            arquivo_url: "https://example.com/prescription2.pdf",
            motivo_rejeicao: "Prescrição ilegível, favor enviar nova digitalização."
          },
          {
            id: "presc_3",
            data_envio: new Date(Date.now() - 2 * 86400000).toISOString(), // 2 days ago
            status: "pendente",
            arquivo_url: "https://example.com/prescription3.pdf"
          }
        ]);
        
        setLoading(false);
      } catch (error) {
        console.error("Error loading data:", error);
        setLoading(false);
      }
    };
    
    loadData();
  }, []);
  
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedFile(file);
      
      // Create preview for images (would need PDF.js for PDF preview)
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = () => {
          setFilePreview(reader.result);
        };
        reader.readAsDataURL(file);
      } else {
        setFilePreview(null);
      }
    }
  };
  
  const handleFileDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      setSelectedFile(file);
      
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = () => {
          setFilePreview(reader.result);
        };
        reader.readAsDataURL(file);
      } else {
        setFilePreview(null);
      }
    }
  };
  
  const handleUploadClick = () => {
    fileInputRef.current.click();
  };
  
  const handleDragOver = (e) => {
    e.preventDefault();
  };
  
  const clearFile = () => {
    setSelectedFile(null);
    setFilePreview(null);
    setFileUrl('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  const uploadFile = async () => {
    if (!selectedFile) return;
    
    try {
      setFileUploading(true);
      
      // In a real app, we would use the real upload integration
      // const response = await UploadFile({ file: selectedFile });
      // const fileUrl = response.file_url;
      
      // Simulate upload delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock response
      const mockFileUrl = "https://example.com/uploaded_prescription.pdf";
      setFileUrl(mockFileUrl);
      
      toast({
        title: "Arquivo enviado",
        description: "O arquivo foi enviado com sucesso.",
      });
      
      setFileUploading(false);
    } catch (error) {
      console.error('Error uploading file:', error);
      setFileUploading(false);
      
      toast({
        title: "Erro no envio",
        description: "Ocorreu um erro ao enviar o arquivo. Tente novamente.",
        variant: "destructive"
      });
    }
  };
  
  const handleSubmit = async () => {
    if (!fileUrl && !selectedFile) {
      toast({
        title: "Arquivo necessário",
        description: "Por favor, selecione um arquivo de prescrição para enviar.",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setSubmitting(true);
      
      // If file is selected but not uploaded yet
      let finalFileUrl = fileUrl;
      if (!fileUrl && selectedFile) {
        await uploadFile();
        finalFileUrl = "https://example.com/uploaded_prescription.pdf"; // Mock URL
      }
      
      // In a real app, we would save to the database
      // await PrescricaoFarmaceutica.create({
      //   paciente_id: currentUser.id,
      //   arquivo_url: finalFileUrl,
      //   data_envio: new Date().toISOString(),
      //   status: "pendente"
      // });
      
      // Simulate delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Prescrição enviada",
        description: "Sua prescrição foi enviada e está aguardando análise farmacêutica.",
      });
      
      setSubmitting(false);
      
      // Add to local state to show in history
      setRecentPrescriptions(prev => [{
        id: `presc_${Date.now()}`,
        data_envio: new Date().toISOString(),
        status: "pendente",
        arquivo_url: finalFileUrl
      }, ...prev]);
      
      // Clear form
      clearFile();
      
      // Switch to history view
      setViewMode('history');
      
    } catch (error) {
      console.error('Error submitting prescription:', error);
      setSubmitting(false);
      
      toast({
        title: "Erro no envio",
        description: "Ocorreu um erro ao enviar sua prescrição. Tente novamente.",
        variant: "destructive"
      });
    }
  };
  
  const formatDateTime = (dateString) => {
    try {
      return format(parseISO(dateString), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR });
    } catch (e) {
      return dateString || "Data não disponível";
    }
  };
  
  const formatDate = (dateString) => {
    try {
      return format(parseISO(dateString), "dd/MM/yyyy", { locale: ptBR });
    } catch (e) {
      return dateString || "Data não disponível";
    }
  };
  
  const getStatusBadge = (status) => {
    switch (status) {
      case 'pendente':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Aguardando Análise</Badge>;
      case 'aprovada':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Aprovada</Badge>;
      case 'rejeitada':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Rejeitada</Badge>;
      case 'solicitado_alteracao':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Alteração Solicitada</Badge>;
      default:
        return <Badge variant="outline">Desconhecido</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6 flex justify-center items-center min-h-[70vh]">
        <Spinner />
        <span className="ml-2">Carregando...</span>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-2">
        <div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate(-1)}
            className="mb-2"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold">Prescrições Médicas</h1>
          <p className="text-muted-foreground">
            Envie uma nova prescrição ou visualize o histórico
          </p>
        </div>
      </div>

      <Tabs defaultValue={viewMode} onValueChange={setViewMode} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="upload" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            <span>Enviar Nova Prescrição</span>
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>Histórico de Prescrições</span>
            <Badge className="ml-1 bg-gray-100 text-gray-800">
              {recentPrescriptions.length}
            </Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="mt-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Enviar Prescrição</CardTitle>
                <CardDescription>
                  Envie a imagem ou PDF da sua prescrição médica para análise
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div 
                  className={`border-2 border-dashed rounded-lg p-6 text-center ${selectedFile ? 'border-green-300 bg-green-50' : 'border-gray-300 hover:border-primary'}`}
                  onDrop={handleFileDrop}
                  onDragOver={handleDragOver}
                  onClick={selectedFile ? undefined : handleUploadClick}
                  style={{ cursor: selectedFile ? 'default' : 'pointer' }}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    className="hidden"
                    accept=".pdf,image/*"
                  />
                  
                  {selectedFile ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-center">
                        <CheckCircle className="h-12 w-12 text-green-500" />
                      </div>
                      <div>
                        <h3 className="font-medium text-lg">Arquivo selecionado</h3>
                        <p className="text-sm text-gray-500">{selectedFile.name}</p>
                        <p className="text-xs text-gray-500">
                          {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                      {filePreview && (
                        <div className="mt-4 max-h-60 overflow-hidden flex justify-center">
                          <img 
                            src={filePreview} 
                            alt="Preview" 
                            className="max-h-full object-contain rounded-md"
                          />
                        </div>
                      )}
                      <div className="flex justify-center gap-2 mt-4">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={(e) => {
                            e.stopPropagation();
                            clearFile();
                          }}
                        >
                          <X className="mr-2 h-4 w-4" />
                          Remover
                        </Button>
                        
                        {!fileUrl && (
                          <Button 
                            size="sm" 
                            onClick={(e) => {
                              e.stopPropagation();
                              uploadFile();
                            }}
                            disabled={fileUploading}
                          >
                            {fileUploading ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Enviando...
                              </>
                            ) : (
                              <>
                                <Upload className="mr-2 h-4 w-4" />
                                Enviar
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center justify-center">
                        <FileText className="h-12 w-12 text-gray-400" />
                      </div>
                      <div>
                        <h3 className="font-medium text-lg">Arraste e solte sua prescrição aqui</h3>
                        <p className="text-sm text-gray-500">ou clique para selecionar o arquivo</p>
                        <p className="text-xs text-gray-500 mt-2">
                          Formatos aceitos: PDF, JPG, PNG
                        </p>
                      </div>
                    </div>
                  )}
                </div>
                
                <Alert className="mt-6">
                  <Info className="h-4 w-4" />
                  <AlertTitle>Requisitos para a prescrição</AlertTitle>
                  <AlertDescription>
                    <p className="text-sm mt-1">
                      A prescrição enviada deve conter as seguintes informações:
                    </p>
                    <ul className="text-sm mt-2 space-y-1 list-disc pl-5">
                      <li>Nome completo do médico e CRM</li>
                      <li>Seu nome completo como paciente</li>
                      <li>Data da prescrição</li>
                      <li>Nome do medicamento, dosagem e posologia</li>
                      <li>Assinatura do médico</li>
                    </ul>
                  </AlertDescription>
                </Alert>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full" 
                  onClick={handleSubmit}
                  disabled={submitting || fileUploading}
                >
                  {submitting ? (
                    <>
                      <Spinner size="small" className="mr-2" />
                      Enviando prescrição...
                    </>
                  ) : (
                    "Enviar para análise"
                  )}
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Processo de Aprovação</CardTitle>
                <CardDescription>
                  Etapas para aprovação da sua prescrição
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-full">
                      <Upload className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">1. Envio da Prescrição</h3>
                      <p className="text-sm text-gray-500">
                        Envie uma imagem clara ou PDF da sua prescrição médica.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="bg-yellow-100 p-2 rounded-full">
                      <Clock className="h-5 w-5 text-yellow-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">2. Aguarde a Análise</h3>
                      <p className="text-sm text-gray-500">
                        Nossa equipe farmacêutica irá analisar sua prescrição em até 24 horas úteis.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="bg-green-100 p-2 rounded-full">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">3. Aprovação</h3>
                      <p className="text-sm text-gray-500">
                        Após aprovada, você será notificado e poderá prosseguir com seu pedido.
                      </p>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="font-medium mb-2">Tempo médio de análise</h3>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-2 text-gray-400" />
                      De 2 a 24 horas úteis
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="mt-0">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Prescrições</CardTitle>
              <CardDescription>
                Visualize e acompanhe o status das suas prescrições enviadas
              </CardDescription>
            </CardHeader>
            <CardContent>
              {recentPrescriptions.length === 0 ? (
                <div className="text-center py-10">
                  <FileText className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">Nenhuma prescrição encontrada</h3>
                  <p className="text-gray-500 mt-1 max-w-md mx-auto">
                    Você ainda não enviou nenhuma prescrição. Clique em "Enviar Nova Prescrição" para começar.
                  </p>
                  <Button 
                    className="mt-4"
                    onClick={() => setViewMode('upload')}
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Enviar Prescrição
                  </Button>
                </div>
              ) : (
                <div className="space-y-6">
                  {recentPrescriptions.map((prescription, index) => (
                    <div key={prescription.id} className="border rounded-lg overflow-hidden">
                      <div className="bg-gray-50 p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-gray-500" />
                            <span className="text-sm text-gray-500">Enviada em {formatDateTime(prescription.data_envio)}</span>
                          </div>
                          <div className="mt-1 flex items-center gap-2">
                            {getStatusBadge(prescription.status)}
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          asChild
                          className="self-start"
                        >
                          <a href={prescription.arquivo_url} target="_blank" rel="noopener noreferrer">
                            <FileText className="mr-2 h-4 w-4" />
                            Ver Prescrição
                          </a>
                        </Button>
                      </div>
                      
                      <div className="p-4">
                        {prescription.status === 'pendente' && (
                          <Alert className="mb-4 bg-yellow-50 border-yellow-200">
                            <Clock className="h-4 w-4 text-yellow-600" />
                            <AlertTitle className="text-yellow-800">Aguardando análise</AlertTitle>
                            <AlertDescription className="text-yellow-700">
                              Sua prescrição está na fila para análise farmacêutica. Você receberá uma notificação quando for analisada.
                            </AlertDescription>
                          </Alert>
                        )}
                        
                        {prescription.status === 'aprovada' && (
                          <div className="space-y-4">
                            <Alert className="bg-green-50 border-green-200">
                              <CheckCircle className="h-4 w-4 text-green-600" />
                              <AlertTitle className="text-green-800">Prescrição aprovada</AlertTitle>
                              <AlertDescription className="text-green-700">
                                Sua prescrição foi analisada e aprovada por nossa equipe farmacêutica em {formatDateTime(prescription.data_analise)}.
                              </AlertDescription>
                            </Alert>
                            
                            {prescription.produtos_prescritos && (
                              <div>
                                <Label className="text-sm font-medium">Produtos Identificados</Label>
                                <div className="mt-2 space-y-2">
                                  {prescription.produtos_prescritos.map((produto, idx) => (
                                    <div key={idx} className="bg-gray-50 p-3 rounded-md">
                                      <p className="font-medium">{produto.nome}</p>
                                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-1">
                                        <p className="text-sm">Dosagem: {produto.dosagem}</p>
                                        <p className="text-sm">Quantidade: {produto.quantidade}</p>
                                      </div>
                                      <p className="text-sm mt-1">Posologia: {produto.posologia}</p>
                                    </div>
                                  ))}
                                </div>
                                
                                <div className="mt-4 flex items-center justify-between">
                                  <div className="flex items-center">
                                    <Calendar className="h-4 w-4 text-gray-500 mr-2" />
                                    <span className="text-sm">
                                      Válida até: <span className="font-medium">{formatDate(prescription.validade_prescricao)}</span>
                                    </span>
                                  </div>
                                  <Button variant="outline" size="sm">
                                    Fazer Pedido
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                        
                        {prescription.status === 'rejeitada' && (
                          <div>
                            <Alert className="bg-red-50 border-red-200">
                              <AlertCircle className="h-4 w-4 text-red-600" />
                              <AlertTitle className="text-red-800">Prescrição rejeitada</AlertTitle>
                              <AlertDescription className="text-red-700">
                                Sua prescrição não pôde ser aprovada. Por favor, verifique o motivo abaixo e envie uma nova prescrição.
                              </AlertDescription>
                            </Alert>
                            
                            <div className="mt-4">
                              <Label className="text-sm font-medium">Motivo da rejeição</Label>
                              <div className="p-3 bg-gray-50 rounded-md mt-1 text-sm">
                                {prescription.motivo_rejeicao}
                              </div>
                            </div>
                            
                            <div className="mt-4 flex justify-end">
                              <Button onClick={() => setViewMode('upload')}>
                                <Upload className="mr-2 h-4 w-4" />
                                Enviar Nova Prescrição
                              </Button>
                            </div>
                          </div>
                        )}
                        
                        {prescription.status === 'solicitado_alteracao' && (
                          <div>
                            <Alert className="bg-blue-50 border-blue-200">
                              <Info className="h-4 w-4 text-blue-600" />
                              <AlertTitle className="text-blue-800">Alterações solicitadas</AlertTitle>
                              <AlertDescription className="text-blue-700">
                                Nossa equipe farmacêutica solicitou algumas alterações em sua prescrição.
                              </AlertDescription>
                            </Alert>
                            
                            <div className="mt-4">
                              <Label className="text-sm font-medium">Alterações necessárias</Label>
                              <div className="p-3 bg-gray-50 rounded-md mt-1 text-sm">
                                {prescription.alteracoes_solicitadas}
                              </div>
                            </div>
                            
                            <div className="mt-4 flex justify-end">
                              <Button onClick={() => setViewMode('upload')}>
                                <Upload className="mr-2 h-4 w-4" />
                                Enviar Prescrição Atualizada
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            {recentPrescriptions.length > 0 && (
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setViewMode('upload')}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Enviar Nova Prescrição
                </Button>
              </CardFooter>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}