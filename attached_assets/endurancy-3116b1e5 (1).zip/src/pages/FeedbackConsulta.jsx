import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { FeedbackConsulta } from '@/api/entities';
import { ConsultaMedica } from '@/api/entities';
import { User } from '@/api/entities';
import { FeedbackConsultaForm } from '@/components/telemedicina/FeedbackConsultaForm';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { Star, ThumbsUp, MessageSquare, Calendar, Clock, User as UserIcon, Video, Send, ArrowLeft } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function FeedbackConsultaPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);
  const consultaId = urlParams.get('id');
  
  const [loading, setLoading] = useState(true);
  const [consulta, setConsulta] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadCurrentUser();
    loadConsultaData();
  }, [consultaId]);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Erro ao carregar dados do usuário:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar seus dados. Por favor, tente novamente mais tarde.",
        variant: "destructive"
      });
    }
  };

  const loadConsultaData = async () => {
    setLoading(true);
    try {
      if (!consultaId) {
        throw new Error("ID da consulta não fornecido");
      }

      // Substituir pelo código real quando a entidade e API estiverem prontas
      // const consultaData = await ConsultaMedica.get(consultaId);
      
      // Dados simulados
      setTimeout(() => {
        const consultaData = {
          id: consultaId,
          tipo_consulta: "telemedicina",
          data_hora: "2023-11-15T14:30:00Z",
          medico_id: "med123",
          medico_nome: "Dr. Carlos Oliveira",
          medico_especialidade: "Neurologia",
          duracao: 30,
          status: "realizada"
        };
        
        setConsulta(consultaData);
        
        // Verificar se já existe feedback para esta consulta
        checkExistingFeedback(consultaData.id);
        
        setLoading(false);
      }, 1000);
      
    } catch (error) {
      console.error("Erro ao carregar dados da consulta:", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os dados da consulta. Por favor, tente novamente mais tarde.",
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  const checkExistingFeedback = async (consultaId) => {
    try {
      // Substituir pelo código real quando a entidade e API estiverem prontas
      // const feedbacks = await FeedbackConsulta.filter({ consulta_id: consultaId });
      // if (feedbacks && feedbacks.length > 0) {
      //   setSubmitted(true);
      // }
      
      // Simulação apenas
      const mockSubmitted = Math.random() > 0.7; // 30% de chance de já ter sido enviado
      setSubmitted(mockSubmitted);
    } catch (error) {
      console.error("Erro ao verificar feedback existente:", error);
    }
  };

  const handleFeedbackSubmit = async (feedbackData) => {
    setSubmitting(true);
    try {
      // Adicionar campos necessários
      const completeData = {
        ...feedbackData,
        organization_id: consulta?.organization_id || currentUser?.organization_id,
        paciente_id: currentUser?.id,
        medico_id: consulta?.medico_id
      };
      
      // Simular envio
      await new Promise(resolve => setTimeout(resolve, 1500));
      // await FeedbackConsulta.create(completeData);
      
      setSubmitted(true);
      toast({
        title: "Feedback enviado",
        description: "Obrigado por compartilhar sua avaliação! Sua opinião é muito importante para melhorarmos nosso serviço.",
      });
    } catch (error) {
      console.error("Erro ao enviar feedback:", error);
      toast({
        title: "Erro",
        description: "Não foi possível enviar seu feedback. Por favor, tente novamente mais tarde.",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = () => {
    navigate(-1);
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <Spinner className="w-10 h-10 mb-4" />
        <p className="text-gray-500">Carregando dados da consulta...</p>
      </div>
    );
  }

  if (!consulta) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Consulta não encontrada</h2>
          <p className="text-gray-500 mb-4">Não foi possível encontrar os dados da consulta solicitada.</p>
          <Button onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="container mx-auto max-w-3xl py-8 px-4">
        <Card className="text-center">
          <CardHeader>
            <div className="flex justify-center mb-4">
              <div className="bg-green-100 p-3 rounded-full">
                <ThumbsUp className="h-8 w-8 text-green-600" />
              </div>
            </div>
            <CardTitle className="text-2xl">Feedback enviado com sucesso!</CardTitle>
            <CardDescription>
              Agradecemos por compartilhar sua experiência e ajudar a melhorar nosso serviço.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6 pb-2">
            <p className="text-gray-500 mb-6">
              Sua avaliação será analisada por nossa equipe e contribuirá para aprimorarmos continuamente o atendimento.
            </p>
            
            <div className="flex flex-col items-center space-y-2">
              <div className="flex items-center text-gray-700">
                <Calendar className="w-4 h-4 mr-2" />
                <span>Consulta realizada em {format(parseISO(consulta.data_hora), "dd 'de'  MMMM 'de' yyyy", { locale: ptBR })}</span>
              </div>
              <div className="flex items-center text-gray-700">
                <UserIcon className="w-4 h-4 mr-2" />
                <span>Médico: {consulta.medico_nome}</span>
              </div>
              <div className="flex items-center text-gray-700">
                <Video className="w-4 h-4 mr-2" />
                <span>Tipo: {consulta.tipo_consulta === "telemedicina" ? "Telemedicina" : "Presencial"}</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-center pt-2 pb-6">
            <Button onClick={() => navigate(createPageUrl("ConsultasMedicas"))}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para consultas
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-3xl py-8 px-4">
      <Button variant="outline" className="mb-6" onClick={() => navigate(-1)}>
        <ArrowLeft className="w-4 h-4 mr-2" />
        Voltar
      </Button>
      
      <FeedbackConsultaForm
        consulta={consulta}
        onSubmit={handleFeedbackSubmit}
        onCancel={handleCancel}
      />
    </div>
  );
}