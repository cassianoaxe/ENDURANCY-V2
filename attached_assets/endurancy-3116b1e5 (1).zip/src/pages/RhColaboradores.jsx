import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  User, 
  Search, 
  Filter, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Users, 
  Briefcase, 
  FileText, 
  Edit, 
  Trash, 
  Plus, 
  MoreHorizontal, 
  Building, 
  MapPin, 
  Phone, 
  Mail, 
  UserPlus, 
  UserMinus, 
  FileCheck, 
  FileX, 
  UserCog, 
  Tag,
  Shield,
  CalendarDays,
  Clock3,
  GraduationCap,
  Award,
  DollarSign,
  CreditCard,
  BadgeCheck
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Dados simulados de colaboradores
const mockColaboradores = [
  {
    id: "col-001",
    nome: "Maria Silva",
    cargo: "Farmacêutica Responsável Técnica",
    departamento: "Produção",
    avatar: "MS",
    email: "maria.silva@exemplo.com",
    telefone: "(11) 99876-5432",
    status: "ativo",
    dataAdmissao: "2021-03-15",
    dataFim: null,
    tipoContrato: "CLT",
    endereco: "Av. Paulista, 123 - São Paulo, SP",
    documentos: {
      cpf: "123.456.789-00",
      rg: "12.345.678-9",
      cnh: null,
      carteiraProfissional: "12345/SP",
      conselhoRegional: "CRF-SP 12345"
    },
    formacao: [
      {
        curso: "Farmácia",
        instituicao: "Universidade de São Paulo",
        nivel: "Graduação",
        dataInicio: "2013-02-01",
        dataFim: "2017-12-15"
      },
      {
        curso: "Farmacologia Clínica",
        instituicao: "Universidade Federal de São Paulo",
        nivel: "Especialização",
        dataInicio: "2018-03-01",
        dataFim: "2019-12-10"
      }
    ],
    certificacoes: [
      {
        titulo: "Boas Práticas de Fabricação de Medicamentos",
        emissor: "ANVISA",
        dataEmissao: "2020-05-10",
        dataValidade: "2025-05-10"
      }
    ],
    frequencia: {
      faltas: 2,
      atrasos: 5,
      horasExtras: 12
    },
    feriasAgendadas: [
      {
        dataInicio: "2023-12-20",
        dataFim: "2024-01-08",
        status: "aprovado"
      }
    ],
    ultimaAvaliacao: {
      data: "2023-04-15",
      pontuacao: 92,
      feedback: "Excelente desempenho técnico e comprometimento com a qualidade dos produtos."
    }
  },
  {
    id: "col-002",
    nome: "Carlos Oliveira",
    cargo: "Analista de Controle de Qualidade",
    departamento: "Qualidade",
    avatar: "CO",
    email: "carlos.oliveira@exemplo.com",
    telefone: "(11) 98765-4321",
    status: "ativo",
    dataAdmissao: "2022-01-10",
    dataFim: null,
    tipoContrato: "CLT",
    endereco: "Rua Augusta, 456 - São Paulo, SP",
    documentos: {
      cpf: "987.654.321-00",
      rg: "98.765.432-1",
      cnh: "12345678900",
      carteiraProfissional: "54321/SP",
      conselhoRegional: null
    },
    formacao: [
      {
        curso: "Química",
        instituicao: "Universidade Estadual de Campinas",
        nivel: "Graduação",
        dataInicio: "2015-02-01",
        dataFim: "2019-12-15"
      }
    ],
    certificacoes: [
      {
        titulo: "Análises Cromatográficas",
        emissor: "Instituto de Química - UNICAMP",
        dataEmissao: "2020-03-20",
        dataValidade: null
      }
    ],
    frequencia: {
      faltas: 0,
      atrasos: 3,
      horasExtras: 8
    },
    feriasAgendadas: [],
    ultimaAvaliacao: {
      data: "2023-04-10",
      pontuacao: 85,
      feedback: "Bom desempenho técnico. Precisa melhorar a comunicação com outros departamentos."
    }
  },
  {
    id: "col-003",
    nome: "Pedro Santos",
    cargo: "Especialista em Cultivo",
    departamento: "Cultivo",
    avatar: "PS",
    email: "pedro.santos@exemplo.com",
    telefone: "(19) 98765-1234",
    status: "ativo",
    dataAdmissao: "2021-08-15",
    dataFim: null,
    tipoContrato: "CLT",
    endereco: "Estrada Rural, Km 5 - Interior de SP",
    documentos: {
      cpf: "456.789.123-00",
      rg: "45.678.912-3",
      cnh: "98765432100",
      carteiraProfissional: "56789/SP",
      conselhoRegional: "CREA-SP 12345"
    },
    formacao: [
      {
        curso: "Agronomia",
        instituicao: "ESALQ - USP",
        nivel: "Graduação",
        dataInicio: "2012-02-01",
        dataFim: "2016-12-15"
      },
      {
        curso: "Fitotecnia",
        instituicao: "ESALQ - USP",
        nivel: "Mestrado",
        dataInicio: "2017-03-01",
        dataFim: "2019-02-28"
      }
    ],
    certificacoes: [
      {
        titulo: "Cultivo de Cannabis Medicinal",
        emissor: "Cannabis Training University",
        dataEmissao: "2020-07-15",
        dataValidade: null
      }
    ],
    frequencia: {
      faltas: 1,
      atrasos: 2,
      horasExtras: 20
    },
    feriasAgendadas: [
      {
        dataInicio: "2023-08-01",
        dataFim: "2023-08-15",
        status: "aprovado"
      }
    ],
    ultimaAvaliacao: {
      data: "2023-04-20",
      pontuacao: 95,
      feedback: "Excelente conhecimento técnico e dedicação. Contribui significativamente para a qualidade das culturas."
    }
  },
  {
    id: "col-004",
    nome: "Ana Souza",
    cargo: "Gerente de Marketing",
    departamento: "Marketing",
    avatar: "AS",
    email: "ana.souza@exemplo.com",
    telefone: "(11) 97654-3210",
    status: "ativo",
    dataAdmissao: "2022-03-01",
    dataFim: null,
    tipoContrato: "CLT",
    endereco: "Rua Haddock Lobo, 789 - São Paulo, SP",
    documentos: {
      cpf: "789.123.456-00",
      rg: "78.912.345-6",
      cnh: "45678912300",
      carteiraProfissional: "98765/SP",
      conselhoRegional: null
    },
    formacao: [
      {
        curso: "Marketing",
        instituicao: "ESPM",
        nivel: "Graduação",
        dataInicio: "2014-02-01",
        dataFim: "2017-12-15"
      },
      {
        curso: "MBA em Marketing Digital",
        instituicao: "FGV",
        nivel: "Especialização",
        dataInicio: "2018-03-01",
        dataFim: "2019-12-10"
      }
    ],
    certificacoes: [
      {
        titulo: "Google Ads",
        emissor: "Google",
        dataEmissao: "2021-05-10",
        dataValidade: "2023-05-10"
      }
    ],
    frequencia: {
      faltas: 0,
      atrasos: 1,
      horasExtras: 15
    },
    feriasAgendadas: [],
    ultimaAvaliacao: {
      data: "2023-04-05",
      pontuacao: 88,
      feedback: "Ótimo desempenho com as campanhas digitais. Foco em melhorar o relacionamento com a equipe de vendas."
    }
  },
  {
    id: "col-005",
    nome: "Roberto Lima",
    cargo: "Pesquisador",
    departamento: "P&D",
    avatar: "RL",
    email: "roberto.lima@exemplo.com",
    telefone: "(11) 91234-5678",
    status: "ativo",
    dataAdmissao: "2021-06-15",
    dataFim: null,
    tipoContrato: "CLT",
    endereco: "Rua dos Pinheiros, 1000 - São Paulo, SP",
    documentos: {
      cpf: "234.567.891-00",
      rg: "23.456.789-1",
      cnh: null,
      carteiraProfissional: "34567/SP",
      conselhoRegional: null
    },
    formacao: [
      {
        curso: "Bioquímica",
        instituicao: "Universidade de São Paulo",
        nivel: "Graduação",
        dataInicio: "2010-02-01",
        dataFim: "2014-12-15"
      },
      {
        curso: "Farmacologia",
        instituicao: "Universidade de São Paulo",
        nivel: "Doutorado",
        dataInicio: "2015-03-01",
        dataFim: "2019-03-01"
      }
    ],
    certificacoes: [],
    frequencia: {
      faltas: 3,
      atrasos: 7,
      horasExtras: 5
    },
    feriasAgendadas: [
      {
        dataInicio: "2023-09-10",
        dataFim: "2023-09-30",
        status: "pendente"
      }
    ],
    ultimaAvaliacao: {
      data: "2023-04-12",
      pontuacao: 82,
      feedback: "Excelente capacidade técnica. Precisa melhorar pontualidade e organização das pesquisas."
    }
  }
];

export default function RhColaboradores() {
  const [colaboradores, setColaboradores] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDepartamento, setFilterDepartamento] = useState("todos");
  const [filterStatus, setFilterStatus] = useState("todos");
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [selectedColaborador, setSelectedColaborador] = useState(null);
  const [activeTab, setActiveTab] = useState("ativos");

  useEffect(() => {
    // Simular carregamento de dados
    setTimeout(() => {
      setColaboradores(mockColaboradores);
      setIsLoading(false);
    }, 1000);
  }, []);

  const handleViewDetail = (colaborador) => {
    setSelectedColaborador(colaborador);
    setShowDetailDialog(true);
  };

  // Filtrar colaboradores
  const filteredColaboradores = colaboradores.filter(col => {
    // Filtro de texto
    const matchesSearch = col.nome.toLowerCase().includes(searchTerm.toLowerCase()) || 
                        col.cargo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        col.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filtro de departamento
    const matchesDepartamento = filterDepartamento === "todos" || col.departamento === filterDepartamento;
    
    // Filtro de status
    const matchesStatus = filterStatus === "todos" || col.status === filterStatus;
    
    // Filtro de aba (ativos/inativos)
    const matchesTab = (activeTab === "ativos" && col.status === "ativo") || 
                      (activeTab === "inativos" && col.status === "inativo");
    
    return matchesSearch && matchesDepartamento && matchesStatus && matchesTab;
  });

  // Lista única de departamentos para o filtro
  const departamentos = ["todos", ...new Set(colaboradores.map(col => col.departamento))];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Colaboradores</h1>
          <p className="text-gray-500 mt-1">
            Gerencie os colaboradores da sua organização
          </p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">
          <UserPlus className="mr-2 h-4 w-4" />
          Adicionar Colaborador
        </Button>
      </div>

      <Tabs defaultValue="ativos" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="ativos">Ativos</TabsTrigger>
          <TabsTrigger value="inativos">Inativos</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row gap-4 sm:items-center justify-between">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar colaboradores..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={filterDepartamento} onValueChange={setFilterDepartamento}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Departamento" />
                </SelectTrigger>
                <SelectContent>
                  {departamentos.map((dep) => (
                    <SelectItem key={dep} value={dep}>
                      {dep === "todos" ? "Todos departamentos" : dep}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos status</SelectItem>
                  <SelectItem value="ativo">Ativos</SelectItem>
                  <SelectItem value="inativo">Inativos</SelectItem>
                  <SelectItem value="ferias">Em férias</SelectItem>
                  <SelectItem value="licenca">Em licença</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
            </div>
          ) : filteredColaboradores.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Colaborador</TableHead>
                    <TableHead>Cargo</TableHead>
                    <TableHead>Departamento</TableHead>
                    <TableHead>Contato</TableHead>
                    <TableHead>Data de Admissão</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredColaboradores.map((colaborador) => (
                    <TableRow key={colaborador.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback className="bg-green-100 text-green-800">
                              {colaborador.avatar}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{colaborador.nome}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{colaborador.cargo}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{colaborador.departamento}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="text-sm flex items-center">
                            <Mail className="h-3.5 w-3.5 mr-1" />
                            {colaborador.email}
                          </span>
                          <span className="text-sm flex items-center text-gray-500">
                            <Phone className="h-3.5 w-3.5 mr-1" />
                            {colaborador.telefone}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>{new Date(colaborador.dataAdmissao).toLocaleDateString('pt-BR')}</TableCell>
                      <TableCell>
                        <Badge className={
                          colaborador.status === 'ativo' ? 'bg-green-100 text-green-800' : 
                          colaborador.status === 'inativo' ? 'bg-red-100 text-red-800' :
                          colaborador.status === 'ferias' ? 'bg-blue-100 text-blue-800' :
                          'bg-yellow-100 text-yellow-800'
                        }>
                          {colaborador.status === 'ativo' ? 'Ativo' : 
                           colaborador.status === 'inativo' ? 'Inativo' :
                           colaborador.status === 'ferias' ? 'Em férias' : 'Em licença'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <span className="sr-only">Abrir menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewDetail(colaborador)}>
                              <User className="mr-2 h-4 w-4" />
                              Ver detalhes
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <FileText className="mr-2 h-4 w-4" />
                              Documentos
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Calendar className="mr-2 h-4 w-4" />
                              Gerenciar férias
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600">
                              <UserMinus className="mr-2 h-4 w-4" />
                              Desligar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-10">
              <Users className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-medium">Nenhum colaborador encontrado</h3>
              <p className="text-gray-500 mt-1">
                Tente ajustar os filtros ou adicione novos colaboradores.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Diálogo de detalhes do colaborador */}
      {selectedColaborador && (
        <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Detalhes do Colaborador</DialogTitle>
              <DialogDescription>
                Informações completas de {selectedColaborador.nome}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Coluna 1: Informações principais */}
              <div className="space-y-6">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-24 w-24 mb-3">
                    <AvatarFallback className="text-xl bg-green-100 text-green-800">
                      {selectedColaborador.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-xl font-bold">{selectedColaborador.nome}</h3>
                  <p className="text-gray-500">{selectedColaborador.cargo}</p>
                  <Badge className="mt-2">{selectedColaborador.departamento}</Badge>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">CONTATO</h4>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Mail className="h-4 w-4 mr-3 text-gray-500" />
                      <span>{selectedColaborador.email}</span>
                    </div>
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 mr-3 text-gray-500" />
                      <span>{selectedColaborador.telefone}</span>
                    </div>
                    <div className="flex items-start">
                      <MapPin className="h-4 w-4 mr-3 mt-1 text-gray-500" />
                      <span>{selectedColaborador.endereco}</span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">DOCUMENTOS</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">CPF:</span>
                      <span>{selectedColaborador.documentos.cpf}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">RG:</span>
                      <span>{selectedColaborador.documentos.rg}</span>
                    </div>
                    {selectedColaborador.documentos.cnh && (
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">CNH:</span>
                        <span>{selectedColaborador.documentos.cnh}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">CTPS:</span>
                      <span>{selectedColaborador.documentos.carteiraProfissional}</span>
                    </div>
                    {selectedColaborador.documentos.conselhoRegional && (
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Conselho:</span>
                        <span>{selectedColaborador.documentos.conselhoRegional}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              {/* Coluna 2: Carreira e Formação */}
              <div className="space-y-6">
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">CARREIRA</h4>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <CalendarDays className="h-4 w-4 mr-3 text-gray-500" />
                      <span>
                        Admissão: {new Date(selectedColaborador.dataAdmissao).toLocaleDateString('pt-BR')}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Briefcase className="h-4 w-4 mr-3 text-gray-500" />
                      <span>Contrato: {selectedColaborador.tipoContrato}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock3 className="h-4 w-4 mr-3 text-gray-500" />
                      <span>
                        Tempo de casa: {calculateTimeInCompany(selectedColaborador.dataAdmissao)}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <BadgeCheck className="h-4 w-4 mr-3 text-gray-500" />
                      <span>Status: {selectedColaborador.status}</span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">FORMAÇÃO ACADÊMICA</h4>
                  {selectedColaborador.formacao.map((form, index) => (
                    <Card key={index} className="p-3">
                      <div className="flex justify-between">
                        <div>
                          <div className="font-medium">{form.curso}</div>
                          <div className="text-sm text-gray-500">{form.instituicao}</div>
                        </div>
                        <Badge variant="outline">{form.nivel}</Badge>
                      </div>
                      <div className="text-sm text-gray-500 mt-1">
                        {new Date(form.dataInicio).getFullYear()} - {form.dataFim ? new Date(form.dataFim).getFullYear() : 'Atual'}
                      </div>
                    </Card>
                  ))}
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">CERTIFICAÇÕES</h4>
                  {selectedColaborador.certificacoes.length > 0 ? (
                    selectedColaborador.certificacoes.map((cert, index) => (
                      <Card key={index} className="p-3">
                        <div className="font-medium">{cert.titulo}</div>
                        <div className="text-sm text-gray-500">{cert.emissor}</div>
                        <div className="text-sm text-gray-500 mt-1">
                          Emissão: {new Date(cert.dataEmissao).toLocaleDateString('pt-BR')}
                          {cert.dataValidade && (
                            <span> • Validade: {new Date(cert.dataValidade).toLocaleDateString('pt-BR')}</span>
                          )}
                        </div>
                      </Card>
                    ))
                  ) : (
                    <p className="text-sm text-gray-500">Nenhuma certificação registrada.</p>
                  )}
                </div>
              </div>
              
              {/* Coluna 3: Métricas e Avaliações */}
              <div className="space-y-6">
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">ÚLTIMA AVALIAÇÃO</h4>
                  {selectedColaborador.ultimaAvaliacao ? (
                    <Card className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <div className="text-sm text-gray-500">
                          {new Date(selectedColaborador.ultimaAvaliacao.data).toLocaleDateString('pt-BR')}
                        </div>
                        <Badge 
                          className={
                            selectedColaborador.ultimaAvaliacao.pontuacao >= 90 ? 'bg-green-100 text-green-800' :
                            selectedColaborador.ultimaAvaliacao.pontuacao >= 70 ? 'bg-blue-100 text-blue-800' :
                            selectedColaborador.ultimaAvaliacao.pontuacao >= 50 ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }
                        >
                          {selectedColaborador.ultimaAvaliacao.pontuacao}/100
                        </Badge>
                      </div>
                      <div className="space-y-2">
                        <Progress 
                          value={selectedColaborador.ultimaAvaliacao.pontuacao} 
                          className="h-2"
                        />
                        <p className="text-sm">{selectedColaborador.ultimaAvaliacao.feedback}</p>
                      </div>
                    </Card>
                  ) : (
                    <p className="text-sm text-gray-500">Nenhuma avaliação registrada.</p>
                  )}
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">FREQUÊNCIA (ÚLTIMO MÊS)</h4>
                  <div className="grid grid-cols-3 gap-3">
                    <Card className="p-3 text-center">
                      <div className="text-2xl font-bold">{selectedColaborador.frequencia.faltas}</div>
                      <div className="text-sm text-gray-500">Faltas</div>
                    </Card>
                    <Card className="p-3 text-center">
                      <div className="text-2xl font-bold">{selectedColaborador.frequencia.atrasos}</div>
                      <div className="text-sm text-gray-500">Atrasos</div>
                    </Card>
                    <Card className="p-3 text-center">
                      <div className="text-2xl font-bold">{selectedColaborador.frequencia.horasExtras}</div>
                      <div className="text-sm text-gray-500">Horas extras</div>
                    </Card>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">FÉRIAS</h4>
                  {selectedColaborador.feriasAgendadas.length > 0 ? (
                    selectedColaborador.feriasAgendadas.map((ferias, index) => (
                      <Card key={index} className="p-3">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="font-medium">
                              {new Date(ferias.dataInicio).toLocaleDateString('pt-BR')} - {new Date(ferias.dataFim).toLocaleDateString('pt-BR')}
                            </div>
                            <div className="text-sm text-gray-500">
                              {calculateDateDifference(ferias.dataInicio, ferias.dataFim)} dias
                            </div>
                          </div>
                          <Badge 
                            className={
                              ferias.status === 'aprovado' ? 'bg-green-100 text-green-800' :
                              ferias.status === 'pendente' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }
                          >
                            {ferias.status === 'aprovado' ? 'Aprovado' :
                             ferias.status === 'pendente' ? 'Pendente' : 'Negado'}
                          </Badge>
                        </div>
                      </Card>
                    ))
                  ) : (
                    <p className="text-sm text-gray-500">Nenhum período de férias agendado.</p>
                  )}
                </div>
              </div>
            </div>
              
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDetailDialog(false)}>
                Fechar
              </Button>
              <Button>Editar Colaborador</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// Funções utilitárias
function calculateTimeInCompany(admissionDate) {
  const start = new Date(admissionDate);
  const now = new Date();
  
  const yearDiff = now.getFullYear() - start.getFullYear();
  const monthDiff = now.getMonth() - start.getMonth();
  
  if (yearDiff > 0) {
    return yearDiff + (yearDiff === 1 ? ' ano' : ' anos');
  } else if (monthDiff > 0) {
    return monthDiff + (monthDiff === 1 ? ' mês' : ' meses');
  } else {
    const dayDiff = Math.floor((now - start) / (1000 * 60 * 60 * 24));
    return dayDiff + (dayDiff === 1 ? ' dia' : ' dias');
  }
}

function calculateDateDifference(startDate, endDate) {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const diffTime = Math.abs(end - start);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; // +1 para incluir o dia final
  return diffDays;
}