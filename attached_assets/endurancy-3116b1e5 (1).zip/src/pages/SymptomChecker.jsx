import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { User } from '@/api/entities';
import { InvokeLLM } from "@/api/integrations";
import { 
  LayoutDashboard, Video, Users, ClipboardList, Brain, DollarSign, 
  Settings, LogOut, Menu, X, Bell, Search, Filter, Plus, MoreHorizontal,
  FileText, Calendar, Phone, Mail, Eye, Pencil, Trash2, ClipboardCheck,
  ChevronLeft, ChevronRight, Download, Upload, FileUp, MessageSquare,
  UserPlus, SlidersHorizontal, ArrowUpDown, CheckCircle, XCircle, AlertTriangle,
  Pill, Stethoscope, Activity, Database, Send, List, BarChart, Calculator,
  FileQuestion, ScrollText, ArrowRight, BookOpen, LucideArrowDownCircle,
  ThumbsUp, ThumbsDown, ChevronDown, HelpCircle, Share2, History, LayoutList,
  BadgePlus, Sparkles
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Spinner } from "@/components/ui/spinner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function SymptomChecker() {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isAiAnalysisLoading, setIsAiAnalysisLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('symptom-checker');
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showPatientSelector, setShowPatientSelector] = useState(false);
  
  // Patient data
  const [patients, setPatients] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredPatients, setFilteredPatients] = useState([]);
  
  // Symptom checker data
  const [symptoms, setSymptoms] = useState([]);
  const [userResponses, setUserResponses] = useState({});
  const [currentSymptomIndex, setCurrentSymptomIndex] = useState(0);
  const [aiAnalysisResult, setAiAnalysisResult] = useState(null);
  const [patientData, setPatientData] = useState({
    age: '',
    gender: '',
    weight: '',
    height: '',
    currentMedications: '',
    existingConditions: '',
    allergies: '',
    additionalNotes: ''
  });
  
  // Patient analytics
  const [patientSymptomHistory, setPatientSymptomHistory] = useState([]);
  const [patientTreatmentHistory, setPatientTreatmentHistory] = useState([]);
  
  // Common symptoms list for the checker
  const commonSymptoms = [
    { id: 'pain', question: "O paciente está sentindo dor?", type: "boolean" },
    { id: 'pain_location', question: "Onde está localizada a dor?", type: "multi-select", options: ["Cabeça", "Pescoço", "Peito", "Abdômen", "Costas", "Articulações", "Membros", "Generalizada"], dependsOn: { id: 'pain', value: true } },
    { id: 'pain_intensity', question: "Qual a intensidade da dor (1-10)?", type: "scale", min: 1, max: 10, dependsOn: { id: 'pain', value: true } },
    { id: 'pain_duration', question: "Há quanto tempo a dor persiste?", type: "select", options: ["Menos de 24 horas", "1-3 dias", "3-7 dias", "1-2 semanas", "2-4 semanas", "Mais de 1 mês"], dependsOn: { id: 'pain', value: true } },
    { id: 'sleep', question: "O paciente está tendo problemas para dormir?", type: "boolean" },
    { id: 'sleep_issues', question: "Que tipo de problema de sono está enfrentando?", type: "multi-select", options: ["Dificuldade para adormecer", "Acordar durante a noite", "Acordar muito cedo", "Sono não reparador", "Pesadelos", "Sonolência diurna"], dependsOn: { id: 'sleep', value: true } },
    { id: 'anxiety', question: "O paciente está sentindo ansiedade?", type: "boolean" },
    { id: 'anxiety_triggers', question: "Há situações específicas que desencadeiam a ansiedade?", type: "text", dependsOn: { id: 'anxiety', value: true } },
    { id: 'mood', question: "Como está o humor do paciente nas últimas duas semanas?", type: "select", options: ["Normal", "Levemente deprimido", "Moderadamente deprimido", "Severamente deprimido", "Elevado/Eufórico", "Irritável", "Oscilante"] },
    { id: 'appetite', question: "Houve mudanças no apetite?", type: "select", options: ["Sem alterações", "Diminuído", "Aumentado"] },
    { id: 'weight_change', question: "Houve mudança de peso não intencional?", type: "select", options: ["Sem alterações", "Perda de peso", "Ganho de peso"] },
    { id: 'weight_amount', question: "Aproximadamente quanto de peso (em kg)?", type: "number", dependsOn: { id: 'weight_change', value: ["Perda de peso", "Ganho de peso"] } },
    { id: 'fatigue', question: "O paciente está sentindo fadiga ou cansaço?", type: "boolean" },
    { id: 'concentration', question: "Notou dificuldades de concentração ou memória?", type: "boolean" },
    { id: 'seizures', question: "O paciente teve convulsões?", type: "boolean" },
    { id: 'seizure_frequency', question: "Com que frequência ocorrem as convulsões?", type: "select", options: ["Raramente (1-2 por ano)", "Ocasionalmente (3-11 por ano)", "Frequentemente (1-4 por mês)", "Muito frequentemente (mais de 4 por mês)"], dependsOn: { id: 'seizures', value: true } },
    { id: 'nausea', question: "O paciente está sentindo náusea ou vômito?", type: "boolean" },
    { id: 'dizziness', question: "Está sentindo tontura?", type: "boolean" },
    { id: 'headache', question: "Está com dor de cabeça?", type: "boolean" },
    { id: 'headache_type', question: "Como é a dor de cabeça?", type: "select", options: ["Pulsátil", "Pressão/Aperto", "Em facada", "Generalizada"], dependsOn: { id: 'headache', value: true } },
    { id: 'treatment_history', question: "Quais tratamentos o paciente já tentou para esses sintomas?", type: "text" },
    { id: 'treatment_response', question: "Como foi a resposta aos tratamentos anteriores?", type: "select", options: ["Eficaz", "Parcialmente eficaz", "Ineficaz", "Agravou sintomas", "Não tentou tratamentos"] },
    { id: 'cbd_thc_experience', question: "O paciente já utilizou produtos com Cannabis (CBD/THC) antes?", type: "boolean" },
    { id: 'cbd_thc_response', question: "Como foi a resposta ao tratamento com Cannabis?", type: "select", options: ["Muito positiva", "Positiva", "Neutra", "Negativa", "Muito negativa"], dependsOn: { id: 'cbd_thc_experience', value: true } }
  ];

  // Initialize with a list of patients
  useEffect(() => {
    loadPatients();
  }, []);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredPatients(patients);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = patients.filter(
        patient => patient.fullName.toLowerCase().includes(query) || 
                   patient.id.toLowerCase().includes(query)
      );
      setFilteredPatients(filtered);
    }
  }, [searchQuery, patients]);

  // Initialize symptoms when tab changes
  useEffect(() => {
    if (activeTab === 'symptom-checker') {
      setSymptoms(commonSymptoms);
    }
  }, [activeTab]);

  const loadPatients = () => {
    // Simulated patient data
    const mockPatients = [
      {
        id: 'PAT001',
        fullName: 'Maria Oliveira',
        age: 39,
        gender: 'Feminino',
        conditions: ['Ansiedade', 'Insônia'],
        lastVisit: '2024-03-01',
        profileImage: null
      },
      {
        id: 'PAT002',
        fullName: 'João Santos',
        age: 51,
        gender: 'Masculino',
        conditions: ['Dor crônica', 'Hipertensão'],
        lastVisit: '2024-02-10',
        profileImage: null
      },
      {
        id: 'PAT003',
        fullName: 'Ana Pereira',
        age: 34,
        gender: 'Feminino',
        conditions: ['Epilepsia'],
        lastVisit: '2024-01-20',
        profileImage: null
      },
      {
        id: 'PAT004',
        fullName: 'Carlos Mendes',
        age: 58,
        gender: 'Masculino',
        conditions: ['Parkinson', 'Depressão'],
        lastVisit: '2023-12-15',
        profileImage: null
      },
      {
        id: 'PAT005',
        fullName: 'Paulo Silva',
        age: 36,
        gender: 'Masculino',
        conditions: ['TDAH', 'Ansiedade'],
        lastVisit: '2023-11-05',
        profileImage: null
      }
    ];
    
    setPatients(mockPatients);
    setFilteredPatients(mockPatients);
  };

  const loadPatientData = (patient) => {
    setSelectedPatient(patient);
    
    // Set basic patient data
    setPatientData({
      age: patient.age.toString(),
      gender: patient.gender === 'Masculino' ? 'male' : 'female',
      weight: '70',
      height: '170',
      currentMedications: 'Fluoxetina 20mg, CBD Oil 5%',
      existingConditions: patient.conditions.join(', '),
      allergies: 'Nenhuma conhecida',
      additionalNotes: ''
    });
    
    // Simulate loading patient symptom history
    const mockSymptomHistory = [
      {
        date: '2024-03-01',
        mainSymptoms: ['Insônia', 'Ansiedade moderada'],
        assessmentNotes: 'Paciente relatou dificuldade para iniciar o sono, despertares noturnos frequentes e ansiedade ao final do dia.',
        treatment: 'CBD Oil 5%, 1ml 2x ao dia'
      },
      {
        date: '2024-01-15',
        mainSymptoms: ['Insônia severa', 'Ansiedade elevada', 'Fadiga diurna'],
        assessmentNotes: 'Paciente com histórico de ansiedade generalizada há 5 anos, com piora dos sintomas nos últimos 3 meses.',
        treatment: 'Iniciado Fluoxetina 20mg 1x ao dia + encaminhamento para avaliação de terapia com CBD'
      }
    ];
    
    setPatientSymptomHistory(mockSymptomHistory);
    
    // Simulate loading patient treatment history
    const mockTreatmentHistory = [
      {
        period: 'Mar 2024 - Atual',
        medication: 'CBD Oil 5%',
        dosage: '1ml 2x ao dia',
        response: 'Melhora significativa no sono e redução da ansiedade',
        sideEffects: 'Sonolência leve na primeira semana',
        adherence: 'Boa'
      },
      {
        period: 'Jan 2024 - Atual',
        medication: 'Fluoxetina',
        dosage: '20mg 1x ao dia',
        response: 'Melhora parcial da ansiedade',
        sideEffects: 'Náusea inicial, boca seca',
        adherence: 'Regular'
      },
      {
        period: 'Out 2023 - Dez 2023',
        medication: 'Clonazepam',
        dosage: '0.5mg à noite',
        response: 'Melhora do sono, pouco efeito na ansiedade diurna',
        sideEffects: 'Sonolência diurna, dependência preocupante',
        adherence: 'Boa',
        discontinued: true,
        discontinueReason: 'Preocupação com dependência e efeitos colaterais'
      }
    ];
    
    setPatientTreatmentHistory(mockTreatmentHistory);
    
    setShowPatientSelector(false);
  };

  const isQuestionApplicable = (symptom) => {
    if (!symptom.dependsOn) return true;
    
    const { id, value } = symptom.dependsOn;
    const userResponse = userResponses[id];
    
    if (Array.isArray(value)) {
      return value.includes(userResponse);
    }
    
    return userResponse === value;
  };

  const getApplicableSymptoms = () => {
    return symptoms.filter(isQuestionApplicable);
  };

  const applicableSymptoms = getApplicableSymptoms();

  const handleNextSymptom = () => {
    if (currentSymptomIndex < applicableSymptoms.length - 1) {
      setCurrentSymptomIndex(currentSymptomIndex + 1);
    }
  };

  const handlePreviousSymptom = () => {
    if (currentSymptomIndex > 0) {
      setCurrentSymptomIndex(currentSymptomIndex - 1);
    }
  };

  const handleResponseChange = (symptomId, value) => {
    setUserResponses({
      ...userResponses,
      [symptomId]: value
    });
  };

  const resetChecker = () => {
    setUserResponses({});
    setCurrentSymptomIndex(0);
    setAiAnalysisResult(null);
  };

  const analyzeWithAI = async () => {
    if (!selectedPatient) {
      toast({
        title: "Nenhum paciente selecionado",
        description: "Por favor, selecione um paciente antes de realizar a análise.",
        variant: "destructive"
      });
      return;
    }
    
    setIsAiAnalysisLoading(true);
    
    try {
      // Prepare patient data
      const patientProfile = {
        name: selectedPatient.fullName,
        age: parseInt(patientData.age),
        gender: patientData.gender,
        weight: parseInt(patientData.weight),
        height: parseInt(patientData.height),
        currentMedications: patientData.currentMedications,
        existingConditions: patientData.existingConditions,
        allergies: patientData.allergies
      };
      
      // Prepare symptom data
      const symptomData = {};
      for (const symptom of symptoms) {
        if (userResponses[symptom.id] !== undefined) {
          symptomData[symptom.id] = userResponses[symptom.id];
        }
      }
      
      const promptData = {
        patientProfile,
        symptoms: symptomData,
        additionalNotes: patientData.additionalNotes
      };
      
      // Use the integration
      const results = await InvokeLLM({
        prompt: `
          Você é um assistente médico especializado em cannabis medicinal.
          
          Analise os dados do paciente e os sintomas reportados a seguir:
          
          DADOS DO PACIENTE:
          ${JSON.stringify(promptData.patientProfile, null, 2)}
          
          SINTOMAS REPORTADOS:
          ${JSON.stringify(promptData.symptoms, null, 2)}
          
          OBSERVAÇÕES ADICIONAIS:
          ${promptData.additionalNotes || "Nenhuma observação adicional."}
          
          Com base nos dados acima, forneça:
          1. Um resumo clínico conciso da condição do paciente
          2. Possíveis condições a serem consideradas, listadas em ordem de probabilidade
          3. Uma avaliação da adequação do tratamento com cannabis medicinal
          4. Recomendações de produtos específicos (CBD, THC ou combinações), incluindo dosagens iniciais sugeridas
          5. Potenciais interações medicamentosas ou preocupações, se houver
          6. Acompanhamento recomendado
          
          Seja detalhado e específico em sua análise. Forneça uma avaliação baseada em evidências científicas atuais sobre cannabis medicinal.
        `,
        response_json_schema: {
          type: "object",
          properties: {
            clinicalSummary: { type: "string" },
            possibleConditions: { 
              type: "array", 
              items: { 
                type: "object", 
                properties: {
                  condition: { type: "string" },
                  likelihood: { type: "string", enum: ["Alta", "Moderada", "Baixa"] },
                  reasoning: { type: "string" }
                }
              } 
            },
            cannabisTreatmentAssessment: {
              type: "object",
              properties: {
                suitability: { type: "string", enum: ["Alta", "Moderada", "Baixa", "Não recomendado"] },
                reasoning: { type: "string" }
              }
            },
            productRecommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  productType: { type: "string" },
                  ratio: { type: "string" },
                  dosage: { type: "string" },
                  frequency: { type: "string" },
                  administrationRoute: { type: "string" },
                  notes: { type: "string" }
                }
              }
            },
            potentialConcerns: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  concern: { type: "string" },
                  severity: { type: "string", enum: ["Alta", "Moderada", "Baixa"] },
                  recommendation: { type: "string" }
                }
              }
            },
            followUpRecommendations: {
              type: "object",
              properties: {
                timeframe: { type: "string" },
                assessmentFocus: { type: "array", items: { type: "string" } },
                additionalTests: { type: "array", items: { type: "string" } }
              }
            }
          }
        },
        add_context_from_internet: true
      });
      
      setAiAnalysisResult(results);
      
      // Save this analysis to patient history
      const newAnalysis = {
        date: new Date().toISOString().split('T')[0],
        mainSymptoms: Object.entries(symptomData)
          .filter(([key, value]) => value === true || (typeof value === 'string' && value.length > 0))
          .map(([key]) => {
            const symptom = symptoms.find(s => s.id === key);
            return symptom ? symptom.question.replace("O paciente está sentindo ", "").replace("?", "") : key;
          }),
        assessmentNotes: results.clinicalSummary,
        treatment: results.productRecommendations.map(rec => 
          `${rec.productType} ${rec.ratio ? `(${rec.ratio})` : ''}, ${rec.dosage} ${rec.frequency}`
        ).join('; ')
      };
      
      setPatientSymptomHistory([newAnalysis, ...patientSymptomHistory]);
      
    } catch (error) {
      console.error("Error analyzing symptoms with AI:", error);
      toast({
        title: "Erro na análise",
        description: "Ocorreu um erro ao analisar os sintomas. Por favor, tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsAiAnalysisLoading(false);
    }
  };

  const renderSymptomInput = (symptom) => {
    const { id, question, type, options, min, max } = symptom;
    
    switch (type) {
      case 'boolean':
        return (
          <RadioGroup
            value={userResponses[id]?.toString() || undefined}
            onValueChange={(value) => handleResponseChange(id, value === 'true')}
            className="flex space-x-4 mt-2"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="true" id={`${id}-yes`} />
              <Label htmlFor={`${id}-yes`}>Sim</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="false" id={`${id}-no`} />
              <Label htmlFor={`${id}-no`}>Não</Label>
            </div>
          </RadioGroup>
        );
      
      case 'select':
        return (
          <Select
            value={userResponses[id] || ''}
            onValueChange={(value) => handleResponseChange(id, value)}
          >
            <SelectTrigger className="mt-2">
              <SelectValue placeholder="Selecione uma opção" />
            </SelectTrigger>
            <SelectContent>
              {options.map((option) => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      
      case 'multi-select':
        return (
          <div className="grid grid-cols-2 gap-2 mt-2">
            {options.map((option) => (
              <div key={option} className="flex items-center space-x-2">
                <Checkbox
                  id={`${id}-${option}`}
                  checked={(userResponses[id] || []).includes(option)}
                  onCheckedChange={(checked) => {
                    const currentValue = userResponses[id] || [];
                    const newValue = checked
                      ? [...currentValue, option]
                      : currentValue.filter(val => val !== option);
                    handleResponseChange(id, newValue);
                  }}
                />
                <Label htmlFor={`${id}-${option}`}>{option}</Label>
              </div>
            ))}
          </div>
        );
      
      case 'scale':
        return (
          <div className="mt-4">
            <div className="flex justify-between mb-2">
              {Array.from({ length: max - min + 1 }, (_, i) => i + min).map((value) => (
                <div key={value} className="text-center">
                  <Button
                    variant={userResponses[id] === value ? "default" : "outline"}
                    className={`w-10 h-10 rounded-full ${userResponses[id] === value ? 'bg-purple-600' : ''}`}
                    onClick={() => handleResponseChange(id, value)}
                  >
                    {value}
                  </Button>
                </div>
              ))}
            </div>
            <div className="flex justify-between text-xs text-gray-500">
              <span>Leve</span>
              <span>Moderada</span>
              <span>Severa</span>
            </div>
          </div>
        );
      
      case 'text':
        return (
          <Textarea
            value={userResponses[id] || ''}
            onChange={(e) => handleResponseChange(id, e.target.value)}
            placeholder="Digite sua resposta..."
            className="mt-2"
          />
        );
      
      case 'number':
        return (
          <Input
            type="number"
            value={userResponses[id] || ''}
            onChange={(e) => handleResponseChange(id, parseFloat(e.target.value))}
            placeholder="Digite um valor..."
            className="mt-2"
          />
        );
      
      default:
        return null;
    }
  };

  const renderPreviousResults = () => {
    if (patientSymptomHistory.length === 0) {
      return (
        <div className="text-center p-6">
          <FileQuestion size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium mb-1">Sem histórico de análises</h3>
          <p className="text-gray-500">Este paciente ainda não possui análises de sintomas registradas.</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {patientSymptomHistory.map((analysis, index) => (
          <Card key={index}>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-base">Análise de {new Date(analysis.date).toLocaleDateString('pt-BR')}</CardTitle>
                  <CardDescription>
                    Sintomas: {analysis.mainSymptoms.join(', ')}
                  </CardDescription>
                </div>
                <Badge variant={index === 0 ? "default" : "outline"} className={index === 0 ? "bg-purple-600" : ""}>
                  {index === 0 ? "Mais recente" : "Histórico"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-sm mb-1">Avaliação</h4>
                  <p className="text-sm text-gray-600">{analysis.assessmentNotes}</p>
                </div>
                <div>
                  <h4 className="font-medium text-sm mb-1">Tratamento Recomendado</h4>
                  <p className="text-sm text-gray-600">{analysis.treatment}</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <div className="flex justify-end w-full">
                <Button variant="ghost" size="sm" className="text-purple-600">
                  <Eye size={16} className="mr-2" />
                  Ver detalhes
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    );
  };

  const renderTreatmentHistory = () => {
    if (patientTreatmentHistory.length === 0) {
      return (
        <div className="text-center p-6">
          <FileText size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium mb-1">Sem histórico de tratamentos</h3>
          <p className="text-gray-500">Este paciente ainda não possui tratamentos registrados.</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {patientTreatmentHistory.map((treatment, index) => (
          <Card key={index} className={treatment.discontinued ? "border-gray-200 bg-gray-50" : ""}>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-base">{treatment.medication}</CardTitle>
                  <CardDescription>{treatment.period}</CardDescription>
                </div>
                {treatment.discontinued ? (
                  <Badge variant="outline" className="bg-gray-100 text-gray-800">Descontinuado</Badge>
                ) : (
                  <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium mb-1">Dosagem</p>
                  <p className="text-gray-600">{treatment.dosage}</p>
                </div>
                <div>
                  <p className="font-medium mb-1">Adesão</p>
                  <p className="text-gray-600">{treatment.adherence}</p>
                </div>
                <div>
                  <p className="font-medium mb-1">Resposta</p>
                  <p className="text-gray-600">{treatment.response}</p>
                </div>
                <div>
                  <p className="font-medium mb-1">Efeitos Colaterais</p>
                  <p className="text-gray-600">{treatment.sideEffects}</p>
                </div>
              </div>
              {treatment.discontinued && treatment.discontinueReason && (
                <div className="mt-4 p-3 bg-gray-100 rounded-lg">
                  <p className="font-medium mb-1">Motivo da Descontinuação</p>
                  <p className="text-gray-600">{treatment.discontinueReason}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  const renderAiAnalysisResults = () => {
    if (!aiAnalysisResult) return null;

    return (
      <ScrollArea className="h-[calc(100vh-400px)]">
        <div className="space-y-6">
          {/* Clinical Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Stethoscope className="w-5 h-5" />
                Resumo Clínico
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700">{aiAnalysisResult.clinicalSummary}</p>
            </CardContent>
          </Card>

          {/* Possible Conditions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <List className="w-5 h-5" />
                Condições a Considerar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {aiAnalysisResult.possibleConditions.map((condition, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <Badge 
                      className={
                        condition.likelihood === "Alta" ? "bg-red-100 text-red-800" :
                        condition.likelihood === "Moderada" ? "bg-yellow-100 text-yellow-800" :
                        "bg-blue-100 text-blue-800"
                      }
                    >
                      {condition.likelihood}
                    </Badge>
                    <div>
                      <h4 className="font-medium">{condition.condition}</h4>
                      <p className="text-sm text-gray-600">{condition.reasoning}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Cannabis Treatment Assessment */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Avaliação para Tratamento com Cannabis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Badge 
                    className={
                      aiAnalysisResult.cannabisTreatmentAssessment.suitability === "Alta" ? "bg-green-100 text-green-800" :
                      aiAnalysisResult.cannabisTreatmentAssessment.suitability === "Moderada" ? "bg-yellow-100 text-yellow-800" :
                      aiAnalysisResult.cannabisTreatmentAssessment.suitability === "Baixa" ? "bg-orange-100 text-orange-800" :
                      "bg-red-100 text-red-800"
                    }
                  >
                    Adequação: {aiAnalysisResult.cannabisTreatmentAssessment.suitability}
                  </Badge>
                </div>
                <p className="text-gray-700">{aiAnalysisResult.cannabisTreatmentAssessment.reasoning}</p>
              </div>
            </CardContent>
          </Card>

          {/* Product Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Pill className="w-5 h-5" />
                Recomendações de Produtos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {aiAnalysisResult.productRecommendations.map((product, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium">{product.productType}</h4>
                      {product.ratio && (
                        <Badge variant="outline">
                          Ratio: {product.ratio}
                        </Badge>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Dosagem</p>
                        <p>{product.dosage}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Frequência</p>
                        <p>{product.frequency}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Via de Administração</p>
                        <p>{product.administrationRoute}</p>
                      </div>
                    </div>
                    {product.notes && (
                      <div className="mt-3 text-sm">
                        <p className="text-gray-500">Observações</p>
                        <p>{product.notes}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Potential Concerns */}
          {aiAnalysisResult.potentialConcerns.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" />
                  Preocupações e Precauções
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aiAnalysisResult.potentialConcerns.map((concern, index) => (
                    <div key={index} className="flex items-start gap-4">
                      <Badge 
                        className={
                          concern.severity === "Alta" ? "bg-red-100 text-red-800" :
                          concern.severity === "Moderada" ? "bg-yellow-100 text-yellow-800" :
                          "bg-blue-100 text-blue-800"
                        }
                      >
                        {concern.severity}
                      </Badge>
                      <div>
                        <h4 className="font-medium">{concern.concern}</h4>
                        <p className="text-sm text-gray-600">{concern.recommendation}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Follow-up Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Recomendações de Acompanhamento
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Prazo para Reavaliação</h4>
                  <Badge variant="outline">{aiAnalysisResult.followUpRecommendations.timeframe}</Badge>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Focos da Avaliação</h4>
                  <div className="flex flex-wrap gap-2">
                    {aiAnalysisResult.followUpRecommendations.assessmentFocus.map((focus, index) => (
                      <Badge key={index} variant="outline">{focus}</Badge>
                    ))}
                  </div>
                </div>
                
                {aiAnalysisResult.followUpRecommendations.additionalTests.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">Exames/Testes Recomendados</h4>
                    <ul className="list-disc list-inside text-sm text-gray-600">
                      {aiAnalysisResult.followUpRecommendations.additionalTests.map((test, index) => (
                        <li key={index}>{test}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </ScrollArea>
    );
  };

  return (
    <div className="flex h-screen overflow-hidden bg-purple-50">
      {/* Sidebar */}
      <aside className={`${isMenuOpen ? 'translate-x-0' : '-translate-x-full'} fixed inset-0 z-50 bg-white border-r shadow-lg transition-transform duration-300 lg:translate-x-0 lg:static lg:w-64 lg:z-auto`}>
        <div className="flex flex-col h-full">
          <div className="p-4 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-purple-600 rounded-md flex items-center justify-center text-white font-bold">
                  D
                </div>
                <span className="text-lg font-medium">DrCanabis</span>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsMenuOpen(false)}
                className="lg:hidden"
              >
                <X size={20} />
              </Button>
            </div>
          </div>
          
          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            <Link to={createPageUrl("DoctorDashboard")} className="flex items-center p-2 rounded-lg hover:bg-purple-100 text-gray-700 transition-colors">
              <LayoutDashboard size={20} className="mr-3" />
              Dashboard
            </Link>
            <Link to={createPageUrl("DoctorPatients")} className="flex items-center p-2 rounded-lg hover:bg-purple-100 text-gray-700 transition-colors">
              <Users size={20} className="mr-3" />
              Pacientes
            </Link>
            <Link to={createPageUrl("DoctorPrescriptions")} className="flex items-center p-2 rounded-lg hover:bg-purple-100 text-gray-700 transition-colors">
              <ClipboardList size={20} className="mr-3" />
              Prescrições
            </Link>
            <Link to={createPageUrl("ConsultaVirtual")} className="flex items-center p-2 rounded-lg hover:bg-purple-100 text-gray-700 transition-colors">
              <Video size={20} className="mr-3" />
              Telemedicina
            </Link>
            <Link to={createPageUrl("SymptomChecker")} className="flex items-center p-2 rounded-lg bg-purple-100 text-purple-700 font-medium transition-colors">
              <Brain size={20} className="mr-3" />
              Acompanhamento
            </Link>
            <Link to={createPageUrl("DoctorFinancial")} className="flex items-center p-2 rounded-lg hover:bg-purple-100 text-gray-700 transition-colors">
              <DollarSign size={20} className="mr-3" />
              Financeiro
            </Link>
            <Link to={createPageUrl("DoctorSettings")} className="flex items-center p-2 rounded-lg hover:bg-purple-100 text-gray-700 transition-colors">
              <Settings size={20} className="mr-3" />
              Configurações
            </Link>
          </nav>
          
          <div className="p-4 border-t mt-auto">
            <Button 
              variant="ghost" 
              className="w-full justify-start text-red-600" 
              onClick={() => {
                // Implement logout functionality here
                navigate(createPageUrl("Index"));
              }}
            >
              <LogOut size={20} className="mr-3" />
              Sair
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b shadow-sm z-10">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsMenuOpen(true)}
                className="lg:hidden mr-2"
              >
                <Menu size={20} />
              </Button>
              <h1 className="font-semibold text-lg">Analisador de Sintomas</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="hidden md:flex">
                <Bell size={20} />
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="flex items-center">
                    <Avatar className="w-8 h-8 mr-2">
                      <AvatarFallback className="bg-purple-600 text-white">JS</AvatarFallback>
                    </Avatar>
                    <span className="hidden md:inline">Dr. João Silva</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Link to={createPageUrl("DoctorSettings")} className="flex items-center w-full">
                      <Settings size={16} className="mr-2" />
                      Configurações
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="text-red-600" 
                    onClick={() => {
                      // Implement logout functionality here
                      navigate(createPageUrl("Index"));
                    }}
                  >
                    <LogOut size={16} className="mr-2" />
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            {/* Patient Selection */}
            {!selectedPatient ? (
              <Card className="mb-6">
                <CardContent className="p-6">
                  <div className="text-center">
                    <Users className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                    <h2 className="text-xl font-semibold mb-2">Selecione um Paciente</h2>
                    <p className="text-gray-500 mb-4">
                      Para iniciar a análise de sintomas, selecione um paciente.
                    </p>
                    <Button 
                      onClick={() => setShowPatientSelector(true)}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <UserPlus size={16} className="mr-2" />
                      Selecionar Paciente
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="mb-6 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
                <div className="flex items-center gap-4">
                  <Avatar className="w-12 h-12">
                    <AvatarFallback className="bg-purple-100 text-purple-600 text-lg">
                      {selectedPatient.fullName.split(' ').map(name => name[0]).join('').slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h2 className="text-xl font-semibold flex items-center gap-2">
                      {selectedPatient.fullName}
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setShowPatientSelector(true)}
                      >
                        <UserPlus size={16} className="text-purple-600" />
                      </Button>
                    </h2>
                    <div className="flex items-center gap-2 text-gray-500">
                      <span>{selectedPatient.age} anos</span>
                      <span>•</span>
                      <span>{selectedPatient.gender}</span>
                      {selectedPatient.conditions.length > 0 && (
                        <>
                          <span>•</span>
                          <span>{selectedPatient.conditions.join(', ')}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
              <TabsList>
                <TabsTrigger value="symptom-checker" className="flex items-center gap-2">
                  <Brain size={16} />
                  Analisador de Sintomas
                </TabsTrigger>
                <TabsTrigger value="history" className="flex items-center gap-2">
                  <History size={16} />
                  Histórico de Análises
                </TabsTrigger>
                <TabsTrigger value="treatments" className="flex items-center gap-2">
                  <LayoutList size={16} />
                  Histórico de Tratamentos
                </TabsTrigger>
              </TabsList>

              <TabsContent value="symptom-checker">
                {selectedPatient ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Symptom Checker Form */}
                    <div className="space-y-6">
                      {/* Patient Data Card */}
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-lg">Dados do Paciente</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor="age">Idade</Label>
                              <Input
                                id="age"
                                value={patientData.age}
                                onChange={(e) => setPatientData({ ...patientData, age: e.target.value })}
                                type="number"
                              />
                            </div>
                            <div>
                              <Label htmlFor="gender">Gênero</Label>
                              <Select
                                value={patientData.gender}
                                onValueChange={(value) => setPatientData({ ...patientData, gender: value })}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="male">Masculino</SelectItem>
                                  <SelectItem value="female">Feminino</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <Label htmlFor="weight">Peso (kg)</Label>
                              <Input
                                id="weight"
                                value={patientData.weight}
                                onChange={(e) => setPatientData({ ...patientData, weight: e.target.value })}
                                type="number"
                              />
                            </div>
                            <div>
                              <Label htmlFor="height">Altura (cm)</Label>
                              <Input
                                id="height"
                                value={patientData.height}
                                onChange={(e) => setPatientData({ ...patientData, height: e.target.value })}
                                type="number"
                              />
                            </div>
                          </div>
                          
                          <div className="mt-4 space-y-4">
                            <div>
                              <Label htmlFor="currentMedications">Medicamentos Atuais</Label>
                              <Textarea
                                id="currentMedications"
                                value={patientData.currentMedications}
                                onChange={(e) => setPatientData({ ...patientData, currentMedications: e.target.value })}
                                placeholder="Liste os medicamentos em uso..."
                              />
                            </div>
                            <div>
                              <Label htmlFor="existingConditions">Condições Existentes</Label>
                              <Textarea
                                id="existingConditions"
                                value={patientData.existingConditions}
                                onChange={(e) => setPatientData({ ...patientData, existingConditions: e.target.value })}
                                placeholder="Liste as condições médicas..."
                              />
                            </div>
                            <div>
                              <Label htmlFor="allergies">Alergias</Label>
                              <Textarea
                                id="allergies"
                                value={patientData.allergies}
                                onChange={(e) => setPatientData({ ...patientData, allergies: e.target.value })}
                                placeholder="Liste as alergias conhecidas..."
                              />
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Symptom Questions */}
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-lg">Avaliação de Sintomas</CardTitle>
                          <CardDescription>
                            {currentSymptomIndex + 1} de {applicableSymptoms.length} questões
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-6">
                            <div>
                              <Progress 
                                value={(currentSymptomIndex + 1) / applicableSymptoms.length * 100} 
                                className="mb-4"
                              />
                              
                              <h3 className="text-lg font-medium mb-4">
                                {applicableSymptoms[currentSymptomIndex].question}
                              </h3>
                              
                              {renderSymptomInput(applicableSymptoms[currentSymptomIndex])}
                            </div>
                            
                            <div className="flex justify-between pt-4">
                              <Button
                                variant="outline"
                                onClick={handlePreviousSymptom}
                                disabled={currentSymptomIndex === 0}
                              >
                                <ChevronLeft size={16} className="mr-2" />
                                Anterior
                              </Button>
                              
                              {currentSymptomIndex < applicableSymptoms.length - 1 ? (
                                <Button
                                  onClick={handleNextSymptom}
                                >
                                  Próxima
                                  <ChevronRight size={16} className="ml-2" />
                                </Button>
                              ) : (
                                <Button
                                  className="bg-purple-600 hover:bg-purple-700"
                                  onClick={analyzeWithAI}
                                  disabled={isAiAnalysisLoading}
                                >
                                  {isAiAnalysisLoading ? (
                                    <>
                                      <Spinner className="mr-2" />
                                      Analisando...
                                    </>
                                  ) : (
                                    <>
                                      <Brain size={16} className="mr-2" />
                                      Analisar Sintomas
                                    </>
                                  )}
                                </Button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Additional Notes */}
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-lg">Observações Adicionais</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <Textarea
                            value={patientData.additionalNotes}
                            onChange={(e) => setPatientData({ ...patientData, additionalNotes: e.target.value })}
                            placeholder="Adicione observações relevantes sobre os sintomas ou condição do paciente..."
                            rows={4}
                          />
                        </CardContent>
                      </Card>
                    </div>

                    {/* Analysis Results */}
                    <div>
                      {isAiAnalysisLoading ? (
                        <Card>
                          <CardContent className="p-6">
                            <div className="flex flex-col items-center justify-center">
                              <Spinner className="w-12 h-12 text-purple-600 mb-4" />
                              <h3 className="text-lg font-medium mb-2">Analisando Sintomas</h3>
                              <p className="text-gray-500 text-center">
                                Nosso sistema está analisando os dados fornecidos para gerar recomendações personalizadas...
                              </p>
                            </div>
                          </CardContent>
                        </Card>
                      ) : aiAnalysisResult ? (
                        renderAiAnalysisResults()
                      ) : (
                        <Card>
                          <CardContent className="p-6">
                            <div className="text-center">
                              <Brain className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                              <h3 className="text-lg font-medium mb-2">Aguardando Análise</h3>
                              <p className="text-gray-500">
                                Preencha o formulário de sintomas e clique em "Analisar Sintomas" para receber recomendações personalizadas.
                              </p>
                            </div>
                          </CardContent>
                        </Card>
                      )}
                    </div>
                  </div>
                ) : (
                  <Card>
                    <CardContent className="p-6">
                      <div className="text-center">
                        <UserPlus className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                        <h3 className="text-lg font-medium mb-2">Nenhum Paciente Selecionado</h3>
                        <p className="text-gray-500 mb-4">
                          Selecione um paciente para iniciar a análise de sintomas.
                        </p>
                        <Button 
                          onClick={() => setShowPatientSelector(true)}
                          className="bg-purple-600 hover:bg-purple-700"
                        >
                          Selecionar Paciente
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="history">
                {selectedPatient ? (
                  renderPreviousResults()
                ) : (
                  <Card>
                    <CardContent className="p-6">
                      <div className="text-center">
                        <UserPlus className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                        <h3 className="text-lg font-medium mb-2">Nenhum Paciente Selecionado</h3>
                        <p className="text-gray-500 mb-4">
                          Selecione um paciente para visualizar o histórico de análises.
                        </p>
                        <Button 
                          onClick={() => setShowPatientSelector(true)}
                          className="bg-purple-600 hover:bg-purple-700"
                        >
                          Selecionar Paciente
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="treatments">
                {selectedPatient ? (
                  renderTreatmentHistory()
                ) : (
                  <Card>
                    <CardContent className="p-6">
                      <div className="text-center">
                        <UserPlus className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                        <h3 className="text-lg font-medium mb-2">Nenhum Paciente Selecionado</h3>
                        <p className="text-gray-500 mb-4">
                          Selecione um paciente para visualizar o histórico de tratamentos.
                        </p>
                        <Button 
                          onClick={() => setShowPatientSelector(true)}
                          className="bg-purple-600 hover:bg-purple-700"
                        >
                          Selecionar Paciente
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>

      {/* Patient Selector Dialog */}
      <Dialog open={showPatientSelector} onOpenChange={setShowPatientSelector}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Selecionar Paciente</DialogTitle>
            <DialogDescription>
              Escolha um paciente para iniciar a análise de sintomas.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <Input 
                className="pl-10" 
                placeholder="Buscar pacientes..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <ScrollArea className="h-[300px]">
              <div className="space-y-2">
                {filteredPatients.map((patient) => (
                  <div
                    key={patient.id}
                    className="p-3 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                    onClick={() => loadPatientData(patient)}
                  >
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback className="bg-purple-100 text-purple-600">
                          {patient.fullName.split(' ').map(name => name[0]).join('').slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{patient.fullName}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <span>{patient.id}</span>
                          <span>•</span>
                          <span>{patient.age} anos</span>
                          <span>•</span>
                          <span>{patient.gender}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {filteredPatients.length === 0 && (
                  <div className="text-center py-8">
                    <Users className="w-12 h-12 mx-auto text-gray-300 mb-2" />
                    <h3 className="text-gray-500">Nenhum paciente encontrado</h3>
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPatientSelector(false)}>
              Cancelar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}