import React, { useState, useEffect } from 'react';
import { 
  Card, 
  CardContent
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  Plus, 
  Search,
  Filter,
  Trash2,
  AlertTriangle,
  Calendar,
  FileText,
  Eye
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function ProducaoDescartes() {
  const [loading, setLoading] = useState(true);
  const [descartes, setDescartes] = useState([]);
  const [tipoFilter, setTipoFilter] = useState("all");
  const [showDialog, setShowDialog] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      // Mock data
      const mockDescartes = [
        {
          id: "DSC001",
          codigo_descarte: "DESC-2024-001",
          data_descarte: "2024-01-15T14:20:00",
          tipo_material: "materia_prima",
          material: "Extrato CBD Full Spectrum",
          lote: "L202401",
          quantidade: 200,
          unidade_medida: "ml",
          motivo_descarte: "vencimento",
          detalhamento_motivo: "Material vencido em 10/01/2024",
          responsavel: "Pedro Costa",
          metodo_descarte: "Incineração",
          empresa_descarte: "EcoDescarte Ltda",
          documento_descarte: "CTR-4567",
          observacoes: "Descarte conforme Procedimento POP-DSC-001"
        },
        {
          id: "DSC002",
          codigo_descarte: "DESC-2024-002",
          data_descarte: "2024-01-18T10:30:00",
          tipo_material: "produto_acabado",
          material: "Óleo CBD 10% Full Spectrum",
          lote: "L202402",
          quantidade: 50,
          unidade_medida: "unidade",
          motivo_descarte: "reprovado_qualidade",
          detalhamento_motivo: "Reprovado em teste de pH",
          responsavel: "Maria Santos",
          metodo_descarte: "Incineração",
          empresa_descarte: "EcoDescarte Ltda",
          documento_descarte: "CTR-4570",
          observacoes: "Descarte conforme Procedimento POP-DSC-001"
        },
        {
          id: "DSC003",
          codigo_descarte: "DESC-2024-003",
          data_descarte: "2024-01-20T09:15:00",
          tipo_material: "embalagem",
          material: "Frascos Vazios",
          lote: "L202403",
          quantidade: 100,
          unidade_medida: "unidade",
          motivo_descarte: "dano_embalagem",
          detalhamento_motivo: "Frascos com defeito de fabricação",
          responsavel: "João Silva",
          metodo_descarte: "Reciclagem",
          empresa_descarte: "ReciclaVerde SA",
          documento_descarte: "MTR-1234",
          observacoes: "Descarte conforme Procedimento POP-DSC-002"
        }
      ];

      setDescartes(mockDescartes);
      setLoading(false);
    };

    loadData();
  }, []);

  const getMotivoDescarte = (motivo) => {
    const motivos = {
      vencimento: "Vencimento",
      reprovado_qualidade: "Reprovado na Qualidade",
      contaminacao: "Contaminação",
      dano_embalagem: "Dano na Embalagem",
      outro: "Outro"
    };

    return motivos[motivo] || motivo;
  };

  const getTipoMaterialLabel = (tipo) => {
    const tipos = {
      materia_prima: "Matéria Prima",
      produto_acabado: "Produto Acabado",
      em_processo: "Em Processo",
      embalagem: "Embalagem"
    };

    return tipos[tipo] || tipo;
  };

  const getTipoBadge = (tipo) => {
    const config = {
      materia_prima: "bg-blue-100 text-blue-800",
      produto_acabado: "bg-green-100 text-green-800",
      em_processo: "bg-yellow-100 text-yellow-800",
      embalagem: "bg-purple-100 text-purple-800"
    };

    return (
      <Badge className={config[tipo] || "bg-gray-100 text-gray-800"}>
        {getTipoMaterialLabel(tipo)}
      </Badge>
    );
  };

  const getMotivoBadge = (motivo) => {
    const config = {
      vencimento: "bg-orange-100 text-orange-800",
      reprovado_qualidade: "bg-red-100 text-red-800",
      contaminacao: "bg-red-100 text-red-800",
      dano_embalagem: "bg-yellow-100 text-yellow-800",
      outro: "bg-gray-100 text-gray-800"
    };

    return (
      <Badge className={config[motivo] || "bg-gray-100 text-gray-800"}>
        {getMotivoDescarte(motivo)}
      </Badge>
    );
  };

  const handleViewDetails = (item) => {
    setSelectedItem(item);
    setShowDialog(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Produção - Descartes</h2>
          <p className="text-gray-500">Gestão e rastreamento de materiais descartados</p>
        </div>
        <Button onClick={() => console.log("Novo descarte")}>
          <Plus className="w-4 h-4 mr-2" />
          Novo Descarte
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Buscar descartes..."
                className="pl-10"
              />
            </div>
            
            <Select value={tipoFilter} onValueChange={setTipoFilter}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Tipo de Material" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Tipos</SelectItem>
                <SelectItem value="materia_prima">Matéria Prima</SelectItem>
                <SelectItem value="produto_acabado">Produto Acabado</SelectItem>
                <SelectItem value="em_processo">Em Processo</SelectItem>
                <SelectItem value="embalagem">Embalagem</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {loading ? (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Código</TableHead>
                  <TableHead>Tipo Material</TableHead>
                  <TableHead>Material</TableHead>
                  <TableHead>Lote</TableHead>
                  <TableHead>Quantidade</TableHead>
                  <TableHead>Motivo</TableHead>
                  <TableHead>Responsável</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {descartes.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{new Date(item.data_descarte).toLocaleDateString()}</TableCell>
                    <TableCell>{item.codigo_descarte}</TableCell>
                    <TableCell>{getTipoBadge(item.tipo_material)}</TableCell>
                    <TableCell>{item.material}</TableCell>
                    <TableCell>{item.lote}</TableCell>
                    <TableCell>{item.quantidade} {item.unidade_medida}</TableCell>
                    <TableCell>{getMotivoBadge(item.motivo_descarte)}</TableCell>
                    <TableCell>{item.responsavel}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" onClick={() => handleViewDetails(item)}>
                        <Eye className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {selectedItem && (
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Detalhes do Descarte - {selectedItem.codigo_descarte}</DialogTitle>
            </DialogHeader>
            
            <div className="grid grid-cols-2 gap-4 mt-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Material</h3>
                <p>{selectedItem.material}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Tipo</h3>
                <p>{getTipoMaterialLabel(selectedItem.tipo_material)}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Data</h3>
                <p>{new Date(selectedItem.data_descarte).toLocaleString()}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Lote</h3>
                <p>{selectedItem.lote}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Quantidade</h3>
                <p>{selectedItem.quantidade} {selectedItem.unidade_medida}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Responsável</h3>
                <p>{selectedItem.responsavel}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Motivo</h3>
                <p>{getMotivoDescarte(selectedItem.motivo_descarte)}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Método de Descarte</h3>
                <p>{selectedItem.metodo_descarte}</p>
              </div>
              <div className="col-span-2">
                <h3 className="text-sm font-medium text-gray-500">Detalhamento do Motivo</h3>
                <p>{selectedItem.detalhamento_motivo}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Empresa de Descarte</h3>
                <p>{selectedItem.empresa_descarte}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Documento</h3>
                <p>{selectedItem.documento_descarte}</p>
              </div>
              <div className="col-span-2">
                <h3 className="text-sm font-medium text-gray-500">Observações</h3>
                <p>{selectedItem.observacoes}</p>
              </div>
            </div>
            
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline">Imprimir</Button>
              <Button variant="outline">Exportar</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}