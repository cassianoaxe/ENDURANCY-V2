import React, { useState, useEffect } from 'react';
import { 
  CheckSquare, 
  FileText, 
  Beaker, 
  Search, 
  Plus, 
  Filter, 
  Eye, 
  Edit, 
  Trash2, 
  FileCheck,
  Calendar,
  User,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ProducaoQualidade() {
  const [activeTab, setActiveTab] = useState("lotes");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("all");
  const [isLoading, setIsLoading] = useState(true);
  const [analises, setAnalises] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    setTimeout(() => {
      setAnalises(mockAnalises);
      setIsLoading(false);
    }, 800);
  };

  const filteredAnalises = analises.filter(analise => {
    const matchesSearch = 
      analise.codigo.toLowerCase().includes(searchTerm.toLowerCase()) || 
      analise.produto.toLowerCase().includes(searchTerm.toLowerCase()) ||
      analise.lote.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || analise.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case "pendente":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case "em_analise":
        return <Badge className="bg-blue-100 text-blue-800">Em Análise</Badge>;
      case "aprovado":
        return <Badge className="bg-green-100 text-green-800">Aprovado</Badge>;
      case "reprovado":
        return <Badge className="bg-red-100 text-red-800">Reprovado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Controle de Qualidade</h1>
          <p className="text-muted-foreground">
            Gerencie análises e controles de qualidade de matérias-primas e produtos
          </p>
        </div>
        <Link to={createPageUrl("ProducaoQualidadeNovaAnalise")}>
          <Button className="bg-green-600 hover:bg-green-700">
            <Plus className="w-4 h-4 mr-2" />
            Nova Análise
          </Button>
        </Link>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="lotes">Análises de Lotes</TabsTrigger>
          <TabsTrigger value="materias_primas">Matérias-Primas</TabsTrigger>
          <TabsTrigger value="insumos">Insumos</TabsTrigger>
          <TabsTrigger value="produtos">Produtos Acabados</TabsTrigger>
        </TabsList>

        <TabsContent value="lotes" className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar por código, lote ou produto..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Status</SelectItem>
                <SelectItem value="pendente">Pendente</SelectItem>
                <SelectItem value="em_analise">Em Análise</SelectItem>
                <SelectItem value="aprovado">Aprovado</SelectItem>
                <SelectItem value="reprovado">Reprovado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Código</TableHead>
                <TableHead>Produto</TableHead>
                <TableHead>Lote</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center">
                    Carregando...
                  </TableCell>
                </TableRow>
              ) : filteredAnalises.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center">
                    Nenhuma análise encontrada
                  </TableCell>
                </TableRow>
              ) : (
                filteredAnalises.map((analise) => (
                  <TableRow key={analise.id}>
                    <TableCell>{analise.codigo}</TableCell>
                    <TableCell>{analise.produto}</TableCell>
                    <TableCell>{analise.lote}</TableCell>
                    <TableCell>{analise.data}</TableCell>
                    <TableCell>{getStatusBadge(analise.status)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TabsContent>
      </Tabs>
    </div>
  );
}

const mockAnalises = [
  {
    id: "1",
    codigo: "QC-2023-001",
    produto: "Óleo CBD 10%",
    lote: "PCBD-2023-045",
    data: "15/07/2023",
    status: "aprovado"
  },
  {
    id: "2",
    codigo: "QC-2023-002",
    produto: "Extrato Full Spectrum",
    lote: "EXT-2023-089",
    data: "18/07/2023",
    status: "pendente"
  },
  {
    id: "3",
    codigo: "QC-2023-003",
    produto: "CBD Isolado",
    lote: "MP-2023-034",
    data: "20/07/2023",
    status: "em_analise"
  }
];