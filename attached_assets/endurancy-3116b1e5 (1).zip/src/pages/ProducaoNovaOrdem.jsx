import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DatePicker } from "@/components/ui/date-picker";
import { ClipboardList, Plus, Trash2, Factory, CheckCircle, Calendar, User, Info } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ProducaoNovaOrdem() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [materiais, setMateriais] = useState([]);
  const [produtos, setProdutos] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState("");
  const [quantidade, setQuantidade] = useState("");
  const [responsavel, setResponsavel] = useState("");
  const [observacoes, setObservacoes] = useState("");
  const [dataInicio, setDataInicio] = useState(new Date());
  const [materiaisSelecionados, setMateriaisSelecionados] = useState([]);
  const [loteNumber, setLoteNumber] = useState("");
  
  useEffect(() => {
    const loadData = async () => {
      // Mock data para produtos do catálogo
      const mockProdutos = [
        { id: "PROD001", nome: "Óleo CBD 5% 30ml", descricao: "Óleo de CBD 5% em frasco de 30ml com conta-gotas" },
        { id: "PROD002", nome: "Óleo CBD 10% 30ml", descricao: "Óleo de CBD 10% em frasco de 30ml com conta-gotas" },
        { id: "PROD003", nome: "Cápsulas CBD 20mg", descricao: "Cápsulas de CBD 20mg, frasco com 30 unidades" },
        { id: "PROD004", nome: "Creme Tópico CBD 2%", descricao: "Creme tópico com CBD 2%, pote com 50g" }
      ];
      
      // Mock data para materiais em estoque
      const mockMateriais = [
        { id: "MAT001", codigo: "MP-EXT-001", nome: "Extrato CBD Full Spectrum", quantidade: 5000, unidade: "g", lote: "EXT-056" },
        { id: "MAT002", codigo: "MP-MCT-001", nome: "Óleo MCT", quantidade: 500, unidade: "L", lote: "MCT-123" },
        { id: "MAT003", codigo: "EMB-FR-001", nome: "Frasco Âmbar 30ml", quantidade: 10000, unidade: "un", lote: "FRA-457" },
        { id: "MAT004", codigo: "EMB-CG-001", nome: "Conta-gotas", quantidade: 10000, unidade: "un", lote: "CG-789" },
        { id: "MAT005", codigo: "EMB-RT-001", nome: "Rótulo Óleo CBD 5%", quantidade: 5000, unidade: "un", lote: "ROT-234" },
        { id: "MAT006", codigo: "EMB-RT-002", nome: "Rótulo Óleo CBD 10%", quantidade: 5000, unidade: "un", lote: "ROT-235" },
        { id: "MAT007", codigo: "EMB-CX-001", nome: "Caixa Individual", quantidade: 8000, unidade: "un", lote: "CX-567" }
      ];
      
      setProdutos(mockProdutos);
      setMateriais(mockMateriais);
      
      // Gerar número de lote automático
      const today = new Date();
      const year = today.getFullYear().toString().slice(-2);
      const month = (today.getMonth() + 1).toString().padStart(2, '0');
      const randomNum = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      setLoteNumber(`LOT-${year}${month}-${randomNum}`);
      
      setLoading(false);
    };
    
    loadData();
  }, []);
  
  const adicionarMaterial = () => {
    // Modal ou seletor de material
  };
  
  const removerMaterial = (id) => {
    setMateriaisSelecionados(materiaisSelecionados.filter(mat => mat.id !== id));
  };
  
  const handleProductChange = (id) => {
    setSelectedProduct(id);
    
    // Automaticamente adicionar materiais dependendo do produto selecionado
    // Este é um exemplo simplificado de "receita" para cada produto
    if (id === "PROD001") { // Óleo CBD 5%
      setMateriaisSelecionados([
        { id: "MAT001", codigo: "MP-EXT-001", nome: "Extrato CBD Full Spectrum", quantidade: 250, unidade: "g", lote: "EXT-056" },
        { id: "MAT002", codigo: "MP-MCT-001", nome: "Óleo MCT", quantidade: 15, unidade: "L", lote: "MCT-123" },
        { id: "MAT003", codigo: "EMB-FR-001", nome: "Frasco Âmbar 30ml", quantidade: 500, unidade: "un", lote: "FRA-457" },
        { id: "MAT004", codigo: "EMB-CG-001", nome: "Conta-gotas", quantidade: 500, unidade: "un", lote: "CG-789" },
        { id: "MAT005", codigo: "EMB-RT-001", nome: "Rótulo Óleo CBD 5%", quantidade: 500, unidade: "un", lote: "ROT-234" },
        { id: "MAT007", codigo: "EMB-CX-001", nome: "Caixa Individual", quantidade: 500, unidade: "un", lote: "CX-567" }
      ]);
      setQuantidade(500);
    } else if (id === "PROD002") { // Óleo CBD 10%
      setMateriaisSelecionados([
        { id: "MAT001", codigo: "MP-EXT-001", nome: "Extrato CBD Full Spectrum", quantidade: 500, unidade: "g", lote: "EXT-056" },
        { id: "MAT002", codigo: "MP-MCT-001", nome: "Óleo MCT", quantidade: 15, unidade: "L", lote: "MCT-123" },
        { id: "MAT003", codigo: "EMB-FR-001", nome: "Frasco Âmbar 30ml", quantidade: 500, unidade: "un", lote: "FRA-457" },
        { id: "MAT004", codigo: "EMB-CG-001", nome: "Conta-gotas", quantidade: 500, unidade: "un", lote: "CG-789" },
        { id: "MAT006", codigo: "EMB-RT-002", nome: "Rótulo Óleo CBD 10%", quantidade: 500, unidade: "un", lote: "ROT-235" },
        { id: "MAT007", codigo: "EMB-CX-001", nome: "Caixa Individual", quantidade: 500, unidade: "un", lote: "CX-567" }
      ]);
      setQuantidade(500);
    }
  };
  
  const handleSalvar = () => {
    // Criar ordem de produção e redirecionar para o processo
    navigate(createPageUrl("ProducaoProcesso"));
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Nova Ordem de Produção</h2>
          <p className="text-gray-500">Preencha os dados para criar uma nova ordem de produção</p>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Informações Básicas</CardTitle>
          <CardDescription>Selecione o produto e defina a quantidade a ser produzida</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="produto">Produto</Label>
                <Select
                  value={selectedProduct}
                  onValueChange={handleProductChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o produto" />
                  </SelectTrigger>
                  <SelectContent>
                    {produtos.map(produto => (
                      <SelectItem key={produto.id} value={produto.id}>
                        {produto.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="lote">Número do Lote</Label>
                <Input
                  id="lote"
                  value={loteNumber}
                  onChange={(e) => setLoteNumber(e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="quantidade">Quantidade</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="quantidade"
                    type="number"
                    value={quantidade}
                    onChange={(e) => setQuantidade(e.target.value)}
                  />
                  <span className="w-20">unidades</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="responsavel">Responsável</Label>
                <Input
                  id="responsavel"
                  value={responsavel}
                  onChange={(e) => setResponsavel(e.target.value)}
                  placeholder="Nome do responsável pela produção"
                />
              </div>
              
              <div>
                <Label htmlFor="data_inicio">Data de Início</Label>
                <Input
                  id="data_inicio"
                  type="date"
                  value={dataInicio ? dataInicio.toISOString().split('T')[0] : ''}
                  onChange={(e) => setDataInicio(new Date(e.target.value))}
                />
              </div>
              
              <div>
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Materiais Necessários</CardTitle>
              <CardDescription>Liste os materiais necessários para esta produção</CardDescription>
            </div>
            <Button onClick={adicionarMaterial}>
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Material
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Código</TableHead>
                <TableHead>Material</TableHead>
                <TableHead>Quantidade</TableHead>
                <TableHead>Unidade</TableHead>
                <TableHead>Lote</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {materiaisSelecionados.map(material => (
                <TableRow key={material.id}>
                  <TableCell>{material.codigo}</TableCell>
                  <TableCell>{material.nome}</TableCell>
                  <TableCell>{material.quantidade}</TableCell>
                  <TableCell>{material.unidade}</TableCell>
                  <TableCell>{material.lote}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm" onClick={() => removerMaterial(material.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {materiaisSelecionados.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-4 text-gray-500">
                    Nenhum material selecionado. Selecione um produto primeiro.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => navigate(createPageUrl("ProducaoOrdens"))}>
          Cancelar
        </Button>
        <Button onClick={handleSalvar} disabled={!selectedProduct || !quantidade || !loteNumber}>
          <ClipboardList className="w-4 h-4 mr-2" />
          Criar Ordem
        </Button>
      </div>
    </div>
  );
}