
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";

import { 
  Factory, 
  CheckCircle2, 
  AlertTriangle, 
  Truck, 
  Package, 
  BarChart, 
  TrendingUp,
  Calendar,
  Clock,
  Clipboard,
  FileText,
  ShoppingCart,
  Bolt,
  Thermometer,
  FlaskConical,
  Scan,
  ArrowDownUp,
  Plus,
  Search,
  GraduationCap
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

// Dados mockados para o dashboard
const mockStats = {
  ordensAtivas: 5,
  producaoMensal: 320,
  eficiencia: 92.5,
  alertasQualidade: 2
};

const mockOrdensProducao = [
  { 
    id: 'OP-2023-0125',
    produto: 'Óleo CBD 5% 30ml',
    lote: 'LOT-CBD-072',
    inicioPrevisto: '2023-08-05',
    terminoPrevisto: '2023-08-12',
    status: 'em_andamento',
    progresso: 65,
    prioridade: 'alta'
  },
  { 
    id: 'OP-2023-0126',
    produto: 'Cápsulas CBD 20mg',
    lote: 'LOT-CAP-033',
    inicioPrevisto: '2023-08-10',
    terminoPrevisto: '2023-08-18',
    status: 'planejada',
    progresso: 0,
    prioridade: 'media'
  },
  { 
    id: 'OP-2023-0124',
    produto: 'Tinturas CBD 3% 50ml',
    lote: 'LOT-TIN-056',
    inicioPrevisto: '2023-08-02',
    terminoPrevisto: '2023-08-09',
    status: 'em_andamento',
    progresso: 80,
    prioridade: 'media'
  },
  { 
    id: 'OP-2023-0123',
    produto: 'Óleo CBD 10% 10ml',
    lote: 'LOT-CBD-071',
    inicioPrevisto: '2023-07-28',
    terminoPrevisto: '2023-08-04',
    status: 'em_andamento',
    progresso: 95,
    prioridade: 'alta'
  },
  { 
    id: 'OP-2023-0122',
    produto: 'Cremes CBD tópico 50g',
    lote: 'LOT-CRE-024',
    inicioPrevisto: '2023-07-22',
    terminoPrevisto: '2023-07-29',
    status: 'concluida',
    progresso: 100,
    prioridade: 'baixa'
  }
];

const mockAlertasQualidade = [
  {
    id: 'QA-2023-0052',
    tipo: 'desvio_parametro',
    produto: 'Óleo CBD 5% 30ml',
    lote: 'LOT-CBD-069',
    descricao: 'Concentração de CBD 4.8%, abaixo do mínimo de 5.0%',
    reportado: '2023-08-03',
    status: 'em_analise',
    severidade: 'media'
  },
  {
    id: 'QA-2023-0051',
    tipo: 'equipamento',
    produto: 'N/A',
    lote: 'N/A',
    descricao: 'Calibração do cromatógrafo HPLC-1 vencida',
    reportado: '2023-08-02',
    status: 'em_correcao',
    severidade: 'alta'
  }
];

const mockMateriaPrimaStatus = [
  { nome: 'Extrato CBD Isolado', estoque: 5.2, unidade: 'kg', status: 'normal' },
  { nome: 'Óleo MCT', estoque: 125, unidade: 'L', status: 'normal' },
  { nome: 'Óleo Semente de Cânhamo', estoque: 12, unidade: 'L', status: 'alerta' },
  { nome: 'Embalagens Vidro Âmbar 30ml', estoque: 850, unidade: 'un', status: 'normal' },
  { nome: 'Conta-gotas', estoque: 820, unidade: 'un', status: 'normal' }
];

const mockProducaoMensal = [
  { mes: 'Jan', quantidade: 250 },
  { mes: 'Fev', quantidade: 280 },
  { mes: 'Mar', quantidade: 300 },
  { mes: 'Abr', quantidade: 270 },
  { mes: 'Mai', quantidade: 290 },
  { mes: 'Jun', quantidade: 310 },
  { mes: 'Jul', quantidade: 320 }
];

const mockProducaoPorCategoria = [
  { nome: 'Óleos CBD', valor: 55 },
  { nome: 'Cápsulas', valor: 20 },
  { nome: 'Tinturas', valor: 15 },
  { nome: 'Tópicos', valor: 10 }
];

const mockEficiencia = [
  { mes: 'Jan', valor: 88 },
  { mes: 'Fev', valor: 90 },
  { mes: 'Mar', valor: 87 },
  { mes: 'Abr', valor: 91 },
  { mes: 'Mai', valor: 93 },
  { mes: 'Jun', valor: 90 },
  { mes: 'Jul', valor: 92.5 }
];

// Componente Estatísticas
const StatsSection = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Ordens Ativas</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.ordensAtivas}</CardTitle>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Clipboard className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-blue-600 mt-2">
            <Clock className="w-4 h-4 mr-1" />
            <span>2 aguardando aprovação</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Produção Mensal</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.producaoMensal} unid.</CardTitle>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <Factory className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-green-600 mt-2">
            <TrendingUp className="w-4 h-4 mr-1" />
            <span>+3.2% em relação ao mês anterior</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Eficiência da Produção</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.eficiencia}%</CardTitle>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <Bolt className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-purple-600 mt-2">
            <TrendingUp className="w-4 h-4 mr-1" />
            <span>+1.5% em relação à meta</span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardDescription>Alertas de Qualidade</CardDescription>
              <CardTitle className="text-3xl font-bold">{stats.alertasQualidade}</CardTitle>
            </div>
            <div className="p-3 bg-amber-50 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-sm text-amber-600 mt-2">
            <Clock className="w-4 h-4 mr-1" />
            <span>1 de alta prioridade</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Gráfico de Barras - Produção Mensal
const ProducaoMensalChart = ({ data }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Produção Mensal</CardTitle>
        <CardDescription>Total de unidades produzidas por mês</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <RechartsBarChart
              data={data}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="mes" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="quantidade" name="Unidades Produzidas" fill="#4CAF50" />
            </RechartsBarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Gráfico de Pizza - Produção por Categoria
const ProducaoPorCategoriaChart = ({ data }) => {
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Produção por Categoria</CardTitle>
        <CardDescription>Distribuição da produção atual</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="valor"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Gráfico de Linha - Eficiência
const EficienciaChart = ({ data }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Eficiência da Produção</CardTitle>
        <CardDescription>Evolução mensal da eficiência operacional</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="mes" />
              <YAxis domain={[80, 100]} />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="valor"
                name="Eficiência (%)"
                stroke="#8884d8"
                activeDot={{ r: 8 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Ordens de Produção
const OrdensProducaoSection = ({ ordens }) => {
  // Função para obter cor baseada no status
  const getStatusColor = (status) => {
    switch(status) {
      case 'planejada': return 'bg-blue-100 text-blue-800';
      case 'em_andamento': return 'bg-amber-100 text-amber-800';
      case 'concluida': return 'bg-green-100 text-green-800';
      case 'atrasada': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Função para obter label do status
  const getStatusLabel = (status) => {
    switch(status) {
      case 'planejada': return 'Planejada';
      case 'em_andamento': return 'Em Andamento';
      case 'concluida': return 'Concluída';
      case 'atrasada': return 'Atrasada';
      default: return status;
    }
  };
  
  // Função para obter cor baseada na prioridade
  const getPriorityColor = (prioridade) => {
    switch(prioridade) {
      case 'alta': return 'text-red-600';
      case 'media': return 'text-amber-600';
      case 'baixa': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Ordens de Produção</CardTitle>
            <CardDescription>Status das ordens ativas e planejadas</CardDescription>
          </div>
          <Link to={createPageUrl("ProducaoOrdens")}>
            <Button variant="outline" size="sm">Ver Todas</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {ordens.map((ordem, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <div className="flex items-center">
                    <span className="font-medium">{ordem.id}</span>
                    <Badge className={`ml-2 ${getStatusColor(ordem.status)}`}>
                      {getStatusLabel(ordem.status)}
                    </Badge>
                  </div>
                  <p className="text-lg font-medium mt-1">{ordem.produto}</p>
                  <div className="text-sm text-gray-500 flex items-center mt-1">
                    <Package className="w-4 h-4 mr-1" />
                    Lote: {ordem.lote}
                  </div>
                </div>
                <div className="text-right">
                  <div className={`font-medium ${getPriorityColor(ordem.prioridade)} capitalize`}>
                    {ordem.prioridade} prioridade
                  </div>
                  <div className="text-sm text-gray-500 flex items-center justify-end mt-1">
                    <Calendar className="w-4 h-4 mr-1" />
                    {ordem.inicioPrevisto} a {ordem.terminoPrevisto}
                  </div>
                </div>
              </div>
              
              {ordem.status !== 'planejada' && (
                <div className="mt-3">
                  <div className="flex justify-between text-xs mb-1">
                    <span>Progresso</span>
                    <span>{ordem.progresso}%</span>
                  </div>
                  <Progress value={ordem.progresso} />
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente Alertas de Qualidade
const AlertasQualidadeSection = ({ alertas }) => {
  // Função para obter ícone baseado no tipo
  const getTipoIcon = (tipo) => {
    switch(tipo) {
      case 'desvio_parametro': return <Thermometer className="w-5 h-5" />;
      case 'equipamento': return <FlaskConical className="w-5 h-5" />;
      case 'contaminacao': return <AlertTriangle className="w-5 h-5" />;
      case 'embalagem': return <Package className="w-5 h-5" />;
      default: return <AlertTriangle className="w-5 h-5" />;
    }
  };
  
  // Função para obter cor baseada na severidade
  const getSeverityColor = (severidade) => {
    switch(severidade) {
      case 'alta': return 'bg-red-50 border-red-200 text-red-700';
      case 'media': return 'bg-amber-50 border-amber-200 text-amber-700';
      case 'baixa': return 'bg-blue-50 border-blue-200 text-blue-700';
      default: return 'bg-gray-50 border-gray-200 text-gray-700';
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Alertas de Qualidade</CardTitle>
            <CardDescription>Desvios e alertas em análise</CardDescription>
          </div>
          <Link to={createPageUrl("ProducaoQualidade")}>
            <Button variant="outline" size="sm">Ver Todos</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        {alertas.length === 0 ? (
          <div className="text-center py-8">
            <CheckCircle2 className="w-12 h-12 mx-auto text-green-500 mb-2" />
            <p>Não há alertas de qualidade ativos no momento</p>
          </div>
        ) : (
          <div className="space-y-4">
            {alertas.map((alerta, index) => (
              <div 
                key={index} 
                className={`p-4 rounded-lg border ${getSeverityColor(alerta.severidade)}`}
              >
                <div className="flex gap-3 items-start">
                  <div className={`p-2 rounded-full ${
                    alerta.severidade === 'alta' ? 'bg-red-100' : 
                    alerta.severidade === 'media' ? 'bg-amber-100' : 'bg-blue-100'
                  }`}>
                    {getTipoIcon(alerta.tipo)}
                  </div>
                  <div>
                    <div className="flex items-center">
                      <span className="font-medium">{alerta.id}</span>
                      <Badge className="ml-2 capitalize">
                        {alerta.status.replace('_', ' ')}
                      </Badge>
                    </div>
                    <p className="font-medium mt-1">{alerta.descricao}</p>
                    <div className="mt-2 text-sm">
                      <div>
                        <span className="text-gray-600">Produto:</span> {alerta.produto}
                      </div>
                      <div>
                        <span className="text-gray-600">Lote:</span> {alerta.lote}
                      </div>
                      <div>
                        <span className="text-gray-600">Reportado:</span> {alerta.reportado}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Componente Matérias-Primas
const MateriaPrimaSection = ({ materiasPrimas }) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Status de Matérias-Primas</CardTitle>
            <CardDescription>Níveis de estoque atuais</CardDescription>
          </div>
          <Link to={createPageUrl("ProducaoMateriasPrimas")}>
            <Button variant="outline" size="sm">Ver Todas</Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {materiasPrimas.map((item, index) => (
            <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${
                  item.status === 'critico' ? 'bg-red-100 text-red-600' :
                  item.status === 'alerta' ? 'bg-amber-100 text-amber-600' :
                  'bg-green-100 text-green-600'
                }`}>
                  {item.status === 'critico' ? (
                    <AlertTriangle className="w-4 h-4" />
                  ) : item.status === 'alerta' ? (
                    <Clock className="w-4 h-4" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4" />
                  )}
                </div>
                <div>
                  <div className="font-medium">{item.nome}</div>
                </div>
              </div>
              <div className="font-medium">
                {item.estoque} {item.unidade}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// Componente principal
export default function ProducaoDashboard() {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({});
  const [ordensProducao, setOrdensProducao] = useState([]);
  const [alertasQualidade, setAlertasQualidade] = useState([]);
  const [materiasPrimas, setMateriasPrimas] = useState([]);
  const [producaoMensal, setProducaoMensal] = useState([]);
  const [producaoPorCategoria, setProducaoPorCategoria] = useState([]);
  const [eficiencia, setEficiencia] = useState([]);
  const [periodFilter, setPeriodFilter] = useState('month');
  
  useEffect(() => {
    loadDashboardData();
  }, [periodFilter]);
  
  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      
      // Em produção, aqui seriam chamadas para as APIs reais
      // Simulando carregamento
      setTimeout(() => {
        setStats(mockStats);
        setOrdensProducao(mockOrdensProducao);
        setAlertasQualidade(mockAlertasQualidade);
        setMateriasPrimas(mockMateriaPrimaStatus);
        setProducaoMensal(mockProducaoMensal);
        setProducaoPorCategoria(mockProducaoPorCategoria);
        setEficiencia(mockEficiencia);
        setIsLoading(false);
      }, 800);
      
    } catch (error) {
      console.error("Erro ao carregar dados do dashboard:", error);
      setIsLoading(false);
    }
  };
  
  const handleRefresh = () => {
    loadDashboardData();
  };
  
  const handlePeriodChange = (value) => {
    setPeriodFilter(value);
  };

  // Add onboarding quick links
  const quickLinks = [
    { icon: GraduationCap, label: 'Onboarding', path: 'ProducaoOnboarding', color: 'bg-purple-100 text-purple-600' },
    { icon: Plus, label: 'Nova Ordem', path: 'ProducaoNovaOrdem', color: 'bg-green-100 text-green-600' },
    { icon: ArrowDownUp, label: 'Movimentação', path: 'NovaMovimentacaoEstoque', color: 'bg-blue-100 text-blue-600' },
    { icon: Package, label: 'Catálogo', path: 'CatalogoProdutos', color: 'bg-amber-100 text-amber-600' },
    { icon: Search, label: 'Rastreabilidade', path: 'ProducaoRastreabilidade', color: 'bg-indigo-100 text-indigo-600' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Dashboard de Produção</h1>
          <p className="text-gray-500 mt-1">
            Visão geral dos processos produtivos, qualidade e estoque
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <Select value={periodFilter} onValueChange={handlePeriodChange}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Última Semana</SelectItem>
              <SelectItem value="month">Último Mês</SelectItem>
              <SelectItem value="quarter">Último Trimestre</SelectItem>
              <SelectItem value="year">Último Ano</SelectItem>
            </SelectContent>
          </Select>
          
          <Button onClick={handleRefresh} variant="outline" className="gap-2">
            <ArrowDownUp className="w-4 h-4" />
            Atualizar
          </Button>
        </div>
      </div>

      {/* Quick access links */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {quickLinks.map((link, index) => (
          <Link 
            key={index} 
            to={createPageUrl(link.path)}
            className="flex flex-col items-center p-4 bg-white rounded-lg border border-gray-100 hover:shadow-md transition-shadow"
          >
            <div className={`p-3 rounded-full ${link.color} mb-2`}>
              <link.icon className="w-5 h-5" />
            </div>
            <span className="text-sm font-medium">{link.label}</span>
          </Link>
        ))}
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
          <p className="ml-2">Carregando dados do dashboard...</p>
        </div>
      ) : (
        <>
          <StatsSection stats={stats} />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <OrdensProducaoSection ordens={ordensProducao} />
            <AlertasQualidadeSection alertas={alertasQualidade} />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <ProducaoMensalChart data={producaoMensal} />
            </div>
            <ProducaoPorCategoriaChart data={producaoPorCategoria} />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <EficienciaChart data={eficiencia} />
            </div>
            <MateriaPrimaSection materiasPrimas={materiasPrimas} />
          </div>
        </>
      )}
      
      <div className="flex justify-center mt-6">
        <Link to={createPageUrl("ProducaoOrdens")}>
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            Nova Ordem de Produção
          </Button>
        </Link>
      </div>
    </div>
  );
}
