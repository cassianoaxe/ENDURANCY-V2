import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  DollarSign,
  Clock,
  Video,
  CalendarDays,
  Settings as SettingsIcon,
  Bell,
  User,
  Building2,
  CreditCard,
  BellRing,
  Mail,
  Phone,
  MapPin,
  Save,
  AlertTriangle
} from 'lucide-react';
import DoctorLayout from '../components/DoctorLayout';

export default function DoctorSettings() {
  const [settings, setSettings] = useState({
    consultationPricing: {
      presential: {
        enabled: true,
        price: 350,
        duration: 30,
      },
      telemedicine: {
        enabled: true,
        price: 300,
        duration: 30,
      },
      returnVisit: {
        enabled: true,
        price: 250,
        duration: 30,
      },
      firstVisit: {
        enabled: true,
        price: 400,
        duration: 45,
      }
    },
    notifications: {
      email: true,
      push: true,
      sms: false,
    },
    availability: {
      monday: true,
      tuesday: true,
      wednesday: true,
      thursday: true,
      friday: true,
      saturday: false,
      sunday: false,
    }
  });

  const handlePricingChange = (type, field, value) => {
    setSettings(prev => ({
      ...prev,
      consultationPricing: {
        ...prev.consultationPricing,
        [type]: {
          ...prev.consultationPricing[type],
          [field]: value
        }
      }
    }));
  };

  const handleSaveSettings = () => {
    // Here you would typically save to backend
    alert('Configurações salvas com sucesso!');
  };

  return (
    <DoctorLayout>
      <div className="container mx-auto py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Configurações</h1>
            <p className="text-gray-500">Gerencie suas preferências e configurações do portal</p>
          </div>
          <Button onClick={handleSaveSettings} className="bg-green-600 hover:bg-green-700">
            <Save className="w-4 h-4 mr-2" />
            Salvar Alterações
          </Button>
        </div>

        <Tabs defaultValue="pricing" className="space-y-4">
          <TabsList>
            <TabsTrigger value="pricing">
              <DollarSign className="w-4 h-4 mr-2" />
              Preços
            </TabsTrigger>
            <TabsTrigger value="profile">
              <User className="w-4 h-4 mr-2" />
              Perfil
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <Bell className="w-4 h-4 mr-2" />
              Notificações
            </TabsTrigger>
            <TabsTrigger value="availability">
              <Clock className="w-4 h-4 mr-2" />
              Disponibilidade
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pricing">
            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Preços das Consultas</CardTitle>
                  <CardDescription>
                    Configure os preços e durações para diferentes tipos de consulta
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Primeira Consulta */}
                  <div className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Primeira Consulta</h3>
                        <p className="text-sm text-gray-500">Consulta inicial com novos pacientes</p>
                      </div>
                      <Switch
                        checked={settings.consultationPricing.firstVisit.enabled}
                        onCheckedChange={(checked) => handlePricingChange('firstVisit', 'enabled', checked)}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Preço (R$)</Label>
                        <div className="relative">
                          <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                          <Input
                            type="number"
                            className="pl-9"
                            value={settings.consultationPricing.firstVisit.price}
                            onChange={(e) => handlePricingChange('firstVisit', 'price', Number(e.target.value))}
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Duração (minutos)</Label>
                        <div className="relative">
                          <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                          <Input
                            type="number"
                            className="pl-9"
                            value={settings.consultationPricing.firstVisit.duration}
                            onChange={(e) => handlePricingChange('firstVisit', 'duration', Number(e.target.value))}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Consulta de Retorno */}
                  <div className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Consulta de Retorno</h3>
                        <p className="text-sm text-gray-500">Consultas de acompanhamento</p>
                      </div>
                      <Switch
                        checked={settings.consultationPricing.returnVisit.enabled}
                        onCheckedChange={(checked) => handlePricingChange('returnVisit', 'enabled', checked)}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Preço (R$)</Label>
                        <div className="relative">
                          <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                          <Input
                            type="number"
                            className="pl-9"
                            value={settings.consultationPricing.returnVisit.price}
                            onChange={(e) => handlePricingChange('returnVisit', 'price', Number(e.target.value))}
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Duração (minutos)</Label>
                        <div className="relative">
                          <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                          <Input
                            type="number"
                            className="pl-9"
                            value={settings.consultationPricing.returnVisit.duration}
                            onChange={(e) => handlePricingChange('returnVisit', 'duration', Number(e.target.value))}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Telemedicina */}
                  <div className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Telemedicina</h3>
                        <p className="text-sm text-gray-500">Consultas online</p>
                      </div>
                      <Switch
                        checked={settings.consultationPricing.telemedicine.enabled}
                        onCheckedChange={(checked) => handlePricingChange('telemedicine', 'enabled', checked)}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Preço (R$)</Label>
                        <div className="relative">
                          <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                          <Input
                            type="number"
                            className="pl-9"
                            value={settings.consultationPricing.telemedicine.price}
                            onChange={(e) => handlePricingChange('telemedicine', 'price', Number(e.target.value))}
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Duração (minutos)</Label>
                        <div className="relative">
                          <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                          <Input
                            type="number"
                            className="pl-9"
                            value={settings.consultationPricing.telemedicine.duration}
                            onChange={(e) => handlePricingChange('telemedicine', 'duration', Number(e.target.value))}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <p className="text-sm text-gray-500">
                    <AlertTriangle className="w-4 h-4 inline mr-2" />
                    Os preços serão exibidos para os pacientes ao agendarem consultas
                  </p>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="profile">
            {/* Profile settings content */}
          </TabsContent>

          <TabsContent value="notifications">
            {/* Notification settings content */}
          </TabsContent>

          <TabsContent value="availability">
            {/* Availability settings content */}
          </TabsContent>
        </Tabs>
      </div>
    </DoctorLayout>
  );
}