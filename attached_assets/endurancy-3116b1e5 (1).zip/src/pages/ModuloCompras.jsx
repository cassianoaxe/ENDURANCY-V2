
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  BarChart3, 
  ShoppingCart, 
  Users, 
  Package, 
  Truck, 
  Wallet, 
  PlusCircle, 
  BarChart, 
  FileText, 
  Settings, 
  Building, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  ArrowUpRight, 
  ArrowRight, 
  DollarSign,
  CreditCard,
  MessageSquare,
  Search,
  PlusSquare,
  X,
  XCircle as CircleX
} from "lucide-react";

const organizacoesCompras = [
  {
    id: "org1",
    nome: "MediCannabis Farma",
    tipo: "Empresa",
    plano: "Básico",
    ativo: true,
    data_ativacao: "2023-06-15T10:30:00Z",
    solicitacoes_mes: 36,
    fornecedores: 24,
    usuarios: 8,
    valor_compras: 128750.45,
    ultimas_solicitacoes: [
      { id: "SOL-1001", data: "2023-07-28T10:30:00Z", valor: 4589.90, status: "aprovada" },
      { id: "SOL-1000", data: "2023-07-27T15:45:00Z", valor: 12750.00, status: "pendente" }
    ]
  },
  {
    id: "org2",
    nome: "Associação Médica Verde",
    tipo: "Associação",
    plano: "Premium",
    ativo: true,
    data_ativacao: "2023-05-10T14:20:00Z",
    solicitacoes_mes: 22,
    fornecedores: 15,
    usuarios: 12,
    valor_compras: 89250.80,
    ultimas_solicitacoes: [
      { id: "SOL-842", data: "2023-07-28T09:15:00Z", valor: 6450.00, status: "aprovada" },
      { id: "SOL-840", data: "2023-07-26T11:30:00Z", valor: 1875.50, status: "em_cotacao" }
    ]
  },
  {
    id: "org3",
    nome: "CannaPesquisa Instituto",
    tipo: "Associação",
    plano: "Básico",
    ativo: false,
    data_ativacao: null,
    solicitacoes_mes: 0,
    fornecedores: 0,
    usuarios: 3,
    valor_compras: 0,
    ultimas_solicitacoes: []
  },
  {
    id: "org4",
    nome: "Green Medical Brasil",
    tipo: "Empresa",
    plano: "Premium",
    ativo: true,
    data_ativacao: "2023-07-05T16:40:00Z",
    solicitacoes_mes: 18,
    fornecedores: 12,
    usuarios: 6,
    valor_compras: 45320.75,
    ultimas_solicitacoes: [
      { id: "SOL-125", data: "2023-07-27T08:20:00Z", valor: 8750.00, status: "recebida" },
      { id: "SOL-124", data: "2023-07-25T14:10:00Z", valor: 3250.90, status: "aprovada" }
    ]
  },
  {
    id: "org5",
    nome: "Cannabis Brasil Sul",
    tipo: "Empresa",
    plano: "Básico",
    ativo: true,
    data_ativacao: "2023-04-12T09:30:00Z",
    solicitacoes_mes: 15,
    fornecedores: 9,
    usuarios: 5,
    valor_compras: 36480.20,
    ultimas_solicitacoes: [
      { id: "SOL-452", data: "2023-07-26T16:50:00Z", valor: 2150.00, status: "rejeitada" },
      { id: "SOL-450", data: "2023-07-24T11:45:00Z", valor: 4350.25, status: "aprovada" }
    ]
  }
];

const dadosAtivacao = [
  { mes: 'Jan', count: 2 },
  { mes: 'Fev', count: 3 },
  { mes: 'Mar', count: 5 },
  { mes: 'Abr', count: 3 },
  { mes: 'Mai', count: 7 },
  { mes: 'Jun', count: 9 },
  { mes: 'Jul', count: 6 }
];

const dadosVolume = [
  { mes: 'Jan', valor: 120000 },
  { mes: 'Fev', valor: 183000 },
  { mes: 'Mar', valor: 157000 },
  { mes: 'Abr', valor: 220000 },
  { mes: 'Mai', valor: 280000 },
  { mes: 'Jun', valor: 320000 },
  { mes: 'Jul', valor: 390000 }
];

const configuracoesModulo = {
  basico: {
    preco: 299,
    usuarios_max: 10,
    fornecedores_max: 30,
    itens_max: 500,
    cotacoes_obrigatorias: true,
    integracao_financeira: false,
    valor_aprovacao_automatica: 1000
  },
  premium: {
    preco: 599,
    usuarios_max: "Ilimitado",
    fornecedores_max: "Ilimitado",
    itens_max: "Ilimitado",
    cotacoes_obrigatorias: true,
    integracao_financeira: true,
    valor_aprovacao_automatica: 5000
  }
};

export default function ModuloCompras() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("visao-geral");
  const [searchTerm, setSearchTerm] = useState("");
  const [organizacoes, setOrganizacoes] = useState([]);
  const [filteredOrganizacoes, setFilteredOrganizacoes] = useState([]);
  const [statusFilter, setStatusFilter] = useState("all");
  const [configDialog, setConfigDialog] = useState(false);
  const [selectedOrg, setSelectedOrg] = useState(null);
  const [loading, setLoading] = useState(true);
  
  const [metricas, setMetricas] = useState({
    total_organizacoes: 0,
    organizacoes_ativas: 0,
    total_solicitacoes: 0,
    volume_total: 0
  });

  useEffect(() => {
    setTimeout(() => {
      setOrganizacoes(organizacoesCompras);
      setFilteredOrganizacoes(organizacoesCompras);
      
      const totalOrgs = organizacoesCompras.length;
      const orgsAtivas = organizacoesCompras.filter(org => org.ativo).length;
      const totalSolicitacoes = organizacoesCompras.reduce((total, org) => total + org.solicitacoes_mes, 0);
      const volumeTotal = organizacoesCompras.reduce((total, org) => total + org.valor_compras, 0);
      
      setMetricas({
        total_organizacoes: totalOrgs,
        organizacoes_ativas: orgsAtivas,
        total_solicitacoes: totalSolicitacoes,
        volume_total: volumeTotal
      });
      
      setLoading(false);
    }, 500);
  }, []);

  useEffect(() => {
    let filtered = [...organizacoes];
    
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(org => 
        org.nome.toLowerCase().includes(term) ||
        org.tipo.toLowerCase().includes(term) ||
        org.plano.toLowerCase().includes(term)
      );
    }
    
    if (statusFilter !== "all") {
      const isActive = statusFilter === "active";
      filtered = filtered.filter(org => org.ativo === isActive);
    }
    
    setFilteredOrganizacoes(filtered);
  }, [organizacoes, searchTerm, statusFilter]);

  const handleActivateModule = (orgId) => {
    const updatedOrgs = organizacoes.map(org => {
      if (org.id === orgId) {
        return {
          ...org,
          ativo: true,
          data_ativacao: new Date().toISOString()
        };
      }
      return org;
    });
    
    setOrganizacoes(updatedOrgs);
    
    toast({
      title: "Módulo ativado com sucesso",
      description: "O módulo de Compras foi ativado para a organização selecionada."
    });
  };

  const handleDeactivateModule = (orgId) => {
    const updatedOrgs = organizacoes.map(org => {
      if (org.id === orgId) {
        return {
          ...org,
          ativo: false
        };
      }
      return org;
    });
    
    setOrganizacoes(updatedOrgs);
    
    toast({
      title: "Módulo desativado",
      description: "O módulo de Compras foi desativado para a organização selecionada."
    });
  };

  const handleOpenConfig = (org) => {
    setSelectedOrg(org);
    setConfigDialog(true);
  };

  const handleSaveConfig = () => {
    toast({
      title: "Configurações salvas",
      description: `As configurações do módulo para ${selectedOrg.nome} foram atualizadas com sucesso.`
    });
    
    setConfigDialog(false);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "aprovada":
        return <Badge className="bg-green-100 text-green-800">Aprovada</Badge>;
      case "pendente":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case "em_cotacao":
        return <Badge className="bg-blue-100 text-blue-800">Em Cotação</Badge>;
      case "rejeitada":
        return <Badge className="bg-red-100 text-red-800">Rejeitada</Badge>;
      case "recebida":
        return <Badge className="bg-purple-100 text-purple-800">Recebida</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Módulo de Compras e Estoque</h1>
          <p className="text-gray-500 mt-1">
            Gerencie o módulo de Compras e Estoque para as organizações
          </p>
        </div>
        
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <Settings className="w-4 h-4" />
            Configurações Gerais
          </Button>
          <Link to={createPageUrl("Organizations")}>
            <Button className="gap-2 bg-green-600 hover:bg-green-700">
              <PlusCircle className="w-4 h-4" />
              Nova Organização
            </Button>
          </Link>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="visao-geral">Visão Geral</TabsTrigger>
          <TabsTrigger value="organizacoes">Organizações</TabsTrigger>
          <TabsTrigger value="planos">Planos e Preços</TabsTrigger>
          <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
        </TabsList>

        <TabsContent value="visao-geral">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total de Organizações</CardTitle>
                <div className="text-3xl font-bold">
                  {loading ? "..." : metricas.total_organizacoes}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-xs text-gray-500">
                  <span className="flex items-center text-green-600">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    {loading ? "..." : metricas.organizacoes_ativas} organizações ativas
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total de Solicitações</CardTitle>
                <div className="text-3xl font-bold">
                  {loading ? "..." : metricas.total_solicitacoes}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-xs text-gray-500">
                  <span className="flex items-center text-green-600">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    Este mês
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Volume Total</CardTitle>
                <div className="text-3xl font-bold">
                  {loading ? "..." : formatCurrency(metricas.volume_total)}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-xs text-gray-500">
                  <span className="flex items-center text-green-600">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    +12% que o mês anterior
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Receita Mensal</CardTitle>
                <div className="text-3xl font-bold">
                  {loading ? "..." : formatCurrency((metricas.organizacoes_ativas * 299))}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-xs text-gray-500">
                  <span className="flex items-center text-green-600">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    Assinaturas ativas
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Ativações de Módulo</CardTitle>
                <CardDescription>
                  Número de organizações que ativaram o módulo por mês
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <div className="bg-gray-50 rounded-md p-4 h-full flex items-center justify-center">
                    <BarChart3 className="h-16 w-16 text-gray-300" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Volume de Compras</CardTitle>
                <CardDescription>
                  Volume total de compras processadas pelo módulo (R$)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <div className="bg-gray-50 rounded-md p-4 h-full flex items-center justify-center">
                    <BarChart className="h-16 w-16 text-gray-300" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Organizações Recentes</CardTitle>
                <CardDescription>
                  Últimas organizações que ativaram o módulo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Organização</TableHead>
                      <TableHead>Plano</TableHead>
                      <TableHead>Data de Ativação</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array(3).fill(0).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell className="animate-pulse">
                            <div className="h-5 bg-gray-200 rounded w-32"></div>
                          </TableCell>
                          <TableCell className="animate-pulse">
                            <div className="h-5 bg-gray-200 rounded w-20"></div>
                          </TableCell>
                          <TableCell className="animate-pulse">
                            <div className="h-5 bg-gray-200 rounded w-24"></div>
                          </TableCell>
                          <TableCell className="animate-pulse">
                            <div className="h-5 bg-gray-200 rounded w-16"></div>
                          </TableCell>
                          <TableCell className="animate-pulse">
                            <div className="h-5 bg-gray-200 rounded w-20"></div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      filteredOrganizacoes
                        .filter(org => org.ativo)
                        .sort((a, b) => new Date(b.data_ativacao) - new Date(a.data_ativacao))
                        .slice(0, 5)
                        .map(org => (
                          <TableRow key={org.id}>
                            <TableCell className="font-medium">{org.nome}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{org.plano}</Badge>
                            </TableCell>
                            <TableCell>{formatDate(org.data_ativacao)}</TableCell>
                            <TableCell>
                              <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                            </TableCell>
                            <TableCell>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleOpenConfig(org)}
                              >
                                Configurar
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                    )}
                  </TableBody>
                </Table>
                <div className="mt-4 flex justify-end">
                  <Link to="#" onClick={() => setActiveTab("organizacoes")}>
                    <Button variant="link" size="sm" className="gap-1">
                      Ver todas
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Últimas Atividades</CardTitle>
                <CardDescription>
                  Atividades recentes do módulo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-5">
                  {loading ? (
                    Array(5).fill(0).map((_, i) => (
                      <div key={i} className="flex gap-3 animate-pulse">
                        <div className="w-9 h-9 rounded-full bg-gray-200"></div>
                        <div className="space-y-2 flex-1">
                          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <>
                      <div className="flex gap-3">
                        <div className="w-9 h-9 bg-green-100 rounded-full flex items-center justify-center">
                          <CheckCircle2 className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Módulo ativado</p>
                          <p className="text-xs text-gray-500">
                            Green Medical Brasil • 2 horas atrás
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex gap-3">
                        <div className="w-9 h-9 bg-blue-100 rounded-full flex items-center justify-center">
                          <Settings className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Configurações atualizadas</p>
                          <p className="text-xs text-gray-500">
                            MediCannabis Farma • 5 horas atrás
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex gap-3">
                        <div className="w-9 h-9 bg-purple-100 rounded-full flex items-center justify-center">
                          <Building className="h-5 w-5 text-purple-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Fornecedor adicionado</p>
                          <p className="text-xs text-gray-500">
                            Associação Médica Verde • 1 dia atrás
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex gap-3">
                        <div className="w-9 h-9 bg-yellow-100 rounded-full flex items-center justify-center">
                          <AlertTriangle className="h-5 w-5 text-yellow-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Alerta de estoque</p>
                          <p className="text-xs text-gray-500">
                            Cannabis Brasil Sul • 1 dia atrás
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex gap-3">
                        <div className="w-9 h-9 bg-red-100 rounded-full flex items-center justify-center">
                          <CircleX className="h-5 w-5 text-red-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Módulo desativado</p>
                          <p className="text-xs text-gray-500">
                            CannaPesquisa Instituto • 2 dias atrás
                          </p>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="organizacoes">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Organizações</CardTitle>
                  <CardDescription>
                    Gerencie as organizações que utilizam o módulo de Compras
                  </CardDescription>
                </div>
                <div className="flex gap-3">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      placeholder="Buscar organização..."
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <select
                    className="px-3 py-2 border rounded-md text-sm"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                  >
                    <option value="all">Todos</option>
                    <option value="active">Ativos</option>
                    <option value="inactive">Inativos</option>
                  </select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Organização</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Plano</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Usuários</TableHead>
                    <TableHead>Fornecedores</TableHead>
                    <TableHead>Volume</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    Array(5).fill(0).map((_, i) => (
                      <TableRow key={i}>
                        <TableCell colSpan={8} className="h-12 animate-pulse">
                          <div className="h-5 bg-gray-200 rounded w-full"></div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : filteredOrganizacoes.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="h-24 text-center">
                        <Search className="mx-auto h-12 w-12 text-gray-200" />
                        <p className="mt-2 text-gray-500">Nenhuma organização encontrada</p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredOrganizacoes.map(org => (
                      <TableRow key={org.id}>
                        <TableCell className="font-medium">{org.nome}</TableCell>
                        <TableCell>{org.tipo}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{org.plano}</Badge>
                        </TableCell>
                        <TableCell>
                          {org.ativo ? (
                            <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                          ) : (
                            <Badge className="bg-gray-100 text-gray-800">Inativo</Badge>
                          )}
                        </TableCell>
                        <TableCell>{org.usuarios}</TableCell>
                        <TableCell>{org.fornecedores}</TableCell>
                        <TableCell>
                          {formatCurrency(org.valor_compras)}
                        </TableCell>
                        <TableCell className="text-right">
                          {org.ativo ? (
                            <div className="flex justify-end gap-2">
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleOpenConfig(org)}
                              >
                                Configurar
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                className="text-red-500 hover:text-red-700"
                                onClick={() => handleDeactivateModule(org.id)}
                              >
                                Desativar
                              </Button>
                            </div>
                          ) : (
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="text-green-500 hover:text-green-700"
                              onClick={() => handleActivateModule(org.id)}
                            >
                              Ativar
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="planos">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="overflow-hidden border-green-100">
              <CardHeader className="bg-green-50">
                <CardTitle>Plano Básico</CardTitle>
                <CardDescription>
                  Ideal para pequenas empresas e associações
                </CardDescription>
                <div className="mt-1">
                  <span className="text-3xl font-bold">R$ 299</span>
                  <span className="text-sm text-gray-500">/mês</span>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <ul className="space-y-3">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <span>Até 10 usuários</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <span>Até 30 fornecedores</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <span>Até 500 itens de estoque</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <span>Sistema de cotação automática</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <span>Portal de fornecedores</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <span>Gestão de solicitações de compra</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                    <span>Alerta de estoque baixo</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter className="flex justify-between border-t pt-6">
                <Button variant="outline">Editar Plano</Button>
                <Button className="bg-green-600 hover:bg-green-700">Definir como Padrão</Button>
              </CardFooter>
            </Card>

            <Card className="overflow-hidden border-purple-100">
              <CardHeader className="bg-purple-50">
                <CardTitle>Plano Premium</CardTitle>
                <CardDescription>
                  Para empresas de médio e grande porte
                </CardDescription>
                <div className="mt-1">
                  <span className="text-3xl font-bold">R$ 599</span>
                  <span className="text-sm text-gray-500">/mês</span>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <ul className="space-y-3">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-purple-500" />
                    <span>Usuários ilimitados</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-purple-500" />
                    <span>Fornecedores ilimitados</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-purple-500" />
                    <span>Itens de estoque ilimitados</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-purple-500" />
                    <span>Sistema de cotação avançado</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-purple-500" />
                    <span>Portal completo de fornecedores</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-purple-500" />
                    <span>Gestão de fornecedores avançada</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-purple-500" />
                    <span>Integração com módulo financeiro</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-purple-500" />
                    <span>Dashboard analítico avançado</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-purple-500" />
                    <span>Histórico completo de preços</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-purple-500" />
                    <span>Relatórios personalizados</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter className="flex justify-between border-t pt-6">
                <Button variant="outline">Editar Plano</Button>
                <Button className="bg-purple-600 hover:bg-purple-700">Definir como Padrão</Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="configuracoes">
          <Card>
            <CardHeader>
              <CardTitle>Configurações Globais</CardTitle>
              <CardDescription>
                Defina as configurações padrão para todas as organizações que usam o módulo de Compras
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>Configurações Gerais</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 p-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="custom-fields">Permitir campos personalizados</Label>
                          <p className="text-sm text-gray-500">
                            Organizações podem criar campos personalizados
                          </p>
                        </div>
                        <Switch id="custom-fields" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="auto-notifications">Notificações automáticas</Label>
                          <p className="text-sm text-gray-500">
                            Enviar notificações automáticas sobre solicitações e estoque
                          </p>
                        </div>
                        <Switch id="auto-notifications" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="daily-reports">Relatórios diários</Label>
                          <p className="text-sm text-gray-500">
                            Gerar relatórios diários automaticamente
                          </p>
                        </div>
                        <Switch id="daily-reports" />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-2">
                  <AccordionTrigger>Plano Básico</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 p-2">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="basic-price">Preço mensal (R$)</Label>
                          <Input id="basic-price" defaultValue="299" />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="basic-users">Máximo de usuários</Label>
                          <Input id="basic-users" defaultValue="10" />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="basic-suppliers">Máximo de fornecedores</Label>
                          <Input id="basic-suppliers" defaultValue="30" />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="basic-items">Máximo de itens no estoque</Label>
                          <Input id="basic-items" defaultValue="500" />
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between pt-2">
                        <div>
                          <Label htmlFor="basic-financial">Integração financeira</Label>
                          <p className="text-sm text-gray-500">
                            Permitir integração com módulo financeiro
                          </p>
                        </div>
                        <Switch id="basic-financial" />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-3">
                  <AccordionTrigger>Plano Premium</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 p-2">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="premium-price">Preço mensal (R$)</Label>
                          <Input id="premium-price" defaultValue="599" />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="premium-auto-approval">Aprovação automática até (R$)</Label>
                          <Input id="premium-auto-approval" defaultValue="5000" />
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between pt-2">
                        <div>
                          <Label htmlFor="premium-financial">Integração financeira</Label>
                          <p className="text-sm text-gray-500">
                            Permitir integração com módulo financeiro
                          </p>
                        </div>
                        <Switch id="premium-financial" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="premium-payments">Integração com pagamentos</Label>
                          <p className="text-sm text-gray-500">
                            Permitir integração com meios de pagamento
                          </p>
                        </div>
                        <Switch id="premium-payments" defaultChecked />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-4">
                  <AccordionTrigger>Configurações de Segurança</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 p-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="security-approval">Aprovação multi-nível</Label>
                          <p className="text-sm text-gray-500">
                            Exigir aprovação de múltiplos usuários para compras de alto valor
                          </p>
                        </div>
                        <Switch id="security-approval" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="security-audit">Registro de auditoria</Label>
                          <p className="text-sm text-gray-500">
                            Manter registro detalhado de todas as ações
                          </p>
                        </div>
                        <Switch id="security-audit" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <Label htmlFor="security-limit">Limite de valor por solicitação</Label>
                          <p className="text-sm text-gray-500">
                            Limitar o valor máximo para solicitações
                          </p>
                        </div>
                        <Switch id="security-limit" />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
              
              <div className="mt-6 flex justify-end gap-2">
                <Button variant="outline">Restaurar Padrões</Button>
                <Button className="bg-green-600 hover:bg-green-700">Salvar Alterações</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {selectedOrg && (
        <Dialog open={configDialog} onOpenChange={setConfigDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Configurações do Módulo</DialogTitle>
              <DialogDescription>
                Configure o módulo de Compras para {selectedOrg.nome}
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4 space-y-4">
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="px-3 py-1 text-base">
                  {selectedOrg.plano === "Básico" ? "Plano Básico" : "Plano Premium"}
                </Badge>
                <Button variant="outline" size="sm">Alterar Plano</Button>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Limites</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="users-limit">Limite de usuários</Label>
                    <Input 
                      id="users-limit" 
                      defaultValue={
                        selectedOrg.plano === "Básico" 
                          ? configuracoesModulo.basico.usuarios_max 
                          : configuracoesModulo.premium.usuarios_max
                      } 
                      disabled={selectedOrg.plano === "Premium"}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="suppliers-limit">Limite de fornecedores</Label>
                    <Input 
                      id="suppliers-limit" 
                      defaultValue={
                        selectedOrg.plano === "Básico" 
                          ? configuracoesModulo.basico.fornecedores_max 
                          : configuracoesModulo.premium.fornecedores_max
                      }
                      disabled={selectedOrg.plano === "Premium"}
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Configurações de Aprovação</h3>
                <div className="space-y-2">
                  <Label htmlFor="auto-approval">Valor limite para aprovação automática (R$)</Label>
                  <Input 
                    id="auto-approval" 
                    defaultValue={
                      selectedOrg.plano === "Básico" 
                        ? configuracoesModulo.basico.valor_aprovacao_automatica 
                        : configuracoesModulo.premium.valor_aprovacao_automatica
                    }
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="multi-approval">Exigir aprovação multi-nível</Label>
                    <p className="text-sm text-gray-500">
                      Para valores acima do limite, exigir aprovação de múltiplos usuários
                    </p>
                  </div>
                  <Switch id="multi-approval" />
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Integrações</h3>
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="financial-integration">Integração com módulo financeiro</Label>
                    <p className="text-sm text-gray-500">
                      Conectar com o módulo financeiro para controle de pagamentos
                    </p>
                  </div>
                  <Switch 
                    id="financial-integration" 
                    disabled={selectedOrg.plano === "Básico"}
                    defaultChecked={selectedOrg.plano === "Premium"}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="payment-integration">Integração com meios de pagamento</Label>
                    <p className="text-sm text-gray-500">
                      Permitir pagamentos diretos para fornecedores
                    </p>
                  </div>
                  <Switch 
                    id="payment-integration" 
                    disabled={selectedOrg.plano === "Básico"}
                    defaultChecked={selectedOrg.plano === "Premium"}
                  />
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setConfigDialog(false)}>
                Cancelar
              </Button>
              <Button className="bg-green-600 hover:bg-green-700" onClick={handleSaveConfig}>
                Salvar Configurações
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
