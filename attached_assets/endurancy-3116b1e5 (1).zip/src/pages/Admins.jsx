import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Search, 
  UserPlus, 
  Calendar, 
  Mail, 
  Shield, 
  Lock, 
  Key, 
  X, 
  CheckCircle, 
  AlertTriangle,
  User,
  MoreHorizontal,
  LogIn,
  Plus,
  Check,
  UserX,
  UserCog
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Sample admin users data
const adminsData = [
  {
    id: 1,
    name: 'João Silva',
    email: 'joao.silva@endurancy.com',
    role: 'super_admin',
    status: 'active',
    last_login: '2023-07-21T10:30:00Z',
    created_date: '2022-11-15T14:30:00Z',
    permissions: ['dashboard', 'organizations', 'requests', 'users', 'reports', 'audit', 'settings', 'system'],
    two_factor: true
  },
  {
    id: 2,
    name: 'Maria Oliveira',
    email: 'maria@endurancy.com',
    role: 'admin',
    status: 'active',
    last_login: '2023-07-20T16:45:00Z',
    created_date: '2023-01-10T09:15:00Z',
    permissions: ['dashboard', 'organizations', 'requests', 'users', 'reports', 'audit'],
    two_factor: true
  },
  {
    id: 3,
    name: 'Carlos Santos',
    email: 'carlos@endurancy.com',
    role: 'support_admin',
    status: 'active',
    last_login: '2023-07-19T14:20:00Z',
    created_date: '2023-02-05T11:45:00Z',
    permissions: ['dashboard', 'organizations', 'requests', 'users'],
    two_factor: false
  },
  {
    id: 4,
    name: 'Ana Costa',
    email: 'ana@endurancy.com',
    role: 'security_admin',
    status: 'active',
    last_login: '2023-07-19T11:10:00Z',
    created_date: '2023-03-20T10:30:00Z',
    permissions: ['dashboard', 'audit', 'settings', 'system'],
    two_factor: true
  },
  {
    id: 5,
    name: 'Roberto Mendes',
    email: 'roberto@endurancy.com',
    role: 'support_admin',
    status: 'suspended',
    last_login: '2023-07-01T09:45:00Z',
    created_date: '2023-04-15T14:20:00Z',
    suspended_reason: 'Licença temporária',
    permissions: ['dashboard', 'organizations', 'requests'],
    two_factor: false
  },
  {
    id: 6,
    name: 'Fernanda Almeida',
    email: 'fernanda@endurancy.com',
    role: 'audit_admin',
    status: 'invited',
    created_date: '2023-07-18T16:30:00Z',
    permissions: ['dashboard', 'audit'],
    two_factor: false
  }
];

// Sample roles data
const rolesData = [
  {
    id: 'super_admin',
    name: 'Super Administrador',
    description: 'Acesso completo a todas as funcionalidades do sistema',
    permissions: ['dashboard', 'organizations', 'requests', 'users', 'reports', 'audit', 'settings', 'system']
  },
  {
    id: 'admin',
    name: 'Administrador',
    description: 'Gerencia organizações, usuários e relatórios',
    permissions: ['dashboard', 'organizations', 'requests', 'users', 'reports', 'audit']
  },
  {
    id: 'support_admin',
    name: 'Administrador de Suporte',
    description: 'Gerencia solicitações e dá suporte a organizações',
    permissions: ['dashboard', 'organizations', 'requests', 'users']
  },
  {
    id: 'security_admin',
    name: 'Administrador de Segurança',
    description: 'Supervisiona segurança e auditoria do sistema',
    permissions: ['dashboard', 'audit', 'settings', 'system']
  },
  {
    id: 'audit_admin',
    name: 'Administrador de Auditoria',
    description: 'Acesso somente leitura para auditoria',
    permissions: ['dashboard', 'audit']
  }
];

// Permissions data
const permissionsData = [
  { id: 'dashboard', name: 'Dashboard', description: 'Acesso ao dashboard' },
  { id: 'organizations', name: 'Organizações', description: 'Gerenciar organizações' },
  { id: 'requests', name: 'Solicitações', description: 'Gerenciar solicitações' },
  { id: 'users', name: 'Usuários', description: 'Gerenciar usuários' },
  { id: 'reports', name: 'Relatórios', description: 'Acessar e gerar relatórios' },
  { id: 'audit', name: 'Auditoria', description: 'Acessar logs de auditoria' },
  { id: 'settings', name: 'Configurações', description: 'Alterar configurações do sistema' },
  { id: 'system', name: 'Sistema', description: 'Acesso a funções críticas do sistema' }
];

const roleColors = {
  'super_admin': 'bg-purple-100 text-purple-800',
  'admin': 'bg-blue-100 text-blue-800',
  'support_admin': 'bg-green-100 text-green-800',
  'security_admin': 'bg-red-100 text-red-800',
  'audit_admin': 'bg-orange-100 text-orange-800'
};

const statusColors = {
  'active': 'bg-green-100 text-green-800',
  'suspended': 'bg-red-100 text-red-800',
  'invited': 'bg-yellow-100 text-yellow-800'
};

export default function Admins() {
  const [admins, setAdmins] = useState(adminsData);
  const [roles, setRoles] = useState(rolesData);
  const [filteredAdmins, setFilteredAdmins] = useState(adminsData);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditRoleDialog, setShowEditRoleDialog] = useState(false);
  const [currentRole, setCurrentRole] = useState(null);
  const [newAdmin, setNewAdmin] = useState({
    name: '',
    email: '',
    role: 'admin',
    require_two_factor: true
  });
  const [activeTab, setActiveTab] = useState('admins');
  
  // Filter admins based on search term, role, and status
  const applyFilters = () => {
    let filtered = [...admins];
    
    if (searchTerm.trim() !== '') {
      filtered = filtered.filter(admin => 
        admin.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        admin.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (roleFilter !== 'all') {
      filtered = filtered.filter(admin => admin.role === roleFilter);
    }
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(admin => admin.status === statusFilter);
    }
    
    setFilteredAdmins(filtered);
  };
  
  // Update filters when search term, role filter, or status filter changes
  React.useEffect(() => {
    applyFilters();
  }, [searchTerm, roleFilter, statusFilter, admins]);
  
  const handleAddAdmin = () => {
    // In a real implementation, this would call an API to create the admin
    const newAdminObj = {
      id: Math.max(...admins.map(a => a.id)) + 1,
      name: newAdmin.name,
      email: newAdmin.email,
      role: newAdmin.role,
      status: 'invited',
      created_date: new Date().toISOString(),
      permissions: roles.find(r => r.id === newAdmin.role)?.permissions || [],
      two_factor: newAdmin.require_two_factor
    };
    
    setAdmins([...admins, newAdminObj]);
    setShowAddDialog(false);
    setNewAdmin({
      name: '',
      email: '',
      role: 'admin',
      require_two_factor: true
    });
  };
  
  const handleSuspendAdmin = (adminId) => {
    setAdmins(admins.map(admin => 
      admin.id === adminId 
        ? {...admin, status: admin.status === 'suspended' ? 'active' : 'suspended'} 
        : admin
    ));
  };
  
  const handleEditRole = (role) => {
    setCurrentRole({...role, permissions: [...role.permissions]});
    setShowEditRoleDialog(true);
  };
  
  const handleSaveRole = () => {
    setRoles(roles.map(role => 
      role.id === currentRole.id ? currentRole : role
    ));
    setShowEditRoleDialog(false);
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  const getRoleName = (roleId) => {
    const role = roles.find(r => r.id === roleId);
    return role ? role.name : roleId;
  };
  
  const getInitials = (name) => {
    if (!name) return 'U';
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Administradores</h1>
          <p className="text-gray-500 mt-1">
            Gerencie usuários com acesso administrativo ao sistema
          </p>
        </div>
        <Button 
          className="gap-2 bg-green-600 hover:bg-green-700"
          onClick={() => setShowAddDialog(true)}
        >
          <UserPlus className="w-4 h-4" />
          Novo Administrador
        </Button>
      </div>

      <Tabs defaultValue="admins" onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="admins">Administradores</TabsTrigger>
          <TabsTrigger value="roles">Funções</TabsTrigger>
          <TabsTrigger value="permissions">Permissões</TabsTrigger>
        </TabsList>
        
        <TabsContent value="admins" className="space-y-4 mt-6">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div className="relative md:w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar administradores..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex gap-3">
              <Select 
                defaultValue="all" 
                onValueChange={setRoleFilter}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filtrar por função" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas Funções</SelectItem>
                  {roles.map(role => (
                    <SelectItem key={role.id} value={role.id}>{role.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select 
                defaultValue="all" 
                onValueChange={setStatusFilter}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos Status</SelectItem>
                  <SelectItem value="active">Ativos</SelectItem>
                  <SelectItem value="suspended">Suspensos</SelectItem>
                  <SelectItem value="invited">Convidados</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Administrador</TableHead>
                    <TableHead>Função</TableHead>
                    <TableHead>Autenticação</TableHead>
                    <TableHead>Último Acesso</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAdmins.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-10">
                        <User className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                        <h3 className="text-lg font-medium text-gray-900">Nenhum administrador encontrado</h3>
                        <p className="text-gray-500 mt-1">
                          {searchTerm || roleFilter !== 'all' || statusFilter !== 'all' 
                            ? 'Tente ajustar os critérios de busca' 
                            : 'Adicione administradores clicando no botão acima'}
                        </p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredAdmins.map(admin => (
                      <TableRow key={admin.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarFallback>{getInitials(admin.name)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{admin.name}</p>
                              <p className="text-sm text-gray-500">{admin.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={roleColors[admin.role]}>
                            {getRoleName(admin.role)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {admin.two_factor ? (
                            <Badge className="bg-green-100 text-green-800">
                              <Shield className="w-3 h-3 mr-1" />
                              2FA Habilitado
                            </Badge>
                          ) : (
                            <Badge variant="outline">
                              Apenas senha
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {admin.last_login ? (
                            <div className="flex items-center gap-1 text-sm">
                              <Calendar className="w-4 h-4 text-gray-400" />
                              {formatDate(admin.last_login)}
                            </div>
                          ) : (
                            <span className="text-gray-500 text-sm">Nunca acessou</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge className={statusColors[admin.status]}>
                            {admin.status === 'active' && (
                              <CheckCircle className="w-3 h-3 mr-1" />
                            )}
                            {admin.status === 'suspended' && (
                              <X className="w-3 h-3 mr-1" />
                            )}
                            {admin.status === 'invited' && (
                              <Mail className="w-3 h-3 mr-1" />
                            )}
                            {admin.status === 'active' && 'Ativo'}
                            {admin.status === 'suspended' && 'Suspenso'}
                            {admin.status === 'invited' && 'Convidado'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Ações</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <User className="w-4 h-4 mr-2" />
                                Editar Perfil
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Key className="w-4 h-4 mr-2" />
                                Redefinir Senha
                              </DropdownMenuItem>
                              {admin.status === 'invited' && (
                                <DropdownMenuItem>
                                  <Mail className="w-4 h-4 mr-2" />
                                  Reenviar Convite
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              {admin.status !== 'suspended' ? (
                                <DropdownMenuItem className="text-red-600" onClick={() => handleSuspendAdmin(admin.id)}>
                                  <UserX className="w-4 h-4 mr-2" />
                                  Suspender Acesso
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem className="text-green-600" onClick={() => handleSuspendAdmin(admin.id)}>
                                  <UserCog className="w-4 h-4 mr-2" />
                                  Reativar Acesso
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="roles" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {roles.map(role => (
              <Card key={role.id}>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className={roleColors[role.id]}>
                        {role.name}
                      </Badge>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => handleEditRole(role)}>
                      Editar
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-500 mb-4">{role.description}</p>
                  
                  <h4 className="text-sm font-semibold mb-2">Permissões</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {role.permissions.map(perm => {
                      const permission = permissionsData.find(p => p.id === perm);
                      return (
                        <div key={perm} className="flex items-center gap-2">
                          <Check className="w-4 h-4 text-green-500" />
                          <span className="text-sm">{permission?.name || perm}</span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="permissions" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Permissões do Sistema</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Permissão</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Funções com Acesso</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {permissionsData.map(permission => (
                    <TableRow key={permission.id}>
                      <TableCell className="font-medium">{permission.name}</TableCell>
                      <TableCell>{permission.description}</TableCell>
                      <TableCell>
                        <div className="flex gap-2 flex-wrap">
                          {roles
                            .filter(role => role.permissions.includes(permission.id))
                            .map(role => (
                              <Badge key={role.id} className={roleColors[role.id]}>
                                {role.name}
                              </Badge>
                            ))
                          }
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Admin Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Adicionar Novo Administrador</DialogTitle>
            <DialogDescription>
              Convide um novo usuário como administrador do sistema
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome Completo</Label>
              <Input
                id="name"
                placeholder="Nome do administrador"
                value={newAdmin.name}
                onChange={(e) => setNewAdmin({...newAdmin, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="email@exemplo.com"
                value={newAdmin.email}
                onChange={(e) => setNewAdmin({...newAdmin, email: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">Função</Label>
              <Select
                value={newAdmin.role}
                onValueChange={(value) => setNewAdmin({...newAdmin, role: value})}
              >
                <SelectTrigger id="role">
                  <SelectValue placeholder="Selecione a função" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map(role => (
                    <SelectItem key={role.id} value={role.id}>{role.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-sm text-gray-500 mt-1">
                {roles.find(r => r.id === newAdmin.role)?.description}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="two-factor"
                checked={newAdmin.require_two_factor}
                onCheckedChange={(checked) => setNewAdmin({...newAdmin, require_two_factor: checked})}
              />
              <Label htmlFor="two-factor">Exigir autenticação de dois fatores</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancelar</Button>
            <Button 
              onClick={handleAddAdmin}
              disabled={!newAdmin.name || !newAdmin.email}
              className="gap-2"
            >
              <Mail className="w-4 h-4" />
              Enviar Convite
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Role Dialog */}
      <Dialog open={showEditRoleDialog} onOpenChange={setShowEditRoleDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Função</DialogTitle>
            <DialogDescription>
              Modifique as permissões da função {currentRole?.name}
            </DialogDescription>
          </DialogHeader>
          {currentRole && (
            <div className="py-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="role-name">Nome da Função</Label>
                  <Input
                    id="role-name"
                    value={currentRole.name}
                    onChange={(e) => setCurrentRole({...currentRole, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role-description">Descrição</Label>
                  <Input
                    id="role-description"
                    value={currentRole.description}
                    onChange={(e) => setCurrentRole({...currentRole, description: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-base">Permissões</Label>
                  <div className="grid grid-cols-1 gap-3">
                    {permissionsData.map(permission => (
                      <div key={permission.id} className="flex items-center space-x-2">
                        <Switch
                          id={`perm-${permission.id}`}
                          checked={currentRole.permissions.includes(permission.id)}
                          onCheckedChange={(checked) => {
                            const newPermissions = checked
                              ? [...currentRole.permissions, permission.id]
                              : currentRole.permissions.filter(p => p !== permission.id);
                            setCurrentRole({...currentRole, permissions: newPermissions});
                          }}
                        />
                        <div className="grid gap-1.5">
                          <Label htmlFor={`perm-${permission.id}`}>{permission.name}</Label>
                          <p className="text-sm text-gray-500">{permission.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditRoleDialog(false)}>Cancelar</Button>
            <Button onClick={handleSaveRole}>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}