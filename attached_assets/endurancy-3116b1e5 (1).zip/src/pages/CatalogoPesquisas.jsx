import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Search,
  Filter,
  Plus,
  FileText,
  Calendar,
  Users,
  Brain,
  Microscope,
  ExternalLink,
  Eye,
  Edit,
  Trash2
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function CatalogoPesquisas() {
  const [pesquisas, setPesquisas] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [areaFilter, setAreaFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);

  // Mock data
  const mockPesquisas = [
    {
      id: 1,
      titulo: "Eficácia do CBD no tratamento da epilepsia refratária",
      area: "Neurologia",
      status: "em_andamento",
      pesquisador_principal: "Dra. Maria Silva",
      participantes: 45,
      data_inicio: "2024-01-15",
      descricao: "Estudo clínico randomizado sobre os efeitos do CBD em pacientes com epilepsia refratária."
    },
    // Add more mock research entries...
  ];

  useEffect(() => {
    const loadPesquisas = async () => {
      setIsLoading(true);
      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        setPesquisas(mockPesquisas);
      } catch (error) {
        console.error("Erro ao carregar pesquisas:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadPesquisas();
  }, []);

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Catálogo de Pesquisas</h1>
          <p className="text-muted-foreground">Explore todas as pesquisas científicas</p>
        </div>
        <Link to={createPageUrl("NovaPesquisa")}>
          <Button className="bg-green-600 hover:bg-green-700">
            <Plus className="w-4 h-4 mr-2" />
            Nova Pesquisa
          </Button>
        </Link>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar pesquisas..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={areaFilter} onValueChange={setAreaFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Área de Pesquisa" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as Áreas</SelectItem>
            <SelectItem value="neurologia">Neurologia</SelectItem>
            <SelectItem value="psiquiatria">Psiquiatria</SelectItem>
            {/* Add more areas */}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Status</SelectItem>
            <SelectItem value="em_andamento">Em Andamento</SelectItem>
            <SelectItem value="concluida">Concluída</SelectItem>
            {/* Add more status options */}
          </SelectContent>
        </Select>
      </div>

      {/* Research Cards */}
      <div className="grid grid-cols-1 gap-6">
        {isLoading ? (
          // Loading skeleton
          <div>Carregando...</div>
        ) : (
          pesquisas.map((pesquisa) => (
            <Card key={pesquisa.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{pesquisa.titulo}</CardTitle>
                    <CardDescription>Área: {pesquisa.area}</CardDescription>
                  </div>
                  <Badge
                    variant={
                      pesquisa.status === "em_andamento" ? "default" :
                      pesquisa.status === "concluida" ? "success" :
                      "secondary"
                    }
                  >
                    {pesquisa.status === "em_andamento" ? "Em Andamento" :
                     pesquisa.status === "concluida" ? "Concluída" :
                     "Em Análise"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">{pesquisa.descricao}</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-gray-400" />
                    <span className="text-sm">
                      {pesquisa.participantes} participantes
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <span className="text-sm">
                      Início: {new Date(pesquisa.data_inicio).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Brain className="w-4 h-4 text-gray-400" />
                    <span className="text-sm">
                      {pesquisa.pesquisador_principal}
                    </span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2">
                <Button variant="outline" size="sm">
                  <Eye className="w-4 h-4 mr-2" />
                  Visualizar
                </Button>
                <Button variant="outline" size="sm">
                  <Edit className="w-4 h-4 mr-2" />
                  Editar
                </Button>
                <Button variant="ghost" size="sm" className="text-red-600">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </CardFooter>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}