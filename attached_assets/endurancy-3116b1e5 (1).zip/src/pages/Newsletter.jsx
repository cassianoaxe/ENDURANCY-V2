import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "@/components/ui/use-toast";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import ReactQuill from 'react-quill';
import { format } from 'date-fns';
import {
  Send,
  Plus,
  FileText,
  Users,
  Search,
  Calendar,
  ChevronRight,
  ArrowUpRight,
  Clock,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Edit,
  Trash2,
  Eye,
  MoreHorizontal,
  Mail,
  ChartBar,
  Download,
  CalendarIcon,
  ArrowRight,
  Copy,
  ClipboardCheck,
  RefreshCw,
  Globe,
  PlusCircle,
  InfoIcon,
  Building2,
  PlayCircle,
  User,
  UserCheck,
  Repeat,
  BarChart,
  LinkIcon,
  Image,
  BellRing
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Organization } from "@/api/entities";

// Configurações do editor Quill
const editorModules = {
  toolbar: [
    [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ 'list': 'ordered'}, { 'list': 'bullet' }],
    [{ 'indent': '-1'}, { 'indent': '+1' }],
    [{ 'align': [] }],
    ['link', 'image'],
    ['clean']
  ],
};

// Dados simulados para newsletters
const mockNewsletters = [
  {
    id: "1",
    title: "Novidades Regulatórias - Janeiro 2024",
    status: "enviado",
    sent_date: "2024-01-15T10:30:00Z",
    recipients: 356,
    open_rate: 68,
    click_rate: 42,
    created_by: "Admin",
    created_date: "2024-01-10T14:20:00Z"
  },
  {
    id: "2",
    title: "Atualizações da Plataforma - Versão 2.5",
    status: "enviado",
    sent_date: "2024-01-05T09:15:00Z",
    recipients: 412,
    open_rate: 75,
    click_rate: 50,
    created_by: "Admin",
    created_date: "2024-01-03T11:30:00Z"
  },
  {
    id: "3",
    title: "Boletim Científico - Novos Estudos",
    status: "rascunho",
    recipients: 0,
    open_rate: 0,
    click_rate: 0,
    created_by: "Admin",
    created_date: "2024-01-20T16:45:00Z"
  },
  {
    id: "4",
    title: "Convite para Webinar - Produtos Canábicos",
    status: "agendado",
    scheduled_date: "2024-02-05T15:00:00Z",
    recipients: 420,
    open_rate: 0,
    click_rate: 0,
    created_by: "Admin",
    created_date: "2024-01-25T13:10:00Z"
  },
  {
    id: "5",
    title: "Newsletter Mensal - Fevereiro 2024",
    status: "recorrente",
    next_run: "2024-02-01T09:00:00Z",
    frequency: "mensal",
    recipients: 450,
    created_by: "Admin",
    created_date: "2024-01-15T13:00:00Z",
    open_rate: 0,
    click_rate: 0
  }
];

// Dados simulados para listas
const mockLists = [
  {
    id: "1",
    name: "Todas Organizações",
    type: "automático",
    subscribers: 412,
    description: "Todas as organizações ativas na plataforma",
    last_updated: "2024-01-20T10:30:00Z",
    criteria: { status: "Ativo" }
  },
  {
    id: "2",
    name: "Empresas Farmacêuticas",
    type: "manual",
    subscribers: 156,
    description: "Organizações do tipo empresa no setor farmacêutico",
    last_updated: "2024-01-15T14:45:00Z",
    members: ["org1", "org2", "org3"]
  },
  {
    id: "3",
    name: "Associações de Pacientes",
    type: "manual",
    subscribers: 87,
    description: "Associações de pacientes cadastradas",
    last_updated: "2024-01-10T09:20:00Z",
    members: ["org4", "org5"]
  },
  {
    id: "4",
    name: "Administradores",
    type: "automático",
    subscribers: 45,
    description: "Todos os usuários com perfil de administrador",
    last_updated: "2024-01-22T11:15:00Z",
    criteria: { role: "admin" }
  }
];

// Dados simulados para templates
const mockTemplates = [
  {
    id: "1",
    name: "Template Padrão",
    description: "Template básico com cabeçalho e rodapé",
    preview_url: "https://via.placeholder.com/800x600.png?text=Template+Padrão",
    created_date: "2023-12-05T14:30:00Z",
    updated_date: "2024-01-10T09:15:00Z"
  },
  {
    id: "2",
    name: "Boletim Informativo",
    description: "Layout para newsletters mensais",
    preview_url: "https://via.placeholder.com/800x600.png?text=Boletim+Informativo",
    created_date: "2023-11-20T11:45:00Z",
    updated_date: "2024-01-15T10:30:00Z"
  },
  {
    id: "3",
    name: "Anúncio de Webinar",
    description: "Template para divulgação de webinars e eventos",
    preview_url: "https://via.placeholder.com/800x600.png?text=Anúncio+de+Webinar",
    created_date: "2024-01-02T15:20:00Z",
    updated_date: "2024-01-02T15:20:00Z"
  }
];

// Estatísticas simuladas para análise
const mockAnalytics = {
  open_rate_by_month: [
    { month: "Set", rate: 58 },
    { month: "Out", rate: 62 },
    { month: "Nov", rate: 65 },
    { month: "Dez", rate: 60 },
    { month: "Jan", rate: 68 }
  ],
  click_rate_by_month: [
    { month: "Set", rate: 32 },
    { month: "Out", rate: 38 },
    { month: "Nov", rate: 41 },
    { month: "Dez", rate: 39 },
    { month: "Jan", rate: 42 }
  ],
  top_campaigns: [
    { id: "1", title: "Novidades Regulatórias - Janeiro 2024", open_rate: 68, click_rate: 42 },
    { id: "2", title: "Atualizações da Plataforma - Versão 2.5", open_rate: 75, click_rate: 50 },
    { id: "old3", title: "Webinar: Novos Regulamentos", open_rate: 82, click_rate: 61 }
  ],
  device_usage: [
    { device: "Desktop", percentage: 65 },
    { device: "Mobile", percentage: 30 },
    { device: "Tablet", percentage: 5 }
  ],
  time_analysis: [
    { hour: "8h", open_rate: 42 },
    { hour: "10h", open_rate: 58 },
    { hour: "12h", open_rate: 45 },
    { hour: "14h", open_rate: 51 },
    { hour: "16h", open_rate: 67 },
    { hour: "18h", open_rate: 70 },
    { hour: "20h", open_rate: 49 }
  ]
};

export default function Newsletter() {
  const [activeTab, setActiveTab] = useState("campanhas");
  const [newsletters, setNewsletters] = useState(mockNewsletters);
  const [lists, setLists] = useState(mockLists);
  const [templates, setTemplates] = useState(mockTemplates);
  const [analytics, setAnalytics] = useState(mockAnalytics);
  const [organizations, setOrganizations] = useState([]);
  
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedNewsletter, setSelectedNewsletter] = useState(null);
  const [selectedList, setSelectedList] = useState(null);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showScheduleDialog, setShowScheduleDialog] = useState(false);
  const [showListDialog, setShowListDialog] = useState(false);
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);
  const [showPreviewDialog, setShowPreviewDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showRecurringDialog, setShowRecurringDialog] = useState(false);
  
  const [createStep, setCreateStep] = useState(1);
  const [campaignType, setCampaignType] = useState("regular");
  const [isLoading, setIsLoading] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    title: "",
    subject: "",
    content: "",
    template_id: "",
    lists: [],
    sender_name: "Endurancy",
    sender_email: "contato@endurancy.com.br",
    schedule: false,
    scheduled_date: new Date().toISOString().split('T')[0],
    scheduled_time: "09:00",
    tracking: true,
    is_recurring: false,
    recurring_type: "monthly",
    recurring_day: "1",
    recurring_hour: "09:00"
  });
  
  const [listFormData, setListFormData] = useState({
    name: "",
    description: "",
    type: "manual",
    criteria: { status: "Ativo" },
    members: []
  });
  
  useEffect(() => {
    loadOrganizations();
  }, []);
  
  const loadOrganizations = async () => {
    try {
      const orgs = await Organization.list();
      setOrganizations(orgs);
    } catch (error) {
      console.error("Error loading organizations:", error);
      toast({
        title: "Erro ao carregar organizações",
        description: "Não foi possível carregar a lista de organizações.",
        variant: "destructive"
      });
    }
  };
  
  // Função para filtrar newsletters
  const filteredNewsletters = newsletters.filter(newsletter => {
    const matchesSearch = newsletter.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || newsletter.status === statusFilter;
    return matchesSearch && matchesStatus;
  });
  
  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return format(date, 'dd/MM/yyyy HH:mm');
    } catch (e) {
      return "Data inválida";
    }
  };
  
  const getStatusLabel = (status) => {
    switch (status) {
      case "enviado": return "Enviado";
      case "agendado": return "Agendado";
      case "rascunho": return "Rascunho";
      case "recorrente": return "Recorrente";
      default: return status.charAt(0).toUpperCase() + status.slice(1);
    }
  };
  
  // Manipuladores de eventos
  const handleCreateNewsletter = () => {
    // Criar nova newsletter com base no formulário
    const newId = `new${Date.now()}`;
    const newNewsletter = {
      id: newId,
      title: formData.title,
      status: formData.schedule ? "agendado" : (formData.is_recurring ? "recorrente" : "rascunho"),
      created_by: "Admin",
      created_date: new Date().toISOString(),
      recipients: formData.lists.reduce((total, listId) => {
        const list = lists.find(l => l.id === listId);
        return total + (list ? list.subscribers : 0);
      }, 0),
      open_rate: 0,
      click_rate: 0
    };
    
    if (formData.schedule) {
      const scheduledDateTime = `${formData.scheduled_date}T${formData.scheduled_time}:00`;
      newNewsletter.scheduled_date = new Date(scheduledDateTime).toISOString();
    }
    
    if (formData.is_recurring) {
      newNewsletter.frequency = formData.recurring_type;
      newNewsletter.next_run = new Date().toISOString(); // Simulação
    }
    
    setNewsletters([newNewsletter, ...newsletters]);
    resetForm();
    setShowCreateDialog(false);
    setCreateStep(1);
    
    toast({
      title: "Newsletter criada com sucesso",
      description: formData.schedule 
        ? "A newsletter foi agendada para envio." 
        : (formData.is_recurring 
          ? "A newsletter recorrente foi configurada." 
          : "A newsletter foi salva como rascunho."),
    });
  };
  
  const handleSendNow = (newsletter) => {
    // Simular envio imediato
    setIsLoading(true);
    setTimeout(() => {
      const updatedNewsletters = newsletters.map(n => {
        if (n.id === newsletter.id) {
          return {
            ...n,
            status: "enviado",
            sent_date: new Date().toISOString()
          };
        }
        return n;
      });
      
      setNewsletters(updatedNewsletters);
      setIsLoading(false);
      
      toast({
        title: "Newsletter enviada com sucesso",
        description: `${newsletter.title} foi enviada para ${newsletter.recipients} destinatários.`,
      });
    }, 2000);
  };
  
  const handleSchedule = (newsletter) => {
    setSelectedNewsletter(newsletter);
    setFormData({
      ...formData,
      scheduled_date: new Date().toISOString().split('T')[0],
      scheduled_time: "09:00"
    });
    setShowScheduleDialog(true);
  };
  
  const confirmSchedule = () => {
    // Agendar newsletter
    const scheduledDateTime = `${formData.scheduled_date}T${formData.scheduled_time}:00`;
    
    const updatedNewsletters = newsletters.map(n => {
      if (n.id === selectedNewsletter.id) {
        return {
          ...n,
          status: "agendado",
          scheduled_date: new Date(scheduledDateTime).toISOString()
        };
      }
      return n;
    });
    
    setNewsletters(updatedNewsletters);
    setShowScheduleDialog(false);
    
    toast({
      title: "Newsletter agendada com sucesso",
      description: `${selectedNewsletter.title} será enviada em ${formatDate(new Date(scheduledDateTime).toISOString())}.`,
    });
  };
  
  const handleSetupRecurring = (newsletter) => {
    setSelectedNewsletter(newsletter);
    setShowRecurringDialog(true);
  };
  
  const confirmRecurring = () => {
    // Configurar newsletter recorrente
    const updatedNewsletters = newsletters.map(n => {
      if (n.id === selectedNewsletter.id) {
        return {
          ...n,
          status: "recorrente",
          frequency: formData.recurring_type,
          next_run: new Date().toISOString() // Simulação
        };
      }
      return n;
    });
    
    setNewsletters(updatedNewsletters);
    setShowRecurringDialog(false);
    
    toast({
      title: "Newsletter recorrente configurada",
      description: `${selectedNewsletter.title} será enviada ${formData.recurring_type === "weekly" ? "semanalmente" : formData.recurring_type === "monthly" ? "mensalmente" : "diariamente"}.`,
    });
  };
  
  const handleDeleteNewsletter = (newsletter) => {
    setSelectedNewsletter(newsletter);
    setShowDeleteDialog(true);
  };
  
  const confirmDelete = () => {
    // Excluir newsletter
    const updatedNewsletters = newsletters.filter(n => n.id !== selectedNewsletter.id);
    setNewsletters(updatedNewsletters);
    setShowDeleteDialog(false);
    
    toast({
      title: "Newsletter excluída",
      description: `${selectedNewsletter.title} foi excluída permanentemente.`,
    });
  };
  
  const handlePreview = () => {
    setPreviewLoading(true);
    setTimeout(() => {
      setPreviewLoading(false);
      setShowPreviewDialog(true);
    }, 1000);
  };
  
  const handleCreateList = () => {
    // Criar nova lista
    const newId = `list${Date.now()}`;
    const newList = {
      id: newId,
      name: listFormData.name,
      description: listFormData.description,
      type: listFormData.type,
      subscribers: listFormData.type === "manual" 
        ? listFormData.members.length 
        : organizations.filter(org => org.status === "Ativo").length,
      last_updated: new Date().toISOString()
    };
    
    if (listFormData.type === "manual") {
      newList.members = listFormData.members;
    } else {
      newList.criteria = listFormData.criteria;
    }
    
    setLists([newList, ...lists]);
    setListFormData({
      name: "",
      description: "",
      type: "manual",
      criteria: { status: "Ativo" },
      members: []
    });
    setShowListDialog(false);
    
    toast({
      title: "Lista criada com sucesso",
      description: `A lista "${newList.name}" foi criada com ${newList.subscribers} assinantes.`,
    });
  };
  
  const resetForm = () => {
    setFormData({
      title: "",
      subject: "",
      content: "",
      template_id: "",
      lists: [],
      sender_name: "Endurancy",
      sender_email: "contato@endurancy.com.br",
      schedule: false,
      scheduled_date: new Date().toISOString().split('T')[0],
      scheduled_time: "09:00",
      tracking: true,
      is_recurring: false,
      recurring_type: "monthly",
      recurring_day: "1",
      recurring_hour: "09:00"
    });
  };
  
  const getNextStepDisabled = () => {
    if (createStep === 1) {
      return !formData.title || !formData.subject || formData.lists.length === 0;
    }
    if (createStep === 2) {
      return !formData.content;
    }
    return false;
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Newsletter</h1>
          <p className="text-gray-500 mt-1">
            Envie comunicações para organizações e usuários da plataforma
          </p>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="campanhas">Campanhas</TabsTrigger>
          <TabsTrigger value="listas">Listas de Envio</TabsTrigger>
          <TabsTrigger value="analytics">Análise</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
        </TabsList>
        
        <TabsContent value="campanhas" className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between gap-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar campanhas..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-40">
                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4" />
                    <SelectValue placeholder="Status" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="rascunho">Rascunhos</SelectItem>
                  <SelectItem value="agendado">Agendados</SelectItem>
                  <SelectItem value="enviado">Enviados</SelectItem>
                  <SelectItem value="recorrente">Recorrentes</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button className="bg-green-600 hover:bg-green-700" onClick={() => {
              resetForm();
              setCreateStep(1);
              setShowCreateDialog(true);
            }}>
              <Plus className="w-4 h-4 mr-2" />
              Nova Campanha
            </Button>
          </div>
          
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Título</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Destinatários</TableHead>
                    <TableHead>Taxa de Abertura</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredNewsletters.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-10 text-gray-500">
                        <Mail className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                        <p className="text-lg font-medium">Nenhuma campanha encontrada</p>
                        <p className="text-sm">
                          {searchTerm 
                            ? `Não encontramos campanhas para "${searchTerm}"`
                            : "Crie sua primeira campanha clicando no botão acima"}
                        </p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredNewsletters.map((newsletter) => (
                      <TableRow key={newsletter.id}>
                        <TableCell>
                          <div className="font-medium">{newsletter.title}</div>
                          <div className="text-sm text-gray-500">
                            Criado por {newsletter.created_by} em {formatDate(newsletter.created_date)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={
                            newsletter.status === 'enviado' 
                              ? 'bg-green-100 text-green-800' 
                              : newsletter.status === 'agendado'
                                ? 'bg-blue-100 text-blue-800'
                                : newsletter.status === 'recorrente'
                                  ? 'bg-purple-100 text-purple-800'
                                  : 'bg-gray-100 text-gray-800'
                          }>
                            <div className="flex items-center gap-1">
                              {newsletter.status === 'enviado' && <CheckCircle2 className="w-3 h-3" />}
                              {newsletter.status === 'agendado' && <Calendar className="w-3 h-3" />}
                              {newsletter.status === 'recorrente' && <Repeat className="w-3 h-3" />}
                              {newsletter.status === 'rascunho' && <FileText className="w-3 h-3" />}
                              {getStatusLabel(newsletter.status)}
                            </div>
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {newsletter.status === 'enviado' && (
                            <div className="flex items-center gap-1 text-sm">
                              <Calendar className="w-4 h-4 text-gray-400" />
                              <span>{formatDate(newsletter.sent_date)}</span>
                            </div>
                          )}
                          {newsletter.status === 'agendado' && (
                            <div className="flex items-center gap-1 text-sm">
                              <Clock className="w-4 h-4 text-blue-500" />
                              <span>{formatDate(newsletter.scheduled_date)}</span>
                            </div>
                          )}
                          {newsletter.status === 'recorrente' && (
                            <div className="flex items-center gap-1 text-sm">
                              <Repeat className="w-4 h-4 text-purple-500" />
                              <span>{newsletter.frequency === 'weekly' ? 'Semanal' : newsletter.frequency === 'monthly' ? 'Mensal' : 'Diário'}</span>
                            </div>
                          )}
                          {newsletter.status === 'rascunho' && (
                            <span className="text-sm text-gray-500">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4 text-gray-400" />
                            <span>{newsletter.recipients}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {newsletter.status === 'enviado' ? (
                            <div className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span>Abertura</span>
                                <span className="font-medium">{newsletter.open_rate}%</span>
                              </div>
                              <Progress value={newsletter.open_rate} className="h-1" />
                            </div>
                          ) : (
                            <span className="text-sm text-gray-500">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Ações</DropdownMenuLabel>
                              <DropdownMenuItem>
                                <Eye className="w-4 h-4 mr-2" />
                                Visualizar
                              </DropdownMenuItem>
                              
                              {newsletter.status !== 'enviado' && (
                                <DropdownMenuItem>
                                  <Edit className="w-4 h-4 mr-2" />
                                  Editar
                                </DropdownMenuItem>
                              )}
                              
                              {newsletter.status === 'rascunho' && (
                                <>
                                  <DropdownMenuItem onClick={() => handleSendNow(newsletter)}>
                                    <Send className="w-4 h-4 mr-2" />
                                    Enviar Agora
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleSchedule(newsletter)}>
                                    <Calendar className="w-4 h-4 mr-2" />
                                    Agendar Envio
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleSetupRecurring(newsletter)}>
                                    <Repeat className="w-4 h-4 mr-2" />
                                    Tornar Recorrente
                                  </DropdownMenuItem>
                                </>
                              )}
                              
                              {newsletter.status === 'agendado' && (
                                <>
                                  <DropdownMenuItem onClick={() => handleSendNow(newsletter)}>
                                    <Send className="w-4 h-4 mr-2" />
                                    Enviar Agora
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleSchedule(newsletter)}>
                                    <Calendar className="w-4 h-4 mr-2" />
                                    Reagendar
                                  </DropdownMenuItem>
                                </>
                              )}
                              
                              {newsletter.status === 'recorrente' && (
                                <>
                                  <DropdownMenuItem onClick={() => handleSendNow(newsletter)}>
                                    <Send className="w-4 h-4 mr-2" />
                                    Enviar Agora
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleSetupRecurring(newsletter)}>
                                    <Repeat className="w-4 h-4 mr-2" />
                                    Editar Recorrência
                                  </DropdownMenuItem>
                                </>
                              )}
                              
                              {newsletter.status === 'enviado' && (
                                <DropdownMenuItem>
                                  <ChartBar className="w-4 h-4 mr-2" />
                                  Ver Relatório
                                </DropdownMenuItem>
                              )}
                              
                              {newsletter.status === 'enviado' && (
                                <DropdownMenuItem>
                                  <Copy className="w-4 h-4 mr-2" />
                                  Duplicar
                                </DropdownMenuItem>
                              )}
                              
                              <DropdownMenuSeparator />
                              
                              <DropdownMenuItem 
                                className="text-red-600"
                                onClick={() => handleDeleteNewsletter(newsletter)}
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="listas" className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between gap-4">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar listas..."
                className="pl-10"
              />
            </div>
            
            <Button onClick={() => setShowListDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Nova Lista
            </Button>
          </div>
          
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Assinantes</TableHead>
                    <TableHead>Última Atualização</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {lists.map((list) => (
                    <TableRow key={list.id}>
                      <TableCell>
                        <div className="font-medium">{list.name}</div>
                        <div className="text-sm text-gray-500">{list.description}</div>
                      </TableCell>
                      <TableCell>
                        <Badge className={list.type === 'automático' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'}>
                          {list.type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4 text-gray-400" />
                          <span>{list.subscribers}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <span>{formatDate(list.last_updated)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Ações</DropdownMenuLabel>
                            <DropdownMenuItem>
                              <Users className="w-4 h-4 mr-2" />
                              Ver Assinantes
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="w-4 h-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Send className="w-4 h-4 mr-2" />
                              Enviar Campanha
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Download className="w-4 h-4 mr-2" />
                              Exportar
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <RefreshCw className="w-4 h-4 mr-2" />
                              Atualizar Lista
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="w-4 h-4 mr-2" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Análise de Desempenho</CardTitle>
              <CardDescription>
                Acompanhe as métricas de desempenho das suas campanhas de email
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">
                      Taxa Média de Abertura
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">68%</div>
                    <p className="text-sm text-green-600 flex items-center mt-1">
                      <ArrowUpRight className="w-4 h-4 mr-1" />
                      12% acima da média do setor
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">
                      Taxa Média de Cliques
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">42%</div>
                    <p className="text-sm text-green-600 flex items-center mt-1">
                      <ArrowUpRight className="w-4 h-4 mr-1" />
                      8% acima da média do setor
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">
                      Total de Envios
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">1.248</div>
                    <p className="text-sm text-gray-500 flex items-center mt-1">
                      Últimos 30 dias
                    </p>
                  </CardContent>
                </Card>
              </div>
              
              <div className="mt-8 space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Taxa de Abertura por Mês</h3>
                  <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                    <p className="text-gray-500">Gráfico de taxa de abertura por mês</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Melhores Horários para Envio</h3>
                  <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                    <p className="text-gray-500">Gráfico de desempenho por horário do dia</p>
                  </div>
                </div>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Campanhas com Melhor Desempenho</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Título</TableHead>
                          <TableHead>Taxa de Abertura</TableHead>
                          <TableHead>Taxa de Cliques</TableHead>
                          <TableHead>Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {analytics.top_campaigns.map(campaign => (
                          <TableRow key={campaign.id}>
                            <TableCell>{campaign.title}</TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <span className="font-medium mr-2">{campaign.open_rate}%</span>
                                <Progress value={campaign.open_rate} className="h-2 w-24" />
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <span className="font-medium mr-2">{campaign.click_rate}%</span>
                                <Progress value={campaign.click_rate} className="h-2 w-24" />
                              </div>
                            </TableCell>
                            <TableCell>
                              <Button variant="ghost" size="sm">
                                <BarChart className="w-4 h-4 mr-1" />
                                Relatório
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="templates" className="space-y-4">
          <div className="flex justify-between mb-4">
            <div>
              <h2 className="text-xl font-medium">Templates de Email</h2>
              <p className="text-gray-500">Gerencie modelos de email para suas campanhas</p>
            </div>
            <Button onClick={() => setShowTemplateDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Novo Template
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {templates.map(template => (
              <Card key={template.id} className="overflow-hidden">
                <div className="h-40 bg-gray-100 flex items-center justify-center relative">
                  <img 
                    src={template.preview_url} 
                    alt={template.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/5 hover:bg-black/10 transition-colors">
                    <div className="absolute top-2 right-2">
                      <Button variant="secondary" size="icon" className="h-8 w-8 rounded-full bg-white">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-medium">{template.name}</h3>
                  <p className="text-sm text-gray-500">{template.description}</p>
                  <div className="text-xs text-gray-400 mt-2">
                    Atualizado em {formatDate(template.updated_date)}
                  </div>
                  <div className="flex justify-end gap-2 mt-4">
                    <Button variant="outline" size="sm">
                      <Eye className="w-4 h-4 mr-1" />
                      Visualizar
                    </Button>
                    <Button size="sm">
                      <Edit className="w-4 h-4 mr-1" />
                      Editar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            <Card className="border-dashed border-2 flex flex-col items-center justify-center p-6">
              <Plus className="w-8 h-8 text-gray-400 mb-2" />
              <h3 className="font-medium">Novo Template</h3>
              <p className="text-sm text-gray-500 text-center mt-1">
                Crie um template personalizado
              </p>
              <Button className="mt-4" onClick={() => setShowTemplateDialog(true)}>Criar Template</Button>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Dialog para criar newsletter */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Nova Campanha de Email</DialogTitle>
            <DialogDescription>
              Crie e envie uma nova campanha de email para sua lista de contatos
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="flex justify-between mb-6">
              <div className="flex gap-2">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${createStep >= 1 ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}>
                  1
                </div>
                <div className={`h-0.5 w-8 self-center ${createStep > 1 ? 'bg-green-200' : 'bg-gray-200'}`}></div>
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${createStep >= 2 ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}>
                  2
                </div>
                <div className={`h-0.5 w-8 self-center ${createStep > 2 ? 'bg-green-200' : 'bg-gray-200'}`}></div>
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${createStep >= 3 ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}>
                  3
                </div>
              </div>
              <div className="text-sm text-gray-500">
                {createStep === 1 ? 'Informações Básicas' : createStep === 2 ? 'Conteúdo' : 'Configurações de Envio'}
              </div>
            </div>
            
            {createStep === 1 && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <Label htmlFor="campaignType">Tipo de Campanha</Label>
                  <RadioGroup 
                    value={campaignType} 
                    onValueChange={setCampaignType}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="regular" id="regular" />
                      <Label htmlFor="regular">Campanha Regular</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="automated" id="automated" />
                      <Label htmlFor="automated">Automação</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-1">
                  <Label htmlFor="title">Título da Campanha (interno)</Label>
                  <Input 
                    id="title"
                    placeholder="Ex: Newsletter Janeiro 2024"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                  />
                  <p className="text-xs text-gray-500">Nome interno para identificar sua campanha</p>
                </div>
                
                <div className="space-y-1">
                  <Label htmlFor="subject">Linha de Assunto</Label>
                  <Input 
                    id="subject"
                    placeholder="Ex: Novidades da Endurancy - Janeiro 2024"
                    value={formData.subject}
                    onChange={(e) => setFormData({...formData, subject: e.target.value})}
                  />
                  <p className="text-xs text-gray-500">Será exibida na caixa de entrada dos destinatários</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="sender_name">Nome do Remetente</Label>
                    <Input 
                      id="sender_name"
                      placeholder="Ex: Endurancy"
                      value={formData.sender_name}
                      onChange={(e) => setFormData({...formData, sender_name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="sender_email">Email do Remetente</Label>
                    <Input 
                      id="sender_email"
                      placeholder="Ex: contato@endurancy.com.br"
                      value={formData.sender_email}
                      onChange={(e) => setFormData({...formData, sender_email: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="space-y-1">
                  <Label>Listas de Destinatários</Label>
                  <div className="border rounded-md p-4 max-h-60 overflow-y-auto space-y-2">
                    {lists.map(list => (
                      <div key={list.id} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`list-${list.id}`} 
                          checked={formData.lists.includes(list.id)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData({
                                ...formData, 
                                lists: [...formData.lists, list.id]
                              });
                            } else {
                              setFormData({
                                ...formData, 
                                lists: formData.lists.filter(id => id !== list.id)
                              });
                            }
                          }}
                        />
                        <Label htmlFor={`list-${list.id}`} className="flex flex-col">
                          <span>{list.name}</span>
                          <span className="text-xs text-gray-500 flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {list.subscribers} assinantes
                          </span>
                        </Label>
                      </div>
                    ))}
                    
                    {lists.length === 0 && (
                      <div className="text-center py-4 text-gray-500">
                        <p>Nenhuma lista de destinatários criada</p>
                        <Button 
                          variant="link" 
                          className="p-0 h-auto mt-1"
                          onClick={() => {
                            setShowCreateDialog(false);
                            setShowListDialog(true);
                          }}
                        >
                          Criar uma lista agora
                        </Button>
                      </div>
                    )}
                  </div>
                  <div className="flex justify-end mt-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setShowCreateDialog(false);
                        setShowListDialog(true);
                      }}
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Nova Lista
                    </Button>
                  </div>
                </div>
              </div>
            )}
            
            {createStep === 2 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="content">Conteúdo do Email</Label>
                    <Select 
                      value={formData.template_id || ""} 
                      onValueChange={(value) => setFormData({...formData, template_id: value})}
                    >
                      <SelectTrigger className="w-56">
                        <SelectValue placeholder="Selecionar template..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>Sem template</SelectItem>
                        {templates.map(template => (
                          <SelectItem key={template.id} value={template.id}>
                            {template.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="border rounded-md overflow-hidden">
                    <ReactQuill
                      value={formData.content}
                      onChange={(content) => setFormData({...formData, content})}
                      modules={editorModules}
                      className="min-h-[300px]"
                    />
                  </div>
                </div>
                
                <div className="flex gap-2 mt-4">
                  <Button variant="outline" size="sm" onClick={handlePreview} disabled={previewLoading}>
                    {previewLoading ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        Gerando prévia...
                      </>
                    ) : (
                      <>
                        <Eye className="w-4 h-4 mr-2" />
                        Visualizar Email
                      </>
                    )}
                  </Button>
                  
                  <Button variant="outline" size="sm">
                    <LinkIcon className="w-4 h-4 mr-2" />
                    Inserir Link
                  </Button>
                  
                  <Button variant="outline" size="sm">
                    <Image className="w-4 h-4 mr-2" />
                    Inserir Imagem
                  </Button>
                </div>
              </div>
            )}
            
            {createStep === 3 && (
              <div className="space-y-6">
                <div className="space-y-3">
                  <h3 className="text-base font-medium">Configurações de Envio</h3>
                  
                  <div className="flex items-center justify-between space-x-2">
                    <Label htmlFor="schedule" className="flex items-center gap-2 cursor-pointer">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      Agendar envio
                    </Label>
                    <Switch
                      id="schedule"
                      checked={formData.schedule}
                      onCheckedChange={(checked) => setFormData({...formData, schedule: checked})}
                    />
                  </div>
                  
                  {formData.schedule && (
                    <div className="grid grid-cols-2 gap-4 pl-6">
                      <div className="space-y-1">
                        <Label htmlFor="scheduled_date">Data</Label>
                        <Input
                          id="scheduled_date"
                          type="date"
                          value={formData.scheduled_date}
                          onChange={(e) => setFormData({...formData, scheduled_date: e.target.value})}
                          min={new Date().toISOString().split('T')[0]}
                        />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="scheduled_time">Hora</Label>
                        <Input
                          id="scheduled_time"
                          type="time"
                          value={formData.scheduled_time}
                          onChange={(e) => setFormData({...formData, scheduled_time: e.target.value})}
                        />
                      </div>
                    </div>
                  )}
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between space-x-2">
                    <Label htmlFor="is_recurring" className="flex items-center gap-2 cursor-pointer">
                      <Repeat className="w-4 h-4 text-gray-500" />
                      Envio recorrente
                    </Label>
                    <Switch
                      id="is_recurring"
                      checked={formData.is_recurring}
                      onCheckedChange={(checked) => setFormData({...formData, is_recurring: checked})}
                    />
                  </div>
                  
                  {formData.is_recurring && (
                    <div className="space-y-4 pl-6">
                      <div className="space-y-1">
                        <Label htmlFor="recurring_type">Frequência</Label>
                        <Select
                          value={formData.recurring_type}
                          onValueChange={(value) => setFormData({...formData, recurring_type: value})}
                        >
                          <SelectTrigger id="recurring_type">
                            <SelectValue placeholder="Selecione a frequência" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="daily">Diária</SelectItem>
                            <SelectItem value="weekly">Semanal</SelectItem>
                            <SelectItem value="monthly">Mensal</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      {formData.recurring_type === 'monthly' && (
                        <div className="space-y-1">
                          <Label htmlFor="recurring_day">Dia do mês</Label>
                          <Select
                            value={formData.recurring_day}
                            onValueChange={(value) => setFormData({...formData, recurring_day: value})}
                          >
                            <SelectTrigger id="recurring_day">
                              <SelectValue placeholder="Selecione o dia" />
                            </SelectTrigger>
                            <SelectContent>
                              {Array.from({ length: 28 }, (_, i) => (
                                <SelectItem key={i+1} value={(i+1).toString()}>
                                  Dia {i+1}
                                </SelectItem>
                              ))}
                              <SelectItem value="last">Último dia</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                      
                      {formData.recurring_type === 'weekly' && (
                        <div className="space-y-1">
                          <Label htmlFor="recurring_day">Dia da semana</Label>
                          <Select
                            value={formData.recurring_day}
                            onValueChange={(value) => setFormData({...formData, recurring_day: value})}
                          >
                            <SelectTrigger id="recurring_day">
                              <SelectValue placeholder="Selecione o dia" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1">Segunda-feira</SelectItem>
                              <SelectItem value="2">Terça-feira</SelectItem>
                              <SelectItem value="3">Quarta-feira</SelectItem>
                              <SelectItem value="4">Quinta-feira</SelectItem>
                              <SelectItem value="5">Sexta-feira</SelectItem>
                              <SelectItem value="6">Sábado</SelectItem>
                              <SelectItem value="0">Domingo</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                      
                      <div className="space-y-1">
                        <Label htmlFor="recurring_hour">Hora do envio</Label>
                        <Input
                          id="recurring_hour"
                          type="time"
                          value={formData.recurring_hour}
                          onChange={(e) => setFormData({...formData, recurring_hour: e.target.value})}
                        />
                      </div>
                    </div>
                  )}
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between space-x-2">
                    <Label htmlFor="tracking" className="flex items-center gap-2 cursor-pointer">
                      <BarChart className="w-4 h-4 text-gray-500" />
                      Rastreamento de abertura e cliques
                    </Label>
                    <Switch
                      id="tracking"
                      checked={formData.tracking}
                      onCheckedChange={(checked) => setFormData({...formData, tracking: checked})}
                    />
                  </div>
                </div>
                
                <Alert>
                  <InfoIcon className="h-4 w-4" />
                  <AlertTitle>Informação</AlertTitle>
                  <AlertDescription>
                    {formData.schedule 
                      ? `Esta campanha será enviada para ${formData.lists.reduce((total, listId) => {
                          const list = lists.find(l => l.id === listId);
                          return total + (list ? list.subscribers : 0);
                        }, 0)} destinatários em ${formatDate(`${formData.scheduled_date}T${formData.scheduled_time}:00Z`)}.`
                      : formData.is_recurring 
                        ? `Esta campanha será enviada ${formData.recurring_type === 'weekly' ? 'semanalmente' : formData.recurring_type === 'monthly' ? 'mensalmente' : 'diariamente'} para ${formData.lists.reduce((total, listId) => {
                            const list = lists.find(l => l.id === listId);
                            return total + (list ? list.subscribers : 0);
                          }, 0)} destinatários.`
                        : `Esta campanha será salva como rascunho e poderá ser enviada posteriormente.`
                    }
                  </AlertDescription>
                </Alert>
              </div>
            )}
          </div>
          
          <DialogFooter className="flex justify-between">
            {createStep > 1 ? (
              <Button 
                variant="outline" 
                onClick={() => setCreateStep(createStep - 1)}
              >
                Voltar
              </Button>
            ) : (
              <Button 
                variant="outline" 
                onClick={() => setShowCreateDialog(false)}
              >
                Cancelar
              </Button>
            )}
            
            {createStep < 3 ? (
              <Button 
                onClick={() => setCreateStep(createStep + 1)}
                disabled={getNextStepDisabled()}
              >
                Próximo
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button 
                onClick={handleCreateNewsletter}
                className="bg-green-600 hover:bg-green-700"
              >
                {formData.schedule ? 'Agendar' : (formData.is_recurring ? 'Configurar Recorrência' : 'Salvar Rascunho')}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para agendar envio */}
      <Dialog open={showScheduleDialog} onOpenChange={setShowScheduleDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Agendar Envio</DialogTitle>
            <DialogDescription>
              Defina quando esta newsletter deve ser enviada
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="schedule_date">Data</Label>
                <Input
                  id="schedule_date"
                  type="date"
                  value={formData.scheduled_date}
                  onChange={(e) => setFormData({...formData, scheduled_date: e.target.value})}
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="schedule_time">Hora</Label>
                <Input
                  id="schedule_time"
                  type="time"
                  value={formData.scheduled_time}
                  onChange={(e) => setFormData({...formData, scheduled_time: e.target.value})}
                />
              </div>
            </div>
            
            <Alert>
              <CalendarIcon className="h-4 w-4" />
              <AlertTitle>Data de Envio</AlertTitle>
              <AlertDescription>
                A newsletter será enviada automaticamente na data e hora programadas.
              </AlertDescription>
            </Alert>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowScheduleDialog(false)}>
              Cancelar
            </Button>
            <Button className="bg-green-600 hover:bg-green-700" onClick={confirmSchedule}>
              Confirmar Agendamento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para configurar recorrência */}
      <Dialog open={showRecurringDialog} onOpenChange={setShowRecurringDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Configurar Envio Recorrente</DialogTitle>
            <DialogDescription>
              Defina a frequência de envio desta newsletter
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="recurring_type_dialog">Frequência</Label>
              <Select
                value={formData.recurring_type}
                onValueChange={(value) => setFormData({...formData, recurring_type: value})}
              >
                <SelectTrigger id="recurring_type_dialog">
                  <SelectValue placeholder="Selecione a frequência" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Diária</SelectItem>
                  <SelectItem value="weekly">Semanal</SelectItem>
                  <SelectItem value="monthly">Mensal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {formData.recurring_type === 'monthly' && (
              <div className="space-y-2">
                <Label htmlFor="recurring_day_dialog">Dia do mês</Label>
                <Select
                  value={formData.recurring_day}
                  onValueChange={(value) => setFormData({...formData, recurring_day: value})}
                >
                  <SelectTrigger id="recurring_day_dialog">
                    <SelectValue placeholder="Selecione o dia" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 28 }, (_, i) => (
                      <SelectItem key={i+1} value={(i+1).toString()}>
                        Dia {i+1}
                      </SelectItem>
                    ))}
                    <SelectItem value="last">Último dia</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            
            {formData.recurring_type === 'weekly' && (
              <div className="space-y-2">
                <Label htmlFor="recurring_day_dialog">Dia da semana</Label>
                <Select
                  value={formData.recurring_day}
                  onValueChange={(value) => setFormData({...formData, recurring_day: value})}
                >
                  <SelectTrigger id="recurring_day_dialog">
                    <SelectValue placeholder="Selecione o dia" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Segunda-feira</SelectItem>
                    <SelectItem value="2">Terça-feira</SelectItem>
                    <SelectItem value="3">Quarta-feira</SelectItem>
                    <SelectItem value="4">Quinta-feira</SelectItem>
                    <SelectItem value="5">Sexta-feira</SelectItem>
                    <SelectItem value="6">Sábado</SelectItem>
                    <SelectItem value="0">Domingo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="recurring_hour_dialog">Hora do envio</Label>
              <Input
                id="recurring_hour_dialog"
                type="time"
                value={formData.recurring_hour}
                onChange={(e) => setFormData({...formData, recurring_hour: e.target.value})}
              />
            </div>
            
            <Alert>
              <Repeat className="h-4 w-4" />
              <AlertTitle>Envio Recorrente</AlertTitle>
              <AlertDescription>
                Esta newsletter será enviada automaticamente com a frequência definida.
                O primeiro envio ocorrerá no próximo dia aplicável.
              </AlertDescription>
            </Alert>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRecurringDialog(false)}>
              Cancelar
            </Button>
            <Button className="bg-green-600 hover:bg-green-700" onClick={confirmRecurring}>
              Confirmar Recorrência
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para visualizar email */}
      <Dialog open={showPreviewDialog} onOpenChange={setShowPreviewDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Prévia do Email</DialogTitle>
            <DialogDescription>
              Visualize como seu email será exibido para os destinatários
            </DialogDescription>
          </DialogHeader>
          
          <div className="border rounded-lg overflow-hidden mt-4">
            <div className="bg-gray-100 p-3 border-b">
              <div className="mb-1">
                <span className="font-medium">De:</span> {formData.sender_name} &lt;{formData.sender_email}&gt;
              </div>
              <div className="mb-1">
                <span className="font-medium">Assunto:</span> {formData.subject}
              </div>
              <div>
                <span className="font-medium">Para:</span> [Destinatários]
              </div>
            </div>
            <div className="bg-white p-6 overflow-y-auto max-h-[50vh]">
              <div dangerouslySetInnerHTML={{ __html: formData.content }} />
            </div>
          </div>
          
          <DialogFooter>
            <Button onClick={() => setShowPreviewDialog(false)}>
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para excluir newsletter */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Excluir Newsletter</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir esta newsletter? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          
          {selectedNewsletter && (
            <div className="py-4">
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <div className="mr-3">
                  <FileText className="w-10 h-10 text-gray-400" />
                </div>
                <div>
                  <h3 className="font-medium">{selectedNewsletter.title}</h3>
                  <p className="text-sm text-gray-500">
                    Status: {getStatusLabel(selectedNewsletter.status)} | 
                    Destinatários: {selectedNewsletter.recipients}
                  </p>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmDelete}>
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para criar lista */}
      <Dialog open={showListDialog} onOpenChange={setShowListDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Nova Lista de Envio</DialogTitle>
            <DialogDescription>
              Crie uma lista de destinatários para suas campanhas de email
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="list_name">Nome da Lista</Label>
              <Input
                id="list_name"
                placeholder="Ex: Clientes Ativos"
                value={listFormData.name}
                onChange={(e) => setListFormData({...listFormData, name: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="list_description">Descrição</Label>
              <Textarea
                id="list_description"
                placeholder="Descreva a finalidade desta lista"
                value={listFormData.description}
                onChange={(e) => setListFormData({...listFormData, description: e.target.value})}
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <Label>Tipo de Lista</Label>
              <RadioGroup
                value={listFormData.type}
                onValueChange={(value) => setListFormData({...listFormData, type: value})}
                className="flex flex-col space-y-1"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="manual" id="manual" />
                  <Label htmlFor="manual" className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-blue-500" />
                    Lista Manual
                    <span className="text-xs text-gray-500">(Selecione organizações específicas)</span>
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="automático" id="automatic" />
                  <Label htmlFor="automatic" className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-purple-500" />
                    Lista Automática
                    <span className="text-xs text-gray-500">(Baseada em critérios que atualizam automaticamente)</span>
                  </Label>
                </div>
              </RadioGroup>
            </div>
            
            {listFormData.type === "manual" ? (
              <div className="space-y-2">
                <Label>Selecione as Organizações</Label>
                <div className="border rounded-md p-4 max-h-60 overflow-y-auto space-y-2">
                  <div className="mb-2">
                    <Input
                      placeholder="Buscar organizações..."
                      className="mb-2"
                    />
                  </div>
                  
                  {organizations.map(org => (
                    <div key={org.id} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`org-${org.id}`} 
                        checked={listFormData.members.includes(org.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setListFormData({
                              ...listFormData, 
                              members: [...listFormData.members, org.id]
                            });
                          } else {
                            setListFormData({
                              ...listFormData, 
                              members: listFormData.members.filter(id => id !== org.id)
                            });
                          }
                        }}
                      />
                      <Label htmlFor={`org-${org.id}`} className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-gray-400" />
                        <div>
                          <span>{org.name}</span>
                          <div className="text-xs text-gray-500">
                            {org.contact_email}
                          </div>
                        </div>
                      </Label>
                    </div>
                  ))}
                  
                  {organizations.length === 0 && (
                    <div className="text-center py-4 text-gray-500">
                      <p>Nenhuma organização encontrada</p>
                    </div>
                  )}
                </div>
                
                <div className="text-sm text-gray-500">
                  {listFormData.members.length} organizações selecionadas
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <Label>Critérios da Lista</Label>
                <div className="border rounded-md p-4">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="criteria_status" className="text-sm">Status da Organização</Label>
                        <Select
                          value={listFormData.criteria.status}
                          onValueChange={(value) => setListFormData({
                            ...listFormData, 
                            criteria: {...listFormData.criteria, status: value}
                          })}
                        >
                          <SelectTrigger id="criteria_status">
                            <SelectValue placeholder="Selecione o status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Ativo">Ativas</SelectItem>
                            <SelectItem value="Pendente">Pendentes</SelectItem>
                            <SelectItem value="Rejeitado">Rejeitadas</SelectItem>
                            <SelectItem value="all">Todas</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="criteria_type" className="text-sm">Tipo de Organização</Label>
                        <Select
                          value={listFormData.criteria.type || "all"}
                          onValueChange={(value) => setListFormData({
                            ...listFormData, 
                            criteria: {...listFormData.criteria, type: value === "all" ? undefined : value}
                          })}
                        >
                          <SelectTrigger id="criteria_type">
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Todos os tipos</SelectItem>
                            <SelectItem value="Empresa">Empresas</SelectItem>
                            <SelectItem value="Associação">Associações</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <Alert>
                      <InfoIcon className="h-4 w-4" />
                      <AlertTitle>Lista Dinâmica</AlertTitle>
                      <AlertDescription>
                        Esta lista será atualizada automaticamente quando novas organizações atenderem aos critérios.
                      </AlertDescription>
                    </Alert>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowListDialog(false)}>
              Cancelar
            </Button>
            <Button 
              className="bg-green-600 hover:bg-green-700" 
              onClick={handleCreateList}
              disabled={!listFormData.name}
            >
              Criar Lista
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para criar template */}
      <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Novo Template de Email</DialogTitle>
            <DialogDescription>
              Crie um modelo reutilizável para suas campanhas de email
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="template_name">Nome do Template</Label>
                <Input
                  id="template_name"
                  placeholder="Ex: Newsletter Mensal"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="template_category">Categoria</Label>
                <Select>
                  <SelectTrigger id="template_category">
                    <SelectValue placeholder="Selecione uma categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newsletter">Newsletter</SelectItem>
                    <SelectItem value="announcement">Anúncio</SelectItem>
                    <SelectItem value="event">Evento</SelectItem>
                    <SelectItem value="update">Atualização</SelectItem>
                    <SelectItem value="other">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="template_description">Descrição</Label>
              <Textarea
                id="template_description"
                placeholder="Descreva o propósito deste template"
                rows={2}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="template_content">Conteúdo do Template</Label>
              <div className="border rounded-md overflow-hidden">
                <ReactQuill
                  modules={editorModules}
                  className="min-h-[300px]"
                />
              </div>
            </div>
            
            <Alert>
              <InfoIcon className="h-4 w-4" />
              <AlertTitle>Variáveis do Template</AlertTitle>
              <AlertDescription>
                Você pode usar as seguintes variáveis: 
                <span className="font-mono">&#123;&#123;organization_name&#125;&#125;</span>, 
                <span className="font-mono">&#123;&#123;contact_name&#125;&#125;</span>, 
                <span className="font-mono">&#123;&#123;unsubscribe_link&#125;&#125;</span>
              </AlertDescription>
            </Alert>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTemplateDialog(false)}>
              Cancelar
            </Button>
            <Button className="bg-green-600 hover:bg-green-700">
              Criar Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}