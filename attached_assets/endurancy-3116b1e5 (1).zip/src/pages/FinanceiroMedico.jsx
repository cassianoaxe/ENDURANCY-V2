
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  DollarSign,
  Calendar,
  FileText,
  Download,
  ArrowUpRight,
  ArrowDownRight,
  CreditCard,
  Wallet,
  Search,
  Filter,
  MoreHorizontal,
  UserCheck,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { Spinner } from '@/components/ui/spinner';
import { toast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function FinanceiroMedico() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [payments, setPayments] = useState([]);
  const [filteredPayments, setFilteredPayments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedPeriod, setSelectedPeriod] = useState('last3months');
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [showPayDialog, setShowPayDialog] = useState(false);
  
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Simulação de dados
        setTimeout(() => {
          // Dados simulados de médicos
          const mockDoctors = [
            { id: 'med1', nome_completo: 'Dr. Carlos Santos', especialidade: 'Neurologia' },
            { id: 'med2', nome_completo: 'Dra. Ana Silva', especialidade: 'Psiquiatria' },
            { id: 'med3', nome_completo: 'Dr. Roberto Oliveira', especialidade: 'Clínica Geral' }
          ];
          
          // Dados simulados de pagamentos
          const mockPayments = [
            { 
              id: 'p1', 
              medico_id: 'med1', 
              medico_nome: 'Dr. Carlos Santos',
              mes_referencia: '2024-11',
              consultas_realizadas: 32,
              valor_total_consultas: 6400,
              percentual_repasse: 15,
              valor_repasse: 960,
              valor_liquido: 5440,
              status: 'pago',
              data_fechamento: '2024-12-01T10:30:00',
              data_pagamento: '2024-12-05T14:20:00'
            },
            { 
              id: 'p2', 
              medico_id: 'med2', 
              medico_nome: 'Dra. Ana Silva',
              mes_referencia: '2024-11',
              consultas_realizadas: 28,
              valor_total_consultas: 5600,
              percentual_repasse: 15,
              valor_repasse: 840,
              valor_liquido: 4760,
              status: 'pago',
              data_fechamento: '2024-12-01T11:15:00',
              data_pagamento: '2024-12-05T14:25:00'
            },
            { 
              id: 'p3', 
              medico_id: 'med3', 
              medico_nome: 'Dr. Roberto Oliveira',
              mes_referencia: '2024-11',
              consultas_realizadas: 18,
              valor_total_consultas: 3600,
              percentual_repasse: 15,
              valor_repasse: 540,
              valor_liquido: 3060,
              status: 'pago',
              data_fechamento: '2024-12-01T09:50:00',
              data_pagamento: '2024-12-05T14:30:00'
            },
            { 
              id: 'p4', 
              medico_id: 'med1', 
              medico_nome: 'Dr. Carlos Santos',
              mes_referencia: '2024-12',
              consultas_realizadas: 35,
              valor_total_consultas: 7000,
              percentual_repasse: 15,
              valor_repasse: 1050,
              valor_liquido: 5950,
              status: 'fechado',
              data_fechamento: '2025-01-01T10:15:00',
              data_pagamento: null
            },
            { 
              id: 'p5', 
              medico_id: 'med2', 
              medico_nome: 'Dra. Ana Silva',
              mes_referencia: '2024-12',
              consultas_realizadas: 30,
              valor_total_consultas: 6000,
              percentual_repasse: 15,
              valor_repasse: 900,
              valor_liquido: 5100,
              status: 'fechado',
              data_fechamento: '2025-01-01T10:20:00',
              data_pagamento: null
            },
            { 
              id: 'p6', 
              medico_id: 'med3', 
              medico_nome: 'Dr. Roberto Oliveira',
              mes_referencia: '2024-12',
              consultas_realizadas: 22,
              valor_total_consultas: 4400,
              percentual_repasse: 15,
              valor_repasse: 660,
              valor_liquido: 3740,
              status: 'fechado',
              data_fechamento: '2025-01-01T10:25:00',
              data_pagamento: null
            },
            { 
              id: 'p7', 
              medico_id: 'med1', 
              medico_nome: 'Dr. Carlos Santos',
              mes_referencia: '2025-01',
              consultas_realizadas: 15,
              valor_total_consultas: 3000,
              percentual_repasse: 15,
              valor_repasse: 450,
              valor_liquido: 2550,
              status: 'aberto',
              data_fechamento: null,
              data_pagamento: null
            }
          ];
          
          setDoctors(mockDoctors);
          setPayments(mockPayments);
          setFilteredPayments(mockPayments);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        toast({
          title: "Erro ao carregar dados",
          description: "Não foi possível carregar os dados financeiros dos médicos.",
          variant: "destructive"
        });
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  useEffect(() => {
    // Filtragem dos pagamentos
    let filtered = [...payments];
    
    // Filtro por médico
    if (selectedDoctor !== 'all') {
      filtered = filtered.filter(payment => payment.medico_id === selectedDoctor);
    }
    
    // Filtro por status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(payment => payment.status === statusFilter);
    }
    
    // Filtro por termo de busca
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(payment => 
        payment.medico_nome.toLowerCase().includes(search) ||
        payment.mes_referencia.includes(search)
      );
    }
    
    setFilteredPayments(filtered);
  }, [payments, selectedDoctor, statusFilter, searchTerm]);
  
  const handlePayment = () => {
    // Simulação de pagamento
    if (selectedPayment) {
      const updatedPayments = payments.map(payment => {
        if (payment.id === selectedPayment.id) {
          return {
            ...payment,
            status: 'pago',
            data_pagamento: new Date().toISOString()
          };
        }
        return payment;
      });
      
      setPayments(updatedPayments);
      setShowPayDialog(false);
      
      toast({
        title: "Pagamento realizado",
        description: `Pagamento de R$ ${selectedPayment.valor_liquido.toLocaleString('pt-BR')} para ${selectedPayment.medico_nome} registrado com sucesso.`,
        variant: "default"
      });
    }
  };
  
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };
  
  const formatMonth = (yearMonth) => {
    const [year, month] = yearMonth.split('-');
    return new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric' }).format(new Date(year, month - 1));
  };
  
  const getStatusBadge = (status) => {
    switch (status) {
      case 'aberto':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Em aberto</Badge>;
      case 'fechado':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Aguardando pagamento</Badge>;
      case 'pago':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Pago</Badge>;
      case 'contestado':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Contestado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  // Cálculo de totais
  const totalPendingPayment = filteredPayments
    .filter(p => p.status === 'fechado')
    .reduce((acc, curr) => acc + curr.valor_liquido, 0);
    
  const totalPaidLastMonth = filteredPayments
    .filter(p => p.status === 'pago' && p.mes_referencia === '2024-12')
    .reduce((acc, curr) => acc + curr.valor_liquido, 0);
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Financeiro Médico</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Gerencie pagamentos e repasses para médicos parceiros
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={() => navigate(createPageUrl('ControleMedico'))}>
            <ArrowRight className="mr-2 h-4 w-4" />
            Dashboard Médico
          </Button>
          <Button variant="outline" onClick={() => navigate(createPageUrl('ListaMedicos'))}>
            <UserCheck className="mr-2 h-4 w-4" />
            Cadastro de Médicos
          </Button>
        </div>
      </div>
      
      {/* Cartões de resumo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Médicos cadastrados</CardDescription>
            <CardTitle className="text-3xl">{doctors.length}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-muted-foreground">
              <UserCheck className="mr-1 h-4 w-4 text-green-500" />
              <span>Todos ativos e disponíveis</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Pagamentos pendentes</CardDescription>
            <CardTitle className="text-3xl">{formatCurrency(totalPendingPayment)}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-muted-foreground">
              <AlertTriangle className="mr-1 h-4 w-4 text-yellow-500" />
              <span>{filteredPayments.filter(p => p.status === 'fechado').length} pagamentos aguardando</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Pagamentos realizados (último mês)</CardDescription>
            <CardTitle className="text-3xl">{formatCurrency(totalPaidLastMonth)}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-muted-foreground">
              <CheckCircle2 className="mr-1 h-4 w-4 text-green-500" />
              <span>{filteredPayments.filter(p => p.status === 'pago' && p.mes_referencia === '2024-12').length} médicos pagos</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle>Filtrar pagamentos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="w-full md:w-1/4">
              <Label htmlFor="doctor-filter">Médico</Label>
              <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
                <SelectTrigger id="doctor-filter">
                  <SelectValue placeholder="Selecione um médico" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os médicos</SelectItem>
                  {doctors.map(doctor => (
                    <SelectItem key={doctor.id} value={doctor.id}>
                      {doctor.nome_completo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full md:w-1/4">
              <Label htmlFor="status-filter">Status</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger id="status-filter">
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="aberto">Em aberto</SelectItem>
                  <SelectItem value="fechado">Aguardando pagamento</SelectItem>
                  <SelectItem value="pago">Pago</SelectItem>
                  <SelectItem value="contestado">Contestado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full md:w-1/4">
              <Label htmlFor="period-filter">Período</Label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger id="period-filter">
                  <SelectValue placeholder="Selecione o período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="last3months"> Últimos 3 meses </SelectItem>
                  <SelectItem value="last6months">Últimos 6 meses</SelectItem>
                  <SelectItem value="thisyear">Este ano</SelectItem>
                  <SelectItem value="lastyear">Ano anterior</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full md:w-1/4">
              <Label htmlFor="search">Buscar</Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
                <Input
                  id="search"
                  placeholder="Buscar médico ou período..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Tabela de pagamentos */}
      <Card>
        <CardHeader>
          <CardTitle>Pagamentos a médicos</CardTitle>
          <CardDescription>
            Gerencie os pagamentos aos médicos associados à plataforma
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center py-8">
              <Spinner className="w-8 h-8" />
              <span className="ml-2">Carregando dados...</span>
            </div>
          ) : filteredPayments.length === 0 ? (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <FileText className="mx-auto h-12 w-12 text-gray-300 dark:text-gray-600 mb-2" />
              <p>Nenhum pagamento encontrado.</p>
              <p className="text-sm">Tente ajustar os filtros ou cadastre novos médicos.</p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Médico</TableHead>
                    <TableHead>Período</TableHead>
                    <TableHead>Consultas</TableHead>
                    <TableHead>Valor Bruto</TableHead>
                    <TableHead>Repasse</TableHead>
                    <TableHead>Valor Líquido</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayments.map((payment) => (
                    <TableRow key={payment.id}>
                      <TableCell className="font-medium">{payment.medico_nome}</TableCell>
                      <TableCell>{formatMonth(payment.mes_referencia)}</TableCell>
                      <TableCell>{payment.consultas_realizadas}</TableCell>
                      <TableCell>{formatCurrency(payment.valor_total_consultas)}</TableCell>
                      <TableCell>
                        {formatCurrency(payment.valor_repasse)}
                        <span className="text-xs text-gray-500 dark:text-gray-400 ml-1">
                          ({payment.percentual_repasse}%)
                        </span>
                      </TableCell>
                      <TableCell className="font-medium">{formatCurrency(payment.valor_liquido)}</TableCell>
                      <TableCell>{getStatusBadge(payment.status)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Abrir menu</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => {
                              setSelectedPayment(payment);
                              setShowDetailDialog(true);
                            }}>
                              Ver detalhes
                            </DropdownMenuItem>
                            {payment.status === 'fechado' && (
                              <DropdownMenuItem onClick={() => {
                                setSelectedPayment(payment);
                                setShowPayDialog(true);
                              }}>
                                Registrar pagamento
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => 
                              toast({
                                title: "Exportado com sucesso",
                                description: "O relatório foi exportado em formato PDF.",
                              })
                            }>
                              Exportar relatório
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Diálogo de detalhes do pagamento */}
      {selectedPayment && (
        <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Detalhes do Pagamento</DialogTitle>
              <DialogDescription>
                Informações detalhadas sobre o pagamento a {selectedPayment.medico_nome}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Médico</p>
                  <p className="font-medium">{selectedPayment.medico_nome}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Período</p>
                  <p className="font-medium">{formatMonth(selectedPayment.mes_referencia)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Consultas</p>
                  <p className="font-medium">{selectedPayment.consultas_realizadas}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Status</p>
                  <p className="font-medium">{getStatusBadge(selectedPayment.status)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Data de fechamento</p>
                  <p className="font-medium">
                    {selectedPayment.data_fechamento 
                      ? format(new Date(selectedPayment.data_fechamento), "dd/MM/yyyy - HH:mm", { locale: ptBR })
                      : "Não fechado"}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Data de pagamento</p>
                  <p className="font-medium">
                    {selectedPayment.data_pagamento 
                      ? format(new Date(selectedPayment.data_pagamento), "dd/MM/yyyy - HH:mm", { locale: ptBR })
                      : "Não pago"}
                  </p>
                </div>
              </div>
              
              <div className="mt-6 pt-4 border-t">
                <div className="flex justify-between mb-2">
                  <span className="text-gray-500 dark:text-gray-400">Valor total bruto:</span>
                  <span className="font-medium">{formatCurrency(selectedPayment.valor_total_consultas)}</span>
                </div>
                <div className="flex justify-between mb-2 text-gray-500 dark:text-gray-400">
                  <span>Taxa de repasse ({selectedPayment.percentual_repasse}%):</span>
                  <span>-{formatCurrency(selectedPayment.valor_repasse)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg mt-4 pt-2 border-t">
                  <span>Valor líquido:</span>
                  <span>{formatCurrency(selectedPayment.valor_liquido)}</span>
                </div>
              </div>
            </div>
            
            <DialogFooter className="flex flex-col sm:flex-row gap-2">
              {selectedPayment.status === 'fechado' && (
                <Button 
                  onClick={() => {
                    setShowDetailDialog(false);
                    setShowPayDialog(true);
                  }}
                >
                  <Wallet className="mr-2 h-4 w-4" />
                  Registrar pagamento
                </Button>
              )}
              <Button variant="outline" onClick={() => setShowDetailDialog(false)}>
                Fechar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Diálogo de confirmação de pagamento */}
      {selectedPayment && (
        <Dialog open={showPayDialog} onOpenChange={setShowPayDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Confirmar Pagamento</DialogTitle>
              <DialogDescription>
                Você está prestes a registrar um pagamento no valor de {formatCurrency(selectedPayment.valor_liquido)} para {selectedPayment.medico_nome}.
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4">
              <div className="rounded-lg bg-green-50 dark:bg-green-900/20 p-4 border border-green-100 dark:border-green-800">
                <div className="flex items-start space-x-3">
                  <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-medium text-green-800 dark:text-green-300">
                      Confirme os dados do pagamento
                    </p>
                    <div className="text-sm text-green-700 dark:text-green-400">
                      <p>Médico: {selectedPayment.medico_nome}</p>
                      <p>Período: {formatMonth(selectedPayment.mes_referencia)}</p>
                      <p>Valor: {formatCurrency(selectedPayment.valor_liquido)}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="secondary" onClick={() => setShowPayDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={handlePayment}>
                <CreditCard className="mr-2 h-4 w-4" />
                Confirmar Pagamento
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
