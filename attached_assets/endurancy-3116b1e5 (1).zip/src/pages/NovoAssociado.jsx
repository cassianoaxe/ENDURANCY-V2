
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  UserPlus, 
  Save, 
  X, 
  ArrowLeft, 
  Calendar, 
  Check, 
  Upload,
  Info,
  FileText,
  HelpCircle,
  Plus,
  MoreHorizontal
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { toast } from "@/components/ui/use-toast";

export default function NovoAssociado() {
  const [activeTab, setActiveTab] = useState("dados-pessoais");
  const navigate = useNavigate();
  
  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "Associado cadastrado com sucesso!",
      description: "O novo associado foi cadastrado e está pendente de aprovação.",
    });
    navigate(createPageUrl("Associados"));
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Associados")}>
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Cadastrar Novo Associado</h1>
            <p className="text-gray-500 mt-1">Preencha o formulário com os dados do novo associado</p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => navigate(createPageUrl("Associados"))}>
            <X className="w-4 h-4" />
            Cancelar
          </Button>
          <Button className="gap-2" onClick={handleSubmit}>
            <Save className="w-4 h-4" />
            Salvar
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="dados-pessoais">Dados Pessoais</TabsTrigger>
          <TabsTrigger value="endereco">Endereço</TabsTrigger>
          <TabsTrigger value="saude">Informações de Saúde</TabsTrigger>
          <TabsTrigger value="documentos">Documentos</TabsTrigger>
          <TabsTrigger value="financeiro">Financeiro</TabsTrigger>
        </TabsList>
        
        <Card>
          <CardContent className="pt-6">
            <TabsContent value="dados-pessoais" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="nome_completo">Nome Completo <span className="text-red-500">*</span></Label>
                  <Input id="nome_completo" placeholder="Nome completo do associado" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email <span className="text-red-500">*</span></Label>
                  <Input id="email" type="email" placeholder="email@exemplo.com" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cpf">CPF <span className="text-red-500">*</span></Label>
                  <Input id="cpf" placeholder="000.000.000-00" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="rg">RG</Label>
                  <Input id="rg" placeholder="00.000.000-0" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="data_nascimento">Data de Nascimento</Label>
                  <div className="flex">
                    <Input id="data_nascimento" type="date" />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tipo_associado">Tipo de Associado <span className="text-red-500">*</span></Label>
                  <Select defaultValue="regular">
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="regular">Regular</SelectItem>
                      <SelectItem value="fundador">Fundador</SelectItem>
                      <SelectItem value="honorario">Honorário</SelectItem>
                      <SelectItem value="colaborador">Colaborador</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone <span className="text-red-500">*</span></Label>
                  <Input id="telefone" placeholder="(00) 00000-0000" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="telefone_alternativo">Telefone Alternativo</Label>
                  <Input id="telefone_alternativo" placeholder="(00) 00000-0000" />
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label>Como conheceu a associação?</Label>
                <RadioGroup defaultValue="indicacao">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="indicacao" id="indicacao" />
                      <Label htmlFor="indicacao">Indicação</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="redes_sociais" id="redes_sociais" />
                      <Label htmlFor="redes_sociais">Redes Sociais</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="site" id="site" />
                      <Label htmlFor="site">Site</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="eventos" id="eventos" />
                      <Label htmlFor="eventos">Eventos</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="midia" id="midia" />
                      <Label htmlFor="midia">Mídia</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="outros" id="outros" />
                      <Label htmlFor="outros">Outros</Label>
                    </div>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="indicado_por">Indicado por (se aplicável)</Label>
                <Input id="indicado_por" placeholder="Nome de quem indicou" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea id="observacoes" placeholder="Observações adicionais sobre o associado" />
              </div>
            </TabsContent>
            
            <TabsContent value="endereco" className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="cep">CEP <span className="text-red-500">*</span></Label>
                <div className="flex gap-2">
                  <Input id="cep" placeholder="00000-000" />
                  <Button variant="outline">Buscar</Button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="endereco">Endereço <span className="text-red-500">*</span></Label>
                  <Input id="endereco" placeholder="Rua, Avenida, etc." />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="numero">Número <span className="text-red-500">*</span></Label>
                  <Input id="numero" placeholder="Número" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="complemento">Complemento</Label>
                  <Input id="complemento" placeholder="Apto, Bloco, etc." />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="bairro">Bairro <span className="text-red-500">*</span></Label>
                  <Input id="bairro" placeholder="Bairro" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cidade">Cidade <span className="text-red-500">*</span></Label>
                  <Input id="cidade" placeholder="Cidade" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="estado">Estado <span className="text-red-500">*</span></Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="AC">Acre</SelectItem>
                      <SelectItem value="AL">Alagoas</SelectItem>
                      <SelectItem value="AP">Amapá</SelectItem>
                      <SelectItem value="AM">Amazonas</SelectItem>
                      <SelectItem value="BA">Bahia</SelectItem>
                      <SelectItem value="CE">Ceará</SelectItem>
                      <SelectItem value="DF">Distrito Federal</SelectItem>
                      <SelectItem value="ES">Espírito Santo</SelectItem>
                      <SelectItem value="GO">Goiás</SelectItem>
                      <SelectItem value="MA">Maranhão</SelectItem>
                      <SelectItem value="MT">Mato Grosso</SelectItem>
                      <SelectItem value="MS">Mato Grosso do Sul</SelectItem>
                      <SelectItem value="MG">Minas Gerais</SelectItem>
                      <SelectItem value="PA">Pará</SelectItem>
                      <SelectItem value="PB">Paraíba</SelectItem>
                      <SelectItem value="PR">Paraná</SelectItem>
                      <SelectItem value="PE">Pernambuco</SelectItem>
                      <SelectItem value="PI">Piauí</SelectItem>
                      <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                      <SelectItem value="RN">Rio Grande do Norte</SelectItem>
                      <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                      <SelectItem value="RO">Rondônia</SelectItem>
                      <SelectItem value="RR">Roraima</SelectItem>
                      <SelectItem value="SC">Santa Catarina</SelectItem>
                      <SelectItem value="SP">São Paulo</SelectItem>
                      <SelectItem value="SE">Sergipe</SelectItem>
                      <SelectItem value="TO">Tocantins</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox id="endereco_correspondencia" />
                  <label htmlFor="endereco_correspondencia" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    Este é o endereço de correspondência
                  </label>
                </div>
              </div>
              
              <Separator />
              
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Endereços Adicionais</h3>
                <Button variant="outline" className="gap-2">
                  <Plus className="w-4 h-4" />
                  Adicionar Endereço
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="saude" className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Condições Médicas</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="epilepsia" />
                    <label htmlFor="epilepsia" className="text-sm font-medium leading-none">
                      Epilepsia
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="dor_cronica" />
                    <label htmlFor="dor_cronica" className="text-sm font-medium leading-none">
                      Dor Crônica
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="ansiedade" />
                    <label htmlFor="ansiedade" className="text-sm font-medium leading-none">
                      Ansiedade
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="depressao" />
                    <label htmlFor="depressao" className="text-sm font-medium leading-none">
                      Depressão
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="insonia" />
                    <label htmlFor="insonia" className="text-sm font-medium leading-none">
                      Insônia
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="fibromialgia" />
                    <label htmlFor="fibromialgia" className="text-sm font-medium leading-none">
                      Fibromialgia
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="esclerose" />
                    <label htmlFor="esclerose" className="text-sm font-medium leading-none">
                      Esclerose Múltipla
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="alzheimer" />
                    <label htmlFor="alzheimer" className="text-sm font-medium leading-none">
                      Alzheimer
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="parkinson" />
                    <label htmlFor="parkinson" className="text-sm font-medium leading-none">
                      Parkinson
                    </label>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="outras_condicoes">Outras Condições</Label>
                  <Textarea id="outras_condicoes" placeholder="Descreva outras condições não listadas acima" />
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Medicamentos em Uso</h3>
                <Textarea placeholder="Liste os medicamentos que o associado utiliza atualmente" />
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Histórico de Tratamentos</h3>
                <Textarea placeholder="Descreva tratamentos anteriores com cannabis medicinal, se houver" />
              </div>
            </TabsContent>
            
            <TabsContent value="documentos" className="space-y-6">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Documentos Necessários</h3>
                  <div className="text-sm text-yellow-600 flex items-center gap-1">
                    <Info className="w-4 h-4" />
                    Formatos aceitos: PDF, JPG, PNG (máx. 5MB)
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2 border rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center">
                      <Label className="font-medium">RG / Documento de Identidade <span className="text-red-500">*</span></Label>
                      <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                    </div>
                    <div className="flex items-center gap-2 h-10">
                      <Input type="file" className="border-none bg-transparent p-0" />
                      <Button variant="outline" size="sm" className="shrink-0">
                        <Upload className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2 border rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center">
                      <Label className="font-medium">CPF <span className="text-red-500">*</span></Label>
                      <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                    </div>
                    <div className="flex items-center gap-2 h-10">
                      <Input type="file" className="border-none bg-transparent p-0" />
                      <Button variant="outline" size="sm" className="shrink-0">
                        <Upload className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2 border rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center">
                      <Label className="font-medium">Comprovante de Residência <span className="text-red-500">*</span></Label>
                      <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                    </div>
                    <div className="flex items-center gap-2 h-10">
                      <Input type="file" className="border-none bg-transparent p-0" />
                      <Button variant="outline" size="sm" className="shrink-0">
                        <Upload className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2 border rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center">
                      <Label className="font-medium">Laudo Médico <span className="text-red-500">*</span></Label>
                      <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                    </div>
                    <div className="flex items-center gap-2 h-10">
                      <Input type="file" className="border-none bg-transparent p-0" />
                      <Button variant="outline" size="sm" className="shrink-0">
                        <Upload className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2 border rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center">
                      <Label className="font-medium">Prescrição Médica</Label>
                      <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                    </div>
                    <div className="flex items-center gap-2 h-10">
                      <Input type="file" className="border-none bg-transparent p-0" />
                      <Button variant="outline" size="sm" className="shrink-0">
                        <Upload className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2 border rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center">
                      <Label className="font-medium">Termo de Adesão Assinado <span className="text-red-500">*</span></Label>
                      <div className="flex gap-1">
                        <Button variant="link" size="sm" className="h-5 p-0">
                          <FileText className="w-4 h-4 mr-1" />
                          Ver modelo
                        </Button>
                        <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                      </div>
                    </div>
                    <div className="flex items-center gap-2 h-10">
                      <Input type="file" className="border-none bg-transparent p-0" />
                      <Button variant="outline" size="sm" className="shrink-0">
                        <Upload className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="outros_documentos">Outros Documentos</Label>
                  <Input type="file" multiple id="outros_documentos" />
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="financeiro" className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Configurações Financeiras</h3>
                
                <div className="space-y-2">
                  <Label htmlFor="situacao_financeira">Situação Financeira Inicial</Label>
                  <Select defaultValue="em_dia">
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a situação" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="em_dia">Em dia</SelectItem>
                      <SelectItem value="isento">Isento de pagamento</SelectItem>
                      <SelectItem value="pendente">Pendente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="motivo_isencao">Motivo da Isenção (se aplicável)</Label>
                  <Textarea id="motivo_isencao" placeholder="Descreva o motivo da isenção de pagamento" />
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label className="text-lg font-medium">Anuidade Atual</Label>
                    <Badge>2023 - R$ 240,00</Badge>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox id="cobrar_anuidade" defaultChecked />
                    <label htmlFor="cobrar_anuidade" className="text-sm font-medium leading-none">
                      Cobrar anuidade ao finalizar cadastro
                    </label>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="forma_pagamento">Forma de Pagamento</Label>
                    <Select defaultValue="pix">
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a forma de pagamento" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pix">PIX</SelectItem>
                        <SelectItem value="boleto">Boleto</SelectItem>
                        <SelectItem value="cartao">Cartão de Crédito</SelectItem>
                        <SelectItem value="transferencia">Transferência Bancária</SelectItem>
                        <SelectItem value="dinheiro">Dinheiro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="parcelas">Número de Parcelas</Label>
                    <Select defaultValue="1">
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o número de parcelas" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1x (à vista)</SelectItem>
                        <SelectItem value="2">2x</SelectItem>
                        <SelectItem value="3">3x</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="observacoes_financeiras">Observações Financeiras</Label>
                  <Textarea id="observacoes_financeiras" placeholder="Observações adicionais sobre pagamentos" />
                </div>
              </div>
            </TabsContent>
          </CardContent>
          <CardFooter className="flex justify-between pt-6 px-6">
            <Button
              variant="outline"
              onClick={() => {
                const tabs = ["dados-pessoais", "endereco", "saude", "documentos", "financeiro"];
                const currentIndex = tabs.indexOf(activeTab);
                if (currentIndex > 0) {
                  setActiveTab(tabs[currentIndex - 1]);
                }
              }}
              disabled={activeTab === "dados-pessoais"}
            >
              Anterior
            </Button>
            
            <Button
              onClick={() => {
                const tabs = ["dados-pessoais", "endereco", "saude", "documentos", "financeiro"];
                const currentIndex = tabs.indexOf(activeTab);
                if (currentIndex < tabs.length - 1) {
                  setActiveTab(tabs[currentIndex + 1]);
                } else {
                  handleSubmit({ preventDefault: () => {} });
                }
              }}
            >
              {activeTab === "financeiro" ? "Salvar Associado" : "Próximo"}
            </Button>
          </CardFooter>
        </Card>
      </Tabs>
    </div>
  );
}
