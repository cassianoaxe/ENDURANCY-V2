import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Heart, 
  Users, 
  DollarSign,
  Share2,
  ArrowRight
} from 'lucide-react';

export default function PortalSocial() {
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Programa Social',
        text: 'Conheça nosso programa de assistência social',
        url: window.location.href,
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Programa Social</h1>
              <p className="text-gray-500">Cuidando de quem mais precisa</p>
            </div>
            <Button onClick={handleShare} variant="outline" className="gap-2">
              <Share2 className="w-4 h-4" />
              Compartilhar
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-6">Nossa Missão</h2>
            <p className="text-gray-600 leading-relaxed">
              Nosso programa social tem como objetivo principal garantir acesso ao tratamento com 
              cannabis medicinal para pacientes em situação de vulnerabilidade socioeconômica. 
              Através de um sistema de subsídios e isenções, trabalhamos para que ninguém fique 
              sem tratamento por questões financeiras.
            </p>
          </section>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card>
              <CardHeader>
                <Heart className="w-8 h-8 text-red-500 mb-2" />
                <CardTitle>Assistência</CardTitle>
                <CardDescription>Apoio integral aos pacientes</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">
                  Oferecemos suporte completo com profissionais qualificados
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Users className="w-8 h-8 text-blue-500 mb-2" />
                <CardTitle>Comunidade</CardTitle>
                <CardDescription>Rede de apoio e acolhimento</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">
                  Construímos uma comunidade forte e solidária
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <DollarSign className="w-8 h-8 text-green-500 mb-2" />
                <CardTitle>Transparência</CardTitle>
                <CardDescription>Gestão clara dos recursos</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">
                  Total transparência na aplicação dos recursos
                </p>
              </CardContent>
            </Card>
          </div>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-6">Como Funciona</h2>
            <div className="space-y-4">
              <div className="bg-white p-6 rounded-lg border">
                <h3 className="font-semibold mb-2">1. Avaliação Socioeconômica</h3>
                <p className="text-gray-600">
                  Realizamos uma análise completa da situação socioeconômica para determinar 
                  o percentual de subsídio adequado.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg border">
                <h3 className="font-semibold mb-2">2. Acompanhamento Médico</h3>
                <p className="text-gray-600">
                  Garantimos acompanhamento médico especializado durante todo o tratamento.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg border">
                <h3 className="font-semibold mb-2">3. Suporte Contínuo</h3>
                <p className="text-gray-600">
                  Oferecemos suporte contínuo através de nossa equipe multidisciplinar.
                </p>
              </div>
            </div>
          </section>

          <section className="text-center mb-12">
            <h2 className="text-2xl font-semibold mb-6">Como Contribuir</h2>
            <p className="text-gray-600 mb-6">
              Você pode fazer a diferença na vida de muitas pessoas. Contribua com nosso programa social.
            </p>
            <div className="flex justify-center gap-4">
              <Button className="gap-2">
                Doar Agora
                <ArrowRight className="w-4 h-4" />
              </Button>
              <Button variant="outline" className="gap-2">
                Ser Voluntário
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </section>

          <section className="bg-gray-50 p-6 rounded-lg">
            <h2 className="text-2xl font-semibold mb-6">Entre em Contato</h2>
            <p className="text-gray-600 mb-4">
              Para mais informações sobre nosso programa social ou para solicitar assistência, 
              entre em contato conosco.
            </p>
            <Button variant="outline" className="gap-2">
              Fale Conosco
              <ArrowRight className="w-4 h-4" />
            </Button>
          </section>
        </div>
      </main>

      <footer className="bg-gray-50 border-t mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-gray-500 text-sm">
            © 2024 Programa Social. Todos os direitos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
}