import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import {
  FlaskConical,
  Thermometer,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  User,
  Calendar,
  Package,
  BarChart,
  Clipboard,
  ClipboardCheck,
  AlertTriangle,
  Search,
  FilterX,
  Plus,
  Trash2,
  Save,
  PlayCircle,
  PauseCircle,
  StopCircle,
  RefreshCw,
  ZoomIn,
  ZoomOut,
  Droplets,
  Scale
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ProducaoEnvasamento() {
  const [loading, setLoading] = useState(false);
  const [lotes, setLotes] = useState([]);
  const [loteAtivo, setLoteAtivo] = useState(null);
  const [maquinaStatus, setMaquinaStatus] = useState('desligada');
  const [velocidadeEnvase, setVelocidadeEnvase] = useState(20);
  const [quantidadeEnvasada, setQuantidadeEnvasada] = useState(0);
  const [emProcesso, setEmProcesso] = useState(false);
  const [checklistConcluido, setChecklistConcluido] = useState(false);
  const [parametrosAjustados, setParametrosAjustados] = useState(false);
  const [alarmes, setAlarmes] = useState([]);
  
  // Checklist de verificação pré-envase
  const [checklist, setChecklist] = useState({
    limpezaMaquina: false,
    calibracaoVolume: false,
    verificacaoFrascos: false,
    verificacaoSolucao: false,
    verificacaoTampas: false,
    procedimentoOperacional: false
  });

  useEffect(() => {
    // Simulação de carregamento de dados
    setLoading(true);
    setTimeout(() => {
      setLotes([
        {
          id: "LOT-CBD-072-DIL",
          produto: "Óleo CBD 5% 30ml",
          ordemProducao: "OP-2023-125",
          quantidadeTotal: 500,
          unidade: "frascos",
          status: "pronto_para_envase",
          dataProcesso: "05/08/2023",
          responsavel: "Carlos Santos",
          volume: "30ml",
          solucao: {
            nome: "Solução diluída CBD 5%",
            lote: "LOT-CBD-072-DIL",
            volume: "15L",
            concentracao: "5%"
          },
          embalagens: [
            { nome: "Frascos âmbar 30ml", quantidade: 520, lote: "FRA-457" },
            { nome: "Conta-gotas", quantidade: 520, lote: "CON-789" }
          ]
        },
        {
          id: "LOT-CBD-073-DIL",
          produto: "Óleo CBD 10% 30ml",
          ordemProducao: "OP-2023-127",
          quantidadeTotal: 300,
          unidade: "frascos",
          status: "pronto_para_envase",
          dataProcesso: "07/08/2023",
          responsavel: "Maria Oliveira",
          volume: "30ml",
          solucao: {
            nome: "Solução diluída CBD 10%",
            lote: "LOT-CBD-073-DIL",
            volume: "9L",
            concentracao: "10%"
          },
          embalagens: [
            { nome: "Frascos âmbar 30ml", quantidade: 320, lote: "FRA-458" },
            { nome: "Conta-gotas", quantidade: 320, lote: "CON-790" }
          ]
        }
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const selecionarLote = (lote) => {
    setLoteAtivo(lote);
    setMaquinaStatus('ligada');
    resetarChecklist();
    setParametrosAjustados(false);
    setQuantidadeEnvasada(0);
    setAlarmes([]);
  };

  const resetarChecklist = () => {
    setChecklist({
      limpezaMaquina: false,
      calibracaoVolume: false,
      verificacaoFrascos: false,
      verificacaoSolucao: false,
      verificacaoTampas: false,
      procedimentoOperacional: false
    });
    setChecklistConcluido(false);
  };

  const atualizarChecklist = (item, valor) => {
    setChecklist(prev => {
      const novoChecklist = {
        ...prev,
        [item]: valor
      };
      // Verificar se todos os itens foram concluídos
      const todosConcluidos = Object.values(novoChecklist).every(Boolean);
      setChecklistConcluido(todosConcluidos);
      return novoChecklist;
    });
  };

  const ajustarParametros = () => {
    if (!checklistConcluido) {
      adicionarAlarme("É necessário concluir o checklist antes de ajustar os parâmetros.");
      return;
    }
    setParametrosAjustados(true);
    setMaquinaStatus('ajustada');
  };

  const iniciarEnvase = () => {
    if (!parametrosAjustados) {
      adicionarAlarme("É necessário ajustar os parâmetros da máquina antes de iniciar o envase.");
      return;
    }
    
    setEmProcesso(true);
    setMaquinaStatus('processando');
    
    // Simular o processo de envase
    const intervalId = setInterval(() => {
      setQuantidadeEnvasada(prev => {
        if (prev >= loteAtivo.quantidadeTotal) {
          clearInterval(intervalId);
          setEmProcesso(false);
          setMaquinaStatus('concluido');
          return loteAtivo.quantidadeTotal;
        }
        
        // Incrementar baseado na velocidade (frascos por minuto)
        // Neste exemplo, aceleramos para ver o progresso mais rapidamente
        const incremento = Math.ceil(velocidadeEnvase / 6);
        return Math.min(prev + incremento, loteAtivo.quantidadeTotal);
      });
    }, 1000);
  };

  const pausarEnvase = () => {
    setEmProcesso(false);
    setMaquinaStatus('pausado');
  };

  const continuarEnvase = () => {
    setEmProcesso(true);
    setMaquinaStatus('processando');
  };

  const finalizarEnvase = () => {
    setEmProcesso(false);
    setMaquinaStatus('finalizado');
    setQuantidadeEnvasada(loteAtivo.quantidadeTotal);
  };

  const reiniciarMaquina = () => {
    setMaquinaStatus('ligada');
    setEmProcesso(false);
    setQuantidadeEnvasada(0);
    resetarChecklist();
    setParametrosAjustados(false);
  };

  const adicionarAlarme = (mensagem) => {
    const novoAlarme = {
      id: Date.now(),
      mensagem,
      data: new Date().toLocaleTimeString()
    };
    setAlarmes(prev => [novoAlarme, ...prev]);
  };

  const registrarLote = () => {
    alert("Lote de envase registrado com sucesso!");
    setLoteAtivo(null);
    setMaquinaStatus('desligada');
    setEmProcesso(false);
    setQuantidadeEnvasada(0);
    resetarChecklist();
    setParametrosAjustados(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Controle de Envasamento</h1>
          <p className="text-gray-500">Gerenciamento do processo de envase de produtos</p>
        </div>
        <div className="flex gap-2">
          <Badge variant={!emProcesso ? 'outline' : 'secondary'} className="text-sm py-1 px-3">
            {maquinaStatus === 'desligada' && 'Máquina Desligada'}
            {maquinaStatus === 'ligada' && 'Máquina Ligada'}
            {maquinaStatus === 'ajustada' && 'Máquina Ajustada'}
            {maquinaStatus === 'processando' && 'Envasando'}
            {maquinaStatus === 'pausado' && 'Pausado'}
            {maquinaStatus === 'concluido' && 'Envase Concluído'}
            {maquinaStatus === 'finalizado' && 'Finalizado'}
          </Badge>
          {loteAtivo && (
            <Button size="sm" variant="outline" onClick={reiniciarMaquina} disabled={maquinaStatus === 'desligada'}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Reiniciar
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {!loteAtivo ? (
            <Card>
              <CardHeader>
                <CardTitle>Lotes Prontos para Envase</CardTitle>
                <CardDescription>Selecione um lote para iniciar o processo de envasamento</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <svg className="animate-spin h-8 w-8 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Lote</TableHead>
                        <TableHead>Produto</TableHead>
                        <TableHead>Ordem de Produção</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Ação</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {lotes.map((lote) => (
                        <TableRow key={lote.id}>
                          <TableCell className="font-medium">{lote.id}</TableCell>
                          <TableCell>{lote.produto}</TableCell>
                          <TableCell>{lote.ordemProducao}</TableCell>
                          <TableCell>{lote.quantidadeTotal} {lote.unidade}</TableCell>
                          <TableCell>
                            <Button size="sm" onClick={() => selecionarLote(lote)}>
                              Selecionar
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Processo de Envasamento - {loteAtivo.produto}</CardTitle>
                    <Badge>{loteAtivo.id}</Badge>
                  </div>
                  <CardDescription>
                    Ordem de Produção: {loteAtivo.ordemProducao} | Quantidade: {loteAtivo.quantidadeTotal} {loteAtivo.unidade}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Checklist de verificação pré-envase */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-sm font-medium">Checklist de Verificação</h3>
                      <Badge variant={checklistConcluido ? 'default' : 'outline'} className={checklistConcluido ? 'bg-green-100 text-green-800' : ''}>
                        {checklistConcluido ? 'Concluído' : 'Pendente'}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="limpezaMaquina" 
                          checked={checklist.limpezaMaquina} 
                          onChange={(e) => atualizarChecklist('limpezaMaquina', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso}
                        />
                        <label htmlFor="limpezaMaquina" className="text-sm">Limpeza da máquina realizada</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="calibracaoVolume" 
                          checked={checklist.calibracaoVolume} 
                          onChange={(e) => atualizarChecklist('calibracaoVolume', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso}
                        />
                        <label htmlFor="calibracaoVolume" className="text-sm">Calibração do volume verificada</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="verificacaoFrascos" 
                          checked={checklist.verificacaoFrascos} 
                          onChange={(e) => atualizarChecklist('verificacaoFrascos', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso}
                        />
                        <label htmlFor="verificacaoFrascos" className="text-sm">Frascos verificados</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="verificacaoSolucao" 
                          checked={checklist.verificacaoSolucao} 
                          onChange={(e) => atualizarChecklist('verificacaoSolucao', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso}
                        />
                        <label htmlFor="verificacaoSolucao" className="text-sm">Solução verificada</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="verificacaoTampas" 
                          checked={checklist.verificacaoTampas} 
                          onChange={(e) => atualizarChecklist('verificacaoTampas', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso}
                        />
                        <label htmlFor="verificacaoTampas" className="text-sm">Tampas/conta-gotas verificados</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="procedimentoOperacional" 
                          checked={checklist.procedimentoOperacional} 
                          onChange={(e) => atualizarChecklist('procedimentoOperacional', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso}
                        />
                        <label htmlFor="procedimentoOperacional" className="text-sm">POP consultado</label>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Parâmetros da máquina */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-sm font-medium">Parâmetros da Máquina</h3>
                      <div>
                        <Button 
                          size="sm" 
                          onClick={ajustarParametros}
                          disabled={!checklistConcluido || emProcesso || parametrosAjustados}
                        >
                          {parametrosAjustados ? 'Parâmetros Ajustados' : 'Ajustar Parâmetros'}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <label className="text-sm">Velocidade de Envase</label>
                          <span className="text-sm font-medium">{velocidadeEnvase} frascos/min</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <input 
                            type="range" 
                            min="5" 
                            max="60" 
                            value={velocidadeEnvase}
                            onChange={(e) => setVelocidadeEnvase(parseInt(e.target.value))}
                            disabled={emProcesso || !parametrosAjustados}
                            className="w-full"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <label className="text-sm">Volume de Enchimento</label>
                          <span className="text-sm font-medium">30.0 ml</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <input 
                            type="range" 
                            min="29.5" 
                            max="30.5" 
                            step="0.1"
                            value="30.0"
                            disabled={emProcesso || !parametrosAjustados}
                            className="w-full"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Progresso do envase */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-sm font-medium">Progresso do Processo</h3>
                      <div className="flex items-center gap-2">
                        <FlaskConical className="w-4 h-4 text-blue-500" />
                        <span className="text-sm font-medium">
                          {quantidadeEnvasada} de {loteAtivo.quantidadeTotal} {loteAtivo.unidade}
                        </span>
                      </div>
                    </div>
                    
                    <Progress value={(quantidadeEnvasada / loteAtivo.quantidadeTotal) * 100} className="h-2" />
                    
                    <div className="flex justify-center gap-2 py-2">
                      {!emProcesso && maquinaStatus !== 'concluido' && maquinaStatus !== 'finalizado' && (
                        <Button onClick={iniciarEnvase} disabled={!parametrosAjustados}>
                          <PlayCircle className="w-4 h-4 mr-2" />
                          {maquinaStatus === 'pausado' ? 'Continuar' : 'Iniciar Envase'}
                        </Button>
                      )}
                      
                      {emProcesso && (
                        <>
                          <Button variant="outline" onClick={pausarEnvase}>
                            <PauseCircle className="w-4 h-4 mr-2" />
                            Pausar
                          </Button>
                          <Button variant="outline" onClick={finalizarEnvase}>
                            <StopCircle className="w-4 h-4 mr-2" />
                            Finalizar
                          </Button>
                        </>
                      )}
                      
                      {maquinaStatus === 'finalizado' && (
                        <Button onClick={registrarLote} className="bg-green-600 hover:bg-green-700">
                          <CheckCircle2 className="w-4 h-4 mr-2" />
                          Registrar Lote
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Materiais do lote */}
              <Card>
                <CardHeader>
                  <CardTitle>Materiais do Lote</CardTitle>
                  <CardDescription>Materiais e componentes para este processo de envase</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="solucao">
                    <TabsList className="mb-4">
                      <TabsTrigger value="solucao">Solução</TabsTrigger>
                      <TabsTrigger value="embalagens">Embalagens</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="solucao">
                      <div className="bg-gray-50 p-4 rounded-lg mb-4">
                        <h3 className="font-medium mb-2">{loteAtivo.solucao.nome}</h3>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-gray-500">Lote</p>
                            <p className="font-medium">{loteAtivo.solucao.lote}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Volume Total</p>
                            <p className="font-medium">{loteAtivo.solucao.volume}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Concentração</p>
                            <p className="font-medium">{loteAtivo.solucao.concentracao}</p>
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="embalagens">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Material</TableHead>
                            <TableHead>Lote</TableHead>
                            <TableHead>Quantidade</TableHead>
                            <TableHead>Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {loteAtivo.embalagens.map((embalagem, index) => (
                            <TableRow key={index}>
                              <TableCell className="font-medium">{embalagem.nome}</TableCell>
                              <TableCell>{embalagem.lote}</TableCell>
                              <TableCell>{embalagem.quantidade} un</TableCell>
                              <TableCell>
                                <Badge className="bg-green-100 text-green-800">Disponível</Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Instruções de Envasamento</CardTitle>
              <CardDescription>Procedimento padrão para envase de óleo CBD</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Badge className="mb-2">Procedimento</Badge>
                <ol className="list-decimal list-inside space-y-2 text-sm">
                  <li>Verificar a limpeza da máquina e realizar sanitização</li>
                  <li>Calibrar o equipamento para o volume de 30ml (±0.5ml)</li>
                  <li>Verificar integridade dos frascos e componentes</li>
                  <li>Alimentar o reservatório com a solução diluída</li>
                  <li>Configurar a velocidade de envase adequada</li>
                  <li>Realizar envase automatizado com amostragem periódica</li>
                  <li>Verificar peso/volume de 10 unidades a cada 50 frascos</li>
                  <li>Registrar dados de controle no sistema</li>
                </ol>
              </div>

              <Separator />

              <div className="space-y-2">
                <Badge className="mb-2">Parâmetros de Controle</Badge>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium">Volume:</p>
                    <p>30.0ml (±0.5ml)</p>
                  </div>
                  <div>
                    <p className="font-medium">Peso médio:</p>
                    <p>28.5g (±0.5g)</p>
                  </div>
                  <div>
                    <p className="font-medium">Velocidade:</p>
                    <p>20-40 frascos/min</p>
                  </div>
                  <div>
                    <p className="font-medium">Temperatura ambiente:</p>
                    <p>18-25°C</p>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <Badge className="mb-2">Controle de Qualidade</Badge>
                <div className="space-y-2 text-sm">
                  <p>• Verificar ausência de vazamentos</p>
                  <p>• Verificar volume correto em cada amostragem</p>
                  <p>• Verificar integridade dos frascos envasados</p>
                  <p>• Verificar encaixe correto dos conta-gotas</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Status da Máquina</CardTitle>
              <CardDescription>Máquina de Envase Automática #02</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Velocidade Atual</p>
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{emProcesso ? velocidadeEnvase : '---'} fr/min</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Volume Ajustado</p>
                  <div className="flex items-center">
                    <Droplets className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{parametrosAjustados ? '30.0' : '---'} ml</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Produção Atual</p>
                  <div className="flex items-center">
                    <FlaskConical className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{emProcesso ? quantidadeEnvasada : '---'} un</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Status</p>
                  <div className="flex items-center mt-1">
                    {maquinaStatus === 'desligada' && (
                      <Badge variant="outline">Desligada</Badge>
                    )}
                    {maquinaStatus === 'ligada' && (
                      <Badge variant="outline">Ligada</Badge>
                    )}
                    {maquinaStatus === 'ajustada' && (
                      <Badge className="bg-yellow-100 text-yellow-800">Ajustada</Badge>
                    )}
                    {maquinaStatus === 'processando' && (
                      <Badge className="bg-blue-100 text-blue-800">Processando</Badge>
                    )}
                    {maquinaStatus === 'pausado' && (
                      <Badge className="bg-orange-100 text-orange-800">Pausada</Badge>
                    )}
                    {maquinaStatus === 'concluido' && (
                      <Badge className="bg-green-100 text-green-800">Concluído</Badge>
                    )}
                    {maquinaStatus === 'finalizado' && (
                      <Badge className="bg-green-100 text-green-800">Finalizado</Badge>
                    )}
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Alarmes e Notificações</h3>
                {alarmes.length === 0 ? (
                  <div className="text-center py-2 text-sm text-gray-500">
                    Nenhum alarme registrado
                  </div>
                ) : (
                  <div className="max-h-40 overflow-y-auto space-y-2">
                    {alarmes.map(alarme => (
                      <div key={alarme.id} className="flex items-start gap-2 bg-red-50 p-2 rounded text-sm">
                        <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="text-red-800">{alarme.mensagem}</p>
                          <p className="text-xs text-gray-500">{alarme.data}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <Separator />

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Última Manutenção</h3>
                <div className="text-sm">
                  <p>• Calibração: 20/07/2023</p>
                  <p>• Próxima manutenção: 20/09/2023</p>
                  <p>• Status: Operacional</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}