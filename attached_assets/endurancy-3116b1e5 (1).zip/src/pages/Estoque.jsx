import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Package, ArrowRight } from "lucide-react";

export default function Estoque() {
  const navigate = useNavigate();
  
  const estoques = [
    {
      id: "ativos",
      nome: "Matéria Prima - Ativos",
      path: "EstoqueAtivos",
      descricao: "Gestão de estoque de princípios ativos",
      quantidade_items: 15,
      alertas: 2
    },
    {
      id: "excipientes",
      nome: "Matéria Prima - Excipientes",
      path: "EstoqueExcipientes",
      descricao: "Gestão de estoque de excipientes",
      quantidade_items: 28,
      alertas: 1
    },
    {
      id: "embalagens",
      nome: "Embalagens",
      path: "EstoqueEmbalagens",
      descricao: "Gestão de estoque de embalagens primárias e secundárias",
      quantidade_items: 45,
      alertas: 3
    },
    {
      id: "rotulos",
      nome: "Rótulos",
      path: "EstoqueRotulos",
      descricao: "Gestão de estoque de rótulos",
      quantidade_items: 32,
      alertas: 0
    },
    {
      id: "produto_acabado",
      nome: "Produto Acabado",
      path: "EstoqueProdutoAcabado",
      descricao: "Gestão de estoque de produtos finalizados",
      quantidade_items: 24,
      alertas: 1
    },
    {
      id: "quarentena",
      nome: "Produto em Quarentena",
      path: "EstoqueQuarentena",
      descricao: "Produtos aguardando liberação do Controle de Qualidade",
      quantidade_items: 8,
      alertas: 4
    },
    {
      id: "laboratorio",
      nome: "Material de Laboratório",
      path: "EstoqueLaboratorio",
      descricao: "Gestão de estoque de materiais de laboratório",
      quantidade_items: 56,
      alertas: 2
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Gestão de Estoque</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {estoques.map((estoque) => (
          <Card 
            key={estoque.id}
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => navigate(createPageUrl(estoque.path))}
          >
            <CardHeader className="pb-3">
              <CardTitle className="flex justify-between items-center">
                <span className="text-lg">{estoque.nome}</span>
                <Package className="h-5 w-5 text-gray-400" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500 mb-4">{estoque.descricao}</p>
              <div className="flex justify-between items-center">
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">Items em estoque</div>
                  <div className="text-2xl font-bold">{estoque.quantidade_items}</div>
                </div>
                {estoque.alertas > 0 && (
                  <Badge variant="destructive">
                    {estoque.alertas} alerta{estoque.alertas > 1 ? 's' : ''}
                  </Badge>
                )}
              </div>
              <Button 
                variant="ghost" 
                className="w-full mt-4"
                onClick={() => navigate(createPageUrl(estoque.path))}
              >
                Gerenciar <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}