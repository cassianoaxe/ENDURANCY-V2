import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Users, 
  TrendingUp, 
  Bell, 
  ShoppingBag, 
  Leaf, 
  FilePlus, 
  CreditCard,
  Clock,
  CheckCircle2,
  XCircle,
  Calendar,
  MoreHorizontal,
  FileText,
  Search,
  Plus,
  UserPlus,
  AlertTriangle,
  BarChart3,
  Package
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

// Sample data for charts
const salesData = [
  { month: 'Jan', total: 12000 },
  { month: 'Fev', total: 18000 },
  { month: 'Mar', total: 15000 },
  { month: 'Abr', total: 22000 },
  { month: 'Mai', total: 28000 },
  { month: 'Jun', total: 32000 },
  { month: 'Jul', total: 40000 }
];

const newUserData = [
  { month: 'Jan', count: 10 },
  { month: 'Fev', count: 15 },
  { month: 'Mar', count: 18 },
  { month: 'Abr', count: 25 },
  { month: 'Mai', count: 30 },
  { month: 'Jun', count: 35 },
  { month: 'Jul', count: 42 }
];

const productCategoryData = [
  { name: 'Óleo', value: 45 },
  { name: 'Cápsula', value: 25 },
  { name: 'Flor', value: 15 },
  { name: 'Extrato', value: 10 },
  { name: 'Tópico', value: 5 }
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

// Sample data for recent orders
const recentOrders = [
  {
    id: '1001',
    patient: 'Maria Silva',
    amount: 356.80,
    date: '22/07/2023',
    status: 'entregue'
  },
  {
    id: '1002',
    patient: 'João Pereira',
    amount: 124.50,
    date: '21/07/2023',
    status: 'enviado'
  },
  {
    id: '1003',
    patient: 'Ana Costa',
    amount: 289.90,
    date: '20/07/2023',
    status: 'preparando'
  },
  {
    id: '1004',
    patient: 'Carlos Santos',
    amount: 432.15,
    date: '19/07/2023',
    status: 'aprovado'
  }
];

// Sample data for pending prescriptions
const pendingPrescriptions = [
  {
    id: '2001',
    patient: 'Luciana Mendes',
    doctor: 'Dr. Carlos Santos',
    date: '22/07/2023',
    products: ['Óleo CBD 10%', 'Cápsulas THC/CBD 1:20']
  },
  {
    id: '2002',
    patient: 'Roberto Alves',
    doctor: 'Dra. Márcia Oliveira',
    date: '22/07/2023',
    products: ['Óleo CBD 5%']
  },
  {
    id: '2003',
    patient: 'Fernanda Lima',
    doctor: 'Dr. João Paulo',
    date: '21/07/2023',
    products: ['Extrato Full Spectrum', 'Creme Tópico CBD']
  },
  {
    id: '2004',
    patient: 'Paulo Rodrigues',
    doctor: 'Dra. Ana Beatriz',
    date: '21/07/2023',
    products: ['Óleo CBD 15%', 'Spray Sublingual THC/CBD']
  }
];

// Sample data for low stock products
const lowStockProducts = [
  {
    id: 'P001',
    name: 'Óleo CBD 10% 30ml',
    stock: 5,
    threshold: 10,
    batch: 'LOT-2023-063'
  },
  {
    id: 'P002',
    name: 'Cápsulas CBD 20mg',
    stock: 8,
    threshold: 15,
    batch: 'LOT-2023-058'
  },
  {
    id: 'P003',
    name: 'Extrato Full Spectrum 10ml',
    stock: 3,
    threshold: 8,
    batch: 'LOT-2023-049'
  }
];

export default function OrgDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [organization, setOrganization] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({
    patients: 128,
    products: 24,
    pendingPrescriptions: 12,
    monthlySales: 42580
  });

  useEffect(() => {
    // Using setTimeout to simulate data loading
    setTimeout(() => {
      setLoading(false);
      setOrganization({ 
        id: 'org1', 
        name: 'Organização Demonstração',
        type: 'Empresa',
        status: 'Ativo' 
      });
    }, 500);
  }, []);

  const getStatusBadge = (status) => {
    switch (status) {
      case 'entregue':
        return <Badge className="bg-green-100 text-green-800">Entregue</Badge>;
      case 'enviado':
        return <Badge className="bg-blue-100 text-blue-800">Enviado</Badge>;
      case 'preparando':
        return <Badge className="bg-yellow-100 text-yellow-800">Preparando</Badge>;
      case 'aprovado':
        return <Badge className="bg-purple-100 text-purple-800">Aprovado</Badge>;
      case 'pendente':
        return <Badge className="bg-gray-100 text-gray-800">Pendente</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-gray-500 mt-1">
            Gerencie sua organização, pacientes e produtos na plataforma Endurancy
          </p>
        </div>
        
        <div className="flex gap-2">
          <Link to={createPageUrl("Patients")}>
            <Button className="gap-2 bg-green-600 hover:bg-green-700">
              <UserPlus className="w-4 h-4" />
              Novo Paciente
            </Button>
          </Link>
          <Link to={createPageUrl("Products")}>
            <Button variant="outline" className="gap-2">
              <Plus className="w-4 h-4" />
              Novo Produto
            </Button>
          </Link>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg mb-4">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2" />
            <span>{error}</span>
          </div>
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="patients">Pacientes</TabsTrigger>
          <TabsTrigger value="products">Produtos</TabsTrigger>
          <TabsTrigger value="prescriptions">Prescrições</TabsTrigger>
          <TabsTrigger value="orders">Pedidos</TabsTrigger>
          <TabsTrigger value="production">Produção</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardDescription>Total de Pacientes</CardDescription>
                    <CardTitle className="text-3xl font-bold">
                      {loading ? '...' : stats.patients}
                    </CardTitle>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <Users className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-blue-600 mt-2">
                  <TrendingUp className="w-4 h-4 mr-1" />
                  +8 novos pacientes este mês
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardDescription>Produtos Ativos</CardDescription>
                    <CardTitle className="text-3xl font-bold">
                      {loading ? '...' : stats.products}
                    </CardTitle>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <Leaf className="w-5 h-5 text-green-600" />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-green-600 mt-2">
                  <TrendingUp className="w-4 h-4 mr-1" />
                  +3 novos produtos adicionados
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardDescription>Prescrições Pendentes</CardDescription>
                    <CardTitle className="text-3xl font-bold">
                      {loading ? '...' : stats.pendingPrescriptions}
                    </CardTitle>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded-lg">
                    <FilePlus className="w-5 h-5 text-yellow-600" />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-yellow-600 mt-2">
                  <Clock className="w-4 h-4 mr-1" />
                  5 novas nas últimas 24h
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardDescription>Faturamento Mensal</CardDescription>
                    <CardTitle className="text-3xl font-bold">
                      {loading ? '...' : `R$ ${stats.monthlySales.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
                    </CardTitle>
                  </div>
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <CreditCard className="w-5 h-5 text-purple-600" />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-purple-600 mt-2">
                  <TrendingUp className="w-4 h-4 mr-1" />
                  +12% comparado ao mês anterior
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Vendas Mensais</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`R$ ${value.toLocaleString()}`, 'Total']}
                        labelFormatter={(label) => `Mês: ${label}`}
                      />
                      <Legend />
                      <Bar dataKey="total" name="Vendas (R$)" fill="#4CAF50" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Distribuição de Produtos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={productCategoryData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {productCategoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} produtos`, 'Quantidade']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Orders and Prescriptions */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Pedidos Recentes</CardTitle>
                  <Link to={createPageUrl("Orders")}>
                    <Button variant="ghost" size="sm">Ver todos</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentOrders.map((order) => (
                    <div key={order.id} className="flex justify-between items-center p-3 hover:bg-gray-50 rounded-lg cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-50 rounded-lg">
                          <ShoppingBag className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium">Pedido #{order.id}</p>
                          <div className="flex items-center text-sm text-gray-500 gap-2">
                            <span>{order.patient}</span>
                            <span>•</span>
                            <span>R$ {order.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                          </div>
                        </div>
                      </div>
                      {getStatusBadge(order.status)}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Prescrições para Aprovação</CardTitle>
                  <Link to={createPageUrl("Prescriptions")}>
                    <Button variant="ghost" size="sm">Ver todas</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingPrescriptions.map((prescription) => (
                    <div key={prescription.id} className="flex justify-between items-center p-3 hover:bg-gray-50 rounded-lg cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-yellow-50 rounded-lg">
                          <FilePlus className="w-5 h-5 text-yellow-600" />
                        </div>
                        <div>
                          <p className="font-medium">{prescription.patient}</p>
                          <div className="flex items-center text-sm text-gray-500 gap-2">
                            <span>{prescription.doctor}</span>
                            <span>•</span>
                            <span>{prescription.date}</span>
                          </div>
                        </div>
                      </div>
                      <Button size="sm">Revisar</Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Alerts and Low Stock */}
          <Card>
            <CardHeader>
              <CardTitle>Produtos com Estoque Baixo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {lowStockProducts.map((product) => (
                  <div key={product.id} className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white rounded-lg">
                        <AlertTriangle className="w-5 h-5 text-red-600" />
                      </div>
                      <div>
                        <p className="font-medium">{product.name}</p>
                        <div className="flex items-center text-sm text-gray-700 gap-2">
                          <span>Estoque: {product.stock} unidades</span>
                          <span>•</span>
                          <span>Lote: {product.batch}</span>
                        </div>
                      </div>
                    </div>
                    <Link to={`${createPageUrl("Products")}?id=${product.id}`}>
                      <Button variant="outline" size="sm">Gerenciar</Button>
                    </Link>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patients">
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Buscar pacientes..."
                  className="pl-8 w-full md:w-80"
                />
              </div>
              <Link to={createPageUrl("NewPatient")}>
                <Button className="w-full md:w-auto gap-2">
                  <UserPlus className="h-4 w-4" />
                  Novo Paciente
                </Button>
              </Link>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Pacientes Recentes</CardTitle>
              </CardHeader>
              <CardContent>
                <Link to={createPageUrl("Patients")}>
                  <Button className="w-full">Ver todos os pacientes</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="products">
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Buscar produtos..."
                  className="pl-8 w-full md:w-80"
                />
              </div>
              <Link to={createPageUrl("NewProduct")}>
                <Button className="w-full md:w-auto gap-2">
                  <Plus className="h-4 w-4" />
                  Novo Produto
                </Button>
              </Link>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Gerenciamento de Produtos</CardTitle>
              </CardHeader>
              <CardContent>
                <Link to={createPageUrl("Products")}>
                  <Button className="w-full">Ver todos os produtos</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="prescriptions">
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Buscar prescrições..."
                  className="pl-8 w-full md:w-80"
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline">Todas</Button>
                <Button variant="outline" className="bg-yellow-50">Pendentes ({stats.pendingPrescriptions})</Button>
                <Button variant="outline" className="bg-green-50">Aprovadas</Button>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Prescrições Pendentes</CardTitle>
              </CardHeader>
              <CardContent>
                <Link to={createPageUrl("Prescriptions")}>
                  <Button className="w-full">Gerenciar prescrições</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="orders">
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Buscar pedidos..."
                  className="pl-8 w-full md:w-80"
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline">Todos</Button>
                <Button variant="outline" className="bg-yellow-50">Pendentes</Button>
                <Button variant="outline" className="bg-blue-50">Enviados</Button>
                <Button variant="outline" className="bg-green-50">Entregues</Button>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Pedidos Recentes</CardTitle>
              </CardHeader>
              <CardContent>
                <Link to={createPageUrl("Orders")}>
                  <Button className="w-full">Gerenciar pedidos</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="production">
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-green-50 rounded-lg">
                  <Package className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium">Rastreamento de Produção</h3>
                  <p className="text-sm text-gray-500">Monitore cada etapa do processo produtivo</p>
                </div>
              </div>
              <Link to={createPageUrl("Production")}>
                <Button className="w-full md:w-auto gap-2">
                  <Plus className="h-4 w-4" />
                  Novo Lote
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Lotes em Produção</CardTitle>
                </CardHeader>
                <CardContent>
                  <Link to={createPageUrl("Production")}>
                    <Button className="w-full">Ver produção</Button>
                  </Link>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Controle de Qualidade</CardTitle>
                </CardHeader>
                <CardContent>
                  <Link to={`${createPageUrl("Production")}?tab=quality`}>
                    <Button className="w-full">Ver relatórios</Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}