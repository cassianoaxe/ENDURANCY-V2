import React, { useState, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from 'recharts';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Calendar, 
  TrendingUp, 
  Users, 
  Building2, 
  Activity, 
  Leaf, 
  DollarSign, 
  FileText, 
  Download,
  Heart
} from "lucide-react";

// Dados simulados
const organizationData = [
  { mes: 'Jan', novas: 8, ativas: 32, taxa: 25 },
  { mes: 'Fev', novas: 12, ativas: 44, taxa: 27 },
  { mes: 'Mar', novas: 15, ativas: 58, taxa: 26 },
  { mes: 'Abr', novas: 18, ativas: 75, taxa: 24 },
  { mes: 'Mai', novas: 16, ativas: 90, taxa: 18 },
  { mes: 'Jun', novas: 20, ativas: 110, taxa: 18 },
  { mes: 'Jul', novas: 25, ativas: 130, taxa: 19 }
];

const revenuaData = [
  { mes: 'Jan', receita: 40000, crescimento: 0 },
  { mes: 'Fev', receita: 52000, crescimento: 30 },
  { mes: 'Mar', receita: 61000, crescimento: 17 },
  { mes: 'Abr', receita: 78000, crescimento: 28 },
  { mes: 'Mai', receita: 91000, crescimento: 17 },
  { mes: 'Jun', receita: 112000, crescimento: 23 },
  { mes: 'Jul', receita: 135000, crescimento: 21 }
];

const moduleUsageData = [
  { nome: 'Cultivo', usuarios: 48, cor: '#22c55e' },
  { nome: 'Produção', usuarios: 36, cor: '#eab308' },
  { nome: 'CRM', usuarios: 52, cor: '#a855f7' },
  { nome: 'RH', usuarios: 28, cor: '#6366f1' },
  { nome: 'Transparência', usuarios: 22, cor: '#3b82f6' }
];

const moduleRevenueData = [
  { nome: 'Cultivo', receita: 42500, cor: '#22c55e' },
  { nome: 'Produção', receita: 32800, cor: '#eab308' },
  { nome: 'CRM', receita: 38600, cor: '#a855f7' },
  { nome: 'RH', receita: 22500, cor: '#6366f1' },
  { nome: 'Transparência', receita: 18200, cor: '#3b82f6' }
];

const trafficSourceData = [
  { fonte: 'Orgânico', valor: 38, cor: '#22c55e' },
  { fonte: 'Referências', valor: 12, cor: '#3b82f6' },
  { fonte: 'Direto', valor: 25, cor: '#a855f7' },
  { fonte: 'Social', valor: 15, cor: '#eab308' },
  { fonte: 'Outros', valor: 10, cor: '#6366f1' }
];

const userActivityData = [
  { data: '2023-07-01', usuarios: 145, sessoes: 420 },
  { data: '2023-07-02', usuarios: 132, sessoes: 380 },
  { data: '2023-07-03', usuarios: 156, sessoes: 460 },
  { data: '2023-07-04', usuarios: 142, sessoes: 410 },
  { data: '2023-07-05', usuarios: 168, sessoes: 490 },
  { data: '2023-07-06', usuarios: 178, sessoes: 510 },
  { data: '2023-07-07', usuarios: 162, sessoes: 480 },
  { data: '2023-07-08', usuarios: 158, sessoes: 470 },
  { data: '2023-07-09', usuarios: 170, sessoes: 500 },
  { data: '2023-07-10', usuarios: 182, sessoes: 530 },
  { data: '2023-07-11', usuarios: 175, sessoes: 520 },
  { data: '2023-07-12', usuarios: 192, sessoes: 550 },
  { data: '2023-07-13', usuarios: 185, sessoes: 540 },
  { data: '2023-07-14', usuarios: 188, sessoes: 545 }
];

export default function Analytics() {
  const [period, setPeriod] = useState('mes');
  const [userType, setUserType] = useState('superadmin');
  
  // Função para formatar números em reais
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };
  
  // Componente de tooltip personalizado para gráficos
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border rounded shadow-sm">
          <p className="text-sm font-medium">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.dataKey.includes('receita') ? formatCurrency(entry.value) : entry.value}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  // Conteúdo simplificado para evitar erros de renderização
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Analytics</h1>
          <p className="text-gray-500 mt-1">
            Visão detalhada do desempenho da plataforma e organizações
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-36">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <SelectValue placeholder="Período" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="dia">Diário</SelectItem>
              <SelectItem value="semana">Semanal</SelectItem>
              <SelectItem value="mes">Mensal</SelectItem>
              <SelectItem value="ano">Anual</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Exportar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Receita Total</CardDescription>
            <div className="flex items-end justify-between">
              <CardTitle className="text-3xl font-bold">R$ 135.000</CardTitle>
              <div className="flex items-center text-green-600 font-medium gap-1">
                <ArrowUpRight className="w-4 h-4" />
                <span>21%</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500 text-sm">vs. R$ 112.000 mês passado</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Organizações Ativas</CardDescription>
            <div className="flex items-end justify-between">
              <CardTitle className="text-3xl font-bold">130</CardTitle>
              <div className="flex items-center text-green-600 font-medium gap-1">
                <ArrowUpRight className="w-4 h-4" />
                <span>18.2%</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500 text-sm">vs. 110 mês passado</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Taxa de Conversão</CardDescription>
            <div className="flex items-end justify-between">
              <CardTitle className="text-3xl font-bold">19%</CardTitle>
              <div className="flex items-center text-amber-600 font-medium gap-1">
                <ArrowUpRight className="w-4 h-4" />
                <span>5.5%</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500 text-sm">vs. 18% mês passado</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Usuários Ativos</CardDescription>
            <div className="flex items-end justify-between">
              <CardTitle className="text-3xl font-bold">628</CardTitle>
              <div className="flex items-center text-green-600 font-medium gap-1">
                <ArrowUpRight className="w-4 h-4" />
                <span>12.3%</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500 text-sm">vs. 559 mês passado</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Crescimento de Organizações</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={organizationData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="mes" />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar name="Novas Organizações" dataKey="novas" fill="#3b82f6" />
                <Bar name="Organizações Ativas" dataKey="ativas" fill="#22c55e" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Receita Mensal</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={revenuaData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="mes" />
                <YAxis formatter={(value) => `R$${value/1000}k`} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Line 
                  type="monotone" 
                  name="Receita" 
                  dataKey="receita" 
                  stroke="#22c55e" 
                  strokeWidth={2} 
                  activeDot={{ r: 8 }} 
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Uso de Módulos</CardTitle>
            <CardDescription>
              Número de organizações por módulo
            </CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={moduleUsageData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="usuarios"
                  nameKey="nome"
                  label={({nome, percent}) => `${nome}: ${(percent * 100).toFixed(0)}%`}
                >
                  {moduleUsageData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.cor} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`${value} organizações`, 'Usuários']} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Receita por Módulo</CardTitle>
            <CardDescription>
              Distribuição de receita mensal
            </CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={moduleRevenueData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="receita"
                  nameKey="nome"
                  label={({nome, percent}) => `${nome}: ${(percent * 100).toFixed(0)}%`}
                >
                  {moduleRevenueData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.cor} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [formatCurrency(value), 'Receita']} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Fontes de Tráfego</CardTitle>
            <CardDescription>
              Origem dos acessos à plataforma
            </CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={trafficSourceData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="valor"
                  nameKey="fonte"
                  label={({fonte, percent}) => `${fonte}: ${(percent * 100).toFixed(0)}%`}
                >
                  {trafficSourceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.cor} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`${value}%`, 'Porcentagem']} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}