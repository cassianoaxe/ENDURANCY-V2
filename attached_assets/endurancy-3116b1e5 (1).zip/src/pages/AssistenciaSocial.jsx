import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Heart,
  Users,
  Search,
  Filter,
  Calendar,
  ChevronDown,
  Edit,
  Eye,
  Download,
  BarChart4,
  PieChart,
  ArrowUpRight,
  Plus,
  FileText,
  CheckCircle,
  XCircle,
  Clock,
  HelpCircle,
  MoreHorizontal,
  Pill,
  Activity,
  User,
  Phone,
  Mail,
  MapPin,
  AlertTriangle,
  UserPlus,
  DollarSign,
  Check,
  FileSpreadsheet,
  AreaChart,
  LineChart,
  TrendingUp,
  Home,
  Printer,
  CircleDollarSign,
  ClipboardList,
  Stethoscope,
  GraduationCap,
  UserCheck,
  Percent
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Alert, 
  AlertDescription, 
  AlertTitle 
} from "@/components/ui/alert";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RechartsPieChart, Pie, Cell, LineChart as RechartsLineChart, Line } from 'recharts';

// Sample data for beneficiaries
const beneficiariesData = [
  {
    id: "1",
    nome: "Maria Silva",
    cpf: "123.456.789-00",
    data_nascimento: "1975-04-12",
    telefone: "(11) 98765-4321",
    email: "maria.silva@email.com",
    endereco: {
      cep: "01234-567",
      logradouro: "Rua das Flores",
      numero: "123",
      complemento: "Apto 45",
      bairro: "Jardim Primavera",
      cidade: "São Paulo",
      estado: "SP"
    },
    condicao_medica: "Epilepsia Refratária",
    data_ingresso: "2022-06-15",
    situacao: "ativo",
    valor_subsidio: 350.00,
    percentual_isencao: 100,
    ultima_consulta: "2023-10-10",
    proxima_consulta: "2024-01-10",
    medicamentos: ["Canabidiol 200mg", "Clobazam 10mg"],
    ultima_atualizacao: "2023-10-10T14:30:00Z"
  },
  {
    id: "2",
    nome: "João Santos",
    cpf: "987.654.321-00",
    data_nascimento: "1980-07-22",
    telefone: "(11) 91234-5678",
    email: "joao.santos@email.com",
    endereco: {
      cep: "04321-765",
      logradouro: "Av. Principal",
      numero: "456",
      complemento: "Casa 2",
      bairro: "Centro",
      cidade: "São Paulo",
      estado: "SP"
    },
    condicao_medica: "Dor Crônica Neuropática",
    data_ingresso: "2022-08-20",
    situacao: "ativo",
    valor_subsidio: 250.00,
    percentual_isencao: 75,
    ultima_consulta: "2023-09-05",
    proxima_consulta: "2024-02-05",
    medicamentos: ["Canabidiol 100mg", "Pregabalina 75mg"],
    ultima_atualizacao: "2023-09-05T10:15:00Z"
  },
  {
    id: "3",
    nome: "Ana Oliveira",
    cpf: "456.789.123-00",
    data_nascimento: "1990-01-30",
    telefone: "(11) 95555-9999",
    email: "ana.oliveira@email.com",
    endereco: {
      cep: "05678-901",
      logradouro: "Rua dos Pinheiros",
      numero: "789",
      complemento: "",
      bairro: "Pinheiros",
      cidade: "São Paulo",
      estado: "SP"
    },
    condicao_medica: "Síndrome de Dravet",
    data_ingresso: "2022-09-10",
    situacao: "pendente_reavaliacao",
    valor_subsidio: 400.00,
    percentual_isencao: 100,
    ultima_consulta: "2023-08-15",
    proxima_consulta: "2024-01-15",
    medicamentos: ["Canabidiol 300mg", "Valproato de Sódio 500mg"],
    ultima_atualizacao: "2023-11-01T11:20:00Z"
  },
  {
    id: "4",
    nome: "Carlos Pereira",
    cpf: "789.123.456-00",
    data_nascimento: "1965-11-05",
    telefone: "(11) 94444-8888",
    email: "carlos.pereira@email.com",
    endereco: {
      cep: "03210-654",
      logradouro: "Alameda dos Anjos",
      numero: "321",
      complemento: "Bloco B, Apto 12",
      bairro: "Vila Mariana",
      cidade: "São Paulo",
      estado: "SP"
    },
    condicao_medica: "Parkinson",
    data_ingresso: "2022-10-05",
    situacao: "ativo",
    valor_subsidio: 300.00,
    percentual_isencao: 80,
    ultima_consulta: "2023-10-20",
    proxima_consulta: "2024-02-20",
    medicamentos: ["Canabidiol 150mg", "Levodopa 250mg"],
    ultima_atualizacao: "2023-10-20T16:45:00Z"
  },
  {
    id: "5",
    nome: "Fernanda Lima",
    cpf: "321.654.987-00",
    data_nascimento: "1985-03-25",
    telefone: "(11) 93333-7777",
    email: "fernanda.lima@email.com",
    endereco: {
      cep: "02109-876",
      logradouro: "Rua das Palmeiras",
      numero: "654",
      complemento: "Casa",
      bairro: "Jardim Paulista",
      cidade: "São Paulo",
      estado: "SP"
    },
    condicao_medica: "Fibromialgia",
    data_ingresso: "2022-11-15",
    situacao: "inativo",
    valor_subsidio: 200.00,
    percentual_isencao: 60,
    ultima_consulta: "2023-07-10",
    proxima_consulta: null,
    medicamentos: ["Canabidiol 100mg", "Duloxetina 60mg"],
    ultima_atualizacao: "2023-07-10T09:30:00Z"
  }
];

// Sample data for program metrics
const programMetrics = {
  totalBeneficiaries: 320,
  activeBeneficiaries: 275,
  pendingReview: 30,
  inactive: 15,
  totalInvestment: 85000,
  averageSubsidy: 265.62,
  newBeneficiariesLastMonth: 25,
  improvementReports: 210,
  qualityOfLifeImprovement: 82,
  medicationCostReduction: 65,
  hospitalVisitsReduction: 58,
  familySatisfaction: 94
};

// Sample data for charts
const monthlyBeneficiariesData = [
  { month: 'Jan', count: 210 },
  { month: 'Feb', count: 230 },
  { month: 'Mar', count: 245 },
  { month: 'Apr', count: 260 },
  { month: 'May', count: 270 },
  { month: 'Jun', count: 285 },
  { month: 'Jul', count: 295 },
  { month: 'Aug', count: 305 },
  { month: 'Sep', count: 310 },
  { month: 'Oct', count: 315 },
  { month: 'Nov', count: 320 },
  { month: 'Dec', count: 320 }
];

const conditionDistributionData = [
  { name: 'Epilepsy', value: 95 },
  { name: 'Chronic Pain', value: 75 },
  { name: 'Parkinson\'s', value: 45 },
  { name: 'Multiple Sclerosis', value: 35 },
  { name: 'Anxiety/Depression', value: 40 },
  { name: 'Other', value: 30 }
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

const impactData = [
  { month: 'Jan', qol: 65, hosp: 45, med: 55 },
  { month: 'Feb', qol: 68, hosp: 48, med: 58 },
  { month: 'Mar', qol: 70, hosp: 50, med: 60 },
  { month: 'Apr', qol: 72, hosp: 52, med: 62 },
  { month: 'May', qol: 75, hosp: 53, med: 63 },
  { month: 'Jun', qol: 78, hosp: 54, med: 64 },
  { month: 'Jul', qol: 80, hosp: 56, med: 65 },
  { month: 'Aug', qol: 82, hosp: 58, med: 65 },
  { month: 'Sep', qol: 83, hosp: 58, med: 66 },
  { month: 'Oct', qol: 84, hosp: 60, med: 67 },
  { month: 'Nov', qol: 85, hosp: 61, med: 68 },
  { month: 'Dec', qol: 87, hosp: 63, med: 70 }
];

export default function AssistenciaSocial() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [beneficiaries, setBeneficiaries] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [selectedBeneficiary, setSelectedBeneficiary] = useState(null);
  const [reportType, setReportType] = useState("beneficiary-list");
  const [reportFormat, setReportFormat] = useState("pdf");
  const [dateRange, setDateRange] = useState("last-month");

  useEffect(() => {
    loadBeneficiaries();
  }, []);

  const loadBeneficiaries = async () => {
    setIsLoading(true);
    try {
      // In a real application, this would be an API call
      setTimeout(() => {
        setBeneficiaries(beneficiariesData);
        setIsLoading(false);
      }, 1000);
    } catch (error) {
      console.error("Error loading beneficiaries:", error);
      setIsLoading(false);
    }
  };

  const handleViewDetails = (beneficiary) => {
    setSelectedBeneficiary(beneficiary);
    setShowDetailDialog(true);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(new Date(dateString));
  };

  const generateReport = () => {
    // In a real application, this would generate and download a report
    console.log(`Generating ${reportType} report in ${reportFormat} format for ${dateRange} period`);
    alert(`Relatório sendo gerado. Em uma aplicação real, isso baixaria um arquivo ${reportFormat}.`);
  };

  const renderDashboard = () => {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Total de Beneficiários</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <div className="text-2xl font-bold">{programMetrics.totalBeneficiaries}</div>
                <Users className="h-8 w-8 text-blue-500" />
              </div>
              <div className="flex items-center text-sm text-green-600 mt-2">
                <ArrowUpRight className="h-4 w-4 mr-1" />
                <span>+{programMetrics.newBeneficiariesLastMonth} no último mês</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Valor Total Investido</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <div className="text-2xl font-bold">{formatCurrency(programMetrics.totalInvestment)}</div>
                <DollarSign className="h-8 w-8 text-green-500" />
              </div>
              <div className="flex items-center text-sm text-gray-500 mt-2">
                <span>Média por beneficiário: {formatCurrency(programMetrics.averageSubsidy)}</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Melhoria na Qualidade de Vida</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <div className="text-2xl font-bold">{programMetrics.qualityOfLifeImprovement}%</div>
                <Activity className="h-8 w-8 text-purple-500" />
              </div>
              <div className="flex items-center text-sm text-gray-500 mt-2">
                <span>Baseado em {programMetrics.improvementReports} relatórios</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Satisfação das Famílias</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <div className="text-2xl font-bold">{programMetrics.familySatisfaction}%</div>
                <Heart className="h-8 w-8 text-red-500" />
              </div>
              <div className="flex items-center text-sm text-gray-500 mt-2">
                <span>Baseado em pesquisas de satisfação</span>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Evolução do Número de Beneficiários</CardTitle>
              <CardDescription>Total de beneficiários por mês durante o último ano</CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyBeneficiariesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="count" name="Beneficiários" fill="#4f46e5" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Distribuição por Condição Médica</CardTitle>
              <CardDescription>Beneficiários atendidos por tipo de condição</CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie
                    data={conditionDistributionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {conditionDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </RechartsPieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Indicadores de Impacto Mensal</CardTitle>
              <CardDescription>Evolução dos principais indicadores de impacto do programa</CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsLineChart data={impactData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="qol" name="Qualidade de Vida (%)" stroke="#8884d8" />
                  <Line type="monotone" dataKey="hosp" name="Redução Hospitalização (%)" stroke="#82ca9d" />
                  <Line type="monotone" dataKey="med" name="Redução Custo Medicamentos (%)" stroke="#ffc658" />
                </RechartsLineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Status dos Beneficiários</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Ativos</span>
                    <span className="text-sm font-medium">{programMetrics.activeBeneficiaries}</span>
                  </div>
                  <Progress value={(programMetrics.activeBeneficiaries / programMetrics.totalBeneficiaries) * 100} className="h-2 bg-gray-200" />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Pendentes de Reavaliação</span>
                    <span className="text-sm font-medium">{programMetrics.pendingReview}</span>
                  </div>
                  <Progress value={(programMetrics.pendingReview / programMetrics.totalBeneficiaries) * 100} className="h-2 bg-gray-200" />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Inativos</span>
                    <span className="text-sm font-medium">{programMetrics.inactive}</span>
                  </div>
                  <Progress value={(programMetrics.inactive / programMetrics.totalBeneficiaries) * 100} className="h-2 bg-gray-200" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Impacto do Programa</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Melhoria na Qualidade de Vida</span>
                    <span className="text-sm font-medium">{programMetrics.qualityOfLifeImprovement}%</span>
                  </div>
                  <Progress value={programMetrics.qualityOfLifeImprovement} className="h-2 bg-gray-200" />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Redução de Custos com Medicamentos</span>
                    <span className="text-sm font-medium">{programMetrics.medicationCostReduction}%</span>
                  </div>
                  <Progress value={programMetrics.medicationCostReduction} className="h-2 bg-gray-200" />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Redução de Visitas Hospitalares</span>
                    <span className="text-sm font-medium">{programMetrics.hospitalVisitsReduction}%</span>
                  </div>
                  <Progress value={programMetrics.hospitalVisitsReduction} className="h-2 bg-gray-200" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ações Rápidas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button className="w-full" onClick={() => setActiveTab("beneficiarios")}>
                  <UserPlus className="mr-2 h-4 w-4" />
                  Cadastrar Novo Beneficiário
                </Button>
                <Button className="w-full" onClick={() => setActiveTab("relatorios")}>
                  <FileText className="mr-2 h-4 w-4" />
                  Gerar Relatórios
                </Button>
                <Button className="w-full" variant="outline">
                  <Calendar className="mr-2 h-4 w-4" />
                  Agendar Reavaliações
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  const renderBeneficiaries = () => {
    const filteredBeneficiaries = beneficiaries.filter(beneficiary => {
      const matchesSearch = 
        beneficiary.nome.toLowerCase().includes(searchQuery.toLowerCase()) ||
        beneficiary.cpf.includes(searchQuery) ||
        beneficiary.condicao_medica.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesStatus = 
        statusFilter === "all" || 
        beneficiary.situacao === statusFilter;
      
      return matchesSearch && matchesStatus;
    });

    return (
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
            <Input
              placeholder="Buscar por nome, CPF ou condição médica..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-4">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Status</SelectItem>
                <SelectItem value="ativo">Ativo</SelectItem>
                <SelectItem value="pendente_reavaliacao">Pendente Reavaliação</SelectItem>
                <SelectItem value="inativo">Inativo</SelectItem>
              </SelectContent>
            </Select>
            
            <Button onClick={() => {}} className="hidden md:flex">
              <Download className="mr-2 h-4 w-4" />
              Exportar
            </Button>
            
            <Button onClick={() => {}} className="bg-green-600 hover:bg-green-700">
              <Plus className="mr-2 h-4 w-4" />
              Novo Beneficiário
            </Button>
          </div>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        ) : (
          <>
            {filteredBeneficiaries.length === 0 ? (
              <div className="bg-white rounded-lg shadow p-8 text-center">
                <UserPlus className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">Nenhum beneficiário encontrado</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Tente ajustar seus filtros ou cadastre um novo beneficiário.
                </p>
                <div className="mt-6">
                  <Button onClick={() => {}}>
                    <Plus className="mr-2 h-4 w-4" />
                    Novo Beneficiário
                  </Button>
                </div>
              </div>
            ) : (
              <Card>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nome</TableHead>
                        <TableHead>CPF</TableHead>
                        <TableHead>Condição Médica</TableHead>
                        <TableHead>Data de Ingresso</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Subsídio</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredBeneficiaries.map((beneficiary) => (
                        <TableRow key={beneficiary.id}>
                          <TableCell className="font-medium">{beneficiary.nome}</TableCell>
                          <TableCell>{beneficiary.cpf}</TableCell>
                          <TableCell>{beneficiary.condicao_medica}</TableCell>
                          <TableCell>{formatDate(beneficiary.data_ingresso)}</TableCell>
                          <TableCell>
                            <Badge className={
                              beneficiary.situacao === "ativo" 
                                ? "bg-green-100 text-green-800" 
                                : beneficiary.situacao === "pendente_reavaliacao"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-gray-100 text-gray-800"
                            }>
                              {beneficiary.situacao === "ativo" 
                                ? "Ativo" 
                                : beneficiary.situacao === "pendente_reavaliacao"
                                ? "Pendente Reavaliação"
                                : "Inativo"}
                            </Badge>
                          </TableCell>
                          <TableCell>{formatCurrency(beneficiary.valor_subsidio)}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Abrir menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleViewDetails(beneficiary)}>
                                  <Eye className="mr-2 h-4 w-4" />
                                  <span>Ver Detalhes</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="mr-2 h-4 w-4" />
                                  <span>Editar</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Calendar className="mr-2 h-4 w-4" />
                                  <span>Agendar Reavaliação</span>
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">
                                  <XCircle className="mr-2 h-4 w-4" />
                                  <span>Desativar</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )}
          </>
        )}

        {/* Beneficiary Details Dialog */}
        <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
          <DialogContent className="max-w-3xl">
            {selectedBeneficiary && (
              <>
                <DialogHeader>
                  <DialogTitle className="text-2xl">Detalhes do Beneficiário</DialogTitle>
                </DialogHeader>
                
                <Tabs defaultValue="info" className="mt-4">
                  <TabsList>
                    <TabsTrigger value="info">Informações Pessoais</TabsTrigger>
                    <TabsTrigger value="medical">Informações Médicas</TabsTrigger>
                    <TabsTrigger value="financial">Informações Financeiras</TabsTrigger>
                    <TabsTrigger value="history">Histórico</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="info" className="mt-4 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-medium mb-4">Dados Pessoais</h3>
                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Nome:</span>
                            <span>{selectedBeneficiary.nome}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <FileText className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">CPF:</span>
                            <span>{selectedBeneficiary.cpf}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Data de Nascimento:</span>
                            <span>{formatDate(selectedBeneficiary.data_nascimento)}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-medium mb-4">Contato</h3>
                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <Phone className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Telefone:</span>
                            <span>{selectedBeneficiary.telefone}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Email:</span>
                            <span>{selectedBeneficiary.email}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-medium mb-4">Endereço</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-gray-500" />
                          <span className="font-medium">CEP:</span>
                          <span>{selectedBeneficiary.endereco.cep}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-gray-500" />
                          <span className="font-medium">Logradouro:</span>
                          <span>{selectedBeneficiary.endereco.logradouro}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-gray-500" />
                          <span className="font-medium">Número:</span>
                          <span>{selectedBeneficiary.endereco.numero}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-gray-500" />
                          <span className="font-medium">Complemento:</span>
                          <span>{selectedBeneficiary.endereco.complemento || "N/A"}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-gray-500" />
                          <span className="font-medium">Bairro:</span>
                          <span>{selectedBeneficiary.endereco.bairro}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-gray-500" />
                          <span className="font-medium">Cidade/UF:</span>
                          <span>{selectedBeneficiary.endereco.cidade}/{selectedBeneficiary.endereco.estado}</span>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="medical" className="mt-4 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-medium mb-4">Condição Médica</h3>
                        <div className="space-y-3">
                          <div className="flex items-start gap-2">
                            <Stethoscope className="h-4 w-4 text-gray-500 mt-1" />
                            <span className="font-medium">Diagnóstico:</span>
                            <span>{selectedBeneficiary.condicao_medica}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Última Consulta:</span>
                            <span>{formatDate(selectedBeneficiary.ultima_consulta)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Próxima Consulta:</span>
                            <span>{selectedBeneficiary.proxima_consulta ? formatDate(selectedBeneficiary.proxima_consulta) : "Não agendada"}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-medium mb-4">Medicamentos</h3>
                        <div className="space-y-2">
                          {selectedBeneficiary.medicamentos.map((medicamento, index) => (
                            <div key={index} className="flex items-center gap-2">
                              <Pill className="h-4 w-4 text-gray-500" />
                              <span>{medicamento}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="financial" className="mt-4 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-medium mb-4">Dados do Programa</h3>
                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Data de Ingresso:</span>
                            <span>{formatDate(selectedBeneficiary.data_ingresso)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Status:</span>
                            <Badge className={
                              selectedBeneficiary.situacao === "ativo" 
                                ? "bg-green-100 text-green-800" 
                                : selectedBeneficiary.situacao === "pendente_reavaliacao"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-gray-100 text-gray-800"
                            }>
                              {selectedBeneficiary.situacao === "ativo" 
                                ? "Ativo" 
                                : selectedBeneficiary.situacao === "pendente_reavaliacao"
                                ? "Pendente Reavaliação"
                                : "Inativo"}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-medium mb-4">Informações Financeiras</h3>
                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <DollarSign className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Valor do Subsídio:</span>
                            <span>{formatCurrency(selectedBeneficiary.valor_subsidio)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Percent className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">Percentual de Isenção:</span>
                            <span>{selectedBeneficiary.percentual_isencao}%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="history" className="mt-4 space-y-4">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Histórico de Atendimentos</h3>
                      <div className="bg-gray-50 p-4 rounded-lg text-center">
                        <p className="text-gray-500">Histórico não disponível na versão de demonstração.</p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
                
                <DialogFooter className="flex justify-between">
                  <div>
                    <Button variant="outline" onClick={() => {}}>
                      <FileText className="mr-2 h-4 w-4" />
                      Gerar Relatório
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setShowDetailDialog(false)}>
                      Fechar
                    </Button>
                    <Button onClick={() => {}}>
                      <Edit className="mr-2 h-4 w-4" />
                      Editar
                    </Button>
                  </div>
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    );
  };

  const renderReports = () => {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Geração de Relatórios</CardTitle>
            <CardDescription>
              Selecione o tipo de relatório, formato e período para gerar relatórios detalhados do programa de assistência social.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="report-type">Tipo de Relatório</Label>
                <Select value={reportType} onValueChange={setReportType}>
                  <SelectTrigger id="report-type">
                    <SelectValue placeholder="Selecione o tipo de relatório" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beneficiary-list">Lista de Beneficiários</SelectItem>
                    <SelectItem value="financial-summary">Resumo Financeiro</SelectItem>
                    <SelectItem value="impact-metrics">Métricas de Impacto</SelectItem>
                    <SelectItem value="medical-conditions">Distribuição de Condições Médicas</SelectItem>
                    <SelectItem value="demographic-analysis">Análise Demográfica</SelectItem>
                    <SelectItem value="comprehensive">Relatório Completo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="report-format">Formato do Relatório</Label>
                <Select value={reportFormat} onValueChange={setReportFormat}>
                  <SelectTrigger id="report-format">
                    <SelectValue placeholder="Selecione o formato" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pdf">PDF</SelectItem>
                    <SelectItem value="excel">Excel</SelectItem>
                    <SelectItem value="csv">CSV</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="date-range">Período</Label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger id="date-range">
                    <SelectValue placeholder="Selecione o período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last-month">Último Mês</SelectItem>
                    <SelectItem value="last-quarter">Último Trimestre</SelectItem>
                    <SelectItem value="last-year">Último Ano</SelectItem>
                    <SelectItem value="all-time">Todo o Período</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="mt-6">
              <Button onClick={generateReport} className="w-full md:w-auto">
                <FileText className="mr-2 h-4 w-4" />
                Gerar Relatório
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Relatórios Disponíveis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="bg-blue-50 p-2 rounded-lg">
                    <FileSpreadsheet className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Lista de Beneficiários</h4>
                    <p className="text-sm text-gray-500">Relatório completo com todos os beneficiários ativos e seus dados.</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-1 h-3 w-3" />
                        PDF
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="mr-1 h-3 w-3" />
                        Excel
                      </Button>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex items-start gap-3">
                  <div className="bg-green-50 p-2 rounded-lg">
                    <BarChart4 className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Métricas de Impacto Social</h4>
                    <p className="text-sm text-gray-500">Análise de impacto social do programa com indicadores de melhoria.</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-1 h-3 w-3" />
                        PDF
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="mr-1 h-3 w-3" />
                        Excel
                      </Button>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex items-start gap-3">
                  <div className="bg-purple-50 p-2 rounded-lg">
                    <CircleDollarSign className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Resumo Financeiro</h4>
                    <p className="text-sm text-gray-500">Análise financeira detalhada do programa de assistência social.</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        <Download className="mr-1 h-3 w-3" />
                        PDF
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="mr-1 h-3 w-3" />
                        Excel
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Relatórios Programados</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="bg-amber-50 p-2 rounded-lg">
                    <Clock className="h-6 w-6 text-amber-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Relatório Mensal</h4>
                    <p className="text-sm text-gray-500">Enviado automaticamente no primeiro dia de cada mês.</p>
                    <div className="text-xs text-gray-500 mt-1">Próximo envio: 01/12/2023</div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex items-start gap-3">
                  <div className="bg-pink-50 p-2 rounded-lg">
                    <Clock className="h-6 w-6 text-pink-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Relatório Trimestral</h4>
                    <p className="text-sm text-gray-500">Enviado automaticamente no primeiro dia de cada trimestre.</p>
                    <div className="text-xs text-gray-500 mt-1">Próximo envio: 01/01/2024</div>
                  </div>
                </div>
                
                <Button variant="outline" className="w-full">
                  <Plus className="mr-2 h-4 w-4" />
                  Adicionar Novo Relatório Programado
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Templates de Relatórios</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="bg-indigo-50 p-2 rounded-lg">
                    <ClipboardList className="h-6 w-6 text-indigo-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Template para Conselho Diretor</h4>
                    <p className="text-sm text-gray-500">Resumo executivo para apresentação ao Conselho Diretor.</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        <Eye className="mr-1 h-3 w-3" />
                        Ver
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="mr-1 h-3 w-3" />
                        Usar
                      </Button>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex items-start gap-3">
                  <div className="bg-orange-50 p-2 rounded-lg">
                    <GraduationCap className="h-6 w-6 text-orange-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Relatório para Órgão Regulador</h4>
                    <p className="text-sm text-gray-500">Template de relatório para prestação de contas.</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        <Eye className="mr-1 h-3 w-3" />
                        Ver
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="mr-1 h-3 w-3" />
                        Usar
                      </Button>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex items-start gap-3">
                  <div className="bg-teal-50 p-2 rounded-lg">
                    <UserCheck className="h-6 w-6 text-teal-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Avaliação de Impacto Social</h4>
                    <p className="text-sm text-gray-500">Template para relatório de impacto social completo.</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        <Eye className="mr-1 h-3 w-3" />
                        Ver
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="mr-1 h-3 w-3" />
                        Usar
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Relatórios Recentes</CardTitle>
            <CardDescription>
              Histórico dos últimos relatórios gerados.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome do Relatório</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Formato</TableHead>
                  <TableHead>Data de Geração</TableHead>
                  <TableHead>Gerado por</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Relatório Mensal - Novembro 2023</TableCell>
                  <TableCell>Comprehensive</TableCell>
                  <TableCell>PDF</TableCell>
                  <TableCell>01/11/2023</TableCell>
                  <TableCell>Sistema (Automático)</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Lista de Beneficiários Ativos</TableCell>
                  <TableCell>Beneficiary List</TableCell>
                  <TableCell>Excel</TableCell>
                  <TableCell>25/10/2023</TableCell>
                  <TableCell>Maria Santos</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Impacto Social - Q3 2023</TableCell>
                  <TableCell>Impact Metrics</TableCell>
                  <TableCell>PDF</TableCell>
                  <TableCell>10/10/2023</TableCell>
                  <TableCell>João Oliveira</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Análise Financeira - Q3 2023</TableCell>
                  <TableCell>Financial Summary</TableCell>
                  <TableCell>Excel</TableCell>
                  <TableCell>01/10/2023</TableCell>
                  <TableCell>Ana Silva</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderImpactMetrics = () => {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Métricas de Impacto Social</CardTitle>
            <CardDescription>
              Análise detalhada do impacto social gerado pelo programa de assistência
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              <div>
                <h3 className="text-lg font-medium mb-4">Melhoria na Qualidade de Vida</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Melhoria Geral</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="text-3xl font-bold">{programMetrics.qualityOfLifeImprovement}%</div>
                        <Activity className="h-8 w-8 text-purple-500" />
                      </div>
                      <div className="mt-4">
                        <Progress value={programMetrics.qualityOfLifeImprovement} className="h-2 bg-gray-200" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Redução de Sintomas</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="text-3xl font-bold">76%</div>
                        <Activity className="h-8 w-8 text-blue-500" />
                      </div>
                      <div className="mt-4">
                        <Progress value={76} className="h-2 bg-gray-200" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Melhoria no Sono</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="text-3xl font-bold">68%</div>
                        <Activity className="h-8 w-8 text-teal-500" />
                      </div>
                      <div className="mt-4">
                        <Progress value={68} className="h-2 bg-gray-200" />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Impacto Econômico</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Redução de Custos com Medicamentos</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="text-3xl font-bold">{programMetrics.medicationCostReduction}%</div>
                        <DollarSign className="h-8 w-8 text-green-500" />
                      </div>
                      <div className="mt-4">
                        <Progress value={programMetrics.medicationCostReduction} className="h-2 bg-gray-200" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Redução de Hospitalização</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="text-3xl font-bold">{programMetrics.hospitalVisitsReduction}%</div>
                        <Activity className="h-8 w-8 text-red-500" />
                      </div>
                      <div className="mt-4">
                        <Progress value={programMetrics.hospitalVisitsReduction} className="h-2 bg-gray-200" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Economia para o Sistema de Saúde</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="text-3xl font-bold">R$ 245.600</div>
                        <DollarSign className="h-8 w-8 text-blue-500" />
                      </div>
                      <div className="mt-4 text-sm text-gray-500">
                        Economia estimada anual baseada na redução de internações e uso de medicamentos de alto custo
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Impacto Social e Familiar</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Melhoria nas Relações Familiares</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="text-3xl font-bold">72%</div>
                        <Heart className="h-8 w-8 text-red-500" />
                      </div>
                      <div className="mt-4">
                        <Progress value={72} className="h-2 bg-gray-200" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Aumento na Produtividade</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="text-3xl font-bold">54%</div>
                        <Activity className="h-8 w-8 text-indigo-500" />
                      </div>
                      <div className="mt-4">
                        <Progress value={54} className="h-2 bg-gray-200" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">Satisfação com o Programa</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="text-3xl font-bold">{programMetrics.familySatisfaction}%</div>
                        <CheckCircle className="h-8 w-8 text-green-500" />
                      </div>
                      <div className="mt-4">
                        <Progress value={programMetrics.familySatisfaction} className="h-2 bg-gray-200" />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Impacto Financeiro Detalhado</CardTitle>
            <CardDescription>
              Análise econômica do programa e sua sustentabilidade
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Investimento x Retorno Social</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={[
                        { name: 'Investimento', value: 85000 },
                        { name: 'Retorno Social Estimado', value: 245600 }
                      ]}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`R$ ${value.toLocaleString()}`, '']} />
                        <Legend />
                        <Bar dataKey="value" name="Valor (R$)" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Distribuição de Investimentos</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <RechartsPieChart>
                        <Pie
                          data={[
                            { name: 'Subsídios a Medicamentos', value: 65 },
                            { name: 'Consultas Médicas', value: 15 },
                            { name: 'Exames e Avaliações', value: 10 },
                            { name: 'Atendimento Psicológico', value: 5 },
                            { name: 'Operação do Programa', value: 5 }
                          ]}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {COLORS.map((color, index) => (
                            <Cell key={`cell-${index}`} fill={color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </RechartsPieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
              
              <Alert className="bg-blue-50 text-blue-800 border-blue-200">
                <AlertTitle className="text-blue-800 flex items-center">
                  <Info className="h-4 w-4 mr-2" />
                  Retorno Social do Investimento (SROI)
                </AlertTitle>
                <AlertDescription className="text-blue-700">
                  O programa tem um SROI estimado de 2,89 - cada R$ 1,00 investido gera R$ 2,89 em benefícios sociais e econômicos.
                </AlertDescription>
              </Alert>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Indicadores de Desempenho (KPIs)</CardTitle>
            <CardDescription>
              Principais indicadores de performance do programa social
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Indicador</TableHead>
                  <TableHead>Meta Anual</TableHead>
                  <TableHead>Atual</TableHead>
                  <TableHead>% Alcançado</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Total de Beneficiários Atendidos</TableCell>
                  <TableCell>400</TableCell>
                  <TableCell>{programMetrics.totalBeneficiaries}</TableCell>
                  <TableCell>{Math.round((programMetrics.totalBeneficiaries / 400) * 100)}%</TableCell>
                  <TableCell>
                    <Badge className="bg-green-100 text-green-800">No caminho</Badge>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Melhoria na Qualidade de Vida</TableCell>
                  <TableCell>80%</TableCell>
                  <TableCell>{programMetrics.qualityOfLifeImprovement}%</TableCell>
                  <TableCell>{Math.round((programMetrics.qualityOfLifeImprovement / 80) * 100)}%</TableCell>
                  <TableCell>
                    <Badge className="bg-green-100 text-green-800">Acima da meta</Badge>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Redução de Custos com Medicamentos</TableCell>
                  <TableCell>60%</TableCell>
                  <TableCell>{programMetrics.medicationCostReduction}%</TableCell>
                  <TableCell>{Math.round((programMetrics.medicationCostReduction / 60) * 100)}%</TableCell>
                  <TableCell>
                    <Badge className="bg-green-100 text-green-800">Acima da meta</Badge>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Redução de Visitas Hospitalares</TableCell>
                  <TableCell>70%</TableCell>
                  <TableCell>{programMetrics.hospitalVisitsReduction}%</TableCell>
                  <TableCell>{Math.round((programMetrics.hospitalVisitsReduction / 70) * 100)}%</TableCell>
                  <TableCell>
                    <Badge className="bg-yellow-100 text-yellow-800">Abaixo da meta</Badge>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Satisfação das Famílias</TableCell>
                  <TableCell>90%</TableCell>
                  <TableCell>{programMetrics.familySatisfaction}%</TableCell>
                  <TableCell>{Math.round((programMetrics.familySatisfaction / 90) * 100)}%</TableCell>
                  <TableCell>
                    <Badge className="bg-green-100 text-green-800">Acima da meta</Badge>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Assistência Social</h1>
          <p className="text-gray-500 mt-1">
            Gestão do programa de assistência social e beneficiários
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setActiveTab("relatorios")}>
            <FileText className="mr-2 h-4 w-4" />
            Relatórios
          </Button>
          <Button onClick={() => setActiveTab("beneficiarios")} className="bg-green-600 hover:bg-green-700">
            <Plus className="mr-2 h-4 w-4" />
            Novo Beneficiário
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <BarChart4 className="w-4 h-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="beneficiarios" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Beneficiários
          </TabsTrigger>
          <TabsTrigger value="relatorios" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Relatórios
          </TabsTrigger>
          <TabsTrigger value="impacto" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Métricas de Impacto
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="dashboard">
          {renderDashboard()}
        </TabsContent>
        
        <TabsContent value="beneficiarios">
          {renderBeneficiaries()}
        </TabsContent>
        
        <TabsContent value="relatorios">
          {renderReports()}
        </TabsContent>
        
        <TabsContent value="impacto">
          {renderImpactMetrics()}
        </TabsContent>
      </Tabs>
    </div>
  );
}