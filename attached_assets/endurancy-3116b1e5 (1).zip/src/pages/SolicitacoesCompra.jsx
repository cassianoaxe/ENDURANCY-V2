import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Search, 
  Plus, 
  Filter, 
  ChevronDown, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  ShoppingCart, 
  Truck, 
  PackageCheck, 
  Package, 
  MoreHorizontal, 
  Calendar, 
  DollarSign, 
  ClipboardList,
  ArrowUpDown,
  Eye,
  FileEdit,
  Trash2,
  AlertTriangle
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Dados simulados para solicitações de compra
const mockSolicitacoes = [
  {
    id: 'SOL-2023-0145',
    data: '2023-06-28T14:30:00Z',
    solicitante: 'Carlos Silva',
    setor: 'Laboratório',
    itens: [
      { nome: 'Reagente para PCR', quantidade: 5, unidade: 'unid' },
      { nome: 'Kit de pipetas', quantidade: 2, unidade: 'kit' }
    ],
    descricao: 'Reagentes para testes de qualidade',
    justificativa: 'Necessário para análises de controle de qualidade do lote 2023-06.',
    status: 'pendente',
    valor: 3450.80,
    urgencia: 'alta'
  },
  {
    id: 'SOL-2023-0144',
    data: '2023-06-27T10:15:00Z',
    solicitante: 'Ana Oliveira',
    setor: 'Produção',
    itens: [
      { nome: 'Embalagens primárias 100ml', quantidade: 1000, unidade: 'unid' },
      { nome: 'Rótulos adesivos', quantidade: 1000, unidade: 'unid' }
    ],
    descricao: 'Materiais de embalagem - lote mensal',
    justificativa: 'Reposição mensal para linha de produção.',
    status: 'em_cotacao',
    valor: 7820.25,
    urgencia: 'media'
  },
  {
    id: 'SOL-2023-0143',
    data: '2023-06-26T16:45:00Z',
    solicitante: 'Ricardo Mendes',
    setor: 'TI',
    itens: [
      { nome: 'Licença Adobe Creative Cloud', quantidade: 5, unidade: 'unid' },
      { nome: 'Notebook Dell Latitude', quantidade: 2, unidade: 'unid' }
    ],
    descricao: 'Licenças de software e equipamentos',
    justificativa: 'Necessário para equipe de design e novos funcionários.',
    status: 'aprovada',
    valor: 12450.00,
    urgencia: 'baixa'
  },
  {
    id: 'SOL-2023-0142',
    data: '2023-06-25T09:20:00Z',
    solicitante: 'Juliana Costa',
    setor: 'Administrativo',
    itens: [
      { nome: 'Papel A4', quantidade: 20, unidade: 'resma' },
      { nome: 'Canetas esferográficas', quantidade: 100, unidade: 'unid' },
      { nome: 'Grampeadores', quantidade: 10, unidade: 'unid' }
    ],
    descricao: 'Material de escritório trimestral',
    justificativa: 'Reposição trimestral de material de escritório.',
    status: 'aguardando_entrega',
    valor: 1890.75,
    urgencia: 'baixa'
  },
  {
    id: 'SOL-2023-0141',
    data: '2023-06-24T15:10:00Z',
    solicitante: 'Pedro Santos',
    setor: 'Laboratório',
    itens: [
      { nome: 'Vidrarias diversas', quantidade: 1, unidade: 'kit' },
      { nome: 'Balança de precisão', quantidade: 1, unidade: 'unid' }
    ],
    descricao: 'Vidrarias e equipamentos de precisão',
    justificativa: 'Ampliação da capacidade do laboratório de controle.',
    status: 'recebida',
    valor: 9320.50,
    urgencia: 'media'
  },
  {
    id: 'SOL-2023-0140',
    data: '2023-06-23T11:30:00Z',
    solicitante: 'Mariana Alves',
    setor: 'Marketing',
    itens: [
      { nome: 'Banner institucional', quantidade: 5, unidade: 'unid' },
      { nome: 'Folhetos promocionais', quantidade: 1000, unidade: 'unid' }
    ],
    descricao: 'Material para feira setorial',
    justificativa: 'Participação na feira do setor em agosto.',
    status: 'rejeitada',
    valor: 4500.00,
    urgencia: 'media'
  }
];

export default function SolicitacoesCompra() {
  const navigate = useNavigate();
  const [solicitacoes, setSolicitacoes] = useState([]);
  const [filteredSolicitacoes, setFilteredSolicitacoes] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('todas');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("todas");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [solicitacaoToDelete, setSolicitacaoToDelete] = useState(null);

  useEffect(() => {
    // Simulando carregamento de dados
    setTimeout(() => {
      setSolicitacoes(mockSolicitacoes);
      setFilteredSolicitacoes(mockSolicitacoes);
      setLoading(false);
    }, 500);
  }, []);

  useEffect(() => {
    let result = [...solicitacoes];
    
    // Aplicar filtro por tab
    if (activeTab !== "todas") {
      result = result.filter(sol => sol.status === activeTab);
    }
    
    // Aplicar termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(sol => 
        sol.id.toLowerCase().includes(term) || 
        sol.solicitante.toLowerCase().includes(term) || 
        sol.descricao.toLowerCase().includes(term) ||
        sol.setor.toLowerCase().includes(term)
      );
    }
    
    setFilteredSolicitacoes(result);
  }, [solicitacoes, searchTerm, activeTab]);

  const formatDate = (dateString) => {
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(dateString));
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pendente':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'em_cotacao':
        return <Badge className="bg-blue-100 text-blue-800">Em Cotação</Badge>;
      case 'aprovada':
        return <Badge className="bg-purple-100 text-purple-800">Aprovada</Badge>;
      case 'aguardando_entrega':
        return <Badge className="bg-orange-100 text-orange-800">Aguardando Entrega</Badge>;
      case 'recebida':
        return <Badge className="bg-green-100 text-green-800">Recebida</Badge>;
      case 'rejeitada':
        return <Badge className="bg-red-100 text-red-800">Rejeitada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getUrgenciaBadge = (urgencia) => {
    switch (urgencia) {
      case 'baixa':
        return <Badge className="bg-green-100 text-green-800">Baixa</Badge>;
      case 'media':
        return <Badge className="bg-blue-100 text-blue-800">Média</Badge>;
      case 'alta':
        return <Badge className="bg-red-100 text-red-800">Alta</Badge>;
      case 'critica':
        return <Badge className="bg-red-600 text-white">Crítica</Badge>;
      default:
        return <Badge>{urgencia}</Badge>;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pendente':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case 'em_cotacao':
        return <ShoppingCart className="w-5 h-5 text-blue-500" />;
      case 'aprovada':
        return <CheckCircle2 className="w-5 h-5 text-purple-500" />;
      case 'aguardando_entrega':
        return <Truck className="w-5 h-5 text-orange-500" />;
      case 'recebida':
        return <Package className="w-5 h-5 text-green-500" />;
      case 'rejeitada':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <ClipboardList className="w-5 h-5 text-gray-500" />;
    }
  };

  const handleDelete = (id) => {
    // Implementar lógica para deletar solicitação
    setSolicitacoes(solicitacoes.filter(sol => sol.id !== id));
    setDeleteDialogOpen(false);
    setSolicitacaoToDelete(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Solicitações de Compra</h1>
          <p className="text-gray-500 mt-1">
            Gerencie todas as solicitações de compra da organização
          </p>
        </div>
        
        <div>
          <Button className="gap-2" onClick={() => navigate(createPageUrl("NovaSolicitacaoCompra"))}>
            <Plus className="w-4 h-4" />
            Nova Solicitação
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row md:items-center gap-4 justify-between">
        <div className="flex flex-1 max-w-md gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Buscar solicitações..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Filtros
                <ChevronDown className="h-4 w-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>Filtrar por</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Select onValueChange={(value) => setStatusFilter(value)}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Todos os status</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="em_cotacao">Em Cotação</SelectItem>
                    <SelectItem value="aprovada">Aprovada</SelectItem>
                    <SelectItem value="aguardando_entrega">Aguardando Entrega</SelectItem>
                    <SelectItem value="recebida">Recebida</SelectItem>
                    <SelectItem value="rejeitada">Rejeitada</SelectItem>
                  </SelectContent>
                </Select>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Select>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Setor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os setores</SelectItem>
                    <SelectItem value="laboratorio">Laboratório</SelectItem>
                    <SelectItem value="producao">Produção</SelectItem>
                    <SelectItem value="administrativo">Administrativo</SelectItem>
                    <SelectItem value="ti">TI</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                  </SelectContent>
                </Select>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Select>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Urgência" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Todas as urgências</SelectItem>
                    <SelectItem value="baixa">Baixa</SelectItem>
                    <SelectItem value="media">Média</SelectItem>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="critica">Crítica</SelectItem>
                  </SelectContent>
                </Select>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="justify-center">
                <Button variant="outline" size="sm" className="w-full">Aplicar Filtros</Button>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <div className="flex gap-2">
          <Select defaultValue="recentes">
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Ordenar por" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recentes">Mais recentes</SelectItem>
              <SelectItem value="antigos">Mais antigos</SelectItem>
              <SelectItem value="valor_alto">Maior valor</SelectItem>
              <SelectItem value="valor_baixo">Menor valor</SelectItem>
              <SelectItem value="urgencia">Urgência</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="todas">Todas</TabsTrigger>
          <TabsTrigger value="pendente">Pendentes</TabsTrigger>
          <TabsTrigger value="em_cotacao">Em Cotação</TabsTrigger>
          <TabsTrigger value="aprovada">Aprovadas</TabsTrigger>
          <TabsTrigger value="aguardando_entrega">Aguardando Entrega</TabsTrigger>
          <TabsTrigger value="recebida">Recebidas</TabsTrigger>
        </TabsList>

        <Card>
          {loading ? (
            <CardContent className="p-6">
              <div className="flex justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500"></div>
              </div>
            </CardContent>
          ) : filteredSolicitacoes.length === 0 ? (
            <CardContent className="p-10 flex flex-col items-center justify-center">
              <ClipboardList className="h-16 w-16 text-gray-300 mb-4" />
              <h3 className="text-xl font-medium text-gray-900">Nenhuma solicitação encontrada</h3>
              <p className="text-gray-500 mt-1 text-center">
                Não foram encontradas solicitações com os filtros aplicados.
              </p>
              <Button className="mt-4" onClick={() => navigate(createPageUrl("NovaSolicitacaoCompra"))}>
                <Plus className="mr-2 h-4 w-4" />
                Nova Solicitação
              </Button>
            </CardContent>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">Status</TableHead>
                  <TableHead>Solicitação</TableHead>
                  <TableHead>Solicitante</TableHead>
                  <TableHead>Setor</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Urgência</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSolicitacoes.map((solicitacao) => (
                  <TableRow key={solicitacao.id} className="cursor-pointer hover:bg-gray-50" onClick={() => navigate(`${createPageUrl("SolicitacaoDetalhe")}?id=${solicitacao.id}`)}>
                    <TableCell>
                      <div className="flex justify-center">
                        {getStatusIcon(solicitacao.status)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{solicitacao.descricao}</div>
                        <div className="text-sm text-gray-500">#{solicitacao.id}</div>
                      </div>
                    </TableCell>
                    <TableCell>{solicitacao.solicitante}</TableCell>
                    <TableCell>{solicitacao.setor}</TableCell>
                    <TableCell>{formatDate(solicitacao.data)}</TableCell>
                    <TableCell>{getUrgenciaBadge(solicitacao.urgencia)}</TableCell>
                    <TableCell>{formatCurrency(solicitacao.valor)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Abrir menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Ações</DropdownMenuLabel>
                          <DropdownMenuItem onClick={(e) => {
                            e.stopPropagation();
                            navigate(`${createPageUrl("SolicitacaoDetalhe")}?id=${solicitacao.id}`);
                          }}>
                            <Eye className="mr-2 h-4 w-4" />
                            Ver detalhes
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={(e) => {
                            e.stopPropagation();
                            navigate(`${createPageUrl("EditarSolicitacao")}?id=${solicitacao.id}`);
                          }}>
                            <FileEdit className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-red-600"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSolicitacaoToDelete(solicitacao);
                              setDeleteDialogOpen(true);
                            }}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Card>
      </Tabs>

      {/* Dialog de confirmação de exclusão */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir a solicitação {solicitacaoToDelete?.id}? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="flex items-center p-3 bg-red-50 rounded-lg mb-4">
              <AlertTriangle className="h-6 w-6 text-red-500 mr-3" />
              <div>
                <h4 className="font-medium text-red-800">Atenção</h4>
                <p className="text-red-700 text-sm">Esta ação excluirá permanentemente todos os dados relacionados a esta solicitação.</p>
              </div>
            </div>
            {solicitacaoToDelete && (
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="font-medium">{solicitacaoToDelete.descricao}</div>
                <div className="text-sm text-gray-500">
                  <p>Solicitante: {solicitacaoToDelete.solicitante}</p>
                  <p>Valor: {formatCurrency(solicitacaoToDelete.valor)}</p>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={() => handleDelete(solicitacaoToDelete?.id)}>
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}