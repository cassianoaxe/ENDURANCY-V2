
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Award, 
  Upload, 
  Download, 
  Search, 
  Plus, 
  Calendar, 
  Clock, 
  Eye, 
  FileText, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Shield, 
  ExternalLink,
  MoreHorizontal,
  ChevronDown,
  FileUp,
  FileCheck,
  Bookmark,
  Star,
  Medal,
  BadgeCheck,
  ScrollText,
  Verified,
  Ribbon,
  File,
  TrendingUp
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";

// Dados simulados de certificações
const mockCertifications = [
  {
    id: "cert-001",
    title: "Selo de Boas Práticas em Cultivo de Cannabis",
    issuer: "Associação Brasileira de Cannabis Medicinal",
    issuer_logo: "https://images.unsplash.com/photo-1627845060954-09770a225b96?q=80&w=100&h=100&auto=format&fit=crop",
    type: "boas_praticas",
    status: "active",
    issue_date: "2023-04-15",
    expiry_date: "2025-04-15",
    scope: "Cultivo e Processamento",
    certificate_number: "ABCM-2023-00156",
    file_url: "#",
    verification_url: "https://example.org/verificar/abcm-2023-00156",
    description: "Certificação que atesta o cumprimento das diretrizes de Boas Práticas de Cultivo e Processamento de Cannabis para uso medicinal, garantindo rastreabilidade, qualidade e segurança do produto.",
    accomplishments: [
      "Cultivo em ambiente controlado",
      "Ausência de pesticidas",
      "Controle de qualidade rigoroso",
      "Rastreabilidade completa do seed-to-sale"
    ],
    category: "cultivation"
  },
  {
    id: "cert-002",
    title: "Transparência Financeira Gold",
    issuer: "Instituto Brasileiro de Transparência Associativa",
    issuer_logo: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=100&h=100&auto=format&fit=crop",
    type: "financial",
    status: "active",
    issue_date: "2023-06-10",
    expiry_date: "2024-06-10",
    scope: "Gestão Financeira",
    certificate_number: "IBTA-FIN-2023-G-078",
    file_url: "#",
    verification_url: "https://example.org/verificar/ibta-fin-2023-g-078",
    description: "Reconhece organizações que seguem padrões excepcionais de transparência na gestão financeira, prestação de contas e disponibilização de informações aos associados e públicos de interesse.",
    accomplishments: [
      "Publicação trimestral de balancetes financeiros",
      "Auditoria externa independente",
      "Política de conflito de interesses",
      "Documentação acessível a todos os associados"
    ],
    category: "financial"
  },
  {
    id: "cert-003",
    title: "Certificado de Conformidade com RDC 327/2019",
    issuer: "Consultoria Cannabis Legal",
    issuer_logo: "https://images.unsplash.com/photo-1521791055366-0d553872125f?q=80&w=100&h=100&auto=format&fit=crop",
    type: "legal",
    status: "active",
    issue_date: "2023-01-25",
    expiry_date: "2024-01-25",
    scope: "Regulatório",
    certificate_number: "CCL-RDC327-2023-042",
    file_url: "#",
    verification_url: "https://example.org/verificar/ccl-rdc327-2023-042",
    description: "Atesta que a organização atende a todos os requisitos da Resolução da Diretoria Colegiada (RDC) 327/2019 da ANVISA, que estabelece os procedimentos para a concessão da Autorização Sanitária para fabricação e importação de produtos de Cannabis para fins medicinais.",
    accomplishments: [
      "Documentação completa conforme RDC 327/2019",
      "Plano de gerenciamento de riscos",
      "Sistema de farmacovigilância",
      "Controle de qualidade conforme especificações"
    ],
    category: "regulatory"
  },
  {
    id: "cert-004",
    title: "Selo Associação Responsável",
    issuer: "Conselho Nacional de Associações Cannábicas",
    issuer_logo: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?q=80&w=100&h=100&auto=format&fit=crop",
    type: "governance",
    status: "active",
    issue_date: "2023-02-05",
    expiry_date: "2025-02-05",
    scope: "Governança Associativa",
    certificate_number: "CNAC-SR-2023-021",
    file_url: "#",
    verification_url: "https://example.org/verificar/cnac-sr-2023-021",
    description: "Reconhece associações que seguem as melhores práticas de governança, transparência administrativa e cumprimento das finalidades estatutárias, garantindo participação efetiva dos associados.",
    accomplishments: [
      "Eleições regulares e democráticas",
      "Assembleias com participação ativa dos associados",
      "Estatuto social transparente",
      "Prestação de contas periódica"
    ],
    category: "governance"
  },
  {
    id: "cert-005",
    title: "Certificação de Produtos Orgânicos",
    issuer: "IBD Certificações",
    issuer_logo: "https://images.unsplash.com/photo-1508935620299-047e0e35fbe3?q=80&w=100&h=100&auto=format&fit=crop",
    type: "product",
    status: "pending_renewal",
    issue_date: "2022-05-20",
    expiry_date: "2023-05-20",
    scope: "Produção Agrícola",
    certificate_number: "IBD-ORG-2022-134",
    file_url: "#",
    verification_url: "https://example.org/verificar/ibd-org-2022-134",
    description: "Certifica que os produtos são cultivados seguindo padrões de agricultura orgânica, sem o uso de pesticidas sintéticos, fertilizantes químicos ou organismos geneticamente modificados.",
    accomplishments: [
      "Ausência de fertilizantes químicos",
      "Ausência de pesticidas sintéticos",
      "Preservação da biodiversidade",
      "Manejo sustentável do solo"
    ],
    category: "cultivation"
  },
  {
    id: "cert-006",
    title: "Certificação GMP (Good Manufacturing Practices)",
    issuer: "Pharmaceutical Certification International",
    issuer_logo: "https://images.unsplash.com/photo-1532938678126-41bcafb0e5b0?q=80&w=100&h=100&auto=format&fit=crop",
    type: "boas_praticas",
    status: "in_process",
    issue_date: null,
    expiry_date: null,
    scope: "Produção",
    certificate_number: "Pendente",
    file_url: null,
    verification_url: null,
    description: "Certificação internacional que atesta o cumprimento das Boas Práticas de Fabricação, garantindo que os produtos sejam consistentemente produzidos e controlados de acordo com padrões de qualidade farmacêutica.",
    accomplishments: [
      "Processo de auditoria iniciado",
      "Adaptação de instalações em andamento",
      "Treinamento de equipe realizado",
      "Documentação de processos em desenvolvimento"
    ],
    category: "production"
  }
];

export default function TransparencyCertifications() {
  const navigate = useNavigate();
  const [certifications, setCertifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedCertification, setSelectedCertification] = useState(null);
  const [showCertDialog, setShowCertDialog] = useState(false);
  
  useEffect(() => {
    loadCertifications();
  }, []);
  
  const loadCertifications = async () => {
    setIsLoading(true);
    try {
      // Simulação de carregamento de dados
      await new Promise(resolve => setTimeout(resolve, 800));
      setCertifications(mockCertifications);
    } catch (error) {
      console.error("Erro ao carregar certificações:", error);
      toast({
        variant: "destructive",
        title: "Erro ao carregar dados",
        description: "Não foi possível obter as certificações. Tente novamente mais tarde.",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };
  
  const handleViewCertification = (certification) => {
    setSelectedCertification(certification);
    setShowCertDialog(true);
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };
  
  const getStatusBadge = (status) => {
    switch (status) {
      case "active":
        return (
          <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" />
            Ativo
          </Badge>
        );
      case "expired":
        return (
          <Badge className="bg-red-100 text-red-800 flex items-center gap-1">
            <XCircle className="w-3 h-3" />
            Expirado
          </Badge>
        );
      case "pending_renewal":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            Renovação Pendente
          </Badge>
        );
      case "in_process":
        return (
          <Badge className="bg-blue-100 text-blue-800 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Em Processo
          </Badge>
        );
      default:
        return (
          <Badge className="bg-gray-100 text-gray-800">
            {status}
          </Badge>
        );
    }
  };
  
  const getCategoryBadge = (category) => {
    switch (category) {
      case "cultivation":
        return (
          <Badge variant="outline" className="text-green-700">Cultivo</Badge>
        );
      case "financial":
        return (
          <Badge variant="outline" className="text-blue-700">Financeiro</Badge>
        );
      case "governance":
        return (
          <Badge variant="outline" className="text-purple-700">Governança</Badge>
        );
      case "regulatory":
        return (
          <Badge variant="outline" className="text-amber-700">Regulatório</Badge>
        );
      case "production":
        return (
          <Badge variant="outline" className="text-indigo-700">Produção</Badge>
        );
      default:
        return (
          <Badge variant="outline">{category}</Badge>
        );
    }
  };
  
  const getCertIcon = (type) => {
    switch (type) {
      case "boas_praticas":
        return <Shield className="w-10 h-10 text-green-600" />;
      case "financial":
        return <ScrollText className="w-10 h-10 text-blue-600" />;
      case "legal":
        return <FileCheck className="w-10 h-10 text-amber-600" />;
      case "governance":
        return <Bookmark className="w-10 h-10 text-purple-600" />;
      case "product":
        return <BadgeCheck className="w-10 h-10 text-emerald-600" />;
      default:
        return <Award className="w-10 h-10 text-gray-600" />;
    }
  };
  
  const filteredCertifications = certifications.filter(cert => {
    const matchesSearch = cert.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         cert.issuer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cert.certificate_number.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === "all" || cert.category === categoryFilter;
    
    const matchesStatus = statusFilter === "all" || cert.status === statusFilter;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });
  
  const [showNewCertDialog, setShowNewCertDialog] = useState(false);
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Certificações</h1>
          <p className="text-gray-500 mt-1">
            Gerencie e apresente as certificações e reconhecimentos da organização
          </p>
        </div>
        
        <Button className="gap-2" onClick={() => setShowNewCertDialog(true)}>
          <Plus className="w-4 h-4" />
          Nova Certificação
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Total de Certificações</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">{certifications.length}</div>
              <Award className="h-4 w-4 text-gray-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Certificações Ativas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">
                {certifications.filter(c => c.status === "active").length}
              </div>
              <CheckCircle className="h-4 w-4 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">A Renovar (30 dias)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">
                {certifications.filter(c => c.status === "pending_renewal").length}
              </div>
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Em Processo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">
                {certifications.filter(c => c.status === "in_process").length}
              </div>
              <Clock className="h-4 w-4 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="flex flex-col md:flex-row md:items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar certificações..."
            className="pl-10"
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>
        
        <div className="flex gap-4">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              <SelectItem value="cultivation">Cultivo</SelectItem>
              <SelectItem value="financial">Financeiro</SelectItem>
              <SelectItem value="governance">Governança</SelectItem>
              <SelectItem value="regulatory">Regulatório</SelectItem>
              <SelectItem value="production">Produção</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="active">Ativos</SelectItem>
              <SelectItem value="pending_renewal">Renovação Pendente</SelectItem>
              <SelectItem value="expired">Expirados</SelectItem>
              <SelectItem value="in_process">Em Processo</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center py-32">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
        </div>
      ) : filteredCertifications.length === 0 ? (
        <div className="text-center py-16">
          <div className="flex justify-center">
            <Award className="h-16 w-16 text-gray-300" />
          </div>
          <h3 className="mt-4 text-xl font-medium text-gray-900">Nenhuma certificação encontrada</h3>
          <p className="mt-2 text-gray-500">
            {searchTerm 
              ? `Não encontramos certificações correspondentes a "${searchTerm}"`
              : "Nenhuma certificação disponível com os filtros selecionados."
            }
          </p>
          <Button className="mt-6 gap-2" onClick={() => setShowNewCertDialog(true)}>
            <Plus className="w-4 h-4" />
            Adicionar Certificação
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredCertifications.map((cert) => (
            <Card key={cert.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="flex p-6">
                  <div className="bg-gray-50 p-4 rounded-lg border flex items-center justify-center mr-4">
                    {getCertIcon(cert.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-lg font-semibold line-clamp-1">{cert.title}</h3>
                        <div className="flex items-center gap-2 mb-1">
                          <Avatar className="w-5 h-5">
                            <AvatarImage src={cert.issuer_logo} alt={cert.issuer} />
                            <AvatarFallback>{cert.issuer.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <p className="text-sm text-gray-600">{cert.issuer}</p>
                        </div>
                      </div>
                      
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleViewCertification(cert)}>
                            <Eye className="mr-2 h-4 w-4" />
                            Ver detalhes
                          </DropdownMenuItem>
                          {cert.file_url && (
                            <DropdownMenuItem>
                              <Download className="mr-2 h-4 w-4" />
                              Baixar certificado
                            </DropdownMenuItem>
                          )}
                          {cert.verification_url && (
                            <DropdownMenuItem>
                              <ExternalLink className="mr-2 h-4 w-4" />
                              Verificar autenticidade
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <FileText className="mr-2 h-4 w-4" />
                            Editar certificação
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-3">
                      {getStatusBadge(cert.status)}
                      {getCategoryBadge(cert.category)}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p className="text-gray-500">Emissão</p>
                        <p className="font-medium">{formatDate(cert.issue_date)}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Validade</p>
                        <p className="font-medium">{formatDate(cert.expiry_date)}</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="border-t p-3 bg-gray-50">
                  <Button 
                    variant="ghost" 
                    className="w-full justify-center" 
                    onClick={() => handleViewCertification(cert)}
                  >
                    Ver certificação
                    <Eye className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {selectedCertification && (
        <Dialog open={showCertDialog} onOpenChange={setShowCertDialog}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle className="text-xl flex items-center gap-3">
                {selectedCertification.title}
              </DialogTitle>
              <div className="flex gap-2 mt-2">
                {getStatusBadge(selectedCertification.status)}
                {getCategoryBadge(selectedCertification.category)}
              </div>
            </DialogHeader>
            
            <div className="space-y-6">
              <div className="flex items-center">
                <div className="mr-4">
                  <Avatar className="w-16 h-16">
                    <AvatarImage src={selectedCertification.issuer_logo} alt={selectedCertification.issuer} />
                    <AvatarFallback>{selectedCertification.issuer.charAt(0)}</AvatarFallback>
                  </Avatar>
                </div>
                <div>
                  <h3 className="font-medium">Emitido por</h3>
                  <p className="text-lg">{selectedCertification.issuer}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <Label className="text-gray-500">Número do Certificado</Label>
                  <p className="font-medium">{selectedCertification.certificate_number}</p>
                </div>
                <div>
                  <Label className="text-gray-500">Data de Emissão</Label>
                  <p className="font-medium">{formatDate(selectedCertification.issue_date)}</p>
                </div>
                <div>
                  <Label className="text-gray-500">Data de Validade</Label>
                  <p className="font-medium">{formatDate(selectedCertification.expiry_date)}</p>
                </div>
                <div>
                  <Label className="text-gray-500">Escopo</Label>
                  <p className="font-medium">{selectedCertification.scope}</p>
                </div>
                <div>
                  <Label className="text-gray-500">Tipo</Label>
                  <p className="font-medium">
                    {selectedCertification.type === "boas_praticas" ? "Boas Práticas" :
                     selectedCertification.type === "financial" ? "Financeiro" :
                     selectedCertification.type === "legal" ? "Legal/Regulatório" :
                     selectedCertification.type === "governance" ? "Governança" :
                     selectedCertification.type === "product" ? "Produto" :
                     selectedCertification.type}
                  </p>
                </div>
                <div>
                  <Label className="text-gray-500">Categoria</Label>
                  <p className="font-medium">
                    {selectedCertification.category === "cultivation" ? "Cultivo" :
                     selectedCertification.category === "financial" ? "Financeiro" :
                     selectedCertification.category === "governance" ? "Governança" :
                     selectedCertification.category === "regulatory" ? "Regulatório" :
                     selectedCertification.category === "production" ? "Produção" :
                     selectedCertification.category}
                  </p>
                </div>
              </div>
              
              <div>
                <Label className="text-gray-500">Descrição</Label>
                <p className="mt-1">{selectedCertification.description}</p>
              </div>
              
              <div>
                <Label className="text-gray-500">Conquistas e Requisitos Atendidos</Label>
                <ul className="mt-2 space-y-1">
                  {selectedCertification.accomplishments.map((item, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="flex flex-wrap gap-4">
                {selectedCertification.file_url && (
                  <Button variant="outline" className="gap-2">
                    <Download className="w-4 h-4" />
                    Baixar Certificado
                  </Button>
                )}
                
                {selectedCertification.verification_url && (
                  <Button variant="outline" className="gap-2">
                    <ExternalLink className="w-4 h-4" />
                    Verificar Autenticidade
                  </Button>
                )}
                
                {selectedCertification.status === "pending_renewal" && (
                  <Button className="gap-2">
                    <Upload className="w-4 h-4" />
                    Renovar Certificação
                  </Button>
                )}
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCertDialog(false)}>
                Fechar
              </Button>
              <Button variant="outline" className="gap-2">
                <FileText className="w-4 h-4" />
                Editar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      <Dialog open={showNewCertDialog} onOpenChange={setShowNewCertDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Nova Certificação</DialogTitle>
            <DialogDescription>
              Adicione uma nova certificação ou reconhecimento à sua organização.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="title">Título da Certificação</Label>
                <Input id="title" placeholder="Ex: Selo de Boas Práticas em Cultivo de Cannabis" />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="issuer">Entidade Emissora</Label>
                  <Input id="issuer" placeholder="Ex: Associação Brasileira de Cannabis Medicinal" />
                </div>
                
                <div>
                  <Label htmlFor="certificate_number">Número do Certificado</Label>
                  <Input id="certificate_number" placeholder="Ex: ABCM-2023-00156" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="type">Tipo</Label>
                  <Select>
                    <SelectTrigger id="type">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="boas_praticas">Boas Práticas</SelectItem>
                      <SelectItem value="financial">Financeiro</SelectItem>
                      <SelectItem value="legal">Legal/Regulatório</SelectItem>
                      <SelectItem value="governance">Governança</SelectItem>
                      <SelectItem value="product">Produto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="issue_date">Data de Emissão</Label>
                  <Input type="date" id="issue_date" />
                </div>
                
                <div>
                  <Label htmlFor="expiry_date">Data de Validade</Label>
                  <Input type="date" id="expiry_date" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="scope">Escopo</Label>
                  <Input id="scope" placeholder="Ex: Cultivo e Processamento" />
                </div>
                
                <div>
                  <Label htmlFor="category">Categoria</Label>
                  <Select>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Selecione a categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cultivation">Cultivo</SelectItem>
                      <SelectItem value="financial">Financeiro</SelectItem>
                      <SelectItem value="governance">Governança</SelectItem>
                      <SelectItem value="regulatory">Regulatório</SelectItem>
                      <SelectItem value="production">Produção</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="description">Descrição</Label>
                <Textarea 
                  id="description" 
                  placeholder="Descreva o que esta certificação representa e quais padrões ela atesta."
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="verification_url">URL de Verificação (opcional)</Label>
                <Input id="verification_url" placeholder="https://example.org/verificar/sua-certificacao" />
              </div>
              
              <div>
                <Label>Arquivo do Certificado (opcional)</Label>
                <div className="mt-2 flex justify-center rounded-lg border border-dashed border-gray-300 px-6 py-10">
                  <div className="text-center">
                    <FileUp className="mx-auto h-12 w-12 text-gray-300" />
                    <div className="mt-4 flex text-sm leading-6 text-gray-600">
                      <label
                        htmlFor="file-upload"
                        className="relative cursor-pointer rounded-md bg-white font-semibold text-indigo-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-indigo-600 focus-within:ring-offset-2 hover:text-indigo-500"
                      >
                        <span>Upload do arquivo</span>
                        <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                      </label>
                      <p className="pl-1">ou arraste e solte</p>
                    </div>
                    <p className="text-xs leading-5 text-gray-600">PDF até 10MB</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewCertDialog(false)}>
              Cancelar
            </Button>
            <Button>
              Adicionar Certificação
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
