
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Scale, 
  FileText, 
  Filter, 
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  BarChart3,
  FileCheck,
  ArrowUpDown,
  MoreHorizontal
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function JuridicoDashboard() {
  const [period, setPeriod] = useState("mensal");
  
  const stats = {
    total_acoes: 124,
    procedentes: 67,
    procedentes_parcial: 18,
    improcedentes: 12,
    em_andamento: 27,
    liminares_concedidas: 42,
    liminares_negadas: 15,
    liminares_pendentes: 8,
    proximas_audiencias: 5,
    prazos_proximos: 7
  };
  
  const statusData = [
    { name: 'Em andamento', value: stats.em_andamento },
    { name: 'Procedentes', value: stats.procedentes },
    { name: 'Procedentes Parcial', value: stats.procedentes_parcial },
    { name: 'Improcedentes', value: stats.improcedentes },
  ];
  
  const liminaresData = [
    { name: 'Concedidas', value: stats.liminares_concedidas },
    { name: 'Negadas', value: stats.liminares_negadas },
    { name: 'Pendentes', value: stats.liminares_pendentes },
  ];
  
  const monthlyData = [
    { mes: 'Jan', acoes: 5, liminares: 3, ganhas: 2 },
    { mes: 'Fev', acoes: 8, liminares: 5, ganhas: 3 },
    { mes: 'Mar', acoes: 12, liminares: 8, ganhas: 5 },
    { mes: 'Abr', acoes: 15, liminares: 10, ganhas: 7 },
    { mes: 'Mai', acoes: 10, liminares: 7, ganhas: 4 },
    { mes: 'Jun', acoes: 20, liminares: 14, ganhas: 12 },
  ];
  
  const acoesPorTipo = [
    { name: 'Fornecimento medicamentos', value: 78 },
    { name: 'Autorização ANVISA', value: 32 },
    { name: 'Cobertura de plano', value: 14 },
  ];
  
  const proximasAudiencias = [
    { id: 1, processo: '0123456-78.2023.8.26.0100', data: '2023-08-15', tipo: 'Conciliação', cliente: 'Ana Maria Silva' },
    { id: 2, processo: '0987654-32.2023.8.26.0100', data: '2023-08-18', tipo: 'Instrução', cliente: 'Carlos Eduardo Santos' },
    { id: 3, processo: '0567890-12.2023.8.26.0100', data: '2023-08-20', tipo: 'Julgamento', cliente: 'Maria José Oliveira' },
    { id: 4, processo: '0135792-46.2023.8.26.0100', data: '2023-08-25', tipo: 'Conciliação', cliente: 'José Carlos Pereira' },
  ];
  
  const proximosPrazos = [
    { id: 1, processo: '0123456-78.2023.8.26.0100', prazo: '2023-08-10', descricao: 'Manifestação sobre laudo pericial', dias: 3 },
    { id: 2, processo: '0987654-32.2023.8.26.0100', prazo: '2023-08-12', descricao: 'Recurso de apelação', dias: 5 },
    { id: 3, processo: '0567890-12.2023.8.26.0100', prazo: '2023-08-14', descricao: 'Contrarrazões', dias: 7 },
    { id: 4, processo: '0135792-46.2023.8.26.0100', prazo: '2023-08-16', descricao: 'Embargos de declaração', dias: 9 },
  ];
  
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];
  const LIMINAR_COLORS = ['#00C49F', '#FF8042', '#FFBB28'];
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Scale className="w-6 h-6 text-emerald-600" />
            Dashboard Jurídico
          </h1>
          <p className="text-gray-500 mt-1">
            Acompanhe todos os indicadores das ações judiciais
          </p>
        </div>
        
        <div className="flex gap-2">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mensal">Mensal</SelectItem>
              <SelectItem value="trimestral">Trimestral</SelectItem>
              <SelectItem value="anual">Anual</SelectItem>
            </SelectContent>
          </Select>
          
          <Button>
            <Filter className="w-4 h-4 mr-2" />
            Filtros
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl font-bold">{stats.total_acoes}</CardTitle>
            <CardDescription>Total de Ações</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-emerald-600">
              <BarChart3 className="w-4 h-4 mr-1" />
              <span>Acompanhamento ativo</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl font-bold">{stats.procedentes + stats.procedentes_parcial}</CardTitle>
            <CardDescription>Ações Procedentes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-emerald-600">
              <CheckCircle2 className="w-4 h-4 mr-1" />
              <span>Taxa de êxito: {Math.round((stats.procedentes + stats.procedentes_parcial) / stats.total_acoes * 100)}%</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl font-bold">{stats.liminares_concedidas}</CardTitle>
            <CardDescription>Liminares Concedidas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-emerald-600">
              <FileCheck className="w-4 h-4 mr-1" />
              <span>Taxa: {Math.round(stats.liminares_concedidas / (stats.liminares_concedidas + stats.liminares_negadas + stats.liminares_pendentes) * 100)}%</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl font-bold">{stats.proximas_audiencias}</CardTitle>
            <CardDescription>Próximas Audiências</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-yellow-600">
              <Calendar className="w-4 h-4 mr-1" />
              <span>Próximos 7 dias</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Ações por Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value} ações`, 'Quantidade']} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Evolução Mensal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="acoes" name="Ações Novas" fill="#8884d8" />
                  <Bar dataKey="liminares" name="Liminares" fill="#82ca9d" />
                  <Bar dataKey="ganhas" name="Ações Ganhas" fill="#ffc658" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Próximas Audiências</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {proximasAudiencias.map((audiencia) => (
                <div key={audiencia.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                  <div className="flex gap-3">
                    <div className="bg-blue-100 p-2 rounded-full">
                      <Calendar className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">{audiencia.tipo}</p>
                      <p className="text-sm text-gray-500">Processo: {audiencia.processo}</p>
                      <p className="text-sm text-gray-500">Cliente: {audiencia.cliente}</p>
                    </div>
                  </div>
                  <Badge variant="outline">
                    {new Date(audiencia.data).toLocaleDateString()}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Prazos Próximos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {proximosPrazos.map((prazo) => (
                <div key={prazo.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                  <div className="flex gap-3">
                    <div className="bg-yellow-100 p-2 rounded-full">
                      <Clock className="h-5 w-5 text-yellow-600" />
                    </div>
                    <div>
                      <p className="font-medium">{prazo.descricao}</p>
                      <p className="text-sm text-gray-500">Processo: {prazo.processo}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline" className="mb-1">
                      {new Date(prazo.prazo).toLocaleDateString()}
                    </Badge>
                    <div className="text-xs">
                      <Badge variant={prazo.dias <= 3 ? "destructive" : "outline"} className="ml-auto">
                        {prazo.dias} dias
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
