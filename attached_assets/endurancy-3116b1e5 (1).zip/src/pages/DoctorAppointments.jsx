import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import DoctorLayout from '../components/DoctorLayout';
import { 
  Calendar, Clock, Filter, Search, Plus, MoreHorizontal, 
  ChevronLeft, ChevronRight, Video, MapPin, Check, X,
  AlertCircle, FileText, PhoneCall, MessageSquare
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Spinner } from "@/components/ui/spinner";

// Mock data for appointments
const mockAppointments = [
  {
    id: 'APT001',
    patientName: 'Maria Oliveira',
    patientAge: 45,
    date: '2024-04-25',
    time: '09:00',
    type: 'Primeira Consulta',
    isVirtual: true,
    status: 'scheduled',
    notes: 'Paciente com dores crônicas, buscando alternativas de tratamento.'
  },
  {
    id: 'APT002',
    patientName: 'João Santos',
    patientAge: 62,
    date: '2024-04-25',
    time: '10:30',
    type: 'Retorno',
    isVirtual: false,
    status: 'scheduled',
    notes: 'Acompanhamento do tratamento iniciado há 3 meses.'
  },
  {
    id: 'APT003',
    patientName: 'Ana Silva',
    patientAge: 35,
    date: '2024-04-25',
    time: '13:00',
    type: 'Retorno',
    isVirtual: true,
    status: 'scheduled',
    notes: 'Avaliação dos efeitos do óleo de CBD.'
  },
  {
    id: 'APT004',
    patientName: 'Carlos Mendes',
    patientAge: 50,
    date: '2024-04-25',
    time: '14:30',
    type: 'Primeira Consulta',
    isVirtual: false,
    status: 'scheduled',
    notes: 'Paciente com Parkinson em estágio inicial.'
  },
  {
    id: 'APT005',
    patientName: 'Fernanda Lima',
    patientAge: 28,
    date: '2024-04-26',
    time: '09:00',
    type: 'Primeira Consulta',
    isVirtual: true,
    status: 'scheduled',
    notes: 'Ansiedade e distúrbios do sono.'
  },
  {
    id: 'APT006',
    patientName: 'Marcelo Santos',
    patientAge: 42,
    date: '2024-04-26',
    time: '11:00',
    type: 'Retorno',
    isVirtual: true,
    status: 'scheduled',
    notes: 'Avaliação da eficácia do tratamento para dor neuropática.'
  }
];

export default function DoctorAppointments() {
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState([]);
  const [filteredAppointments, setFilteredAppointments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('today');
  
  // Format date to YYYY-MM-DD
  const formatDateString = (date) => {
    return date.toISOString().split('T')[0];
  };

  useEffect(() => {
    // Simulate loading appointments
    const timer = setTimeout(() => {
      setAppointments(mockAppointments);
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Filter appointments based on current filters
    const today = formatDateString(new Date());
    let filtered = [...appointments];

    // Filter by tab
    if (activeTab === 'today') {
      filtered = filtered.filter(apt => apt.date === today);
    } else if (activeTab === 'upcoming') {
      filtered = filtered.filter(apt => apt.date > today);
    } else if (activeTab === 'selected') {
      filtered = filtered.filter(apt => apt.date === formatDateString(selectedDate));
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(apt => 
        apt.patientName.toLowerCase().includes(query) || 
        apt.notes.toLowerCase().includes(query)
      );
    }

    // Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(apt => apt.status === statusFilter);
    }

    // Filter by type
    if (typeFilter !== 'all') {
      filtered = filtered.filter(apt => 
        (typeFilter === 'virtual' && apt.isVirtual) || 
        (typeFilter === 'in-person' && !apt.isVirtual)
      );
    }

    setFilteredAppointments(filtered);
  }, [appointments, searchQuery, statusFilter, typeFilter, activeTab, selectedDate]);

  // Format date for display
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  // Navigate to previous/next day
  const changeDate = (days) => {
    const newDate = new Date(selectedDate);
    newDate.setDate(selectedDate.getDate() + days);
    setSelectedDate(newDate);
    setActiveTab('selected');
  };

  // Format time
  const formatTime = (timeString) => {
    return timeString.replace(':', 'h');
  };

  return (
    <DoctorLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Consultas</h1>
            <p className="text-gray-500">Gerencie suas consultas e agendamentos</p>
          </div>
          <Button className="gap-2 bg-pink-600 hover:bg-pink-700">
            <Plus className="w-4 h-4" />
            Nova Consulta
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="col-span-1 md:col-span-2">
            <CardHeader className="pb-3">
              <CardTitle>Minha Agenda</CardTitle>
              <CardDescription>Visualize e gerencie suas consultas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col space-y-4">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid grid-cols-3 mb-4">
                    <TabsTrigger value="today">Hoje</TabsTrigger>
                    <TabsTrigger value="upcoming">Próximas</TabsTrigger>
                    <TabsTrigger value="selected">Calendário</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="today" className="mt-0">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-medium">Consultas de Hoje</h3>
                      <div className="text-sm text-gray-500">
                        {new Date().toLocaleDateString('pt-BR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="upcoming" className="mt-0">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-medium">Próximas Consultas</h3>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="selected" className="mt-0">
                    <div className="flex justify-between items-center mb-4">
                      <Button variant="outline" size="sm" onClick={() => changeDate(-1)}>
                        <ChevronLeft className="w-4 h-4 mr-1" />
                        Anterior
                      </Button>
                      <div className="font-medium">
                        {selectedDate.toLocaleDateString('pt-BR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                      </div>
                      <Button variant="outline" size="sm" onClick={() => changeDate(1)}>
                        Próximo
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>

                <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
                  <div className="relative w-full md:w-64">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Buscar paciente..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <div className="flex gap-3 w-full md:w-auto">
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-full md:w-40">
                        <div className="flex items-center gap-2">
                          <Filter className="w-4 h-4" />
                          <SelectValue placeholder="Status" />
                        </div>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos</SelectItem>
                        <SelectItem value="scheduled">Agendadas</SelectItem>
                        <SelectItem value="completed">Realizadas</SelectItem>
                        <SelectItem value="cancelled">Canceladas</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select value={typeFilter} onValueChange={setTypeFilter}>
                      <SelectTrigger className="w-full md:w-40">
                        <div className="flex items-center gap-2">
                          <Filter className="w-4 h-4" />
                          <SelectValue placeholder="Tipo" />
                        </div>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos</SelectItem>
                        <SelectItem value="virtual">Telemedicina</SelectItem>
                        <SelectItem value="in-person">Presencial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {isLoading ? (
                  <div className="flex justify-center my-8">
                    <Spinner className="h-8 w-8 text-pink-600" />
                  </div>
                ) : filteredAppointments.length === 0 ? (
                  <div className="text-center py-8">
                    <Calendar className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-lg font-medium">Sem consultas</h3>
                    <p className="text-gray-500 mt-1">
                      {searchQuery || statusFilter !== 'all' || typeFilter !== 'all' 
                        ? "Nenhuma consulta encontrada com os filtros atuais" 
                        : "Você não tem consultas agendadas neste período"}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4 mt-2">
                    {filteredAppointments.map((appointment) => (
                      <div 
                        key={appointment.id} 
                        className="p-4 border rounded-lg hover:shadow-md transition-shadow bg-white"
                      >
                        <div className="flex justify-between items-start">
                          <div className="flex items-start gap-3">
                            <Avatar className="h-10 w-10">
                              <AvatarFallback className="bg-pink-100 text-pink-800">
                                {appointment.patientName.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <h4 className="font-medium">{appointment.patientName}</h4>
                              <div className="text-sm text-gray-500">
                                {appointment.patientAge} anos • {appointment.type}
                              </div>
                            </div>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-5 w-5" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>Ver detalhes</DropdownMenuItem>
                              <DropdownMenuItem>Editar consulta</DropdownMenuItem>
                              <DropdownMenuItem>Reagendar</DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600">Cancelar</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mt-3">
                          <div className="flex items-center text-sm text-gray-500">
                            <Calendar className="h-4 w-4 mr-1" />
                            {formatDate(appointment.date)}
                          </div>
                          <div className="flex items-center text-sm text-gray-500">
                            <Clock className="h-4 w-4 mr-1" />
                            {formatTime(appointment.time)}
                          </div>
                          {appointment.isVirtual ? (
                            <Badge className="bg-blue-100 text-blue-800 flex items-center gap-1">
                              <Video className="h-3 w-3" />
                              Telemedicina
                            </Badge>
                          ) : (
                            <Badge className="bg-purple-100 text-purple-800 flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              Presencial
                            </Badge>
                          )}
                          {appointment.status === 'scheduled' && (
                            <Badge className="bg-green-100 text-green-800">Agendada</Badge>
                          )}
                        </div>
                        
                        {appointment.notes && (
                          <div className="mt-3 text-sm text-gray-600 bg-gray-50 p-2 rounded-md">
                            {appointment.notes}
                          </div>
                        )}
                        
                        <div className="mt-4 flex gap-2">
                          {appointment.isVirtual && appointment.status === 'scheduled' && (
                            <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                              <Video className="h-4 w-4 mr-1" />
                              Iniciar Consulta
                            </Button>
                          )}
                          <Button size="sm" variant="outline">
                            <FileText className="h-4 w-4 mr-1" />
                            Prontuário
                          </Button>
                          <Button size="sm" variant="outline">
                            <MessageSquare className="h-4 w-4 mr-1" />
                            Mensagem
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Resumo</CardTitle>
              <CardDescription>Visão geral da agenda</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-pink-50 rounded-lg">
                  <h3 className="font-medium mb-3">Hoje</h3>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-600">Total de consultas</span>
                    <Badge className="bg-pink-100 text-pink-800">
                      {appointments.filter(apt => apt.date === formatDateString(new Date())).length}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-600">Telemedicina</span>
                    <span className="text-gray-800">
                      {appointments.filter(apt => apt.date === formatDateString(new Date()) && apt.isVirtual).length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Presenciais</span>
                    <span className="text-gray-800">
                      {appointments.filter(apt => apt.date === formatDateString(new Date()) && !apt.isVirtual).length}
                    </span>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-3">Esta Semana</h3>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-600">Total de consultas</span>
                    <Badge className="bg-gray-100 text-gray-800">{appointments.length}</Badge>
                  </div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-600">Novas consultas</span>
                    <span className="text-gray-800">
                      {appointments.filter(apt => apt.type === 'Primeira Consulta').length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Retornos</span>
                    <span className="text-gray-800">
                      {appointments.filter(apt => apt.type === 'Retorno').length}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col gap-3 mt-4">
                  <h3 className="font-medium">Ações Rápidas</h3>
                  <Button variant="outline" className="justify-start">
                    <Calendar className="h-4 w-4 mr-2" />
                    Ver Agenda Completa
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Plus className="h-4 w-4 mr-2" />
                    Agendar Nova Consulta
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <PhoneCall className="h-4 w-4 mr-2" />
                    Notificar Pacientes
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DoctorLayout>
  );
}