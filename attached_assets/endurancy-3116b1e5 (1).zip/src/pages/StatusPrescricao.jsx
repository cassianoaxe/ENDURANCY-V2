import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { PrescricaoFarmaceutica } from '@/api/entities';
import { PrescricaoNotificacao } from '@/api/entities';
import { User } from '@/api/entities';
import { toast } from '@/components/ui/use-toast';
import {
  ArrowLeft,
  Clock,
  CheckCircle,
  XCircle,
  MessageSquare,
  AlertCircle,
  FileText,
  Calendar,
  Pill,
  RefreshCw,
  Download,
  Eye,
  Edit,
  Upload
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Spinner } from '@/components/ui/spinner';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Separator } from '@/components/ui/separator';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function StatusPrescricao() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [prescricao, setPrescricao] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [eventos, setEventos] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [sendingComment, setSendingComment] = useState(false);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [file, setFile] = useState(null);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    loadCurrentUser();
    loadPrescricao();
  }, [id]);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error loading user", error);
      toast({
        title: "Erro de autenticação",
        description: "Você precisa estar logado para acessar esta página.",
        variant: "destructive",
      });
      navigate(createPageUrl("Access"));
    }
  };

  const loadPrescricao = async () => {
    setLoading(true);
    try {
      // In a real app, we would fetch from the database
      // const prescricaoData = await PrescricaoFarmaceutica.get(id);
      
      // Using mock data for now
      setTimeout(() => {
        const mockPrescricao = generateMockPrescricao(id);
        setPrescricao(mockPrescricao);
        setEventos(generateTimelineEvents(mockPrescricao));
        setLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Error loading prescription', error);
      setLoading(false);
      toast({
        title: "Erro ao carregar prescrição",
        description: "Não foi possível carregar os detalhes da prescrição",
        variant: "destructive"
      });
    }
  };

  const generateMockPrescricao = (id) => {
    return {
      id: id,
      paciente_id: 'user_123',
      paciente_nome: 'João Silva',
      paciente_avatar: 'JS',
      arquivo_url: 'https://example.com/prescricao.pdf',
      data_envio: new Date(Date.now() - 3 * 86400000).toISOString(), // 3 days ago
      status: 'pendente',
      validade_prescricao: new Date(Date.now() + 90 * 86400000).toISOString(), // 90 days from now
      dados_medico: {
        nome: 'Dr. Ricardo Almeida',
        crm: '12345-SP',
        especialidade: 'Neurologia'
      },
      observacoes_paciente: 'Favor verificar prescrição o mais rápido possível. Obrigado.',
      comentarios: [
        {
          id: 'comm_1',
          usuario_id: 'farm_123',
          usuario_nome: 'Farmacêutico Carlos',
          usuario_tipo: 'farmaceutico',
          usuario_avatar: 'FC',
          conteudo: 'Estou analisando sua prescrição, poderia confirmar se a dosagem é diária ou semanal?',
          data: new Date(Date.now() - 2 * 86400000).toISOString() // 2 days ago
        },
        {
          id: 'comm_2',
          usuario_id: 'user_123',
          usuario_nome: 'João Silva',
          usuario_tipo: 'paciente',
          usuario_avatar: 'JS',
          conteudo: 'A dosagem é diária, conforme orientação do médico.',
          data: new Date(Date.now() - 1.5 * 86400000).toISOString() // 1.5 days ago
        }
      ],
      historico_status: [
        {
          data: new Date(Date.now() - 3 * 86400000).toISOString(), // 3 days ago
          status: 'pendente',
          usuario_id: 'user_123',
          usuario_nome: 'João Silva',
          observacao: 'Prescrição enviada pelo paciente'
        }
      ]
    };
  };

  const generateTimelineEvents = (prescricao) => {
    const events = [];
    
    // Add status history
    if (prescricao.historico_status) {
      prescricao.historico_status.forEach(item => {
        events.push({
          type: 'status',
          data: item.data,
          status: item.status,
          user: {
            id: item.usuario_id,
            name: item.usuario_nome
          },
          message: item.observacao
        });
      });
    }
    
    // Add comments
    if (prescricao.comentarios) {
      prescricao.comentarios.forEach(comment => {
        events.push({
          type: 'comment',
          data: comment.data,
          user: {
            id: comment.usuario_id,
            name: comment.usuario_nome,
            avatar: comment.usuario_avatar,
            type: comment.usuario_tipo
          },
          message: comment.conteudo
        });
      });
    }
    
    // Sort events by date
    return events.sort((a, b) => new Date(b.data) - new Date(a.data));
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;
    
    setSendingComment(true);
    try {
      const commentData = {
        id: `comm_${Date.now()}`,
        usuario_id: currentUser.id,
        usuario_nome: currentUser.full_name || 'Usuário',
        usuario_tipo: currentUser.role === 'admin' ? 'farmaceutico' : 'paciente',
        usuario_avatar: (currentUser.full_name || 'U').charAt(0),
        conteudo: newComment,
        data: new Date().toISOString()
      };
      
      // In a real app, we would update the database
      // await PrescricaoFarmaceutica.addComment(id, commentData);

      // Update local state
      setPrescricao(prev => ({
        ...prev,
        comentarios: [...(prev.comentarios || []), commentData]
      }));

      // Update timeline
      setEventos(prev => [
        {
          type: 'comment',
          data: commentData.data,
          user: {
            id: commentData.usuario_id,
            name: commentData.usuario_nome,
            avatar: commentData.usuario_avatar,
            type: commentData.usuario_tipo
          },
          message: commentData.conteudo
        },
        ...prev
      ]);
      
      setNewComment('');
      toast({
        title: "Comentário adicionado",
        description: "Seu comentário foi adicionado com sucesso.",
      });
    } catch (error) {
      console.error('Error adding comment', error);
      toast({
        title: "Erro ao adicionar comentário",
        description: "Não foi possível adicionar seu comentário. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setSendingComment(false);
    }
  };

  const handleRefresh = () => {
    loadPrescricao();
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'pendente':
        return 'Pendente de análise';
      case 'aprovada':
        return 'Aprovada';
      case 'rejeitada':
        return 'Rejeitada';
      case 'solicitado_alteracao':
        return 'Alteração solicitada';
      default:
        return 'Status desconhecido';
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pendente':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Pendente</Badge>;
      case 'aprovada':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Aprovada</Badge>;
      case 'rejeitada':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Rejeitada</Badge>;
      case 'solicitado_alteracao':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Alteração solicitada</Badge>;
      default:
        return <Badge variant="outline">Desconhecido</Badge>;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pendente':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'aprovada':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'rejeitada':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'solicitado_alteracao':
        return <AlertCircle className="h-5 w-5 text-blue-500" />;
      default:
        return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };

  const formatDateTime = (dateString) => {
    try {
      return format(parseISO(dateString), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR });
    } catch (e) {
      return dateString || "Data não disponível";
    }
  };

  const formatDate = (dateString) => {
    try {
      return format(parseISO(dateString), "dd/MM/yyyy", { locale: ptBR });
    } catch (e) {
      return dateString || "Data não disponível";
    }
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      if (selectedFile.type !== 'application/pdf' && 
          !selectedFile.type.startsWith('image/')) {
        setErrorMessage('Por favor, envie um arquivo PDF ou uma imagem.');
        setFile(null);
        return;
      }

      setFile(selectedFile);
      setErrorMessage('');
    }
  };

  const handleUploadRevision = async () => {
    if (!file) {
      setErrorMessage('Por favor, selecione um arquivo para enviar.');
      return;
    }

    setUploadingFile(true);
    try {
      // In a real app, we would upload the file and update the database
      // const uploadedFile = await UploadFile({ file });
      // await PrescricaoFarmaceutica.update(id, {
      //   arquivo_url: uploadedFile.file_url,
      //   status: 'pendente'
      // });

      // Update local state
      setTimeout(() => {
        setPrescricao(prev => ({
          ...prev,
          status: 'pendente',
          historico_status: [
            ...prev.historico_status,
            {
              data: new Date().toISOString(),
              status: 'pendente',
              usuario_id: currentUser.id,
              usuario_nome: currentUser.full_name || 'Usuário',
              observacao: 'Prescrição atualizada pelo paciente'
            }
          ]
        }));

        // Update timeline
        setEventos(prev => [
          {
            type: 'status',
            data: new Date().toISOString(),
            status: 'pendente',
            user: {
              id: currentUser.id,
              name: currentUser.full_name || 'Usuário'
            },
            message: 'Prescrição atualizada pelo paciente'
          },
          ...prev
        ]);

        setShowUploadDialog(false);
        setFile(null);
        
        toast({
          title: "Prescrição atualizada",
          description: "Sua prescrição foi atualizada e será analisada novamente.",
        });
      }, 1500);
    } catch (error) {
      console.error('Error uploading revision', error);
      toast({
        title: "Erro ao atualizar prescrição",
        description: "Não foi possível atualizar sua prescrição. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setUploadingFile(false);
    }
  };

  const renderStatusTimeline = () => {
    return (
      <div className="space-y-6">
        {eventos.map((event, index) => (
          <div key={index} className="relative">
            {index !== eventos.length - 1 && (
              <div className="absolute top-7 left-4 bottom-0 w-0.5 bg-gray-200"></div>
            )}
            
            <div className="flex gap-4">
              <div className="relative z-10">
                {event.type === 'status' ? (
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    event.status === 'pendente' ? 'bg-yellow-100' : 
                    event.status === 'aprovada' ? 'bg-green-100' : 
                    event.status === 'rejeitada' ? 'bg-red-100' : 
                    event.status === 'solicitado_alteracao' ? 'bg-blue-100' : 'bg-gray-100'
                  }`}>
                    {getStatusIcon(event.status)}
                  </div>
                ) : (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{event.user.avatar || event.user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                )}
              </div>
              
              <div className="flex-1">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start mb-1">
                  <div>
                    <p className="font-medium">
                      {event.type === 'status' ? getStatusLabel(event.status) : event.user.name}
                    </p>
                    <p className="text-sm text-gray-500">
                      {event.type === 'status' ? event.user.name : (event.user.type === 'farmaceutico' ? 'Farmacêutico' : 'Paciente')}
                    </p>
                  </div>
                  <p className="text-sm text-gray-500 mt-1 sm:mt-0">{formatDateTime(event.data)}</p>
                </div>
                
                <div className={`mt-2 p-3 rounded-lg ${event.type === 'comment' ? 'bg-gray-50' : ''}`}>
                  <p className="text-sm">{event.message}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="container mx-auto py-12 flex justify-center items-center">
        <Spinner className="mr-2" />
        <span>Carregando detalhes da prescrição...</span>
      </div>
    );
  }

  if (!prescricao) {
    return (
      <div className="container mx-auto py-12">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Erro</AlertTitle>
          <AlertDescription>
            Não foi possível encontrar a prescrição solicitada. 
            <Button variant="link" onClick={() => navigate(createPageUrl("PrescricoesAssociados"))}>
              Voltar para Prescrições
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center mb-6 gap-3">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate(createPageUrl("PrescricoesAssociados"))}
          className="mr-1"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold">Acompanhamento de Prescrição</h1>
          <p className="text-gray-500 mt-1">
            Confira o status e as atualizações da sua prescrição médica
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          className="flex items-center"
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          Atualizar
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="pb-3 border-b">
              <div className="flex justify-between items-center">
                <div className="flex flex-col">
                  <CardTitle className="flex items-center gap-2">
                    Status da Prescrição
                    {getStatusBadge(prescricao.status)}
                  </CardTitle>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6 pb-0">
              {renderStatusTimeline()}
            </CardContent>
            <CardFooter className="flex flex-col p-6">
              <div className="w-full">
                <Textarea
                  placeholder="Digite uma mensagem ou pergunta sobre esta prescrição..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  rows={3}
                  className="mb-3 w-full resize-none"
                />
                <div className="flex justify-end">
                  <Button 
                    onClick={handleAddComment} 
                    disabled={!newComment.trim() || sendingComment}
                  >
                    {sendingComment ? (
                      <>
                        <Spinner className="mr-2 h-4 w-4" />
                        Enviando...
                      </>
                    ) : (
                      <>
                        <MessageSquare className="mr-2 h-4 w-4" />
                        Enviar mensagem
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardFooter>
          </Card>
        </div>

        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="h-5 w-5 text-gray-500" />
                Detalhes da Prescrição
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-gray-500">Enviada por</p>
                <div className="flex items-center gap-2 mt-1">
                  <Avatar className="h-6 w-6">
                    <AvatarFallback>{prescricao.paciente_avatar}</AvatarFallback>
                  </Avatar>
                  <p className="font-medium">{prescricao.paciente_nome}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Data de envio</p>
                <p className="font-medium">{formatDateTime(prescricao.data_envio)}</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Validade</p>
                <p className="font-medium">{formatDate(prescricao.validade_prescricao)}</p>
              </div>

              <Separator />
              
              <div>
                <p className="text-sm text-gray-500">Médico</p>
                <p className="font-medium">{prescricao.dados_medico?.nome}</p>
                <p className="text-sm">{prescricao.dados_medico?.crm}</p>
                <p className="text-sm">{prescricao.dados_medico?.especialidade}</p>
              </div>

              {prescricao.observacoes_paciente && (
                <div>
                  <p className="text-sm text-gray-500">Observações do paciente</p>
                  <p className="text-sm p-2 bg-gray-50 rounded-md mt-1">{prescricao.observacoes_paciente}</p>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex-col items-start gap-3 pt-0">
              <Button variant="outline" className="w-full flex items-center justify-center">
                <Eye className="mr-2 h-4 w-4" />
                Visualizar Prescrição
              </Button>
              <Button variant="outline" className="w-full flex items-center justify-center">
                <Download className="mr-2 h-4 w-4" />
                Baixar Prescrição
              </Button>

              {(prescricao.status === 'rejeitada' || prescricao.status === 'solicitado_alteracao') && 
                currentUser && currentUser.id === prescricao.paciente_id && (
                <Button 
                  className="w-full flex items-center justify-center mt-2"
                  onClick={() => setShowUploadDialog(true)}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Enviar Nova Versão
                </Button>
              )}
            </CardFooter>
          </Card>

          {prescricao.status === 'aprovada' && (
            <Card className="bg-green-50 border-green-200">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-green-800">Prescrição Aprovada</h3>
                    <p className="text-sm text-green-700">
                      Esta prescrição foi aprovada e pode ser utilizada
                    </p>
                  </div>
                </div>
                
                <div className="bg-white rounded-md p-3 mb-3">
                  <p className="text-sm text-gray-700">
                    <span className="font-medium">Data de aprovação:</span> {prescricao.data_analise ? formatDateTime(prescricao.data_analise) : 'Não disponível'}
                  </p>
                </div>
                
                <Button className="w-full bg-green-600 hover:bg-green-700">
                  <Pill className="mr-2 h-4 w-4" />
                  Visualizar Produtos
                </Button>
              </CardContent>
            </Card>
          )}

          {prescricao.status === 'rejeitada' && (
            <Card className="bg-red-50 border-red-200">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="bg-red-100 p-2 rounded-full">
                    <XCircle className="h-6 w-6 text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-red-800">Prescrição Rejeitada</h3>
                    <p className="text-sm text-red-700">
                      Esta prescrição foi rejeitada e precisa ser corrigida
                    </p>
                  </div>
                </div>
                
                {prescricao.motivo_rejeicao && (
                  <div className="bg-white rounded-md p-3 mb-3">
                    <p className="text-sm font-medium text-gray-700 mb-1">
                      Motivo da rejeição:
                    </p>
                    <p className="text-sm text-gray-600">
                      {prescricao.motivo_rejeicao}
                    </p>
                  </div>
                )}
                
                {currentUser && currentUser.id === prescricao.paciente_id && (
                  <Button 
                    className="w-full bg-red-600 hover:bg-red-700"
                    onClick={() => setShowUploadDialog(true)}
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Enviar Nova Versão
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Upload New Version Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Enviar Nova Versão da Prescrição</DialogTitle>
            <DialogDescription>
              Faça o upload de uma nova versão da sua prescrição médica
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {errorMessage && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Erro</AlertTitle>
                <AlertDescription>{errorMessage}</AlertDescription>
              </Alert>
            )}

            <div>
              <label htmlFor="prescription-file" className="text-sm font-medium block mb-2">
                Arquivo da Prescrição
              </label>
              <div 
                className="border-2 border-dashed rounded-lg p-8 text-center hover:bg-gray-50 transition-colors cursor-pointer"
                onClick={() => document.getElementById('prescription-file').click()}
              >
                <Upload className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                <p className="text-sm font-medium mb-1">Arraste e solte o arquivo aqui ou clique para selecionar</p>
                <p className="text-xs text-gray-500">Suporta PDF, JPG ou PNG (até 10MB)</p>
              </div>
              <input
                id="prescription-file"
                type="file"
                accept=".pdf,image/*"
                className="hidden"
                onChange={handleFileChange}
              />
              
              {file && (
                <div className="mt-3 flex items-center justify-between p-3 border rounded-md">
                  <div className="flex items-center">
                    <FileText className="h-5 w-5 text-blue-500 mr-2" />
                    <span className="text-sm font-medium">{file.name}</span>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setFile(null)}
                  >
                    <XCircle className="h-4 w-4 text-gray-500" />
                  </Button>
                </div>
              )}
            </div>

            <p className="text-sm text-gray-500">
              Certifique-se de que a prescrição está legível e contém o nome do médico, CRM e data.
              Após o envio, sua prescrição entrará novamente em análise.
            </p>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUploadDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleUploadRevision}
              disabled={!file || uploadingFile}
            >
              {uploadingFile ? (
                <>
                  <Spinner className="mr-2 h-4 w-4" />
                  Enviando...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Enviar Nova Versão
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}