import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Leaf, 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Trash2, 
  Download, 
  FileText, 
  ClipboardList,
  Dna,
  FlaskConical,
  Sprout
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Strain } from "@/api/entities";

// Dados mockados para strains
const mockStrains = [
  { 
    id: 'strain1', 
    name: 'Charlotte\'s Web', 
    type: 'CBD', 
    thc_content: 0.6, 
    cbd_content: 18.2, 
    description: 'Strain de alto CBD desenvolvida para fins medicinais, com efeitos mínimos psicoativos.', 
    flowering_time: 60, 
    is_active: true, 
    current_mother_plant_count: 3,
    medical_applications: ['epilepsia', 'ansiedade', 'inflamação', 'dor crônica'],
    image_url: 'https://images.unsplash.com/photo-1536819114556-1c10251f684d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80'
  },
  { 
    id: 'strain2', 
    name: 'Cannatonic', 
    type: 'híbrida', 
    thc_content: 6.5, 
    cbd_content: 12.0, 
    description: 'Híbrida com razão THC:CBD balanceada, ideal para uso medicinal durante o dia.', 
    flowering_time: 70, 
    is_active: true, 
    current_mother_plant_count: 2,
    medical_applications: ['dor', 'espasmos musculares', 'enxaqueca', 'ansiedade'],
    image_url: 'https://images.unsplash.com/photo-1603909223429-69bb7101f92a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80'
  },
  { 
    id: 'strain3', 
    name: 'CBD Skunk', 
    type: 'híbrida', 
    thc_content: 3.8, 
    cbd_content: 9.5, 
    description: 'Variante rica em CBD da clássica Skunk, com teor reduzido de THC.', 
    flowering_time: 55, 
    is_active: true,
    current_mother_plant_count: 2,
    medical_applications: ['insônia', 'dor', 'inflamação', 'estresse'],
    image_url: 'https://images.unsplash.com/photo-1631383392337-b0a7de109786?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80'
  },
  { 
    id: 'strain4', 
    name: 'Harlequin', 
    type: 'sativa', 
    thc_content: 4.2, 
    cbd_content: 10.8, 
    description: 'Sativa predominante com alto CBD e efeitos cerebrais leves e focados.', 
    flowering_time: 65, 
    is_active: true,
    current_mother_plant_count: 1,
    medical_applications: ['dor crônica', 'ansiedade', 'TEPT', 'inflamação'],
    image_url: 'https://images.unsplash.com/photo-1620274549031-9785a68df728?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80'
  },
  { 
    id: 'strain5', 
    name: 'ACDC', 
    type: 'CBD', 
    thc_content: 0.5, 
    cbd_content: 20.0, 
    description: 'Fenótipo da Cannatonic com raz��o CBD:THC impressionante de 20:1.', 
    flowering_time: 72, 
    is_active: true,
    current_mother_plant_count: 2,
    medical_applications: ['epilepsia', 'esclerose múltipla', 'Parkinson', 'dor neuropática'],
    image_url: 'https://images.unsplash.com/photo-1586289883499-f11d28aaf57c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80'
  },
  { 
    id: 'strain6', 
    name: 'Sour Tsunami', 
    type: 'híbrida', 
    thc_content: 5.0, 
    cbd_content: 11.5, 
    description: 'Desenvolvida para maximizar o teor de CBD enquanto mantém efeitos de THC moderados.', 
    flowering_time: 58, 
    is_active: false,
    current_mother_plant_count: 0,
    medical_applications: ['dor crônica', 'inflamação', 'ansiedade', 'depressão'],
    image_url: 'https://images.unsplash.com/photo-1603909223644-541980c4adc7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80'
  }
];

// Componente para o formulário de nova strain
const NewStrainForm = ({ onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    name: '',
    type: 'híbrida',
    thc_content: 0,
    cbd_content: 0,
    description: '',
    flowering_time: 60,
    medical_applications: '',
    image_url: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Convertendo valores numéricos
    const processedData = {
      ...formData,
      thc_content: parseFloat(formData.thc_content),
      cbd_content: parseFloat(formData.cbd_content),
      flowering_time: parseInt(formData.flowering_time),
      medical_applications: formData.medical_applications.split(',').map(app => app.trim()),
      is_active: true,
      current_mother_plant_count: 0
    };
    
    onSubmit(processedData);
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Nome da Strain</Label>
        <Input 
          id="name" 
          name="name" 
          value={formData.name} 
          onChange={handleChange} 
          required 
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="type">Tipo</Label>
          <select 
            id="type" 
            name="type" 
            value={formData.type} 
            onChange={handleChange}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <option value="sativa">Sativa</option>
            <option value="indica">Indica</option>
            <option value="híbrida">Híbrida</option>
            <option value="CBD">CBD</option>
            <option value="industrial">Industrial</option>
          </select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="flowering_time">Tempo de Floração (dias)</Label>
          <Input 
            id="flowering_time" 
            name="flowering_time" 
            type="number" 
            value={formData.flowering_time} 
            onChange={handleChange} 
            min="30" 
            max="120" 
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="thc_content">Teor de THC (%)</Label>
          <Input 
            id="thc_content" 
            name="thc_content" 
            type="number" 
            step="0.1" 
            value={formData.thc_content} 
            onChange={handleChange} 
            min="0" 
            max="30" 
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="cbd_content">Teor de CBD (%)</Label>
          <Input 
            id="cbd_content" 
            name="cbd_content" 
            type="number" 
            step="0.1" 
            value={formData.cbd_content} 
            onChange={handleChange} 
            min="0" 
            max="30" 
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="medical_applications">Aplicações Medicinais (separadas por vírgula)</Label>
        <Input 
          id="medical_applications" 
          name="medical_applications" 
          value={formData.medical_applications} 
          onChange={handleChange} 
          placeholder="ex: dor, ansiedade, inflamação" 
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Descrição</Label>
        <Textarea 
          id="description" 
          name="description" 
          value={formData.description} 
          onChange={handleChange} 
          rows={3} 
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="image_url">URL da Imagem</Label>
        <Input 
          id="image_url" 
          name="image_url" 
          value={formData.image_url} 
          onChange={handleChange} 
          placeholder="https://..." 
        />
      </div>
      
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
        <Button type="submit">Salvar Strain</Button>
      </DialogFooter>
    </form>
  );
};

// Componente para visualizar detalhes da strain
const StrainDetailDialog = ({ strain, onClose }) => {
  if (!strain) return null;
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <div className="rounded-lg overflow-hidden h-[200px] mb-4">
          <img 
            src={strain.image_url || 'https://via.placeholder.com/400x300?text=Sem+Imagem'} 
            alt={strain.name} 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="space-y-3">
          <div>
            <Label className="text-sm text-gray-500">Tipo</Label>
            <p className="capitalize font-medium">{strain.type}</p>
          </div>
          
          <div>
            <Label className="text-sm text-gray-500">Status</Label>
            <p>
              {strain.is_active ? (
                <Badge className="bg-green-100 text-green-800">Ativa</Badge>
              ) : (
                <Badge className="bg-gray-100 text-gray-800">Inativa</Badge>
              )}
            </p>
          </div>
          
          <div>
            <Label className="text-sm text-gray-500">Tempo de Floração</Label>
            <p className="font-medium">{strain.flowering_time} dias</p>
          </div>
          
          <div>
            <Label className="text-sm text-gray-500">Plantas Madre Ativas</Label>
            <p className="font-medium">{strain.current_mother_plant_count}</p>
          </div>
        </div>
      </div>
      
      <div className="space-y-4">
        <div>
          <Label className="text-sm text-gray-500">Perfil de Canabinóides</Label>
          <div className="grid grid-cols-2 gap-2 mt-1">
            <div className="bg-green-50 p-3 rounded-lg">
              <div className="text-sm text-gray-600">THC</div>
              <div className="text-2xl font-bold text-green-600">{strain.thc_content}%</div>
            </div>
            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="text-sm text-gray-600">CBD</div>
              <div className="text-2xl font-bold text-blue-600">{strain.cbd_content}%</div>
            </div>
          </div>
          <div className="mt-1 text-sm text-gray-500">
            Razão CBD:THC - {(strain.cbd_content / (strain.thc_content || 0.1)).toFixed(1)}:1
          </div>
        </div>
        
        <div>
          <Label className="text-sm text-gray-500">Aplicações Medicinais</Label>
          <div className="flex flex-wrap gap-2 mt-1">
            {strain.medical_applications.map((app, idx) => (
              <Badge key={idx} variant="outline" className="capitalize">
                {app}
              </Badge>
            ))}
          </div>
        </div>
        
        <div>
          <Label className="text-sm text-gray-500">Descrição</Label>
          <p className="mt-1">{strain.description}</p>
        </div>
      </div>
      
      <div className="md:col-span-2">
        <Button className="w-full" onClick={onClose}>Fechar</Button>
      </div>
    </div>
  );
};

// Componente principal
export default function CultivoStrains() {
  const [isLoading, setIsLoading] = useState(true);
  const [strains, setStrains] = useState([]);
  const [filteredStrains, setFilteredStrains] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('todas');
  const [showNewStrainDialog, setShowNewStrainDialog] = useState(false);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [selectedStrain, setSelectedStrain] = useState(null);
  const [activeTab, setActiveTab] = useState('todas');

  useEffect(() => {
    loadStrains();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [searchTerm, typeFilter, activeTab, strains]);

  const loadStrains = async () => {
    try {
      setIsLoading(true);
      
      // Em produção, aqui seriam chamadas para as APIs reais
      // const fetchedStrains = await Strain.list();
      
      // Simulando carregamento
      setTimeout(() => {
        setStrains(mockStrains);
        setFilteredStrains(mockStrains);
        setIsLoading(false);
      }, 800);
      
    } catch (error) {
      console.error("Erro ao carregar strains:", error);
      setIsLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...strains];
    
    // Filtro por aba
    if (activeTab === 'ativas') {
      filtered = filtered.filter(strain => strain.is_active);
    } else if (activeTab === 'inativas') {
      filtered = filtered.filter(strain => !strain.is_active);
    }
    
    // Filtro por termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(strain => 
        strain.name.toLowerCase().includes(term) || 
        strain.description.toLowerCase().includes(term) ||
        strain.medical_applications.some(app => app.toLowerCase().includes(term))
      );
    }
    
    // Filtro por tipo
    if (typeFilter !== 'todas') {
      filtered = filtered.filter(strain => strain.type === typeFilter);
    }
    
    setFilteredStrains(filtered);
  };

  const handleNewStrain = (strainData) => {
    const newStrain = {
      id: `strain${strains.length + 1}`,
      ...strainData
    };
    
    setStrains(prev => [...prev, newStrain]);
  };

  const handleViewDetail = (strain) => {
    setSelectedStrain(strain);
    setShowDetailDialog(true);
  };

  const handleToggleStatus = (strainId) => {
    setStrains(prev => prev.map(strain => 
      strain.id === strainId ? { ...strain, is_active: !strain.is_active } : strain
    ));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Strains</h1>
          <p className="text-gray-500 mt-1">
            Gerenciamento de variedades genéticas para cultivo
          </p>
        </div>
        
        <Dialog open={showNewStrainDialog} onOpenChange={setShowNewStrainDialog}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Nova Strain
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Adicionar Nova Strain</DialogTitle>
              <DialogDescription>
                Cadastre uma nova variedade genética para cultivo
              </DialogDescription>
            </DialogHeader>
            <NewStrainForm 
              onClose={() => setShowNewStrainDialog(false)}
              onSubmit={handleNewStrain}
            />
          </DialogContent>
        </Dialog>
        
        <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
          <DialogContent className="sm:max-w-[650px]">
            <DialogHeader>
              <DialogTitle>{selectedStrain?.name}</DialogTitle>
              <DialogDescription>
                Detalhes completos da strain
              </DialogDescription>
            </DialogHeader>
            <StrainDetailDialog 
              strain={selectedStrain}
              onClose={() => setShowDetailDialog(false)}
            />
          </DialogContent>
        </Dialog>
      </div>
      
      <Tabs defaultValue="todas" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="todas">Todas as Strains</TabsTrigger>
          <TabsTrigger value="ativas">Ativas</TabsTrigger>
          <TabsTrigger value="inativas">Inativas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="todas" className="space-y-4">
          <Card>
            <CardHeader className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar strains..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <div className="flex gap-2 justify-end">
                  <select 
                    value={typeFilter} 
                    onChange={(e) => setTypeFilter(e.target.value)}
                    className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="todas">Todos os Tipos</option>
                    <option value="sativa">Sativa</option>
                    <option value="indica">Indica</option>
                    <option value="híbrida">Híbrida</option>
                    <option value="CBD">CBD</option>
                    <option value="industrial">Industrial</option>
                  </select>
                  
                  <Button variant="outline" size="icon" onClick={() => {
                    setSearchTerm('');
                    setTypeFilter('todas');
                  }}>
                    <Filter className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
                  <p className="ml-2">Carregando strains...</p>
                </div>
              ) : filteredStrains.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-12 text-center">
                  <Leaf className="w-12 h-12 text-gray-300 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900">Nenhuma strain encontrada</h3>
                  <p className="text-gray-500 mt-1 max-w-md mx-auto">
                    Não foram encontradas strains com os filtros selecionados. Tente ajustar seus critérios de busca ou crie uma nova strain.
                  </p>
                  <Button className="mt-4 gap-2" onClick={() => setShowNewStrainDialog(true)}>
                    <Plus className="w-4 h-4" />
                    Adicionar Strain
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 p-4">
                  {filteredStrains.map((strain) => (
                    <Card key={strain.id} className="overflow-hidden">
                      <div className="h-40 overflow-hidden relative">
                        <img 
                          src={strain.image_url || 'https://via.placeholder.com/400x200?text=Sem+Imagem'} 
                          alt={strain.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-2 right-2">
                          <Badge className={strain.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                            {strain.is_active ? 'Ativa' : 'Inativa'}
                          </Badge>
                        </div>
                      </div>
                      
                      <CardHeader className="p-4 pb-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg">{strain.name}</CardTitle>
                            <CardDescription className="flex items-center gap-1 capitalize">
                              <Leaf className="w-3 h-3" />
                              {strain.type}
                            </CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      
                      <CardContent className="p-4 pt-0">
                        <div className="flex gap-4 mb-3">
                          <div>
                            <div className="text-xs text-gray-500">THC</div>
                            <div className="font-bold">{strain.thc_content}%</div>
                          </div>
                          <div>
                            <div className="text-xs text-gray-500">CBD</div>
                            <div className="font-bold">{strain.cbd_content}%</div>
                          </div>
                          <div>
                            <div className="text-xs text-gray-500">Floração</div>
                            <div className="font-medium">{strain.flowering_time} dias</div>
                          </div>
                        </div>
                        
                        <p className="text-sm text-gray-600 line-clamp-2">
                          {strain.description}
                        </p>
                        
                        <div className="flex flex-wrap gap-1 mt-3">
                          {strain.medical_applications.slice(0, 3).map((app, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs capitalize">
                              {app}
                            </Badge>
                          ))}
                          {strain.medical_applications.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{strain.medical_applications.length - 3}
                            </Badge>
                          )}
                        </div>
                      </CardContent>
                      
                      <CardFooter className="flex justify-between p-4 pt-0">
                        <div className="text-sm">
                          <span className="text-gray-500">Madres:</span> {strain.current_mother_plant_count}
                        </div>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <span className="sr-only">Abrir menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Ações</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleViewDetail(strain)}>
                              <Eye className="mr-2 h-4 w-4" />
                              <span>Ver detalhes</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              <span>Editar</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => handleToggleStatus(strain.id)}>
                              {strain.is_active ? (
                                <>
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  <span>Desativar</span>
                                </>
                              ) : (
                                <>
                                  <Leaf className="mr-2 h-4 w-4" />
                                  <span>Ativar</span>
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Sprout className="mr-2 h-4 w-4" />
                              <span>Criar madre</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Download className="mr-2 h-4 w-4" />
                              <span>Exportar dados</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="ativas"><div className="h-4"></div></TabsContent>
        <TabsContent value="inativas"><div className="h-4"></div></TabsContent>
      </Tabs>
    </div>
  );
}