
import React, { useState, useEffect } from 'react';
import { 
  Brain, 
  Search, 
  Filter, 
  Plus, 
  BookOpen, 
  ChevronRight, 
  Users, 
  PieChart,
  Heart,
  FileText,
  BadgeInfo,
  Eye,
  Edit,
  Trash2,
  ArrowRight,
  ExternalLink,
  Dna,
  Flame,
  Stethoscope,
  AlertTriangle,
  CheckCircle,
  Microscope
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function DoencasCondicoes() {
  const [doencas, setDoencas] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [areaFilter, setAreaFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [showDetail, setShowDetail] = useState(false);
  const [selectedDoenca, setSelectedDoenca] = useState(null);
  const [view, setView] = useState('cards'); // 'cards' or 'table'

  // Mock data
  const mockDoencas = [
    {
      id: "d1",
      nome: "Epilepsia",
      nome_cientifico: "Epilepsia",
      cid: "G40",
      area: "neurologia",
      descricao: "Distúrbio em que a atividade cerebral se torna anormal, causando convulsões ou períodos de comportamento e sensações incomuns e, às vezes, perda de consciência.",
      sintomas: [
        "Convulsões",
        "Espasmos musculares",
        "Perda de consciência",
        "Confusão temporária",
        "Sintomas psíquicos"
      ],
      causas: [
        "Genética",
        "Traumatismo craniano",
        "Doenças cerebrais",
        "Infecções",
        "Distúrbios do desenvolvimento"
      ],
      fatores_risco: [
        "Histórico familiar",
        "Lesões na cabeça",
        "AVC",
        "Demência",
        "Infecções cerebrais"
      ],
      tratamentos_cannabis: [
        {
          tipo: "CBD isolado",
          descricao: "O canabidiol tem demonstrado redução na frequência de convulsões, especialmente em síndromes epilépticas específicas.",
          eficacia: "alta",
          estudos: 28
        },
        {
          tipo: "Espectro Completo",
          descricao: "Extratos com presença de múltiplos canabinoides incluindo baixas doses de THC podem potencializar o efeito anticonvulsivante.",
          eficacia: "moderada",
          estudos: 12
        }
      ],
      tratamentos_convencionais: [
        {
          tipo: "Anticonvulsivantes",
          descricao: "Medicamentos como valproato, carbamazepina e lamotrigina.",
          eficacia: "moderada",
          efeitos_colaterais: "Sonolência, tontura, problemas hepáticos, alterações comportamentais."
        },
        {
          tipo: "Cirurgia",
          descricao: "Remoção da área cerebral causadora das convulsões.",
          eficacia: "alta",
          efeitos_colaterais: "Riscos cirúrgicos, recuperação prolongada, possíveis déficits neurológicos."
        }
      ],
      prevalencia: {
        percentual_populacao: "1-2%",
        faixa_etaria: {
          "0-18": "30%",
          "19-40": "40%",
          "41-60": "20%",
          "60+": "10%"
        },
        genero: {
          masculino: "48%",
          feminino: "52%"
        }
      },
      pesquisas_relacionadas: [
        "Estudo da eficácia do CBD em epilepsia refratária",
        "Investigação sobre a farmacologia de canabinoides em doenças neurológicas"
      ],
      referencias: [
        {
          titulo: "Efficacy and Safety of Epidiolex (Cannabidiol) in Children and Young Adults with Treatment-Resistant Epilepsy",
          autores: ["Devinsky O", "Cross JH", "Wright S"],
          ano: "2019",
          url: "#"
        },
        {
          titulo: "Cannabis‐based medicinal products for epilepsy",
          autores: ["Stockings E", "Zagic D", "Campbell G"],
          ano: "2018",
          url: "#"
        }
      ]
    },
    {
      id: "d2",
      nome: "Dor crônica",
      nome_cientifico: "Dolor Chronicus",
      cid: "R52",
      area: "neurologia",
      descricao: "Dor persistente ou recorrente que dura mais que o tempo normal de cura (geralmente 3 meses). Pode existir mesmo após a cura da lesão que a originou.",
      sintomas: [
        "Dor persistente",
        "Limitação de movimentos",
        "Rigidez muscular",
        "Fadiga",
        "Alterações de humor",
        "Problemas de sono"
      ],
      causas: [
        "Lesões nervosas",
        "Fibromialgia",
        "Artrite",
        "Enxaqueca crônica",
        "Dor lombar crônica",
        "Neuropatia"
      ],
      fatores_risco: [
        "Lesões graves anteriores",
        "Cirurgias",
        "Infecções",
        "Doenças autoimunes",
        "Fatores genéticos"
      ],
      tratamentos_cannabis: [
        {
          tipo: "THC:CBD balanceado",
          descricao: "Combinações que incluem THC e CBD em proporções semelhantes têm demonstrado benefícios para dor neuropática e inflamatória.",
          eficacia: "alta",
          estudos: 35
        },
        {
          tipo: "CBD predominante",
          descricao: "Formulações com maior proporção de CBD são úteis para dor inflamatória com menos efeitos psicoativos.",
          eficacia: "moderada",
          estudos: 22
        }
      ],
      tratamentos_convencionais: [
        {
          tipo: "Analgésicos",
          descricao: "Anti-inflamatórios não esteroidais, opioides, acetaminofeno.",
          eficacia: "variável",
          efeitos_colaterais: "Problemas gastrointestinais, danos hepáticos, dependência (opioides)."
        },
        {
          tipo: "Antidepressivos",
          descricao: "Duloxetina, amitriptilina, entre outros.",
          eficacia: "moderada",
          efeitos_colaterais: "Boca seca, constipação, sonolência, tontura, náusea."
        }
      ],
      prevalencia: {
        percentual_populacao: "20-25%",
        faixa_etaria: {
          "0-18": "5%",
          "19-40": "25%",
          "41-60": "45%",
          "60+": "25%"
        },
        genero: {
          masculino: "40%",
          feminino: "60%"
        }
      },
      pesquisas_relacionadas: [
        "Efeitos do THC e CBD em pacientes com dor crônica",
        "Cannabis medicinal como alternativa a opioides para dor crônica"
      ],
      referencias: [
        {
          titulo: "Cannabis and cannabinoids for the treatment of chronic pain",
          autores: ["Aviram J", "Samuelly-Leichtag G"],
          ano: "2017",
          url: "#"
        },
        {
          titulo: "Cannabinoids for chronic pain",
          autores: ["Romero-Sandoval EA", "Kolano AL", "Alvarado-Vázquez PA"],
          ano: "2020",
          url: "#"
        }
      ]
    },
    {
      id: "d3",
      nome: "Esclerose Múltipla",
      nome_cientifico: "Sclerosis Multiplex",
      cid: "G35",
      area: "neurologia",
      descricao: "Doença autoimune crônica que afeta o sistema nervoso central, danificando a bainha de mielina que protege os nervos.",
      sintomas: [
        "Fadiga",
        "Dificuldade de mobilidade",
        "Problemas de coordenação",
        "Espasticidade",
        "Dor neuropática",
        "Problemas de visão",
        "Disfunção vesical e intestinal"
      ],
      causas: [
        "Autoimunidade",
        "Fatores genéticos",
        "Fatores ambientais",
        "Infecções virais"
      ],
      fatores_risco: [
        "Histórico familiar",
        "Deficiência de vitamina D",
        "Tabagismo",
        "Obesidade na adolescência",
        "Exposição a certos vírus"
      ],
      tratamentos_cannabis: [
        {
          tipo: "THC:CBD balanceado",
          descricao: "Sativex (nabiximols) é aprovado em vários países para espasticidade associada à EM.",
          eficacia: "alta",
          estudos: 30
        },
        {
          tipo: "CBD predominante",
          descricao: "Pode ajudar com inflamação e dor sem efeitos psicoativos significativos.",
          eficacia: "moderada",
          estudos: 18
        }
      ],
      tratamentos_convencionais: [
        {
          tipo: "Imunomoduladores",
          descricao: "Interferons, acetato de glatirâmer, fingolimode, entre outros.",
          eficacia: "moderada",
          efeitos_colaterais: "Sintomas semelhantes à gripe, reações no local da injeção, risco de infecções."
        },
        {
          tipo: "Corticosteroides",
          descricao: "Para tratamento de surtos agudos.",
          eficacia: "alta para surtos",
          efeitos_colaterais: "Retenção de líquidos, hipertensão, alterações de humor, ganho de peso."
        }
      ],
      prevalencia: {
        percentual_populacao: "0.1-0.2%",
        faixa_etaria: {
          "0-18": "5%",
          "19-40": "60%",
          "41-60": "30%",
          "60+": "5%"
        },
        genero: {
          masculino: "30%",
          feminino: "70%"
        }
      },
      pesquisas_relacionadas: [
        "Avaliação de longo prazo do uso de nabiximols em esclerose múltipla",
        "CBD e neuroinflamação em modelos de esclerose múltipla"
      ],
      referencias: [
        {
          titulo: "Sativex for the management of multiple sclerosis symptoms",
          autores: ["Giacoppo S", "Bramanti P", "Mazzon E"],
          ano: "2017",
          url: "#"
        },
        {
          titulo: "Cannabinoids in multiple sclerosis: A systematic review",
          autores: ["Nielsen S", "Germanos R", "McGregor IS"],
          ano: "2018",
          url: "#"
        }
      ]
    }
  ];

  useEffect(() => {
    const loadDoencas = async () => {
      setIsLoading(true);
      try {
        // Simular delay de API
        await new Promise(resolve => setTimeout(resolve, 1000));
        setDoencas(mockDoencas);
      } catch (error) {
        console.error("Erro ao carregar doenças:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadDoencas();
  }, []);

  const filteredDoencas = doencas.filter(doenca => {
    const matchesSearch = 
      doenca.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doenca.cid.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesArea = areaFilter === 'all' || doenca.area === areaFilter;
    
    return matchesSearch && matchesArea;
  });

  const handleViewDetail = (doenca) => {
    setSelectedDoenca(doenca);
    setShowDetail(true);
  };

  // Format efficacy to proper display text and color
  const formatEfficacy = (efficacy) => {
    const options = {
      alta: { text: "Alta Eficácia", color: "bg-green-100 text-green-800" },
      moderada: { text: "Eficácia Moderada", color: "bg-blue-100 text-blue-800" },
      baixa: { text: "Eficácia Baixa", color: "bg-yellow-100 text-yellow-800" },
      variavel: { text: "Eficácia Variável", color: "bg-purple-100 text-purple-800" }
    };

    return options[efficacy] || { text: efficacy, color: "bg-gray-100 text-gray-800" };
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Doenças e Condições</h1>
          <p className="text-muted-foreground">Base de conhecimento sobre condições tratadas com cannabis medicinal</p>
        </div>
        <div className="flex gap-2">
          <div className="flex p-1 border rounded-md bg-background">
            <Button 
              variant={view === 'cards' ? 'secondary' : 'ghost'} 
              size="sm" 
              onClick={() => setView('cards')}
              className="rounded-md"
            >
              <BookOpen className="h-4 w-4 mr-2" />
              Cards
            </Button>
            <Button 
              variant={view === 'table' ? 'secondary' : 'ghost'} 
              size="sm" 
              onClick={() => setView('table')}
              className="rounded-md"
            >
              <FileText className="h-4 w-4 mr-2" />
              Tabela
            </Button>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Nova Condição
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar por nome ou CID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={areaFilter} onValueChange={setAreaFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Área" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as Áreas</SelectItem>
            <SelectItem value="neurologia">Neurologia</SelectItem>
            <SelectItem value="psiquiatria">Psiquiatria</SelectItem>
            <SelectItem value="dor">Tratamento da Dor</SelectItem>
            <SelectItem value="oncologia">Oncologia</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Cards or Table View */}
      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
          <span className="ml-2">Carregando doenças e condições...</span>
        </div>
      ) : view === 'cards' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDoencas.map((doenca) => (
            <Card key={doenca.id} className="overflow-hidden hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <div className="flex justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Brain className="h-5 w-5 text-purple-500" />
                      {doenca.nome}
                    </CardTitle>
                    <CardDescription>CID: {doenca.cid}</CardDescription>
                  </div>
                  <Badge>{doenca.area}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 line-clamp-3 mb-3">{doenca.descricao}</p>
                
                <div className="space-y-3">
                  <div>
                    <h4 className="text-xs font-medium text-muted-foreground">Principais Sintomas</h4>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {doenca.sintomas.slice(0, 3).map((sintoma, index) => (
                        <Badge key={index} variant="outline" className="text-xs">{sintoma}</Badge>
                      ))}
                      {doenca.sintomas.length > 3 && (
                        <Badge variant="outline" className="text-xs">+{doenca.sintomas.length - 3}</Badge>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-xs font-medium text-muted-foreground">Tratamentos com Cannabis</h4>
                    <div className="space-y-1 mt-1">
                      {doenca.tratamentos_cannabis.map((tratamento, index) => {
                        const { text, color } = formatEfficacy(tratamento.eficacia);
                        return (
                          <div key={index} className="flex items-center justify-between text-sm">
                            <span>{tratamento.tipo}</span>
                            <Badge className={color}>{text}</Badge>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 dark:bg-gray-800/50 pt-2">
                <Button variant="outline" className="w-full" onClick={() => handleViewDetail(doenca)}>
                  <Eye className="w-4 h-4 mr-2" />
                  Ver Detalhes
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>CID</TableHead>
                  <TableHead>Área</TableHead>
                  <TableHead>Principais Sintomas</TableHead>
                  <TableHead>Tratamentos Cannabis</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDoencas.map((doenca) => (
                  <TableRow key={doenca.id}>
                    <TableCell className="font-medium">{doenca.nome}</TableCell>
                    <TableCell>{doenca.cid}</TableCell>
                    <TableCell>
                      <Badge>{doenca.area}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {doenca.sintomas.slice(0, 2).map((sintoma, index) => (
                          <Badge key={index} variant="outline" className="text-xs">{sintoma}</Badge>
                        ))}
                        {doenca.sintomas.length > 2 && (
                          <Badge variant="outline" className="text-xs">+{doenca.sintomas.length - 2}</Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {doenca.tratamentos_cannabis.map((tratamento, index) => (
                        <div key={index} className="text-sm">
                          {tratamento.tipo}
                        </div>
                      ))}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="sm" onClick={() => handleViewDetail(doenca)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-600">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Disease Detail Modal */}
      {selectedDoenca && (
        <Dialog open={showDetail} onOpenChange={setShowDetail}>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-2xl">
                <Brain className="h-6 w-6 text-purple-500" />
                {selectedDoenca.nome}
                <Badge className="ml-2">{selectedDoenca.cid}</Badge>
              </DialogTitle>
              <DialogDescription>
                {selectedDoenca.nome_cientifico}
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="overview" className="mt-6">
              <TabsList className="grid grid-cols-4">
                <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                <TabsTrigger value="treatments">Tratamentos</TabsTrigger>
                <TabsTrigger value="research">Pesquisas</TabsTrigger>
                <TabsTrigger value="statistics">Estatísticas</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-6 mt-6">
                <div>
                  <h3 className="text-lg font-medium">Descrição</h3>
                  <p className="mt-2">{selectedDoenca.descricao}</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-2 text-red-500" />
                        Sintomas
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        {selectedDoenca.sintomas.map((sintoma, index) => (
                          <li key={index} className="text-sm">{sintoma}</li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base flex items-center">
                        <Flame className="h-4 w-4 mr-2 text-orange-500" />
                        Causas
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        {selectedDoenca.causas.map((causa, index) => (
                          <li key={index} className="text-sm">{causa}</li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base flex items-center">
                        <BadgeInfo className="h-4 w-4 mr-2 text-blue-500" />
                        Fatores de Risco
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        {selectedDoenca.fatores_risco.map((fator, index) => (
                          <li key={index} className="text-sm">{fator}</li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="treatments" className="space-y-6 mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-medium mb-4 flex items-center">
                      <Heart className="h-5 w-5 mr-2 text-green-500" />
                      Tratamentos com Cannabis
                    </h3>
                    
                    <div className="space-y-4">
                      {selectedDoenca.tratamentos_cannabis.map((tratamento, index) => {
                        const { text, color } = formatEfficacy(tratamento.eficacia);
                        return (
                          <Card key={index}>
                            <CardHeader className="pb-2">
                              <div className="flex justify-between items-center">
                                <CardTitle className="text-base">{tratamento.tipo}</CardTitle>
                                <Badge className={color}>{text}</Badge>
                              </div>
                            </CardHeader>
                            <CardContent>
                              <p className="text-sm">{tratamento.descricao}</p>
                              <div className="mt-2 text-xs text-muted-foreground">
                                Baseado em {tratamento.estudos} estudos científicos
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium mb-4 flex items-center">
                      <Stethoscope className="h-5 w-5 mr-2 text-blue-500" />
                      Tratamentos Convencionais
                    </h3>
                    
                    <div className="space-y-4">
                      {selectedDoenca.tratamentos_convencionais.map((tratamento, index) => {
                        const { text, color } = formatEfficacy(tratamento.eficacia);
                        return (
                          <Card key={index}>
                            <CardHeader className="pb-2">
                              <div className="flex justify-between items-center">
                                <CardTitle className="text-base">{tratamento.tipo}</CardTitle>
                                <Badge className={color}>{text}</Badge>
                              </div>
                            </CardHeader>
                            <CardContent>
                              <p className="text-sm">{tratamento.descricao}</p>
                              <div className="mt-2 text-sm text-red-500">
                                <strong>Efeitos colaterais:</strong> {tratamento.efeitos_colaterais}
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="research" className="space-y-6 mt-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Pesquisas Relacionadas</h3>
                  
                  <div className="space-y-3">
                    {selectedDoenca.pesquisas_relacionadas.map((pesquisa, index) => (
                      <div key={index} className="flex items-center bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                        <Microscope className="h-5 w-5 text-purple-500 mr-3" />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{pesquisa}</p>
                        </div>
                        <Button variant="ghost" size="sm">
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}

                    {selectedDoenca.pesquisas_relacionadas.length === 0 && (
                      <p className="text-muted-foreground">Nenhuma pesquisa relacionada encontrada.</p>
                    )}
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Referências Bibliográficas</h3>
                  
                  <div className="space-y-3">
                    {selectedDoenca.referencias.map((referencia, index) => (
                      <div key={index} className="flex items-start p-3 border rounded-lg">
                        <BookOpen className="h-5 w-5 text-blue-500 mr-3 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{referencia.titulo}</p>
                          <p className="text-sm text-muted-foreground">
                            {referencia.autores.join(", ")} ({referencia.ano})
                          </p>
                        </div>
                        <Button variant="outline" size="sm">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Link
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="statistics" className="space-y-6 mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center">
                        <PieChart className="h-5 w-5 mr-2 text-blue-500" />
                        Prevalência
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-muted-foreground">Percentual na População Geral</h4>
                          <p className="text-xl font-bold mt-1">{selectedDoenca.prevalencia.percentual_populacao}</p>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium text-muted-foreground">Distribuição por Gênero</h4>
                          <div className="grid grid-cols-2 gap-4 mt-2">
                            <div className="bg-blue-50 p-3 rounded-lg text-center">
                              <p className="text-sm font-medium text-blue-700">Masculino</p>
                              <p className="text-lg font-bold text-blue-700">{selectedDoenca.prevalencia.genero.masculino}</p>
                            </div>
                            <div className="bg-pink-50 p-3 rounded-lg text-center">
                              <p className="text-sm font-medium text-pink-700">Feminino</p>
                              <p className="text-lg font-bold text-pink-700">{selectedDoenca.prevalencia.genero.feminino}</p>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium text-muted-foreground">Distribuição por Faixa Etária</h4>
                          <div className="space-y-2 mt-2">
                            {Object.entries(selectedDoenca.prevalencia.faixa_etaria).map(([faixa, percentual]) => (
                              <div key={faixa} className="flex items-center">
                                <span className="w-16 text-sm">{faixa}</span>
                                <div className="flex-1 h-4 bg-gray-100 rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-green-500 rounded-full"
                                    style={{ width: percentual }}
                                  ></div>
                                </div>
                                <span className="ml-2 text-sm font-medium">{percentual}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center">
                        <Dna className="h-5 w-5 mr-2 text-purple-500" />
                        Comparação de Tratamentos
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-muted-foreground">Eficácia Tratamentos com Cannabis</h4>
                          <div className="space-y-2 mt-2">
                            {selectedDoenca.tratamentos_cannabis.map((tratamento, index) => {
                              const { text, color } = formatEfficacy(tratamento.eficacia);
                              return (
                                <div key={index} className="flex items-center justify-between">
                                  <span className="text-sm">{tratamento.tipo}</span>
                                  <Badge className={color}>{text}</Badge>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                        
                        <Separator />
                        
                        <div>
                          <h4 className="text-sm font-medium text-muted-foreground">Eficácia Tratamentos Convencionais</h4>
                          <div className="space-y-2 mt-2">
                            {selectedDoenca.tratamentos_convencionais.map((tratamento, index) => {
                              const { text, color } = formatEfficacy(tratamento.eficacia);
                              return (
                                <div key={index} className="flex items-center justify-between">
                                  <span className="text-sm">{tratamento.tipo}</span>
                                  <Badge className={color}>{text}</Badge>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium text-muted-foreground mb-2">Estudos Científicos</h4>
                          <div className="bg-gray-50 p-3 rounded-lg">
                            <p className="text-center">
                              <span className="text-2xl font-bold text-green-600">{selectedDoenca.tratamentos_cannabis.reduce((acc, curr) => acc + curr.estudos, 0)}</span>
                              <span className="text-sm ml-2 text-muted-foreground">estudos sobre cannabis para esta condição</span>
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
            
            <DialogFooter className="mt-4">
              <Button variant="outline" onClick={() => setShowDetail(false)}>
                Fechar
              </Button>
              <Button variant="default">
                <Edit className="h-4 w-4 mr-2" />
                Editar Informações
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
