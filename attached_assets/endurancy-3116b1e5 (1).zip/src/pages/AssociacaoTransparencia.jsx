
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Eye, 
  Download, 
  FileText, 
  Search, 
  Filter, 
  ArrowUpRight, 
  CalendarDays, 
  User, 
  UserCheck, 
  Building, 
  DollarSign, 
  FileCheck, 
  CheckCircle2, 
  BarChart2, 
  Scale, 
  Clock, 
  MoreHorizontal, 
  ChevronDown, 
  Shield, 
  Award, 
  FileArchive, 
  BookOpen, 
  FileSearch,
  Info,
  Users,
  FileDigit,
  ListChecks,
  Scroll,
  BarChart
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";

// Dados simulados para documentos de transparência
const mockDocuments = [
  {
    id: "doc-001",
    title: "Relatório Financeiro Anual 2022",
    description: "Balanço anual completo com receitas, despesas e investimentos da associação no ano de 2022",
    category: "financial",
    date: "2023-03-15",
    file_url: "#",
    file_type: "pdf",
    file_size: 1458000,
    author: "Conselho Fiscal",
    is_public: true,
    views: 145,
    downloads: 32,
    tags: ["financeiro", "anual", "2022"],
    period_covered: {
      start: "2022-01-01",
      end: "2022-12-31"
    }
  },
  {
    id: "doc-002",
    title: "Ata da Assembleia Geral Ordinária",
    description: "Ata completa da Assembleia Geral Ordinária realizada em 25 de março de 2023",
    category: "governance",
    date: "2023-03-28",
    file_url: "#",
    file_type: "pdf",
    file_size: 850000,
    author: "Secretaria",
    is_public: true,
    views: 87,
    downloads: 21,
    tags: ["assembleia", "governança", "ata"],
    period_covered: null
  },
  {
    id: "doc-003",
    title: "Estatuto Social Atualizado",
    description: "Versão atual do Estatuto Social da Associação, com alterações aprovadas na AGE de 12/02/2023",
    category: "legal",
    date: "2023-02-20",
    file_url: "#",
    file_type: "pdf",
    file_size: 1280000,
    author: "Diretoria Jurídica",
    is_public: true,
    views: 203,
    downloads: 78,
    tags: ["estatuto", "legal", "governança"],
    period_covered: null
  },
  {
    id: "doc-004",
    title: "Relatório de Atividades do 1º Trimestre 2023",
    description: "Resumo das atividades, projetos e iniciativas realizadas pela associação no primeiro trimestre de 2023",
    category: "reports",
    date: "2023-04-10",
    file_url: "#",
    file_type: "pdf",
    file_size: 2300000,
    author: "Diretoria Executiva",
    is_public: true,
    views: 91,
    downloads: 17,
    tags: ["atividades", "trimestral", "2023"],
    period_covered: {
      start: "2023-01-01",
      end: "2023-03-31"
    }
  },
  {
    id: "doc-005",
    title: "Prestação de Contas - Janeiro 2023",
    description: "Detalhamento mensal de receitas e despesas da associação",
    category: "financial",
    date: "2023-02-10",
    file_url: "#",
    file_type: "pdf",
    file_size: 980000,
    author: "Conselho Fiscal",
    is_public: true,
    views: 56,
    downloads: 12,
    tags: ["financeiro", "mensal", "2023"],
    period_covered: {
      start: "2023-01-01",
      end: "2023-01-31"
    }
  },
  {
    id: "doc-006",
    title: "Lista Atual de Membros da Diretoria",
    description: "Relação completa dos membros que compõem a atual Diretoria Executiva e Conselhos",
    category: "members",
    date: "2023-04-01",
    file_url: "#",
    file_type: "pdf",
    file_size: 450000,
    author: "Secretaria",
    is_public: true,
    views: 134,
    downloads: 29,
    tags: ["diretoria", "governança", "membros"],
    period_covered: null
  },
  {
    id: "doc-007",
    title: "Relatório de Impacto Social 2022",
    description: "Análise detalhada do impacto social das atividades e projetos da associação durante o ano de 2022",
    category: "reports",
    date: "2023-03-01",
    file_url: "#",
    file_type: "pdf",
    file_size: 3500000,
    author: "Comitê de Responsabilidade Social",
    is_public: true,
    views: 112,
    downloads: 45,
    tags: ["impacto", "social", "relatório", "2022"],
    period_covered: {
      start: "2022-01-01",
      end: "2022-12-31"
    }
  },
  {
    id: "doc-008",
    title: "Edital de Convocação - AGE Junho 2023",
    description: "Edital de convocação para Assembleia Geral Extraordinária a ser realizada em 15 de junho de 2023",
    category: "governance",
    date: "2023-05-15",
    file_url: "#",
    file_type: "pdf",
    file_size: 320000,
    author: "Diretoria Executiva",
    is_public: true,
    views: 68,
    downloads: 15,
    tags: ["assembleia", "convocação", "governança"],
    period_covered: null
  }
];

// Dados simulados para membros da diretoria
const mockBoardMembers = [
  {
    id: "member-001",
    name: "Dr. José Roberto Silva",
    position: "Presidente",
    email: "presidente@associacaomedicannabisverde.org.br",
    phone: "(11) 99123-4567",
    bio: "Médico neurologista com 25 anos de experiência. Pesquisador na área de canabinoides desde 2010.",
    avatar: "https://randomuser.me/api/portraits/men/43.jpg",
    term_start: "2022-01-01",
    term_end: "2023-12-31",
    is_public: true
  },
  {
    id: "member-002",
    name: "Dra. Maria Luiza Santos",
    position: "Vice-Presidente",
    email: "vicepresidente@associacaomedicannabisverde.org.br",
    phone: "(11) 99234-5678",
    bio: "Farmacêutica, doutora em Farmacologia. Pesquisadora em tratamentos alternativos para dor crônica.",
    avatar: "https://randomuser.me/api/portraits/women/63.jpg",
    term_start: "2022-01-01",
    term_end: "2023-12-31",
    is_public: true
  },
  {
    id: "member-003",
    name: "João Carlos Mendes",
    position: "Diretor Financeiro",
    email: "financeiro@associacaomedicannabisverde.org.br",
    phone: "(11) 99345-6789",
    bio: "Contador, especialista em gestão financeira para organizações sem fins lucrativos. MBA em Finanças.",
    avatar: "https://randomuser.me/api/portraits/men/32.jpg",
    term_start: "2022-01-01",
    term_end: "2023-12-31",
    is_public: true
  },
  {
    id: "member-004",
    name: "Ana Paula Ferreira",
    position: "Diretora Jurídica",
    email: "juridico@associacaomedicannabisverde.org.br",
    phone: "(11) 99456-7890",
    bio: "Advogada especializada em direito médico e regulatório. Atuante em causas relacionadas ao acesso à cannabis medicinal.",
    avatar: "https://randomuser.me/api/portraits/women/45.jpg",
    term_start: "2022-01-01",
    term_end: "2023-12-31",
    is_public: true
  },
  {
    id: "member-005",
    name: "Dr. Roberto Almeida",
    position: "Diretor Científico",
    email: "cientifico@associacaomedicannabisverde.org.br",
    phone: "(11) 99567-8901",
    bio: "Médico e doutor em Neurociências. Autor de mais de 50 publicações científicas sobre o sistema endocanabinoide.",
    avatar: "https://randomuser.me/api/portraits/men/65.jpg",
    term_start: "2022-01-01",
    term_end: "2023-12-31",
    is_public: true
  },
  {
    id: "member-006",
    name: "Patrícia Costa",
    position: "Diretora de Comunicação",
    email: "comunicacao@associacaomedicannabisverde.org.br",
    phone: "(11) 99678-9012",
    bio: "Jornalista com especialização em comunicação para saúde. Experiência em campanhas de conscientização em saúde pública.",
    avatar: "https://randomuser.me/api/portraits/women/33.jpg",
    term_start: "2022-01-01",
    term_end: "2023-12-31",
    is_public: true
  }
];

// Dados simulados para informações financeiras
const mockFinancialInfo = {
  current_year: {
    revenue: 845600,
    expenses: 776300,
    balance: 69300,
    members_fees: 623400,
    donations: 122200,
    events: 85000,
    other_revenue: 15000,
    administrative: 245600,
    personnel: 321400,
    projects: 156300,
    research: 35000,
    other_expenses: 18000
  },
  previous_year: {
    revenue: 720300,
    expenses: 685200,
    balance: 35100,
    members_fees: 523000,
    donations: 97300,
    events: 75000,
    other_revenue: 25000,
    administrative: 220500,
    personnel: 285000,
    projects: 132300,
    research: 30000,
    other_expenses: 17400
  }
};

export default function AssociacaoTransparencia() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [documents, setDocuments] = useState([]);
  const [boardMembers, setBoardMembers] = useState([]);
  const [financialInfo, setFinancialInfo] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // Simulação de carregamento de dados
    const loadData = async () => {
      setIsLoading(true);
      try {
        // Simular uma chamada API com timeout
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setDocuments(mockDocuments);
        setBoardMembers(mockBoardMembers);
        setFinancialInfo(mockFinancialInfo);
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        toast({
          title: "Erro ao carregar dados",
          description: "Não foi possível carregar as informações de transparência.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          doc.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          doc.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = categoryFilter === "all" || doc.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  const getCategoryIcon = (category) => {
    switch (category) {
      case "financial":
        return <DollarSign className="w-5 h-5 text-emerald-600" />;
      case "governance":
        return <UserCheck className="w-5 h-5 text-blue-600" />;
      case "legal":
        return <Scale className="w-5 h-5 text-purple-600" />;
      case "reports":
        return <FileText className="w-5 h-5 text-amber-600" />;
      case "members":
        return <Users className="w-5 h-5 text-indigo-600" />;
      case "events":
        return <CalendarDays className="w-5 h-5 text-red-600" />;
      default:
        return <FileText className="w-5 h-5 text-gray-600" />;
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + " B";
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
    else return (bytes / 1048576).toFixed(1) + " MB";
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 border-t-4 border-blue-500 border-solid rounded-full animate-spin"></div>
          <p className="text-lg text-gray-600">Carregando informações de transparência...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Portal de Transparência</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Acesse todos os documentos, relatórios e informações sobre nossa gestão, governança e finanças. 
          Transparência é um dos nossos valores fundamentais.
        </p>
      </div>

      <Tabs defaultValue="documents" className="mb-12">
        <TabsList className="grid w-full grid-cols-3 md:w-auto md:inline-flex mb-8">
          <TabsTrigger value="documents" className="text-sm md:text-base">
            <FileText className="w-4 h-4 mr-2" />
            Documentos
          </TabsTrigger>
          <TabsTrigger value="governance" className="text-sm md:text-base">
            <UserCheck className="w-4 h-4 mr-2" />
            Governança
          </TabsTrigger>
          <TabsTrigger value="financial" className="text-sm md:text-base">
            <DollarSign className="w-4 h-4 mr-2" />
            Financeiro
          </TabsTrigger>
        </TabsList>

        <TabsContent value="documents">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <CardTitle>Documentos Públicos</CardTitle>
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Buscar documentos..."
                      className="pl-10 w-full"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue placeholder="Categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas categorias</SelectItem>
                      <SelectItem value="financial">Financeiro</SelectItem>
                      <SelectItem value="governance">Governança</SelectItem>
                      <SelectItem value="legal">Legal</SelectItem>
                      <SelectItem value="reports">Relatórios</SelectItem>
                      <SelectItem value="members">Membros</SelectItem>
                      <SelectItem value="events">Eventos</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {filteredDocuments.length === 0 ? (
                <div className="text-center py-10">
                  <FileSearch className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhum documento encontrado</h3>
                  <p className="text-gray-500">
                    Tente ajustar seus filtros ou termos de busca para encontrar o que procura.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredDocuments.map((doc) => (
                    <Card key={doc.id} className="overflow-hidden hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-3">
                            {getCategoryIcon(doc.category)}
                            <Badge variant="outline" className="capitalize">
                              {doc.category === "financial" ? "Financeiro" : 
                               doc.category === "governance" ? "Governança" : 
                               doc.category === "legal" ? "Legal" : 
                               doc.category === "reports" ? "Relatórios" : 
                               doc.category === "members" ? "Membros" : 
                               doc.category === "events" ? "Eventos" : doc.category}
                            </Badge>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem className="cursor-pointer">
                                <Eye className="w-4 h-4 mr-2" />
                                Visualizar
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <Download className="w-4 h-4 mr-2" />
                                Download
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="cursor-pointer">
                                <ArrowUpRight className="w-4 h-4 mr-2" />
                                Compartilhar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                        <CardTitle className="text-lg mt-2">{doc.title}</CardTitle>
                        <CardDescription className="line-clamp-2">
                          {doc.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex items-center text-sm text-gray-500 mt-1">
                          <CalendarDays className="w-4 h-4 mr-1" />
                          <span>{new Date(doc.date).toLocaleDateString('pt-BR')}</span>
                          {doc.period_covered && (
                            <span className="mx-1">
                              (Período: {new Date(doc.period_covered.start).toLocaleDateString('pt-BR')} - {new Date(doc.period_covered.end).toLocaleDateString('pt-BR')})
                            </span>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-1 mt-3">
                          {doc.tags.map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                      <CardFooter className="bg-gray-50 border-t px-6 py-3">
                        <div className="flex justify-between items-center w-full text-sm">
                          <div className="text-gray-500">
                            {doc.file_type.toUpperCase()} • {formatFileSize(doc.file_size)}
                          </div>
                          <Button variant="ghost" size="sm" className="gap-1">
                            <Download className="w-4 h-4" />
                            Download
                          </Button>
                        </div>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="governance">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>Sobre a Associação</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-base font-semibold mb-2">Missão</h3>
                  <p className="text-gray-600">
                    Promover o acesso seguro e legal à cannabis medicinal, apoiando pacientes e desenvolvendo pesquisas para avanço do conhecimento científico sobre os benefícios terapêuticos dos canabinoides.
                  </p>
                </div>
                <div>
                  <h3 className="text-base font-semibold mb-2">Visão</h3>
                  <p className="text-gray-600">
                    Ser referência nacional em excelência no cultivo, produção e fornecimento de cannabis medicinal, com total transparência e compromisso com a saúde dos pacientes.
                  </p>
                </div>
                <div>
                  <h3 className="text-base font-semibold mb-2">Valores</h3>
                  <ul className="list-disc list-inside text-gray-600 space-y-1">
                    <li>Transparência em todas as ações</li>
                    <li>Compromisso com a qualidade e segurança</li>
                    <li>Responsabilidade social</li>
                    <li>Rigor científico</li>
                    <li>Foco no bem-estar do paciente</li>
                    <li>Ética e integridade</li>
                  </ul>
                </div>
                <div>
                  <h3 className="text-base font-semibold mb-2">Fundação</h3>
                  <p className="text-gray-600">
                    Fundada em 15 de maio de 2018 por um grupo de médicos, pacientes e familiares comprometidos com o acesso seguro à cannabis medicinal.
                  </p>
                </div>
                <div className="pt-2">
                  <Button variant="outline" className="w-full">
                    <FileText className="w-4 h-4 mr-2" />
                    Ver Estatuto Social
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Membros da Diretoria</CardTitle>
                <CardDescription>
                  Conheça os responsáveis pela gestão da nossa associação
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {boardMembers.map((member) => (
                    <div key={member.id} className="flex gap-4">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={member.avatar} alt={member.name} />
                        <AvatarFallback>{member.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="space-y-1">
                        <h3 className="font-medium">{member.name}</h3>
                        <p className="text-sm text-blue-600 font-medium">{member.position}</p>
                        <p className="text-sm text-gray-500 line-clamp-2">{member.bio}</p>
                        <p className="text-xs text-gray-400">
                          Mandato: {new Date(member.term_start).toLocaleDateString('pt-BR')} - {new Date(member.term_end).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 border-t px-6 py-3">
                <Button variant="outline" size="sm" className="ml-auto">
                  <Users className="w-4 h-4 mr-2" />
                  Ver Todos os Associados
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="financial">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-3">
              <CardHeader>
                <CardTitle>Resumo Financeiro Anual</CardTitle>
                <CardDescription>
                  Comparativo financeiro entre o ano atual e o anterior
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-lg font-medium mb-4">Receitas vs Despesas</h3>
                    <div className="space-y-6">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-green-50 p-4 rounded-lg">
                          <p className="text-sm text-green-700 mb-1">Receita Total</p>
                          <p className="text-2xl font-bold text-green-700">
                            {formatCurrency(financialInfo.current_year.revenue)}
                          </p>
                          <div className="flex items-center mt-1 text-sm">
                            <ArrowUpRight className="w-4 h-4 text-green-500 mr-1" />
                            <span className="text-green-500">
                              +{((financialInfo.current_year.revenue / financialInfo.previous_year.revenue - 1) * 100).toFixed(1)}%
                            </span>
                            <span className="text-gray-500 ml-1">vs ano anterior</span>
                          </div>
                        </div>

                        <div className="bg-red-50 p-4 rounded-lg">
                          <p className="text-sm text-red-700 mb-1">Despesa Total</p>
                          <p className="text-2xl font-bold text-red-700">
                            {formatCurrency(financialInfo.current_year.expenses)}
                          </p>
                          <div className="flex items-center mt-1 text-sm">
                            <ArrowUpRight className="w-4 h-4 text-red-500 mr-1" />
                            <span className="text-red-500">
                              +{((financialInfo.current_year.expenses / financialInfo.previous_year.expenses - 1) * 100).toFixed(1)}%
                            </span>
                            <span className="text-gray-500 ml-1">vs ano anterior</span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-blue-50 p-4 rounded-lg">
                        <p className="text-sm text-blue-700 mb-1">Balanço</p>
                        <p className="text-2xl font-bold text-blue-700">
                          {formatCurrency(financialInfo.current_year.balance)}
                        </p>
                        <div className="flex items-center mt-1 text-sm">
                          <ArrowUpRight className="w-4 h-4 text-blue-500 mr-1" />
                          <span className="text-blue-500">
                            +{((financialInfo.current_year.balance / financialInfo.previous_year.balance - 1) * 100).toFixed(1)}%
                          </span>
                          <span className="text-gray-500 ml-1">vs ano anterior</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-4">Detalhamento de Receitas</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                          <span className="text-sm">Contribuições dos Associados</span>
                        </div>
                        <span className="font-medium">{formatCurrency(financialInfo.current_year.members_fees)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-green-500"></div>
                          <span className="text-sm">Doações</span>
                        </div>
                        <span className="font-medium">{formatCurrency(financialInfo.current_year.donations)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                          <span className="text-sm">Eventos e Cursos</span>
                        </div>
                        <span className="font-medium">{formatCurrency(financialInfo.current_year.events)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-gray-500"></div>
                          <span className="text-sm">Outras Receitas</span>
                        </div>
                        <span className="font-medium">{formatCurrency(financialInfo.current_year.other_revenue)}</span>
                      </div>
                    </div>

                    <h3 className="text-lg font-medium mt-8 mb-4">Detalhamento de Despesas</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                          <span className="text-sm">Administrativas</span>
                        </div>
                        <span className="font-medium">{formatCurrency(financialInfo.current_year.administrative)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-red-500"></div>
                          <span className="text-sm">Pessoal</span>
                        </div>
                        <span className="font-medium">{formatCurrency(financialInfo.current_year.personnel)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-indigo-500"></div>
                          <span className="text-sm">Projetos</span>
                        </div>
                        <span className="font-medium">{formatCurrency(financialInfo.current_year.projects)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-teal-500"></div>
                          <span className="text-sm">Pesquisa</span>
                        </div>
                        <span className="font-medium">{formatCurrency(financialInfo.current_year.research)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 border-t px-6 py-3 flex justify-between">
                <div className="flex items-center text-sm text-gray-500">
                  <Info className="w-4 h-4 mr-1" />
                  <span>Os dados acima são atualizados trimestralmente.</span>
                </div>
                <Button variant="outline" size="sm">
                  <FileDigit className="w-4 h-4 mr-2" />
                  Ver Relatório Financeiro Completo
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <div className="text-center mt-16 mb-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Compromisso com a Transparência</h2>
        <p className="text-gray-600 max-w-3xl mx-auto mb-8">
          Nossa associação acredita que a transparência é fundamental para construir confiança e 
          credibilidade. Disponibilizamos todas as informações relevantes sobre nossa gestão, 
          finanças e governança para que associados e público em geral possam acompanhar 
          nossas ações.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <Card className="text-center">
            <CardHeader className="pb-2 pt-6">
              <div className="w-12 h-12 bg-blue-100 rounded-full mx-auto flex items-center justify-center mb-4">
                <FileCheck className="h-6 w-6 text-blue-600" />
              </div>
              <CardTitle className="text-lg">Documentos Públicos</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm">
                Todos os documentos importantes são disponibilizados para consulta livre, incluindo 
                estatuto, atas, balanços e relatórios.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader className="pb-2 pt-6">
              <div className="w-12 h-12 bg-amber-100 rounded-full mx-auto flex items-center justify-center mb-4">
                <ListChecks className="h-6 w-6 text-amber-600" />
              </div>
              <CardTitle className="text-lg">Prestação de Contas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm">
                Apresentamos regularmente relatórios detalhados sobre nossa gestão financeira, 
                com auditoria independente anual.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader className="pb-2 pt-6">
              <div className="w-12 h-12 bg-green-100 rounded-full mx-auto flex items-center justify-center mb-4">
                <Scroll className="h-6 w-6 text-green-600" />
              </div>
              <CardTitle className="text-lg">Gestão Responsável</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm">
                Nossa governança é baseada em processos claros e documentados, 
                com responsabilidades bem definidas.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
