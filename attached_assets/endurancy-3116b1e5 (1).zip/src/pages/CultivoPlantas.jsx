import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Leaf, 
  Search, 
  Filter, 
  Plus, 
  Calendar, 
  Clock, 
  Ruler, 
  FileText, 
  Star, 
  MoreHorizontal, 
  Sprout,
  SunMedium,
  Scissors,
  AlertTriangle,
  CheckCircle2,
  Trash2,
  Edit,
  Eye
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Plant } from "@/api/entities";
import { format } from 'date-fns';

// Dados mockados para plantas
const mockPlantas = [
  { 
    id: 'plant1', 
    plant_id: 'PLT-2023-1001', 
    strain: 'Charlotte\'s Web', 
    origin: 'clone', 
    mother_plant_id: 'PLT-MAE-023', 
    status: 'ativa', 
    current_phase: 'vegetativo', 
    location: 'Sala Vegetativo 1',
    planting_date: '2023-06-15',
    phase_start_date: '2023-06-30',
    expected_harvest_date: '2023-08-30',
    height: 45,
    health_status: 'saudável',
    health_notes: '',
    notes: 'Desenvolvimento acima da média',
    batch_id: 'LOTE-2023-0142'
  },
  { 
    id: 'plant2', 
    plant_id: 'PLT-2023-1002', 
    strain: 'Charlotte\'s Web', 
    origin: 'clone', 
    mother_plant_id: 'PLT-MAE-023', 
    status: 'ativa', 
    current_phase: 'vegetativo', 
    location: 'Sala Vegetativo 1',
    planting_date: '2023-06-15',
    phase_start_date: '2023-06-30',
    expected_harvest_date: '2023-08-30',
    height: 40,
    health_status: 'saudável',
    health_notes: '',
    notes: '',
    batch_id: 'LOTE-2023-0142'
  },
  { 
    id: 'plant3', 
    plant_id: 'PLT-2023-1003', 
    strain: 'CBD Skunk', 
    origin: 'clone', 
    mother_plant_id: 'PLT-MAE-018', 
    status: 'ativa', 
    current_phase: 'floração', 
    location: 'Sala Floração 1',
    planting_date: '2023-06-01',
    phase_start_date: '2023-07-01',
    expected_harvest_date: '2023-08-15',
    height: 65,
    health_status: 'problema leve',
    health_notes: 'Algumas folhas com pontas amareladas',
    notes: 'Monitorar diariamente',
    batch_id: 'LOTE-2023-0143'
  },
  { 
    id: 'plant4', 
    plant_id: 'PLT-2023-1004', 
    strain: 'Cannatonic', 
    origin: 'clone', 
    mother_plant_id: 'PLT-MAE-015', 
    status: 'ativa', 
    current_phase: 'floração', 
    location: 'Sala Floração 2',
    planting_date: '2023-06-05',
    phase_start_date: '2023-07-05',
    expected_harvest_date: '2023-08-20',
    height: 70,
    health_status: 'saudável',
    health_notes: '',
    notes: '',
    batch_id: 'LOTE-2023-0144'
  },
  { 
    id: 'plant5', 
    plant_id: 'PLT-2023-1005', 
    strain: 'Harlequin', 
    origin: 'semente', 
    mother_plant_id: null, 
    status: 'ativa', 
    current_phase: 'propagação', 
    location: 'Sala Propagação',
    planting_date: '2023-07-10',
    phase_start_date: '2023-07-10',
    expected_harvest_date: '2023-10-01',
    height: 12,
    health_status: 'saudável',
    health_notes: '',
    notes: 'Germinação rápida',
    batch_id: 'LOTE-2023-0145'
  },
  { 
    id: 'plant6', 
    plant_id: 'PLT-MAE-023', 
    strain: 'Charlotte\'s Web', 
    origin: 'semente', 
    mother_plant_id: null, 
    status: 'madre', 
    current_phase: 'vegetativo', 
    location: 'Sala de Mães',
    planting_date: '2023-03-15',
    phase_start_date: '2023-03-30',
    expected_harvest_date: null,
    height: 120,
    health_status: 'saudável',
    health_notes: '',
    notes: 'Planta madre principal, excelente genética',
    batch_id: null
  },
  { 
    id: 'plant7', 
    plant_id: 'PLT-2023-0985', 
    strain: 'ACDC', 
    origin: 'clone', 
    mother_plant_id: 'PLT-MAE-021', 
    status: 'colhida', 
    current_phase: 'colheita', 
    location: 'Sala de Secagem',
    planting_date: '2023-05-02',
    phase_start_date: '2023-07-20',
    expected_harvest_date: '2023-07-22',
    actual_harvest_date: '2023-07-22',
    height: 80,
    wet_weight: 450,
    dry_weight: 112,
    health_status: 'saudável',
    health_notes: '',
    notes: 'Colheita dentro do esperado',
    batch_id: 'LOTE-2023-0130'
  }
];

// Função para obter ícone por fase
const getPhaseIcon = (phase) => {
  switch(phase) {
    case 'propagação':
      return <Sprout className="w-4 h-4 text-blue-600" />;
    case 'vegetativo':
      return <Leaf className="w-4 h-4 text-green-600" />;
    case 'floração':
      return <SunMedium className="w-4 h-4 text-purple-600" />;
    case 'colheita':
      return <Scissors className="w-4 h-4 text-amber-600" />;
    case 'secagem':
      return <FileText className="w-4 h-4 text-gray-600" />;
    default:
      return <Leaf className="w-4 h-4 text-gray-600" />;
  }
};

// Função para obter cor por status de saúde
const getHealthColor = (status) => {
  switch(status) {
    case 'saudável':
      return 'bg-green-100 text-green-800';
    case 'problema leve':
      return 'bg-yellow-100 text-yellow-800';
    case 'problema grave':
      return 'bg-orange-100 text-orange-800';
    case 'infestação':
    case 'doença':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

// Função para obter cor por status da planta
const getStatusColor = (status) => {
  switch(status) {
    case 'ativa':
      return 'bg-green-100 text-green-800';
    case 'madre':
      return 'bg-purple-100 text-purple-800';
    case 'colhida':
      return 'bg-amber-100 text-amber-800';
    case 'descartada':
      return 'bg-red-100 text-red-800';
    case 'transferida':
      return 'bg-blue-100 text-blue-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export default function CultivoPlantas() {
  const [isLoading, setIsLoading] = useState(true);
  const [plantas, setPlantas] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('todas');
  const [filterPhase, setFilterPhase] = useState('all');
  const [filterStrain, setFilterStrain] = useState('all');
  const [filterHealth, setFilterHealth] = useState('all');
  
  useEffect(() => {
    loadPlantas();
  }, []);
  
  const loadPlantas = async () => {
    try {
      setIsLoading(true);
      // Em produção, seria uma chamada à API real
      setTimeout(() => {
        setPlantas(mockPlantas);
        setIsLoading(false);
      }, 800);
    } catch (error) {
      console.error("Erro ao carregar plantas:", error);
      setIsLoading(false);
    }
  };
  
  // Filtros
  const filterPlantsByTab = (plantas) => {
    switch (activeTab) {
      case 'ativas':
        return plantas.filter(planta => planta.status === 'ativa');
      case 'madres':
        return plantas.filter(planta => planta.status === 'madre');
      case 'colhidas':
        return plantas.filter(planta => planta.status === 'colhida');
      default:
        return plantas;
    }
  };
  
  const applyFilters = (plantas) => {
    return plantas.filter(planta => {
      // Filtro de pesquisa
      const matchesSearch = planta.plant_id.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           planta.strain.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           (planta.notes && planta.notes.toLowerCase().includes(searchTerm.toLowerCase()));
      
      // Filtros de seleção
      const matchesPhase = filterPhase === 'all' || planta.current_phase === filterPhase;
      const matchesStrain = filterStrain === 'all' || planta.strain === filterStrain;
      const matchesHealth = filterHealth === 'all' || planta.health_status === filterHealth;
      
      return matchesSearch && matchesPhase && matchesStrain && matchesHealth;
    });
  };
  
  const filteredPlantas = applyFilters(filterPlantsByTab(plantas));
  
  // Extração de opções únicas para os filtros
  const strainOptions = [...new Set(plantas.map(p => p.strain))];
  const phaseOptions = [...new Set(plantas.map(p => p.current_phase))];
  const healthOptions = [...new Set(plantas.map(p => p.health_status))];
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Plantas</h1>
          <p className="text-gray-500 mt-1">
            Gerenciamento de plantas individuais e madres
          </p>
        </div>
        
        <div className="flex gap-3">
          <Link to={createPageUrl("CultivoNovaPlanta")}>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Nova Planta
            </Button>
          </Link>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="todas">Todas</TabsTrigger>
            <TabsTrigger value="ativas">Ativas</TabsTrigger>
            <TabsTrigger value="madres">Madres</TabsTrigger>
            <TabsTrigger value="colhidas">Colhidas</TabsTrigger>
          </TabsList>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Buscar plantas..."
              className="pl-10 w-full sm:w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        <div className="flex flex-wrap gap-4 pb-4">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-500" />
            <Select
              value={filterPhase}
              onValueChange={setFilterPhase}
            >
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Fase" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as Fases</SelectItem>
                {phaseOptions.map((phase, index) => (
                  <SelectItem key={index} value={phase} className="capitalize">
                    {phase}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-500" />
            <Select
              value={filterStrain}
              onValueChange={setFilterStrain}
            >
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Strain" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as Strains</SelectItem>
                {strainOptions.map((strain, index) => (
                  <SelectItem key={index} value={strain}>
                    {strain}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-500" />
            <Select
              value={filterHealth}
              onValueChange={setFilterHealth}
            >
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Saúde" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Estados</SelectItem>
                {healthOptions.map((health, index) => (
                  <SelectItem key={index} value={health} className="capitalize">
                    {health}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <TabsContent value="todas">
          <PlantasTable plantas={filteredPlantas} isLoading={isLoading} />
        </TabsContent>
        <TabsContent value="ativas">
          <PlantasTable plantas={filteredPlantas} isLoading={isLoading} />
        </TabsContent>
        <TabsContent value="madres">
          <PlantasTable plantas={filteredPlantas} isLoading={isLoading} />
        </TabsContent>
        <TabsContent value="colhidas">
          <PlantasTable plantas={filteredPlantas} isLoading={isLoading} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Componente de tabela de plantas
function PlantasTable({ plantas, isLoading }) {
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
        <p className="ml-2">Carregando plantas...</p>
      </div>
    );
  }
  
  if (plantas.length === 0) {
    return (
      <Card className="w-full p-8 flex flex-col items-center justify-center text-center">
        <Leaf className="h-12 w-12 text-gray-300 mb-4" />
        <h3 className="text-lg font-medium">Nenhuma planta encontrada</h3>
        <p className="text-gray-500 mt-1 max-w-md">
          Não existem plantas correspondentes aos filtros selecionados.
        </p>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Strain</TableHead>
              <TableHead>Fase</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Localização</TableHead>
              <TableHead>Saúde</TableHead>
              <TableHead>Idade</TableHead>
              <TableHead>Altura</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {plantas.map((planta) => {
              // Calcula a idade em dias
              const plantingDate = new Date(planta.planting_date);
              const today = new Date();
              const ageInDays = Math.floor((today - plantingDate) / (1000 * 60 * 60 * 24));
              
              return (
                <TableRow key={planta.id}>
                  <TableCell className="font-medium">
                    <div className="flex flex-col">
                      <span>{planta.plant_id}</span>
                      {planta.batch_id && (
                        <span className="text-xs text-gray-500">
                          Lote: {planta.batch_id}
                        </span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{planta.strain}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      {getPhaseIcon(planta.current_phase)}
                      <span className="ml-2 capitalize">{planta.current_phase}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(planta.status)}>
                      {planta.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{planta.location}</TableCell>
                  <TableCell>
                    <Badge className={getHealthColor(planta.health_status)}>
                      {planta.health_status}
                    </Badge>
                  </TableCell>
                  <TableCell>{ageInDays} dias</TableCell>
                  <TableCell>{planta.height} cm</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Abrir menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Ações</DropdownMenuLabel>
                        <DropdownMenuItem>
                          <Eye className="mr-2 h-4 w-4" />
                          <span>Ver Detalhes</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="mr-2 h-4 w-4" />
                          <span>Editar</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Leaf className="mr-2 h-4 w-4" />
                          <span>Registrar Evento</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Ruler className="mr-2 h-4 w-4" />
                          <span>Atualizar Medidas</span>
                        </DropdownMenuItem>
                        {planta.status === 'ativa' && (
                          <>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Scissors className="mr-2 h-4 w-4" />
                              <span>Iniciar Colheita</span>
                            </DropdownMenuItem>
                          </>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="mr-2 h-4 w-4" />
                          <span>Descartar Planta</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}