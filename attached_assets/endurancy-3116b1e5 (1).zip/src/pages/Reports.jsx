
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Calendar, 
  Download, 
  FileText, 
  Filter, 
  BarChart2, 
  PieChart, 
  LineChart,
  RefreshCw,
  ArrowRight,
  Clock
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart as RechartsLineChart,
  Line,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

// Sample report data
const usageData = [
  { name: 'Jan', ativos: 32, novos: 18 },
  { name: 'Fev', ativos: 45, novos: 12 },
  { name: 'Mar', ativos: 62, novos: 22 },
  { name: 'Abr', ativos: 78, novos: 16 },
  { name: 'Mai', ativos: 91, novos: 14 },
  { name: 'Jun', ativos: 120, novos: 29 },
  { name: 'Jul', ativos: 142, novos: 22 }
];

const organizationTypeData = [
  { name: 'Empresas', value: 35 },
  { name: 'Associações', value: 65 }
];

const planDistributionData = [
  { name: 'Básico', value: 15 },
  { name: 'Pro', value: 20 },
  { name: 'Plus', value: 30 },
  { name: 'Premium', value: 35 }
];

const COLORS = ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0'];

// Sample report list
const availableReports = [
  { 
    id: 1, 
    name: 'Relatório de Crescimento Mensal', 
    description: 'Mostra o crescimento de usuários e organizações ao longo do tempo',
    type: 'user', 
    format: 'pdf', 
    period: 'monthly',
    last_generated: '2023-07-10T14:30:00Z'
  },
  { 
    id: 2, 
    name: 'Resumo de Atividades por Organização', 
    description: 'Análise detalhada de atividades de cada organização',
    type: 'activity', 
    format: 'excel', 
    period: 'monthly',
    last_generated: '2023-07-15T09:45:00Z'
  },
  { 
    id: 3, 
    name: 'Relatório Financeiro', 
    description: 'Receitas e transações financeiras da plataforma',
    type: 'financial', 
    format: 'pdf', 
    period: 'quarterly',
    last_generated: '2023-07-01T16:20:00Z'
  },
  { 
    id: 4, 
    name: 'Auditoria de Acessos', 
    description: 'Registro de logins e atividades de usuários administradores',
    type: 'security', 
    format: 'excel', 
    period: 'weekly',
    last_generated: '2023-07-18T11:10:00Z'
  },
  { 
    id: 5, 
    name: 'Análise de Uso da Plataforma', 
    description: 'Métricas de uso dos diferentes recursos da plataforma',
    type: 'usage', 
    format: 'pdf', 
    period: 'monthly',
    last_generated: '2023-07-05T13:30:00Z'
  }
];

const typeIcons = {
  user: <FileText className="w-4 h-4" />,
  activity: <BarChart2 className="w-4 h-4" />,
  financial: <FileText className="w-4 h-4" />,
  security: <FileText className="w-4 h-4" />,
  usage: <PieChart className="w-4 h-4" />
};

export default function Reports() {
  const [reportPeriod, setReportPeriod] = useState('monthly');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [isGenerating, setIsGenerating] = useState(false);
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const handleGenerateReport = (reportId) => {
    setIsGenerating(true);
    
    // Simulate report generation
    setTimeout(() => {
      setIsGenerating(false);
      alert(`Relatório ${reportId} gerado com sucesso!`);
    }, 2000);
  };

  const filteredReports = availableReports.filter(report => 
    categoryFilter === 'all' || report.type === categoryFilter
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Relatórios</h1>
        <p className="text-gray-500 mt-1">
          Visualize e gere relatórios da plataforma
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: User Growth */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg flex items-center justify-between">
              <span>Crescimento de Usuários</span>
              <Button variant="outline" size="sm" className="h-8 gap-1">
                <Download className="w-3 h-3" />
                Exportar
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsLineChart
                  data={usageData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="ativos" 
                    stroke="#4CAF50" 
                    name="Usuários Ativos" 
                    strokeWidth={2}
                    activeDot={{ r: 8 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="novos" 
                    stroke="#2196F3" 
                    name="Novos Usuários"
                    strokeWidth={2}
                  />
                </RechartsLineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Chart 2: Organization Types */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Tipos de Organizações</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie
                    data={organizationTypeData}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={90}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {organizationTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Chart 3: Plan Distribution */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-lg">Distribuição por Plano</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={planDistributionData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="value" name="Organizações" fill="#4CAF50" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-10">
        <h2 className="text-xl font-semibold mb-4">Relatórios Disponíveis</h2>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center mb-6">
          <div className="flex gap-4 flex-col sm:flex-row w-full sm:w-auto">
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full sm:w-40">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  <SelectValue placeholder="Categoria" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="user">Usuários</SelectItem>
                <SelectItem value="activity">Atividades</SelectItem>
                <SelectItem value="financial">Financeiro</SelectItem>
                <SelectItem value="security">Segurança</SelectItem>
                <SelectItem value="usage">Uso</SelectItem>
              </SelectContent>
            </Select>
            
            <Tabs defaultValue="monthly" className="w-auto" onValueChange={setReportPeriod}>
              <TabsList>
                <TabsTrigger value="weekly">Semanal</TabsTrigger>
                <TabsTrigger value="monthly">Mensal</TabsTrigger>
                <TabsTrigger value="quarterly">Trimestral</TabsTrigger>
                <TabsTrigger value="custom">Personalizado</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
        
        {reportPeriod === 'custom' && (
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="space-y-2 flex-1">
              <label htmlFor="start-date" className="text-sm font-medium">Data Inicial</label>
              <Input
                id="start-date"
                type="date"
                value={dateRange.start}
                onChange={(e) => setDateRange({...dateRange, start: e.target.value})}
              />
            </div>
            <div className="space-y-2 flex-1">
              <label htmlFor="end-date" className="text-sm font-medium">Data Final</label>
              <Input
                id="end-date"
                type="date"
                value={dateRange.end}
                onChange={(e) => setDateRange({...dateRange, end: e.target.value})}
              />
            </div>
          </div>
        )}

        <Card className="shadow-sm">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome do Relatório</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Formato</TableHead>
                <TableHead>Última Geração</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredReports.map((report) => (
                <TableRow key={report.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      {typeIcons[report.type]}
                      {report.name}
                    </div>
                  </TableCell>
                  <TableCell>{report.description}</TableCell>
                  <TableCell className="uppercase">{report.format}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1 text-sm">
                      <Clock className="w-3 h-3 text-gray-400" />
                      {formatDate(report.last_generated)}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="gap-1"
                        onClick={() => handleGenerateReport(report.id)}
                        disabled={isGenerating}
                      >
                        {isGenerating ? (
                          <>
                            <RefreshCw className="w-3 h-3 animate-spin" />
                            Gerando...
                          </>
                        ) : (
                          <>
                            <LineChart className="w-3 h-3" />
                            Gerar
                          </>
                        )}
                      </Button>
                      <Button variant="ghost" size="sm" className="gap-1">
                        <Download className="w-3 h-3" />
                        Baixar
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </div>
    </div>
  );
}
