
import React, { useState, useEffect } from "react";
import { 
  Settings, 
  FileText, 
  Truck, 
  Package, 
  Bell, 
  User, 
  Building2, 
  Plus, 
  Edit, 
  Trash, 
  Power,
  Heart,
  Upload,
  Save,
  Info,
  Flag,
  Globe,
  Phone,
  Mail,
  MapPin,
  DollarSign,
  Calendar,
  Clock,
  HelpCircle,
  MessageSquare,
  MessageCircle,
  Users,
  Briefcase
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { createPageUrl } from "@/utils";

export default function OrgConfiguracoes() {
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("geral");
  
  const [generalSettings, setGeneralSettings] = useState({
    companyName: "Minha Organização",
    cnpj: "12.345.678/0001-90",
    address: "Rua Exemplo, 123 - São Paulo, SP",
    email: "contato@minhaorganizacao.com.br",
    phone: "(11) 1234-5678",
    website: "www.minhaorganizacao.com.br",
    logo: "",
    enableDarkMode: true,
    language: "pt-BR",
    timezone: "America/Sao_Paulo"
  });

  const [fiscalSettings, setFiscalSettings] = useState({
    fiscalRegime: "Simples Nacional",
    stateRegistration: "123456789",
    municipalRegistration: "987654321",
    enabledDocuments: ["nfe", "nfce", "nfse"],
    certificateExpiration: "2024-12-31",
    accountant: "João Silva",
    accountantEmail: "joao.silva@contabilidade.com.br",
    accountantPhone: "(11) 9876-5432"
  });

  const [associadosSettings, setAssociadosSettings] = useState({
    tiposAssociados: [
      { id: "1", nome: "Regular", descricao: "Associado padrão", status: "ativo", valor_anuidade: 120.00, desconto_porcentagem: 0 },
      { id: "2", nome: "Fundador", descricao: "Associado participante da fundação", status: "ativo", valor_anuidade: 100.00, desconto_porcentagem: 20 },
      { id: "3", nome: "Honorário", descricao: "Associado homenageado", status: "ativo", valor_anuidade: 60.00, desconto_porcentagem: 50 },
      { id: "4", nome: "Colaborador", descricao: "Contribui com trabalho voluntário", status: "ativo", valor_anuidade: 90.00, desconto_porcentagem: 25 }
    ],
    permiteCadastroOnline: true,
    requerAprovacao: true,
    documentosObrigatorios: ["rg", "cpf", "comprovante_residencia", "laudo_medico"],
    porcentagemDescontoIsencao: 100,
    criteriosIsencao: "Renda familiar inferior a 2 salários mínimos, análise socioeconômica realizada por assistente social.",
    permiteCadastroPrograma: true,
    nomePrograma: "Programa Acesso Solidário",
    descricaoPrograma: "Programa de assistência social para pessoas de baixa renda",
    metasPrograma: "Atender 200 pessoas por ano",
    relatoriosPeriodicos: true,
    frequenciaRelatorios: "trimestral"
  });

  const [transportadoras, setTransportadoras] = useState([
    { id: "1", nome: "Transportadora 1", ativo: false },
    { id: "2", nome: "Transportadora 2", ativo: true }
  ]);

  const handleTransportadoraToggle = (id, checked) => {
    setTransportadoras(prev => 
      prev.map(t => t.id === id ? {...t, ativo: checked} : t)
    );
  };

  const handleEditTransportadora = (transportadora) => {
    console.log("Editar transportadora", transportadora);
  };

  const [editingType, setEditingType] = useState(null);
  const [currentEditingTypeId, setCurrentEditingTypeId] = useState(null);
  const [showAddTransportadoraDialog, setShowAddTransportadoraDialog] = useState(false);

  const notificationVariables = [
    { name: 'nome', description: 'Nome do destinatário' },
    { name: 'data', description: 'Data atual' },
    { name: 'organizacao', description: 'Nome da organização' },
    { name: 'link', description: 'Link relacionado' }
  ];

  const [notificationTemplates, setNotificationTemplates] = useState([
    { 
      id: 'welcome', 
      nome: 'Boas-vindas', 
      titulo: 'Bem-vindo à {{organizacao}}', 
      conteudo: 'Olá {{nome}}, seja bem-vindo à nossa organização!' 
    },
    { 
      id: 'approval', 
      nome: 'Aprovação de Cadastro', 
      titulo: 'Cadastro Aprovado', 
      conteudo: 'Seu cadastro em {{organizacao}} foi aprovado em {{data}}' 
    }
  ]);

  const [selectedTemplate, setSelectedTemplate] = useState(null);

  const handleSelectTemplate = (templateId) => {
    const template = notificationTemplates.find(t => t.id === templateId);
    setSelectedTemplate(template);
  };

  const handleSaveTemplate = () => {
    if (selectedTemplate) {
      toast({
        title: "Template Salvo",
        description: `Template "${selectedTemplate.nome}" salvo com sucesso.`
      });
    }
  };

  const handleAddAssociateType = () => {
    const newId = (associadosSettings.tiposAssociados.length + 1).toString();
    const newType = {
      id: newId,
      nome: "Novo Tipo",
      descricao: "Descrição do novo tipo",
      status: "ativo",
      valor_anuidade: 100.00,
      desconto_porcentagem: 0
    };
    
    setAssociadosSettings({
      ...associadosSettings,
      tiposAssociados: [...associadosSettings.tiposAssociados, newType]
    });
    
    toast({
      title: "Tipo de associado adicionado",
      description: "Um novo tipo de associado foi adicionado com sucesso."
    });
  };

  const openEditDialog = (type) => {
    setEditingType({ ...type });
    setCurrentEditingTypeId(type.id);
  };

  const handleEditAssociateTypeField = (field, value) => {
    if (editingType) {
      setEditingType(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };

  const saveEditingType = () => {
    if (editingType) {
      setAssociadosSettings(prev => ({
        ...prev,
        tiposAssociados: prev.tiposAssociados.map(type => 
          type.id === editingType.id ? { ...editingType } : type
        )
      }));
      
      toast({
        title: "Tipo de associado atualizado",
        description: "O tipo de associado foi atualizado com sucesso."
      });
      
      setEditingType(null);
      setCurrentEditingTypeId(null);
    }
  };

  const handleRemoveAssociateType = (id) => {
    setAssociadosSettings({
      ...associadosSettings,
      tiposAssociados: associadosSettings.tiposAssociados.filter(type => type.id !== id)
    });
    
    toast({
      title: "Tipo de associado removido",
      description: "O tipo de associado foi removido com sucesso."
    });
  };

  const handleToggleTypeStatus = (id) => {
    const typeToToggle = associadosSettings.tiposAssociados.find(type => type.id === id);
    const newStatus = typeToToggle.status === 'ativo' ? 'inativo' : 'ativo';
    
    setAssociadosSettings({
      ...associadosSettings,
      tiposAssociados: associadosSettings.tiposAssociados.map(type => 
        type.id === id ? { ...type, status: newStatus } : type
      )
    });
    
    toast({
      title: "Status atualizado",
      description: `O tipo de associado foi ${newStatus === 'ativo' ? 'ativado' : 'desativado'} com sucesso.`
    });
  };

  const handleSaveSettings = () => {
    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Configurações salvas",
        description: "Suas configurações foram salvas com sucesso."
      });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Configurações da Organização</h1>
          <p className="text-gray-500">Gerencie as configurações da sua organização</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="geral" className="flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            <span>Geral</span>
          </TabsTrigger>
          <TabsTrigger value="fiscal" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            <span>Fiscal</span>
          </TabsTrigger>
          <TabsTrigger value="associados" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            <span>Associados</span>
          </TabsTrigger>
          <TabsTrigger value="estructura" className="flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            <span>Estrutura</span>
          </TabsTrigger>
          <TabsTrigger value="integracao" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            <span>Integrações</span>
          </TabsTrigger>
          <TabsTrigger value="notificacoes" className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            <span>Notificações</span>
          </TabsTrigger>
          <TabsTrigger value="assistencia" className="flex items-center gap-2">
            <Heart className="w-4 h-4" />
            <span>Assistência Social</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="estructura">
          <Card>
            <CardHeader>
              <CardTitle>Estrutura Organizacional</CardTitle>
              <CardDescription>
                Visualize e gerencie a estrutura organizacional da sua empresa
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <p className="text-sm text-gray-500">
                  Configure a estrutura organizacional da sua empresa para organizar seus departamentos, setores e colaboradores.
                </p>
                <Button variant="outline" onClick={() => window.location.href = createPageUrl('OrgEstrutura')}>
                  Ir para Estrutura Organizacional
                </Button>
              </div>
              
              <div className="border rounded-md p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium">Resumo da Estrutura</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="border rounded-md p-4 flex gap-3 items-center">
                    <Building2 className="h-8 w-8 text-blue-500" />
                    <div>
                      <p className="text-sm text-gray-500">Total de Setores</p>
                      <p className="text-2xl font-bold">3</p>
                    </div>
                  </div>
                  <div className="border rounded-md p-4 flex gap-3 items-center">
                    <Briefcase className="h-8 w-8 text-purple-500" />
                    <div>
                      <p className="text-sm text-gray-500">Total de Departamentos</p>
                      <p className="text-2xl font-bold">8</p>
                    </div>
                  </div>
                  <div className="border rounded-md p-4 flex gap-3 items-center">
                    <Users className="h-8 w-8 text-green-500" />
                    <div>
                      <p className="text-sm text-gray-500">Total de Colaboradores</p>
                      <p className="text-2xl font-bold">45</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="flex justify-end">
                <Button onClick={() => window.location.href = createPageUrl('OrgEstrutura')}>
                  Gerenciar Estrutura Organizacional
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

      </Tabs>

      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} disabled={isLoading}>
          {isLoading ? "Salvando..." : "Salvar Configurações"}
        </Button>
      </div>
    </div>
  );
}
