
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Beaker, 
  Search, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Plus, 
  FileText, 
  Download, 
  Leaf, 
  Calendar, 
  Filter, 
  ArrowUpDown, 
  MoreHorizontal 
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"; 

const mockLabTests = [
  {
    id: "test001",
    test_id: "TE-2023-001",
    batch_id: "L20230510-001",
    lab_name: "CannabLab Análises",
    sample_id: "AM-001-23",
    sample_date: "2023-05-12",
    test_date: "2023-05-15",
    report_date: "2023-05-17",
    test_types: ["potência", "terpenos", "microbiólogico"],
    overall_pass: true,
    strain: "CBD Therapy",
    product_type: "Óleo CBD 5%",
    cannabinoid_profile: {
      thc: 0.2,
      thca: 0.05,
      total_thc: 0.25,
      cbd: 5.1,
      cbda: 0.3,
      total_cbd: 5.4,
      cbn: 0.1,
      cbg: 0.4
    }
  },
  {
    id: "test002",
    test_id: "TE-2023-002",
    batch_id: "L20230522-003",
    lab_name: "CannabLab Análises",
    sample_id: "AM-002-23",
    sample_date: "2023-05-24",
    test_date: "2023-05-26",
    report_date: "2023-05-28",
    test_types: ["potência", "pesticidas", "metais_pesados", "solventes"],
    overall_pass: false,
    strain: "Harlequin",
    product_type: "Flor seca",
    failure_reasons: ["Presença de pesticidas acima do limite permitido"],
    cannabinoid_profile: {
      thc: 0.8,
      thca: 0.2,
      total_thc: 1.0,
      cbd: 8.5,
      cbda: 1.1,
      total_cbd: 9.6,
      cbn: 0.1,
      cbg: 0.5
    }
  },
  {
    id: "test003",
    test_id: "TE-2023-003",
    batch_id: "L20230601-005",
    lab_name: "Phytolab Análises",
    sample_id: "AM-023-PL",
    sample_date: "2023-06-02",
    test_date: "2023-06-05",
    report_date: "2023-06-08",
    test_types: ["completo"],
    overall_pass: true,
    strain: "Charlotte's Web",
    product_type: "Extrato Full Spectrum",
    cannabinoid_profile: {
      thc: 0.1,
      thca: 0.05,
      total_thc: 0.15,
      cbd: 15.2,
      cbda: 0.8,
      total_cbd: 16.0,
      cbn: 0.3,
      cbg: 0.9
    }
  },
  {
    id: "test004",
    test_id: "TE-2023-004",
    batch_id: "L20230615-002",
    lab_name: "CannabLab Análises",
    sample_id: "AM-015-23",
    sample_date: "2023-06-16",
    test_date: "2023-06-19",
    report_date: "2023-06-21",
    test_types: ["potência", "terpenos", "umidade"],
    overall_pass: true,
    strain: "ACDC",
    product_type: "Flor seca",
    cannabinoid_profile: {
      thc: 0.4,
      thca: 0.1,
      total_thc: 0.5,
      cbd: 12.1,
      cbda: 1.3,
      total_cbd: 13.4,
      cbn: 0.1,
      cbg: 0.7
    },
    moisture_content: 8.3
  },
  {
    id: "test005",
    test_id: "TE-2023-005",
    batch_id: "L20230620-007",
    lab_name: "Phytolab Análises",
    sample_id: "AM-045-PL",
    sample_date: "2023-06-22",
    test_date: "2023-06-26",
    report_date: "2023-06-28",
    test_types: ["potência", "pesticidas", "metais_pesados", "microbiólogico"],
    overall_pass: false,
    strain: "Cannatonic",
    product_type: "Óleo CBD 10%",
    failure_reasons: ["Contaminação microbiológica detectada"],
    cannabinoid_profile: {
      thc: 0.3,
      thca: 0.1,
      total_thc: 0.4,
      cbd: 10.5,
      cbda: 0.2,
      total_cbd: 10.7,
      cbn: 0.2,
      cbg: 0.6
    }
  }
];

const tiposTestes = [
  { valor: "potência", label: "Potência (Canabinoides)" },
  { valor: "terpenos", label: "Perfil de Terpenos" },
  { valor: "pesticidas", label: "Pesticidas" },
  { valor: "metais_pesados", label: "Metais Pesados" },
  { valor: "solventes", label: "Solventes Residuais" },
  { valor: "microbiólogico", label: "Microbiológico" },
  { valor: "umidade", label: "Umidade" },
  { valor: "completo", label: "Teste Completo" }
];

export default function CultivoTestes() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [activeTab, setActiveTab] = useState("todos");
  const [isLoading, setIsLoading] = useState(true);
  const [labTests, setLabTests] = useState([]);
  const [selectedTest, setSelectedTest] = useState(null);
  const [showTestDetails, setShowTestDetails] = useState(false);
  const [uploadedDocument, setUploadedDocument] = useState(null);

  useEffect(() => {
    // Simulação de carregamento assíncrono
    const loadData = async () => {
      setIsLoading(true);
      // Simular delay de rede
      await new Promise(resolve => setTimeout(resolve, 800));
      setLabTests(mockLabTests);
      setIsLoading(false);
    };

    loadData();
  }, []);

  const handleDocumentUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setUploadedDocument(file);
    }
  };

  const filteredTests = labTests.filter(test => {
    // Filtro de busca
    const searchMatch = 
      test.test_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      test.batch_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      test.strain.toLowerCase().includes(searchTerm.toLowerCase()) ||
      test.product_type.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filtro de status
    const statusMatch = 
      filterStatus === "all" || 
      (filterStatus === "pass" && test.overall_pass) || 
      (filterStatus === "fail" && !test.overall_pass);
      
    // Filtro de tab
    const tabMatch = 
      activeTab === "todos" || 
      (activeTab === "pendentes" && !test.is_verified) || 
      (activeTab === "verificados" && test.is_verified);
      
    return searchMatch && statusMatch && tabMatch;
  });

  const handleViewDetails = (test) => {
    setSelectedTest(test);
    setShowTestDetails(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Testes Laboratoriais</h1>
          <p className="text-gray-500 mt-1">
            Visualize e gerencie os resultados das análises laboratoriais
          </p>
        </div>
        <div className="flex gap-2">
          <Button asChild>
            <Link to={createPageUrl("CultivoNovoTeste")}>
              <Plus className="h-4 w-4 mr-2" />
              Novo Teste
            </Link>
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div className="flex flex-col md:flex-row gap-4 flex-1">
          <div className="relative md:w-80">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Buscar por ID, lote ou strain..."
              className="pl-8 w-full"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Select
            defaultValue="all"
            onValueChange={setFilterStatus}
          >
            <SelectTrigger className="md:w-[180px]">
              <SelectValue placeholder="Filtrar por status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="pass">Aprovados</SelectItem>
              <SelectItem value="fail">Reprovados</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="todos">Todos os Testes</TabsTrigger>
          <TabsTrigger value="pendentes">Pendentes de Verificação</TabsTrigger>
          <TabsTrigger value="verificados">Verificados</TabsTrigger>
        </TabsList>
        
        <TabsContent value="todos" className="mt-4">
          {isLoading ? (
            <div className="flex justify-center py-10">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500"></div>
            </div>
          ) : filteredTests.length === 0 ? (
            <div className="text-center py-10 border rounded-lg">
              <Beaker className="h-12 w-12 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium">Nenhum teste encontrado</h3>
              <p className="text-gray-500">Tente ajustar seus filtros ou adicione um novo teste</p>
            </div>
          ) : (
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID do Teste</TableHead>
                    <TableHead>Lote</TableHead>
                    <TableHead>Produto / Strain</TableHead>
                    <TableHead>Data do Teste</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Resultado</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTests.map((test) => (
                    <TableRow key={test.id}>
                      <TableCell className="font-medium">{test.test_id}</TableCell>
                      <TableCell>{test.batch_id}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{test.product_type}</div>
                          <div className="text-gray-500 text-sm">{test.strain}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {new Date(test.test_date).toLocaleDateString('pt-BR')}
                      </TableCell>
                      <TableCell>
                        {test.test_types.includes('completo') ? (
                          <Badge variant="outline">Completo</Badge>
                        ) : (
                          <Badge variant="outline">{`${test.test_types.length} tipos`}</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {test.overall_pass ? (
                          <Badge className="bg-green-100 text-green-800">Aprovado</Badge>
                        ) : (
                          <Badge className="bg-red-100 text-red-800">Reprovado</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewDetails(test)}>
                              Ver detalhes
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link to="#">Baixar relatório</Link>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>Verificar teste</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="pendentes" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Testes Pendentes de Verificação</CardTitle>
              <CardDescription>
                Testes que aguardam sua verificação e aprovação
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-10">
                <Beaker className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium">Nenhum teste pendente</h3>
                <p className="text-gray-500">Todos os testes foram verificados</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="verificados" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Testes Verificados</CardTitle>
              <CardDescription>
                Testes que já foram verificados pela equipe
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-10">
                <CheckCircle2 className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium">Nenhum teste verificado</h3>
                <p className="text-gray-500">Verifique seus testes pendentes</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div className="md:w-80">
          <Label htmlFor="document-upload" className="block mb-2">Upload de Documentos:</Label>
          <Input type="file" id="document-upload" onChange={handleDocumentUpload} />
        </div>
      </div>

      {/* Dialog de Detalhes do Teste */}
      <Dialog open={showTestDetails} onOpenChange={setShowTestDetails}>
        <DialogContent className="max-w-4xl">
          {selectedTest && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-green-600" />
                  Teste Laboratorial: {selectedTest.test_id}
                </DialogTitle>
                <DialogDescription>
                  Detalhes completos dos resultados laboratoriais
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Informações Gerais</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">ID do Teste:</span>
                      <span className="font-medium">{selectedTest.test_id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Lote:</span>
                      <span className="font-medium">{selectedTest.batch_id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Produto:</span>
                      <span className="font-medium">{selectedTest.product_type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Strain:</span>
                      <span className="font-medium">{selectedTest.strain}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Laboratório:</span>
                      <span className="font-medium">{selectedTest.lab_name}</span>
                    </div>
                  </div>

                  <h3 className="text-sm font-medium text-gray-500 mt-6 mb-2">Datas</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Amostragem:</span>
                      <span className="font-medium">{new Date(selectedTest.sample_date).toLocaleDateString('pt-BR')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Análise:</span>
                      <span className="font-medium">{new Date(selectedTest.test_date).toLocaleDateString('pt-BR')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Relatório:</span>
                      <span className="font-medium">{new Date(selectedTest.report_date).toLocaleDateString('pt-BR')}</span>
                    </div>
                  </div>

                  <h3 className="text-sm font-medium text-gray-500 mt-6 mb-2">Tipos de Testes Realizados</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedTest.test_types.map((type, index) => (
                      <Badge key={index} variant="outline" className="text-sm">
                        {tiposTestes.find(t => t.valor === type)?.label || type}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="mt-6">
                    <span className="text-sm font-medium text-gray-500">Resultado Final:</span>
                    <div className="mt-2">
                      {selectedTest.overall_pass ? (
                        <Badge className="bg-green-100 text-green-800">Aprovado</Badge>
                      ) : (
                        <Badge className="bg-red-100 text-red-800">Reprovado</Badge>
                      )}
                    </div>
                    
                    {!selectedTest.overall_pass && selectedTest.failure_reasons && (
                      <div className="mt-4">
                        <span className="text-sm font-medium text-gray-500">Motivos da Reprovação:</span>
                        <ul className="mt-2 text-sm text-red-600 pl-5 list-disc">
                          {selectedTest.failure_reasons.map((reason, idx) => (
                            <li key={idx}>{reason}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Perfil de Canabinoides</h3>
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">THC:</span>
                          <span className="font-medium">{selectedTest.cannabinoid_profile.thc}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">THCA:</span>
                          <span className="font-medium">{selectedTest.cannabinoid_profile.thca}%</span>
                        </div>
                        <div className="flex justify-between bg-green-50 p-1 rounded">
                          <span className="text-sm font-medium">Total THC:</span>
                          <span className="font-bold">{selectedTest.cannabinoid_profile.total_thc}%</span>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">CBD:</span>
                          <span className="font-medium">{selectedTest.cannabinoid_profile.cbd}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">CBDA:</span>
                          <span className="font-medium">{selectedTest.cannabinoid_profile.cbda}%</span>
                        </div>
                        <div className="flex justify-between bg-green-50 p-1 rounded">
                          <span className="text-sm font-medium">Total CBD:</span>
                          <span className="font-bold">{selectedTest.cannabinoid_profile.total_cbd}%</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-2 mt-4">
                      <div className="flex justify-between">
                        <span className="text-sm">CBN:</span>
                        <span className="font-medium">{selectedTest.cannabinoid_profile.cbn}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">CBG:</span>
                        <span className="font-medium">{selectedTest.cannabinoid_profile.cbg}%</span>
                      </div>
                      
                      {selectedTest.moisture_content && (
                        <div className="flex justify-between mt-4">
                          <span className="text-sm">Umidade:</span>
                          <span className="font-medium">{selectedTest.moisture_content}%</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <Button className="w-full" asChild>
                      <Link to="#">
                        <Download className="h-4 w-4 mr-2" />
                        Baixar Relatório Completo (PDF)
                      </Link>
                    </Button>
                  </div>
                  
                  <div className="mt-4 p-4 border rounded-lg bg-gray-50">
                    <h3 className="text-sm font-medium mb-2">Código QR para Verificação</h3>
                    <div className="w-32 h-32 bg-white border flex items-center justify-center mx-auto">
                      <div className="text-xs text-gray-400 text-center">QR Code do Relatório</div>
                    </div>
                    <p className="text-xs text-center text-gray-500 mt-2">
                      Escaneie para verificar a autenticidade do relatório
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
