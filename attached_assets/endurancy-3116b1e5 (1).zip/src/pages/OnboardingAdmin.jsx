import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  GraduationCap,
  Users,
  BarChart,
  Clock,
  ArrowUp,
  ArrowDown,
  CheckCircle,
  XCircle,
  AlertTriangle
} from 'lucide-react';

export default function OnboardingAdmin() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    completionRate: 0,
    activeModules: 0,
    avgCompletionTime: 0
  });

  const [recentActivity, setRecentActivity] = useState([]);
  const [moduleStats, setModuleStats] = useState([]);

  useEffect(() => {
    // Mock data for demonstration
    setStats({
      totalUsers: 1250,
      completionRate: 68,
      activeModules: 8,
      avgCompletionTime: 45
    });

    setModuleStats([
      { name: 'Introdução', completion: 85, users: 1200 },
      { name: 'Cultivo', completion: 72, users: 800 },
      { name: 'Produção', completion: 65, users: 750 },
      { name: 'Dispensário', completion: 58, users: 600 },
      { name: 'Pacientes', completion: 70, users: 900 }
    ]);

    setRecentActivity([
      { 
        user: 'João Silva',
        action: 'completed',
        module: 'Introdução',
        time: '2h atrás'
      },
      {
        user: 'Maria Santos',
        action: 'started',
        module: 'Cultivo',
        time: '3h atrás'
      },
      // ... more activities
    ]);
  }, []);

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Dashboard de Onboarding</h1>
          <p className="text-gray-500 mt-1">
            Visão geral do progresso e engajamento dos usuários
          </p>
        </div>
        <Button>Exportar Relatório</Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Usuários</CardTitle>
            <Users className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers}</div>
            <p className="text-xs text-gray-500">+12% em relação ao mês anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Conclusão</CardTitle>
            <CheckCircle className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.completionRate}%</div>
            <Progress value={stats.completionRate} className="h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Módulos Ativos</CardTitle>
            <GraduationCap className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeModules}</div>
            <p className="text-xs text-gray-500">2 novos módulos este mês</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tempo Médio de Conclusão</CardTitle>
            <Clock className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgCompletionTime} min</div>
            <p className="text-xs text-gray-500">-5 min em relação à média anterior</p>
          </CardContent>
        </Card>
      </div>

      {/* Module Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Progresso por Módulo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {moduleStats.map((module) => (
              <div key={module.name} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>{module.name}</span>
                  <span className="text-gray-500">{module.completion}% ({module.users} usuários)</span>
                </div>
                <Progress value={module.completion} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Atividade Recente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-center justify-between py-2">
                <div className="flex items-center gap-2">
                  <Badge variant={activity.action === 'completed' ? 'success' : 'default'}>
                    {activity.action === 'completed' ? 'Concluído' : 'Iniciado'}
                  </Badge>
                  <span className="font-medium">{activity.user}</span>
                  <span className="text-gray-500">{activity.module}</span>
                </div>
                <span className="text-sm text-gray-500">{activity.time}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}