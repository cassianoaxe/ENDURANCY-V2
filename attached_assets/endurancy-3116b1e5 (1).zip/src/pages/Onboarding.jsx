import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  GraduationCap,
  PlayCircle,
  CheckCircle,
  BookOpen,
  Leaf,
  Factory,
  ShoppingBag,
  Users,
  FileText,
  Settings,
  Heart,
  Scale,
  DollarSign,
  ArrowRight,
  Clock,
  AlertCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import ModuleContent from '../components/onboarding/ModuleContent';

const modules = [
  {
    id: 'getting-started',
    title: 'Começando',
    description: 'Introdução à plataforma e conceitos básicos',
    icon: GraduationCap,
    duration: '10 min',
    progress: 0,
    lessons: [
      {
        id: 'platform-overview',
        title: 'Visão Geral da Plataforma',
        type: 'video',
        duration: '3 min',
        completed: false
      },
      {
        id: 'navigation',
        title: 'Navegação e Interface',
        type: 'text',
        duration: '2 min',
        completed: false
      },
      {
        id: 'first-steps',
        title: 'Primeiros Passos',
        type: 'interactive',
        duration: '5 min',
        completed: false
      }
    ]
  },
  {
    id: 'cultivation',
    title: 'Módulo Cultivo',
    description: 'Gestão completa do processo de cultivo',
    icon: Leaf,
    duration: '25 min',
    progress: 0,
    lessons: [
      {
        id: 'cultivation-dashboard',
        title: 'Dashboard de Cultivo',
        type: 'video',
        duration: '5 min',
        completed: false
      },
      {
        id: 'plant-management',
        title: 'Gestão de Plantas',
        type: 'interactive',
        duration: '10 min',
        completed: false
      },
      {
        id: 'batch-tracking',
        title: 'Rastreamento de Lotes',
        type: 'text',
        duration: '5 min',
        completed: false
      },
      {
        id: 'quality-control',
        title: 'Controle de Qualidade',
        type: 'video',
        duration: '5 min',
        completed: false
      }
    ]
  },
  {
    id: 'production',
    title: 'Módulo Produção',
    description: 'Controle do processo produtivo',
    icon: Factory,
    duration: '30 min',
    progress: 0,
    lessons: [
      {
        id: 'production-flow',
        title: 'Fluxo de Produção',
        type: 'video',
        duration: '8 min',
        completed: false
      },
      {
        id: 'quality-management',
        title: 'Gestão da Qualidade',
        type: 'interactive',
        duration: '12 min',
        completed: false
      },
      {
        id: 'inventory-control',
        title: 'Controle de Estoque',
        type: 'text',
        duration: '10 min',
        completed: false
      }
    ]
  },
  {
    id: 'dispensary',
    title: 'Dispensário',
    description: 'Gerenciamento de dispensário e ponto de venda',
    icon: ShoppingBag,
    duration: '20 min',
    progress: 0,
    lessons: [
      {
        id: 'dispensary-dashboard',
        title: 'Dashboard do Dispensário',
        type: 'video',
        duration: '4 min',
        completed: false
      },
      {
        id: 'pdv',
        title: 'Ponto de Venda (PDV)',
        type: 'interactive',
        duration: '8 min',
        completed: false
      },
      {
        id: 'inventory-management',
        title: 'Gestão de Estoque',
        type: 'text',
        duration: '4 min',
        completed: false
      },
      {
        id: 'prescriptions',
        title: 'Gestão de Receituário',
        type: 'video',
        duration: '4 min',
        completed: false
      }
    ]
  },
  {
    id: 'patients',
    title: 'Gestão de Pacientes/Associados',
    description: 'Administração de pacientes, clientes ou associados',
    icon: Users,
    duration: '15 min',
    progress: 0,
    lessons: [
      {
        id: 'patient-registration',
        title: 'Cadastro de Pacientes',
        type: 'video',
        duration: '5 min',
        completed: false
      },
      {
        id: 'document-management',
        title: 'Gestão de Documentos',
        type: 'text',
        duration: '3 min',
        completed: false
      },
      {
        id: 'prescription-management',
        title: 'Gestão de Prescrições',
        type: 'interactive',
        duration: '7 min',
        completed: false
      }
    ]
  },
  {
    id: 'financial',
    title: 'Módulo Financeiro',
    description: 'Controle financeiro e gestão contábil',
    icon: DollarSign,
    duration: '25 min',
    progress: 0,
    lessons: [
      {
        id: 'financial-dashboard',
        title: 'Dashboard Financeiro',
        type: 'video',
        duration: '5 min',
        completed: false
      },
      {
        id: 'accounts-payable',
        title: 'Contas a Pagar',
        type: 'text',
        duration: '5 min',
        completed: false
      },
      {
        id: 'accounts-receivable',
        title: 'Contas a Receber',
        type: 'text',
        duration: '5 min',
        completed: false
      },
      {
        id: 'financial-reports',
        title: 'Relatórios Financeiros',
        type: 'interactive',
        duration: '10 min',
        completed: false
      }
    ]
  },
  {
    id: 'legal',
    title: 'Módulo Jurídico',
    description: 'Gerenciamento legal e compliance',
    icon: Scale,
    duration: '20 min',
    progress: 0,
    lessons: [
      {
        id: 'legal-dashboard',
        title: 'Dashboard Jurídico',
        type: 'video',
        duration: '4 min',
        completed: false
      },
      {
        id: 'legal-cases',
        title: 'Ações Judiciais',
        type: 'text',
        duration: '4 min',
        completed: false
      },
      {
        id: 'legal-documents',
        title: 'Documentos Jurídicos',
        type: 'text',
        duration: '4 min',
        completed: false
      },
      {
        id: 'compliance',
        title: 'Compliance',
        type: 'interactive',
        duration: '8 min',
        completed: false
      }
    ]
  },
  {
    id: 'tasks',
    title: 'Gestão de Tarefas',
    description: 'Organização e acompanhamento de tarefas',
    icon: CheckCircle,
    duration: '15 min',
    progress: 0,
    lessons: [
      {
        id: 'tasks-basics',
        title: 'Fundamentos da Gestão de Tarefas',
        type: 'video',
        duration: '4 min',
        completed: false
      },
      {
        id: 'kanban-board',
        title: 'Quadro Kanban',
        type: 'interactive',
        duration: '5 min',
        completed: false
      },
      {
        id: 'task-assignments',
        title: 'Atribuição e Acompanhamento',
        type: 'text',
        duration: '3 min',
        completed: false
      },
      {
        id: 'task-reports',
        title: 'Relatórios de Produtividade',
        type: 'text',
        duration: '3 min',
        completed: false
      }
    ]
  }
];

export default function Onboarding() {
  const [selectedModule, setSelectedModule] = useState(null);
  const [completedLessons, setCompletedLessons] = useState({});

  const handleLessonComplete = (moduleId, lessonId) => {
    setCompletedLessons(prev => ({
      ...prev,
      [`${moduleId}-${lessonId}`]: true
    }));
  };

  const calculateModuleProgress = (moduleId) => {
    const module = modules.find(m => m.id === moduleId);
    if (!module) return 0;

    const totalLessons = module.lessons.length;
    const completed = module.lessons.filter(lesson => 
      completedLessons[`${moduleId}-${lesson.id}`]
    ).length;

    return (completed / totalLessons) * 100;
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Onboarding</h1>
          <p className="text-gray-500 mt-1">
            Aprenda a utilizar todos os recursos da plataforma
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            Total: 3h 20min
          </Badge>
          <Button variant="outline" className="flex items-center gap-2">
            <BookOpen className="w-4 h-4" />
            Guia Completo (PDF)
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {modules.map((module) => (
          <Card key={module.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <module.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{module.title}</CardTitle>
                    <CardDescription>{module.description}</CardDescription>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {module.duration}
                  </span>
                  <span>{calculateModuleProgress(module.id)}% completo</span>
                </div>
                
                <Progress value={calculateModuleProgress(module.id)} />
                
                <Button 
                  className="w-full mt-4"
                  onClick={() => setSelectedModule(module)}
                  variant="outline"
                >
                  {calculateModuleProgress(module.id) === 0 ? 'Começar' : 'Continuar'}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedModule && (
        <ModuleContent 
          module={selectedModule}
          onLessonComplete={handleLessonComplete}
          completedLessons={completedLessons}
          onClose={() => setSelectedModule(null)}
        />
      )}
    </div>
  );
}