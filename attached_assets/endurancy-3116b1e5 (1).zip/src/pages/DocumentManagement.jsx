
import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Search, 
  Filter, 
  Upload, 
  Download, 
  Eye, 
  Trash2, 
  Edit, 
  Clock, 
  Plus,
  Calendar,
  Tag,
  MoreHorizontal,
  Lock,
  Users,
  AlertTriangle,
  CheckCircle2,
  History,
  ArrowUpDown,
  FolderPlus,
  Folder,
  Shield,
  Activity,
  Star,
  StarOff,
  Share2,
  FileInput,
  ChevronDown,
  ChevronUp,
  SlidersHorizontal,
  Copy,
  Grid,
  List,
  Info,
  Archive,
  RefreshCw,
  MessageSquare,
  XCircle
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Organization } from "@/api/entities";
import { User } from "@/api/entities";
import { Document } from "@/api/entities";
import { DocumentActivity } from "@/api/entities";
import { DocumentComment } from "@/api/entities";
import { DocumentCategory } from "@/api/entities";
import { toast } from "@/components/ui/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogClose
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { 
  Pagination, 
  PaginationContent, 
  PaginationEllipsis, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from "@/components/ui/pagination";
import { UploadFile } from "@/api/integrations";

const ITEMS_PER_PAGE = 10;

// Mapping of file types to colors and icons
const fileTypeMap = {
  'application/pdf': { color: 'bg-red-100 text-red-700', icon: FileText },
  'application/msword': { color: 'bg-blue-100 text-blue-700', icon: FileText },
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { color: 'bg-blue-100 text-blue-700', icon: FileText },
  'application/vnd.ms-excel': { color: 'bg-green-100 text-green-700', icon: FileText },
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': { color: 'bg-green-100 text-green-700', icon: FileText },
  'application/vnd.ms-powerpoint': { color: 'bg-orange-100 text-orange-700', icon: FileText },
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': { color: 'bg-orange-100 text-orange-700', icon: FileText },
  'image/jpeg': { color: 'bg-purple-100 text-purple-700', icon: FileInput },
  'image/png': { color: 'bg-purple-100 text-purple-700', icon: FileInput },
  'text/plain': { color: 'bg-gray-100 text-gray-700', icon: FileText },
  'application/zip': { color: 'bg-yellow-100 text-yellow-700', icon: Archive },
  'default': { color: 'bg-gray-100 text-gray-700', icon: FileText }
};

// Default document categories
const defaultCategories = [
  { id: 'legal', name: 'Documentos Legais', color: '#4F46E5', icon: 'Shield' },
  { id: 'financial', name: 'Documentos Financeiros', color: '#10B981', icon: 'DollarSign' },
  { id: 'compliance', name: 'Compliance', color: '#F59E0B', icon: 'CheckSquare' },
  { id: 'operations', name: 'Operações', color: '#3B82F6', icon: 'Settings' },
  { id: 'regulatory', name: 'Regulatório', color: '#EF4444', icon: 'Scale' },
  { id: 'strategic', name: 'Documentos Estratégicos', color: '#8B5CF6', icon: 'Target' },
  { id: 'human_resources', name: 'Recursos Humanos', color: '#EC4899', icon: 'Users' },
  { id: 'marketing', name: 'Marketing', color: '#F97316', icon: 'PieChart' },
  { id: 'technical', name: 'Documentos Técnicos', color: '#6366F1', icon: 'FileCode' },
  { id: 'other', name: 'Outros', color: '#9CA3AF', icon: 'File' }
];

// Document classifications with colors
const classificationColors = {
  'public': 'bg-green-100 text-green-800',
  'internal': 'bg-blue-100 text-blue-800',
  'confidential': 'bg-amber-100 text-amber-800',
  'restricted': 'bg-red-100 text-red-800'
};

const DocumentManagement = () => {
  // State for organization and user data
  const [organization, setOrganization] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // State for documents, categories, and activities
  const [documents, setDocuments] = useState([]);
  const [categories, setCategories] = useState([]);
  const [recentActivities, setRecentActivities] = useState([]);
  
  // UI state
  const [activeTab, setActiveTab] = useState("all");
  const [viewMode, setViewMode] = useState("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedClassification, setSelectedClassification] = useState("all");
  const [sortField, setSortField] = useState("updated_date");
  const [sortDirection, setSortDirection] = useState("desc");
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  
  // New document state
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [newDocument, setNewDocument] = useState({
    title: '',
    description: '',
    category: 'other',
    tags: [],
    classification: 'internal',
    visibility: 'organization',
    access_roles: ['admin'],
    file: null
  });
  const [tagInput, setTagInput] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  
  // Document details state
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [documentComments, setDocumentComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  
  // File upload ref
  const fileInputRef = useRef(null);
  
  useEffect(() => {
    loadData();
  }, []);
  
  useEffect(() => {
    if (documents.length > 0) {
      applyFiltersAndSort();
    }
  }, [searchQuery, selectedCategory, selectedStatus, selectedClassification, sortField, sortDirection, currentPage]);
  
  const loadData = async () => {
    try {
      setIsLoading(true);
      
      // Get current user
      const user = await User.me();
      setCurrentUser(user);
      
      // Get organization
      const orgs = await Organization.filter({ id: user.organization_id });
      if (orgs.length > 0) {
        setOrganization(orgs[0]);
        
        // Load documents
        const docsData = await Document.filter({ organization_id: orgs[0].id });
        setDocuments(docsData || []);
        
        // Load categories
        const categoriesData = await DocumentCategory.filter({ organization_id: orgs[0].id });
        
        if (categoriesData.length === 0) {
          // Create default categories if none exist
          const defaultCategoriesPromises = defaultCategories.map(cat => 
            DocumentCategory.create({
              organization_id: orgs[0].id,
              name: cat.name,
              color: cat.color,
              icon: cat.icon,
              is_default: true
            })
          );
          
          const createdCategories = await Promise.all(defaultCategoriesPromises);
          setCategories(createdCategories);
        } else {
          setCategories(categoriesData);
        }
        
        // Load recent activities
        const activitiesData = await DocumentActivity.filter(
          { organization_id: orgs[0].id },
          "-created_date",
          10
        );
        setRecentActivities(activitiesData || []);
      }
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
      toast({
        title: "Erro ao carregar dados",
        description: "Ocorreu um erro ao carregar os documentos e categorias.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const applyFiltersAndSort = () => {
    let filteredDocs = [...documents];
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filteredDocs = filteredDocs.filter(doc => 
        doc.title.toLowerCase().includes(query) || 
        (doc.description && doc.description.toLowerCase().includes(query)) ||
        (doc.tags && doc.tags.some(tag => tag.toLowerCase().includes(query)))
      );
    }
    
    // Apply category filter
    if (selectedCategory !== "all") {
      filteredDocs = filteredDocs.filter(doc => doc.category === selectedCategory);
    }
    
    // Apply status filter
    if (selectedStatus !== "all") {
      filteredDocs = filteredDocs.filter(doc => doc.status === selectedStatus);
    }
    
    // Apply classification filter
    if (selectedClassification !== "all") {
      filteredDocs = filteredDocs.filter(doc => doc.classification === selectedClassification);
    }
    
    // Apply tab filter
    if (activeTab === "favorites") {
      // This would need a "favorites" field in the document entity or a separate user favorites entity
      // For now, we'll just show all documents
    } else if (activeTab === "recent") {
      // Sort by updated_date desc and take the first 20
      filteredDocs = filteredDocs.sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date)).slice(0, 20);
    } else if (activeTab === "shared") {
      // Show documents shared with the user
      filteredDocs = filteredDocs.filter(doc => 
        doc.visibility === "organization" || 
        (doc.access_users && doc.access_users.includes(currentUser.id))
      );
    }
    
    // Apply sorting
    filteredDocs = filteredDocs.sort((a, b) => {
      if (sortField === "title") {
        return sortDirection === "asc" 
          ? a.title.localeCompare(b.title) 
          : b.title.localeCompare(a.title);
      } else if (sortField === "created_date" || sortField === "updated_date") {
        return sortDirection === "asc" 
          ? new Date(a[sortField]) - new Date(b[sortField]) 
          : new Date(b[sortField]) - new Date(a[sortField]);
      }
      return 0;
    });
    
    // Apply pagination
    const totalItems = filteredDocs.length;
    setTotalPages(Math.ceil(totalItems / ITEMS_PER_PAGE));
    
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    const paginatedDocs = filteredDocs.slice(startIndex, startIndex + ITEMS_PER_PAGE);
    
    return paginatedDocs;
  };
  
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setNewDocument({
        ...newDocument,
        file,
        title: file.name.split('.')[0], // Set default title to filename without extension
      });
    }
  };
  
  const addTag = () => {
    if (tagInput.trim() && !newDocument.tags.includes(tagInput.trim())) {
      setNewDocument({
        ...newDocument,
        tags: [...newDocument.tags, tagInput.trim()]
      });
      setTagInput('');
    }
  };
  
  const removeTag = (tagToRemove) => {
    setNewDocument({
      ...newDocument,
      tags: newDocument.tags.filter(tag => tag !== tagToRemove)
    });
  };
  
  const handleUploadDocument = async () => {
    try {
      if (!newDocument.file) {
        toast({
          title: "Arquivo obrigatório",
          description: "Por favor, selecione um arquivo para upload.",
          variant: "destructive"
        });
        return;
      }
      
      if (!newDocument.title) {
        toast({
          title: "Título obrigatório",
          description: "Por favor, forneça um título para o documento.",
          variant: "destructive"
        });
        return;
      }
      
      setIsUploading(true);
      
      // Upload file
      const { file_url } = await UploadFile({ file: newDocument.file });
      
      // Create document record
      const documentData = {
        organization_id: organization.id,
        title: newDocument.title,
        description: newDocument.description || '',
        file_url,
        file_name: newDocument.file.name,
        file_type: newDocument.file.type,
        file_size: newDocument.file.size,
        category: newDocument.category,
        tags: newDocument.tags,
        version: 1,
        status: 'published',
        visibility: newDocument.visibility,
        access_roles: newDocument.access_roles,
        classification: newDocument.classification,
        effective_date: new Date().toISOString().split('T')[0]
      };
      
      const createdDocument = await Document.create(documentData);
      
      // Record activity
      await DocumentActivity.create({
        document_id: createdDocument.id,
        organization_id: organization.id,
        user_id: currentUser.id,
        activity_type: 'created',
        details: `Documento "${createdDocument.title}" foi criado`
      });
      
      // Reset form and close dialog
      setNewDocument({
        title: '',
        description: '',
        category: 'other',
        tags: [],
        classification: 'internal',
        visibility: 'organization',
        access_roles: ['admin'],
        file: null
      });
      setIsUploadDialogOpen(false);
      
      // Refresh data
      loadData();
      
      toast({
        title: "Documento enviado com sucesso",
        description: "O documento foi adicionado ao sistema CDI.",
      });
    } catch (error) {
      console.error("Erro ao fazer upload do documento:", error);
      toast({
        title: "Erro ao fazer upload",
        description: "Ocorreu um erro ao fazer upload do documento. Por favor, tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  const handleViewDocument = async (doc) => {
    try {
      setSelectedDocument(doc);
      
      // Record view activity
      await DocumentActivity.create({
        document_id: doc.id,
        organization_id: organization.id,
        user_id: currentUser.id,
        activity_type: 'viewed',
        details: `Documento "${doc.title}" foi visualizado`
      });
      
      // Load document comments
      const commentsData = await DocumentComment.filter(
        { document_id: doc.id },
        "-created_date"
      );
      setDocumentComments(commentsData || []);
      
      setIsDetailsDialogOpen(true);
    } catch (error) {
      console.error("Erro ao visualizar documento:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao abrir os detalhes do documento.",
        variant: "destructive"
      });
    }
  };
  
  const handleDownloadDocument = async (doc) => {
    try {
      // Record download activity
      await DocumentActivity.create({
        document_id: doc.id,
        organization_id: organization.id,
        user_id: currentUser.id,
        activity_type: 'downloaded',
        details: `Documento "${doc.title}" foi baixado`
      });
      
      // Open document in new tab
      window.open(doc.file_url, '_blank');
      
      toast({
        title: "Download iniciado",
        description: "O download do documento foi iniciado em uma nova aba.",
      });
    } catch (error) {
      console.error("Erro ao baixar documento:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao baixar o documento.",
        variant: "destructive"
      });
    }
  };
  
  const handleAddComment = async () => {
    try {
      if (!newComment.trim() || !selectedDocument) return;
      
      const commentData = {
        document_id: selectedDocument.id,
        organization_id: organization.id,
        user_id: currentUser.id,
        content: newComment.trim()
      };
      
      const createdComment = await DocumentComment.create(commentData);
      
      // Add comment to local state
      setDocumentComments([createdComment, ...documentComments]);
      setNewComment('');
      
      // Record activity
      await DocumentActivity.create({
        document_id: selectedDocument.id,
        organization_id: organization.id,
        user_id: currentUser.id,
        activity_type: 'commented',
        details: `Comentário adicionado ao documento "${selectedDocument.title}"`
      });
    } catch (error) {
      console.error("Erro ao adicionar comentário:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao adicionar o comentário.",
        variant: "destructive"
      });
    }
  };
  
  const handleArchiveDocument = async (doc) => {
    try {
      await Document.update(doc.id, { ...doc, status: 'archived' });
      
      // Record activity
      await DocumentActivity.create({
        document_id: doc.id,
        organization_id: organization.id,
        user_id: currentUser.id,
        activity_type: 'status_changed',
        details: `Documento "${doc.title}" foi arquivado`,
        previous_value: doc.status,
        new_value: 'archived'
      });
      
      // Refresh data
      loadData();
      
      // Close details dialog if open
      if (isDetailsDialogOpen && selectedDocument && selectedDocument.id === doc.id) {
        setIsDetailsDialogOpen(false);
      }
      
      toast({
        title: "Documento arquivado",
        description: "O documento foi arquivado com sucesso.",
      });
    } catch (error) {
      console.error("Erro ao arquivar documento:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao arquivar o documento.",
        variant: "destructive"
      });
    }
  };
  
  const handleRestoreDocument = async (doc) => {
    try {
      await Document.update(doc.id, { ...doc, status: 'published' });
      
      // Record activity
      await DocumentActivity.create({
        document_id: doc.id,
        organization_id: organization.id,
        user_id: currentUser.id,
        activity_type: 'status_changed',
        details: `Documento "${doc.title}" foi restaurado`,
        previous_value: doc.status,
        new_value: 'published'
      });
      
      // Refresh data
      loadData();
      
      toast({
        title: "Documento restaurado",
        description: "O documento foi restaurado com sucesso.",
      });
    } catch (error) {
      console.error("Erro ao restaurar documento:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao restaurar o documento.",
        variant: "destructive"
      });
    }
  };
  
  const handleDeleteDocument = async (doc) => {
    try {
      if (confirm(`Tem certeza que deseja excluir permanentemente o documento "${doc.title}"?`)) {
        await Document.delete(doc.id);
        
        // Record activity
        await DocumentActivity.create({
          document_id: doc.id,
          organization_id: organization.id,
          user_id: currentUser.id,
          activity_type: 'deleted',
          details: `Documento "${doc.title}" foi excluído permanentemente`
        });
        
        // Refresh data
        loadData();
        
        // Close details dialog if open
        if (isDetailsDialogOpen && selectedDocument && selectedDocument.id === doc.id) {
          setIsDetailsDialogOpen(false);
        }
        
        toast({
          title: "Documento excluído",
          description: "O documento foi excluído permanentemente.",
        });
      }
    } catch (error) {
      console.error("Erro ao excluir documento:", error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao excluir o documento.",
        variant: "destructive"
      });
    }
  };
  
  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' bytes';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(2) + ' KB';
    else return (bytes / 1048576).toFixed(2) + ' MB';
  };
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  const getDocumentTypeIcon = (fileType) => {
    const typeInfo = fileTypeMap[fileType] || fileTypeMap['default'];
    const IconComponent = typeInfo.icon;
    return (
      <div className={`p-2 rounded-lg ${typeInfo.color}`}>
        <IconComponent className="w-5 h-5" />
      </div>
    );
  };
  
  const getCategoryById = (categoryId) => {
    return categories.find(cat => cat.id === categoryId) || 
           defaultCategories.find(cat => cat.id === categoryId) || 
           { name: 'Outro', color: '#9CA3AF' };
  };
  
  const getStatusBadge = (status) => {
    switch(status) {
      case 'draft':
        return <Badge className="bg-gray-100 text-gray-800">Rascunho</Badge>;
      case 'published':
        return <Badge className="bg-green-100 text-green-800">Publicado</Badge>;
      case 'archived':
        return <Badge className="bg-amber-100 text-amber-800">Arquivado</Badge>;
      case 'obsolete':
        return <Badge className="bg-red-100 text-red-800">Obsoleto</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  const getClassificationBadge = (classification) => {
    return (
      <Badge className={classificationColors[classification] || 'bg-gray-100 text-gray-800'}>
        {classification === 'public' && 'Público'}
        {classification === 'internal' && 'Interno'}
        {classification === 'confidential' && 'Confidencial'}
        {classification === 'restricted' && 'Restrito'}
      </Badge>
    );
  };
  
  const renderDocumentGrid = () => {
    const filteredDocs = applyFiltersAndSort();
    
    if (filteredDocs.length === 0) {
      return (
        <div className="text-center py-12">
          <FileText className="w-16 h-16 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500 text-lg">Nenhum documento encontrado</p>
          <p className="text-gray-400 mt-2">Tente alterar os filtros ou adicione novos documentos</p>
        </div>
      );
    }
    
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDocs.map((doc) => (
          <Card key={doc.id} className="group overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                {getDocumentTypeIcon(doc.file_type)}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                      <span className="sr-only">Ações</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleViewDocument(doc)}>
                      <Eye className="w-4 h-4 mr-2" />
                      Visualizar Detalhes
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleDownloadDocument(doc)}>
                      <Download className="w-4 h-4 mr-2" />
                      Baixar
                    </DropdownMenuItem>
                    {doc.status !== 'archived' ? (
                      <DropdownMenuItem onClick={() => handleArchiveDocument(doc)}>
                        <Archive className="w-4 h-4 mr-2" />
                        Arquivar
                      </DropdownMenuItem>
                    ) : (
                      <DropdownMenuItem onClick={() => handleRestoreDocument(doc)}>
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Restaurar
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      onClick={() => handleDeleteDocument(doc)}
                      className="text-red-600 hover:text-red-700 focus:text-red-700"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <div className="mt-2 cursor-pointer" onClick={() => handleViewDocument(doc)}>
                <CardTitle className="truncate text-base">{doc.title}</CardTitle>
                {doc.description && (
                  <CardDescription className="mt-1 line-clamp-2">
                    {doc.description}
                  </CardDescription>
                )}
              </div>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="flex flex-wrap gap-2 mb-3">
                {getStatusBadge(doc.status)}
                {getClassificationBadge(doc.classification)}
                <Badge variant="outline" className="text-xs">
                  {getCategoryById(doc.category).name}
                </Badge>
              </div>
              
              {doc.tags && doc.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-3">
                  {doc.tags.slice(0, 3).map((tag, index) => (
                    <Badge key={index} variant="secondary" className="text-xs px-2 py-0">
                      {tag}
                    </Badge>
                  ))}
                  {doc.tags.length > 3 && (
                    <Badge variant="secondary" className="text-xs px-2 py-0">
                      +{doc.tags.length - 3}
                    </Badge>
                  )}
                </div>
              )}
              
              <div className="text-xs text-gray-500 flex items-center justify-between">
                <div>
                  <span>V{doc.version || 1}</span>
                  {doc.file_size && (
                    <span className="ml-2">
                      {formatFileSize(doc.file_size)}
                    </span>
                  )}
                </div>
                <span title={formatDate(doc.updated_date)}>
                  {formatDate(doc.updated_date)}
                </span>
              </div>
            </CardContent>
            <CardFooter className="pt-0 pb-3">
              <div className="w-full flex justify-between mt-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => handleViewDocument(doc)}
                  className="w-full"
                >
                  Visualizar
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    );
  };
  
  const renderDocumentTable = () => {
    const filteredDocs = applyFiltersAndSort();
    
    if (filteredDocs.length === 0) {
      return (
        <div className="text-center py-12">
          <FileText className="w-16 h-16 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500 text-lg">Nenhum documento encontrado</p>
          <p className="text-gray-400 mt-2">Tente alterar os filtros ou adicione novos documentos</p>
        </div>
      );
    }
    
    return (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[250px]">
              <div 
                className="flex items-center gap-1 cursor-pointer" 
                onClick={() => {
                  setSortDirection(sortField === 'title' && sortDirection === 'asc' ? 'desc' : 'asc');
                  setSortField('title');
                }}
              >
                Nome
                {sortField === 'title' && (
                  sortDirection === 'asc' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                )}
              </div>
            </TableHead>
            <TableHead>Categoria</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Classificação</TableHead>
            <TableHead>
              <div 
                className="flex items-center gap-1 cursor-pointer" 
                onClick={() => {
                  setSortDirection(sortField === 'updated_date' && sortDirection === 'asc' ? 'desc' : 'asc');
                  setSortField('updated_date');
                }}
              >
                Atualizado
                {sortField === 'updated_date' && (
                  sortDirection === 'asc' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
                )}
              </div>
            </TableHead>
            <TableHead>Tamanho</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredDocs.map((doc) => (
            <TableRow key={doc.id} className="cursor-pointer hover:bg-gray-50" onClick={() => handleViewDocument(doc)}>
              <TableCell className="font-medium">
                <div className="flex items-center gap-3">
                  {getDocumentTypeIcon(doc.file_type)}
                  <div className="truncate max-w-[200px]">
                    {doc.title}
                  </div>
                </div>
              </TableCell>
              <TableCell>
                <Badge variant="outline" className="text-xs">
                  {getCategoryById(doc.category).name}
                </Badge>
              </TableCell>
              <TableCell>{getStatusBadge(doc.status)}</TableCell>
              <TableCell>{getClassificationBadge(doc.classification)}</TableCell>
              <TableCell>{formatDate(doc.updated_date)}</TableCell>
              <TableCell>
                {doc.file_size && formatFileSize(doc.file_size)}
              </TableCell>
              <TableCell className="text-right">
                <div className="flex justify-end items-center gap-2" onClick={(e) => e.stopPropagation()}>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDownloadDocument(doc);
                    }}
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleViewDocument(doc)}>
                        <Eye className="w-4 h-4 mr-2" />
                        Visualizar Detalhes
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDownloadDocument(doc)}>
                        <Download className="w-4 h-4 mr-2" />
                        Baixar
                      </DropdownMenuItem>
                      {doc.status !== 'archived' ? (
                        <DropdownMenuItem onClick={() => handleArchiveDocument(doc)}>
                          <Archive className="w-4 h-4 mr-2" />
                          Arquivar
                        </DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem onClick={() => handleRestoreDocument(doc)}>
                          <CheckCircle2 className="w-4 h-4 mr-2" />
                          Restaurar
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        onClick={() => handleDeleteDocument(doc)}
                        className="text-red-600 hover:text-red-700 focus:text-red-700"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Excluir
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  };
  
  const renderActivityIcon = (activityType) => {
    switch(activityType) {
      case 'created':
        return <Plus className="w-4 h-4 text-green-600" />;
      case 'viewed':
        return <Eye className="w-4 h-4 text-blue-600" />;
      case 'downloaded':
        return <Download className="w-4 h-4 text-purple-600" />;
      case 'modified':
        return <Edit className="w-4 h-4 text-amber-600" />;
      case 'deleted':
        return <Trash2 className="w-4 h-4 text-red-600" />;
      case 'status_changed':
        return <RefreshCw className="w-4 h-4 text-blue-600" />;
      case 'shared':
        return <Share2 className="w-4 h-4 text-indigo-600" />;
      case 'commented':
        return <MessageSquare className="w-4 h-4 text-green-600" />;
      default:
        return <Activity className="w-4 h-4 text-gray-600" />;
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-green-500"></div>
        <span className="ml-4 text-lg text-gray-700">Carregando Sistema CDI...</span>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold">Sistema CDI - Gestão de Documentos</h1>
          <p className="text-gray-500 mt-1">
            Gerencie, organize e compartilhe documentos importantes da sua organização
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Upload className="w-4 h-4" />
                Enviar Documento
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[625px]">
              <DialogHeader>
                <DialogTitle>Enviar Novo Documento</DialogTitle>
                <DialogDescription>
                  Carregue um documento e preencha os metadados para adicioná-lo ao sistema CDI.
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-4 py-4">
                <div 
                  className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:bg-gray-50 transition-colors ${
                    newDocument.file ? 'border-green-300 bg-green-50' : 'border-gray-300'
                  }`}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  
                  {newDocument.file ? (
                    <div className="flex flex-col items-center">
                      <CheckCircle2 className="w-12 h-12 text-green-500 mb-2" />
                      <p className="font-medium text-gray-900">{newDocument.file.name}</p>
                      <p className="text-sm text-gray-500 mt-1">
                        {formatFileSize(newDocument.file.size)} • {newDocument.file.type || 'Documento'}
                      </p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="mt-2"
                        onClick={(e) => {
                          e.stopPropagation();
                          setNewDocument({...newDocument, file: null});
                          if (fileInputRef.current) fileInputRef.current.value = '';
                        }}
                      >
                        Alterar arquivo
                      </Button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center">
                      <Upload className="w-12 h-12 text-gray-400 mb-2" />
                      <p className="font-medium text-gray-900">Clique para selecionar um arquivo</p>
                      <p className="text-sm text-gray-500 mt-1">
                        ou arraste e solte aqui
                      </p>
                      <p className="text-xs text-gray-400 mt-2">
                        PDF, Word, Excel, PowerPoint, imagens (máx. 25MB)
                      </p>
                    </div>
                  )}
                </div>
                
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Título do Documento*</Label>
                    <Input
                      id="title"
                      value={newDocument.title}
                      onChange={(e) => setNewDocument({...newDocument, title: e.target.value})}
                      placeholder="Insira um título descritivo para o documento"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="description">Descrição</Label>
                    <Textarea
                      id="description"
                      value={newDocument.description}
                      onChange={(e) => setNewDocument({...newDocument, description: e.target.value})}
                      placeholder="Descreva brevemente o conteúdo deste documento"
                      rows={3}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Categoria*</Label>
                    <Select
                      value={newDocument.category}
                      onValueChange={(value) => setNewDocument({...newDocument, category: value})}
                    >
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {defaultCategories.map((category) => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="classification">Classificação de Segurança*</Label>
                    <Select
                      value={newDocument.classification}
                      onValueChange={(value) => setNewDocument({...newDocument, classification: value})}
                    >
                      <SelectTrigger id="classification">
                        <SelectValue placeholder="Selecione uma classificação" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Público</SelectItem>
                        <SelectItem value="internal">Interno</SelectItem>
                        <SelectItem value="confidential">Confidencial</SelectItem>
                        <SelectItem value="restricted">Restrito</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="visibility">Visibilidade</Label>
                  <Select
                    value={newDocument.visibility}
                    onValueChange={(value) => setNewDocument({...newDocument, visibility: value})}
                  >
                    <SelectTrigger id="visibility">
                      <SelectValue placeholder="Selecione a visibilidade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="private">Privado (Apenas eu)</SelectItem>
                      <SelectItem value="organization">Organização (Todos os membros)</SelectItem>
                      <SelectItem value="public">Público (Acessível externamente)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Tags</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      placeholder="Adicione tags para facilitar a busca"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          addTag();
                        }
                      }}
                    />
                    <Button type="button" variant="outline" onClick={addTag}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  {newDocument.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {newDocument.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="px-2 py-1 flex items-center gap-1">
                          {tag}
                          <button 
                            onClick={() => removeTag(tag)}
                            className="text-gray-500 hover:text-gray-700 focus:outline-none"
                          >
                            <XCircle className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button 
                  onClick={handleUploadDocument}
                  disabled={isUploading || !newDocument.file || !newDocument.title}
                >
                  {isUploading ? (
                    <>
                      <div className="mr-2 animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      Enviando...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Enviar Documento
                    </>
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4" />
                Opções
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuLabel>Visualização</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => setViewMode("grid")}>
                <Grid className="w-4 h-4 mr-2" />
                Grade
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setViewMode("table")}>
                <List className="w-4 h-4 mr-2" />
                Tabela
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuLabel>Ordenar por</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => {
                setSortField("title");
                setSortDirection("asc");
              }}>
                Nome (A-Z)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                setSortField("title");
                setSortDirection("desc");
              }}>
                Nome (Z-A)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                setSortField("updated_date");
                setSortDirection("desc");
              }}>
                Mais recentes primeiro
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                setSortField("updated_date");
                setSortDirection("asc");
              }}>
                Mais antigos primeiro
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <Card>
            <CardHeader className="pb-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar documentos..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <div className="flex flex-wrap gap-3">
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="w-36">
                      <SelectValue placeholder="Categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas Categorias</SelectItem>
                      {defaultCategories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos Status</SelectItem>
                      <SelectItem value="draft">Rascunho</SelectItem>
                      <SelectItem value="published">Publicado</SelectItem>
                      <SelectItem value="archived">Arquivado</SelectItem>
                      <SelectItem value="obsolete">Obsoleto</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <div className="flex gap-2">
                    <Button
                      variant={viewMode === "grid" ? "default" : "outline"}
                      size="icon"
                      onClick={() => setViewMode("grid")}
                      className="h-10 w-10"
                    >
                      <Grid className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={viewMode === "table" ? "default" : "outline"}
                      size="icon"
                      onClick={() => setViewMode("table")}
                      className="h-10 w-10"
                    >
                      <List className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
                <TabsList>
                  <TabsTrigger value="all" className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    <span>Todos</span>
                  </TabsTrigger>
                  <TabsTrigger value="recent" className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>Recentes</span>
                  </TabsTrigger>
                  <TabsTrigger value="favorites" className="flex items-center gap-2">
                    <Star className="w-4 h-4" />
                    <span>Favoritos</span>
                  </TabsTrigger>
                  <TabsTrigger value="shared" className="flex items-center gap-2">
                    <Share2 className="w-4 h-4" />
                    <span>Compartilhados</span>
                  </TabsTrigger>
                </TabsList>
              </Tabs>
              
              <div className="space-y-6">
                {viewMode === "grid" ? renderDocumentGrid() : renderDocumentTable()}
                
                {totalPages > 1 && (
                  <Pagination className="mt-6">
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                          disabled={currentPage ===   1}
                        />
                      </PaginationItem>
                      
                      {Array.from({ length: totalPages }, (_, i) => i + 1)
                        .filter(page => {
                          const isFirstPage = page === 1;
                          const isLastPage = page === totalPages;
                          const isCurrentPageAdjacent = Math.abs(page - currentPage) <= 1;
                          return isFirstPage || isLastPage || isCurrentPageAdjacent;
                        })
                        .map((page, i, filteredPages) => {
                          const prevPage = filteredPages[i - 1];
                          const needsEllipsis = prevPage && page - prevPage > 1;
                          
                          return (
                            <React.Fragment key={page}>
                              {needsEllipsis && (
                                <PaginationItem>
                                  <PaginationEllipsis />
                                </PaginationItem>
                              )}
                              <PaginationItem>
                                <PaginationLink
                                  onClick={() => setCurrentPage(page)}
                                  isActive={page === currentPage}
                                >
                                  {page}
                                </PaginationLink>
                              </PaginationItem>
                            </React.Fragment>
                          );
                        })}
                      
                      <PaginationItem>
                        <PaginationNext 
                          onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                          disabled={currentPage === totalPages}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Atividades Recentes</CardTitle>
            </CardHeader>
            <CardContent>
              {recentActivities.length > 0 ? (
                <div className="space-y-4">
                  {recentActivities.map((activity) => (
                    <div key={activity.id} className="flex items-start gap-3">
                      <div className="p-2 bg-gray-100 rounded-full mt-0.5">
                        {renderActivityIcon(activity.activity_type)}
                      </div>
                      <div>
                        <p className="text-sm">
                          {activity.details}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {formatDate(activity.created_date)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <Clock className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                  <p className="text-gray-500">Nenhuma atividade recente</p>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Categorias</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {defaultCategories.map((category) => {
                  const count = documents.filter(doc => doc.category === category.id).length;
                  return (
                    <div 
                      key={category.id}
                      className={`flex items-center justify-between p-2 rounded-lg cursor-pointer hover:bg-gray-50 ${
                        selectedCategory === category.id ? 'bg-gray-50' : ''
                      }`}
                      onClick={() => setSelectedCategory(category.id)}
                    >
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded-full" 
                          style={{ backgroundColor: category.color }}
                        />
                        <span className="text-sm">{category.name}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {count}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Documentos por Classificação</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {Object.entries({
                  'public': 'Público',
                  'internal': 'Interno',
                  'confidential': 'Confidencial',
                  'restricted': 'Restrito'
                }).map(([key, label]) => {
                  const count = documents.filter(doc => doc.classification === key).length;
                  return (
                    <div 
                      key={key}
                      className={`flex items-center justify-between p-2 rounded-lg cursor-pointer hover:bg-gray-50 ${
                        selectedClassification === key ? 'bg-gray-50' : ''
                      }`}
                      onClick={() => setSelectedClassification(key)}
                    >
                      <div className="flex items-center gap-3">
                        <Badge className={classificationColors[key]}>
                          {label}
                        </Badge>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {count}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Document Details Dialog */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[90vh]">
          {selectedDocument && (
            <>
              <DialogHeader>
                <div className="flex items-start gap-3">
                  {getDocumentTypeIcon(selectedDocument.file_type)}
                  <div>
                    <DialogTitle>{selectedDocument.title}</DialogTitle>
                    {selectedDocument.description && (
                      <DialogDescription className="mt-1">
                        {selectedDocument.description}
                      </DialogDescription>
                    )}
                  </div>
                </div>
              </DialogHeader>
              
              <div className="flex flex-col-reverse md:flex-row gap-6">
                <div className="flex-1">
                  <Tabs defaultValue="details">
                    <TabsList className="mb-4">
                      <TabsTrigger value="details" className="flex items-center gap-2">
                        <Info className="w-4 h-4" />
                        Detalhes
                      </TabsTrigger>
                      <TabsTrigger value="comments" className="flex items-center gap-2">
                        <MessageSquare className="w-4 h-4" />
                        Comentários
                      </TabsTrigger>
                      <TabsTrigger value="history" className="flex items-center gap-2">
                        <History className="w-4 h-4" />
                        Histórico
                      </TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="details">
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-gray-500">Categoria</p>
                            <p className="font-medium">
                              {getCategoryById(selectedDocument.category).name}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Status</p>
                            <div>
                              {getStatusBadge(selectedDocument.status)}
                            </div>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Classificação</p>
                            <div>
                              {getClassificationBadge(selectedDocument.classification)}
                            </div>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Visibilidade</p>
                            <p className="font-medium">
                              {selectedDocument.visibility === 'private' ? 'Privado' : 
                                selectedDocument.visibility === 'organization' ? 'Organização' : 
                                'Público'}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Versão</p>
                            <p className="font-medium">V{selectedDocument.version || 1}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Tamanho</p>
                            <p className="font-medium">
                              {selectedDocument.file_size && formatFileSize(selectedDocument.file_size)}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Data de Criação</p>
                            <p className="font-medium">{formatDate(selectedDocument.created_date)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Última Atualização</p>
                            <p className="font-medium">{formatDate(selectedDocument.updated_date)}</p>
                          </div>
                        </div>
                        
                        {selectedDocument.tags && selectedDocument.tags.length > 0 && (
                          <div>
                            <p className="text-sm text-gray-500 mb-2">Tags</p>
                            <div className="flex flex-wrap gap-2">
                              {selectedDocument.tags.map((tag, index) => (
                                <Badge key={index} variant="secondary">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        <div>
                          <p className="text-sm text-gray-500 mb-2">Criado por</p>
                          <div className="flex items-center gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback>
                                {selectedDocument.created_by?.substring(0, 2).toUpperCase() || "US"}
                              </AvatarFallback>
                            </Avatar>
                            <span>{selectedDocument.created_by}</span>
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="comments">
                      <div className="space-y-4">
                        <div className="flex gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback>
                              {currentUser?.full_name?.substring(0, 2).toUpperCase() || "US"}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <Textarea
                              placeholder="Adicione um comentário..."
                              value={newComment}
                              onChange={(e) => setNewComment(e.target.value)}
                            />
                            <div className="flex justify-end mt-2">
                              <Button 
                                size="sm" 
                                onClick={handleAddComment} 
                                disabled={!newComment.trim()}
                              >
                                Comentar
                              </Button>
                            </div>
                          </div>
                        </div>
                        
                        <ScrollArea className="h-64">
                          {documentComments.length > 0 ? (
                            <div className="space-y-4">
                              {documentComments.map((comment) => (
                                <div key={comment.id} className="flex gap-3">
                                  <Avatar className="h-8 w-8">
                                    <AvatarFallback>
                                      {comment.user_id?.substring(0, 2).toUpperCase() || "US"}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div className="flex-1">
                                    <div className="bg-gray-100 p-3 rounded-lg">
                                      <div className="flex justify-between items-center mb-1">
                                        <p className="font-medium text-sm">
                                          {comment.user_id === currentUser?.id ? 'Você' : comment.user_id}
                                        </p>
                                        <p className="text-xs text-gray-500">
                                          {formatDate(comment.created_date)}
                                        </p>
                                      </div>
                                      <p className="text-sm">{comment.content}</p>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="text-center py-8">
                              <MessageSquare className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                              <p className="text-gray-500">Nenhum comentário ainda</p>
                              <p className="text-sm text-gray-400 mt-1">Seja o primeiro a comentar</p>
                            </div>
                          )}
                        </ScrollArea>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="history">
                      <div className="space-y-4">
                        <div className="text-center py-8">
                          <History className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                          <p className="text-gray-500">Histórico de versões</p>
                          <p className="text-sm text-gray-400 mt-1">
                            Este documento está na versão {selectedDocument.version || 1}
                          </p>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
                
                <div className="md:w-48 space-y-3">
                  <Button 
                    className="w-full" 
                    onClick={() => window.open(selectedDocument.file_url, '_blank')}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Visualizar
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={() => handleDownloadDocument(selectedDocument)}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Baixar
                  </Button>
                  
                  {selectedDocument.status !== 'archived' ? (
                    <Button 
                      variant="outline" 
                      className="w-full" 
                      onClick={() => {
                        handleArchiveDocument(selectedDocument);
                        setIsDetailsDialogOpen(false);
                      }}
                    >
                      <Archive className="w-4 h-4 mr-2" />
                      Arquivar
                    </Button>
                  ) : (
                    <Button 
                      variant="outline" 
                      className="w-full" 
                      onClick={() => {
                        handleRestoreDocument(selectedDocument);
                        setIsDetailsDialogOpen(false);
                      }}
                    >
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                      Restaurar
                    </Button>
                  )}
                  
                  <Button
                    variant="outline"
                    className="w-full text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={() => {
                      handleDeleteDocument(selectedDocument);
                      setIsDetailsDialogOpen(false);
                    }}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Excluir
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DocumentManagement;
