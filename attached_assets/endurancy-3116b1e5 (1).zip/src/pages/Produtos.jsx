import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Package, 
  Plus, 
  Search, 
  Filter, 
  Download, 
  MoreHorizontal, 
  Edit, 
  Trash, 
  BarChart,
  Tag,
  AlertCircle,
  CheckCircle,
  XCircle,
  Eye,
  Copy
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

// Dados mockados para demonstração
const produtos = [
  {
    id: 'prod1',
    nome: 'Óleo CBD 10% 30ml',
    categoria: 'óleo',
    preco: 249.90,
    estoque: 32,
    status: 'ativo',
    imagem_url: null,
    sku: 'CBD-OIL-10-30',
    thc: 0.1,
    cbd: 10.0,
    data_criacao: '15/06/2023'
  },
  {
    id: 'prod2',
    nome: 'Cápsulas CBD 20mg',
    categoria: 'cápsula',
    preco: 89.90,
    estoque: 120,
    status: 'ativo',
    imagem_url: null,
    sku: 'CBD-CAP-20',
    thc: 0.05,
    cbd: 20.0,
    data_criacao: '20/06/2023'
  },
  {
    id: 'prod3',
    nome: 'Extrato Full Spectrum 10ml',
    categoria: 'extrato',
    preco: 189.90,
    estoque: 18,
    status: 'ativo',
    imagem_url: null,
    sku: 'CBD-EXT-FS-10',
    thc: 0.3,
    cbd: 15.0,
    data_criacao: '10/07/2023'
  },
  {
    id: 'prod4',
    nome: 'Spray Sublingual THC/CBD',
    categoria: 'óleo',
    preco: 132.50,
    estoque: 45,
    status: 'ativo',
    imagem_url: null,
    sku: 'CBD-SPRAY-SUB',
    thc: 0.2,
    cbd: 5.0,
    data_criacao: '05/07/2023'
  },
  {
    id: 'prod5',
    nome: 'Creme Tópico CBD',
    categoria: 'tópico',
    preco: 99.90,
    estoque: 60,
    status: 'ativo',
    imagem_url: null,
    sku: 'CBD-CREME-TOP',
    thc: 0.0,
    cbd: 2.5,
    data_criacao: '25/06/2023'
  },
  {
    id: 'prod6',
    nome: 'Óleo CBD 5% 30ml',
    categoria: 'óleo',
    preco: 149.90,
    estoque: 0,
    status: 'esgotado',
    imagem_url: null,
    sku: 'CBD-OIL-5-30',
    thc: 0.1,
    cbd: 5.0,
    data_criacao: '18/06/2023'
  },
  {
    id: 'prod7',
    nome: 'Pomada Canabidiol 50g',
    categoria: 'tópico',
    preco: 79.90,
    estoque: 38,
    status: 'ativo',
    imagem_url: null,
    sku: 'CBD-POM-50',
    thc: 0.0,
    cbd: 1.5,
    data_criacao: '12/07/2023'
  }
];

export default function Produtos() {
  const [filtro, setFiltro] = useState('todos');
  const [termoBusca, setTermoBusca] = useState('');
  const [produtosFiltrados, setProdutosFiltrados] = useState(produtos);
  const [produtoSelecionado, setProdutoSelecionado] = useState(null);
  const [confirmacaoExclusao, setConfirmacaoExclusao] = useState(false);
  const [ordenacao, setOrdenacao] = useState('nome');

  useEffect(() => {
    filtrarProdutos();
  }, [filtro, termoBusca, ordenacao]);

  const filtrarProdutos = () => {
    let resultados = produtos;
    
    // Filtrar por status
    if (filtro !== 'todos') {
      resultados = resultados.filter(produto => produto.status === filtro);
    }
    
    // Filtrar por termo de busca
    if (termoBusca) {
      resultados = resultados.filter(produto => 
        produto.nome.toLowerCase().includes(termoBusca.toLowerCase()) ||
        produto.sku.toLowerCase().includes(termoBusca.toLowerCase()) ||
        produto.categoria.toLowerCase().includes(termoBusca.toLowerCase())
      );
    }
    
    // Ordenar resultados
    resultados = ordernarProdutos(resultados, ordenacao);
    
    setProdutosFiltrados(resultados);
  };

  const ordernarProdutos = (lista, criterio) => {
    switch (criterio) {
      case 'nome':
        return [...lista].sort((a, b) => a.nome.localeCompare(b.nome));
      case 'preco_asc':
        return [...lista].sort((a, b) => a.preco - b.preco);
      case 'preco_desc':
        return [...lista].sort((a, b) => b.preco - a.preco);
      case 'estoque_asc':
        return [...lista].sort((a, b) => a.estoque - b.estoque);
      case 'estoque_desc':
        return [...lista].sort((a, b) => b.estoque - a.estoque);
      case 'recente':
        return [...lista].sort((a, b) => new Date(b.data_criacao) - new Date(a.data_criacao));
      default:
        return lista;
    }
  };

  const confirmarExclusao = (produto) => {
    setProdutoSelecionado(produto);
    setConfirmacaoExclusao(true);
  };

  const excluirProduto = () => {
    // Em uma implementação real, aqui chamaria a API para excluir o produto
    const produtosAtualizados = produtosFiltrados.filter(p => p.id !== produtoSelecionado.id);
    setProdutosFiltrados(produtosAtualizados);
    setConfirmacaoExclusao(false);
  };

  // Badge para status do produto
  const getStatusBadge = (status, estoque) => {
    if (estoque === 0 || status === 'esgotado') {
      return <Badge className="bg-red-100 text-red-800">Esgotado</Badge>;
    } else if (estoque < 20) {
      return <Badge className="bg-yellow-100 text-yellow-800">Estoque baixo</Badge>;
    } else if (status === 'ativo') {
      return <Badge className="bg-green-100 text-green-800">Ativo</Badge>;
    } else if (status === 'inativo') {
      return <Badge className="bg-gray-100 text-gray-800">Inativo</Badge>;
    } else {
      return <Badge>{status}</Badge>;
    }
  };

  // Formatar moeda em reais
  const formatarMoeda = (valor) => {
    return valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Produtos</h1>
          <p className="text-gray-500 mt-1">
            Gerencie o catálogo de produtos
          </p>
        </div>
        
        <Link to={createPageUrl("NovoProduto")}>
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            Novo Produto
          </Button>
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
          <Input 
            placeholder="Buscar produto por nome, SKU..." 
            value={termoBusca}
            onChange={(e) => setTermoBusca(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex gap-2 ml-auto">
          <Select value={ordenacao} onValueChange={setOrdenacao}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Ordenar por" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="nome">Nome (A-Z)</SelectItem>
              <SelectItem value="preco_asc">Menor preço</SelectItem>
              <SelectItem value="preco_desc">Maior preço</SelectItem>
              <SelectItem value="estoque_asc">Menor estoque</SelectItem>
              <SelectItem value="estoque_desc">Maior estoque</SelectItem>
              <SelectItem value="recente">Mais recentes</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="gap-2">
            <Filter className="w-4 h-4" />
            Filtrar
          </Button>
          
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Exportar
          </Button>
        </div>
      </div>

      <Tabs value={filtro} onValueChange={setFiltro}>
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="todos">Todos</TabsTrigger>
          <TabsTrigger value="ativo">Ativos</TabsTrigger>
          <TabsTrigger value="esgotado">Esgotados</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card>
        <CardContent className="p-0">
          {produtosFiltrados.length === 0 ? (
            <div className="p-8 text-center">
              <Package className="w-12 h-12 mx-auto text-gray-300 mb-3" />
              <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhum produto encontrado</h3>
              <p className="text-gray-500">
                Nenhum produto corresponde aos filtros aplicados.
              </p>
              <Button variant="outline" className="mt-4" onClick={() => { setFiltro('todos'); setTermoBusca(''); }}>
                Limpar filtros
              </Button>
            </div>
          ) : (
            <div className="rounded-lg border overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Produto</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">SKU</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Categoria</th>
                      <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Preço</th>
                      <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Estoque</th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">Status</th>
                      <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {produtosFiltrados.map((produto, i) => (
                      <tr key={produto.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10">
                              {produto.imagem_url ? (
                                <AvatarImage src={produto.imagem_url} />
                              ) : (
                                <AvatarFallback className="bg-primary/10 text-primary">
                                  {produto.nome.substring(0, 2).toUpperCase()}
                                </AvatarFallback>
                              )}
                            </Avatar>
                            <div>
                              <Link to={`${createPageUrl("DetalheProduto")}?id=${produto.id}`}>
                                <div className="text-sm font-medium hover:text-blue-600">
                                  {produto.nome}
                                </div>
                              </Link>
                              <div className="text-xs text-gray-500">
                                THC: {produto.thc}% | CBD: {produto.cbd}%
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-700">{produto.sku}</td>
                        <td className="px-4 py-3">
                          <Badge variant="outline">
                            {produto.categoria}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-sm text-right font-medium">
                          {formatarMoeda(produto.preco)}
                        </td>
                        <td className="px-4 py-3 text-sm text-right">
                          {produto.estoque} unidades
                        </td>
                        <td className="px-4 py-3 text-center">
                          {getStatusBadge(produto.status, produto.estoque)}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Ações</DropdownMenuLabel>
                              <DropdownMenuItem onSelect={() => window.location.href = `${createPageUrl("DetalheProduto")}?id=${produto.id}`}>
                                <Eye className="w-4 h-4 mr-2" />
                                Visualizar
                              </DropdownMenuItem>
                              <DropdownMenuItem onSelect={() => window.location.href = `${createPageUrl("EditarProduto")}?id=${produto.id}`}>
                                <Edit className="w-4 h-4 mr-2" />
                                Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem onSelect={() => {}}>
                                <Copy className="w-4 h-4 mr-2" />
                                Duplicar
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onSelect={() => confirmarExclusao(produto)} className="text-red-600">
                                <Trash className="w-4 h-4 mr-2" />
                                Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={confirmacaoExclusao} onOpenChange={setConfirmacaoExclusao}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir o produto "{produtoSelecionado?.nome}"? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="flex items-center p-4 border border-red-100 bg-red-50 rounded-lg">
              <AlertCircle className="text-red-600 mr-3 h-5 w-5" />
              <p className="text-sm text-red-900">
                A exclusão irá remover o produto permanentemente e pode afetar pedidos em andamento.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmacaoExclusao(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={excluirProduto}>
              Sim, excluir produto
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}