import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  BarChart, 
  Info, 
  Check, 
  Plus, 
  Search, 
  Settings,
  Download,
  ArrowRight,
  Building2,
  DollarSign,
  Users,
  Smartphone,
  Headphones,
  BadgePercent,
  X
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";

// Mock data for module
const moduleData = {
  name: "CRM",
  description: "Gestão de pacientes e prescrições",
  icon: Heart,
  active_organizations: 18,
  total_revenue: 32580,
  features: [
    "Cadastro e gestão de pacientes",
    "Controle de prescrições",
    "Gestão de atendimentos",
    "Campanhas",
    "Histórico médico"
  ],
  tiers: [
    {
      name: "Básico",
      price: 399,
      limit: "até 100 pacientes",
      features: [
        { name: "Cadastro de pacientes", included: true },
        { name: "Gestão de prescrições", included: true },
        { name: "Histórico básico", included: true },
        { name: "Atendimento", included: true },
        { name: "Campanhas", included: false },
        { name: "Análise avançada", included: false }
      ]
    },
    {
      name: "Profissional",
      price: 799,
      limit: "até 500 pacientes",
      features: [
        { name: "Cadastro completo de pacientes", included: true },
        { name: "Gestão avançada de prescrições", included: true },
        { name: "Histórico médico completo", included: true },
        { name: "Atendimento multicanal", included: true },
        { name: "Campanhas", included: true },
        { name: "Análise avançada", included: false }
      ]
    },
    {
      name: "Enterprise",
      price: 1299,
      limit: "pacientes ilimitados",
      features: [
        { name: "Cadastro completo de pacientes", included: true },
        { name: "Gestão avançada de prescrições", included: true },
        { name: "Histórico médico completo", included: true },
        { name: "Atendimento multicanal", included: true },
        { name: "Campanhas automatizadas", included: true },
        { name: "Análise e relatórios avançados", included: true }
      ]
    }
  ],
  organizations: [
    {
      id: "org1",
      name: "MediCannabis Farma",
      type: "Empresa",
      plan: "Profissional",
      contact_name: "João Silva",
      since: "15/07/2023",
      status: "Ativo"
    },
    {
      id: "org2",
      name: "Associação Médica Verde",
      type: "Associação",
      plan: "Enterprise",
      contact_name: "Maria Oliveira",
      since: "12/07/2023",
      status: "Ativo"
    },
    {
      id: "org3",
      name: "Green Medical Brasil",
      type: "Empresa",
      plan: "Enterprise",
      contact_name: "Ana Sousa",
      since: "20/07/2023",
      status: "Ativo"
    },
    {
      id: "org4",
      name: "Cultivo Sustentável Ltda",
      type: "Empresa",
      plan: "Básico",
      contact_name: "Ana Costa",
      since: "28/06/2023",
      status: "Ativo"
    }
  ]
};

export default function ModuloCRM() {
  const [activeTab, setActiveTab] = useState("overview");
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const filteredOrganizations = moduleData.organizations.filter(org => 
    org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    org.contact_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-purple-100 rounded-lg">
            <Heart className="w-6 h-6 text-purple-700" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Módulo CRM</h1>
            <p className="text-gray-500">Gestão de pacientes e prescrições</p>
          </div>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Adicionar a Organização
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Organizações com o Módulo</CardDescription>
            <CardTitle className="text-3xl font-bold">{moduleData.active_organizations}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-blue-600">
              <Info className="w-4 h-4 mr-1" />
              {moduleData.active_organizations} organizações ativas
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Receita Mensal</CardDescription>
            <CardTitle className="text-3xl font-bold">R$ {moduleData.total_revenue.toLocaleString('pt-BR')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-green-600">
              <DollarSign className="w-4 h-4 mr-1" />
              Faturamento recorrente
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Taxa de Adoção</CardDescription>
            <CardTitle className="text-3xl font-bold">42%</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-purple-600">
              <BarChart className="w-4 h-4 mr-1" />
              Crescimento de 8% este mês
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="organizations">Organizações</TabsTrigger>
          <TabsTrigger value="pricing">Planos e Preços</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Sobre o Módulo</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                O módulo de CRM permite a gestão completa de pacientes, prescrições médicas, 
                histórico de atendimentos, campanhas e comunicações, fornecendo uma visão 
                centralizada de cada paciente.
              </p>
              
              <h3 className="text-lg font-medium mb-2">Recursos Principais</h3>
              <ul className="space-y-2">
                {moduleData.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-green-500 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Organizações com o Módulo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {moduleData.organizations.slice(0, 5).map((org, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback className="bg-purple-100 text-purple-800">
                          {org.name.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{org.name}</p>
                        <p className="text-sm text-gray-500">Plano {org.plan}</p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">
                      Ativo
                    </Badge>
                  </div>
                ))}
              </div>
              
              <div className="mt-4">
                <Button variant="outline" className="w-full" onClick={() => setActiveTab("organizations")}>
                  Ver Todas as Organizações
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="organizations" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <CardTitle>Organizações com Acesso</CardTitle>
                <CardDescription>
                  Gerenciar organizações que utilizam o módulo de CRM
                </CardDescription>
              </div>
              <div className="w-full sm:w-auto">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input 
                    placeholder="Buscar organizações" 
                    className="pl-10 w-full sm:w-auto" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-md">
                <div className="grid grid-cols-12 gap-2 p-4 border-b bg-gray-50 font-medium text-sm">
                  <div className="col-span-4">Organização</div>
                  <div className="col-span-2">Tipo</div>
                  <div className="col-span-2">Plano</div>
                  <div className="col-span-2">Desde</div>
                  <div className="col-span-2 text-right">Ações</div>
                </div>
                
                {filteredOrganizations.length === 0 ? (
                  <div className="p-8 text-center">
                    <Heart className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <h3 className="text-lg font-medium">Nenhuma organização encontrada</h3>
                    <p className="text-gray-500 mt-1 max-w-md mx-auto">
                      {searchTerm 
                        ? `Não encontramos organizações correspondentes a "${searchTerm}"`
                        : "Adicione organizações a este módulo clicando no botão acima."}
                    </p>
                    {searchTerm && (
                      <Button 
                        variant="outline" 
                        className="mt-4"
                        onClick={() => setSearchTerm("")}
                      >
                        Limpar busca
                      </Button>
                    )}
                  </div>
                ) : (
                  <>
                    {filteredOrganizations.map((org, index) => (
                      <div 
                        key={index} 
                        className={`grid grid-cols-12 gap-2 p-4 text-sm items-center ${
                          index < filteredOrganizations.length - 1 ? 'border-b' : ''
                        }`}
                      >
                        <div className="col-span-4">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="bg-purple-100 text-purple-800 text-xs">
                                {org.name.substring(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{org.name}</p>
                              <p className="text-xs text-gray-500">{org.contact_name}</p>
                            </div>
                          </div>
                        </div>
                        <div className="col-span-2">
                          <Badge variant="outline">{org.type}</Badge>
                        </div>
                        <div className="col-span-2">
                          {org.plan}
                        </div>
                        <div className="col-span-2 text-gray-500">
                          {org.since}
                        </div>
                        <div className="col-span-2 text-right">
                          <Button variant="outline" size="sm">
                            Gerenciar
                          </Button>
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pricing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Planos do Módulo de CRM</CardTitle>
              <CardDescription>
                Configure os preços e limites dos planos disponíveis
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {moduleData.tiers.map((tier, index) => (
                  <Card key={index} className="flex flex-col h-full border-purple-200">
                    <CardHeader className={index === 1 ? "bg-purple-50" : ""}>
                      {index === 1 && (
                        <Badge className="mb-2 bg-purple-600">Recomendado</Badge>
                      )}
                      <CardTitle>{tier.name}</CardTitle>
                      <CardDescription>
                        Limite: {tier.limit}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="flex-1">
                      <div className="mb-6">
                        <span className="text-3xl font-bold">R$ {tier.price}</span>
                        <span className="text-gray-500 ml-1">/mês</span>
                      </div>
                      
                      <ul className="space-y-2">
                        {tier.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center gap-2 text-sm">
                            {feature.included ? (
                              <Check className="w-4 h-4 text-green-500" />
                            ) : (
                              <X className="w-4 h-4 text-gray-300" />
                            )}
                            <span className={feature.included ? "" : "text-gray-400"}>
                              {feature.name}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full" variant={index === 1 ? "default" : "outline"}>
                        Editar Plano
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Personalização de Planos</CardTitle>
              <CardDescription>
                Configure opções adicionais para os planos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Período de Testes</h3>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch id="trial-mode" defaultChecked />
                      <Label htmlFor="trial-mode">Ativar período de testes</Label>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Input
                        id="trial-days"
                        className="w-20"
                        type="number"
                        placeholder="Dias"
                        defaultValue="30"
                      />
                      <Label htmlFor="trial-days">dias</Label>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Descontos</h3>
                  <div className="space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                      <div className="flex items-center space-x-2">
                        <Switch id="annual-discount" defaultChecked />
                        <Label htmlFor="annual-discount">Desconto para pagamento anual</Label>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Input
                          id="discount-percent"
                          className="w-20"
                          type="number"
                          placeholder="%"
                          defaultValue="15"
                        />
                        <Label htmlFor="discount-percent">%</Label>
                      </div>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                      <div className="flex items-center space-x-2">
                        <Switch id="new-customer-discount" defaultChecked />
                        <Label htmlFor="new-customer-discount">Desconto para novos clientes</Label>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Input
                          id="new-customer-percent"
                          className="w-20"
                          type="number"
                          placeholder="%"
                          defaultValue="20"
                        />
                        <Label htmlFor="new-customer-percent">%</Label>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Label htmlFor="new-customer-months">por</Label>
                        <Input
                          id="new-customer-months"
                          className="w-20"
                          type="number"
                          placeholder="Meses"
                          defaultValue="2"
                        />
                        <Label htmlFor="new-customer-months">meses</Label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="ml-auto" onClick={() => toast({
                title: "Configurações salvas",
                description: "As configurações de preços foram atualizadas com sucesso."
              })}>
                Salvar Alterações
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do Módulo</CardTitle>
              <CardDescription>
                Personalize configurações gerais do módulo de CRM
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="module-name">Nome do Módulo</Label>
                  <Input id="module-name" defaultValue="CRM" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="module-description">Descrição</Label>
                  <Input id="module-description" defaultValue="Gestão de pacientes e prescrições" />
                </div>
                
                <div className="space-y-2">
                  <Label className="block mb-2">Disponibilidade</Label>
                  <div className="flex items-center space-x-2">
                    <Switch id="active-status" defaultChecked />
                    <Label htmlFor="active-status">Módulo ativo para novas organizações</Label>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Label className="block mb-2">Acesso por Tipo de Organização</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Switch id="access-business" defaultChecked />
                      <Label htmlFor="access-business">Empresas</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="access-association" defaultChecked />
                      <Label htmlFor="access-association">Associações</Label>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Label className="block mb-2">Integrações</Label>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2">
                        <Switch id="integration-patient-portal" defaultChecked />
                        <Label htmlFor="integration-patient-portal">Portal do Paciente</Label>
                      </div>
                      <Button variant="ghost" size="sm">Configurar</Button>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2">
                        <Switch id="integration-email" defaultChecked />
                        <Label htmlFor="integration-email">Integração com Email</Label>
                      </div>
                      <Button variant="ghost" size="sm">Configurar</Button>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2">
                        <Switch id="integration-whatsapp" defaultChecked />
                        <Label htmlFor="integration-whatsapp">Integração com WhatsApp</Label>
                      </div>
                      <Button variant="ghost" size="sm">Configurar</Button>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2">
                        <Switch id="integration-sms" />
                        <Label htmlFor="integration-sms">Integração com SMS</Label>
                      </div>
                      <Button variant="ghost" size="sm">Configurar</Button>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Label className="block mb-2">Configurações de Segurança</Label>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Switch id="hipaa-compliance" defaultChecked />
                      <Label htmlFor="hipaa-compliance">Conformidade com LGPD</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="encryption" defaultChecked />
                      <Label htmlFor="encryption">Criptografia de dados sensíveis</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="audit-trail" defaultChecked />
                      <Label htmlFor="audit-trail">Trilha de auditoria</Label>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="mr-2">Cancelar</Button>
              <Button onClick={() => toast({
                title: "Configurações salvas",
                description: "As configurações do módulo foram atualizadas com sucesso."
              })}>
                Salvar Alterações
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}