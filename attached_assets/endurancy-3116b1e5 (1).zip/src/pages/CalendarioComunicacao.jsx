import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Plus,
  Filter,
  MoreHorizontal,
  Clock,
  MapPin,
  Users,
  Tag,
  Bell,
  Trash2,
  Edit,
  CheckCircle2,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
  DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Spinner } from '@/components/ui/spinner';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/components/ui/use-toast';
import { format, addDays, subDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO, startOfMonth, endOfMonth, addMonths, subMonths, getDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function CalendarioComunicacao() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [currentView, setCurrentView] = useState('month'); // month, week, day
  const [events, setEvents] = useState([]);
  const [showAddEventDialog, setShowAddEventDialog] = useState(false);
  const [showEventDetailsDialog, setShowEventDetailsDialog] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [filteredEventTypes, setFilteredEventTypes] = useState([
    'presencial', 'online', 'hibrido', 'campanha'
  ]);
  const [confirmDeleteDialog, setConfirmDeleteDialog] = useState(false);
  
  const [newEvent, setNewEvent] = useState({
    titulo: '',
    descricao: '',
    tipo: 'presencial',
    data_inicio: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
    data_fim: format(addDays(new Date(), 1), "yyyy-MM-dd'T'HH:mm"),
    dia_todo: false,
    local: '',
    cor: '#4f46e5' // indigo-600
  });

  // Simular carregamento de eventos
  useEffect(() => {
    const loadEvents = async () => {
      setLoading(true);
      try {
        // Simular um delay de carregamento
        setTimeout(() => {
          const mockEvents = [
            {
              id: '1',
              titulo: 'Palestra: Benefícios do CBD',
              descricao: 'Palestra educativa sobre os benefícios do CBD para tratamentos médicos',
              tipo: 'presencial',
              data_inicio: '2025-01-10T14:00:00',
              data_fim: '2025-01-10T16:00:00',
              dia_todo: false,
              local: 'Auditório Principal',
              cor: '#4f46e5', // indigo-600
              participantes: [
                { id: 'p1', nome: 'Dr. Carlos Santos', email: 'carlos@exemplo.com' },
                { id: 'p2', nome: 'Dra. Ana Silva', email: 'ana@exemplo.com' }
              ]
            },
            {
              id: '2',
              titulo: 'Workshop Online: Qualidade de Vida',
              descricao: 'Workshop sobre como a cannabis medicinal pode melhorar a qualidade de vida',
              tipo: 'online',
              data_inicio: '2025-01-15T10:00:00',
              data_fim: '2025-01-15T12:00:00',
              dia_todo: false,
              local: 'Zoom (link será enviado)',
              cor: '#0891b2', // cyan-600
              participantes: []
            },
            {
              id: '3',
              titulo: 'Campanha: Esclarecimento Medicinal',
              descricao: 'Campanha de email para esclarecimento sobre uso medicinal da cannabis',
              tipo: 'campanha',
              data_inicio: '2025-01-20T08:00:00',
              data_fim: '2025-01-24T18:00:00',
              dia_todo: true,
              local: 'Online',
              cor: '#ca8a04', // yellow-600
              participantes: []
            }
          ];
          
          setEvents(mockEvents);
          setLoading(false);
        }, 800);
      } catch (error) {
        console.error("Erro ao carregar eventos:", error);
        toast({
          title: "Erro ao carregar eventos",
          description: "Não foi possível carregar os eventos do calendário.",
          variant: "destructive"
        });
        setLoading(false);
      }
    };
    
    loadEvents();
  }, []);

  const handleAddEvent = () => {
    // Em uma implementação real, integraria com a API
    const newEventWithId = {
      ...newEvent,
      id: `temp-${Date.now()}`,
      participantes: []
    };
    
    setEvents([...events, newEventWithId]);
    setShowAddEventDialog(false);
    
    // Resetar formulário
    setNewEvent({
      titulo: '',
      descricao: '',
      tipo: 'presencial',
      data_inicio: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
      data_fim: format(addDays(new Date(), 1), "yyyy-MM-dd'T'HH:mm"),
      dia_todo: false,
      local: '',
      cor: '#4f46e5'
    });
    
    toast({
      title: "Evento adicionado",
      description: "O evento foi adicionado com sucesso ao calendário.",
    });
  };

  const handleDeleteEvent = () => {
    if (!selectedEvent) return;
    
    setEvents(events.filter(event => event.id !== selectedEvent.id));
    setConfirmDeleteDialog(false);
    setShowEventDetailsDialog(false);
    
    toast({
      title: "Evento excluído",
      description: "O evento foi excluído com sucesso do calendário.",
    });
  };

  const navigatePrevious = () => {
    if (currentView === 'month') {
      setCurrentDate(subMonths(currentDate, 1));
    } else if (currentView === 'week') {
      setCurrentDate(subDays(currentDate, 7));
    } else {
      setCurrentDate(subDays(currentDate, 1));
    }
  };

  const navigateNext = () => {
    if (currentView === 'month') {
      setCurrentDate(addMonths(currentDate, 1));
    } else if (currentView === 'week') {
      setCurrentDate(addDays(currentDate, 7));
    } else {
      setCurrentDate(addDays(currentDate, 1));
    }
  };

  const navigateToday = () => {
    setCurrentDate(new Date());
  };

  const toggleEventTypeFilter = (type) => {
    if (filteredEventTypes.includes(type)) {
      setFilteredEventTypes(filteredEventTypes.filter(t => t !== type));
    } else {
      setFilteredEventTypes([...filteredEventTypes, type]);
    }
  };

  const getFilteredEvents = () => {
    return events.filter(event => filteredEventTypes.includes(event.tipo));
  };

  const getEventTypeColor = (type) => {
    switch (type) {
      case 'presencial': return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'online': return 'bg-cyan-100 text-cyan-800 border-cyan-200';
      case 'hibrido': return 'bg-violet-100 text-violet-800 border-violet-200';
      case 'campanha': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  // Renderizadores para diferentes visualizações
  const renderMonthView = () => {
    const startDate = startOfMonth(currentDate);
    const endDate = endOfMonth(currentDate);
    const days = eachDayOfInterval({ start: startDate, end: endDate });
    
    // Adicionar dias do mês anterior para completar a primeira semana
    const firstDayOfMonth = getDay(startDate);
    const prevMonthDays = firstDayOfMonth > 0 
      ? eachDayOfInterval({ 
          start: subDays(startDate, firstDayOfMonth), 
          end: subDays(startDate, 1) 
        }) 
      : [];
    
    // Adicionar dias do próximo mês para completar a última semana
    const lastDayOfMonth = getDay(endDate);
    const nextMonthDays = lastDayOfMonth < 6 
      ? eachDayOfInterval({ 
          start: addDays(endDate, 1), 
          end: addDays(endDate, 6 - lastDayOfMonth) 
        }) 
      : [];
    
    const allDays = [...prevMonthDays, ...days, ...nextMonthDays];
    
    // Agrupar por semanas
    const weeks = [];
    for (let i = 0; i < allDays.length; i += 7) {
      weeks.push(allDays.slice(i, i + 7));
    }
    
    return (
      <div className="border rounded-lg overflow-hidden">
        <div className="grid grid-cols-7 text-center bg-muted py-2 font-medium text-sm border-b">
          <div>Dom</div>
          <div>Seg</div>
          <div>Ter</div>
          <div>Qua</div>
          <div>Qui</div>
          <div>Sex</div>
          <div>Sáb</div>
        </div>
        <div className="bg-background">
          {weeks.map((week, weekIndex) => (
            <div key={weekIndex} className="grid grid-cols-7 border-b last:border-b-0">
              {week.map((day, dayIndex) => {
                const isCurrentMonth = day.getMonth() === currentDate.getMonth();
                const isToday = isSameDay(day, new Date());
                
                // Filtrar eventos para este dia
                const dayEvents = getFilteredEvents().filter(event => {
                  const eventStart = parseISO(event.data_inicio);
                  const eventEnd = parseISO(event.data_fim);
                  return isSameDay(day, eventStart) || 
                         (event.dia_todo && day >= eventStart && day <= eventEnd);
                });
                
                return (
                  <div 
                    key={dayIndex}
                    className={`min-h-[100px] p-1 border-r last:border-r-0 ${
                      isCurrentMonth ? 'bg-background' : 'bg-muted/20'
                    } ${isToday ? 'bg-blue-50 dark:bg-blue-950/20' : ''}`}
                  >
                    <div className="flex justify-between items-center">
                      <span 
                        className={`text-sm font-medium ${
                          isCurrentMonth 
                            ? isToday 
                              ? 'text-blue-600 dark:text-blue-400' 
                              : 'text-foreground' 
                            : 'text-muted-foreground'
                        }`}
                      >
                        {format(day, 'd')}
                      </span>
                      {isCurrentMonth && (
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-5 w-5 rounded-full opacity-0 hover:opacity-100 transition-opacity"
                          onClick={() => {
                            setNewEvent({
                              ...newEvent,
                              data_inicio: format(day, "yyyy-MM-dd'T'10:00"),
                              data_fim: format(day, "yyyy-MM-dd'T'11:00")
                            });
                            setShowAddEventDialog(true);
                          }}
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                    <div className="space-y-1 mt-1">
                      {dayEvents.slice(0, 3).map((event) => (
                        <div 
                          key={event.id}
                          className="text-xs p-1 rounded-sm truncate cursor-pointer"
                          style={{ backgroundColor: `${event.cor}20`, borderLeft: `3px solid ${event.cor}` }}
                          onClick={() => {
                            setSelectedEvent(event);
                            setShowEventDetailsDialog(true);
                          }}
                        >
                          {event.titulo}
                        </div>
                      ))}
                      {dayEvents.length > 3 && (
                        <div className="text-xs text-muted-foreground px-1">
                          + {dayEvents.length - 3} mais
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderWeekView = () => {
    const startDate = startOfWeek(currentDate, { weekStartsOn: 0 });
    const endDate = endOfWeek(currentDate, { weekStartsOn: 0 });
    const days = eachDayOfInterval({ start: startDate, end: endDate });
    
    return (
      <div className="border rounded-lg overflow-hidden">
        <div className="grid grid-cols-8 text-center py-2 font-medium text-sm border-b">
          <div className="border-r"></div>
          {days.map((day, index) => (
            <div key={index} className={`${isSameDay(day, new Date()) ? 'text-blue-600 dark:text-blue-400' : ''}`}>
              <div>{format(day, 'EEE', { locale: ptBR })}</div>
              <div className="text-lg">{format(day, 'd')}</div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-8 border-b">
          {Array.from({ length: 12 }).map((_, hour) => (
            <React.Fragment key={hour}>
              <div className="border-r px-2 py-4 text-xs text-right">
                {`${hour + 8}:00`}
              </div>
              {days.map((day, dayIndex) => {
                const hourStart = new Date(day);
                hourStart.setHours(hour + 8, 0, 0);
                const hourEnd = new Date(day);
                hourEnd.setHours(hour + 9, 0, 0);
                
                // Filtrar eventos para esta hora
                const hourEvents = getFilteredEvents().filter(event => {
                  if (event.dia_todo) return false;
                  
                  const eventStart = parseISO(event.data_inicio);
                  const eventEnd = parseISO(event.data_fim);
                  
                  return isSameDay(day, eventStart) && 
                         eventStart.getHours() === hourStart.getHours();
                });
                
                return (
                  <div 
                    key={dayIndex}
                    className={`border-r last:border-r-0 border-b p-1 ${
                      isSameDay(day, new Date()) ? 'bg-blue-50 dark:bg-blue-950/20' : ''
                    }`}
                  >
                    {hourEvents.map(event => (
                      <div 
                        key={event.id}
                        className="text-xs p-1 rounded-sm mb-1 truncate cursor-pointer"
                        style={{ backgroundColor: `${event.cor}20`, borderLeft: `3px solid ${event.cor}` }}
                        onClick={() => {
                          setSelectedEvent(event);
                          setShowEventDetailsDialog(true);
                        }}
                      >
                        {event.titulo}
                      </div>
                    ))}
                  </div>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
    );
  };

  const renderDayView = () => {
    return (
      <div className="border rounded-lg overflow-hidden">
        <div className="p-4 border-b bg-muted/20">
          <h3 className="text-xl font-semibold">{format(currentDate, 'PPPP', { locale: ptBR })}</h3>
        </div>
        <div>
          {Array.from({ length: 12 }).map((_, hour) => {
            const hourStart = new Date(currentDate);
            hourStart.setHours(hour + 8, 0, 0);
            const hourEnd = new Date(currentDate);
            hourEnd.setHours(hour + 9, 0, 0);
            
            // Filtrar eventos para esta hora
            const hourEvents = getFilteredEvents().filter(event => {
              if (event.dia_todo) return false;
              
              const eventStart = parseISO(event.data_inicio);
              const eventEnd = parseISO(event.data_fim);
              
              return isSameDay(currentDate, eventStart) && 
                     eventStart.getHours() === hourStart.getHours();
            });
            
            return (
              <div key={hour} className="grid grid-cols-[80px_1fr] border-b last:border-b-0">
                <div className="p-2 border-r text-sm text-right pr-3 font-medium">
                  {`${hour + 8}:00`}
                </div>
                <div className="p-2">
                  {hourEvents.map(event => (
                    <div 
                      key={event.id}
                      className="p-2 rounded-md mb-2 cursor-pointer"
                      style={{ backgroundColor: `${event.cor}20`, borderLeft: `3px solid ${event.cor}` }}
                      onClick={() => {
                        setSelectedEvent(event);
                        setShowEventDetailsDialog(true);
                      }}
                    >
                      <div className="font-medium">{event.titulo}</div>
                      {event.local && (
                        <div className="text-sm text-muted-foreground flex items-center mt-1">
                          <MapPin className="h-3 w-3 mr-1" /> {event.local}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Componente principal
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Calendário de Eventos</h1>
          <p className="text-muted-foreground">
            Gerencie eventos, campanhas e lembretes
          </p>
        </div>
        <div className="flex items-center gap-2 self-end sm:self-auto">
          <Button 
            variant="outline" 
            onClick={() => setShowAddEventDialog(true)}
          >
            <Plus className="mr-2 h-4 w-4" />
            Novo Evento
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-2 sm:space-y-0">
        <div className="flex items-center gap-1">
          <Button variant="outline" size="sm" onClick={navigatePrevious}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={navigateToday}>
            Hoje
          </Button>
          <Button variant="outline" size="sm" onClick={navigateNext}>
            <ChevronRight className="h-4 w-4" />
          </Button>
          <div className="ml-2 font-semibold text-lg">
            {currentView === 'month' && format(currentDate, 'MMMM yyyy', { locale: ptBR })}
            {currentView === 'week' && `${format(startOfWeek(currentDate), 'd MMM', { locale: ptBR })} - ${format(endOfWeek(currentDate), 'd MMM yyyy', { locale: ptBR })}`}
            {currentView === 'day' && format(currentDate, 'd MMMM yyyy', { locale: ptBR })}
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          <Select value={currentView} onValueChange={setCurrentView}>
            <SelectTrigger className="w-[130px]">
              <CalendarIcon className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Visualização" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">Mês</SelectItem>
              <SelectItem value="week">Semana</SelectItem>
              <SelectItem value="day">Dia</SelectItem>
            </SelectContent>
          </Select>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="default">
                <Filter className="mr-2 h-4 w-4" />
                Filtrar
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[200px]">
              <div className="p-2">
                <div className="font-medium mb-2">Tipos de Evento</div>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="filter-presencial"
                      checked={filteredEventTypes.includes('presencial')}
                      onChange={() => toggleEventTypeFilter('presencial')}
                      className="mr-2"
                    />
                    <label htmlFor="filter-presencial" className="text-sm">
                      <Badge className={getEventTypeColor('presencial')}>Presencial</Badge>
                    </label>
                  </div>
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="filter-online"
                      checked={filteredEventTypes.includes('online')}
                      onChange={() => toggleEventTypeFilter('online')}
                      className="mr-2"
                    />
                    <label htmlFor="filter-online" className="text-sm">
                      <Badge className={getEventTypeColor('online')}>Online</Badge>
                    </label>
                  </div>
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="filter-hibrido"
                      checked={filteredEventTypes.includes('hibrido')}
                      onChange={() => toggleEventTypeFilter('hibrido')}
                      className="mr-2"
                    />
                    <label htmlFor="filter-hibrido" className="text-sm">
                      <Badge className={getEventTypeColor('hibrido')}>Híbrido</Badge>
                    </label>
                  </div>
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="filter-campanha"
                      checked={filteredEventTypes.includes('campanha')}
                      onChange={() => toggleEventTypeFilter('campanha')}
                      className="mr-2"
                    />
                    <label htmlFor="filter-campanha" className="text-sm">
                      <Badge className={getEventTypeColor('campanha')}>Campanha</Badge>
                    </label>
                  </div>
                </div>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-96 border rounded-lg bg-muted/20">
          <div className="text-center">
            <Spinner className="mx-auto" />
            <p className="mt-4 text-muted-foreground">Carregando eventos do calendário...</p>
          </div>
        </div>
      ) : (
        <div>
          {currentView === 'month' && renderMonthView()}
          {currentView === 'week' && renderWeekView()}
          {currentView === 'day' && renderDayView()}
        </div>
      )}

      {/* Modal de criação de evento */}
      <Dialog open={showAddEventDialog} onOpenChange={setShowAddEventDialog}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Criar Novo Evento</DialogTitle>
            <DialogDescription>
              Adicione um novo evento ao calendário da organização.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="titulo">Título</Label>
              <Input
                id="titulo"
                placeholder="Título do evento"
                value={newEvent.titulo}
                onChange={(e) => setNewEvent({ ...newEvent, titulo: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="data_inicio">Data de Início</Label>
                <Input
                  id="data_inicio"
                  type="datetime-local"
                  value={newEvent.data_inicio}
                  onChange={(e) => setNewEvent({ ...newEvent, data_inicio: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="data_fim">Data de Término</Label>
                <Input
                  id="data_fim"
                  type="datetime-local"
                  value={newEvent.data_fim}
                  onChange={(e) => setNewEvent({ ...newEvent, data_fim: e.target.value })}
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Switch
                id="dia_todo"
                checked={newEvent.dia_todo}
                onCheckedChange={(checked) => setNewEvent({ ...newEvent, dia_todo: checked })}
              />
              <Label htmlFor="dia_todo">Evento de dia inteiro</Label>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="tipo">Tipo de Evento</Label>
              <Select
                value={newEvent.tipo}
                onValueChange={(value) => setNewEvent({ ...newEvent, tipo: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo de evento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="presencial">Presencial</SelectItem>
                  <SelectItem value="online">Online</SelectItem>
                  <SelectItem value="hibrido">Híbrido</SelectItem>
                  <SelectItem value="campanha">Campanha</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="local">Local</Label>
              <Input
                id="local"
                placeholder="Local do evento"
                value={newEvent.local}
                onChange={(e) => setNewEvent({ ...newEvent, local: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="descricao">Descrição</Label>
              <Textarea
                id="descricao"
                placeholder="Descreva o evento"
                rows={3}
                value={newEvent.descricao}
                onChange={(e) => setNewEvent({ ...newEvent, descricao: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="cor">Cor</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="cor"
                  type="color"
                  className="w-12 h-10"
                  value={newEvent.cor}
                  onChange={(e) => setNewEvent({ ...newEvent, cor: e.target.value })}
                />
                <span className="text-sm text-muted-foreground">Selecione uma cor para o evento</span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddEventDialog(false)}>Cancelar</Button>
            <Button onClick={handleAddEvent} disabled={!newEvent.titulo}>Criar Evento</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de detalhes do evento */}
      <Dialog open={showEventDetailsDialog} onOpenChange={setShowEventDetailsDialog}>
        <DialogContent className="max-w-xl">
          {selectedEvent && (
            <>
              <DialogHeader>
                <div className="flex justify-between items-start">
                  <DialogTitle>{selectedEvent.titulo}</DialogTitle>
                  <Badge className={getEventTypeColor(selectedEvent.tipo)}>
                    {selectedEvent.tipo === 'presencial' && 'Presencial'}
                    {selectedEvent.tipo === 'online' && 'Online'}
                    {selectedEvent.tipo === 'hibrido' && 'Híbrido'}
                    {selectedEvent.tipo === 'campanha' && 'Campanha'}
                  </Badge>
                </div>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>
                    {format(parseISO(selectedEvent.data_inicio), 'PPp', { locale: ptBR })}
                    {!selectedEvent.dia_todo && ` - ${format(parseISO(selectedEvent.data_fim), 'p', { locale: ptBR })}`}
                    {selectedEvent.dia_todo && ' (Dia inteiro)'}
                  </span>
                </div>
                
                {selectedEvent.local && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{selectedEvent.local}</span>
                  </div>
                )}
                
                <Separator />
                
                <div>
                  <p className="text-sm">{selectedEvent.descricao}</p>
                </div>
                
                {selectedEvent.participantes && selectedEvent.participantes.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">Participantes</span>
                      </div>
                      <div className="space-y-2">
                        {selectedEvent.participantes.map(participante => (
                          <div key={participante.id} className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-medium">
                              {participante.nome.charAt(0)}
                            </div>
                            <div>
                              <p className="text-sm font-medium">{participante.nome}</p>
                              <p className="text-xs text-muted-foreground">{participante.email}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
              <DialogFooter className="gap-2 sm:gap-0">
                <Button 
                  variant="outline" 
                  className="text-red-600"
                  onClick={() => setConfirmDeleteDialog(true)}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Excluir
                </Button>
                <Button 
                  variant="default"
                  onClick={() => {
                    // Aqui, idealmente, abriríamos um modal de edição
                    // Por simplicidade, fecharemos a visualização
                    setShowEventDetailsDialog(false);
                  }}
                >
                  <Edit className="mr-2 h-4 w-4" />
                  Editar
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Modal de confirmação de exclusão */}
      <Dialog open={confirmDeleteDialog} onOpenChange={setConfirmDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir este evento? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setConfirmDeleteDialog(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleDeleteEvent}>
              Excluir Evento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}