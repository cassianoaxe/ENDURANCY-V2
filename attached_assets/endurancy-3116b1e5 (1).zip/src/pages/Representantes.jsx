import React, { useState, useEffect } from 'react';
import { Representante } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { UserPlus, Phone, Mail, MapPin, MoreHorizontal, Search, Filter, Download, Plus, UserCheck, UserX, DollarSign } from "lucide-react";

export default function Representantes() {
  const [representantes, setRepresentantes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');

  useEffect(() => {
    loadRepresentantes();
  }, []);

  const loadRepresentantes = async () => {
    try {
      setIsLoading(true);
      const result = await Representante.list('-data_cadastro');
      setRepresentantes(result);
    } catch (error) {
      console.error('Erro ao carregar representantes:', error);
      // Usar dados de demonstração caso a API falhe
      setRepresentantes([
        {
          id: '1',
          nome_completo: 'Carlos Oliveira',
          email: 'carlos@exemplo.com',
          telefone: '(11) 98765-4321',
          status: 'ativo',
          regiao_atuacao: ['São Paulo', 'Rio de Janeiro'],
          percentual_comissao: 7.5,
          data_cadastro: '2023-06-15T10:30:00Z'
        },
        {
          id: '2',
          nome_completo: 'Ana Silva',
          email: 'ana@exemplo.com',
          telefone: '(21) 99876-5432',
          status: 'ativo',
          regiao_atuacao: ['Minas Gerais', 'Espírito Santo'],
          percentual_comissao: 6,
          data_cadastro: '2023-07-20T14:45:00Z'
        },
        {
          id: '3',
          nome_completo: 'Roberto Santos',
          email: 'roberto@exemplo.com',
          telefone: '(31) 97654-3210',
          status: 'inativo',
          regiao_atuacao: ['Bahia', 'Sergipe'],
          percentual_comissao: 5,
          data_cadastro: '2023-05-10T09:15:00Z'
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredRepresentantes = representantes.filter(rep => {
    const matchesSearch = 
      rep.nome_completo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rep.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'todos' || rep.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'ativo':
        return <Badge className="bg-green-100 text-green-800">Ativo</Badge>;
      case 'inativo':
        return <Badge className="bg-gray-100 text-gray-800">Inativo</Badge>;
      case 'suspenso':
        return <Badge className="bg-yellow-100 text-yellow-800">Suspenso</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Representantes</h1>
          <p className="text-gray-500 mt-1">Gerencie os representantes de vendas da sua organização</p>
        </div>
        
        <div className="flex gap-3">
          <Link to={createPageUrl("NovoRepresentante")}>
            <Button className="flex gap-2 items-center">
              <UserPlus className="w-4 h-4" />
              Novo Representante
            </Button>
          </Link>
        </div>
      </div>
      
      <Tabs defaultValue="todos" className="w-full" onValueChange={setStatusFilter}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
          <TabsList className="bg-gray-100 dark:bg-gray-800">
            <TabsTrigger value="todos">Todos</TabsTrigger>
            <TabsTrigger value="ativo">Ativos</TabsTrigger>
            <TabsTrigger value="inativo">Inativos</TabsTrigger>
            <TabsTrigger value="suspenso">Suspensos</TabsTrigger>
          </TabsList>
          
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Buscar representante..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        <TabsContent value="todos" className="m-0">
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="flex flex-col items-center">
                    <div className="animate-spin h-8 w-8 border-4 border-green-500 rounded-full border-t-transparent"></div>
                    <p className="mt-4 text-gray-500">Carregando representantes...</p>
                  </div>
                </div>
              ) : filteredRepresentantes.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Contato</TableHead>
                      <TableHead>Região</TableHead>
                      <TableHead>Comissão</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Data de Cadastro</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRepresentantes.map((representante) => (
                      <TableRow key={representante.id}>
                        <TableCell className="font-medium">
                          <Link to={createPageUrl(`Representante?id=${representante.id}`)} className="hover:text-blue-600">
                            {representante.nome_completo}
                          </Link>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col space-y-1">
                            <div className="flex items-center space-x-1">
                              <Mail className="h-3 w-3 text-gray-400" />
                              <span className="text-xs">{representante.email}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Phone className="h-3 w-3 text-gray-400" />
                              <span className="text-xs">{representante.telefone}</span>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {representante.regiao_atuacao?.map((regiao, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {regiao}
                              </Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 text-green-500 mr-1" />
                            {representante.percentual_comissao}%
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(representante.status)}</TableCell>
                        <TableCell>{formatDate(representante.data_cadastro)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Abrir menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Link to={createPageUrl(`Representante?id=${representante.id}`)} className="w-full">
                                  Ver detalhes
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Link to={createPageUrl(`EditarRepresentante?id=${representante.id}`)} className="w-full">
                                  Editar
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Link to={createPageUrl(`ComissoesRepresentante?id=${representante.id}`)} className="w-full">
                                  Ver comissões
                                </Link>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center h-64">
                  <UserX className="h-12 w-12 text-gray-300 mb-4" />
                  <h3 className="text-lg font-semibold">Nenhum representante encontrado</h3>
                  <p className="text-gray-500 text-center mt-2 max-w-md">
                    {searchTerm
                      ? `Não encontramos representantes correspondentes à sua busca.`
                      : `Comece cadastrando seu primeiro representante de vendas.`}
                  </p>
                  <Link to={createPageUrl("NovoRepresentante")}>
                    <Button className="mt-4">Cadastrar Representante</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="ativo" className="m-0">
          {/* Mesmo conteúdo - filtrado automaticamente pelo valor da tab */}
        </TabsContent>
        
        <TabsContent value="inativo" className="m-0">
          {/* Mesmo conteúdo - filtrado automaticamente pelo valor da tab */}
        </TabsContent>
        
        <TabsContent value="suspenso" className="m-0">
          {/* Mesmo conteúdo - filtrado automaticamente pelo valor da tab */}
        </TabsContent>
      </Tabs>
    </div>
  );
}