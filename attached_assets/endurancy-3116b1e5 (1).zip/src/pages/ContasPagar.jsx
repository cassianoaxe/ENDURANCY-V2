import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  DollarSign,
  Plus,
  Filter,
  Download,
  ArrowUpCircle,
  Eye,
  Edit,
  Trash,
  CheckCircle,
  Calendar,
  Search,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function ContasPagar() {
  const navigate = useNavigate();
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPeriod, setFilterPeriod] = useState("month");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [paymentConfirmDialog, setPaymentConfirmDialog] = useState(false);

  // Dados simulados de contas a pagar
  const contas = [
    {
      id: "1",
      descricao: "Aluguel Sede",
      valor: 5000.00,
      vencimento: "2023-05-25",
      categoria: "Ocupação",
      fornecedor: "Imobiliária Central",
      status: "pendente",
      formaPagamento: "transferência",
      observacao: "Pagar até dia 25 para evitar multa"
    },
    {
      id: "2",
      descricao: "Folha de Pagamento",
      valor: 12500.00,
      vencimento: "2023-06-05",
      categoria: "Pessoal",
      fornecedor: "Funcionários",
      status: "pendente",
      formaPagamento: "transferência",
      observacao: "Incluir benefícios"
    },
    {
      id: "3",
      descricao: "Serviços Contábeis",
      valor: 1800.00,
      vencimento: "2023-06-10",
      categoria: "Administrativo",
      fornecedor: "Contabilidade Expressa",
      status: "pendente",
      formaPagamento: "transferência",
      observacao: ""
    },
    {
      id: "4",
      descricao: "Energia Elétrica",
      valor: 980.00,
      vencimento: "2023-06-12",
      categoria: "Utilidades",
      fornecedor: "Companhia Elétrica",
      status: "pendente",
      formaPagamento: "boleto",
      observacao: ""
    },
    {
      id: "5",
      descricao: "Internet e Telefone",
      valor: 450.00,
      vencimento: "2023-06-15",
      categoria: "Utilidades",
      fornecedor: "Telecom",
      status: "pendente",
      formaPagamento: "débito automático",
      observacao: ""
    },
    {
      id: "6",
      descricao: "Material de Escritório",
      valor: 350.00,
      vencimento: "2023-05-20",
      categoria: "Administrativo",
      fornecedor: "Papelaria Central",
      status: "pago",
      formaPagamento: "cartão corporativo",
      dataPagamento: "2023-05-18",
      observacao: ""
    },
    {
      id: "7",
      descricao: "Seguro Predial",
      valor: 3200.00,
      vencimento: "2023-06-10",
      categoria: "Seguro",
      fornecedor: "Seguradora Nacional",
      status: "pendente",
      formaPagamento: "boleto",
      observacao: "Renovação anual"
    },
    {
      id: "8",
      descricao: "Manutenção Sistema",
      valor: 750.00,
      vencimento: "2023-05-15",
      categoria: "Tecnologia",
      fornecedor: "IT Solutions",
      status: "pago",
      formaPagamento: "transferência",
      dataPagamento: "2023-05-15",
      observacao: ""
    }
  ];

  // Filtrar contas conforme os critérios selecionados
  const filteredContas = contas.filter(conta => {
    // Filtro de status
    if (filterStatus !== "all" && conta.status !== filterStatus) {
      return false;
    }

    // Filtro de busca
    if (searchTerm && !conta.descricao.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !conta.fornecedor.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }

    // Filtro de período
    const hoje = new Date();
    const vencimento = new Date(conta.vencimento);
    
    if (filterPeriod === "week") {
      const umaSemana = new Date();
      umaSemana.setDate(hoje.getDate() + 7);
      return vencimento <= umaSemana;
    } else if (filterPeriod === "month") {
      const umMes = new Date();
      umMes.setMonth(hoje.getMonth() + 1);
      return vencimento <= umMes;
    } else if (filterPeriod === "overdue") {
      return vencimento < hoje && conta.status === "pendente";
    }

    return true;
  });

  // Formatar data para exibição
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  // Verificar se a conta está vencida
  const isOverdue = (dateString) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const date = new Date(dateString);
    return date < today;
  };

  // Confirmar pagamento de uma conta
  const confirmPayment = () => {
    if (selectedAccount) {
      toast({
        title: "Pagamento registrado",
        description: `O pagamento de ${selectedAccount.descricao} foi registrado com sucesso.`,
      });
      setPaymentConfirmDialog(false);
      setSelectedAccount(null);
    }
  };

  // Excluir conta
  const handleDelete = (conta) => {
    toast({
      title: "Conta excluída",
      description: `A conta "${conta.descricao}" foi excluída com sucesso.`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Contas a Pagar</h1>
          <p className="text-gray-500 mt-1">
            Gerencie as obrigações financeiras da sua organização
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Exportar
          </Button>
          <Button onClick={() => navigate(createPageUrl("NovoContaPagar"))}>
            <Plus className="w-4 h-4 mr-2" />
            Nova Conta
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle>Contas Pendentes</CardTitle>
              <CardDescription>
                Total pendente nos próximos 30 dias: R$ 24.480,00
              </CardDescription>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar..."
                  className="pl-10 w-full sm:w-60"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full sm:w-40">
                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4" />
                    <SelectValue placeholder="Status" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Status</SelectItem>
                  <SelectItem value="pendente">Pendentes</SelectItem>
                  <SelectItem value="pago">Pagos</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={filterPeriod} onValueChange={setFilterPeriod}>
                <SelectTrigger className="w-full sm:w-40">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <SelectValue placeholder="Período" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Próxima Semana</SelectItem>
                  <SelectItem value="month">Próximo Mês</SelectItem>
                  <SelectItem value="overdue">Vencidas</SelectItem>
                  <SelectItem value="all">Todas</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Fornecedor</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead>Vencimento</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredContas.map((conta) => (
                  <TableRow key={conta.id}>
                    <TableCell className="font-medium">{conta.descricao}</TableCell>
                    <TableCell>{conta.fornecedor}</TableCell>
                    <TableCell>{conta.categoria}</TableCell>
                    <TableCell className={isOverdue(conta.vencimento) && conta.status === 'pendente' ? 'text-red-600 font-medium' : ''}>
                      {formatDate(conta.vencimento)}
                    </TableCell>
                    <TableCell className="text-right">R$ {conta.valor.toFixed(2)}</TableCell>
                    <TableCell>
                      <Badge className={
                        conta.status === 'pago' 
                          ? 'bg-green-100 text-green-800' 
                          : isOverdue(conta.vencimento) 
                            ? 'bg-red-100 text-red-800' 
                            : 'bg-amber-100 text-amber-800'
                      }>
                        {conta.status === 'pago' ? 'Pago' : isOverdue(conta.vencimento) ? 'Vencida' : 'Pendente'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => navigate(`${createPageUrl("DetalhesContaPagar")}?id=${conta.id}`)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {conta.status === 'pendente' && (
                          <>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => {
                                    setSelectedAccount(conta);
                                    setPaymentConfirmDialog(true);
                                  }}
                                >
                                  <CheckCircle className="h-4 w-4 text-green-600" />
                                </Button>
                              </DialogTrigger>
                              {selectedAccount && paymentConfirmDialog && (
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Confirmar Pagamento</DialogTitle>
                                    <DialogDescription>
                                      Confirme o pagamento de {selectedAccount.descricao}.
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div className="grid gap-4 py-4">
                                    <div className="grid grid-cols-4 items-center gap-4">
                                      <Label htmlFor="payment-date" className="text-right">
                                        Data do Pagamento
                                      </Label>
                                      <Input
                                        id="payment-date"
                                        type="date"
                                        defaultValue={new Date().toISOString().split('T')[0]}
                                        className="col-span-3"
                                      />
                                    </div>
                                    <div className="grid grid-cols-4 items-center gap-4">
                                      <Label htmlFor="payment-method" className="text-right">
                                        Forma de Pagamento
                                      </Label>
                                      <Select defaultValue={selectedAccount.formaPagamento}>
                                        <SelectTrigger id="payment-method" className="col-span-3">
                                          <SelectValue placeholder="Selecione" />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="transferência">Transferência</SelectItem>
                                          <SelectItem value="boleto">Boleto</SelectItem>
                                          <SelectItem value="pix">Pix</SelectItem>
                                          <SelectItem value="cartão corporativo">Cartão Corporativo</SelectItem>
                                          <SelectItem value="débito automático">Débito Automático</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>
                                    <div className="grid grid-cols-4 items-center gap-4">
                                      <Label htmlFor="payment-value" className="text-right">
                                        Valor Pago
                                      </Label>
                                      <Input
                                        id="payment-value"
                                        type="number"
                                        step="0.01"
                                        defaultValue={selectedAccount.valor}
                                        className="col-span-3"
                                      />
                                    </div>
                                    <div className="grid grid-cols-4 items-center gap-4">
                                      <Label htmlFor="payment-obs" className="text-right">
                                        Observações
                                      </Label>
                                      <Input
                                        id="payment-obs"
                                        placeholder="Observações opcionais"
                                        className="col-span-3"
                                      />
                                    </div>
                                  </div>
                                  <DialogFooter>
                                    <Button variant="outline" onClick={() => setPaymentConfirmDialog(false)}>
                                      Cancelar
                                    </Button>
                                    <Button onClick={confirmPayment}>
                                      Confirmar Pagamento
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              )}
                            </Dialog>
                            
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => navigate(`${createPageUrl("EditarContaPagar")}?id=${conta.id}`)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                >
                                  <Trash className="h-4 w-4 text-red-600" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem 
                                  className="text-red-600"
                                  onClick={() => handleDelete(conta)}
                                >
                                  Confirmar exclusão
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                
                {filteredContas.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">
                      <div className="flex flex-col items-center justify-center">
                        <FileText className="h-10 w-10 text-gray-300 mb-2" />
                        <p className="text-lg font-medium text-gray-900 mb-1">Nenhuma conta encontrada</p>
                        <p className="text-gray-500">Não existem contas correspondentes aos filtros aplicados.</p>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-sm text-gray-500">
            Exibindo {filteredContas.length} de {contas.length} contas
          </div>
          <div className="flex items-center gap-2">
            <p className="font-medium">Total filtrado:</p>
            <p className="font-bold">
              R$ {filteredContas.reduce((acc, conta) => acc + conta.valor, 0).toFixed(2)}
            </p>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}