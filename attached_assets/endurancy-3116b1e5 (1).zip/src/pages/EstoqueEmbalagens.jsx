import React, { useState, useEffect } from 'react';
import EstoqueBaseView from '../components/estoque/EstoqueBaseView';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function EstoqueEmbalagens() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [tipoFilter, setTipoFilter] = useState("all");
  const [categoriaFilter, setCategoriaFilter] = useState("all");

  useEffect(() => {
    const loadData = async () => {
      const mockData = [
        {
          id: "1",
          codigo: "EMB-FR30-001",
          nome: "Frasco Âmbar 30ml",
          lote: "L202301",
          quantidade_atual: 5000,
          quantidade_minima: 2000,
          unidade_medida: "unidade",
          status: "disponivel",
          data_validade: "2025-12-31",
          tipo: "frasco",
          categoria: "primaria"
        },
        {
          id: "2",
          codigo: "EMB-CT30-001",
          nome: "Conta-gotas 30ml",
          lote: "L202302",
          quantidade_atual: 4800,
          quantidade_minima: 2000,
          unidade_medida: "unidade",
          status: "disponivel",
          data_validade: "2025-12-31",
          tipo: "conta_gotas",
          categoria: "primaria"
        }
      ];
      
      setData(mockData);
      setLoading(false);
    };

    setTimeout(loadData, 1000);
  }, []);

  const customFilters = (
    <div className="flex gap-2">
      <Select value={tipoFilter} onValueChange={setTipoFilter}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Tipo" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todos Tipos</SelectItem>
          <SelectItem value="frasco">Frascos</SelectItem>
          <SelectItem value="conta_gotas">Conta-gotas</SelectItem>
          <SelectItem value="tampa">Tampas</SelectItem>
          <SelectItem value="bisnaga">Bisnagas</SelectItem>
          <SelectItem value="caixa">Caixas</SelectItem>
        </SelectContent>
      </Select>

      <Select value={categoriaFilter} onValueChange={setCategoriaFilter}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Categoria" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todas Categorias</SelectItem>
          <SelectItem value="primaria">Primária</SelectItem>
          <SelectItem value="secundaria">Secundária</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );

  return (
    <EstoqueBaseView
      title="Estoque de Embalagens"
      description="Gestão de estoque de embalagens primárias e secundárias"
      tipoEstoque="embalagem"
      data={data}
      loading={loading}
      onAddItem={() => console.log("Adicionar item")}
      onEditItem={(item) => console.log("Editar item", item)}
      onViewDetails={(item) => console.log("Ver detalhes", item)}
      customFilters={customFilters}
    />
  );
}