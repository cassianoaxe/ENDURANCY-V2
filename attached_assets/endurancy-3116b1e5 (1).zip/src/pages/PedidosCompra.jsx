import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ShoppingBag, 
  Search, 
  Filter, 
  Plus, 
  Clock, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Truck, 
  Download, 
  FileCheck,
  ShoppingCart,
  Calendar,
  DollarSign,
  User,
  Building
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { 
  Table, 
  TableHeader, 
  TableBody, 
  TableHead, 
  TableRow, 
  TableCell 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription, 
  DialogFooter 
} from "@/components/ui/dialog";

// Dados simulados para pedidos de compra
const mockPedidos = [
  {
    id: "ped-001",
    numero_pedido: "PC-2023-0001",
    data_pedido: "2023-06-10T14:30:00Z",
    solicitante: {
      id: "user-001",
      nome: "Carlos Mendes",
      setor: "Laboratório"
    },
    fornecedor: {
      id: "forn-001",
      nome: "Sigma Aldrich"
    },
    valor_total: 7250.30,
    status: "aprovado",
    data_aprovacao: "2023-06-11T09:45:00Z",
    previsao_entrega: "2023-06-20",
    itens: [
      {
        id: "item-001",
        produto_id: "LAB-R001",
        descricao: "Reagente para PCR",
        quantidade: 15,
        unidade_medida: "unidade",
        valor_unitario: 450.50,
        valor_total: 6757.50
      },
      {
        id: "item-002",
        produto_id: "LAB-AUX001",
        descricao: "Pipetas descartáveis",
        quantidade: 100,
        unidade_medida: "unidade",
        valor_unitario: 4.928,
        valor_total: 492.80
      }
    ],
    documento_relacionado: {
      numero: "SC-2023-0001",
      tipo: "solicitacao_compra",
    }
  },
  {
    id: "ped-002",
    numero_pedido: "PC-2023-0002",
    data_pedido: "2023-06-12T10:15:00Z",
    solicitante: {
      id: "user-002",
      nome: "Ana Silva",
      setor: "Produção"
    },
    fornecedor: {
      id: "forn-002",
      nome: "EmbalaFarma"
    },
    valor_total: 3850.00,
    status: "aguardando_entrega",
    data_aprovacao: "2023-06-13T11:20:00Z",
    previsao_entrega: "2023-06-22",
    itens: [
      {
        id: "item-003",
        produto_id: "EMB-001",
        descricao: "Embalagens Primárias 100ml",
        quantidade: 1000,
        unidade_medida: "unidade",
        valor_unitario: 3.85,
        valor_total: 3850.00
      }
    ],
    documento_relacionado: {
      numero: "SC-2023-0002",
      tipo: "solicitacao_compra",
    }
  },
  {
    id: "ped-003",
    numero_pedido: "PC-2023-0003",
    data_pedido: "2023-06-15T09:30:00Z",
    solicitante: {
      id: "user-003",
      nome: "Paulo Sousa",
      setor: "TI"
    },
    fornecedor: {
      id: "forn-003",
      nome: "Dell Computadores"
    },
    valor_total: 10400.00,
    status: "pendente",
    data_aprovacao: null,
    previsao_entrega: null,
    itens: [
      {
        id: "item-004",
        produto_id: "TI-002",
        descricao: "Notebook Dell Latitude",
        quantidade: 2,
        unidade_medida: "unidade",
        valor_unitario: 5200.00,
        valor_total: 10400.00
      }
    ],
    documento_relacionado: {
      numero: "SC-2023-0003",
      tipo: "solicitacao_compra",
    }
  },
  {
    id: "ped-004",
    numero_pedido: "PC-2023-0004",
    data_pedido: "2023-06-08T14:20:00Z",
    solicitante: {
      id: "user-004",
      nome: "Maria Oliveira",
      setor: "Administrativo"
    },
    fornecedor: {
      id: "forn-004",
      nome: "Papelaria Express"
    },
    valor_total: 1295.00,
    status: "recebido",
    data_aprovacao: "2023-06-09T10:30:00Z",
    previsao_entrega: "2023-06-16",
    data_recebimento: "2023-06-15T11:45:00Z",
    itens: [
      {
        id: "item-005",
        produto_id: "ESC-001",
        descricao: "Papel A4",
        quantidade: 50,
        unidade_medida: "resma",
        valor_unitario: 25.90,
        valor_total: 1295.00
      }
    ],
    documento_relacionado: {
      numero: "SC-2023-0004",
      tipo: "solicitacao_compra",
    }
  },
  {
    id: "ped-005",
    numero_pedido: "PC-2023-0005",
    data_pedido: "2023-06-14T11:10:00Z",
    solicitante: {
      id: "user-002",
      nome: "Ana Silva",
      setor: "Produção"
    },
    fornecedor: {
      id: "forn-005",
      nome: "GraficaPharma"
    },
    valor_total: 2400.00,
    status: "rejeitado",
    data_aprovacao: null,
    previsao_entrega: null,
    itens: [
      {
        id: "item-006",
        produto_id: "EMB-002",
        descricao: "Rótulos Adesivos",
        quantidade: 2000,
        unidade_medida: "unidade",
        valor_unitario: 1.20,
        valor_total: 2400.00
      }
    ],
    documento_relacionado: {
      numero: "SC-2023-0005",
      tipo: "solicitacao_compra",
    },
    motivo_rejeicao: "Valor acima do orçamento previsto. Solicitar novas cotações."
  }
];

export default function PedidosCompra() {
  const navigate = useNavigate();
  const [pedidos, setPedidos] = useState([]);
  const [filteredPedidos, setFilteredPedidos] = useState([]);
  const [selectedStatus, setSelectedStatus] = useState("todos");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPedido, setSelectedPedido] = useState(null);
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("aguardando");

  useEffect(() => {
    // Simulação de carregamento de dados
    setTimeout(() => {
      setPedidos(mockPedidos);
      setFilteredPedidos(mockPedidos);
      setLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    let filtered = [...pedidos];
    
    // Filtro por status
    if (selectedStatus !== "todos") {
      filtered = filtered.filter(pedido => pedido.status === selectedStatus);
    }
    
    // Filtro por termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(pedido => 
        pedido.numero_pedido.toLowerCase().includes(term) || 
        pedido.solicitante.nome.toLowerCase().includes(term) ||
        pedido.fornecedor.nome.toLowerCase().includes(term)
      );
    }
    
    // Filtro por tab
    if (activeTab === "aguardando") {
      filtered = filtered.filter(pedido => 
        pedido.status === "pendente" || 
        pedido.status === "aprovado" || 
        pedido.status === "aguardando_entrega"
      );
    } else if (activeTab === "recebidos") {
      filtered = filtered.filter(pedido => pedido.status === "recebido");
    } else if (activeTab === "todos") {
      // Mantém todos os pedidos
    } else if (activeTab === "rejeitados") {
      filtered = filtered.filter(pedido => pedido.status === "rejeitado");
    }
    
    setFilteredPedidos(filtered);
  }, [pedidos, selectedStatus, searchTerm, activeTab]);

  const getStatusBadge = (status) => {
    switch(status) {
      case 'pendente':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'aprovado':
        return <Badge className="bg-blue-100 text-blue-800">Aprovado</Badge>;
      case 'aguardando_entrega':
        return <Badge className="bg-purple-100 text-purple-800">Aguardando Entrega</Badge>;
      case 'recebido':
        return <Badge className="bg-green-100 text-green-800">Recebido</Badge>;
      case 'rejeitado':
        return <Badge className="bg-red-100 text-red-800">Rejeitado</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "—";
    
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return "—";
    
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const handleViewDetails = (pedido) => {
    setSelectedPedido(pedido);
    setDetailsDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Pedidos de Compra</h1>
          <p className="text-gray-500 mt-1">
            Gerencie os pedidos de compra da organização
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button 
            onClick={() => navigate(createPageUrl("NovaSolicitacaoCompra"))}
            className="bg-green-600 hover:bg-green-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nova Solicitação
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="aguardando" className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            <span>Em Andamento</span>
          </TabsTrigger>
          <TabsTrigger value="recebidos" className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Recebidos</span>
          </TabsTrigger>
          <TabsTrigger value="rejeitados" className="flex items-center gap-2">
            <XCircle className="w-4 h-4" />
            <span>Rejeitados</span>
          </TabsTrigger>
          <TabsTrigger value="todos" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            <span>Todos</span>
          </TabsTrigger>
        </TabsList>
        
        <Card className="mt-6">
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <CardTitle>Pedidos de Compra</CardTitle>
              
              <div className="flex flex-wrap gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Buscar pedidos..."
                    className="pl-9"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-full md:w-[200px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os Status</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="aprovado">Aprovado</SelectItem>
                    <SelectItem value="aguardando_entrega">Aguardando Entrega</SelectItem>
                    <SelectItem value="recebido">Recebido</SelectItem>
                    <SelectItem value="rejeitado">Rejeitado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-[60vh]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Número</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Solicitante</TableHead>
                    <TableHead>Fornecedor</TableHead>
                    <TableHead className="text-right">Valor Total</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Previsão de Entrega</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    Array(5).fill(0).map((_, i) => (
                      <TableRow key={i}>
                        <TableCell colSpan={8} className="h-16 animate-pulse">
                          <div className="w-full h-4 bg-gray-200 rounded"></div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : filteredPedidos.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="h-24 text-center">
                        <div className="flex flex-col items-center justify-center">
                          <ShoppingCart className="h-8 w-8 text-gray-300 mb-1" />
                          <span className="text-gray-500">Nenhum pedido encontrado</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredPedidos.map((pedido) => (
                      <TableRow key={pedido.id} className="h-16">
                        <TableCell className="font-medium">{pedido.numero_pedido}</TableCell>
                        <TableCell>{formatDate(pedido.data_pedido)}</TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span>{pedido.solicitante.nome}</span>
                            <span className="text-xs text-gray-500">{pedido.solicitante.setor}</span>
                          </div>
                        </TableCell>
                        <TableCell>{pedido.fornecedor.nome}</TableCell>
                        <TableCell className="text-right font-medium">
                          {formatCurrency(pedido.valor_total)}
                        </TableCell>
                        <TableCell>{getStatusBadge(pedido.status)}</TableCell>
                        <TableCell>
                          {pedido.previsao_entrega 
                            ? formatDate(pedido.previsao_entrega) 
                            : "—"}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => handleViewDetails(pedido)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleViewDetails(pedido)}>
                                  <Eye className="mr-2 h-4 w-4" />
                                  <span>Ver detalhes</span>
                                </DropdownMenuItem>
                                
                                {pedido.status === 'pendente' && (
                                  <>
                                    <DropdownMenuItem>
                                      <CheckCircle2 className="mr-2 h-4 w-4" />
                                      <span>Aprovar pedido</span>
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <XCircle className="mr-2 h-4 w-4" />
                                      <span>Rejeitar pedido</span>
                                    </DropdownMenuItem>
                                  </>
                                )}
                                
                                {pedido.status === 'aprovado' && (
                                  <DropdownMenuItem>
                                    <Truck className="mr-2 h-4 w-4" />
                                    <span>Registrar envio</span>
                                  </DropdownMenuItem>
                                )}
                                
                                {pedido.status === 'aguardando_entrega' && (
                                  <DropdownMenuItem>
                                    <CheckCircle2 className="mr-2 h-4 w-4" />
                                    <span>Confirmar recebimento</span>
                                  </DropdownMenuItem>
                                )}
                                
                                <DropdownMenuSeparator />
                                
                                <DropdownMenuItem>
                                  <Download className="mr-2 h-4 w-4" />
                                  <span>Baixar PDF</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </ScrollArea>
          </CardContent>
        </Card>
      </Tabs>
      
      {/* Diálogo de Detalhes do Pedido */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Pedido</DialogTitle>
            <DialogDescription>
              Informações completas sobre o pedido de compra
            </DialogDescription>
          </DialogHeader>
          
          {selectedPedido && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-500">Número do Pedido</h3>
                    <p className="font-medium">{selectedPedido.numero_pedido}</p>
                  </div>
                  
                  <div className="space-y-2 mt-4">
                    <h3 className="text-sm font-medium text-gray-500">Solicitação de Origem</h3>
                    <p>{selectedPedido.documento_relacionado.numero}</p>
                  </div>
                  
                  <div className="space-y-2 mt-4">
                    <h3 className="text-sm font-medium text-gray-500">Status</h3>
                    {getStatusBadge(selectedPedido.status)}
                    
                    {selectedPedido.status === 'rejeitado' && selectedPedido.motivo_rejeicao && (
                      <div className="mt-1 text-sm text-red-600">
                        <p><span className="font-medium">Motivo da rejeição:</span> {selectedPedido.motivo_rejeicao}</p>
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-500">Data do Pedido</h3>
                    <p>{formatDateTime(selectedPedido.data_pedido)}</p>
                  </div>
                  
                  <div className="space-y-2 mt-4">
                    <h3 className="text-sm font-medium text-gray-500">Solicitante</h3>
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-gray-400" />
                      <p>{selectedPedido.solicitante.nome}</p>
                    </div>
                    <p className="text-sm text-gray-500">{selectedPedido.solicitante.setor}</p>
                  </div>
                  
                  <div className="space-y-2 mt-4">
                    <h3 className="text-sm font-medium text-gray-500">Fornecedor</h3>
                    <div className="flex items-center gap-2">
                      <Building className="w-4 h-4 text-gray-400" />
                      <p>{selectedPedido.fornecedor.nome}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-sm font-medium text-gray-500">Datas</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span>Aprovação:</span>
                      <span>{formatDate(selectedPedido.data_aprovacao)}</span>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span>Previsão de Entrega:</span>
                      <span>{formatDate(selectedPedido.previsao_entrega)}</span>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span>Recebimento:</span>
                      <span>{formatDate(selectedPedido.data_recebimento)}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-gray-500">Itens do Pedido</h3>
                
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Código</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead className="text-center">Qtd.</TableHead>
                      <TableHead className="text-center">Un.</TableHead>
                      <TableHead className="text-right">Valor Unit.</TableHead>
                      <TableHead className="text-right">Valor Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedPedido.itens.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.produto_id}</TableCell>
                        <TableCell>{item.descricao}</TableCell>
                        <TableCell className="text-center">{item.quantidade}</TableCell>
                        <TableCell className="text-center">{item.unidade_medida}</TableCell>
                        <TableCell className="text-right">
                          {formatCurrency(item.valor_unitario)}
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          {formatCurrency(item.valor_total)}
                        </TableCell>
                      </TableRow>
                    ))}
                    <TableRow>
                      <TableCell colSpan={5} className="text-right font-medium">
                        Valor Total:
                      </TableCell>
                      <TableCell className="text-right font-bold">
                        {formatCurrency(selectedPedido.valor_total)}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
          
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDetailsDialogOpen(false)}>
              Fechar
            </Button>
            
            {selectedPedido && selectedPedido.status === 'pendente' && (
              <>
                <Button variant="destructive" className="gap-2">
                  <XCircle className="w-4 h-4" />
                  Rejeitar
                </Button>
                <Button className="gap-2 bg-green-600 hover:bg-green-700">
                  <CheckCircle2 className="w-4 h-4" />
                  Aprovar
                </Button>
              </>
            )}
            
            {selectedPedido && selectedPedido.status === 'aprovado' && (
              <Button className="gap-2">
                <Truck className="w-4 h-4" />
                Registrar Envio
              </Button>
            )}
            
            {selectedPedido && selectedPedido.status === 'aguardando_entrega' && (
              <Button className="gap-2 bg-green-600 hover:bg-green-700">
                <CheckCircle2 className="w-4 h-4" />
                Confirmar Recebimento
              </Button>
            )}
            
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Baixar PDF
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}