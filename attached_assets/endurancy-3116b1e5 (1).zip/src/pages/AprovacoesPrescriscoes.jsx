import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { PrescricaoFarmaceutica } from '@/api/entities';
import { User } from '@/api/entities';
import { toast } from '@/components/ui/use-toast';
import {
  ClipboardCheck,
  Search,
  Filter,
  CheckCircle,
  XCircle,
  Eye,
  Download,
  RefreshCw,
  MoreHorizontal,
  FileText,
  Calendar,
  Clock,
  AlertCircle,
  MessageSquare,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Spinner } from '@/components/ui/spinner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function AprovacoesPrescriscoes() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [prescricoes, setPrescricoes] = useState([]);
  const [filteredPrescricoes, setFilteredPrescricoes] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedPrescricao, setSelectedPrescricao] = useState(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [showApprovalDialog, setShowApprovalDialog] = useState(false);
  const [showRejectionDialog, setShowRejectionDialog] = useState(false);
  const [comments, setComments] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [processingAction, setProcessingAction] = useState(false);

  useEffect(() => {
    loadPrescricoes();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [prescricoes, statusFilter, searchTerm]);

  const loadPrescricoes = async () => {
    setLoading(true);
    try {
      // In a real app, we would fetch from the database
      // const fetchedPrescricoes = await PrescricaoFarmaceutica.list('-data_envio');

      // Using mock data for now
      setTimeout(() => {
        const mockData = generateMockPrescricoes();
        setPrescricoes(mockData);
        setFilteredPrescricoes(mockData);
        setLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Error loading prescriptions', error);
      setLoading(false);
      toast({
        title: "Erro ao carregar prescrições",
        description: "Não foi possível carregar as prescrições para análise",
        variant: "destructive"
      });
    }
  };

  const generateMockPrescricoes = () => {
    return [
      {
        id: '1',
        paciente_id: 'user_123',
        paciente_nome: 'João Silva',
        paciente_avatar: 'JS',
        arquivo_url: 'https://example.com/prescricao1.pdf',
        data_envio: new Date(Date.now() - 2 * 3600000).toISOString(), // 2 hours ago
        status: 'pendente',
        validade_prescricao: new Date(Date.now() + 90 * 86400000).toISOString(), // 90 days from now
        dados_medico: {
          nome: 'Dr. Ricardo Almeida',
          crm: '12345-SP',
          especialidade: 'Neurologia'
        }
      },
      {
        id: '2',
        paciente_id: 'user_456',
        paciente_nome: 'Maria Oliveira',
        paciente_avatar: 'MO',
        arquivo_url: 'https://example.com/prescricao2.pdf',
        data_envio: new Date(Date.now() - 1 * 86400000).toISOString(), // 1 day ago
        status: 'pendente',
        validade_prescricao: new Date(Date.now() + 60 * 86400000).toISOString(), // 60 days from now
        dados_medico: {
          nome: 'Dra. Carla Mendes',
          crm: '54321-SP',
          especialidade: 'Psiquiatria'
        }
      },
      {
        id: '3',
        paciente_id: 'user_789',
        paciente_nome: 'Pedro Santos',
        paciente_avatar: 'PS',
        arquivo_url: 'https://example.com/prescricao3.pdf',
        data_envio: new Date(Date.now() - 3 * 86400000).toISOString(), // 3 days ago
        status: 'aprovada',
        validade_prescricao: new Date(Date.now() + 180 * 86400000).toISOString(), // 180 days from now
        data_analise: new Date(Date.now() - 2 * 86400000).toISOString(), // 2 days ago
        farmaceutico_id: 'user_999',
        dados_medico: {
          nome: 'Dr. Paulo Rodrigues',
          crm: '98765-SP',
          especialidade: 'Clínica Médica'
        },
        produtos_prescritos: [
          {
            nome: 'Óleo CBD 10%',
            dosagem: '30mg/ml',
            posologia: '15 gotas, 2x ao dia',
            quantidade: 1
          }
        ],
        observacoes_farmaceutico: 'Prescrição válida e completa. Aprovada sem restrições.'
      },
      {
        id: '4',
        paciente_id: 'user_101',
        paciente_nome: 'Ana Beatriz',
        paciente_avatar: 'AB',
        arquivo_url: 'https://example.com/prescricao4.pdf',
        data_envio: new Date(Date.now() - 5 * 86400000).toISOString(), // 5 days ago
        status: 'rejeitada',
        validade_prescricao: new Date(Date.now() + 45 * 86400000).toISOString(), // 45 days from now
        data_analise: new Date(Date.now() - 4 * 86400000).toISOString(), // 4 days ago
        farmaceutico_id: 'user_999',
        dados_medico: {
          nome: 'Dra. Maria Silva',
          crm: '23456-SP',
          especialidade: 'Neurologia'
        },
        motivo_rejeicao: 'A prescrição está ilegível. Por favor, solicite ao paciente que envie uma digitalização mais clara.'
      }
    ];
  };

  const applyFilters = () => {
    let filtered = [...prescricoes];
    
    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(item => item.status === statusFilter);
    }
    
    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(
        item => (item.paciente_nome?.toLowerCase().includes(term)) || 
                (item.dados_medico?.nome?.toLowerCase().includes(term)) || 
                (item.dados_medico?.crm?.toLowerCase().includes(term))
      );
    }
    
    setFilteredPrescricoes(filtered);
  };

  const handleViewDetails = (prescricao) => {
    setSelectedPrescricao(prescricao);
    setShowDetailsDialog(true);
  };

  const handleShowApproval = (prescricao) => {
    setSelectedPrescricao(prescricao);
    setComments('');
    setShowApprovalDialog(true);
  };

  const handleShowRejection = (prescricao) => {
    setSelectedPrescricao(prescricao);
    setRejectionReason('');
    setShowRejectionDialog(true);
  };

  const handleApprove = async () => {
    setProcessingAction(true);
    try {
      // In a real app, we would update the database
      // await PrescricaoFarmaceutica.update(selectedPrescricao.id, {
      //   status: 'aprovada',
      //   data_analise: new Date().toISOString(),
      //   farmaceutico_id: currentUser.id,
      //   observacoes_farmaceutico: comments
      // });

      // Update local state instead
      setPrescricoes(prevState => 
        prevState.map(item => 
          item.id === selectedPrescricao.id 
            ? { 
                ...item, 
                status: 'aprovada', 
                data_analise: new Date().toISOString(),
                farmaceutico_id: 'current_user_id',
                observacoes_farmaceutico: comments
              } 
            : item
        )
      );

      toast({
        title: "Prescrição aprovada",
        description: "A prescrição foi aprovada com sucesso.",
      });

      setShowApprovalDialog(false);
    } catch (error) {
      console.error('Error approving prescription', error);
      toast({
        title: "Erro ao aprovar prescrição",
        description: "Não foi possível aprovar a prescrição. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setProcessingAction(false);
    }
  };

  const handleReject = async () => {
    if (!rejectionReason.trim()) {
      toast({
        title: "Motivo da rejeição obrigatório",
        description: "Por favor, informe o motivo da rejeição para continuar.",
        variant: "destructive"
      });
      return;
    }

    setProcessingAction(true);
    try {
      // In a real app, we would update the database
      // await PrescricaoFarmaceutica.update(selectedPrescricao.id, {
      //   status: 'rejeitada',
      //   data_analise: new Date().toISOString(),
      //   farmaceutico_id: currentUser.id,
      //   motivo_rejeicao: rejectionReason
      // });

      // Update local state instead
      setPrescricoes(prevState => 
        prevState.map(item => 
          item.id === selectedPrescricao.id 
            ? { 
                ...item, 
                status: 'rejeitada', 
                data_analise: new Date().toISOString(),
                farmaceutico_id: 'current_user_id',
                motivo_rejeicao: rejectionReason
              } 
            : item
        )
      );

      toast({
        title: "Prescrição rejeitada",
        description: "A prescrição foi rejeitada e o paciente será notificado.",
      });

      setShowRejectionDialog(false);
    } catch (error) {
      console.error('Error rejecting prescription', error);
      toast({
        title: "Erro ao rejeitar prescrição",
        description: "Não foi possível rejeitar a prescrição. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setProcessingAction(false);
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'pendente':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Pendente</Badge>;
      case 'aprovada':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Aprovada</Badge>;
      case 'rejeitada':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Rejeitada</Badge>;
      case 'solicitado_alteracao':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Alteração solicitada</Badge>;
      default:
        return <Badge variant="outline">Desconhecido</Badge>;
    }
  };

  const formatDateTime = (dateString) => {
    try {
      return format(parseISO(dateString), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR });
    } catch (e) {
      return dateString || "Data não disponível";
    }
  };

  const formatDate = (dateString) => {
    try {
      return format(parseISO(dateString), "dd/MM/yyyy", { locale: ptBR });
    } catch (e) {
      return dateString || "Data não disponível";
    }
  };

  const handleRefresh = () => {
    loadPrescricoes();
  };

  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-2xl font-bold">Aprovação de Prescrições</h1>
          <p className="text-muted-foreground">
            Analise e aprove prescrições médicas enviadas pelos pacientes
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          className="flex items-center"
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          Atualizar
        </Button>
      </div>

      <Tabs defaultValue="all" onValueChange={setStatusFilter} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all" className="flex items-center gap-2">
            <ClipboardCheck className="h-4 w-4" />
            <span>Todas</span>
          </TabsTrigger>
          <TabsTrigger value="pendente" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>Pendentes</span>
            <Badge className="ml-1 bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
              {prescricoes.filter(p => p.status === 'pendente').length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="aprovada" className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            <span>Aprovadas</span>
          </TabsTrigger>
          <TabsTrigger value="rejeitada" className="flex items-center gap-2">
            <XCircle className="h-4 w-4" />
            <span>Rejeitadas</span>
          </TabsTrigger>
        </TabsList>
        
        <div className="mb-6 mt-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Buscar por paciente, médico ou CRM..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <TabsContent value={statusFilter} className="mt-0">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>
                {statusFilter === 'all' ? 'Todas as Prescrições' : 
                 statusFilter === 'pendente' ? 'Prescrições Pendentes' :
                 statusFilter === 'aprovada' ? 'Prescrições Aprovadas' : 'Prescrições Rejeitadas'}
              </CardTitle>
              <CardDescription>
                {filteredPrescricoes.length} prescrições encontradas
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center items-center py-12">
                  <Spinner />
                  <span className="ml-3 text-gray-500">Carregando prescrições...</span>
                </div>
              ) : filteredPrescricoes.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium">Nenhuma prescrição encontrada</h3>
                  <p className="text-gray-500 mt-2">
                    Não existem prescrições que correspondam aos critérios selecionados.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Paciente</TableHead>
                        <TableHead>Médico</TableHead>
                        <TableHead>CRM</TableHead>
                        <TableHead>Data de Envio</TableHead>
                        <TableHead>Validade</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPrescricoes.map((prescricao) => (
                        <TableRow key={prescricao.id} className="cursor-pointer hover:bg-gray-50" onClick={() => handleViewDetails(prescricao)}>
                          <TableCell>
                            <div className="flex items-center">
                              <Avatar className="h-8 w-8 mr-2">
                                <AvatarFallback>{prescricao.paciente_avatar}</AvatarFallback>
                              </Avatar>
                              <span className="font-medium">{prescricao.paciente_nome}</span>
                            </div>
                          </TableCell>
                          <TableCell>{prescricao.dados_medico?.nome}</TableCell>
                          <TableCell>{prescricao.dados_medico?.crm}</TableCell>
                          <TableCell>{formatDateTime(prescricao.data_envio)}</TableCell>
                          <TableCell>{formatDate(prescricao.validade_prescricao)}</TableCell>
                          <TableCell>{getStatusBadge(prescricao.status)}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end">
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleViewDetails(prescricao);
                                }}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              {prescricao.status === 'pendente' && (
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                                    <Button variant="ghost" size="icon">
                                      <MoreHorizontal className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem onClick={(e) => {
                                      e.stopPropagation();
                                      handleShowApproval(prescricao);
                                    }}>
                                      <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                                      Aprovar
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={(e) => {
                                      e.stopPropagation();
                                      handleShowRejection(prescricao);
                                    }}>
                                      <XCircle className="mr-2 h-4 w-4 text-red-500" />
                                      Rejeitar
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Detalhes da Prescrição</DialogTitle>
            <DialogDescription>
              Análise detalhada da prescrição médica
            </DialogDescription>
          </DialogHeader>

          {selectedPrescricao && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-semibold text-lg">Prescrição Médica</h3>
                  <p className="text-sm text-gray-500">Enviada em {formatDateTime(selectedPrescricao.data_envio)}</p>
                </div>
                <div className="flex items-center gap-3">
                  {getStatusBadge(selectedPrescricao.status)}
                  {selectedPrescricao.status === 'pendente' && (
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="border-red-200 text-red-600 hover:bg-red-50"
                        onClick={() => {
                          setShowDetailsDialog(false);
                          setTimeout(() => {
                            handleShowRejection(selectedPrescricao);
                          }, 100);
                        }}
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        Rejeitar
                      </Button>
                      <Button 
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => {
                          setShowDetailsDialog(false);
                          setTimeout(() => {
                            handleShowApproval(selectedPrescricao);
                          }, 100);
                        }}
                      >
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Aprovar
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-1">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Paciente</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-3 mb-3">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback>{selectedPrescricao.paciente_avatar}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{selectedPrescricao.paciente_nome}</p>
                          <p className="text-sm text-gray-500">ID: {selectedPrescricao.paciente_id}</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="w-full" onClick={() => navigate(createPageUrl(`Paciente/${selectedPrescricao.paciente_id}`))}>
                        <ExternalLink className="mr-2 h-4 w-4" />
                        Ver perfil do paciente
                      </Button>
                    </CardContent>
                  </Card>
                </div>

                <div className="md:col-span-2">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Informações da Prescrição</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-500">Médico Prescritor</p>
                          <p className="font-medium">{selectedPrescricao.dados_medico?.nome}</p>
                          <p className="text-sm">{selectedPrescricao.dados_medico?.crm} - {selectedPrescricao.dados_medico?.especialidade}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Validade</p>
                          <p className="font-medium">{formatDate(selectedPrescricao.validade_prescricao)}</p>
                          <p className="text-sm">
                            {new Date(selectedPrescricao.validade_prescricao) > new Date() 
                              ? "Prescrição válida" 
                              : "Prescrição expirada"}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Documento da Prescrição</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col items-center justify-center py-8 border-2 border-dashed rounded-lg">
                    <FileText className="h-16 w-16 text-gray-400 mb-3" />
                    <p className="text-sm text-gray-500 mb-3">Visualize ou baixe a prescrição digitalizada</p>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="flex items-center">
                        <Eye className="mr-2 h-4 w-4" />
                        Visualizar
                      </Button>
                      <Button variant="outline" size="sm" className="flex items-center">
                        <Download className="mr-2 h-4 w-4" />
                        Baixar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {selectedPrescricao.status !== 'pendente' && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Análise Farmacêutica</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-gray-500">Data da Análise</p>
                        <p className="font-medium">{formatDateTime(selectedPrescricao.data_analise)}</p>
                      </div>
                      {selectedPrescricao.status === 'aprovada' && (
                        <div>
                          <p className="text-sm text-gray-500">Observações</p>
                          <p className="font-medium">{selectedPrescricao.observacoes_farmaceutico || "Nenhuma observação"}</p>
                        </div>
                      )}
                      {selectedPrescricao.status === 'rejeitada' && (
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Motivo da Rejeição</p>
                          <div className="bg-red-50 text-red-800 p-3 rounded-md">
                            {selectedPrescricao.motivo_rejeicao}
                          </div>
                        </div>
                      )}
                      {selectedPrescricao.produtos_prescritos && selectedPrescricao.produtos_prescritos.length > 0 && (
                        <div>
                          <p className="text-sm text-gray-500 mb-2">Produtos Prescritos</p>
                          <ul className="space-y-2">
                            {selectedPrescricao.produtos_prescritos.map((produto, index) => (
                              <li key={index} className="bg-gray-50 p-3 rounded-md">
                                <p className="font-medium">{produto.nome}</p>
                                <p className="text-sm">Dosagem: {produto.dosagem}</p>
                                <p className="text-sm">Posologia: {produto.posologia}</p>
                                <p className="text-sm">Quantidade: {produto.quantidade}</p>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDetailsDialog(false)}>
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Approval Dialog */}
      <Dialog open={showApprovalDialog} onOpenChange={setShowApprovalDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Aprovar Prescrição</DialogTitle>
            <DialogDescription>
              Confirme a aprovação da prescrição médica
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <p className="text-sm">
              Você está prestes a aprovar a prescrição do paciente <span className="font-medium">{selectedPrescricao?.paciente_nome}</span>.
            </p>
            
            <p className="text-sm">
              Verifique se:
            </p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>A prescrição está legível e completa</li>
              <li>Contém carimbo e assinatura do médico</li>
              <li>O CRM do médico é válido</li>
              <li>A data de validade está correta</li>
            </ul>

            <div className="grid gap-3 pt-2">
              <label htmlFor="observations" className="text-sm font-medium">
                Observações (opcional)
              </label>
              <Textarea
                id="observations"
                placeholder="Adicione observações sobre esta prescrição se necessário"
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApprovalDialog(false)}>
              Cancelar
            </Button>
            <Button 
              className="bg-green-600 hover:bg-green-700" 
              onClick={handleApprove}
              disabled={processingAction}
            >
              {processingAction ? (
                <>
                  <Spinner className="mr-2" />
                  Processando...
                </>
              ) : (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Confirmar Aprovação
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rejection Dialog */}
      <Dialog open={showRejectionDialog} onOpenChange={setShowRejectionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rejeitar Prescrição</DialogTitle>
            <DialogDescription>
              Informe o motivo da rejeição da prescrição
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <p className="text-sm">
              Você está prestes a rejeitar a prescrição do paciente <span className="font-medium">{selectedPrescricao?.paciente_nome}</span>.
            </p>
            
            <div className="grid gap-3 pt-2">
              <label htmlFor="rejection-reason" className="text-sm font-medium">
                Motivo da Rejeição <span className="text-red-500">*</span>
              </label>
              <Textarea
                id="rejection-reason"
                placeholder="Descreva de forma clara o motivo da rejeição para que o paciente possa corrigir e reenviar"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={4}
                required
              />
              <p className="text-xs text-gray-500">
                Este texto será enviado ao paciente como justificativa para a rejeição.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRejectionDialog(false)}>
              Cancelar
            </Button>
            <Button 
              variant="destructive"
              onClick={handleReject}
              disabled={processingAction}
            >
              {processingAction ? (
                <>
                  <Spinner className="mr-2" />
                  Processando...
                </>
              ) : (
                <>
                  <XCircle className="mr-2 h-4 w-4" />
                  Confirmar Rejeição
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}