import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { PaymentTransaction } from '@/api/entities';
import {
  Search,
  Download,
  Filter,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle,
  XCircle,
  AlertCircle,
  Clock,
  RefreshCw,
  CreditCard,
  FileText,
  Calendar,
  DollarSign,
  MoreHorizontal,
  Eye,
  Copy,
  FileSearch,
  ArrowLeftRight,
  Printer,
  Building2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/components/ui/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function ComplyPayTransactions() {
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [viewingTransaction, setViewingTransaction] = useState(null);
  const [showDetails, setShowDetails] = useState(false);

  // Sample data for demonstration
  useEffect(() => {
    const mockTransactions = [
      {
        id: 'tx-001',
        transaction_id: 'txn_6ZyQj8AqPw2L',
        type: 'payment',
        status: 'completed',
        amount: 520.99,
        currency: 'BRL',
        payment_method_details: {
          type: 'credit_card',
          brand: 'visa',
          last4: '4242'
        },
        customer: {
          name: 'João Silva',
          email: 'joao.silva@exemplo.com'
        },
        date_created: '2023-11-05T10:15:30Z',
        date_completed: '2023-11-05T10:16:45Z',
        invoice_id: 'inv-001',
        description: 'Pagamento de fatura #FAT-2023-001'
      },
      {
        id: 'tx-002',
        transaction_id: 'txn_8YtRk3BvNm5P',
        type: 'payment',
        status: 'pending',
        amount: 1250.75,
        currency: 'BRL',
        payment_method_details: {
          type: 'boleto',
          barcode: '03399.63290 64000.000006 00125.201020 4 89150000125075'
        },
        customer: {
          name: 'Maria Oliveira',
          email: 'maria.oliveira@exemplo.com'
        },
        date_created: '2023-11-04T14:30:00Z',
        invoice_id: 'inv-002',
        description: 'Pagamento de fatura #FAT-2023-002'
      },
      {
        id: 'tx-003',
        transaction_id: 'txn_3CvTp7KxQm9N',
        type: 'refund',
        status: 'completed',
        amount: 320.50,
        currency: 'BRL',
        payment_method_details: {
          type: 'credit_card',
          brand: 'mastercard',
          last4: '8765'
        },
        customer: {
          name: 'Carlos Santos',
          email: 'carlos.santos@exemplo.com'
        },
        date_created: '2023-11-03T11:45:20Z',
        date_completed: '2023-11-03T12:05:30Z',
        invoice_id: 'inv-003',
        description: 'Reembolso parcial da fatura #FAT-2023-003'
      },
      {
        id: 'tx-004',
        transaction_id: 'txn_5GbWv9LzXy2S',
        type: 'payment',
        status: 'failed',
        amount: 750.00,
        currency: 'BRL',
        payment_method_details: {
          type: 'credit_card',
          brand: 'visa',
          last4: '1111'
        },
        customer: {
          name: 'Ana Pereira',
          email: 'ana.pereira@exemplo.com'
        },
        date_created: '2023-11-02T09:20:15Z',
        error_code: 'card_declined',
        error_message: 'Cartão recusado pela operadora',
        invoice_id: 'inv-004',
        description: 'Pagamento de fatura #FAT-2023-004'
      },
      {
        id: 'tx-005',
        transaction_id: 'txn_2DwUp6MzVn4R',
        type: 'payment',
        status: 'completed',
        amount: 1875.25,
        currency: 'BRL',
        payment_method_details: {
          type: 'pix',
          qr_code: 'pix_qrcode_data'
        },
        customer: {
          name: 'Pedro Almeida',
          email: 'pedro.almeida@exemplo.com'
        },
        date_created: '2023-11-01T16:10:45Z',
        date_completed: '2023-11-01T16:12:30Z',
        invoice_id: 'inv-005',
        description: 'Pagamento de fatura #FAT-2023-005'
      }
    ];

    setTimeout(() => {
      setTransactions(mockTransactions);
      setIsLoading(false);
    }, 1000);
  }, []);

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = 
      transaction.transaction_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (transaction.description && transaction.description.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = filterStatus === 'all' || transaction.status === filterStatus;
    const matchesType = filterType === 'all' || transaction.type === filterType;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const getStatusBadge = (status) => {
    switch(status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800">Concluída</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'processing':
        return <Badge className="bg-blue-100 text-blue-800">Processando</Badge>;
      case 'failed':
        return <Badge className="bg-red-100 text-red-800">Falha</Badge>;
      case 'refunded':
        return <Badge className="bg-purple-100 text-purple-800">Reembolsada</Badge>;
      case 'cancelled':
        return <Badge className="bg-gray-100 text-gray-800">Cancelada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getTypeLabel = (type) => {
    switch(type) {
      case 'payment':
        return 'Pagamento';
      case 'refund':
        return 'Reembolso';
      case 'chargeback':
        return 'Estorno';
      case 'fee':
        return 'Taxa';
      case 'adjustment':
        return 'Ajuste';
      default:
        return type;
    }
  };

  const getTypeIcon = (type) => {
    switch(type) {
      case 'payment':
        return <ArrowUpRight className="h-4 w-4 text-green-500" />;
      case 'refund':
        return <ArrowDownRight className="h-4 w-4 text-red-500" />;
      case 'chargeback':
        return <ArrowLeftRight className="h-4 w-4 text-orange-500" />;
      case 'fee':
        return <DollarSign className="h-4 w-4 text-gray-500" />;
      case 'adjustment':
        return <RefreshCw className="h-4 w-4 text-blue-500" />;
      default:
        return null;
    }
  };

  const getPaymentMethodIcon = (method) => {
    if (!method) return null;
    
    switch(method.type) {
      case 'credit_card':
      case 'debit_card':
        return <CreditCard className="h-4 w-4 text-blue-500" />;
      case 'boleto':
        return <FileText className="h-4 w-4 text-purple-500" />;
      case 'pix':
        return <ArrowLeftRight className="h-4 w-4 text-green-500" />;
      case 'bank_account':
        return <Building2 className="h-4 w-4 text-teal-500" />;
      default:
        return <DollarSign className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return format(new Date(dateString), 'dd/MM/yyyy HH:mm', { locale: ptBR });
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const viewTransactionDetails = (transaction) => {
    setViewingTransaction(transaction);
    setShowDetails(true);
  };

  const handleRefresh = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Dados atualizados",
        description: "A lista de transações foi atualizada."
      });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Transações</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Gerencie todas as transações realizadas no sistema ComplyPay
          </p>
        </div>
        <Button onClick={handleRefresh} variant="secondary" disabled={isLoading}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Atualizar
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input 
            placeholder="Buscar transações..." 
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="completed">Concluída</SelectItem>
              <SelectItem value="pending">Pendente</SelectItem>
              <SelectItem value="processing">Processando</SelectItem>
              <SelectItem value="failed">Falha</SelectItem>
              <SelectItem value="refunded">Reembolsada</SelectItem>
              <SelectItem value="cancelled">Cancelada</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os tipos</SelectItem>
              <SelectItem value="payment">Pagamento</SelectItem>
              <SelectItem value="refund">Reembolso</SelectItem>
              <SelectItem value="chargeback">Estorno</SelectItem>
              <SelectItem value="fee">Taxa</SelectItem>
              <SelectItem value="adjustment">Ajuste</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="outline" 
            onClick={() => toast({
              title: "Exportação",
              description: "A exportação de transações estará disponível em breve."
            })}
          >
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle>Transações</CardTitle>
          <CardDescription>
            {filteredTransactions.length} {filteredTransactions.length === 1 ? 'transação encontrada' : 'transações encontradas'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 dark:border-gray-100"></div>
            </div>
          ) : filteredTransactions.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID da Transação</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Método</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.map((transaction) => (
                    <TableRow key={transaction.id} className="cursor-pointer" onClick={() => viewTransactionDetails(transaction)}>
                      <TableCell className="font-medium">{transaction.transaction_id}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {getTypeIcon(transaction.type)}
                          <span>{getTypeLabel(transaction.type)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">{transaction.customer.name}</span>
                          <span className="text-xs text-gray-500">{transaction.customer.email}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{formatCurrency(transaction.amount)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {getPaymentMethodIcon(transaction.payment_method_details)}
                          <span>
                            {transaction.payment_method_details.type === 'credit_card' && 
                              `${transaction.payment_method_details.brand.charAt(0).toUpperCase() + transaction.payment_method_details.brand.slice(1)} ****${transaction.payment_method_details.last4}`}
                            {transaction.payment_method_details.type === 'boleto' && 'Boleto'}
                            {transaction.payment_method_details.type === 'pix' && 'PIX'}
                            {transaction.payment_method_details.type === 'bank_account' && 'Transferência'}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>{formatDate(transaction.date_created)}</TableCell>
                      <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={(e) => {
                          e.stopPropagation();
                          viewTransactionDetails(transaction);
                        }}>
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12">
              <FileSearch className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhuma transação encontrada</h3>
              <p className="text-gray-500 text-center max-w-sm">
                Não foi possível encontrar transações com os filtros atuais. Tente ajustar sua busca ou filtros.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-3xl">
          {viewingTransaction && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {getTypeIcon(viewingTransaction.type)}
                  <span>
                    {getTypeLabel(viewingTransaction.type)} - {viewingTransaction.transaction_id}
                  </span>
                </DialogTitle>
                <div className="flex items-center gap-2">
                  {getStatusBadge(viewingTransaction.status)}
                  <span className="text-sm text-gray-500">
                    {formatDate(viewingTransaction.date_created)}
                  </span>
                </div>
              </DialogHeader>

              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Detalhes da Transação</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">ID da Transação:</span>
                        <span className="text-sm font-medium">{viewingTransaction.transaction_id}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Tipo:</span>
                        <span className="text-sm font-medium">{getTypeLabel(viewingTransaction.type)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Valor:</span>
                        <span className="text-sm font-medium">{formatCurrency(viewingTransaction.amount)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Status:</span>
                        <span className="text-sm font-medium">{getStatusBadge(viewingTransaction.status)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Data de Criação:</span>
                        <span className="text-sm font-medium">{formatDate(viewingTransaction.date_created)}</span>
                      </div>
                      {viewingTransaction.date_completed && (
                        <div className="flex justify-between">
                          <span className="text-sm">Data de Conclusão:</span>
                          <span className="text-sm font-medium">{formatDate(viewingTransaction.date_completed)}</span>
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span className="text-sm">ID da Fatura:</span>
                        <span className="text-sm font-medium">{viewingTransaction.invoice_id}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Descrição:</span>
                        <span className="text-sm font-medium">{viewingTransaction.description}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Cliente</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Nome:</span>
                        <span className="text-sm font-medium">{viewingTransaction.customer.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Email:</span>
                        <span className="text-sm font-medium">{viewingTransaction.customer.email}</span>
                      </div>
                    </div>

                    <h3 className="text-sm font-medium text-gray-500 mt-4 mb-1">Método de Pagamento</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Tipo:</span>
                        <span className="text-sm font-medium">
                          {viewingTransaction.payment_method_details.type === 'credit_card' && 'Cartão de Crédito'}
                          {viewingTransaction.payment_method_details.type === 'boleto' && 'Boleto Bancário'}
                          {viewingTransaction.payment_method_details.type === 'pix' && 'PIX'}
                          {viewingTransaction.payment_method_details.type === 'bank_account' && 'Transferência Bancária'}
                        </span>
                      </div>
                      {viewingTransaction.payment_method_details.type === 'credit_card' && (
                        <>
                          <div className="flex justify-between">
                            <span className="text-sm">Bandeira:</span>
                            <span className="text-sm font-medium">{viewingTransaction.payment_method_details.brand.charAt(0).toUpperCase() + viewingTransaction.payment_method_details.brand.slice(1)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Número Final:</span>
                            <span className="text-sm font-medium">****{viewingTransaction.payment_method_details.last4}</span>
                          </div>
                        </>
                      )}
                      {viewingTransaction.payment_method_details.type === 'boleto' && (
                        <div className="flex justify-between">
                          <span className="text-sm">Código de Barras:</span>
                          <span className="text-sm font-medium truncate max-w-[200px]">{viewingTransaction.payment_method_details.barcode}</span>
                        </div>
                      )}
                    </div>

                    {viewingTransaction.error_message && (
                      <div className="mt-4 p-3 bg-red-50 border border-red-100 rounded-md">
                        <h3 className="text-sm font-medium text-red-800 mb-1">Detalhes do Erro</h3>
                        <p className="text-sm text-red-700">{viewingTransaction.error_message}</p>
                        {viewingTransaction.error_code && (
                          <p className="text-xs text-red-600 mt-1">Código: {viewingTransaction.error_code}</p>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                <Separator />

                <div className="flex justify-between">
                  <Button variant="outline" onClick={() => {
                    toast({
                      title: "Imprimir recibo",
                      description: "Esta funcionalidade estará disponível em breve."
                    });
                  }}>
                    <Printer className="mr-2 h-4 w-4" />
                    Imprimir Recibo
                  </Button>

                  {viewingTransaction.status === 'completed' && viewingTransaction.type === 'payment' && (
                    <Button variant="outline" onClick={() => {
                      toast({
                        title: "Iniciar reembolso",
                        description: "Esta funcionalidade estará disponível em breve."
                      });
                    }}>
                      <ArrowDownRight className="mr-2 h-4 w-4" />
                      Iniciar Reembolso
                    </Button>
                  )}

                  {viewingTransaction.status === 'pending' && (
                    <Button variant="default" onClick={() => {
                      toast({
                        title: "Verificar status",
                        description: "Esta funcionalidade estará disponível em breve."
                      });
                    }}>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Verificar Status
                    </Button>
                  )}

                  {viewingTransaction.status === 'failed' && (
                    <Button variant="outline" onClick={() => {
                      toast({
                        title: "Tentar novamente",
                        description: "Esta funcionalidade estará disponível em breve."
                      });
                    }}>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Tentar Novamente
                    </Button>
                  )}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}