import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Calendar as CalendarIcon, Clock, Video, Users } from 'lucide-react';

export default function AgendamentoEntrevistaSocial() {
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState("");
  const [selectedType, setSelectedType] = useState("presencial");

  const availableTimes = [
    "09:00", "10:00", "11:00",
    "14:00", "15:00", "16:00"
  ];

  const handleSchedule = () => {
    // Implementar agendamento
    alert('Entrevista agendada com sucesso!');
  };

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle>Agendar Entrevista Social</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border"
              />
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Tipo de Entrevista</label>
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="presencial">
                      <div className="flex items-center">
                        <Users className="w-4 h-4 mr-2" />
                        Presencial
                      </div>
                    </SelectItem>
                    <SelectItem value="online">
                      <div className="flex items-center">
                        <Video className="w-4 h-4 mr-2" />
                        Online
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Horário Disponível</label>
                <Select value={selectedTime} onValueChange={setSelectedTime}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o horário" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableTimes.map((time) => (
                      <SelectItem key={time} value={time}>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-2" />
                          {time}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedType === "presencial" && (
                <Alert>
                  <AlertDescription>
                    A entrevista presencial será realizada em nossa sede.
                    Endereço: Av. Principal, 1000 - Centro
                  </AlertDescription>
                </Alert>
              )}

              {selectedType === "online" && (
                <Alert>
                  <AlertDescription>
                    O link para a entrevista online será enviado por email após a confirmação.
                  </AlertDescription>
                </Alert>
              )}

              <Button 
                className="w-full mt-4"
                onClick={handleSchedule}
                disabled={!selectedDate || !selectedTime}
              >
                Confirmar Agendamento
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}