import React, { useState, useEffect } from 'react';
import { Task } from "@/api/entities";
import { User } from "@/api/entities";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { 
  CheckSquare, 
  Clock, 
  AlertCircle, 
  CheckCircle,
  UserCheck, 
  CalendarDays, 
  TrendingUp, 
  ArrowRight,
  Tag
} from 'lucide-react';

// Status colors for consistent styling
const STATUS_COLORS = {
  backlog: "#94a3b8",
  todo: "#6366f1",
  in_progress: "#a855f7",
  review: "#f59e0b",
  done: "#22c55e"
};

const PRIORITY_COLORS = {
  low: "#60a5fa",
  medium: "#fbbf24",
  high: "#f97316",
  urgent: "#ef4444"
};

export default function TasksDashboard() {
  const [taskStats, setTaskStats] = useState({
    total: 0,
    byStatus: {
      backlog: 0,
      todo: 0,
      in_progress: 0,
      review: 0,
      done: 0
    },
    byPriority: {
      low: 0,
      medium: 0,
      high: 0,
      urgent: 0
    },
    overdue: 0,
    completedThisWeek: 0,
    assignedToMe: 0
  });
  
  const [recentlyCompletedTasks, setRecentlyCompletedTasks] = useState([]);
  const [upcomingTasks, setUpcomingTasks] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUserAndTasks();
  }, []);

  const loadUserAndTasks = async () => {
    try {
      setLoading(true);
      
      // Get current user
      const user = await User.me();
      setCurrentUser(user);
      
      // Get all tasks
      const tasks = await Task.list();
      
      // Calculate stats
      const now = new Date();
      const weekStart = new Date(now);
      weekStart.setDate(now.getDate() - 7);
      
      const stats = {
        total: tasks.length,
        byStatus: {
          backlog: 0,
          todo: 0,
          in_progress: 0,
          review: 0,
          done: 0
        },
        byPriority: {
          low: 0,
          medium: 0,
          high: 0,
          urgent: 0
        },
        overdue: 0,
        completedThisWeek: 0,
        assignedToMe: 0
      };
      
      // Process tasks for statistics
      tasks.forEach(task => {
        // Count by status
        if (stats.byStatus.hasOwnProperty(task.status)) {
          stats.byStatus[task.status]++;
        }
        
        // Count by priority
        if (stats.byPriority.hasOwnProperty(task.priority)) {
          stats.byPriority[task.priority]++;
        }
        
        // Count overdue tasks
        if (task.due_date && new Date(task.due_date) < now && task.status !== 'done') {
          stats.overdue++;
        }
        
        // Count tasks completed this week
        if (task.status === 'done' && task.updated_date && new Date(task.updated_date) > weekStart) {
          stats.completedThisWeek++;
        }
        
        // Count tasks assigned to current user
        if (task.assigned_to === user.id) {
          stats.assignedToMe++;
        }
      });
      
      setTaskStats(stats);
      
      // Get recently completed tasks
      const completed = tasks
        .filter(task => task.status === 'done')
        .sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date))
        .slice(0, 5);
      setRecentlyCompletedTasks(completed);
      
      // Get upcoming tasks with due dates
      const upcoming = tasks
        .filter(task => task.status !== 'done' && task.due_date)
        .sort((a, b) => new Date(a.due_date) - new Date(b.due_date))
        .slice(0, 5);
      setUpcomingTasks(upcoming);
    } catch (error) {
      console.error('Error loading tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  // Data for charts
  const statusChartData = Object.keys(taskStats.byStatus).map(status => ({
    name: status.charAt(0).toUpperCase() + status.slice(1),
    value: taskStats.byStatus[status],
    color: STATUS_COLORS[status]
  }));

  const priorityChartData = Object.keys(taskStats.byPriority).map(priority => ({
    name: priority.charAt(0).toUpperCase() + priority.slice(1),
    value: taskStats.byPriority[priority],
    color: PRIORITY_COLORS[priority]
  }));

  if (loading) {
    return (
      <div className="flex h-full w-full items-center justify-center p-8">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-green-200 border-t-green-600"></div>
          <p className="text-sm text-gray-500">Carregando estatísticas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col space-y-1.5">
        <h1 className="text-2xl font-bold">Dashboard de Tarefas</h1>
        <p className="text-sm text-muted-foreground">
          Visão geral de todas as suas tarefas e estatísticas
        </p>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total de Tarefas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <CheckSquare className="h-5 w-5 text-muted-foreground mr-2" />
              <span className="text-2xl font-bold">{taskStats.total}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Em Progresso
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Clock className="h-5 w-5 text-purple-500 mr-2" />
              <span className="text-2xl font-bold">{taskStats.byStatus.in_progress}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Tarefas Atrasadas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
              <span className="text-2xl font-bold">{taskStats.overdue}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Concluídas (7 dias)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
              <span className="text-2xl font-bold">{taskStats.completedThisWeek}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Tarefas por Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusChartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value, name) => [value, name]}
                    labelFormatter={() => 'Quantidade'}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Tarefas por Prioridade</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={priorityChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value) => [value, 'Quantidade']}
                  />
                  <Legend />
                  <Bar dataKey="value" name="Quantidade">
                    {priorityChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent and Upcoming Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Tarefas Recentemente Concluídas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentlyCompletedTasks.length > 0 ? (
                recentlyCompletedTasks.map(task => (
                  <div key={task.id} className="flex items-start space-x-4 pb-4 border-b border-gray-100 last:border-0">
                    <div className="flex-shrink-0 mt-1">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{task.title}</p>
                      <p className="text-xs text-gray-500 truncate">{task.description}</p>
                      <div className="flex items-center mt-1 space-x-2">
                        <Badge variant="outline" className={`text-xs bg-${task.priority}-100 text-${task.priority}-800`}>
                          {task.priority}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          Concluída em {new Date(task.updated_date).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500 py-4 text-center">Nenhuma tarefa concluída recentemente</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Próximas Tarefas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingTasks.length > 0 ? (
                upcomingTasks.map(task => (
                  <div key={task.id} className="flex items-start space-x-4 pb-4 border-b border-gray-100 last:border-0">
                    <div className="flex-shrink-0 mt-1">
                      {new Date(task.due_date) < new Date() ? (
                        <AlertCircle className="h-5 w-5 text-red-500" />
                      ) : (
                        <CalendarDays className="h-5 w-5 text-blue-500" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{task.title}</p>
                      <p className="text-xs text-gray-500 truncate">{task.description}</p>
                      <div className="flex items-center mt-1 space-x-2">
                        <Badge className={`bg-${STATUS_COLORS[task.status]}/20 text-${STATUS_COLORS[task.status]}`}>
                          {task.status}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          Vence em {new Date(task.due_date).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500 py-4 text-center">Nenhuma tarefa com vencimento próximo</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}