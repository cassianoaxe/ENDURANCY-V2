import React, { useState, useEffect } from 'react';
import EstoqueBaseView from '../components/estoque/EstoqueBaseView';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function EstoqueProdutoAcabado() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [categoriaFilter, setCategoriaFilter] = useState("all");
  const [concentracaoFilter, setConcentracaoFilter] = useState("all");

  useEffect(() => {
    const loadData = async () => {
      const mockData = [
        {
          id: "1",
          codigo: "PA-CBD10-001",
          nome: "Óleo CBD 10% Full Spectrum",
          lote: "L202301",
          quantidade_atual: 500,
          quantidade_minima: 200,
          unidade_medida: "unidade",
          status: "disponivel",
          data_validade: "2024-12-31",
          categoria: "oleo",
          concentracao: "10"
        },
        {
          id: "2",
          codigo: "PA-CBD5-001",
          nome: "Óleo CBD 5% Full Spectrum",
          lote: "L202302",
          quantidade_atual: 750,
          quantidade_minima: 200,
          unidade_medida: "unidade",
          status: "disponivel",
          data_validade: "2024-12-31",
          categoria: "oleo",
          concentracao: "5"
        }
      ];
      
      setData(mockData);
      setLoading(false);
    };

    setTimeout(loadData, 1000);
  }, []);

  const customFilters = (
    <div className="flex gap-2">
      <Select value={categoriaFilter} onValueChange={setCategoriaFilter}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Categoria" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todas Categorias</SelectItem>
          <SelectItem value="oleo">Óleos</SelectItem>
          <SelectItem value="capsula">Cápsulas</SelectItem>
          <SelectItem value="topico">Tópicos</SelectItem>
          <SelectItem value="spray">Sprays</SelectItem>
        </SelectContent>
      </Select>

      <Select value={concentracaoFilter} onValueChange={setConcentracaoFilter}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Concentração" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todas</SelectItem>
          <SelectItem value="5">5%</SelectItem>
          <SelectItem value="10">10%</SelectItem>
          <SelectItem value="20">20%</SelectItem>
          <SelectItem value="30">30%</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );

  return (
    <EstoqueBaseView
      title="Estoque de Produtos Acabados"
      description="Gestão de estoque de produtos finalizados e aprovados"
      tipoEstoque="produto_acabado"
      data={data}
      loading={loading}
      onAddItem={() => console.log("Adicionar item")}
      onEditItem={(item) => console.log("Editar item", item)}
      onViewDetails={(item) => console.log("Ver detalhes", item)}
      customFilters={customFilters}
    />
  );
}