
import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Medico } from '@/api/entities';
import { Representante } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge"; // Add missing Badge import
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";
import { ArrowLeft, Save, Plus, Trash2 } from "lucide-react";

export default function CadastroMedico() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const medicoId = searchParams.get('id');
  const isEditing = !!medicoId;
  const representanteId = searchParams.get('representante_id');

  const [formData, setFormData] = useState({
    nome_completo: '',
    crm: '',
    uf_crm: '',
    especialidade: '',
    outras_especialidades: [],
    email: '',
    telefone: '',
    celular: '',
    representante_id: representanteId || '',
    percentual_comissao: 15,
    percentual_comissao_representante: 0,
    endereco: {
      cep: '',
      logradouro: '',
      numero: '',
      complemento: '',
      bairro: '',
      cidade: '',
      estado: ''
    },
    curriculo: '',
    foto_url: '',
    valor_consulta: '',
    tempo_consulta: 30,
    aceita_convenio: false,
    convenios: [],
    especialista_cannabis: true,
    permite_telemedicina: true,
    status: 'ativo'
  });

  const [novoConvenio, setNovoConvenio] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [representantes, setRepresentantes] = useState([]);
  const [activeTab, setActiveTab] = useState("informacoes-basicas");

  useEffect(() => {
    const loadRepresentantes = async () => {
      try {
        const result = await Representante.filter({ status: 'ativo' });
        setRepresentantes(result);
      } catch (error) {
        console.error('Erro ao carregar representantes:', error);
        toast({
          title: "Erro ao carregar representantes",
          description: "Não foi possível carregar a lista de representantes.",
          variant: "destructive"
        });
      }
    };

    if (isEditing) {
      loadMedico();
    }
    
    loadRepresentantes();
  }, [medicoId]);

  const loadMedico = async () => {
    try {
      setIsLoading(true);
      const medico = await Medico.get(medicoId);
      setFormData({
        ...medico,
        endereco: medico.endereco || {
          cep: '',
          logradouro: '',
          numero: '',
          complemento: '',
          bairro: '',
          cidade: '',
          estado: ''
        }
      });
    } catch (error) {
      console.error('Erro ao carregar dados do médico:', error);
      toast({
        title: "Erro ao carregar dados do médico",
        description: "Não foi possível carregar os dados do médico selecionado.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAddressChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      endereco: {
        ...prev.endereco,
        [name]: value
      }
    }));
  };

  const handleCheckboxChange = (name) => (checked) => {
    setFormData(prev => ({
      ...prev,
      [name]: checked
    }));
  };

  const handleAddConvenio = () => {
    if (novoConvenio.trim()) {
      setFormData(prev => ({
        ...prev,
        convenios: [...(prev.convenios || []), novoConvenio.trim()]
      }));
      setNovoConvenio('');
    }
  };

  const handleRemoveConvenio = (index) => {
    setFormData(prev => ({
      ...prev,
      convenios: prev.convenios.filter((_, i) => i !== index)
    }));
  };

  const handleRepresentanteChange = (value) => {
    setFormData(prev => ({
      ...prev,
      representante_id: value,
      percentual_comissao_representante: value ? 3 : 0
    }));
  };

  const lookupAddressByCep = async () => {
    const cep = formData.endereco.cep.replace(/\D/g, '');
    if (cep.length !== 8) return;

    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await response.json();
      
      if (!data.erro) {
        setFormData(prev => ({
          ...prev,
          endereco: {
            ...prev.endereco,
            logradouro: data.logradouro,
            bairro: data.bairro,
            cidade: data.localidade,
            estado: data.uf
          }
        }));
      }
    } catch (error) {
      console.error('Erro ao buscar CEP:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const dataToSubmit = {
        ...formData,
        data_cadastro: formData.data_cadastro || new Date().toISOString()
      };

      if (isEditing) {
        await Medico.update(medicoId, dataToSubmit);
        
        if (formData.representante_id) {
          const representante = await Representante.get(formData.representante_id);
          
          const medicoIndex = representante.medicos_cadastrados?.findIndex(m => m.medico_id === medicoId) || -1;
          
          if (medicoIndex >= 0) {
            const medicosAtualizados = [...(representante.medicos_cadastrados || [])];
            medicosAtualizados[medicoIndex] = {
              ...medicosAtualizados[medicoIndex],
              nome_medico: formData.nome_completo,
              crm: formData.crm,
              uf_crm: formData.uf_crm,
              percentual_comissao_especial: formData.percentual_comissao_representante
            };
            
            await Representante.update(formData.representante_id, {
              medicos_cadastrados: medicosAtualizados
            });
          } else {
            const medicosAtualizados = [
              ...(representante.medicos_cadastrados || []),
              {
                medico_id: medicoId,
                nome_medico: formData.nome_completo,
                crm: formData.crm,
                uf_crm: formData.uf_crm,
                data_cadastro: new Date().toISOString(),
                percentual_comissao_especial: formData.percentual_comissao_representante
              }
            ];
            
            await Representante.update(formData.representante_id, {
              medicos_cadastrados: medicosAtualizados
            });
          }
        }
        
        toast({
          title: "Médico atualizado",
          description: "Os dados do médico foram atualizados com sucesso.",
        });
      } else {
        const novoMedico = await Medico.create(dataToSubmit);
        
        if (formData.representante_id) {
          const representante = await Representante.get(formData.representante_id);
          
          const medicosAtualizados = [
            ...(representante.medicos_cadastrados || []),
            {
              medico_id: novoMedico.id,
              nome_medico: formData.nome_completo,
              crm: formData.crm,
              uf_crm: formData.uf_crm,
              data_cadastro: new Date().toISOString(),
              percentual_comissao_especial: formData.percentual_comissao_representante
            }
          ];
          
          await Representante.update(formData.representante_id, {
            medicos_cadastrados: medicosAtualizados
          });
        }
        
        toast({
          title: "Médico cadastrado",
          description: "O médico foi cadastrado com sucesso.",
        });
      }
      navigate(createPageUrl('ListaMedicos'));
    } catch (error) {
      console.error('Erro ao salvar médico:', error);
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar os dados do médico.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin h-12 w-12 border-4 border-green-500 rounded-full border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto py-6">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate(createPageUrl('ListaMedicos'))}
          className="mr-4"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">{isEditing ? 'Editar Médico' : 'Cadastrar Novo Médico'}</h1>
          <p className="text-gray-500 mt-1">
            {isEditing 
              ? 'Atualize os dados do médico no sistema' 
              : 'Preencha os dados para cadastrar um novo médico no sistema'}
          </p>
        </div>
      </div>
      
      <form onSubmit={handleSubmit}>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="informacoes-basicas">Informações Básicas</TabsTrigger>
            <TabsTrigger value="endereco-contato">Endereço e Contato</TabsTrigger>
            <TabsTrigger value="configuracoes">Configurações</TabsTrigger>
          </TabsList>
          
          <TabsContent value="informacoes-basicas" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Dados Pessoais e Profissionais</CardTitle>
                <CardDescription>Informações básicas de identificação do médico</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nome_completo">Nome Completo *</Label>
                    <Input 
                      id="nome_completo" 
                      name="nome_completo" 
                      value={formData.nome_completo} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="crm">CRM *</Label>
                    <Input 
                      id="crm" 
                      name="crm" 
                      value={formData.crm} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="uf_crm">UF do CRM *</Label>
                    <Select 
                      value={formData.uf_crm} 
                      onValueChange={(value) => setFormData({...formData, uf_crm: value})} 
                      required
                    >
                      <SelectTrigger id="uf_crm">
                        <SelectValue placeholder="Selecione a UF" />
                      </SelectTrigger>
                      <SelectContent>
                        {["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"].map((uf) => (
                          <SelectItem key={uf} value={uf}>{uf}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="especialidade">Especialidade Principal *</Label>
                    <Input 
                      id="especialidade" 
                      name="especialidade" 
                      value={formData.especialidade} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="valor_consulta">Valor da Consulta (R$)</Label>
                    <Input 
                      id="valor_consulta" 
                      name="valor_consulta" 
                      type="number" 
                      value={formData.valor_consulta} 
                      onChange={handleChange} 
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="curriculo">Mini Currículo</Label>
                  <Textarea 
                    id="curriculo" 
                    name="curriculo" 
                    value={formData.curriculo} 
                    onChange={handleChange} 
                    rows={4} 
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="especialista_cannabis" 
                    checked={formData.especialista_cannabis} 
                    onCheckedChange={handleCheckboxChange('especialista_cannabis')} 
                  />
                  <Label htmlFor="especialista_cannabis" className="font-normal">
                    Especialista em Cannabis Medicinal
                  </Label>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Representante Associado</CardTitle>
                <CardDescription>Associe este médico a um representante para rastreamento de comissões</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="representante_id">Representante</Label>
                  <Select 
                    value={formData.representante_id} 
                    onValueChange={handleRepresentanteChange}
                  >
                    <SelectTrigger id="representante_id">
                      <SelectValue placeholder="Selecione um representante (opcional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Nenhum</SelectItem>
                      {representantes.map((rep) => (
                        <SelectItem key={rep.id} value={rep.id}>
                          {rep.nome_completo}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                {formData.representante_id && (
                  <div className="space-y-2">
                    <Label htmlFor="percentual_comissao_representante">
                      Percentual de Comissão do Representante (%)
                    </Label>
                    <Input 
                      id="percentual_comissao_representante" 
                      name="percentual_comissao_representante" 
                      type="number" 
                      min="0"
                      max="100"
                      step="0.1"
                      value={formData.percentual_comissao_representante} 
                      onChange={handleChange} 
                    />
                    <p className="text-xs text-gray-500">
                      Porcentagem que o representante receberá sobre vendas realizadas para pacientes deste médico.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <div className="flex justify-end">
              <Button 
                type="button" 
                onClick={() => setActiveTab("endereco-contato")}
                className="ml-auto"
              >
                Próximo
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="endereco-contato" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Informações de Contato</CardTitle>
                <CardDescription>Canais de comunicação com o médico</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail *</Label>
                    <Input 
                      id="email" 
                      name="email" 
                      type="email" 
                      value={formData.email} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="telefone">Telefone Principal *</Label>
                    <Input 
                      id="telefone" 
                      name="telefone" 
                      value={formData.telefone} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="celular">Celular</Label>
                  <Input 
                    id="celular" 
                    name="celular" 
                    value={formData.celular} 
                    onChange={handleChange} 
                  />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Endereço do Consultório</CardTitle>
                <CardDescription>Informações de localização do consultório principal</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="cep">CEP</Label>
                    <div className="flex gap-2">
                      <Input 
                        id="cep" 
                        name="cep" 
                        value={formData.endereco?.cep} 
                        onChange={handleAddressChange} 
                      />
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={lookupAddressByCep}
                      >
                        Buscar
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="logradouro">Logradouro</Label>
                    <Input 
                      id="logradouro" 
                      name="logradouro" 
                      value={formData.endereco?.logradouro} 
                      onChange={handleAddressChange} 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="numero">Número</Label>
                    <Input 
                      id="numero" 
                      name="numero" 
                      value={formData.endereco?.numero} 
                      onChange={handleAddressChange} 
                    />
                  </div>
                  <div className="md:col-span-2 space-y-2">
                    <Label htmlFor="complemento">Complemento</Label>
                    <Input 
                      id="complemento" 
                      name="complemento" 
                      value={formData.endereco?.complemento} 
                      onChange={handleAddressChange} 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="bairro">Bairro</Label>
                    <Input 
                      id="bairro" 
                      name="bairro" 
                      value={formData.endereco?.bairro} 
                      onChange={handleAddressChange} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cidade">Cidade</Label>
                    <Input 
                      id="cidade" 
                      name="cidade" 
                      value={formData.endereco?.cidade} 
                      onChange={handleAddressChange} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="estado">Estado</Label>
                    <Select 
                      value={formData.endereco?.estado} 
                      onValueChange={(value) => setFormData({
                        ...formData, 
                        endereco: {...formData.endereco, estado: value}
                      })}
                    >
                      <SelectTrigger id="estado">
                        <SelectValue placeholder="UF" />
                      </SelectTrigger>
                      <SelectContent>
                        {["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"].map((uf) => (
                          <SelectItem key={uf} value={uf}>{uf}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex justify-between">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setActiveTab("informacoes-basicas")}
              >
                Anterior
              </Button>
              <Button 
                type="button" 
                onClick={() => setActiveTab("configuracoes")}
              >
                Próximo
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="configuracoes" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configurações de Atendimento</CardTitle>
                <CardDescription>Configure as opções de atendimento do médico</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tempo_consulta">Duração da Consulta (minutos)</Label>
                    <Input 
                      id="tempo_consulta" 
                      name="tempo_consulta" 
                      type="number" 
                      value={formData.tempo_consulta} 
                      onChange={handleChange} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="percentual_comissao">Percentual de Repasse para Organização (%)</Label>
                    <Input 
                      id="percentual_comissao" 
                      name="percentual_comissao" 
                      type="number" 
                      min="0"
                      max="100"
                      step="0.1"
                      value={formData.percentual_comissao} 
                      onChange={handleChange} 
                    />
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="permite_telemedicina" 
                    checked={formData.permite_telemedicina} 
                    onCheckedChange={handleCheckboxChange('permite_telemedicina')} 
                  />
                  <Label htmlFor="permite_telemedicina" className="font-normal">
                    Permite atendimento por telemedicina
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="aceita_convenio" 
                    checked={formData.aceita_convenio} 
                    onCheckedChange={handleCheckboxChange('aceita_convenio')} 
                  />
                  <Label htmlFor="aceita_convenio" className="font-normal">
                    Aceita convênios médicos
                  </Label>
                </div>
                
                {formData.aceita_convenio && (
                  <div className="space-y-2 mt-4">
                    <Label>Convênios Aceitos</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {formData.convenios?.map((convenio, index) => (
                        <Badge key={index} className="flex items-center gap-1">
                          {convenio}
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="h-4 w-4 rounded-full"
                            onClick={() => handleRemoveConvenio(index)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </Badge>
                      ))}
                    </div>
                    <div className="flex mt-2">
                      <Input
                        placeholder="Adicionar convênio"
                        value={novoConvenio}
                        onChange={(e) => setNovoConvenio(e.target.value)}
                        className="mr-2"
                      />
                      <Button 
                        type="button" 
                        size="icon" 
                        onClick={handleAddConvenio}
                        disabled={!novoConvenio.trim()}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
                
                <div className="space-y-2 mt-4">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(value) => setFormData({...formData, status: value})} 
                    required
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                      <SelectItem value="pendente">Pendente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex justify-between">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setActiveTab("endereco-contato")}
              >
                Anterior
              </Button>
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="flex gap-2 items-center"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin h-4 w-4 border-2 border-white rounded-full border-t-transparent"></div>
                    <span>Salvando...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Salvar</span>
                  </>
                )}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </form>
    </div>
  );
}
