
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Search, 
  Filter, 
  Download, 
  Eye, 
  Shield, 
  UserCog, 
  Building2, 
  Key, 
  Settings, 
  AlertTriangle, 
  Clock, 
  Calendar,
  File,
  FileText
} from "lucide-react";

// Sample audit logs data
const auditLogs = [
  {
    id: 1,
    action: 'user_login',
    description: 'Login realizado',
    user: 'João Silva (Admin)',
    ip_address: '189.54.220.123',
    user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    resource: 'Authentication',
    resource_id: null,
    organization: 'Cannabis Brasil Medicinal',
    timestamp: '2023-07-21T09:45:00Z',
    additional_data: {
      location: 'São Paulo, SP',
      device: 'Desktop',
      successful: true
    }
  },
  {
    id: 2,
    action: 'organization_created',
    description: 'Nova organização adicionada',
    user: 'Maria Souza (Super Admin)',
    ip_address: '200.152.41.210',
    user_agent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36',
    resource: 'Organization',
    resource_id: '123',
    organization: 'Endurancy System',
    timestamp: '2023-07-20T14:30:00Z',
    additional_data: {
      organization_name: 'Associação Médica Verde',
      organization_type: 'Associação',
      plan: 'Associação Plus'
    }
  },
  {
    id: 3,
    action: 'user_created',
    description: 'Novo usuário adicionado',
    user: 'Ana Costa (Admin)',
    ip_address: '177.94.150.87',
    user_agent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Mobile/15E148 Safari/604.1',
    resource: 'User',
    resource_id: '456',
    organization: 'Cannabis Brasil Medicinal',
    timestamp: '2023-07-19T11:15:00Z',
    additional_data: {
      user_email: 'pedro@cannabismed.com',
      user_role: 'Manager'
    }
  },
  {
    id: 4,
    action: 'settings_changed',
    description: 'Configurações alteradas',
    user: 'João Silva (Admin)',
    ip_address: '189.54.220.123',
    user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    resource: 'Settings',
    resource_id: null,
    organization: 'Cannabis Brasil Medicinal',
    timestamp: '2023-07-18T16:40:00Z',
    additional_data: {
      changed_settings: ['security_policy', 'billing_address'],
      previous_values: {
        security_policy: 'standard',
        billing_address: 'Av. Paulista, 100'
      },
      new_values: {
        security_policy: 'enhanced',
        billing_address: 'Av. Paulista, 200'
      }
    }
  },
  {
    id: 5,
    action: 'password_reset',
    description: 'Solicitação de redefinição de senha',
    user: 'Sistema',
    ip_address: '187.122.85.45',
    user_agent: 'PostmanRuntime/7.28.2',
    resource: 'User',
    resource_id: '789',
    organization: 'Apoio Médico Cannabis',
    timestamp: '2023-07-17T09:20:00Z',
    additional_data: {
      user_email: 'carlos@apoiomedico.com.br',
      reset_method: 'email',
      successful: true
    }
  }
];

const actionIcons = {
  user_login: <Key className="w-4 h-4" />,
  organization_created: <Building2 className="w-4 h-4" />,
  user_created: <UserCog className="w-4 h-4" />,
  settings_changed: <Settings className="w-4 h-4" />,
  password_reset: <Key className="w-4 h-4" />
};

const actionStyles = {
  user_login: "bg-blue-100 text-blue-800",
  organization_created: "bg-green-100 text-green-800",
  user_created: "bg-purple-100 text-purple-800",
  settings_changed: "bg-yellow-100 text-yellow-800",
  password_reset: "bg-orange-100 text-orange-800",
  security_alert: "bg-red-100 text-red-800"
};

export default function AuditLogs() {
  const [searchTerm, setSearchTerm] = useState("");
  const [actionFilter, setActionFilter] = useState("all");
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [selectedLog, setSelectedLog] = useState(null);
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };

  const handleViewDetails = (log) => {
    setSelectedLog(log);
    setShowDetailDialog(true);
  };

  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch = 
      log.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.organization.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesAction = actionFilter === "all" || log.action === actionFilter;
    
    const matchesDate = (!dateRange.start || new Date(log.timestamp) >= new Date(dateRange.start)) &&
                        (!dateRange.end || new Date(log.timestamp) <= new Date(dateRange.end));
    
    return matchesSearch && matchesAction && matchesDate;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Logs de Auditoria</h1>
          <p className="text-gray-500 mt-1">
            Registros de todas as ações realizadas no sistema
          </p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          Exportar Logs
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div className="w-full md:w-auto flex flex-col md:flex-row gap-4">
          <div className="relative max-w-sm w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar nos logs..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Select value={actionFilter} onValueChange={setActionFilter}>
            <SelectTrigger className="w-full md:w-44">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4" />
                <SelectValue placeholder="Tipo de Ação" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as Ações</SelectItem>
              <SelectItem value="user_login">Login</SelectItem>
              <SelectItem value="organization_created">Criação de Organização</SelectItem>
              <SelectItem value="user_created">Criação de Usuário</SelectItem>
              <SelectItem value="settings_changed">Alteração de Configurações</SelectItem>
              <SelectItem value="password_reset">Redefinição de Senha</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="w-full md:w-auto flex flex-col md:flex-row gap-4">
          <div className="space-y-1">
            <span className="text-sm font-medium">De:</span>
            <Input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange({...dateRange, start: e.target.value})}
              className="w-full"
            />
          </div>
          
          <div className="space-y-1">
            <span className="text-sm font-medium">Até:</span>
            <Input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange({...dateRange, end: e.target.value})}
              className="w-full"
            />
          </div>
        </div>
      </div>

      <Card className="shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data/Hora</TableHead>
              <TableHead>Ação</TableHead>
              <TableHead>Usuário</TableHead>
              <TableHead>Organização</TableHead>
              <TableHead>IP</TableHead>
              <TableHead className="text-right">Detalhes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredLogs.map((log) => (
              <TableRow key={log.id}>
                <TableCell className="whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-400" />
                    {formatDate(log.timestamp)}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col gap-1">
                    <Badge className={actionStyles[log.action]}>
                      <div className="flex items-center gap-1">
                        {actionIcons[log.action]}
                        <span className="capitalize">
                          {log.action.replace(/_/g, ' ')}
                        </span>
                      </div>
                    </Badge>
                    <span className="text-sm text-gray-600">{log.description}</span>
                  </div>
                </TableCell>
                <TableCell>{log.user}</TableCell>
                <TableCell>{log.organization}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-gray-400" />
                    {log.ip_address}
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="gap-1 h-8"
                    onClick={() => handleViewDetails(log)}
                  >
                    <Eye className="w-3 h-3" />
                    Detalhes
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Log Detail Dialog */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <FileText className="w-5 h-5" />
              Detalhes do Log de Auditoria
            </DialogTitle>
          </DialogHeader>
          {selectedLog && (
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">ID do Log</div>
                  <div className="font-medium">{selectedLog.id}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">Data/Hora</div>
                  <div className="font-medium">{formatDate(selectedLog.timestamp)}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">Ação</div>
                  <div>
                    <Badge className={actionStyles[selectedLog.action]}>
                      <div className="flex items-center gap-1">
                        {actionIcons[selectedLog.action]}
                        <span className="capitalize">
                          {selectedLog.action.replace(/_/g, ' ')}
                        </span>
                      </div>
                    </Badge>
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">Descrição</div>
                  <div className="font-medium">{selectedLog.description}</div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">Usuário</div>
                  <div className="font-medium">{selectedLog.user}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">Organização</div>
                  <div className="font-medium">{selectedLog.organization}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">Recurso</div>
                  <div className="font-medium">{selectedLog.resource}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">ID do Recurso</div>
                  <div className="font-medium">{selectedLog.resource_id || '-'}</div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">Endereço IP</div>
                  <div className="font-medium">{selectedLog.ip_address}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm text-gray-500">User Agent</div>
                  <div className="font-medium text-sm truncate">{selectedLog.user_agent}</div>
                </div>
              </div>
              
              {selectedLog.additional_data && (
                <div className="space-y-2">
                  <div className="text-sm text-gray-500">Dados Adicionais</div>
                  <div className="bg-gray-50 p-4 rounded-md">
                    <pre className="text-xs overflow-auto whitespace-pre-wrap">
                      {JSON.stringify(selectedLog.additional_data, null, 2)}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
