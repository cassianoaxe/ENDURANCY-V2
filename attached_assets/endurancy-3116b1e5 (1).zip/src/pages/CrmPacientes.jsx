
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Users, 
  Search, 
  Plus, 
  Filter, 
  FileText, 
  Download, 
  Heart, 
  Calendar, 
  Phone, 
  Mail, 
  User, 
  MoreHorizontal,
  Calendar as CalendarIcon,
  Clipboard,
  FileCheck2,
  ShoppingBag,
  PieChart,
  Clock,
  ChevronDown,
  CheckCircle,
  XCircle,
  AlertCircle,
  Clock3,
  ArrowUpDown,
  FileEdit
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";

// Dados simulados para pacientes
const mockPatients = [
  {
    id: "pac001",
    nome_completo: "Maria Silva Oliveira",
    cpf: "123.456.789-00",
    data_nascimento: "1975-05-15",
    genero: "feminino",
    telefone: "(11) 98765-4321",
    email: "maria.silva@email.com",
    endereco: "Rua das Flores, 123 - Jardim Primavera - São Paulo/SP",
    status: "ativo",
    condicoes_medicas: ["Epilepsia Refratária", "Ansiedade"],
    data_registro: "2022-03-10",
    ultima_consulta: "2023-06-05",
    receitas_ativas: 2,
    pedidos_totais: 8,
    ultima_compra: "2023-06-20",
    medico_responsavel: "Dr. João Carlos Santos",
    avatar: ""
  },
  {
    id: "pac002",
    nome_completo: "José Pereira Souza",
    cpf: "987.654.321-00",
    data_nascimento: "1968-08-22",
    genero: "masculino",
    telefone: "(11) 97654-3210",
    email: "jose.pereira@email.com",
    endereco: "Av. Paulista, 1000 - Apto 205 - São Paulo/SP",
    status: "ativo",
    condicoes_medicas: ["Dor Crônica", "Insônia"],
    data_registro: "2022-05-20",
    ultima_consulta: "2023-05-15",
    receitas_ativas: 1,
    pedidos_totais: 5,
    ultima_compra: "2023-05-18",
    medico_responsavel: "Dra. Ana Paula Mendes",
    avatar: ""
  },
  {
    id: "pac003",
    nome_completo: "Antônio Carlos Ferreira",
    cpf: "456.789.123-00",
    data_nascimento: "1950-02-10",
    genero: "masculino",
    telefone: "(11) 96543-2109",
    email: "antonio.ferreira@email.com",
    endereco: "Rua dos Ipês, 45 - Vila Verde - São Paulo/SP",
    status: "ativo",
    condicoes_medicas: ["Parkinson", "Artrite"],
    data_registro: "2022-01-15",
    ultima_consulta: "2023-06-01",
    receitas_ativas: 2,
    pedidos_totais: 12,
    ultima_compra: "2023-06-10",
    medico_responsavel: "Dr. Roberto Almeida",
    avatar: ""
  },
  {
    id: "pac004",
    nome_completo: "Ana Beatriz Martins",
    cpf: "789.123.456-00",
    data_nascimento: "1990-11-28",
    genero: "feminino",
    telefone: "(11) 95432-1098",
    email: "ana.martins@email.com",
    endereco: "Alameda Santos, 500 - Apto 102 - São Paulo/SP",
    status: "inativo",
    condicoes_medicas: ["Ansiedade", "Enxaqueca"],
    data_registro: "2022-07-05",
    ultima_consulta: "2022-12-20",
    receitas_ativas: 0,
    pedidos_totais: 3,
    ultima_compra: "2022-12-22",
    medico_responsavel: "Dra. Maria do Carmo",
    avatar: ""
  },
  {
    id: "pac005",
    nome_completo: "Carlos Eduardo Santos",
    cpf: "321.654.987-00",
    data_nascimento: "1985-04-17",
    genero: "masculino",
    telefone: "(11) 94321-0987",
    email: "carlos.santos@email.com",
    endereco: "Rua Augusta, 1500 - Apto 504 - São Paulo/SP",
    status: "ativo",
    condicoes_medicas: ["Esclerose Múltipla"],
    data_registro: "2023-01-10",
    ultima_consulta: "2023-05-25",
    receitas_ativas: 1,
    pedidos_totais: 2,
    ultima_compra: "2023-05-28",
    medico_responsavel: "Dr. Paulo Menezes",
    avatar: ""
  },
  {
    id: "pac006",
    nome_completo: "Laura Cristina Alves",
    cpf: "654.987.321-00",
    data_nascimento: "1972-09-03",
    genero: "feminino",
    telefone: "(11) 93210-9876",
    email: "laura.alves@email.com",
    endereco: "Rua Consolação, 200 - São Paulo/SP",
    status: "pendente",
    condicoes_medicas: ["Fibromialgia", "Insônia"],
    data_registro: "2023-06-01",
    ultima_consulta: "2023-06-15",
    receitas_ativas: 1,
    pedidos_totais: 0,
    ultima_compra: "",
    medico_responsavel: "Dra. Sandra Gomes",
    avatar: ""
  },
  {
    id: "pac007",
    nome_completo: "Roberto Mendes Costa",
    cpf: "234.567.890-00",
    data_nascimento: "1960-06-25",
    genero: "masculino",
    telefone: "(11) 92109-8765",
    email: "roberto.costa@email.com",
    endereco: "Av. Rebouças, 1200 - São Paulo/SP",
    status: "ativo",
    condicoes_medicas: ["Alzheimer", "Hipertensão"],
    data_registro: "2022-02-10",
    ultima_consulta: "2023-04-20",
    receitas_ativas: 2,
    pedidos_totais: 9,
    ultima_compra: "2023-06-05",
    medico_responsavel: "Dr. Antônio Silveira",
    avatar: ""
  },
  {
    id: "pac008",
    nome_completo: "Juliana Ferreira Dias",
    cpf: "345.678.901-00",
    data_nascimento: "1988-12-12",
    genero: "feminino",
    telefone: "(11) 91098-7654",
    email: "juliana.dias@email.com",
    endereco: "Rua Oscar Freire, 500 - São Paulo/SP",
    status: "ativo",
    condicoes_medicas: ["Ansiedade", "Depressão"],
    data_registro: "2022-09-15",
    ultima_consulta: "2023-06-10",
    receitas_ativas: 1,
    pedidos_totais: 4,
    ultima_compra: "2023-06-15",
    medico_responsavel: "Dra. Camila Rocha",
    avatar: ""
  }
];

// Dados simulados para prescrições
const mockPrescriptions = [
  {
    id: "presc001",
    paciente_id: "pac001",
    medico: "Dr. João Carlos Santos",
    crm: "CRM-SP 123456",
    data_emissao: "2023-06-05",
    data_validade: "2024-06-05",
    status: "ativa",
    produtos: [
      { nome: "Óleo CBD 5% 30ml", dosagem: "1ml (15 gotas) 2x ao dia", quantidade: 2 },
      { nome: "Spray CBD 2.5% 30ml", dosagem: "2 borrifadas pela manhã", quantidade: 1 }
    ]
  },
  {
    id: "presc002",
    paciente_id: "pac001",
    medico: "Dr. João Carlos Santos",
    crm: "CRM-SP 123456",
    data_emissao: "2022-12-10",
    data_validade: "2023-12-10",
    status: "ativa",
    produtos: [
      { nome: "Cápsulas CBD 20mg", dosagem: "1 cápsula ao dia", quantidade: 3 }
    ]
  },
  {
    id: "presc003",
    paciente_id: "pac002",
    medico: "Dra. Ana Paula Mendes",
    crm: "CRM-SP 234567",
    data_emissao: "2023-05-15",
    data_validade: "2024-05-15",
    status: "ativa",
    produtos: [
      { nome: "Óleo CBD 10% 10ml", dosagem: "0.5ml (8 gotas) à noite", quantidade: 3 }
    ]
  },
  {
    id: "presc004",
    paciente_id: "pac003",
    medico: "Dr. Roberto Almeida",
    crm: "CRM-SP 345678",
    data_emissao: "2023-06-01",
    data_validade: "2024-06-01",
    status: "ativa",
    produtos: [
      { nome: "Óleo CBD 15% 20ml", dosagem: "0.7ml (10 gotas) 2x ao dia", quantidade: 2 },
      { nome: "Creme CBD tópico 50g", dosagem: "Aplicar nas articulações 3x ao dia", quantidade: 1 }
    ]
  },
  {
    id: "presc005",
    paciente_id: "pac003",
    medico: "Dr. Roberto Almeida",
    crm: "CRM-SP 345678",
    data_emissao: "2023-06-01",
    data_validade: "2024-06-01",
    status: "ativa",
    produtos: [
      { nome: "Cápsulas CBD 20mg", dosagem: "1 cápsula a cada 12h", quantidade: 2 }
    ]
  },
  {
    id: "presc006",
    paciente_id: "pac004",
    medico: "Dra. Maria do Carmo",
    crm: "CRM-SP 456789",
    data_emissao: "2022-12-20",
    data_validade: "2023-12-20",
    status: "expirada",
    produtos: [
      { nome: "Óleo CBD 5% 30ml", dosagem: "1ml (15 gotas) à noite", quantidade: 1 }
    ]
  },
  {
    id: "presc007",
    paciente_id: "pac005",
    medico: "Dr. Paulo Menezes",
    crm: "CRM-SP 567890",
    data_emissao: "2023-05-25",
    data_validade: "2024-05-25",
    status: "ativa",
    produtos: [
      { nome: "Óleo CBD 20% 10ml", dosagem: "0.3ml (5 gotas) 3x ao dia", quantidade: 3 }
    ]
  },
  {
    id: "presc008",
    paciente_id: "pac006",
    medico: "Dra. Sandra Gomes",
    crm: "CRM-SP 678901",
    data_emissao: "2023-06-15",
    data_validade: "2024-06-15",
    status: "ativa",
    produtos: [
      { nome: "Gel CBD para dores 100g", dosagem: "Aplicar na região afetada 3x ao dia", quantidade: 2 }
    ]
  },
  {
    id: "presc009",
    paciente_id: "pac007",
    medico: "Dr. Antônio Silveira",
    crm: "CRM-SP 789012",
    data_emissao: "2023-04-20",
    data_validade: "2024-04-20",
    status: "ativa",
    produtos: [
      { nome: "Óleo CBD 5% 30ml", dosagem: "1ml (15 gotas) pela manhã", quantidade: 3 },
      { nome: "Cápsulas CBD 10mg", dosagem: "1 cápsula à noite", quantidade: 2 }
    ]
  },
  {
    id: "presc010",
    paciente_id: "pac007",
    medico: "Dr. Antônio Silveira",
    crm: "CRM-SP 789012",
    data_emissao: "2023-04-20",
    data_validade: "2024-04-20",
    status: "ativa",
    produtos: [
      { nome: "Spray CBD 2.5% 30ml", dosagem: "2 borrifadas sublingual 2x ao dia", quantidade: 2 }
    ]
  },
  {
    id: "presc011",
    paciente_id: "pac008",
    medico: "Dra. Camila Rocha",
    crm: "CRM-SP 890123",
    data_emissao: "2023-06-10",
    data_validade: "2024-06-10",
    status: "ativa",
    produtos: [
      { nome: "Óleo CBD 10% 10ml", dosagem: "0.5ml (8 gotas) à noite", quantidade: 2 }
    ]
  }
];

// Dados simulados para pedidos
const mockOrders = [
  {
    id: "ped001",
    paciente_id: "pac001",
    data_pedido: "2023-06-20",
    status: "entregue",
    total: 380.00,
    produtos: [
      { nome: "Óleo CBD 5% 30ml", quantidade: 2, preco: 180.00 },
      { nome: "Spray CBD 2.5% 30ml", quantidade: 1, preco: 130.00 }
    ],
    prescricao_id: "presc001"
  },
  {
    id: "ped002",
    paciente_id: "pac001",
    data_pedido: "2023-05-15",
    status: "entregue",
    total: 180.00,
    produtos: [
      { nome: "Óleo CBD 5% 30ml", quantidade: 1, preco: 180.00 }
    ],
    prescricao_id: "presc001"
  },
  {
    id: "ped003",
    paciente_id: "pac001",
    data_pedido: "2023-04-10",
    status: "entregue",
    total: 450.00,
    produtos: [
      { nome: "Cápsulas CBD 20mg", quantidade: 3, preco: 150.00 }
    ],
    prescricao_id: "presc002"
  },
  {
    id: "ped004",
    paciente_id: "pac002",
    data_pedido: "2023-05-18",
    status: "entregue",
    total: 360.00,
    produtos: [
      { nome: "Óleo CBD 10% 10ml", quantidade: 3, preco: 120.00 }
    ],
    prescricao_id: "presc003"
  },
  {
    id: "ped005",
    paciente_id: "pac003",
    data_pedido: "2023-06-10",
    status: "entregue",
    total: 530.00,
    produtos: [
      { nome: "Óleo CBD 15% 20ml", quantidade: 2, preco: 220.00 },
      { nome: "Creme CBD tópico 50g", quantidade: 1, preco: 90.00 }
    ],
    prescricao_id: "presc004"
  },
  {
    id: "ped006",
    paciente_id: "pac003",
    data_pedido: "2023-05-20",
    status: "entregue",
    total: 300.00,
    produtos: [
      { nome: "Cápsulas CBD 20mg", quantidade: 2, preco: 150.00 }
    ],
    prescricao_id: "presc005"
  },
  {
    id: "ped007",
    paciente_id: "pac005",
    data_pedido: "2023-05-28",
    status: "entregue",
    total: 660.00,
    produtos: [
      { nome: "Óleo CBD 20% 10ml", quantidade: 3, preco: 220.00 }
    ],
    prescricao_id: "presc007"
  },
  {
    id: "ped008",
    paciente_id: "pac007",
    data_pedido: "2023-06-05",
    status: "entregue",
    total: 540.00,
    produtos: [
      { nome: "Óleo CBD 5% 30ml", quantidade: 3, preco: 180.00 }
    ],
    prescricao_id: "presc009"
  },
  {
    id: "ped009",
    paciente_id: "pac008",
    data_pedido: "2023-06-15",
    status: "entregue",
    total: 240.00,
    produtos: [
      { nome: "Óleo CBD 10% 10ml", quantidade: 2, preco: 120.00 }
    ],
    prescricao_id: "presc011"
  }
];

export default function CrmPacientes() {
  const [patients, setPatients] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [activeTab, setActiveTab] = useState("todos");
  const [prescriptions, setPrescriptions] = useState([]);
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadPatients();
  }, []);

  const loadPatients = async () => {
    setIsLoading(true);
    // Simular carregamento de dados
    setTimeout(() => {
      setPatients(mockPatients);
      setPrescriptions(mockPrescriptions);
      setOrders(mockOrders);
      setIsLoading(false);
    }, 800);
  };

  // Carregar prescrições do paciente
  const getPatientPrescriptions = (patientId) => {
    return prescriptions.filter(p => p.paciente_id === patientId);
  };

  // Carregar pedidos do paciente
  const getPatientOrders = (patientId) => {
    return orders.filter(o => o.paciente_id === patientId);
  };

  // Filtrar pacientes por status
  const filteredByStatus = statusFilter === "all" 
    ? patients 
    : patients.filter(patient => patient.status === statusFilter);

  // Filtrar pacientes por busca
  const filteredPatients = searchTerm
    ? filteredByStatus.filter(patient => 
        patient.nome_completo.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.cpf.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.telefone.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : filteredByStatus;

  // Filtrar por tab
  const tabFilteredPatients = activeTab === "todos" 
    ? filteredPatients
    : activeTab === "ativos"
      ? filteredPatients.filter(patient => patient.status === "ativo")
      : activeTab === "inativos"
        ? filteredPatients.filter(patient => patient.status === "inativo")
        : activeTab === "pendentes"
          ? filteredPatients.filter(patient => patient.status === "pendente")
          : filteredPatients;

  // Formatar data para exibição
  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  // Obter iniciais do nome
  const getInitials = (name) => {
    if (!name) return "";
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .substring(0, 2)
      .toUpperCase();
  };

  // Obter cor do badge de status
  const getStatusColor = (status) => {
    switch (status) {
      case 'ativo': return 'bg-green-100 text-green-800';
      case 'inativo': return 'bg-red-100 text-red-800';
      case 'pendente': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Obter label do status
  const getStatusLabel = (status) => {
    switch (status) {
      case 'ativo': return 'Ativo';
      case 'inativo': return 'Inativo';
      case 'pendente': return 'Pendente';
      default: return status;
    }
  };

  // Abrir detalhes do paciente
  const openPatientDetails = (patient) => {
    setSelectedPatient(patient);
    setShowDetailDialog(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Pacientes</h1>
          <p className="text-gray-500 mt-1">
            Gerenciamento de pacientes e suas prescrições
          </p>
        </div>
        <Link to={createPageUrl("CrmNovoPaciente")}>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Novo Paciente
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Total de Pacientes</CardTitle>
            <div className="text-2xl font-bold">{patients.length}</div>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Pacientes Ativos</CardTitle>
            <div className="text-2xl font-bold">{patients.filter(p => p.status === 'ativo').length}</div>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Receitas Ativas</CardTitle>
            <div className="text-2xl font-bold">{prescriptions.filter(p => p.status === 'ativa').length}</div>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Total de Pedidos</CardTitle>
            <div className="text-2xl font-bold">{orders.length}</div>
          </CardHeader>
        </Card>
      </div>

      <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <Input
            placeholder="Buscar por nome, CPF, email ou telefone..."
            className="pl-10 w-full"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos Status</SelectItem>
              <SelectItem value="ativo">Ativos</SelectItem>
              <SelectItem value="inativo">Inativos</SelectItem>
              <SelectItem value="pendente">Pendentes</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" onClick={loadPatients}>
            <ArrowUpDown className="mr-2 h-4 w-4" />
            Atualizar
          </Button>

          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
        </div>
      </div>

      <Tabs defaultValue="todos" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="todos">Todos</TabsTrigger>
          <TabsTrigger value="ativos">Ativos</TabsTrigger>
          <TabsTrigger value="pendentes">Pendentes</TabsTrigger>
          <TabsTrigger value="inativos">Inativos</TabsTrigger>
        </TabsList>
      </Tabs>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
          <p className="ml-2">Carregando pacientes...</p>
        </div>
      ) : tabFilteredPatients.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <Users className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-lg font-medium">Nenhum paciente encontrado</h3>
          <p className="mt-1 text-gray-500">
            Não existem pacientes que correspondam aos filtros selecionados.
          </p>
          <Button variant="outline" className="mt-4" onClick={() => {
            setSearchTerm("");
            setStatusFilter("all");
          }}>
            Limpar filtros
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Paciente</TableHead>
                  <TableHead>Contato</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Receitas</TableHead>
                  <TableHead>Pedidos</TableHead>
                  <TableHead>Última Consulta</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tabFilteredPatients.map((patient) => (
                  <TableRow key={patient.id} className="cursor-pointer hover:bg-gray-50" onClick={() => openPatientDetails(patient)}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9">
                          {patient.avatar ? (
                            <AvatarImage src={patient.avatar} alt={patient.nome_completo} />
                          ) : (
                            <AvatarFallback className="bg-green-100 text-green-800">
                              {getInitials(patient.nome_completo)}
                            </AvatarFallback>
                          )}
                        </Avatar>
                        <div>
                          <div className="font-medium">{patient.nome_completo}</div>
                          <div className="text-xs text-gray-500">{patient.cpf}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <div className="flex items-center">
                          <Phone className="h-3 w-3 mr-1 text-gray-400" />
                          <span className="text-sm">{patient.telefone}</span>
                        </div>
                        <div className="flex items-center mt-1">
                          <Mail className="h-3 w-3 mr-1 text-gray-400" />
                          <span className="text-sm">{patient.email}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(patient.status)}>
                        {getStatusLabel(patient.status)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <FileCheck2 className="h-4 w-4 mr-1 text-green-600" />
                        <span>{patient.receitas_ativas} ativas</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <ShoppingBag className="h-4 w-4 mr-1 text-blue-600" />
                        <span>{patient.pedidos_totais} pedidos</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                        <span>{formatDate(patient.ultima_consulta)}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div onClick={(e) => e.stopPropagation()}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openPatientDetails(patient)}>
                              <User className="h-4 w-4 mr-2" />
                              Ver Detalhes
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => navigate(createPageUrl(`CrmEditarPaciente?id=${patient.id}`))}>
                              <FileEdit className="h-4 w-4 mr-2" />
                              Editar Paciente
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <FileText className="h-4 w-4 mr-2" />
                              Ver Receitas
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <ShoppingBag className="h-4 w-4 mr-2" />
                              Ver Pedidos
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Clock className="h-4 w-4 mr-2" />
                              Histórico
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {/* Diálogo de detalhes do paciente */}
      {selectedPatient && (
        <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
          <DialogContent className="max-w-5xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Detalhes do Paciente
              </DialogTitle>
              <DialogDescription>
                Informações completas do paciente e seu histórico
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center mb-4">
                      <Avatar className="h-20 w-20 mb-3">
                        {selectedPatient.avatar ? (
                          <AvatarImage src={selectedPatient.avatar} alt={selectedPatient.nome_completo} />
                        ) : (
                          <AvatarFallback className="bg-green-100 text-green-800 text-xl">
                            {getInitials(selectedPatient.nome_completo)}
                          </AvatarFallback>
                        )}
                      </Avatar>
                      <h3 className="text-lg font-semibold text-center">{selectedPatient.nome_completo}</h3>
                      <Badge className={`mt-2 ${getStatusColor(selectedPatient.status)}`}>
                        {getStatusLabel(selectedPatient.status)}
                      </Badge>
                    </div>

                    <Separator className="my-4" />

                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-gray-500 mb-1">CPF</p>
                        <p className="font-medium">{selectedPatient.cpf}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Data de Nascimento</p>
                        <p className="font-medium">{formatDate(selectedPatient.data_nascimento)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Email</p>
                        <p className="font-medium">{selectedPatient.email}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Telefone</p>
                        <p className="font-medium">{selectedPatient.telefone}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Endereço</p>
                        <p className="font-medium">{selectedPatient.endereco}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Condições Médicas</p>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {selectedPatient.condicoes_medicas.map((condicao, index) => (
                            <Badge key={index} variant="outline" className="bg-purple-50">
                              {condicao}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Médico Responsável</p>
                        <p className="font-medium">{selectedPatient.medico_responsavel}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="lg:col-span-2">
                <Tabs defaultValue="prescricoes">
                  <TabsList className="mb-4">
                    <TabsTrigger value="prescricoes">Prescrições</TabsTrigger>
                    <TabsTrigger value="pedidos">Pedidos</TabsTrigger>
                    <TabsTrigger value="historico">Histórico</TabsTrigger>
                  </TabsList>

                  <TabsContent value="prescricoes">
                    <div className="bg-white rounded-lg shadow">
                      <div className="p-4 border-b">
                        <h3 className="font-semibold">Prescrições Médicas</h3>
                      </div>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Médico</TableHead>
                              <TableHead>Data Emissão</TableHead>
                              <TableHead>Validade</TableHead>
                              <TableHead>Produtos</TableHead>
                              <TableHead>Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {getPatientPrescriptions(selectedPatient.id).map((prescription) => (
                              <TableRow key={prescription.id}>
                                <TableCell>
                                  <div>
                                    <p className="font-medium">{prescription.medico}</p>
                                    <p className="text-xs text-gray-500">{prescription.crm}</p>
                                  </div>
                                </TableCell>
                                <TableCell>{formatDate(prescription.data_emissao)}</TableCell>
                                <TableCell>{formatDate(prescription.data_validade)}</TableCell>
                                <TableCell>
                                  <div className="space-y-1">
                                    {prescription.produtos.map((produto, idx) => (
                                      <p key={idx} className="text-sm">
                                        {produto.nome} ({produto.quantidade}x)
                                      </p>
                                    ))}
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Badge className={prescription.status === 'ativa' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                                    {prescription.status === 'ativa' ? 'Ativa' : 'Expirada'}
                                  </Badge>
                                </TableCell>
                              </TableRow>
                            ))}
                            {getPatientPrescriptions(selectedPatient.id).length === 0 && (
                              <TableRow>
                                <TableCell colSpan={5} className="text-center py-4 text-gray-500">
                                  Não há prescrições para este paciente
                                </TableCell>
                              </TableRow>
                            )}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="pedidos">
                    <div className="bg-white rounded-lg shadow">
                      <div className="p-4 border-b">
                        <h3 className="font-semibold">Histórico de Pedidos</h3>
                      </div>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>ID Pedido</TableHead>
                              <TableHead>Data</TableHead>
                              <TableHead>Produtos</TableHead>
                              <TableHead>Total</TableHead>
                              <TableHead>Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {getPatientOrders(selectedPatient.id).map((order) => (
                              <TableRow key={order.id}>
                                <TableCell className="font-medium">{order.id}</TableCell>
                                <TableCell>{formatDate(order.data_pedido)}</TableCell>
                                <TableCell>
                                  <div className="space-y-1">
                                    {order.produtos.map((produto, idx) => (
                                      <p key={idx} className="text-sm">
                                        {produto.nome} (x{produto.quantidade})
                                      </p>
                                    ))}
                                  </div>
                                </TableCell>
                                <TableCell>
                                  {new Intl.NumberFormat('pt-BR', {
                                    style: 'currency',
                                    currency: 'BRL'
                                  }).format(order.total)}
                                </TableCell>
                                <TableCell>
                                  <Badge className={
                                    order.status === 'entregue' ? 'bg-green-100 text-green-800' :
                                    order.status === 'em_andamento' ? 'bg-blue-100 text-blue-800' :
                                    'bg-gray-100 text-gray-800'
                                  }>
                                    {order.status === 'entregue' ? 'Entregue' : 
                                     order.status === 'em_andamento' ? 'Em andamento' : 
                                     order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                                  </Badge>
                                </TableCell>
                              </TableRow>
                            ))}
                            {getPatientOrders(selectedPatient.id).length === 0 && (
                              <TableRow>
                                <TableCell colSpan={5} className="text-center py-4 text-gray-500">
                                  Não há pedidos para este paciente
                                </TableCell>
                              </TableRow>
                            )}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="historico">
                    <div className="bg-white rounded-lg shadow p-6">
                      <h3 className="font-semibold mb-4">Dados do Registro</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <p className="text-sm text-gray-500">Data de Registro</p>
                          <p className="font-medium">{formatDate(selectedPatient.data_registro)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Última Consulta</p>
                          <p className="font-medium">{formatDate(selectedPatient.ultima_consulta)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Última Compra</p>
                          <p className="font-medium">{formatDate(selectedPatient.ultima_compra)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Total de Pedidos</p>
                          <p className="font-medium">{selectedPatient.pedidos_totais}</p>
                        </div>
                      </div>

                      {/* Aqui poderíamos adicionar um histórico de atividades, mas vamos deixar vazio por ora */}
                      <div className="mt-8">
                        <h3 className="font-semibold mb-4">Histórico de Atividades</h3>
                        <div className="text-center py-8 text-gray-500">
                          <Clock3 className="w-12 h-12 mx-auto text-gray-300 mb-2" />
                          <p>Histórico detalhado em desenvolvimento</p>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>

            <DialogFooter className="flex justify-between items-center flex-wrap gap-2">
              <div className="space-x-2">
                <Button variant="outline" size="sm" asChild>
                  <Link to={`${createPageUrl("CrmNovaPrescricao")}?paciente_id=${selectedPatient.id}`}>
                    <FileText className="w-4 h-4 mr-1" />
                    Nova Prescrição
                  </Link>
                </Button>
                <Button variant="outline" size="sm" asChild>
                  <Link to={`${createPageUrl("CrmNovoPedido")}?paciente_id=${selectedPatient.id}`}>
                    <ShoppingBag className="w-4 h-4 mr-1" />
                    Novo Pedido
                  </Link>
                </Button>
              </div>
              
              <div className="space-x-2">
                <Button variant="outline" onClick={() => setShowDetailDialog(false)}>
                  Fechar
                </Button>
                <Button asChild>
                  <Link to={`${createPageUrl("CrmEditarPaciente")}?id=${selectedPatient.id}`}>
                    Editar Paciente
                  </Link>
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
