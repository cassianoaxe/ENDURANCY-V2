
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { toast } from "@/components/ui/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  FileText,
  Send,
  Download,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Calendar,
  ArrowRight,
  RefreshCw,
  Printer,
  FileBadge,
  FileWarning,
  FileCheck,
  FileX,
  Upload,
  Plus,
  Eye,
  X,
  Search
} from 'lucide-react';
import { format, startOfMonth, endOfMonth, subMonths, addDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function RelatorioSNGPC() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [relatorios, setRelatorios] = useState([]);
  const [periodoInicio, setPeriodoInicio] = useState(format(startOfMonth(subMonths(new Date(), 1)), 'yyyy-MM-dd'));
  const [periodoFim, setPeriodoFim] = useState(format(endOfMonth(subMonths(new Date(), 1)), 'yyyy-MM-dd'));
  const [showNovoRelatorio, setShowNovoRelatorio] = useState(false);
  const [enviandoRelatorio, setEnviandoRelatorio] = useState(false);
  const [showDetalhes, setShowDetalhes] = useState(false);
  const [relatorioSelecionado, setRelatorioSelecionado] = useState(null);
  const [resumoMovimentacoes, setResumoMovimentacoes] = useState({
    entradas: 0,
    saidas: 0,
    perdas: 0,
    total_medicamentos: 0
  });
  const [statusFiltro, setStatusFiltro] = useState('todos');
  const [receituariosPendentes, setReceituariosPendentes] = useState([]);
  const [showConfirmEnvio, setShowConfirmEnvio] = useState(false);
  const [showReceituariosPendentes, setShowReceituariosPendentes] = useState(false);

  useEffect(() => {
    const loadData = () => {
      try {
        const userType = localStorage.getItem('mockUserType');
        if (!userType) {
          console.log("User not authenticated, redirecting to login");
          navigate(createPageUrl("Access"));
          return;
        }

        const mockRelatorios = [
          {
            id: '1',
            periodo_inicio: '2024-01-01',
            periodo_fim: '2024-01-31',
            data_envio: '2024-02-01T10:00:00Z',
            status: 'enviado',
            protocolo: 'SNGPC-2024-001',
            quantidade_entradas: 15,
            quantidade_saidas: 12,
            quantidade_perdas: 0
          },
        ];

        setRelatorios(mockRelatorios);
        setIsLoading(false);
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar os relatórios SNGPC.",
          variant: "destructive",
        });
      }
    };

    loadData();
  }, [navigate]);

  const handleCriarRelatorio = async () => {
    try {
      setEnviandoRelatorio(true);
      
      const relatorioExistente = relatorios.find(
        r => r.periodo_inicio === periodoInicio && r.periodo_fim === periodoFim
      );
      
      if (relatorioExistente) {
        toast({
          title: "Relatório já existe",
          description: "Já existe um relatório para o período selecionado.",
          variant: "destructive",
        });
        setEnviandoRelatorio(false);
        return;
      }
      
      const novoRelatorio = {
        id: `rel-${Date.now()}`,
        organization_id: "mock-org",
        periodo_inicio: periodoInicio,
        periodo_fim: periodoFim,
        data_envio: new Date().toISOString(),
        status: "pendente",
        farmaceutico_id: "mock-user",
        quantidade_entradas: resumoMovimentacoes.entradas,
        quantidade_saidas: resumoMovimentacoes.saidas,
        quantidade_perdas: resumoMovimentacoes.perdas
      };
      
      setRelatorios(prev => [novoRelatorio, ...prev]);
      
      toast({
        title: "Relatório criado",
        description: "O relatório foi criado com sucesso e está pronto para envio.",
      });
      
      setShowNovoRelatorio(false);
      
    } catch (error) {
      console.error("Erro ao criar relatório:", error);
      toast({
        title: "Erro",
        description: "Não foi possível criar o relatório.",
        variant: "destructive",
      });
    } finally {
      setEnviandoRelatorio(false);
    }
  };

  const handleEnviarRelatorio = async (relatorio) => {
    try {
      toast({
        title: "Enviando relatório",
        description: "Enviando relatório para o SNGPC...",
      });
      
      setTimeout(() => {
        const relatorioAtualizado = {
          ...relatorio,
          status: "enviado",
          protocolo: `SNGPC${Math.floor(Math.random() * 1000000000)}`,
          data_envio: new Date().toISOString()
        };
        
        setRelatorios(prev => 
          prev.map(r => r.id === relatorio.id ? relatorioAtualizado : r)
        );
        
        toast({
          title: "Relatório enviado",
          description: "O relatório foi enviado com sucesso para o SNGPC.",
        });
        
        setShowConfirmEnvio(false);
      }, 2000);
      
    } catch (error) {
      console.error("Erro ao enviar relatório:", error);
      toast({
        title: "Erro",
        description: "Não foi possível enviar o relatório.",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      pendente: { label: 'Pendente', className: 'bg-yellow-100 text-yellow-800' },
      enviado: { label: 'Enviado', className: 'bg-blue-100 text-blue-800' },
      aceito: { label: 'Aceito', className: 'bg-green-100 text-green-800' },
      rejeitado: { label: 'Rejeitado', className: 'bg-red-100 text-red-800' },
      erro: { label: 'Erro', className: 'bg-red-100 text-red-800' }
    };
    
    return (
      <Badge className={statusConfig[status].className}>
        {statusConfig[status].label}
      </Badge>
    );
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pendente':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'enviado':
        return <Send className="h-5 w-5 text-blue-500" />;
      case 'aceito':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'rejeitado':
      case 'erro':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      default:
        return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-green-200 border-t-green-600"></div>
          <p className="text-sm text-gray-500">Carregando relatórios...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Relatórios SNGPC</h1>
          <p className="text-gray-500">Sistema Nacional de Gerenciamento de Produtos Controlados</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => setShowNovoRelatorio(true)}
            className="bg-green-600 hover:bg-green-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Relatório
          </Button>
          {receituariosPendentes.length > 0 && (
            <Button 
              variant="outline" 
              onClick={() => setShowReceituariosPendentes(true)}
              className="relative"
            >
              <FileText className="w-4 h-4 mr-2" />
              Receituários Pendentes
              <Badge className="absolute -top-2 -right-2 bg-red-500 text-white">
                {receituariosPendentes.length}
              </Badge>
            </Button>
          )}
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <Label>Período</Label>
              <div className="flex items-center gap-2">
                <Input
                  type="date"
                  value={periodoInicio}
                  onChange={(e) => setPeriodoInicio(e.target.value)}
                />
                <ArrowRight className="h-4 w-4 text-gray-400" />
                <Input
                  type="date"
                  value={periodoFim}
                  onChange={(e) => setPeriodoFim(e.target.value)}
                />
              </div>
            </div>
            
            <div>
              <Label>Status</Label>
              <Select 
                value={statusFiltro} 
                onValueChange={setStatusFiltro}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  <SelectItem value="pendente">Pendente</SelectItem>
                  <SelectItem value="enviado">Enviado</SelectItem>
                  <SelectItem value="aceito">Aceito</SelectItem>
                  <SelectItem value="rejeitado">Rejeitado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-end">
              <Button className="w-full" variant="outline">
                <Search className="h-4 w-4 mr-2" />
                Aplicar Filtros
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Status</TableHead>
                  <TableHead>Período</TableHead>
                  <TableHead>Data Envio</TableHead>
                  <TableHead>Protocolo</TableHead>
                  <TableHead className="text-center">Entradas</TableHead>
                  <TableHead className="text-center">Saídas</TableHead>
                  <TableHead className="text-center">Perdas</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {relatorios.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                      Nenhum relatório encontrado
                    </TableCell>
                  </TableRow>
                ) : (
                  relatorios
                    .filter(rel => statusFiltro === 'todos' || rel.status === statusFiltro)
                    .map((relatorio) => (
                      <TableRow key={relatorio.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(relatorio.status)}
                            {getStatusBadge(relatorio.status)}
                          </div>
                        </TableCell>
                        <TableCell>
                          {format(new Date(relatorio.periodo_inicio), 'dd/MM/yyyy')} a {format(new Date(relatorio.periodo_fim), 'dd/MM/yyyy')}
                        </TableCell>
                        <TableCell>
                          {relatorio.data_envio ? format(new Date(relatorio.data_envio), 'dd/MM/yyyy HH:mm') : '-'}
                        </TableCell>
                        <TableCell>{relatorio.protocolo || '-'}</TableCell>
                        <TableCell className="text-center">{relatorio.quantidade_entradas}</TableCell>
                        <TableCell className="text-center">{relatorio.quantidade_saidas}</TableCell>
                        <TableCell className="text-center">{relatorio.quantidade_perdas}</TableCell>
                        <TableCell>
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setRelatorioSelecionado(relatorio);
                                setShowDetalhes(true);
                              }}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            
                            {relatorio.status === 'pendente' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setRelatorioSelecionado(relatorio);
                                  setShowConfirmEnvio(true);
                                }}
                              >
                                <Send className="h-4 w-4" />
                              </Button>
                            )}
                            
                            {['enviado', 'aceito', 'rejeitado'].includes(relatorio.status) && (
                              <Button
                                variant="ghost"
                                size="icon"
                              >
                                <Download className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      <Dialog open={showNovoRelatorio} onOpenChange={setShowNovoRelatorio}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Novo Relatório SNGPC</DialogTitle>
            <DialogDescription>
              Selecione o período para criar um novo relatório
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Período de Referência</Label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs">Data Inicial</Label>
                  <Input
                    type="date"
                    value={periodoInicio}
                    onChange={(e) => setPeriodoInicio(e.target.value)}
                  />
                </div>
                <div>
                  <Label className="text-xs">Data Final</Label>
                  <Input
                    type="date"
                    value={periodoFim}
                    onChange={(e) => setPeriodoFim(e.target.value)}
                  />
                </div>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <h3 className="font-medium">Resumo das Movimentações</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 p-3 rounded-md border border-blue-100">
                  <p className="text-sm text-blue-800 font-medium">Entradas</p>
                  <p className="text-xl font-bold text-blue-800">{resumoMovimentacoes.entradas}</p>
                </div>
                <div className="bg-green-50 p-3 rounded-md border border-green-100">
                  <p className="text-sm text-green-800 font-medium">Saídas</p>
                  <p className="text-xl font-bold text-green-800">{resumoMovimentacoes.saidas}</p>
                </div>
                <div className="bg-red-50 p-3 rounded-md border border-red-100">
                  <p className="text-sm text-red-800 font-medium">Perdas</p>
                  <p className="text-xl font-bold text-red-800">{resumoMovimentacoes.perdas}</p>
                </div>
                <div className="bg-purple-50 p-3 rounded-md border border-purple-100">
                  <p className="text-sm text-purple-800 font-medium">Medicamentos</p>
                  <p className="text-xl font-bold text-purple-800">{resumoMovimentacoes.total_medicamentos}</p>
                </div>
              </div>
            </div>
            
            {receituariosPendentes.length > 0 && (
              <div className="bg-yellow-50 p-4 rounded-md border border-yellow-200">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <p className="text-yellow-800 font-medium">
                    Existem receituários pendentes de envio
                  </p>
                </div>
                <p className="text-sm text-yellow-700 mt-1">
                  Existem {receituariosPendentes.length} receituários que não foram enviados ao SNGPC.
                  É recomendado enviar estes receituários antes de criar um novo relatório.
                </p>
                <Button
                  variant="outline"
                  className="mt-2 border-yellow-300 bg-yellow-100 hover:bg-yellow-200 text-yellow-800"
                  onClick={() => {
                    setShowNovoRelatorio(false);
                    setShowReceituariosPendentes(true);
                  }}
                >
                  <Eye className="h-4 w-4 mr-2" />
                  Ver Receituários Pendentes
                </Button>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNovoRelatorio(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleCriarRelatorio}
              disabled={enviandoRelatorio}
            >
              {enviandoRelatorio ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Criando...
                </>
              ) : (
                <>
                  <Plus className="h-4 w-4 mr-2" />
                  Criar Relatório
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showDetalhes} onOpenChange={setShowDetalhes}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Relatório</DialogTitle>
          </DialogHeader>
          
          {relatorioSelecionado && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm text-gray-500">Status</p>
                  {getStatusBadge(relatorioSelecionado.status)}
                </div>
                <div>
                  <p className="text-sm text-gray-500">Protocolo</p>
                  <p className="font-bold">{relatorioSelecionado.protocolo || 'Não enviado'}</p>
                </div>
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-sm text-gray-500">Período</p>
                  <p className="font-medium">
                    {format(new Date(relatorioSelecionado.periodo_inicio), 'dd/MM/yyyy')} a {format(new Date(relatorioSelecionado.periodo_fim), 'dd/MM/yyyy')}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Data de Envio</p>
                  <p className="font-medium">
                    {relatorioSelecionado.data_envio ? format(new Date(relatorioSelecionado.data_envio), 'dd/MM/yyyy HH:mm') : 'Não enviado'}
                  </p>
                </div>
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-3 gap-6">
                <div className="p-4 bg-blue-50 rounded-md border border-blue-100">
                  <p className="text-blue-700 font-medium">Entradas</p>
                  <p className="text-2xl font-bold text-blue-800">{relatorioSelecionado.quantidade_entradas}</p>
                </div>
                <div className="p-4 bg-green-50 rounded-md border border-green-100">
                  <p className="text-green-700 font-medium">Saídas</p>
                  <p className="text-2xl font-bold text-green-800">{relatorioSelecionado.quantidade_saidas}</p>
                </div>
                <div className="p-4 bg-red-50 rounded-md border border-red-100">
                  <p className="text-red-700 font-medium">Perdas</p>
                  <p className="text-2xl font-bold text-red-800">{relatorioSelecionado.quantidade_perdas}</p>
                </div>
              </div>
              
              {relatorioSelecionado.retorno_anvisa && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <p className="font-medium">Retorno ANVISA</p>
                    <div className={`p-4 rounded-md ${
                      relatorioSelecionado.status === 'aceito' 
                        ? 'bg-green-50 border border-green-100 text-green-800' 
                        : relatorioSelecionado.status === 'rejeitado'
                        ? 'bg-red-50 border border-red-100 text-red-800'
                        : 'bg-gray-50 border border-gray-100 text-gray-800'
                    }`}>
                      <p>{relatorioSelecionado.retorno_anvisa}</p>
                    </div>
                  </div>
                </>
              )}
              
              {relatorioSelecionado.status === 'pendente' && (
                <div className="flex justify-center">
                  <Button
                    onClick={() => {
                      setShowDetalhes(false);
                      setShowConfirmEnvio(true);
                    }}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Enviar Relatório
                  </Button>
                </div>
              )}
              
              {['enviado', 'aceito', 'rejeitado'].includes(relatorioSelecionado.status) && (
                <div className="flex justify-center">
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Download do XML
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={showConfirmEnvio} onOpenChange={setShowConfirmEnvio}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Enviar Relatório SNGPC</AlertDialogTitle>
            <AlertDialogDescription>
              Você está prestes a enviar este relatório para o SNGPC (ANVISA).
              Esta ação não pode ser desfeita após o envio.
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          {relatorioSelecionado && (
            <div className="py-2">
              <div className="flex items-center gap-2 justify-center mb-4">
                <FileBadge className="h-6 w-6 text-green-600" />
                <p className="font-medium">
                  Período: {format(new Date(relatorioSelecionado.periodo_inicio), 'dd/MM/yyyy')} a {format(new Date(relatorioSelecionado.periodo_fim), 'dd/MM/yyyy')}
                </p>
              </div>
              
              {receituariosPendentes.length > 0 && (
                <div className="bg-yellow-50 p-4 rounded-md mb-6 border border-yellow-200">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-yellow-600" />
                    <p className="text-yellow-800 font-medium">
                      Existem receituários pendentes de envio
                    </p>
                  </div>
                  <p className="text-sm text-yellow-700 mt-1">
                    Existem {receituariosPendentes.length} receituários que não foram enviados ao SNGPC.
                    É recomendado enviar estes receituários antes de enviar o relatório.
                  </p>
                </div>
              )}
            </div>
          )}
          
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => handleEnviarRelatorio(relatorioSelecionado)}>
              <Send className="h-4 w-4 mr-2" />
              Confirmar Envio
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <Dialog open={showReceituariosPendentes} onOpenChange={setShowReceituariosPendentes}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Receituários Pendentes de Envio</DialogTitle>
            <DialogDescription>
              Receituários que ainda não foram enviados ao SNGPC
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            {receituariosPendentes.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <CheckCircle2 className="h-12 w-12 mx-auto mb-4 text-green-500" />
                <p className="text-lg font-medium">Não há receituários pendentes de envio!</p>
                <p className="text-sm">Todos os receituários foram enviados ao SNGPC.</p>
              </div>
            ) : (
              <ScrollArea className="h-96">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nº Controle</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Paciente</TableHead>
                      <TableHead>Médico</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {receituariosPendentes.map((receita) => (
                      <TableRow key={receita.id}>
                        <TableCell>{receita.numero_controle}</TableCell>
                        <TableCell>{format(new Date(receita.data_receita), 'dd/MM/yyyy')}</TableCell>
                        <TableCell>{receita.paciente.nome}</TableCell>
                        <TableCell>
                          {receita.medico.nome}
                          <p className="text-xs text-gray-500">CRM: {receita.medico.crm} {receita.medico.uf_crm}</p>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {receita.tipo_receita.replace('_', ' ').toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button size="sm" variant="ghost">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReceituariosPendentes(false)}>
              Fechar
            </Button>
            <Button 
              onClick={() => {
                setShowReceituariosPendentes(false);
                navigate(createPageUrl("GerenciarReceituario"));
              }}
            >
              Ir para Gerenciamento de Receituário
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
