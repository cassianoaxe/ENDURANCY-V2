import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { toast } from "@/components/ui/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Settings,
  Save,
  Printer,
  CreditCard,
  Building2,
  FileText,
  Users,
  Bell,
  Mail,
  CheckCircle2,
  AlertTriangle,
  Info
} from 'lucide-react';

export default function DispensarioConfig() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Configuration states
  const [config, setConfig] = useState({
    general: {
      nome_estabelecimento: '',
      cnpj: '',
      inscricao_estadual: '',
      endereco: '',
      telefone: '',
      email: '',
      responsavel_tecnico: '',
      crf: ''
    },
    pdv: {
      impressao_automatica: true,
      mostrar_logo_cupom: true,
      permitir_desconto: true,
      desconto_maximo: 10,
      exigir_cpf: true,
      consultar_receita: true
    },
    sngpc: {
      inventario_automatico: true,
      alerta_medicamentos: true,
      dias_alerta_vencimento: 30,
      envio_automatico: false
    },
    notificacoes: {
      estoque_baixo: true,
      vencimento_produtos: true,
      vendas_controlados: true,
      email_notificacoes: true,
      dias_antecedencia: 7
    }
  });

  useEffect(() => {
    const loadData = () => {
      try {
        // Check authentication
        const userType = localStorage.getItem('mockUserType');
        if (!userType) {
          console.log("User not authenticated, redirecting to login");
          navigate(createPageUrl("Access"));
          return;
        }

        // Load mock configuration data
        const mockConfig = {
          general: {
            nome_estabelecimento: 'Farmácia Modelo',
            cnpj: '12.345.678/0001-90',
            inscricao_estadual: '123456789',
            endereco: 'Rua Exemplo, 123 - Centro',
            telefone: '(11) 1234-5678',
            email: 'contato@farmaciamodelo.com.br',
            responsavel_tecnico: 'Dr. João Silva',
            crf: 'CRF-SP 12345'
          },
          pdv: {
            impressao_automatica: true,
            mostrar_logo_cupom: true,
            permitir_desconto: true,
            desconto_maximo: 10,
            exigir_cpf: true,
            consultar_receita: true
          },
          sngpc: {
            inventario_automatico: true,
            alerta_medicamentos: true,
            dias_alerta_vencimento: 30,
            envio_automatico: false
          },
          notificacoes: {
            estoque_baixo: true,
            vencimento_produtos: true,
            vendas_controlados: true,
            email_notificacoes: true,
            dias_antecedencia: 7
          }
        };

        setConfig(mockConfig);
        setIsLoading(false);

      } catch (error) {
        console.error("Erro ao carregar configurações:", error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar as configurações.",
          variant: "destructive",
        });
      }
    };

    loadData();
  }, [navigate]);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Sucesso",
        description: "Configurações salvas com sucesso.",
      });
    } catch (error) {
      console.error("Erro ao salvar configurações:", error);
      toast({
        title: "Erro",
        description: "Não foi possível salvar as configurações.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-green-200 border-t-green-600"></div>
          <p className="text-sm text-gray-500">Carregando configurações...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Configurações do Dispensário</h1>
          <p className="text-gray-500">Gerencie as configurações do seu dispensário</p>
        </div>
        <Button onClick={handleSave} disabled={isSaving} className="gap-2">
          <Save className="w-4 h-4" />
          {isSaving ? "Salvando..." : "Salvar Alterações"}
        </Button>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList>
          <TabsTrigger value="general" className="gap-2">
            <Building2 className="w-4 h-4" />
            Geral
          </TabsTrigger>
          <TabsTrigger value="pdv" className="gap-2">
            <CreditCard className="w-4 h-4" />
            PDV
          </TabsTrigger>
          <TabsTrigger value="sngpc" className="gap-2">
            <FileText className="w-4 h-4" />
            SNGPC
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-2">
            <Bell className="w-4 h-4" />
            Notificações
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>Configurações Gerais</CardTitle>
              <CardDescription>Informações básicas do estabelecimento</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nome_estabelecimento">Nome do Estabelecimento</Label>
                  <Input
                    id="nome_estabelecimento"
                    value={config.general.nome_estabelecimento}
                    onChange={(e) => setConfig({
                      ...config,
                      general: { ...config.general, nome_estabelecimento: e.target.value }
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cnpj">CNPJ</Label>
                  <Input
                    id="cnpj"
                    value={config.general.cnpj}
                    onChange={(e) => setConfig({
                      ...config,
                      general: { ...config.general, cnpj: e.target.value }
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="inscricao_estadual">Inscrição Estadual</Label>
                  <Input
                    id="inscricao_estadual"
                    value={config.general.inscricao_estadual}
                    onChange={(e) => setConfig({
                      ...config,
                      general: { ...config.general, inscricao_estadual: e.target.value }
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endereco">Endereço</Label>
                  <Input
                    id="endereco"
                    value={config.general.endereco}
                    onChange={(e) => setConfig({
                      ...config,
                      general: { ...config.general, endereco: e.target.value }
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone</Label>
                  <Input
                    id="telefone"
                    value={config.general.telefone}
                    onChange={(e) => setConfig({
                      ...config,
                      general: { ...config.general, telefone: e.target.value }
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    value={config.general.email}
                    onChange={(e) => setConfig({
                      ...config,
                      general: { ...config.general, email: e.target.value }
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="responsavel_tecnico">Responsável Técnico</Label>
                  <Input
                    id="responsavel_tecnico"
                    value={config.general.responsavel_tecnico}
                    onChange={(e) => setConfig({
                      ...config,
                      general: { ...config.general, responsavel_tecnico: e.target.value }
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="crf">CRF</Label>
                  <Input
                    id="crf"
                    value={config.general.crf}
                    onChange={(e) => setConfig({
                      ...config,
                      general: { ...config.general, crf: e.target.value }
                    })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pdv">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do PDV</CardTitle>
              <CardDescription>Configure o comportamento do Ponto de Venda</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Impressão Automática</Label>
                    <p className="text-sm text-gray-500">Imprimir cupom automaticamente após a venda</p>
                  </div>
                  <Switch
                    checked={config.pdv.impressao_automatica}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      pdv: { ...config.pdv, impressao_automatica: checked }
                    })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Mostrar Logo no Cupom</Label>
                    <p className="text-sm text-gray-500">Incluir logotipo da empresa no cupom</p>
                  </div>
                  <Switch
                    checked={config.pdv.mostrar_logo_cupom}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      pdv: { ...config.pdv, mostrar_logo_cupom: checked }
                    })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Permitir Desconto</Label>
                    <p className="text-sm text-gray-500">Habilitar aplicação de descontos no PDV</p>
                  </div>
                  <Switch
                    checked={config.pdv.permitir_desconto}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      pdv: { ...config.pdv, permitir_desconto: checked }
                    })}
                  />
                </div>
                {config.pdv.permitir_desconto && (
                  <div className="space-y-2">
                    <Label htmlFor="desconto_maximo">Desconto Máximo (%)</Label>
                    <Input
                      id="desconto_maximo"
                      type="number"
                      min="0"
                      max="100"
                      value={config.pdv.desconto_maximo}
                      onChange={(e) => setConfig({
                        ...config,
                        pdv: { ...config.pdv, desconto_maximo: Number(e.target.value) }
                      })}
                    />
                  </div>
                )}
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Exigir CPF</Label>
                    <p className="text-sm text-gray-500">Exigir CPF do cliente na venda</p>
                  </div>
                  <Switch
                    checked={config.pdv.exigir_cpf}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      pdv: { ...config.pdv, exigir_cpf: checked }
                    })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Consultar Receita</Label>
                    <p className="text-sm text-gray-500">Verificar receita para medicamentos controlados</p>
                  </div>
                  <Switch
                    checked={config.pdv.consultar_receita}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      pdv: { ...config.pdv, consultar_receita: checked }
                    })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sngpc">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do SNGPC</CardTitle>
              <CardDescription>Configure as opções relacionadas ao SNGPC</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Inventário Automático</Label>
                    <p className="text-sm text-gray-500">Gerar inventário automático para o SNGPC</p>
                  </div>
                  <Switch
                    checked={config.sngpc.inventario_automatico}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      sngpc: { ...config.sngpc, inventario_automatico: checked }
                    })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Alerta de Medicamentos</Label>
                    <p className="text-sm text-gray-500">Alertar sobre medicamentos próximos ao vencimento</p>
                  </div>
                  <Switch
                    checked={config.sngpc.alerta_medicamentos}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      sngpc: { ...config.sngpc, alerta_medicamentos: checked }
                    })}
                  />
                </div>
                {config.sngpc.alerta_medicamentos && (
                  <div className="space-y-2">
                    <Label htmlFor="dias_alerta_vencimento">Dias para Alerta de Vencimento</Label>
                    <Input
                      id="dias_alerta_vencimento"
                      type="number"
                      min="1"
                      value={config.sngpc.dias_alerta_vencimento}
                      onChange={(e) => setConfig({
                        ...config,
                        sngpc: { ...config.sngpc, dias_alerta_vencimento: Number(e.target.value) }
                      })}
                    />
                  </div>
                )}
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Envio Automático</Label>
                    <p className="text-sm text-gray-500">Enviar relatórios automaticamente para o SNGPC</p>
                  </div>
                  <Switch
                    checked={config.sngpc.envio_automatico}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      sngpc: { ...config.sngpc, envio_automatico: checked }
                    })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Notificações</CardTitle>
              <CardDescription>Configure as notificações do sistema</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Estoque Baixo</Label>
                    <p className="text-sm text-gray-500">Notificar quando o estoque estiver baixo</p>
                  </div>
                  <Switch
                    checked={config.notificacoes.estoque_baixo}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      notificacoes: { ...config.notificacoes, estoque_baixo: checked }
                    })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Vencimento de Produtos</Label>
                    <p className="text-sm text-gray-500">Notificar sobre produtos próximos ao vencimento</p>
                  </div>
                  <Switch
                    checked={config.notificacoes.vencimento_produtos}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      notificacoes: { ...config.notificacoes, vencimento_produtos: checked }
                    })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Vendas de Controlados</Label>
                    <p className="text-sm text-gray-500">Notificar sobre vendas de medicamentos controlados</p>
                  </div>
                  <Switch
                    checked={config.notificacoes.vendas_controlados}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      notificacoes: { ...config.notificacoes, vendas_controlados: checked }
                    })}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Notificações por Email</Label>
                    <p className="text-sm text-gray-500">Enviar notificações também por email</p>
                  </div>
                  <Switch
                    checked={config.notificacoes.email_notificacoes}
                    onCheckedChange={(checked) => setConfig({
                      ...config,
                      notificacoes: { ...config.notificacoes, email_notificacoes: checked }
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dias_antecedencia">Dias de Antecedência</Label>
                  <Input
                    id="dias_antecedencia"
                    type="number"
                    min="1"
                    value={config.notificacoes.dias_antecedencia}
                    onChange={(e) => setConfig({
                      ...config,
                      notificacoes: { ...config.notificacoes, dias_antecedencia: Number(e.target.value) }
                    })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <AlertDialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Restaurar Configurações Padrão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja restaurar todas as configurações para o padrão?
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction>Confirmar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}