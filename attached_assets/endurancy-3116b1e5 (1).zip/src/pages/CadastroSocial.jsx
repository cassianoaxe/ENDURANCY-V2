import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { SendEmail } from "@/api/integrations";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  User, 
  Mail, 
  Phone, 
  Home, 
  FileText, 
  Calendar, 
  Upload,
  AlertTriangle,
  Upload as UploadIcon,
  Clock,
  CheckCircle2,
  Info
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function CadastroSocial() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [formData, setFormData] = useState({
    // Dados Pessoais
    nome: '',
    cpf: '',
    rg: '',
    data_nascimento: '',
    email: '',
    telefone: '',
    celular: '',
    
    // Endereço
    cep: '',
    logradouro: '',
    numero: '',
    complemento: '',
    bairro: '',
    cidade: '',
    estado: '',
    
    // Dados Socioeconômicos
    renda_familiar: '',
    num_dependentes: '',
    tipo_moradia: '',
    gastos_medicamentos: '',
    possui_plano_saude: false,
    
    // Documentos
    numero_cad_unico: '',
    numero_nis: '',
    numero_pis: '',
    
    // Condição Médica
    diagnostico_principal: '',
    medico_responsavel: '',
    crm_medico: '',
    medicamentos_uso: '',
    
    // Extras
    como_conheceu: '',
    observacoes: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleNext = () => {
    setStep(prev => prev + 1);
  };

  const handleBack = () => {
    setStep(prev => prev - 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Aqui você faria o envio dos dados para a API
      
      // Enviar email de confirmação
      await SendEmail({
        to: formData.email,
        subject: "Cadastro Recebido - Programa Social",
        body: `
          Olá ${formData.nome},

          Recebemos seu cadastro para o programa social. 
          Em breve nossa equipe entrará em contato para agendar uma entrevista social.

          Manteremos você informado sobre o andamento do processo.

          Atenciosamente,
          Equipe do Programa Social
        `
      });

      setShowSuccessDialog(true);
    } catch (error) {
      console.error('Erro ao enviar cadastro:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl">Cadastro Programa Social</CardTitle>
            <CardDescription>
              Preencha o formulário abaixo para solicitar sua inclusão no programa social
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div className="mb-8">
              <div className="flex justify-between items-center">
                {[1, 2, 3, 4].map((stepNumber) => (
                  <div 
                    key={stepNumber}
                    className={`flex items-center ${step >= stepNumber ? 'text-green-600' : 'text-gray-400'}`}
                  >
                    <div className={`
                      w-8 h-8 rounded-full flex items-center justify-center
                      ${step >= stepNumber ? 'bg-green-100' : 'bg-gray-100'}
                    `}>
                      {step > stepNumber ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : (
                        stepNumber
                      )}
                    </div>
                    {stepNumber < 4 && (
                      <div className={`w-full h-1 mx-2 ${step > stepNumber ? 'bg-green-200' : 'bg-gray-200'}`} />
                    )}
                  </div>
                ))}
              </div>
              <div className="flex justify-between mt-2 text-sm">
                <span>Dados Pessoais</span>
                <span>Endereço</span>
                <span>Documentos</span>
                <span>Finalizar</span>
              </div>
            </div>

            <form onSubmit={handleSubmit}>
              {step === 1 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField>
                      <FormLabel>Nome Completo *</FormLabel>
                      <FormControl>
                        <Input
                          name="nome"
                          value={formData.nome}
                          onChange={handleInputChange}
                          required
                        />
                      </FormControl>
                    </FormField>

                    <FormField>
                      <FormLabel>CPF *</FormLabel>
                      <FormControl>
                        <Input
                          name="cpf"
                          value={formData.cpf}
                          onChange={handleInputChange}
                          required
                        />
                      </FormControl>
                    </FormField>

                    <FormField>
                      <FormLabel>RG</FormLabel>
                      <FormControl>
                        <Input
                          name="rg"
                          value={formData.rg}
                          onChange={handleInputChange}
                        />
                      </FormControl>
                    </FormField>

                    <FormField>
                      <FormLabel>Data de Nascimento *</FormLabel>
                      <FormControl>
                        <Input
                          type="date"
                          name="data_nascimento"
                          value={formData.data_nascimento}
                          onChange={handleInputChange}
                          required
                        />
                      </FormControl>
                    </FormField>

                    <FormField>
                      <FormLabel>Email *</FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                        />
                      </FormControl>
                    </FormField>

                    <FormField>
                      <FormLabel>Telefone *</FormLabel>
                      <FormControl>
                        <Input
                          name="telefone"
                          value={formData.telefone}
                          onChange={handleInputChange}
                          required
                        />
                      </FormControl>
                    </FormField>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField>
                      <FormLabel>CEP *</FormLabel>
                      <FormControl>
                        <Input
                          name="cep"
                          value={formData.cep}
                          onChange={handleInputChange}
                          required
                        />
                      </FormControl>
                    </FormField>

                    <FormField>
                      <FormLabel>Logradouro *</FormLabel>
                      <FormControl>
                        <Input
                          name="logradouro"
                          value={formData.logradouro}
                          onChange={handleInputChange}
                          required
                        />
                      </FormControl>
                    </FormField>

                    {/* Outros campos de endereço */}
                  </div>

                  <div className="space-y-4 mt-6">
                    <h3 className="font-medium">Dados Socioeconômicos</h3>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField>
                        <FormLabel>Renda Familiar *</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            name="renda_familiar"
                            value={formData.renda_familiar}
                            onChange={handleInputChange}
                            required
                          />
                        </FormControl>
                      </FormField>

                      <FormField>
                        <FormLabel>Número de Dependentes</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            name="num_dependentes"
                            value={formData.num_dependentes}
                            onChange={handleInputChange}
                          />
                        </FormControl>
                      </FormField>

                      <FormField>
                        <FormLabel>Tipo de Moradia</FormLabel>
                        <Select
                          name="tipo_moradia"
                          value={formData.tipo_moradia}
                          onValueChange={(value) => handleInputChange({
                            target: { name: 'tipo_moradia', value }
                          })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="propria">Própria</SelectItem>
                            <SelectItem value="alugada">Alugada</SelectItem>
                            <SelectItem value="cedida">Cedida</SelectItem>
                            <SelectItem value="financiada">Financiada</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormField>

                      <FormField>
                        <FormLabel>Gastos com Medicamentos</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            name="gastos_medicamentos"
                            value={formData.gastos_medicamentos}
                            onChange={handleInputChange}
                          />
                        </FormControl>
                      </FormField>
                    </div>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="font-medium">Documentos Necessários</h3>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField>
                        <FormLabel>Número CAD Único *</FormLabel>
                        <FormControl>
                          <Input
                            name="numero_cad_unico"
                            value={formData.numero_cad_unico}
                            onChange={handleInputChange}
                            required
                          />
                        </FormControl>
                      </FormField>

                      <FormField>
                        <FormLabel>Número NIS</FormLabel>
                        <FormControl>
                          <Input
                            name="numero_nis"
                            value={formData.numero_nis}
                            onChange={handleInputChange}
                          />
                        </FormControl>
                      </FormField>

                      <FormField>
                        <FormLabel>Número PIS</FormLabel>
                        <FormControl>
                          <Input
                            name="numero_pis"
                            value={formData.numero_pis}
                            onChange={handleInputChange}
                          />
                        </FormControl>
                      </FormField>
                    </div>

                    <div className="space-y-4 mt-6">
                      <h4 className="font-medium">Upload de Documentos</h4>
                      
                      <div className="grid grid-cols-1 gap-4">
                        <div className="border-2 border-dashed rounded-lg p-6">
                          <div className="flex flex-col items-center">
                            <UploadIcon className="h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-600">
                              Comprovante CAD Único
                            </p>
                            <input type="file" className="hidden" />
                            <Button variant="outline" size="sm" className="mt-2">
                              Selecionar Arquivo
                            </Button>
                          </div>
                        </div>

                        <div className="border-2 border-dashed rounded-lg p-6">
                          <div className="flex flex-col items-center">
                            <UploadIcon className="h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-600">
                              Comprovante de Renda
                            </p>
                            <input type="file" className="hidden" />
                            <Button variant="outline" size="sm" className="mt-2">
                              Selecionar Arquivo
                            </Button>
                          </div>
                        </div>

                        <div className="border-2 border-dashed rounded-lg p-6">
                          <div className="flex flex-col items-center">
                            <UploadIcon className="h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-600">
                              Laudo Médico
                            </p>
                            <input type="file" className="hidden" />
                            <Button variant="outline" size="sm" className="mt-2">
                              Selecionar Arquivo
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {step === 4 && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-4">Informações Médicas</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField>
                        <FormLabel>Diagnóstico Principal *</FormLabel>
                        <FormControl>
                          <Textarea
                            name="diagnostico_principal"
                            value={formData.diagnostico_principal}
                            onChange={handleInputChange}
                            required
                          />
                        </FormControl>
                      </FormField>

                      <FormField>
                        <FormLabel>Medicamentos em Uso</FormLabel>
                        <FormControl>
                          <Textarea
                            name="medicamentos_uso"
                            value={formData.medicamentos_uso}
                            onChange={handleInputChange}
                          />
                        </FormControl>
                      </FormField>
                    </div>
                  </div>

                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertDescription>
                      Após o envio do cadastro, nossa equipe entrará em contato para agendar
                      uma entrevista social e dar continuidade ao processo.
                    </AlertDescription>
                  </Alert>

                  <FormField>
                    <FormLabel>Observações Adicionais</FormLabel>
                    <FormControl>
                      <Textarea
                        name="observacoes"
                        value={formData.observacoes}
                        onChange={handleInputChange}
                        placeholder="Informações adicionais que você considere importantes..."
                      />
                    </FormControl>
                  </FormField>
                </div>
              )}

              <div className="flex justify-between mt-8">
                {step > 1 && (
                  <Button type="button" variant="outline" onClick={handleBack}>
                    Voltar
                  </Button>
                )}
                {step < 4 ? (
                  <Button type="button" onClick={handleNext}>
                    Próximo
                  </Button>
                ) : (
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? 'Enviando...' : 'Enviar Cadastro'}
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-6 w-6 text-green-500" />
              Cadastro Enviado com Sucesso!
            </DialogTitle>
            <DialogDescription>
              <p className="mt-2">
                Recebemos seu cadastro para o programa social. Em breve nossa equipe
                entrará em contato para agendar uma entrevista social.
              </p>
              <p className="mt-4">
                Você receberá um email de confirmação com mais informações.
              </p>
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end">
            <Button onClick={() => navigate(createPageUrl("PortalSocial"))}>
              Retornar ao Portal
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}