
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  FileCheck, 
  Search, 
  Plus, 
  Filter, 
  Clock, 
  Download, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  Calendar, 
  User, 
  FileText, 
  MoreHorizontal,
  ChevronDown,
  CalendarDays,
  Pill,
  Heart,
  ArrowUpDown,
  Eye,
  FileEdit,
  Archive,
  Send,
  Printer
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";

// Dados simulados para prescrições
const mockPrescriptions = [
  {
    id: "presc001",
    numero: "P-2023-0156",
    paciente: {
      id: "pac001",
      nome: "Maria Silva Oliveira",
      cpf: "123.456.789-00"
    },
    medico: {
      nome: "Dr. João Carlos Santos",
      crm: "12345-SP",
      especialidade: "Neurologia"
    },
    data_emissao: "2023-06-01",
    data_validade: "2024-06-01",
    status: "aprovada",
    produtos: [
      {
        id: "prod001",
        nome: "Óleo CBD 5% 30ml",
        dosagem: "5 gotas, 2x ao dia",
        quantidade: 2,
        duracao: "60 dias"
      }
    ],
    diagnostico: "Epilepsia Refratária",
    observacoes: "Iniciar com dosagem reduzida por 7 dias.",
    file_url: "#",
    revisado_por: "Ana Oliveira",
    data_revisao: "2023-06-02",
  },
  {
    id: "presc002",
    numero: "P-2023-0157",
    paciente: {
      id: "pac002",
      nome: "José Pereira Souza",
      cpf: "987.654.321-00"
    },
    medico: {
      nome: "Dra. Ana Paula Mendes",
      crm: "54321-SP",
      especialidade: "Medicina da Dor"
    },
    data_emissao: "2023-05-12",
    data_validade: "2023-11-12",
    status: "aprovada",
    produtos: [
      {
        id: "prod003",
        nome: "Tinturas CBD 3% 50ml",
        dosagem: "1ml, 2x ao dia",
        quantidade: 3,
        duracao: "90 dias"
      },
      {
        id: "prod006",
        nome: "Creme CBD tópico 50g",
        dosagem: "Aplicar nas áreas afetadas, 3x ao dia",
        quantidade: 2,
        duracao: "60 dias"
      }
    ],
    diagnostico: "Dor Crônica, Fibromialgia",
    observacoes: "Acompanhar efeitos colaterais.",
    file_url: "#",
    revisado_por: "Carlos Mendes",
    data_revisao: "2023-05-13",
  },
  {
    id: "presc003",
    numero: "P-2023-0158",
    paciente: {
      id: "pac003",
      nome: "Antônio Carlos Ferreira",
      cpf: "456.789.123-00"
    },
    medico: {
      nome: "Dr. Roberto Almeida",
      crm: "23456-SP",
      especialidade: "Geriatria"
    },
    data_emissao: "2023-06-01",
    data_validade: "2023-12-01",
    status: "aprovada",
    produtos: [
      {
        id: "prod004",
        nome: "Óleo CBD 10% 10ml",
        dosagem: "3 gotas, 3x ao dia",
        quantidade: 6,
        duracao: "180 dias"
      }
    ],
    diagnostico: "Parkinson, Artrite",
    observacoes: "Paciente reporta melhora significativa nos tremores.",
    file_url: "#",
    revisado_por: "Ana Oliveira",
    data_revisao: "2023-06-02",
  },
  {
    id: "presc004",
    numero: "P-2023-0159",
    paciente: {
      id: "pac005",
      nome: "Carlos Eduardo Santos",
      cpf: "321.654.987-00"
    },
    medico: {
      nome: "Dr. Paulo Menezes",
      crm: "34567-SP",
      especialidade: "Neurologia"
    },
    data_emissao: "2023-05-25",
    data_validade: "2023-11-25",
    status: "pendente",
    produtos: [
      {
        id: "prod005",
        nome: "Cápsulas CBD 20mg",
        dosagem: "1 cápsula, 2x ao dia",
        quantidade: 3,
        duracao: "90 dias"
      }
    ],
    diagnostico: "Esclerose Múltipla",
    observacoes: "Primeira prescrição para este paciente. Monitorar efeitos.",
    file_url: "#",
    revisado_por: "",
    data_revisao: "",
  },
  {
    id: "presc005",
    numero: "P-2023-0155",
    paciente: {
      id: "pac006",
      nome: "Marina Fernandes Costa",
      cpf: "789.123.456-00"
    },
    medico: {
      nome: "Dra. Cristina Martins",
      crm: "45678-SP",
      especialidade: "Psiquiatria"
    },
    data_emissao: "2023-05-20",
    data_validade: "2023-11-20",
    status: "rejeitada",
    produtos: [
      {
        id: "prod002",
        nome: "Óleo CBD 10% 30ml",
        dosagem: "10 gotas, 1x ao dia",
        quantidade: 1,
        duracao: "30 dias"
      }
    ],
    diagnostico: "Transtorno de Ansiedade Generalizada",
    observacoes: "Prescrição rejeitada devido à dosagem fora do padrão recomendado.",
    file_url: "#",
    revisado_por: "Carlos Mendes",
    data_revisao: "2023-05-21",
    motivo_rejeicao: "Dosagem acima do recomendado para início de tratamento."
  }
];

export default function CrmPrescricoes() {
  const navigate = useNavigate();
  const [prescriptions, setPrescriptions] = useState([]);
  const [filteredPrescriptions, setFilteredPrescriptions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedPrescription, setSelectedPrescription] = useState(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  
  useEffect(() => {
    loadPrescriptions();
  }, []);
  
  useEffect(() => {
    applyFilters();
  }, [prescriptions, searchTerm, statusFilter]);

  const loadPrescriptions = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setPrescriptions(mockPrescriptions);
    } catch (error) {
      console.error("Erro ao carregar prescrições:", error);
      toast({
        variant: "destructive",
        title: "Erro ao carregar prescrições",
        description: "Não foi possível obter as prescrições no momento.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...prescriptions];

    // Filtrar por termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(prescription => 
        prescription.paciente.nome.toLowerCase().includes(term) ||
        prescription.numero.toLowerCase().includes(term) ||
        prescription.medico.nome.toLowerCase().includes(term) ||
        prescription.diagnostico.toLowerCase().includes(term) ||
        prescription.produtos.some(p => p.nome.toLowerCase().includes(term))
      );
    }

    // Filtrar por status
    if (statusFilter !== "all") {
      filtered = filtered.filter(prescription => prescription.status === statusFilter);
    }

    setFilteredPrescriptions(filtered);
  };

  const handleViewPrescription = (prescription) => {
    setSelectedPrescription(prescription);
    setShowDetailDialog(true);
  };

  const handleEditPrescription = (id) => {
    navigate(`${createPageUrl("NovaPrescricao")}?id=${id}`);
  };

  const handleNewPrescription = () => {
    navigate(createPageUrl("NovaPrescricao"));
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "aprovada":
        return (
          <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" />
            Aprovada
          </Badge>
        );
      case "pendente":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Pendente
          </Badge>
        );
      case "rejeitada":
        return (
          <Badge className="bg-red-100 text-red-800 flex items-center gap-1">
            <XCircle className="w-3 h-3" />
            Rejeitada
          </Badge>
        );
      default:
        return (
          <Badge className="bg-gray-100 text-gray-800">
            {status}
          </Badge>
        );
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Prescrições</h1>
          <p className="text-gray-500 mt-1">
            Gerencie prescrições médicas de produtos de cannabis
          </p>
        </div>
        <Button onClick={handleNewPrescription} className="gap-2">
          <Plus className="w-4 h-4" />
          Nova Prescrição
        </Button>
      </div>
      
      {/* Filtros e busca */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar prescrições..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full md:w-[180px]">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <SelectValue placeholder="Filtrar por status" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os status</SelectItem>
            <SelectItem value="aprovada">Aprovadas</SelectItem>
            <SelectItem value="pendente">Pendentes</SelectItem>
            <SelectItem value="rejeitada">Rejeitadas</SelectItem>
          </SelectContent>
        </Select>
        
        <Button variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          Exportar
        </Button>
      </div>
      
      {/* Tabela de prescrições */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="py-32 flex justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
            </div>
          ) : filteredPrescriptions.length === 0 ? (
            <div className="py-20 text-center">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-900">Nenhuma prescrição encontrada</h3>
              <p className="text-gray-500 mt-1 max-w-md mx-auto">
                {searchTerm 
                  ? `Não encontramos prescrições correspondentes a "${searchTerm}"`
                  : "Não há prescrições com os filtros selecionados."}
              </p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => {
                  setSearchTerm("");
                  setStatusFilter("all");
                }}
              >
                Limpar filtros
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[180px]">Número</TableHead>
                    <TableHead>Paciente</TableHead>
                    <TableHead>Médico/CRM</TableHead>
                    <TableHead>Emissão</TableHead>
                    <TableHead>Validade</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPrescriptions.map((prescription) => (
                    <TableRow key={prescription.id}>
                      <TableCell className="font-medium">{prescription.numero}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{prescription.paciente.nome}</span>
                          <span className="text-xs text-gray-500">{prescription.paciente.cpf}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{prescription.medico.nome}</span>
                          <span className="text-xs text-gray-500">{prescription.medico.crm} • {prescription.medico.especialidade}</span>
                        </div>
                      </TableCell>
                      <TableCell>{formatDate(prescription.data_emissao)}</TableCell>
                      <TableCell>{formatDate(prescription.data_validade)}</TableCell>
                      <TableCell>{getStatusBadge(prescription.status)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Abrir menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewPrescription(prescription)}>
                              <Eye className="mr-2 h-4 w-4" />
                              <span>Ver detalhes</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEditPrescription(prescription.id)}>
                              <FileEdit className="mr-2 h-4 w-4" />
                              <span>Editar</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Printer className="mr-2 h-4 w-4" />
                              <span>Imprimir</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Archive className="mr-2 h-4 w-4" />
                              <span>Arquivar</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Modal de detalhes da prescrição */}
      {selectedPrescription && (
        <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileCheck className="w-5 h-5" />
                Prescrição {selectedPrescription.numero}
              </DialogTitle>
              <DialogDescription>
                Detalhes completos da prescrição
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Status badge */}
              <div className="flex justify-between items-center">
                {getStatusBadge(selectedPrescription.status)}
                
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <Calendar className="w-4 h-4" />
                  <span>Emissão: {formatDate(selectedPrescription.data_emissao)}</span>
                  <span className="mx-1">•</span>
                  <span>Validade: {formatDate(selectedPrescription.data_validade)}</span>
                </div>
              </div>
              
              <Separator />
              
              {/* Dados do paciente e médico */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium flex items-center gap-2 mb-2">
                    <User className="w-4 h-4 text-gray-500" />
                    Dados do Paciente
                  </h3>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <Avatar>
                          <AvatarFallback className="bg-blue-100 text-blue-800">
                            {selectedPrescription.paciente.nome.split(' ').map(n => n[0]).join('').substring(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{selectedPrescription.paciente.nome}</p>
                          <p className="text-sm text-gray-500">{selectedPrescription.paciente.cpf}</p>
                        </div>
                      </div>
                      
                      <div className="text-sm space-y-1">
                        <p className="flex items-center gap-2">
                          <Heart className="w-4 h-4 text-gray-500" />
                          <span className="font-medium">Diagnóstico:</span> {selectedPrescription.diagnostico}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                <div>
                  <h3 className="font-medium flex items-center gap-2 mb-2">
                    <User className="w-4 h-4 text-gray-500" />
                    Dados do Médico
                  </h3>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <Avatar>
                          <AvatarFallback className="bg-green-100 text-green-800">
                            {selectedPrescription.medico.nome.split(' ').map(n => n[0]).join('').substring(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{selectedPrescription.medico.nome}</p>
                          <p className="text-sm text-gray-500">{selectedPrescription.medico.crm} • {selectedPrescription.medico.especialidade}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
              
              {/* Produtos prescritos */}
              <div>
                <h3 className="font-medium flex items-center gap-2 mb-2">
                  <Pill className="w-4 h-4 text-gray-500" />
                  Produtos Prescritos
                </h3>
                <Card>
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produto</TableHead>
                          <TableHead>Dosagem</TableHead>
                          <TableHead>Qtd.</TableHead>
                          <TableHead>Duração</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedPrescription.produtos.map((produto, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{produto.nome}</TableCell>
                            <TableCell>{produto.dosagem}</TableCell>
                            <TableCell>{produto.quantidade}</TableCell>
                            <TableCell>{produto.duracao}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
              
              {/* Observações */}
              {selectedPrescription.observacoes && (
                <div>
                  <h3 className="font-medium flex items-center gap-2 mb-2">
                    <FileText className="w-4 h-4 text-gray-500" />
                    Observações
                  </h3>
                  <Card>
                    <CardContent className="p-4">
                      <p>{selectedPrescription.observacoes}</p>
                    </CardContent>
                  </Card>
                </div>
              )}
              
              {/* Motivo de rejeição, se aplicável */}
              {selectedPrescription.status === "rejeitada" && selectedPrescription.motivo_rejeicao && (
                <div>
                  <h3 className="font-medium flex items-center gap-2 mb-2 text-red-600">
                    <XCircle className="w-4 h-4" />
                    Motivo da Rejeição
                  </h3>
                  <Card className="border-red-200">
                    <CardContent className="p-4 text-red-600">
                      <p>{selectedPrescription.motivo_rejeicao}</p>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Dados de revisão */}
              {selectedPrescription.revisado_por && (
                <div className="text-sm text-gray-500 flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Revisado por {selectedPrescription.revisado_por} em {formatDate(selectedPrescription.data_revisao)}
                </div>
              )}
            </div>
            
            <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:gap-0">
              <Button variant="outline" className="gap-2" onClick={() => setShowDetailDialog(false)}>
                Fechar
              </Button>
              <Button variant="outline" className="gap-2">
                <Printer className="w-4 h-4" />
                Imprimir
              </Button>
              <Button className="gap-2" onClick={() => handleEditPrescription(selectedPrescription.id)}>
                <FileEdit className="w-4 h-4" />
                Editar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
