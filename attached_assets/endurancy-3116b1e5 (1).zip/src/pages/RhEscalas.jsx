
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Calendar as CalendarIcon, 
  Clock, 
  User, 
  Users, 
  Plus, 
  Edit, 
  Trash, 
  Filter, 
  Search, 
  ChevronLeft, 
  ChevronRight, 
  MoreHorizontal, 
  Download, 
  MessageSquare, 
  Printer, 
  Clock3, 
  Calendar, 
  X, 
  Save, 
  Sun, 
  Moon, 
  UserCheck, 
  FileText, 
  ClipboardList, 
  AlertTriangle,
  Share,
  CheckCircle2
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Dados simulados de escalas
const mockEscalas = [
  {
    id: "escala-001",
    nome: "Escala de Produção - Julho 2023",
    departamento: "Produção",
    dataInicio: "2023-07-01",
    dataFim: "2023-07-31",
    tipo: "mensal",
    status: "publicada",
    responsavel: "Maria Silva",
    colaboradores: [
      {
        id: "col-001",
        nome: "Maria Silva",
        cargo: "Farmacêutica RT",
        avatar: "MS",
        turno: "Diurno",
        horario: "08:00 - 17:00"
      },
      {
        id: "col-002",
        nome: "Carlos Oliveira",
        cargo: "Analista de Qualidade",
        avatar: "CO",
        turno: "Diurno",
        horario: "08:00 - 17:00"
      },
      {
        id: "col-005",
        nome: "Roberto Ferreira",
        cargo: "Técnico de Produção",
        avatar: "RF",
        turno: "Noturno",
        horario: "22:00 - 07:00"
      },
      {
        id: "col-007",
        nome: "Lúcia Mendes",
        cargo: "Auxiliar de Produção",
        avatar: "LM",
        turno: "Vespertino",
        horario: "14:00 - 23:00"
      }
    ],
    escalaDias: [
      {
        data: "2023-07-01",
        tipo: "fds",
        turnos: {
          "08:00 - 17:00": ["col-001"],
          "14:00 - 23:00": [],
          "22:00 - 07:00": ["col-005"]
        }
      },
      // mais dias seriam adicionados aqui
    ]
  },
  {
    id: "escala-002",
    nome: "Escala de Cultivo - Julho 2023",
    departamento: "Cultivo",
    dataInicio: "2023-07-01",
    dataFim: "2023-07-31",
    tipo: "mensal",
    status: "publicada",
    responsavel: "Pedro Santos",
    colaboradores: [
      {
        id: "col-003",
        nome: "Pedro Santos",
        cargo: "Especialista em Cultivo",
        avatar: "PS",
        turno: "Diurno",
        horario: "07:00 - 16:00"
      },
      {
        id: "col-008",
        nome: "Ana Sousa",
        cargo: "Técnica Agrícola",
        avatar: "AS",
        turno: "Diurno",
        horario: "07:00 - 16:00"
      },
      {
        id: "col-009",
        nome: "Marcos Lima",
        cargo: "Auxiliar de Cultivo",
        avatar: "ML",
        turno: "Vespertino",
        horario: "13:00 - 22:00"
      }
    ]
  },
  {
    id: "escala-003",
    nome: "Escala de Laboratório - Julho 2023",
    departamento: "Qualidade",
    dataInicio: "2023-07-01",
    dataFim: "2023-07-31",
    tipo: "mensal",
    status: "rascunho",
    responsavel: "Carlos Oliveira",
    colaboradores: [
      {
        id: "col-002",
        nome: "Carlos Oliveira",
        cargo: "Analista de Qualidade",
        avatar: "CO",
        turno: "Diurno",
        horario: "08:00 - 17:00"
      },
      {
        id: "col-010",
        nome: "Juliana Freitas",
        cargo: "Analista de Controle",
        avatar: "JF",
        turno: "Diurno",
        horario: "08:00 - 17:00"
      }
    ]
  },
  {
    id: "escala-004",
    nome: "Plantão de Fim de Semana - Julho 2023",
    departamento: "Geral",
    dataInicio: "2023-07-01",
    dataFim: "2023-07-31",
    tipo: "especial",
    status: "publicada",
    responsavel: "Maria Silva",
    colaboradores: [
      {
        id: "col-001",
        nome: "Maria Silva",
        cargo: "Farmacêutica RT",
        avatar: "MS",
        turno: "Diurno",
        horario: "08:00 - 17:00"
      },
      {
        id: "col-002",
        nome: "Carlos Oliveira",
        cargo: "Analista de Qualidade",
        avatar: "CO",
        turno: "Diurno",
        horario: "08:00 - 17:00"
      },
      {
        id: "col-003",
        nome: "Pedro Santos",
        cargo: "Especialista em Cultivo",
        avatar: "PS",
        turno: "Diurno",
        horario: "07:00 - 16:00"
      }
    ]
  },
  {
    id: "escala-005",
    nome: "Escala de Agosto 2023 - Produção",
    departamento: "Produção",
    dataInicio: "2023-08-01",
    dataFim: "2023-08-31",
    tipo: "mensal",
    status: "rascunho",
    responsavel: "Maria Silva",
    colaboradores: [
      {
        id: "col-001",
        nome: "Maria Silva",
        cargo: "Farmacêutica RT",
        avatar: "MS",
        turno: "Diurno",
        horario: "08:00 - 17:00"
      },
      {
        id: "col-005",
        nome: "Roberto Ferreira",
        cargo: "Técnico de Produção",
        avatar: "RF",
        turno: "Noturno",
        horario: "22:00 - 07:00"
      },
      {
        id: "col-007",
        nome: "Lúcia Mendes",
        cargo: "Auxiliar de Produção",
        avatar: "LM",
        turno: "Vespertino",
        horario: "14:00 - 23:00"
      }
    ]
  }
];

// Dados simulados de horários padrão
const horariosPadrao = [
  { id: "horario-1", nome: "Diurno - Administrativo", inicio: "08:00", fim: "17:00", descricao: "Segunda a sexta, 1h de almoço" },
  { id: "horario-2", nome: "Diurno - Produção", inicio: "07:00", fim: "16:00", descricao: "Segunda a sexta, 1h de almoço" },
  { id: "horario-3", nome: "Vespertino", inicio: "14:00", fim: "23:00", descricao: "Segunda a sexta, 1h de intervalo" },
  { id: "horario-4", nome: "Noturno", inicio: "22:00", fim: "07:00", descricao: "Escala 12x36" },
  { id: "horario-5", nome: "Fim de Semana", inicio: "08:00", fim: "20:00", descricao: "Sábados e domingos, 1h de almoço" }
];

// Dados simulados de colaboradores
const todosColaboradores = [
  { id: "col-001", nome: "Maria Silva", cargo: "Farmacêutica RT", departamento: "Produção", avatar: "MS" },
  { id: "col-002", nome: "Carlos Oliveira", cargo: "Analista de Qualidade", departamento: "Qualidade", avatar: "CO" },
  { id: "col-003", nome: "Pedro Santos", cargo: "Especialista em Cultivo", departamento: "Cultivo", avatar: "PS" },
  { id: "col-004", nome: "Joana Lima", cargo: "Gerente de RH", departamento: "RH", avatar: "JL" },
  { id: "col-005", nome: "Roberto Ferreira", cargo: "Técnico de Produção", departamento: "Produção", avatar: "RF" },
  { id: "col-006", nome: "Amanda Costa", cargo: "Auxiliar Administrativo", departamento: "Administrativo", avatar: "AC" },
  { id: "col-007", nome: "Lúcia Mendes", cargo: "Auxiliar de Produção", departamento: "Produção", avatar: "LM" },
  { id: "col-008", nome: "Ana Sousa", cargo: "Técnica Agrícola", departamento: "Cultivo", avatar: "AS" },
  { id: "col-009", nome: "Marcos Lima", cargo: "Auxiliar de Cultivo", departamento: "Cultivo", avatar: "ML" },
  { id: "col-010", nome: "Juliana Freitas", cargo: "Analista de Controle", departamento: "Qualidade", avatar: "JF" }
];

export default function RhEscalas() {
  const [escalas, setEscalas] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("lista");
  const [searchTerm, setSearchTerm] = useState("");
  const [departamentoFiltro, setDepartamentoFiltro] = useState("todos");
  const [statusFiltro, setStatusFiltro] = useState("todos");
  const [showNovaEscalaDialog, setShowNovaEscalaDialog] = useState(false);
  const [showVisualizarEscalaDialog, setShowVisualizarEscalaDialog] = useState(false);
  const [selectedEscala, setSelectedEscala] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  
  // Estado para nova escala
  const [novaEscala, setNovaEscala] = useState({
    nome: "",
    departamento: "",
    dataInicio: "",
    dataFim: "",
    tipo: "mensal",
    responsavel: "",
    colaboradores: []
  });

  useEffect(() => {
    // Simular carregamento de dados
    setTimeout(() => {
      setEscalas(mockEscalas);
      setIsLoading(false);
    }, 800);
  }, []);

  // Filtrar escalas
  const filteredEscalas = escalas.filter(escala => {
    // Filtro de texto
    const matchesSearch = 
      escala.nome.toLowerCase().includes(searchTerm.toLowerCase()) || 
      escala.responsavel.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filtro de departamento
    const matchesDepartamento = departamentoFiltro === "todos" || escala.departamento === departamentoFiltro;
    
    // Filtro de status
    const matchesStatus = statusFiltro === "todos" || escala.status === statusFiltro;
    
    return matchesSearch && matchesDepartamento && matchesStatus;
  });

  // Ordenar escalas por data (mais recentes primeiro)
  const sortedEscalas = [...filteredEscalas].sort((a, b) => 
    new Date(b.dataInicio) - new Date(a.dataInicio)
  );

  const handleVisualizarEscala = (escala) => {
    setSelectedEscala(escala);
    setShowVisualizarEscalaDialog(true);
  };

  const handleNovaEscala = () => {
    setShowNovaEscalaDialog(false);
    // Lógica para criar nova escala
    const novaEscalaObj = {
      id: `escala-${Math.floor(Math.random() * 1000)}`,
      nome: novaEscala.nome,
      departamento: novaEscala.departamento,
      dataInicio: novaEscala.dataInicio,
      dataFim: novaEscala.dataFim,
      tipo: novaEscala.tipo,
      status: "rascunho",
      responsavel: novaEscala.responsavel || "Usuário Atual",
      colaboradores: novaEscala.colaboradores.map(colId => {
        const colaborador = todosColaboradores.find(col => col.id === colId);
        return {
          id: colaborador.id,
          nome: colaborador.nome,
          cargo: colaborador.cargo,
          avatar: colaborador.avatar,
          turno: "Diurno", // Valor padrão
          horario: "08:00 - 17:00" // Valor padrão
        };
      })
    };

    setEscalas([novaEscalaObj, ...escalas]);
    
    // Resetar o formulário
    setNovaEscala({
      nome: "",
      departamento: "",
      dataInicio: "",
      dataFim: "",
      tipo: "mensal",
      responsavel: "",
      colaboradores: []
    });
  };

  // Mover para o mês anterior
  const handlePreviousMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  // Mover para o próximo mês
  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  // Obter nome do mês
  const getMonthName = (month) => {
    const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", 
                        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    return monthNames[month];
  };

  // Formatar data
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  // Função para renderizar o calendário
  const renderCalendario = () => {
    // Primeiro dia do mês atual
    const firstDay = new Date(currentYear, currentMonth, 1);
    // Último dia do mês atual
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    
    // Dias da semana
    const diasSemana = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
    
    // Calcular quantos dias o mês tem
    const numDias = lastDay.getDate();
    
    // Calcular em que dia da semana começa o mês (0 = domingo, 6 = sábado)
    const primeiroDiaSemana = firstDay.getDay();
    
    // Escalas para o mês atual
    const escalasDoMes = escalas.filter(escala => {
      const inicio = new Date(escala.dataInicio);
      const fim = new Date(escala.dataFim);
      
      // Verificar se a escala está ativa no mês atual
      return (inicio.getMonth() <= currentMonth && inicio.getFullYear() <= currentYear) &&
             (fim.getMonth() >= currentMonth && fim.getFullYear() >= currentYear);
    });
    
    // Criar dias do calendário
    const diasCalendario = [];
    
    // Adicionar dias vazios do mês anterior
    for (let i = 0; i < primeiroDiaSemana; i++) {
      diasCalendario.push(null);
    }
    
    // Adicionar dias do mês atual
    for (let dia = 1; dia <= numDias; dia++) {
      const dataAtual = new Date(currentYear, currentMonth, dia);
      const escalasNoDia = escalasDoMes.filter(escala => {
        const inicio = new Date(escala.dataInicio);
        const fim = new Date(escala.dataFim);
        return dataAtual >= inicio && dataAtual <= fim;
      });
      
      diasCalendario.push({
        dia,
        escalas: escalasNoDia
      });
    }
    
    // Organizar em semanas
    const semanas = [];
    for (let i = 0; i < diasCalendario.length; i += 7) {
      semanas.push(diasCalendario.slice(i, i + 7));
    }
    
    // Adicionar dias vazios na última semana
    const ultimaSemana = semanas[semanas.length - 1];
    if (ultimaSemana && ultimaSemana.length < 7) {
      for (let i = ultimaSemana.length; i < 7; i++) {
        ultimaSemana.push(null);
      }
    }
    
    return (
      <div className="mt-4">
        <div className="flex justify-between items-center mb-4">
          <Button variant="outline" size="sm" onClick={handlePreviousMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <h2 className="text-xl font-bold">
            {getMonthName(currentMonth)} {currentYear}
          </h2>
          <Button variant="outline" size="sm" onClick={handleNextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="grid grid-cols-7 gap-px bg-gray-200 rounded-md overflow-hidden">
          {/* Cabeçalho dos dias da semana */}
          {diasSemana.map((dia, index) => (
            <div key={`cabecalho-${index}`} className="bg-gray-100 text-center p-2 font-medium text-sm">
              {dia}
            </div>
          ))}
          
          {/* Dias do calendário */}
          {semanas.map((semana, semanaIndex) => (
            semana.map((dia, diaIndex) => (
              <div 
                key={`dia-${semanaIndex}-${diaIndex}`} 
                className={`bg-white min-h-24 p-2 ${!dia ? 'text-gray-300' : ''} ${
                  dia && new Date().getDate() === dia.dia && 
                  new Date().getMonth() === currentMonth && 
                  new Date().getFullYear() === currentYear ? 
                  'bg-blue-50 border border-blue-200' : ''
                }`}
              >
                {dia ? (
                  <div>
                    <div className="flex justify-between items-start">
                      <span className="font-medium">{dia.dia}</span>
                      {dia.escalas.length > 0 && (
                        <Badge className="bg-green-100 text-green-800">
                          {dia.escalas.length}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="mt-1">
                      {dia.escalas.slice(0, 2).map((escala, index) => (
                        <div 
                          key={`escala-${index}`} 
                          className="text-xs p-1 mb-1 rounded truncate cursor-pointer hover:bg-gray-100"
                          title={escala.nome}
                          onClick={() => handleVisualizarEscala(escala)}
                        >
                          {escala.nome.length > 18 ? `${escala.nome.substring(0, 15)}...` : escala.nome}
                        </div>
                      ))}
                      
                      {dia.escalas.length > 2 && (
                        <div className="text-xs text-gray-500 text-center">
                          + {dia.escalas.length - 2} mais
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <span>&nbsp;</span>
                )}
              </div>
            ))
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Escalas de Trabalho</h1>
          <p className="text-gray-500 mt-1">
            Gerencie as escalas de trabalho dos colaboradores
          </p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700" onClick={() => setShowNovaEscalaDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Escala
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="lista">Lista de Escalas</TabsTrigger>
          <TabsTrigger value="calendario">Calendário</TabsTrigger>
        </TabsList>

        <TabsContent value="lista" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row gap-4 sm:items-center justify-between">
                <div className="relative w-full sm:w-64">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Buscar escalas..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex flex-wrap gap-2">
                  <Select value={departamentoFiltro} onValueChange={setDepartamentoFiltro}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Departamento" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos os departamentos</SelectItem>
                      <SelectItem value="Produção">Produção</SelectItem>
                      <SelectItem value="Qualidade">Qualidade</SelectItem>
                      <SelectItem value="Cultivo">Cultivo</SelectItem>
                      <SelectItem value="Geral">Geral</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select value={statusFiltro} onValueChange={setStatusFiltro}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos os status</SelectItem>
                      <SelectItem value="rascunho">Rascunho</SelectItem>
                      <SelectItem value="publicada">Publicada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
                </div>
              ) : sortedEscalas.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[40%]">Nome</TableHead>
                        <TableHead>Departamento</TableHead>
                        <TableHead>Período</TableHead>
                        <TableHead>Colaboradores</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sortedEscalas.map((escala) => (
                        <TableRow key={escala.id}>
                          <TableCell className="font-medium">
                            <div className="flex flex-col">
                              <p>{escala.nome}</p>
                              <p className="text-sm text-gray-500">Responsável: {escala.responsavel}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="capitalize">
                              {escala.departamento}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-col text-sm">
                              <span>Início: {formatDate(escala.dataInicio)}</span>
                              <span>Fim: {formatDate(escala.dataFim)}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex -space-x-2">
                              {escala.colaboradores.slice(0, 3).map((colaborador, index) => (
                                <Avatar key={index} className="border-2 border-white h-8 w-8">
                                  <AvatarFallback className="text-xs">
                                    {colaborador.avatar}
                                  </AvatarFallback>
                                </Avatar>
                              ))}
                              {escala.colaboradores.length > 3 && (
                                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-200 border-2 border-white text-xs font-medium">
                                  +{escala.colaboradores.length - 3}
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={escala.status === 'publicada' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                              {escala.status === 'publicada' ? 'Publicada' : 'Rascunho'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <span className="sr-only">Abrir menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleVisualizarEscala(escala)}>
                                  <CalendarIcon className="mr-2 h-4 w-4" />
                                  Visualizar
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="mr-2 h-4 w-4" />
                                  Editar
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Download className="mr-2 h-4 w-4" />
                                  Exportar (PDF)
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Printer className="mr-2 h-4 w-4" />
                                  Imprimir
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                {escala.status === 'rascunho' ? (
                                  <DropdownMenuItem>
                                    <CheckCircle2 className="mr-2 h-4 w-4" />
                                    Publicar
                                  </DropdownMenuItem>
                                ) : (
                                  <DropdownMenuItem>
                                    <MessageSquare className="mr-2 h-4 w-4" />
                                    Notificar colaboradores
                                  </DropdownMenuItem>
                                )}
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">
                                  <Trash className="mr-2 h-4 w-4" />
                                  Excluir
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-10">
                  <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                  <h3 className="text-lg font-medium">Nenhuma escala encontrada</h3>
                  <p className="text-gray-500 mt-1">
                    Comece criando uma nova escala para seus colaboradores.
                  </p>
                  <Button className="mt-4" onClick={() => setShowNovaEscalaDialog(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Nova Escala
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendario">
          <Card>
            <CardHeader>
              <CardTitle>Calendário de Escalas</CardTitle>
              <CardDescription>
                Visualize todas as escalas em formato de calendário
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
                </div>
              ) : (
                renderCalendario()
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Diálogo de Nova Escala */}
      <Dialog open={showNovaEscalaDialog} onOpenChange={setShowNovaEscalaDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Criar Nova Escala</DialogTitle>
            <DialogDescription>
              Preencha as informações para criar uma nova escala de trabalho.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 gap-3">
              <div className="space-y-2">
                <Label htmlFor="nome-escala">Nome da escala</Label>
                <Input 
                  id="nome-escala" 
                  placeholder="Ex: Escala de Produção - Agosto 2023" 
                  value={novaEscala.nome}
                  onChange={(e) => setNovaEscala({...novaEscala, nome: e.target.value})}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="departamento">Departamento</Label>
                  <Select
                    value={novaEscala.departamento}
                    onValueChange={(value) => setNovaEscala({...novaEscala, departamento: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um departamento" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Produção">Produção</SelectItem>
                      <SelectItem value="Qualidade">Qualidade</SelectItem>
                      <SelectItem value="Cultivo">Cultivo</SelectItem>
                      <SelectItem value="Geral">Geral</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tipo-escala">Tipo de escala</Label>
                  <Select
                    value={novaEscala.tipo}
                    onValueChange={(value) => setNovaEscala({...novaEscala, tipo: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mensal">Mensal</SelectItem>
                      <SelectItem value="semanal">Semanal</SelectItem>
                      <SelectItem value="especial">Especial (Plantão/Eventos)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="data-inicio">Data de início</Label>
                  <Input 
                    id="data-inicio"
                    type="date"
                    value={novaEscala.dataInicio}
                    onChange={(e) => setNovaEscala({...novaEscala, dataInicio: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="data-fim">Data de fim</Label>
                  <Input 
                    id="data-fim"
                    type="date"
                    value={novaEscala.dataFim}
                    onChange={(e) => setNovaEscala({...novaEscala, dataFim: e.target.value})}
                  />
                </div>
              </div>
              
              <Separator className="my-2" />
              
              <div className="space-y-2">
                <Label>Selecione os colaboradores</Label>
                <div className="border rounded-md p-4 space-y-2 max-h-48 overflow-y-auto">
                  {todosColaboradores
                    .filter(col => !novaEscala.departamento || col.departamento === novaEscala.departamento || novaEscala.departamento === "Geral")
                    .map(colaborador => (
                    <div key={colaborador.id} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`colaborador-${colaborador.id}`} 
                        checked={novaEscala.colaboradores.includes(colaborador.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setNovaEscala({
                              ...novaEscala, 
                              colaboradores: [...novaEscala.colaboradores, colaborador.id]
                            });
                          } else {
                            setNovaEscala({
                              ...novaEscala, 
                              colaboradores: novaEscala.colaboradores.filter(id => id !== colaborador.id)
                            });
                          }
                        }}
                      />
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarFallback className="text-xs">{colaborador.avatar}</AvatarFallback>
                        </Avatar>
                        <label
                          htmlFor={`colaborador-${colaborador.id}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {colaborador.nome}
                          <span className="ml-1 text-xs text-gray-500">({colaborador.cargo})</span>
                        </label>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNovaEscalaDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleNovaEscala} 
              disabled={!novaEscala.nome || !novaEscala.departamento || !novaEscala.dataInicio || !novaEscala.dataFim || novaEscala.colaboradores.length === 0}
            >
              Criar Escala
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de Visualização de Escala */}
      {selectedEscala && (
        <Dialog open={showVisualizarEscalaDialog} onOpenChange={setShowVisualizarEscalaDialog}>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedEscala.nome}</DialogTitle>
              <DialogDescription>
                Período: {formatDate(selectedEscala.dataInicio)} a {formatDate(selectedEscala.dataFim)}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="flex flex-wrap justify-between items-center gap-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{selectedEscala.departamento}</Badge>
                  <Badge className={selectedEscala.status === 'publicada' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                    {selectedEscala.status === 'publicada' ? 'Publicada' : 'Rascunho'}
                  </Badge>
                </div>
                
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Edit className="mr-2 h-4 w-4" />
                    Editar
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Exportar
                  </Button>
                  <Button variant="outline" size="sm">
                    <Printer className="mr-2 h-4 w-4" />
                    Imprimir
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share className="mr-2 h-4 w-4" />
                    Compartilhar
                  </Button>
                </div>
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-1">
                  <div className="bg-gray-50 p-4 rounded-md">
                    <h3 className="font-medium mb-3">Colaboradores</h3>
                    <div className="space-y-3">
                      {selectedEscala.colaboradores.map((colaborador, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <Avatar>
                            <AvatarFallback>{colaborador.avatar}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-sm">{colaborador.nome}</p>
                            <p className="text-xs text-gray-500">{colaborador.cargo}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="md:col-span-3">
                  <div className="bg-white rounded-md border overflow-hidden">
                    <div className="bg-gray-50 p-4 border-b">
                      <h3 className="font-medium">Escala do Período</h3>
                    </div>
                    
                    <div className="p-4">
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Colaborador</TableHead>
                              <TableHead>Cargo</TableHead>
                              <TableHead>Turno</TableHead>
                              <TableHead>Horário</TableHead>
                              <TableHead>Observação</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedEscala.colaboradores.map((colaborador, index) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium">
                                  <div className="flex items-center gap-2">
                                    <Avatar className="h-6 w-6">
                                      <AvatarFallback className="text-xs">{colaborador.avatar}</AvatarFallback>
                                    </Avatar>
                                    <span>{colaborador.nome}</span>
                                  </div>
                                </TableCell>
                                <TableCell>{colaborador.cargo}</TableCell>
                                <TableCell>
                                  <Badge className={
                                    colaborador.turno === 'Diurno' ? 'bg-blue-100 text-blue-800' :
                                    colaborador.turno === 'Vespertino' ? 'bg-orange-100 text-orange-800' :
                                    'bg-indigo-100 text-indigo-800'
                                  }>
                                    {colaborador.turno === 'Diurno' ? 
                                      <Sun className="h-3 w-3 mr-1" /> : 
                                      <Moon className="h-3 w-3 mr-1" />
                                    }
                                    {colaborador.turno}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center gap-1">
                                    <Clock3 className="h-3 w-3 text-gray-400" />
                                    <span>{colaborador.horario}</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  {/* Observações simuladas */}
                                  {index % 3 === 0 ? 
                                    <span className="text-sm text-gray-500">Folga aos domingos</span> : 
                                    index % 2 === 0 ? 
                                    <span className="text-sm text-gray-500">Hora extra aprovada</span> : 
                                    <span className="text-sm text-gray-500">-</span>
                                  }
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                      
                      {selectedEscala.colaboradores.length === 0 && (
                        <div className="text-center py-8">
                          <p className="text-gray-500">Nenhum colaborador adicionado a esta escala ainda.</p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Exemplo de outro elemento que poderia ser mostrado */}
                  <div className="mt-4 bg-white rounded-md border overflow-hidden">
                    <div className="bg-gray-50 p-4 border-b">
                      <h3 className="font-medium">Turnos Específicos</h3>
                    </div>
                    
                    <div className="p-4">
                      <div className="flex flex-col items-center justify-center py-8">
                        <ClipboardList className="h-12 w-12 text-gray-300 mb-2" />
                        <p className="text-gray-500">
                          Para definir escalas específicas por data, edite esta escala e adicione turnos especiais.
                        </p>
                        <Button variant="outline" className="mt-4">
                          Adicionar Turnos Específicos
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowVisualizarEscalaDialog(false)}>
                Fechar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
