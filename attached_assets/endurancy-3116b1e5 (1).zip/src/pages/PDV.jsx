
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Search,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  CreditCard,
  ClipboardCheck,
  User,
  QrCode,
  Receipt,
  X,
  CheckCircle2,
  Printer,
  ArrowLeft,
  Maximize,
  Minimize,
  Clock
} from "lucide-react";
import { Product } from '@/api/entities';
import { Venda } from '@/api/entities';
import { Caixa } from '@/api/entities';

export default function PDV() {
  const navigate = useNavigate();
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [cart, setCart] = useState([]);
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showReceipt, setShowReceipt] = useState(false);
  const [customer, setCustomer] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState("dinheiro");
  const [amountPaid, setAmountPaid] = useState("");
  const [change, setChange] = useState(0);
  const [lastSale, setLastSale] = useState(null);
  const [caixaInfo, setCaixaInfo] = useState({ status: "fechado", id: null });

  useEffect(() => {
    checkCaixaStatus();
    loadProducts();
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  useEffect(() => {
    if (searchTerm) {
      const results = products.filter(product => 
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.sku?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredProducts(results);
    } else {
      setFilteredProducts(products);
    }
  }, [searchTerm, products]);

  const handleFullscreenChange = () => {
    setIsFullscreen(!!document.fullscreenElement);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      const elem = document.documentElement;
      if (elem.requestFullscreen) {
        elem.requestFullscreen();
      } else if (elem.webkitRequestFullscreen) { 
        elem.webkitRequestFullscreen();
      } else if (elem.msRequestFullscreen) { 
        elem.msRequestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) { 
        document.webkitExitFullscreen();
      } else if (document.msExitFullscreen) { 
        document.msExitFullscreen();
      }
    }
  };

  const checkCaixaStatus = async () => {
    try {
      const caixas = await Caixa.list("-created_date", 1);
      if (caixas && caixas.length > 0) {
        setCaixaInfo({
          status: caixas[0].status,
          id: caixas[0].id
        });
      }
    } catch (error) {
      console.error("Error checking caixa status:", error);
    }
  };

  const loadProducts = async () => {
    try {
      const data = await Product.list();
      setProducts(data);
      setFilteredProducts(data);
    } catch (error) {
      console.error("Error loading products:", error);
    }
  };

  const addToCart = (product) => {
    const existingItem = cart.find(item => item.id === product.id);
    if (existingItem) {
      setCart(cart.map(item => 
        item.id === product.id 
          ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * item.price } 
          : item
      ));
    } else {
      setCart([...cart, { 
        id: product.id, 
        name: product.name, 
        price: product.price, 
        quantity: 1, 
        subtotal: product.price,
        controlled_substance: product.controlled_substance || false
      }]);
    }
  };

  const updateQuantity = (id, newQuantity) => {
    if (newQuantity <= 0) {
      return removeFromCart(id);
    }
    
    setCart(cart.map(item => 
      item.id === id 
        ? { ...item, quantity: newQuantity, subtotal: newQuantity * item.price } 
        : item
    ));
  };

  const removeFromCart = (id) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + item.subtotal, 0);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const handlePayment = async () => {
    if (cart.length === 0) return;
    
    if (paymentMethod === "dinheiro" && !amountPaid) {
      alert("Informe o valor recebido");
      return;
    }
    
    setIsProcessing(true);
    
    try {
      const total = getCartTotal();
      
      let changeAmount = 0;
      if (paymentMethod === "dinheiro" && amountPaid) {
        changeAmount = parseFloat(amountPaid) - total;
        setChange(changeAmount);
      }
      
      const venda = await Venda.create({
        organization_id: "org_1", 
        numero_venda: `V${Date.now()}`,
        data_venda: new Date().toISOString(),
        tipo_venda: "balcao",
        status: "finalizada",
        cliente: customer ? {
          id: customer.id,
          nome: customer.nome_completo || customer.nome,
          cpf: customer.cpf
        } : null,
        items: cart.map(item => ({
          produto_id: item.id,
          nome_produto: item.name,
          quantidade: item.quantity,
          valor_unitario: item.price,
          valor_total: item.subtotal
        })),
        subtotal: total,
        desconto: 0,
        total: total,
        pagamento: {
          forma: paymentMethod,
          valor_pago: paymentMethod === "dinheiro" ? parseFloat(amountPaid) : total,
          troco: changeAmount
        },
        vendedor_id: "user_1", 
        caixa_id: caixaInfo.id
      });
      
      setLastSale(venda);
      setShowReceipt(true);
      
      setCart([]);
      setCustomer(null);
      setPaymentMethod("dinheiro");
      setAmountPaid("");
      setChange(0);
      
    } catch (error) {
      console.error("Error processing sale:", error);
      alert("Erro ao processar venda. Tente novamente.");
    } finally {
      setIsProcessing(false);
    }
  };

  const printReceipt = () => {
    window.print();
  };

  const newSale = () => {
    setShowReceipt(false);
    setLastSale(null);
  };

  if (caixaInfo.status !== "aberto") {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-50">
        <Card className="w-[400px]">
          <CardHeader>
            <CardTitle>Caixa Fechado</CardTitle>
            <CardDescription>É necessário abrir o caixa para iniciar as vendas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="rounded-full bg-yellow-100 p-3">
                <Clock className="h-10 w-10 text-yellow-600" />
              </div>
              <p className="text-center text-sm text-gray-500">
                O caixa está fechado. Para iniciar as vendas, é necessário abrir o caixa primeiro.
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              onClick={() => navigate(createPageUrl("DispensarioCaixa"))}
            >
              Ir para Gestão de Caixa
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  if (showReceipt && lastSale) {
    return (
      <div className="flex min-h-screen flex-col bg-gray-50 p-4 md:p-6">
        <div className="flex justify-between mb-6">
          <Button variant="outline" onClick={newSale}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Nova Venda
          </Button>
          <Button variant="outline" onClick={printReceipt}>
            <Printer className="h-4 w-4 mr-2" />
            Imprimir
          </Button>
        </div>
        
        <Card className="mx-auto w-full max-w-md">
          <CardHeader className="text-center border-b">
            <CardTitle>Comprovante de Venda</CardTitle>
            <CardDescription>
              {new Date(lastSale.data_venda).toLocaleString('pt-BR')}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-6">
            <div className="text-center mb-6">
              <h3 className="font-semibold">Dispensário Medicinal</h3>
              <p className="text-sm text-gray-500">CNPJ: 12.345.678/0001-90</p>
              <p className="text-sm text-gray-500">Rua Exemplo, 123 - Cidade/UF</p>
            </div>
            
            <Separator />
            
            <div>
              <h4 className="font-semibold mb-2">Nº VENDA: {lastSale.numero_venda}</h4>
              {lastSale.cliente && (
                <p className="text-sm">Cliente: {lastSale.cliente.nome}</p>
              )}
            </div>
            
            <Separator />
            
            <div>
              <h4 className="font-semibold mb-2">ITENS</h4>
              <div className="space-y-2">
                {lastSale.items.map((item, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <div>
                      <span>{item.quantidade}x {item.nome_produto}</span>
                      <p className="text-xs text-gray-500">
                        {formatCurrency(item.valor_unitario)} un.
                      </p>
                    </div>
                    <span>{formatCurrency(item.valor_total)}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-1">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>{formatCurrency(lastSale.subtotal)}</span>
              </div>
              {lastSale.desconto > 0 && (
                <div className="flex justify-between">
                  <span>Desconto:</span>
                  <span>- {formatCurrency(lastSale.desconto)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold">
                <span>Total:</span>
                <span>{formatCurrency(lastSale.total)}</span>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-1">
              <div className="flex justify-between">
                <span>Forma de Pagamento:</span>
                <span>
                  {lastSale.pagamento.forma === 'dinheiro' ? 'Dinheiro' : 
                   lastSale.pagamento.forma === 'cartao_credito' ? 'Cartão de Crédito' : 
                   lastSale.pagamento.forma === 'cartao_debito' ? 'Cartão de Débito' : 
                   lastSale.pagamento.forma === 'pix' ? 'PIX' : lastSale.pagamento.forma}
                </span>
              </div>
              {lastSale.pagamento.forma === 'dinheiro' && (
                <>
                  <div className="flex justify-between">
                    <span>Valor Pago:</span>
                    <span>{formatCurrency(lastSale.pagamento.valor_pago)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Troco:</span>
                    <span>{formatCurrency(lastSale.pagamento.troco)}</span>
                  </div>
                </>
              )}
            </div>
            
            <div className="pt-4 text-center">
              <CheckCircle2 className="h-8 w-8 mx-auto text-green-500 mb-2" />
              <h3 className="font-semibold text-green-600">Venda Finalizada</h3>
              <p className="text-sm text-gray-500 mt-1">
                Obrigado pela compra!
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className={`flex h-screen flex-col overflow-hidden ${isFullscreen ? 'bg-gray-900' : 'bg-gray-50'}`}>
      <div className={`flex justify-between items-center p-4 ${isFullscreen ? 'bg-gray-800 text-white' : 'bg-white border-b'}`}>
        <h1 className="text-xl font-bold">PDV - Dispensário</h1>
        <div className="flex gap-2">
          <Button 
            variant={isFullscreen ? "outline" : "default"} 
            size="sm" 
            onClick={toggleFullscreen}
            className={isFullscreen ? "border-white text-white hover:bg-gray-700" : ""}
          >
            {isFullscreen ? (
              <>
                <Minimize className="h-4 w-4 mr-2" />
                Sair da Tela Cheia
              </>
            ) : (
              <>
                <Maximize className="h-4 w-4 mr-2" />
                Tela Cheia
              </>
            )}
          </Button>
          {isFullscreen && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate(createPageUrl("DispensarioDashboard"))}
              className="border-white text-white hover:bg-gray-700"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
          )}
        </div>
      </div>

      <div className={`flex flex-1 ${isFullscreen ? 'bg-gray-800 text-white' : ''}`}>
        <div className={`w-2/5 flex flex-col border-r ${isFullscreen ? 'border-gray-700 bg-gray-800' : ''}`}>
          <div className="p-4 border-b">
            <div className="flex gap-2 mb-4">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => setCustomer({ nome: "Cliente Padrão" })}
              >
                <User className="h-4 w-4 mr-2" />
                {customer ? customer.nome : "Cliente"}
              </Button>
              <Button variant="outline" className="flex-1">
                <QrCode className="h-4 w-4 mr-2" />
                Scanear
              </Button>
            </div>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="Buscar produto..." 
                className="pl-8" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-auto p-4">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <ShoppingCart className={`h-12 w-12 mb-2 ${isFullscreen ? 'text-gray-600' : 'text-gray-300'}`} />
                <h3 className={`font-medium ${isFullscreen ? 'text-gray-400' : 'text-gray-500'}`}>Carrinho Vazio</h3>
                <p className={`text-sm mt-1 ${isFullscreen ? 'text-gray-500' : 'text-gray-400'}`}>
                  Adicione produtos clicando nos itens à direita
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {cart.map((item) => (
                  <div 
                    key={item.id} 
                    className={`rounded-lg p-3 ${isFullscreen ? 'bg-gray-700 hover:bg-gray-600' : 'bg-white border hover:bg-gray-50'}`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-medium">{item.name}</h3>
                        <p className={`text-sm ${isFullscreen ? 'text-gray-300' : 'text-gray-500'}`}>
                          {formatCurrency(item.price)} / unidade
                        </p>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => removeFromCart(item.id)}
                        className={isFullscreen ? 'text-red-400 hover:text-red-300 hover:bg-gray-600' : ''}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-1">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className={isFullscreen ? 'border-gray-600 hover:bg-gray-600 text-white' : ''}
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <div 
                          className={`px-3 py-1 rounded-md w-10 text-center ${isFullscreen ? 'bg-gray-600 text-white' : 'bg-gray-100'}`}
                        >
                          {item.quantity}
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className={isFullscreen ? 'border-gray-600 hover:bg-gray-600 text-white' : ''}
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="font-medium">{formatCurrency(item.subtotal)}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div className={`p-4 border-t ${isFullscreen ? 'border-gray-700 bg-gray-800' : ''}`}>
            <div className="space-y-2 mb-4">
              <div className="flex justify-between">
                <span className={isFullscreen ? 'text-gray-300' : 'text-gray-500'}>Subtotal</span>
                <span>{formatCurrency(getCartTotal())}</span>
              </div>
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>{formatCurrency(getCartTotal())}</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-2 mb-4">
              <Button 
                variant={paymentMethod === "dinheiro" ? "default" : "outline"}
                onClick={() => setPaymentMethod("dinheiro")}
                className={isFullscreen && paymentMethod !== "dinheiro" ? 'border-gray-600 text-white hover:bg-gray-700' : ''}
              >
                Dinheiro
              </Button>
              <Button 
                variant={paymentMethod === "cartao_credito" ? "default" : "outline"}
                onClick={() => setPaymentMethod("cartao_credito")}
                className={isFullscreen && paymentMethod !== "cartao_credito" ? 'border-gray-600 text-white hover:bg-gray-700' : ''}
              >
                Crédito
              </Button>
              <Button 
                variant={paymentMethod === "cartao_debito" ? "default" : "outline"}
                onClick={() => setPaymentMethod("cartao_debito")}
                className={isFullscreen && paymentMethod !== "cartao_debito" ? 'border-gray-600 text-white hover:bg-gray-700' : ''}
              >
                Débito
              </Button>
              <Button 
                variant={paymentMethod === "pix" ? "default" : "outline"}
                onClick={() => setPaymentMethod("pix")}
                className={isFullscreen && paymentMethod !== "pix" ? 'border-gray-600 text-white hover:bg-gray-700' : ''}
              >
                PIX
              </Button>
            </div>
            
            {paymentMethod === "dinheiro" && (
              <div className="space-y-4 mb-4">
                <div>
                  <Label htmlFor="amount-paid" className={isFullscreen ? 'text-gray-300' : ''}>
                    Valor Recebido
                  </Label>
                  <Input
                    id="amount-paid"
                    type="number"
                    value={amountPaid}
                    onChange={(e) => {
                      setAmountPaid(e.target.value);
                      const paid = parseFloat(e.target.value) || 0;
                      setChange(Math.max(0, paid - getCartTotal()));
                    }}
                    placeholder="0,00"
                    className={isFullscreen ? 'bg-gray-700 border-gray-600 text-white' : ''}
                  />
                </div>
                {amountPaid && parseFloat(amountPaid) >= getCartTotal() && (
                  <div className="flex justify-between items-center p-2 bg-green-100 rounded-md text-green-800">
                    <span>Troco:</span>
                    <span className="font-bold">{formatCurrency(change)}</span>
                  </div>
                )}
              </div>
            )}
            
            <Button 
              onClick={handlePayment} 
              disabled={cart.length === 0 || isProcessing}
              className="w-full"
            >
              {isProcessing ? (
                "Processando..."
              ) : (
                <>
                  <CreditCard className="h-4 w-4 mr-2" />
                  Finalizar Venda {cart.length > 0 && `(${formatCurrency(getCartTotal())})`}
                </>
              )}
            </Button>
          </div>
        </div>
        
        <div className={`w-3/5 flex flex-col ${isFullscreen ? 'bg-gray-800' : ''}`}>
          <div className="p-4 border-b">
            <Tabs defaultValue="all">
              <TabsList className={isFullscreen ? 'bg-gray-700' : ''}>
                <TabsTrigger value="all" className={isFullscreen ? 'data-[state=active]:bg-gray-600 data-[state=active]:text-white' : ''}>
                  Todos
                </TabsTrigger>
                <TabsTrigger value="oils" className={isFullscreen ? 'data-[state=active]:bg-gray-600 data-[state=active]:text-white' : ''}>
                  Óleos
                </TabsTrigger>
                <TabsTrigger value="capsules" className={isFullscreen ? 'data-[state=active]:bg-gray-600 data-[state=active]:text-white' : ''}>
                  Cápsulas
                </TabsTrigger>
                <TabsTrigger value="topical" className={isFullscreen ? 'data-[state=active]:bg-gray-600 data-[state=active]:text-white' : ''}>
                  Tópicos
                </TabsTrigger>
                <TabsTrigger value="others" className={isFullscreen ? 'data-[state=active]:bg-gray-600 data-[state=active]:text-white' : ''}>
                  Outros
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          <div className="flex-1 overflow-auto p-4">
            {isLoading ? (
              <div className="grid grid-cols-3 gap-4">
                {[...Array(12)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className={`h-32 rounded-lg ${isFullscreen ? 'bg-gray-700' : 'bg-gray-200'}`}></div>
                    <div className={`h-4 rounded mt-2 ${isFullscreen ? 'bg-gray-700' : 'bg-gray-200'}`}></div>
                    <div className={`h-4 w-1/2 rounded mt-2 ${isFullscreen ? 'bg-gray-700' : 'bg-gray-200'}`}></div>
                  </div>
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <Search className={`h-12 w-12 mb-2 ${isFullscreen ? 'text-gray-600' : 'text-gray-300'}`} />
                <h3 className={`font-medium ${isFullscreen ? 'text-gray-400' : 'text-gray-500'}`}>
                  Nenhum produto encontrado
                </h3>
                <p className={`text-sm mt-1 ${isFullscreen ? 'text-gray-500' : 'text-gray-400'}`}>
                  Tente outro termo de busca
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredProducts.map((product) => (
                  <div 
                    key={product.id} 
                    className={`rounded-lg p-4 cursor-pointer transition-colors ${
                      isFullscreen 
                        ? 'bg-gray-700 hover:bg-gray-600' 
                        : 'bg-white border hover:bg-gray-50'
                    }`}
                    onClick={() => addToCart(product)}
                  >
                    <div className="aspect-square rounded-md bg-gray-100 mb-2 overflow-hidden">
                      {product.image_url ? (
                        <img 
                          src={product.image_url} 
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className={`w-full h-full flex items-center justify-center ${isFullscreen ? 'bg-gray-600' : 'bg-gray-100'}`}>
                          <ShoppingCart className={`h-8 w-8 ${isFullscreen ? 'text-gray-500' : 'text-gray-300'}`} />
                        </div>
                      )}
                    </div>
                    <h3 className={`font-medium truncate ${isFullscreen ? 'text-white' : 'text-gray-900'}`}>
                      {product.name}
                    </h3>
                    <div className="flex justify-between items-center mt-1">
                      <span className="font-bold">{formatCurrency(product.price)}</span>
                      {product.controlled_substance && (
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          isFullscreen ? 'bg-yellow-700 text-yellow-100' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          Controlado
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
