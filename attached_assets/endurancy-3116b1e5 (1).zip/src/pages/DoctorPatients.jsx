
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { User } from '@/api/entities';
import { 
  LayoutDashboard, Video, Users, ClipboardList, Brain, DollarSign, 
  Settings, LogOut, Menu, X, Bell, Search, Filter, Plus, MoreHorizontal,
  FileText, Calendar, Phone, Mail, Eye, Pencil, Trash2, ClipboardCheck,
  ChevronLeft, ChevronRight, Download, Upload, FileUp, MessageSquare,
  UserPlus, SlidersHorizontal, ArrowUpDown, CheckCircle, XCircle, AlertTriangle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Spinner } from "@/components/ui/spinner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import DoctorLayout from '../components/DoctorLayout';

export default function DoctorPatients() {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [patients, setPatients] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [filteredPatients, setFilteredPatients] = useState([]);
  const [showAddPatientDialog, setShowAddPatientDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showPatientDetails, setShowPatientDetails] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [sortOrder, setSortOrder] = useState({ field: 'lastVisit', direction: 'desc' });
  const [filters, setFilters] = useState({
    conditions: [],
    minAge: '',
    maxAge: '',
    gender: 'all',
    status: 'all',
  });

  const [newPatient, setNewPatient] = useState({
    fullName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    gender: 'feminino',
    address: '',
    medicalConditions: '',
    medications: '',
    notes: '',
  });

  const patientsPerPage = 10;

  useEffect(() => {
    loadPatients();
  }, []);

  useEffect(() => {
    filterAndSortPatients();
  }, [patients, searchQuery, activeTab, sortOrder, filters]);

  const loadPatients = () => {
    setIsLoading(true);
    setTimeout(() => {
      const mockPatients = [
        {
          id: 'PAT001',
          fullName: 'Maria Oliveira',
          email: 'maria.oliveira@email.com',
          phone: '(11) 98765-4321',
          dateOfBirth: '1985-03-12',
          age: 39,
          gender: 'Feminino',
          address: 'Rua das Flores, 123 - São Paulo, SP',
          profileImage: null,
          medicalConditions: ['Ansiedade', 'Insônia'],
          medications: ['Fluoxetina 20mg', 'CBD Oil 5%'],
          prescriptions: [
            { id: 'PR001', date: '2024-03-01', products: ['CBD Oil 5%'], status: 'active' },
          ],
          consultations: [
            { id: 'CS001', date: '2024-03-01', type: 'Retorno', notes: 'Paciente relatou melhora no sono' },
            { id: 'CS002', date: '2024-01-15', type: 'Primeira Consulta', notes: 'Avaliação inicial' },
          ],
          status: 'active',
          lastVisit: '2024-03-01',
          nextVisit: '2024-04-01',
          notes: 'Paciente responsiva ao tratamento com CBD para insônia.',
          files: [
            { id: 'FL001', name: 'Exame de Sangue.pdf', date: '2024-01-15', type: 'Exame' },
            { id: 'FL002', name: 'Relatório Médico.pdf', date: '2024-01-15', type: 'Relatório' }
          ]
        },
        {
          id: 'PAT002',
          fullName: 'João Santos',
          email: 'joao.santos@email.com',
          phone: '(11) 91234-5678',
          dateOfBirth: '1972-08-25',
          age: 51,
          gender: 'Masculino',
          address: 'Av. Paulista, 1500, Apto 52 - São Paulo, SP',
          profileImage: null,
          medicalConditions: ['Dor Crônica', 'Artrite'],
          medications: ['CBD Oil 10%', 'Ibuprofeno 600mg'],
          prescriptions: [
            { id: 'PR002', date: '2024-02-10', products: ['CBD Oil 10%'], status: 'active' },
          ],
          consultations: [
            { id: 'CS003', date: '2024-02-10', type: 'Retorno', notes: 'Paciente relatou redução na dor' },
            { id: 'CS004', date: '2023-12-05', type: 'Primeira Consulta', notes: 'Avaliação inicial' },
          ],
          status: 'active',
          lastVisit: '2024-02-10',
          nextVisit: '2024-05-10',
          notes: 'Paciente com boa resposta ao tratamento para dor crônica.',
          files: [
            { id: 'FL003', name: 'Ressonância Magnética.pdf', date: '2023-12-01', type: 'Exame' }
          ]
        },
        {
          id: 'PAT003',
          fullName: 'Ana Pereira',
          email: 'ana.pereira@email.com',
          phone: '(11) 98888-7777',
          dateOfBirth: '1990-05-15',
          age: 34,
          gender: 'Feminino',
          address: 'Rua Augusta, 200 - São Paulo, SP',
          profileImage: null,
          medicalConditions: ['Epilepsia', 'Ansiedade'],
          medications: ['CBD Oil 20%', 'Lamotrigina 100mg'],
          prescriptions: [
            { id: 'PR003', date: '2024-01-20', products: ['CBD Oil 20%'], status: 'active' },
          ],
          consultations: [
            { id: 'CS005', date: '2024-01-20', type: 'Retorno', notes: 'Redução de 60% na frequência de crises' },
            { id: 'CS006', date: '2023-11-10', type: 'Primeira Consulta', notes: 'Avaliação inicial' },
          ],
          status: 'active',
          lastVisit: '2024-01-20',
          nextVisit: '2024-04-20',
          notes: 'Redução significativa no número de crises epilépticas após introdução do CBD.',
          files: [
            { id: 'FL004', name: 'EEG.pdf', date: '2023-10-30', type: 'Exame' },
            { id: 'FL005', name: 'Laudo Neurológico.pdf', date: '2023-11-05', type: 'Laudo' }
          ]
        },
        {
          id: 'PAT004',
          fullName: 'Carlos Mendes',
          email: 'carlos.mendes@email.com',
          phone: '(11) 97777-6666',
          dateOfBirth: '1965-12-03',
          age: 58,
          gender: 'Masculino',
          address: 'Rua Oscar Freire, 500 - São Paulo, SP',
          profileImage: null,
          medicalConditions: ['Parkinson', 'Hipertensão'],
          medications: ['CBD Oil 10%', 'Levodopa 200mg', 'Losartana 50mg'],
          prescriptions: [
            { id: 'PR004', date: '2023-12-15', products: ['CBD Oil 10%'], status: 'expiring' },
          ],
          consultations: [
            { id: 'CS007', date: '2023-12-15', type: 'Retorno', notes: 'Melhora nos tremores e rigidez' },
            { id: 'CS008', date: '2023-09-20', type: 'Primeira Consulta', notes: 'Avaliação inicial' },
          ],
          status: 'active',
          lastVisit: '2023-12-15',
          nextVisit: '2024-03-15',
          notes: 'Paciente apresenta melhora na qualidade de vida após introdução do CBD.',
          files: [
            { id: 'FL006', name: 'Avaliação Neurológica.pdf', date: '2023-09-15', type: 'Laudo' }
          ]
        },
        {
          id: 'PAT005',
          fullName: 'Paulo Silva',
          email: 'paulo.silva@email.com',
          phone: '(11) 95555-4444',
          dateOfBirth: '1988-07-20',
          age: 36,
          gender: 'Masculino',
          address: 'Alameda Santos, 800 - São Paulo, SP',
          profileImage: null,
          medicalConditions: ['TDAH', 'Insônia'],
          medications: ['CBD Oil 5%', 'Metilfenidato 10mg'],
          prescriptions: [
            { id: 'PR005', date: '2023-11-05', products: ['CBD Oil 5%'], status: 'expired' },
          ],
          consultations: [
            { id: 'CS009', date: '2023-11-05', type: 'Retorno', notes: 'Melhora na concentração e qualidade do sono' },
            { id: 'CS010', date: '2023-08-15', type: 'Primeira Consulta', notes: 'Avaliação inicial' },
          ],
          status: 'inactive',
          lastVisit: '2023-11-05',
          nextVisit: null,
          notes: 'Paciente não retornou para renovação da prescrição.',
          files: [
            { id: 'FL007', name: 'Avaliação Psiquiátrica.pdf', date: '2023-08-10', type: 'Laudo' }
          ]
        }
      ];
      
      setPatients(mockPatients);
      setFilteredPatients(mockPatients);
      setIsLoading(false);
    }, 1000);
  };

  const filterAndSortPatients = () => {
    if (!patients.length) return;
    
    let filtered = [...patients];
    
    if (activeTab === 'active') {
      filtered = filtered.filter(p => p.status === 'active');
    } else if (activeTab === 'inactive') {
      filtered = filtered.filter(p => p.status === 'inactive');
    }
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        p => p.fullName.toLowerCase().includes(query) || 
             p.email.toLowerCase().includes(query) ||
             p.phone.includes(query)
      );
    }
    
    if (filters.gender !== 'all') {
      filtered = filtered.filter(p => p.gender.toLowerCase() === filters.gender);
    }
    
    if (filters.status !== 'all') {
      filtered = filtered.filter(p => p.status === filters.status);
    }
    
    if (filters.minAge && !isNaN(parseInt(filters.minAge))) {
      filtered = filtered.filter(p => p.age >= parseInt(filters.minAge));
    }
    
    if (filters.maxAge && !isNaN(parseInt(filters.maxAge))) {
      filtered = filtered.filter(p => p.age <= parseInt(filters.maxAge));
    }
    
    if (filters.conditions.length) {
      filtered = filtered.filter(p => 
        p.medicalConditions.some(condition => 
          filters.conditions.includes(condition.toLowerCase())
        )
      );
    }
    
    filtered.sort((a, b) => {
      const aValue = a[sortOrder.field];
      const bValue = b[sortOrder.field];
      
      if (!aValue && !bValue) return 0;
      if (!aValue) return 1;
      if (!bValue) return -1;
      
      const compareResult = 
        typeof aValue === 'string'
          ? aValue.localeCompare(bValue)
          : aValue - bValue;
      
      return sortOrder.direction === 'asc' ? compareResult : -compareResult;
    });
    
    setFilteredPatients(filtered);
  };

  const handleAddPatient = () => {
    if (!newPatient.fullName || !newPatient.email || !newPatient.dateOfBirth) {
      toast({
        title: "Dados incompletos",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newPatient.email)) {
      toast({
        title: "Email inválido",
        description: "Por favor, forneça um endereço de email válido.",
        variant: "destructive"
      });
      return;
    }
    
    const newPatientObj = {
      id: `PAT${String(patients.length + 1).padStart(3, '0')}`,
      fullName: newPatient.fullName,
      email: newPatient.email,
      phone: newPatient.phone || "",
      dateOfBirth: newPatient.dateOfBirth,
      age: calculateAge(newPatient.dateOfBirth),
      gender: newPatient.gender === 'masculino' ? 'Masculino' : 'Feminino',
      address: newPatient.address || "",
      profileImage: null,
      medicalConditions: newPatient.medicalConditions ? 
        newPatient.medicalConditions.split(',').map(c => c.trim()) : [],
      medications: newPatient.medications ? 
        newPatient.medications.split(',').map(m => m.trim()) : [],
      prescriptions: [],
      consultations: [],
      status: 'active',
      lastVisit: new Date().toISOString().split('T')[0],
      nextVisit: null,
      notes: newPatient.notes || "",
      files: []
    };
    
    setPatients([newPatientObj, ...patients]);
    
    toast({
      title: "Paciente adicionado",
      description: `${newPatient.fullName} foi adicionado com sucesso.`,
    });
    
    setNewPatient({
      fullName: '',
      email: '',
      phone: '',
      dateOfBirth: '',
      gender: 'feminino',
      address: '',
      medicalConditions: '',
      medications: '',
      notes: '',
    });
    
    setShowAddPatientDialog(false);
  };

  const calculateAge = (dateOfBirth) => {
    const birth = new Date(dateOfBirth);
    const today = new Date();
    
    let age = today.getFullYear() - birth.getFullYear();
    const monthDifference = today.getMonth() - birth.getMonth();
    
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  };

  const handleViewPatient = (patient) => {
    setSelectedPatient(patient);
    setShowPatientDetails(true);
  };

  const handleSort = (field) => {
    setSortOrder(prev => ({
      field,
      direction: prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const handleConditionToggle = (condition) => {
    setFilters(prev => {
      const conditions = [...prev.conditions];
      const index = conditions.indexOf(condition.toLowerCase());
      
      if (index === -1) {
        conditions.push(condition.toLowerCase());
      } else {
        conditions.splice(index, 1);
      }
      
      return { ...prev, conditions };
    });
  };

  const resetFilters = () => {
    setFilters({
      conditions: [],
      minAge: '',
      maxAge: '',
      gender: 'all',
      status: 'all',
    });
    setSearchQuery('');
  };

  const getPagedPatients = () => {
    const startIndex = (currentPage - 1) * patientsPerPage;
    return filteredPatients.slice(startIndex, startIndex + patientsPerPage);
  };

  const pageCount = Math.ceil(filteredPatients.length / patientsPerPage);

  const CustomPagination = ({ currentPage, pageCount, onPageChange }) => {
    if (pageCount <= 1) return null;
    
    const getPageNumbers = () => {
      const pages = [];
      const maxVisiblePages = 5;
      
      if (pageCount <= maxVisiblePages) {
        for (let i = 1; i <= pageCount; i++) {
          pages.push(i);
        }
      } else {
        pages.push(1);
        
        const startPage = Math.max(2, currentPage - 1);
        const endPage = Math.min(pageCount - 1, currentPage + 1);
        
        if (startPage > 2) {
          pages.push('...');
        }
        
        for (let i = startPage; i <= endPage; i++) {
          pages.push(i);
        }
        
        if (endPage < pageCount - 1) {
          pages.push('...');
        }
        
        pages.push(pageCount);
      }
      
      return pages;
    };
    
    return (
      <div className="flex items-center justify-center space-x-2 py-4">
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        
        {getPageNumbers().map((page, index) => (
          page === '...' ? (
            <span key={`ellipsis-${index}`} className="px-2">...</span>
          ) : (
            <Button
              key={page}
              variant={currentPage === page ? "default" : "outline"}
              size="sm"
              onClick={() => onPageChange(page)}
            >
              {page}
            </Button>
          )
        ))}
        
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === pageCount}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    );
  };

  const allConditions = [...new Set(
    patients.flatMap(p => p.medicalConditions.map(c => c.toLowerCase()))
  )];

  return (
    <DoctorLayout>
      <div className="flex h-screen overflow-hidden bg-purple-50">
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          <header className="bg-white border-b shadow-sm z-10">
            <div className="flex items-center justify-between p-4">
              <h1 className="font-semibold text-lg">Pacientes</h1>
              <div className="flex items-center space-x-4">
                <Button variant="ghost" size="sm" className="hidden md:flex">
                  <Bell size={20} />
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="flex items-center">
                      <Avatar className="w-8 h-8 mr-2">
                        <AvatarFallback className="bg-purple-600 text-white">JS</AvatarFallback>
                      </Avatar>
                      <span className="hidden md:inline">Dr. João Silva</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <Link to={createPageUrl("DoctorSettings")} className="flex items-center w-full">
                        <Settings size={16} className="mr-2" />
                        Configurações
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="text-red-600" 
                      onClick={() => {
                        navigate(createPageUrl("Index"));
                      }}
                    >
                      <LogOut size={16} className="mr-2" />
                      Sair
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </header>

          <main className="flex-1 overflow-y-auto p-6">
            <div className="max-w-7xl mx-auto">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
                <div className="relative flex-1 md:w-80">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <Input 
                    className="pl-10" 
                    placeholder="Buscar pacientes..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline"
                    className="flex items-center gap-1"
                    onClick={() => setShowImportDialog(true)}
                  >
                    <Upload size={16} />
                    <span className="hidden md:inline">Importar</span>
                  </Button>
                  <Button
                    className="bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-1"
                    onClick={() => setShowAddPatientDialog(true)}
                  >
                    <Plus size={16} />
                    <span>Novo Paciente</span>
                  </Button>
                </div>
              </div>
              {isLoading ? (
                <div className="flex flex-col items-center justify-center p-8">
                  <Spinner className="text-purple-600 mb-4" />
                  <p className="text-gray-500">Carregando pacientes...</p>
                </div>
              ) : filteredPatients.length === 0 ? (
                <Card className="bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-8">
                    <Users size={48} className="text-gray-300 mb-4" />
                    <h3 className="text-lg font-medium mb-2">Nenhum paciente encontrado</h3>
                    <p className="text-gray-500 text-center max-w-md">
                      {searchQuery || filters.conditions.length || filters.gender !== 'all' || filters.status !== 'all' || filters.minAge || filters.maxAge
                        ? "Nenhum paciente corresponde aos filtros aplicados. Tente modificar sua busca."
                        : "Você ainda não tem pacientes cadastrados. Clique em 'Novo Paciente' para começar."}
                    </p>
                    {(searchQuery || filters.conditions.length || filters.gender !== 'all' || filters.status !== 'all' || filters.minAge || filters.maxAge) && (
                      <Button
                        variant="outline"
                        onClick={resetFilters}
                        className="mt-4"
                      >
                        Limpar Filtros
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <>
                  <Card className="bg-white">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Paciente</TableHead>
                          <TableHead>Contato</TableHead>
                          <TableHead>
                            <Button
                              variant="ghost"
                              className="flex items-center gap-1 -ml-4 font-medium"
                              onClick={() => handleSort('lastVisit')}
                            >
                              Última Consulta
                              <ArrowUpDown size={14} />
                            </Button>
                          </TableHead>
                          <TableHead>
                            <Button
                              variant="ghost"
                              className="flex items-center gap-1 -ml-4 font-medium"
                              onClick={() => handleSort('nextVisit')}
                            >
                              Próxima Consulta
                              <ArrowUpDown size={14} />
                            </Button>
                          </TableHead>
                          <TableHead>Condições</TableHead>
                          <TableHead className="text-right">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {getPagedPatients().map((patient) => (
                          <TableRow key={patient.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <Avatar className="h-10 w-10 mr-3">
                                  {patient.profileImage ? (
                                    <AvatarImage src={patient.profileImage} alt={patient.fullName} />
                                  ) : (
                                    <AvatarFallback className="bg-purple-100 text-purple-600">
                                      {patient.fullName.split(' ').map(name => name[0]).join('').slice(0, 2)}
                                    </AvatarFallback>
                                  )}
                                </Avatar>
                                <div>
                                  <div className="font-medium">{patient.fullName}</div>
                                  <div className="text-gray-500 text-sm">
                                    {patient.age} anos • {patient.gender}
                                  </div>
                                  {patient.status === 'inactive' && (
                                    <Badge variant="outline" className="text-yellow-600 border-yellow-600 text-xs mt-1">
                                      Inativo
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <div className="flex items-center text-sm">
                                  <Mail size={14} className="mr-2 text-gray-400" />
                                  <span>{patient.email}</span>
                                </div>
                                <div className="flex items-center text-sm mt-1">
                                  <Phone size={14} className="mr-2 text-gray-400" />
                                  <span>{patient.phone}</span>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              {patient.lastVisit ? (
                                <div className="flex items-center">
                                  <Calendar size={14} className="mr-2 text-gray-400" />
                                  {new Date(patient.lastVisit).toLocaleDateString('pt-BR')}
                                </div>
                              ) : (
                                <span className="text-gray-400">Nunca</span>
                              )}
                            </TableCell>
                            <TableCell>
                              {patient.nextVisit ? (
                                <div className="flex items-center">
                                  <Calendar size={14} className="mr-2 text-gray-400" />
                                  {new Date(patient.nextVisit).toLocaleDateString('pt-BR')}
                                </div>
                              ) : (
                                <span className="text-gray-400">Não agendada</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1 max-w-xs">
                                {patient.medicalConditions.slice(0, 2).map((condition, index) => (
                                  <Badge key={index} variant="outline" className="bg-purple-50">
                                    {condition}
                                  </Badge>
                                ))}
                                {patient.medicalConditions.length > 2 && (
                                  <Badge variant="outline" className="bg-purple-50">
                                    +{patient.medicalConditions.length - 2}
                                  </Badge>
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end items-center">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="text-purple-600 hover:text-purple-800 hover:bg-purple-50"
                                  onClick={() => handleViewPatient(patient)}
                                >
                                  <Eye size={18} />
                                </Button>
                                
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="icon">
                                      <MoreHorizontal size={18} />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem
                                      onClick={() => handleViewPatient(patient)}
                                    >
                                      <Eye size={16} className="mr-2" />
                                      Detalhes
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <Pencil size={16} className="mr-2" />
                                      Editar
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <FileText size={16} className="mr-2" />
                                      Nova Prescrição
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <Calendar size={16} className="mr-2" />
                                      Agendar Consulta
                                    </DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem className="text-red-600">
                                      <Trash2 size={16} className="mr-2" />
                                      Excluir Paciente
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </Card>

                  <CustomPagination
                    currentPage={currentPage}
                    pageCount={pageCount}
                    onPageChange={setCurrentPage}
                  />
                </>
              )}
            </div>
          </main>
        </div>

        <Dialog open={showAddPatientDialog} onOpenChange={setShowAddPatientDialog}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle className="text-xl">Adicionar Novo Paciente</DialogTitle>
              <DialogDescription>
                Preencha as informações abaixo para cadastrar um novo paciente.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-full">
                  <Label htmlFor="fullName" className="required">Nome Completo</Label>
                  <Input 
                    id="fullName" 
                    value={newPatient.fullName}
                    onChange={(e) => setNewPatient({...newPatient, fullName: e.target.value})}
                  />
                </div>
                
                <div>
                  <Label htmlFor="email" className="required">Email</Label>
                  <Input 
                    id="email" 
                    type="email"
                    value={newPatient.email}
                    onChange={(e) => setNewPatient({...newPatient, email: e.target.value})}
                  />
                </div>
                
                <div>
                  <Label htmlFor="phone">Telefone</Label>
                  <Input 
                    id="phone" 
                    value={newPatient.phone}
                    onChange={(e) => setNewPatient({...newPatient, phone: e.target.value})}
                  />
                </div>
                
                <div>
                  <Label htmlFor="dateOfBirth" className="required">Data de Nascimento</Label>
                  <Input 
                    id="dateOfBirth" 
                    type="date"
                    value={newPatient.dateOfBirth}
                    onChange={(e) => setNewPatient({...newPatient, dateOfBirth: e.target.value})}
                  />
                </div>
                
                <div>
                  <Label htmlFor="gender">Gênero</Label>
                  <Select 
                    value={newPatient.gender}
                    onValueChange={(value) => setNewPatient({...newPatient, gender: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o gênero" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="feminino">Feminino</SelectItem>
                      <SelectItem value="masculino">Masculino</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="col-span-full">
                  <Label htmlFor="address">Endereço</Label>
                  <Input 
                    id="address" 
                    value={newPatient.address}
                    onChange={(e) => setNewPatient({...newPatient, address: e.target.value})}
                  />
                </div>
                
                <div className="col-span-full">
                  <Label htmlFor="medicalConditions">Condições Médicas</Label>
                  <Input 
                    id="medicalConditions" 
                    placeholder="Separadas por vírgula (ex: Ansiedade, Insônia)"
                    value={newPatient.medicalConditions}
                    onChange={(e) => setNewPatient({...newPatient, medicalConditions: e.target.value})}
                  />
                </div>
                
                <div className="col-span-full">
                  <Label htmlFor="medications">Medicamentos Atuais</Label>
                  <Input 
                    id="medications" 
                    placeholder="Separados por vírgula (ex: Fluoxetina 20mg, CBD Oil 5%)"
                    value={newPatient.medications}
                    onChange={(e) => setNewPatient({...newPatient, medications: e.target.value})}
                  />
                </div>
                
                <div className="col-span-full">
                  <Label htmlFor="notes">Observações</Label>
                  <Textarea 
                    id="notes" 
                    rows={3}
                    value={newPatient.notes}
                    onChange={(e) => setNewPatient({...newPatient, notes: e.target.value})}
                  />
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setShowAddPatientDialog(false)}
              >
                Cancelar
              </Button>
              <Button
                onClick={handleAddPatient}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                Adicionar Paciente
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Importar Pacientes</DialogTitle>
              <DialogDescription>
                Importe pacientes a partir de um arquivo CSV ou da sua lista de contatos.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <div className="flex flex-col items-center">
                  <FileUp size={36} className="text-gray-400 mb-2" />
                  <p className="text-sm text-gray-500 mb-4">
                    Arraste e solte seu arquivo CSV aqui ou clique para escolher
                  </p>
                  <Button variant="outline" size="sm">
                    Escolher Arquivo
                  </Button>
                </div>
              </div>
              
              <Separator />
              
              <div className="flex flex-col items-center">
                <Button variant="outline" className="w-full">
                  <Upload size={16} className="mr-2" />
                  Importar de Outro Sistema
                </Button>
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setShowImportDialog(false)}
              >
                Cancelar
              </Button>
              <Button 
                disabled 
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                Importar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog 
          open={showPatientDetails} 
          onOpenChange={setShowPatientDetails}
        >
          <DialogContent className="sm:max-w-4xl max-h-[90vh]">
            {selectedPatient && (
              <ScrollArea className="max-h-[calc(90vh-80px)]">
                <DialogHeader className="flex flex-row items-center justify-between">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-14 w-14">
                      {selectedPatient.profileImage ? (
                        <AvatarImage src={selectedPatient.profileImage} alt={selectedPatient.fullName} />
                      ) : (
                        <AvatarFallback className="bg-purple-100 text-purple-600 text-lg">
                          {selectedPatient.fullName.split(' ').map(name => name[0]).join('').slice(0, 2)}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    <div>
                      <DialogTitle className="text-xl">{selectedPatient.fullName}</DialogTitle>
                      <DialogDescription>
                        {selectedPatient.age} anos • {selectedPatient.gender} • ID: {selectedPatient.id}
                      </DialogDescription>
                      {selectedPatient.status === 'inactive' && (
                        <Badge variant="outline" className="text-yellow-600 border-yellow-600 text-xs mt-1">
                          Inativo
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="text-purple-600 border-purple-200 hover:bg-purple-50 hover:text-purple-700"
                    >
                      <FileText size={16} className="mr-2" />
                      Nova Prescrição
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="text-purple-600 border-purple-200 hover:bg-purple-50 hover:text-purple-700"
                    >
                      <Calendar size={16} className="mr-2" />
                      Agendar
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setShowPatientDetails(false)}
                    >
                      <X size={16} />
                    </Button>
                  </div>
                </DialogHeader>
                
                <div className="mt-6">
                  <Tabs defaultValue="info">
                    <TabsList className="mb-4 bg-purple-50">
                      <TabsTrigger value="info">Informações</TabsTrigger>
                      <TabsTrigger value="consultations">Consultas</TabsTrigger>
                      <TabsTrigger value="prescriptions">Prescrições</TabsTrigger>
                      <TabsTrigger value="files">Documentos</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="info" className="m-0 p-1">
                      <div className="space-y-4">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Informações de Contato</CardTitle>
                          </CardHeader>
                          <CardContent className="grid md:grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm text-gray-500">Email</p>
                              <p>{selectedPatient.email}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Telefone</p>
                              <p>{selectedPatient.phone}</p>
                            </div>
                            <div className="md:col-span-2">
                              <p className="text-sm text-gray-500">Endereço</p>
                              <p>{selectedPatient.address}</p>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Condições Médicas</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="flex flex-wrap gap-2">
                              {selectedPatient.medicalConditions.length > 0 ? (
                                selectedPatient.medicalConditions.map((condition, i) => (
                                  <Badge key={i} className="bg-purple-100 text-purple-800">
                                    {condition}
                                  </Badge>
                                ))
                              ) : (
                                <span className="text-gray-500 text-sm">Nenhuma condição registrada</span>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Medicamentos Atuais</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="flex flex-wrap gap-2">
                              {selectedPatient.medications.length > 0 ? (
                                selectedPatient.medications.map((medication, i) => (
                                  <Badge key={i} variant="outline" className="bg-green-50 text-green-800 border-green-200">
                                    {medication}
                                  </Badge>
                                ))
                              ) : (
                                <span className="text-gray-500 text-sm">Nenhum medicamento registrado</span>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Observações</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-gray-700">{selectedPatient.notes || "Nenhuma observação registrada."}</p>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Histórico de Visitas</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              <div className="flex justify-between items-center">
                                <p className="text-sm font-medium">Última consulta</p>
                                <p>{selectedPatient.lastVisit ? new Date(selectedPatient.lastVisit).toLocaleDateString('pt-BR') : "Nunca"}</p>
                              </div>
                              <div className="flex justify-between items-center">
                                <p className="text-sm font-medium">Próxima consulta</p>
                                <p>{selectedPatient.nextVisit ? new Date(selectedPatient.nextVisit).toLocaleDateString('pt-BR') : "Não agendada"}</p>
                              </div>
                              <div className="flex justify-between items-center">
                                <p className="text-sm font-medium">Total de consultas</p>
                                <p>{selectedPatient.consultations ? selectedPatient.consultations.length : 0}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="consultations" className="m-0 p-1">
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between pb-2">
                          <CardTitle className="text-base">Histórico de Consultas</CardTitle>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="text-purple-600 border-purple-200 hover:bg-purple-50"
                          >
                            <Plus size={16} className="mr-1" />
                            Nova Consulta
                          </Button>
                        </CardHeader>
                        <CardContent>
                          {selectedPatient.consultations && selectedPatient.consultations.length > 0 ? (
                            <div className="space-y-4">
                              {selectedPatient.consultations.map((consultation, index) => (
                                <div key={consultation.id} className="border rounded-lg p-4">
                                  <div className="flex justify-between items-start mb-2">
                                    <div>
                                      <h4 className="font-medium">{consultation.type}</h4>
                                      <p className="text-sm text-gray-500">
                                        {new Date(consultation.date).toLocaleDateString('pt-BR')}
                                      </p>
                                    </div>
                                    <Button variant="ghost" size="icon">
                                      <MoreHorizontal size={16} />
                                    </Button>
                                  </div>
                                  <p className="text-sm mt-2">{consultation.notes}</p>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="text-center py-8">
                              <ClipboardList size={36} className="mx-auto text-gray-300 mb-2" />
                              <p className="text-gray-500">Nenhuma consulta registrada</p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </TabsContent>
                    
                    <TabsContent value="prescriptions" className="m-0 p-1">
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between pb-2">
                          <CardTitle className="text-base">Prescrições</CardTitle>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="text-purple-600 border-purple-200 hover:bg-purple-50"
                          >
                            <Plus size={16} className="mr-1" />
                            Nova Prescrição
                          </Button>
                        </CardHeader>
                        <CardContent>
                          {selectedPatient.prescriptions && selectedPatient.prescriptions.length > 0 ? (
                            <div className="space-y-4">
                              {selectedPatient.prescriptions.map((prescription) => (
                                <div key={prescription.id} className="border rounded-lg p-4">
                                  <div className="flex justify-between items-start mb-2">
                                    <div>
                                      <div className="flex items-center">
                                        <FileText size={16} className="mr-2 text-gray-400" />
                                        <h4 className="font-medium">Prescrição #{prescription.id}</h4>
                                      </div>
                                      <p className="text-sm text-gray-500 mt-1">
                                        {new Date(prescription.date).toLocaleDateString('pt-BR')}
                                      </p>
                                    </div>
                                    <Badge 
                                      className={
                                        prescription.status === 'active' 
                                          ? 'bg-green-100 text-green-800' 
                                          : prescription.status === 'expiring'
                                            ? 'bg-yellow-100 text-yellow-800'
                                            : 'bg-red-100 text-red-800'
                                      }
                                    >
                                      {prescription.status === 'active' 
                                        ? 'Ativa' 
                                        : prescription.status === 'expiring'
                                          ? 'Expirando'
                                          : 'Expirada'}
                                    </Badge>
                                  </div>
                                  <div className="flex flex-wrap gap-2 mt-3">
                                    {prescription.products.map((product, i) => (
                                      <Badge key={i} variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">
                                        {product}
                                      </Badge>
                                    ))}
                                  </div>
                                  <div className="flex justify-end mt-3 gap-2">
                                    <Button variant="ghost" size="sm">
                                      <Eye size={14} className="mr-1" />
                                      Ver
                                    </Button>
                                    <Button variant="ghost" size="sm">
                                      <Download size={14} className="mr-1" />
                                      Baixar
                                    </Button>
                                    <Button variant="ghost" size="sm">
                                      <ClipboardCheck size={14} className="mr-1" />
                                      Renovar
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="text-center py-8">
                              <FileText size={36} className="mx-auto text-gray-300 mb-2" />
                              <p className="text-gray-500">Nenhuma prescrição registrada</p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </TabsContent>
                    
                    <TabsContent value="files" className="m-0 p-1">
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between pb-2">
                          <CardTitle className="text-base">Documentos</CardTitle>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="text-purple-600 border-purple-200 hover:bg-purple-50"
                          >
                            <Plus size={16} className="mr-1" />
                            Adicionar Documento
                          </Button>
                        </CardHeader>
                        <CardContent>
                          {selectedPatient.files && selectedPatient.files.length > 0 ? (
                            <div className="space-y-2">
                              {selectedPatient.files.map((file) => (
                                <div key={file.id} className="flex items-center justify-between border-b pb-2 mb-2">
                                  <div className="flex items-center">
                                    <FileText size={16} className="mr-3 text-gray-400" />
                                    <div>
                                      <p className="font-medium">{file.name}</p>
                                      <div className="flex items-center text-sm text-gray-500">
                                        <Badge variant="outline" className="text-xs mr-2">
                                          {file.type}
                                        </Badge>
                                        {new Date(file.date).toLocaleDateString('pt-BR')}
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex gap-1">
                                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                      <Eye size={16} />
                                    </Button>
                                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                      <Download size={16} />
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="text-center py-8">
                              <FileText size={36} className="mx-auto text-gray-300 mb-2" />
                              <p className="text-gray-500">Nenhum documento adicionado</p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </TabsContent>
                  </Tabs>
                </div>
              </ScrollArea>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DoctorLayout>
  );
}
