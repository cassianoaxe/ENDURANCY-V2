import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { toast } from "@/components/ui/use-toast";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import {
  DollarSign,
  CheckCircle2,
  XCircle,
  ArrowUp,
  ArrowDown,
  ShoppingBag,
  Wallet,
  CreditCard,
  Clock,
  Calendar,
  FileText,
  Printer,
  AlertTriangle,
  RefreshCw,
  ChevronRight,
  ArrowUpCircle,
  ArrowDownCircle,
  ShoppingCart,
  MoreHorizontal,
  LogOut,
  LogIn,
  Plus,
  Minus
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function DispensarioCaixa() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [caixas, setCaixas] = useState([]);
  const [caixaAtual, setCaixaAtual] = useState(null);
  const [showAbrirCaixa, setShowAbrirCaixa] = useState(false);
  const [showFecharCaixa, setShowFecharCaixa] = useState(false);
  const [showMovimentacao, setShowMovimentacao] = useState(false);
  const [tipoMovimentacao, setTipoMovimentacao] = useState(null);
  const [vendas, setVendas] = useState([]);
  const [valorAbertura, setValorAbertura] = useState('');
  const [valorMovimentacao, setValorMovimentacao] = useState('');
  const [motivoMovimentacao, setMotivoMovimentacao] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [resumoCaixa, setResumoCaixa] = useState({
    total_vendas: 0,
    total_dinheiro: 0,
    total_cartao_credito: 0,
    total_cartao_debito: 0,
    total_pix: 0,
    total_sangrias: 0,
    total_suprimentos: 0,
    saldo_atual: 0
  });
  const [showConfirmFecharCaixa, setShowConfirmFecharCaixa] = useState(false);

  useEffect(() => {
    const loadData = () => {
      try {
        // Simple auth check using localStorage directly
        const userType = localStorage.getItem('mockUserType');
        if (!userType) {
          console.log("User not authenticated, redirecting to login");
          navigate(createPageUrl("Access"));
          return;
        }

        setIsLoading(false);
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar os dados do caixa.",
          variant: "destructive",
        });
      }
    };

    loadData();
  }, [navigate]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        
        // Simulated mock data for demonstration
        const mockCaixas = [
          {
            id: "caixa-001",
            numero_caixa: "CAIXA-001",
            status: "fechado",
            operador_id: "mock-user-1",
            saldo_inicial: 0,
            saldo_final: 0,
            resumo: {
              total_vendas: 0,
              total_dinheiro: 0,
              total_cartao_credito: 0,
              total_cartao_debito: 0,
              total_pix: 0,
              total_sangrias: 0,
              total_suprimentos: 0
            },
            movimentacoes: []
          }
        ];
        
        setCaixas(mockCaixas);
        
        const caixaAberto = mockCaixas.find(c => c.status === 'aberto');
        if (caixaAberto) {
          setCaixaAtual(caixaAberto);
          await carregarResumo(caixaAberto);
          await carregarVendas(caixaAberto.id);
        }
        
      } catch (error) {
        console.error("Erro ao carregar caixas:", error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar os dados do caixa.",
          variant: "destructive",
        });
        
        simulateCaixaData();
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  const simulateCaixaData = () => {
    const caixaDemo = {
      id: "demo-caixa-001",
      numero_caixa: "CAIXA-001",
      status: "fechado",
      operador_id: "demo-user",
      saldo_inicial: 0,
      saldo_final: 0,
      movimentacoes: [],
      resumo: {
        total_vendas: 0,
        total_dinheiro: 0,
        total_cartao_credito: 0,
        total_cartao_debito: 0,
        total_pix: 0,
        total_sangrias: 0,
        total_suprimentos: 0
      }
    };
    
    setCaixas([caixaDemo]);
  };
  
  const carregarResumo = async (caixa) => {
    try {
      const resumo = caixa.resumo || {
        total_vendas: 0,
        total_dinheiro: 0,
        total_cartao_credito: 0,
        total_cartao_debito: 0,
        total_pix: 0,
        total_sangrias: 0,
        total_suprimentos: 0
      };
      
      const saldoAtual = (caixa.saldo_inicial || 0) + 
        resumo.total_dinheiro - 
        resumo.total_sangrias + 
        resumo.total_suprimentos;
      
      setResumoCaixa({
        ...resumo,
        saldo_atual: saldoAtual
      });
      
    } catch (error) {
      console.error("Erro ao carregar resumo:", error);
    }
  };
  
  const carregarVendas = async (caixaId) => {
    try {
      // Simulate mock sales data
      const vendasSimuladas = [
        {
          id: "venda-001",
          numero_venda: "V-0001",
          data_venda: new Date().toISOString(),
          cliente: { nome: "Cliente 1" },
          total: 125.90,
          status: "finalizada",
          pagamento: { forma: "dinheiro", valor_pago: 150, troco: 24.10 }
        },
        {
          id: "venda-002",
          numero_venda: "V-0002",
          data_venda: new Date().toISOString(),
          cliente: { nome: "Cliente 2" },
          total: 87.50,
          status: "finalizada",
          pagamento: { forma: "cartao_credito", valor_pago: 87.50, troco: 0 }
        }
      ];
      
      setVendas(vendasSimuladas);
    } catch (error) {
      console.error("Erro ao carregar vendas:", error);
    }
  };
  
  const handleAbrirCaixa = async () => {
    try {
      setIsProcessing(true);
      
      if (!valorAbertura || isNaN(parseFloat(valorAbertura)) || parseFloat(valorAbertura) < 0) {
        toast({
          title: "Valor inválido",
          description: "Por favor, informe um valor válido para abertura do caixa.",
          variant: "destructive",
        });
        return;
      }
      
      const saldoInicial = parseFloat(valorAbertura);
      
      const caixaParaAbrir = caixas.find(c => c.status === 'fechado');
      
      if (!caixaParaAbrir) {
        toast({
          title: "Erro",
          description: "Nenhum caixa disponível para abertura.",
          variant: "destructive",
        });
        return;
      }
      
      // Simulate opening a cash register with mock data
      const mockUserId = "mock-user-1";
      
      const caixaAtualizado = {
        ...caixaParaAbrir,
        status: 'aberto',
        operador_id: mockUserId,
        data_abertura: new Date().toISOString(),
        saldo_inicial: saldoInicial,
        movimentacoes: [],
        resumo: {
          total_vendas: 0,
          total_dinheiro: 0,
          total_cartao_credito: 0,
          total_cartao_debito: 0,
          total_pix: 0,
          total_sangrias: 0,
          total_suprimentos: 0
        }
      };
      
      setCaixaAtual(caixaAtualizado);
      setResumoCaixa({
        ...caixaAtualizado.resumo,
        saldo_atual: saldoInicial
      });
      
      const caixasAtualizados = caixas.map(c => 
        c.id === caixaParaAbrir.id ? caixaAtualizado : c
      );
      setCaixas(caixasAtualizados);
      
      toast({
        title: "Caixa aberto",
        description: `Caixa aberto com saldo inicial de R$ ${saldoInicial.toFixed(2)}.`,
      });
      
      setShowAbrirCaixa(false);
      setValorAbertura('');
      
    } catch (error) {
      console.error("Erro ao abrir caixa:", error);
      toast({
        title: "Erro",
        description: "Não foi possível abrir o caixa.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleFecharCaixa = async () => {
    try {
      setIsProcessing(true);
      
      if (!caixaAtual) {
        toast({
          title: "Erro",
          description: "Nenhum caixa aberto para fechamento.",
          variant: "destructive",
        });
        return;
      }
      
      const caixaAtualizado = {
        ...caixaAtual,
        status: 'fechado',
        data_fechamento: new Date().toISOString(),
        saldo_final: resumoCaixa.saldo_atual
      };
      
      const caixasAtualizados = caixas.map(c => 
        c.id === caixaAtual.id ? caixaAtualizado : c
      );
      setCaixas(caixasAtualizados);
      
      setCaixaAtual(null);
      setVendas([]);
      
      toast({
        title: "Caixa fechado",
        description: `Caixa fechado com saldo final de R$ ${resumoCaixa.saldo_atual.toFixed(2)}.`,
      });
      
      setShowConfirmFecharCaixa(false);
      
    } catch (error) {
      console.error("Erro ao fechar caixa:", error);
      toast({
        title: "Erro",
        description: "Não foi possível fechar o caixa.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleMovimentacaoCaixa = async () => {
    try {
      setIsProcessing(true);
      
      if (!valorMovimentacao || isNaN(parseFloat(valorMovimentacao)) || parseFloat(valorMovimentacao) <= 0) {
        toast({
          title: "Valor inválido",
          description: "Por favor, informe um valor válido para a movimentação.",
          variant: "destructive",
        });
        return;
      }
      
      if (!motivoMovimentacao) {
        toast({
          title: "Motivo obrigatório",
          description: "Por favor, informe o motivo da movimentação.",
          variant: "destructive",
        });
        return;
      }
      
      if (!caixaAtual) {
        toast({
          title: "Erro",
          description: "Nenhum caixa aberto para realizar movimentação.",
          variant: "destructive",
        });
        return;
      }
      
      const valor = parseFloat(valorMovimentacao);
      
      const novaMovimentacao = {
        tipo: tipoMovimentacao,
        valor,
        forma_pagamento: 'dinheiro',
        data: new Date().toISOString(),
        observacao: motivoMovimentacao
      };
      
      const movimentacoesAtualizadas = [...(caixaAtual.movimentacoes || []), novaMovimentacao];
      
      const resumoAtualizado = { ...caixaAtual.resumo };
      if (tipoMovimentacao === 'sangria') {
        resumoAtualizado.total_sangrias = (resumoAtualizado.total_sangrias || 0) + valor;
      } else if (tipoMovimentacao === 'suprimento') {
        resumoAtualizado.total_suprimentos = (resumoAtualizado.total_suprimentos || 0) + valor;
      }
      
      const novoSaldo = tipoMovimentacao === 'sangria'
        ? resumoCaixa.saldo_atual - valor
        : resumoCaixa.saldo_atual + valor;
      
      const caixaAtualizado = {
        ...caixaAtual,
        movimentacoes: movimentacoesAtualizadas,
        resumo: resumoAtualizado
      };
      
      setCaixaAtual(caixaAtualizado);
      setResumoCaixa({
        ...resumoAtualizado,
        saldo_atual: novoSaldo
      });
      
      const caixasAtualizados = caixas.map(c => 
        c.id === caixaAtual.id ? caixaAtualizado : c
      );
      setCaixas(caixasAtualizados);
      
      toast({
        title: tipoMovimentacao === 'sangria' ? "Sangria realizada" : "Suprimento realizado",
        description: `${tipoMovimentacao === 'sangria' ? 'Sangria' : 'Suprimento'} de R$ ${valor.toFixed(2)} realizado com sucesso.`,
      });
      
      setShowMovimentacao(false);
      setValorMovimentacao('');
      setMotivoMovimentacao('');
      
    } catch (error) {
      console.error("Erro ao realizar movimentação:", error);
      toast({
        title: "Erro",
        description: "Não foi possível realizar a movimentação.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const formatMoney = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Caixa do Dispensário</h1>
          <p className="text-gray-500">Gerenciamento de operações de caixa</p>
        </div>
        
        <div className="flex space-x-2">
          {caixaAtual ? (
            <>
              <Button
                variant="outline"
                onClick={() => {
                  setTipoMovimentacao('sangria');
                  setShowMovimentacao(true);
                }}
                className="flex items-center gap-2"
              >
                <ArrowUp className="h-4 w-4" />
                Sangria
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setTipoMovimentacao('suprimento');
                  setShowMovimentacao(true);
                }}
                className="flex items-center gap-2"
              >
                <ArrowDown className="h-4 w-4" />
                Suprimento
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowConfirmFecharCaixa(true)}
                className="flex items-center gap-2"
              >
                <LogOut className="h-4 w-4" />
                Fechar Caixa
              </Button>
              <Button
                onClick={() => navigate(createPageUrl("PDV"))}
                className="bg-green-600 hover:bg-green-700"
              >
                <ShoppingBag className="mr-2 h-4 w-4" />
                Abrir PDV
              </Button>
            </>
          ) : (
            <Button onClick={() => setShowAbrirCaixa(true)}>
              <LogIn className="mr-2 h-4 w-4" />
              Abrir Caixa
            </Button>
          )}
        </div>
      </div>

      {caixaAtual ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-green-50 border-green-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-green-800">Saldo Atual em Caixa</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-700">{formatMoney(resumoCaixa.saldo_atual)}</div>
                <p className="text-xs text-green-600">
                  Saldo Inicial: {formatMoney(caixaAtual.saldo_inicial || 0)}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total em Vendas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatMoney(resumoCaixa.total_vendas || 0)}</div>
                <p className="text-xs text-gray-500">
                  {vendas.length} vendas no caixa atual
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Dinheiro</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatMoney(resumoCaixa.total_dinheiro || 0)}</div>
                <div className="flex justify-between text-xs text-gray-500">
                  <span>Sangrias: {formatMoney(resumoCaixa.total_sangrias || 0)}</span>
                  <span>Suprimentos: {formatMoney(resumoCaixa.total_suprimentos || 0)}</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Outros Meios</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Cartão de Crédito:</span>
                    <span className="font-medium">{formatMoney(resumoCaixa.total_cartao_credito || 0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Cartão de Débito:</span>
                    <span className="font-medium">{formatMoney(resumoCaixa.total_cartao_debito || 0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">PIX:</span>
                    <span className="font-medium">{formatMoney(resumoCaixa.total_pix || 0)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="vendas" className="space-y-4">
            <TabsList>
              <TabsTrigger value="vendas" className="flex items-center gap-2">
                <ShoppingCart className="h-4 w-4" />
                Vendas do Caixa
              </TabsTrigger>
              <TabsTrigger value="movimentacoes" className="flex items-center gap-2">
                <ArrowUpCircle className="h-4 w-4" />
                Sangrias e Suprimentos
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="vendas">
              <Card>
                <CardHeader>
                  <CardTitle>Vendas no Caixa Atual</CardTitle>
                  <CardDescription>
                    Vendas realizadas desde a abertura do caixa
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Código</TableHead>
                          <TableHead>Data/Hora</TableHead>
                          <TableHead>Cliente</TableHead>
                          <TableHead>Valor</TableHead>
                          <TableHead>Forma Pagamento</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoading ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-8">
                              <RefreshCw className="h-6 w-6 animate-spin mx-auto text-gray-400" />
                            </TableCell>
                          </TableRow>
                        ) : vendas.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-8">
                              <div className="flex flex-col items-center gap-2">
                                <ShoppingCart className="h-8 w-8 text-gray-400" />
                                <p className="text-gray-500">Nenhuma venda realizada neste caixa</p>
                                <Button
                                  onClick={() => navigate(createPageUrl("PDV"))}
                                  className="mt-2"
                                >
                                  <ShoppingBag className="mr-2 h-4 w-4" />
                                  Abrir PDV
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ) : (
                          vendas.map((venda) => (
                            <TableRow key={venda.id}>
                              <TableCell>{venda.numero_venda}</TableCell>
                              <TableCell>
                                {format(new Date(venda.data_venda), 'dd/MM/yyyy HH:mm')}
                              </TableCell>
                              <TableCell>
                                {venda.cliente?.nome || 'Cliente não identificado'}
                              </TableCell>
                              <TableCell className="font-medium">
                                {formatMoney(venda.total)}
                              </TableCell>
                              <TableCell>
                                {venda.pagamento?.forma === 'dinheiro' && (
                                  <Badge className="bg-green-100 text-green-800">Dinheiro</Badge>
                                )}
                                {venda.pagamento?.forma === 'cartao_credito' && (
                                  <Badge className="bg-blue-100 text-blue-800">Cartão de Crédito</Badge>
                                )}
                                {venda.pagamento?.forma === 'cartao_debito' && (
                                  <Badge className="bg-purple-100 text-purple-800">Cartão de Débito</Badge>
                                )}
                                {venda.pagamento?.forma === 'pix' && (
                                  <Badge className="bg-indigo-100 text-indigo-800">PIX</Badge>
                                )}
                              </TableCell>
                              <TableCell>
                                {venda.status === 'finalizada' && (
                                  <Badge className="bg-green-100 text-green-800">Finalizada</Badge>
                                )}
                                {venda.status === 'cancelada' && (
                                  <Badge className="bg-red-100 text-red-800">Cancelada</Badge>
                                )}
                                {venda.status === 'em_andamento' && (
                                  <Badge className="bg-yellow-100 text-yellow-800">Em Andamento</Badge>
                                )}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="movimentacoes">
              <Card>
                <CardHeader>
                  <CardTitle>Sangrias e Suprimentos</CardTitle>
                  <CardDescription>
                    Movimentações de entrada e saída de dinheiro do caixa
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Data/Hora</TableHead>
                          <TableHead>Tipo</TableHead>
                          <TableHead>Valor</TableHead>
                          <TableHead>Motivo</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoading ? (
                          <TableRow>
                            <TableCell colSpan={4} className="text-center py-8">
                              <RefreshCw className="h-6 w-6 animate-spin mx-auto text-gray-400" />
                            </TableCell>
                          </TableRow>
                        ) : !caixaAtual.movimentacoes || caixaAtual.movimentacoes.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={4} className="text-center py-8">
                              <div className="flex flex-col items-center gap-2">
                                <ArrowUpCircle className="h-8 w-8 text-gray-400" />
                                <p className="text-gray-500">Nenhuma movimentação registrada</p>
                                <div className="flex gap-2 mt-2">
                                  <Button
                                    variant="outline"
                                    onClick={() => {
                                      setTipoMovimentacao('sangria');
                                      setShowMovimentacao(true);
                                    }}
                                  >
                                    <ArrowUp className="mr-2 h-4 w-4" />
                                    Sangria
                                  </Button>
                                  <Button
                                    onClick={() => {
                                      setTipoMovimentacao('suprimento');
                                      setShowMovimentacao(true);
                                    }}
                                  >
                                    <ArrowDown className="mr-2 h-4 w-4" />
                                    Suprimento
                                  </Button>
                                </div>
                              </div>
                            </TableCell>
                          </TableRow>
                        ) : (
                          caixaAtual.movimentacoes
                            .filter(m => m.tipo === 'sangria' || m.tipo === 'suprimento')
                            .map((mov, index) => (
                              <TableRow key={index}>
                                <TableCell>
                                  {format(new Date(mov.data), 'dd/MM/yyyy HH:mm')}
                                </TableCell>
                                <TableCell>
                                  {mov.tipo === 'sangria' ? (
                                    <Badge className="bg-red-100 text-red-800 flex items-center gap-1">
                                      <ArrowUp className="h-3 w-3" />
                                      Sangria
                                    </Badge>
                                  ) : (
                                    <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
                                      <ArrowDown className="h-3 w-3" />
                                      Suprimento
                                    </Badge>
                                  )}
                                </TableCell>
                                <TableCell className="font-medium">
                                  {formatMoney(mov.valor)}
                                </TableCell>
                                <TableCell>
                                  {mov.observacao}
                                </TableCell>
                              </TableRow>
                            ))
                        )}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="bg-gray-100 p-6 rounded-full mb-4">
              <Wallet className="h-12 w-12 text-gray-500" />
            </div>
            <h2 className="text-xl font-medium mb-2">Nenhum caixa aberto</h2>
            <p className="text-gray-500 text-center mb-6 max-w-md">
              Para iniciar as operações de venda é necessário abrir um caixa primeiro.
            </p>
            <Button onClick={() => setShowAbrirCaixa(true)}>
              <LogIn className="mr-2 h-4 w-4" />
              Abrir Caixa
            </Button>
          </CardContent>
        </Card>
      )}

      <Dialog open={showAbrirCaixa} onOpenChange={setShowAbrirCaixa}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Abrir Caixa</DialogTitle>
            <DialogDescription>
              Informe o valor inicial do caixa para iniciar as operações.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="valor-abertura">Valor Inicial (R$)</Label>
              <Input 
                id="valor-abertura" 
                type="number" 
                step="0.01"
                min="0"
                value={valorAbertura} 
                onChange={(e) => setValorAbertura(e.target.value)}
                placeholder="0,00"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAbrirCaixa(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAbrirCaixa} disabled={isProcessing}>
              {isProcessing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Abrindo...
                </>
              ) : (
                <>
                  <LogIn className="mr-2 h-4 w-4" />
                  Abrir Caixa
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showMovimentacao} onOpenChange={setShowMovimentacao}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {tipoMovimentacao === 'sangria' ? 'Realizar Sangria' : 'Realizar Suprimento'}
            </DialogTitle>
            <DialogDescription>
              {tipoMovimentacao === 'sangria' 
                ? 'Retire dinheiro do caixa (sangria).' 
                : 'Adicione dinheiro ao caixa (suprimento).'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="valor-movimentacao">Valor (R$)</Label>
              <Input 
                id="valor-movimentacao" 
                type="number" 
                step="0.01"
                min="0.01"
                value={valorMovimentacao} 
                onChange={(e) => setValorMovimentacao(e.target.value)}
                placeholder="0,00"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="motivo">Motivo</Label>
              <Input 
                id="motivo" 
                value={motivoMovimentacao} 
                onChange={(e) => setMotivoMovimentacao(e.target.value)}
                placeholder="Informe o motivo"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMovimentacao(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleMovimentacaoCaixa} 
              disabled={isProcessing}
              className={tipoMovimentacao === 'sangria' ? 'bg-red-600 hover:bg-red-700' : ''}
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Processando...
                </>
              ) : tipoMovimentacao === 'sangria' ? (
                <>
                  <ArrowUp className="mr-2 h-4 w-4" />
                  Confirmar Sangria
                </>
              ) : (
                <>
                  <ArrowDown className="mr-2 h-4 w-4" />
                  Confirmar Suprimento
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showConfirmFecharCaixa} onOpenChange={setShowConfirmFecharCaixa}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Fechar Caixa</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja fechar o caixa? Esta ação não pode ser desfeita.
              <div className="mt-4 p-4 bg-gray-50 rounded-md border">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">Saldo Inicial:</span>
                    <span>{formatMoney(caixaAtual?.saldo_inicial || 0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Vendas em Dinheiro:</span>
                    <span>{formatMoney(resumoCaixa.total_dinheiro || 0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Sangrias:</span>
                    <span className="text-red-600">- {formatMoney(resumoCaixa.total_sangrias || 0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Suprimentos:</span>
                    <span className="text-green-600">+ {formatMoney(resumoCaixa.total_suprimentos || 0)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg font-semibold">
                    <span>Saldo Final:</span>
                    <span>{formatMoney(resumoCaixa.saldo_atual || 0)}</span>
                  </div>
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleFecharCaixa}
              disabled={isProcessing}
              className="bg-red-600 hover:bg-red-700"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Fechando...
                </>
              ) : (
                <>
                  <LogOut className="mr-2 h-4 w-4" />
                  Confirmar Fechamento
                </>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}