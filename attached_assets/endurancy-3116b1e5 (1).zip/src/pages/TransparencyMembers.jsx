import React, { useState, useEffect } from 'react';
import { 
  Users, 
  UserPlus, 
  Search, 
  Download, 
  Filter, 
  ChevronDown, 
  Mail,
  Building2,
  CheckCircle2,
  XCircle,
  UserCheck,
  MoreHorizontal,
  UserX,
  Eye,
  FileText,
  Pencil
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// Exemplo de membros
const sampleMembers = [
  {
    id: "mem1",
    name: "Maria Oliveira",
    email: "m******@email.com",
    membership_type: "board",
    board_position: "Presidente",
    join_date: "2018-05-23",
    status: "active",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    has_voting_rights: true,
    public_profile: true
  },
  {
    id: "mem2",
    name: "Carlos Santos",
    email: "c******@email.com",
    membership_type: "board",
    board_position: "Vice-Presidente",
    join_date: "2018-07-15",
    status: "active",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    has_voting_rights: true,
    public_profile: true
  },
  {
    id: "mem3",
    name: "Enzo Rodrigues",
    email: "e******@email.com",
    membership_type: "board",
    board_position: "Diretor Financeiro",
    join_date: "2019-01-10",
    status: "active",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    has_voting_rights: true,
    public_profile: true
  },
  {
    id: "mem4",
    name: "Ana Beatriz Lima",
    email: "a******@email.com",
    membership_type: "board",
    board_position: "Diretora Científica",
    join_date: "2019-03-22",
    status: "active",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    has_voting_rights: true,
    public_profile: true
  },
  {
    id: "mem5",
    name: "Fernando Alves",
    email: "f******@email.com",
    membership_type: "effective",
    board_position: null,
    join_date: "2020-05-15",
    status: "active",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    has_voting_rights: true,
    public_profile: true
  },
  {
    id: "mem6",
    name: "Luciana Mendes",
    email: "l******@email.com",
    membership_type: "effective",
    board_position: null,
    join_date: "2020-06-20",
    status: "active",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    has_voting_rights: true,
    public_profile: false
  },
  {
    id: "mem7",
    name: "Roberto Silva",
    email: "r******@email.com",
    membership_type: "contributor",
    board_position: null,
    join_date: "2021-02-10",
    status: "active",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    has_voting_rights: false,
    public_profile: true
  },
  {
    id: "mem8",
    name: "Carolina Souza",
    email: "c******@email.com",
    membership_type: "effective",
    board_position: null,
    join_date: "2021-07-05",
    status: "inactive",
    organization_id: "org2",
    organization_name: "Associação Médica Verde",
    has_voting_rights: false,
    public_profile: false
  }
];

export default function TransparencyMembers() {
  const [members, setMembers] = useState([]);
  const [filteredMembers, setFilteredMembers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [organizationFilter, setOrganizationFilter] = useState("");

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setMembers(sampleMembers);
      setFilteredMembers(sampleMembers);
      setIsLoading(false);
    }, 800);
  }, []);

  useEffect(() => {
    let filtered = members;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(member => 
        member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (member.board_position && member.board_position.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Apply membership type filter
    if (typeFilter) {
      filtered = filtered.filter(member => member.membership_type === typeFilter);
    }

    // Apply status filter
    if (statusFilter) {
      filtered = filtered.filter(member => member.status === statusFilter);
    }

    // Apply organization filter
    if (organizationFilter) {
      filtered = filtered.filter(member => member.organization_id === organizationFilter);
    }

    setFilteredMembers(filtered);
  }, [searchTerm, typeFilter, statusFilter, organizationFilter, members]);

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), 'dd MMM yyyy', { locale: ptBR });
    } catch {
      return dateString;
    }
  };

  const getMembershipTypeLabel = (type) => {
    const types = {
      founder: { label: "Fundador", color: "bg-purple-100 text-purple-800" },
      effective: { label: "Efetivo", color: "bg-blue-100 text-blue-800" },
      contributor: { label: "Contribuinte", color: "bg-green-100 text-green-800" },
      honorary: { label: "Honorário", color: "bg-amber-100 text-amber-800" },
      board: { label: "Diretoria", color: "bg-red-100 text-red-800" }
    };
    
    return types[type] || { label: type, color: "bg-gray-100 text-gray-800" };
  };

  const getStatusLabel = (status) => {
    const statuses = {
      active: { label: "Ativo", color: "bg-green-100 text-green-800" },
      inactive: { label: "Inativo", color: "bg-gray-100 text-gray-800" },
      suspended: { label: "Suspenso", color: "bg-red-100 text-red-800" },
      pending: { label: "Pendente", color: "bg-yellow-100 text-yellow-800" }
    };
    
    return statuses[status] || { label: status, color: "bg-gray-100 text-gray-800" };
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Membros e Governança</h1>
          <p className="text-gray-500 mt-1">
            Gerencie membros e estrutura de governança para transparência
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button className="gap-2">
            <UserPlus className="w-4 h-4" />
            Adicionar Membro
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Exportar Lista
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar membros..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex flex-wrap gap-2 w-full md:w-auto justify-end">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-full md:w-36">
              <SelectValue placeholder="Tipo de Membro" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Todos os tipos</SelectItem>
              <SelectItem value="founder">Fundador</SelectItem>
              <SelectItem value="effective">Efetivo</SelectItem>
              <SelectItem value="contributor">Contribuinte</SelectItem>
              <SelectItem value="honorary">Honorário</SelectItem>
              <SelectItem value="board">Diretoria</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-36">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Todos</SelectItem>
              <SelectItem value="active">Ativos</SelectItem>
              <SelectItem value="inactive">Inativos</SelectItem>
              <SelectItem value="suspended">Suspensos</SelectItem>
              <SelectItem value="pending">Pendentes</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={organizationFilter} onValueChange={setOrganizationFilter}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Organização" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Todas as organizações</SelectItem>
              <SelectItem value="org2">Associação Médica Verde</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Membros Cadastrados</CardTitle>
          <CardDescription>
            {filteredMembers.length} membros encontrados
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-16 bg-gray-100 rounded-md"></div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Membro</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Cargo/Função</TableHead>
                    <TableHead>Data de Ingresso</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Visibilidade</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMembers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                        Nenhum membro encontrado com os filtros selecionados
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredMembers.map(member => (
                      <TableRow key={member.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarFallback>
                                {member.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{member.name}</div>
                              <div className="text-sm text-gray-500 flex items-center gap-1">
                                <Mail className="w-3 h-3" />
                                {member.email}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getMembershipTypeLabel(member.membership_type).color}>
                            {getMembershipTypeLabel(member.membership_type).label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {member.board_position || "-"}
                        </TableCell>
                        <TableCell>
                          {formatDate(member.join_date)}
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusLabel(member.status).color}>
                            {getStatusLabel(member.status).label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {member.public_profile ? 
                            <Badge variant="outline" className="bg-green-100 text-green-800 border-0">
                              <Eye className="w-3 h-3 mr-1" />
                              Público
                            </Badge> : 
                            <Badge variant="outline" className="text-gray-500">
                              Privado
                            </Badge>
                          }
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem className="cursor-pointer">
                                <Eye className="w-4 h-4 mr-2" />
                                Visualizar Perfil
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <Pencil className="w-4 h-4 mr-2" />
                                Editar Membro
                              </DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer">
                                <FileText className="w-4 h-4 mr-2" />
                                Documentos
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {member.status === "active" ? (
                                <DropdownMenuItem className="cursor-pointer text-amber-600">
                                  <UserX className="w-4 h-4 mr-2" />
                                  Desativar
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem className="cursor-pointer text-green-600">
                                  <UserCheck className="w-4 h-4 mr-2" />
                                  Ativar
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}