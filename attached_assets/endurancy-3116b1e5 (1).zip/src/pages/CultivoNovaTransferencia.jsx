import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ArrowLeftRight, 
  Save, 
  X, 
  Calendar, 
  FileText, 
  Truck,
  Package, 
  User, 
  CheckSquare,
  ChevronLeft,
  Leaf,
  Building,
  Warehouse,
  BadgePlus,
  Search,
  AlertCircle,
  Loader2,
  MapPin
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";

export default function CultivoNovaTransferencia() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  // Parse URL parameters
  const urlParams = new URLSearchParams(location.search);
  const loteId = urlParams.get('lote');
  const editId = urlParams.get('id');
  
  // State for form data
  const [formData, setFormData] = useState({
    tipo: "interna",
    origem_location: "",
    destino_location: "",
    destino_entity: "",
    destino_address: "",
    destino_license: "",
    data_transferencia: new Date().toISOString().split('T')[0],
    status: "solicitada",
    motivo: "",
    observacoes: "",
    responsavel: "",
    itens: []
  });
  
  // State for item being added
  const [itemToAdd, setItemToAdd] = useState({
    inventory_id: "",
    batch_id: "",
    strain: "",
    type: "",
    quantity: "",
    unit: "g"
  });
  
  // Mock data for locations and items
  const mockLocations = [
    { id: "loc1", name: "Sala de Cultivo A", type: "cultivo" },
    { id: "loc2", name: "Sala de Cultivo B", type: "cultivo" },
    { id: "loc3", name: "Sala de Secagem", type: "secagem" },
    { id: "loc4", name: "Sala de Processamento", type: "processamento" },
    { id: "loc5", name: "Estoque Principal", type: "estoque" },
    { id: "loc6", name: "Laboratório QC", type: "laboratorio" }
  ];
  
  const mockInventoryItems = [
    { 
      id: "inv1", 
      strain: "CBD Rich", 
      batch_id: "BAT2023001", 
      type: "flor", 
      quantity: 1500, 
      unit: "g", 
      location: "loc2"
    },
    { 
      id: "inv2", 
      strain: "Harlequin", 
      batch_id: "BAT2023002", 
      type: "folha", 
      quantity: 800, 
      unit: "g", 
      location: "loc2"
    },
    { 
      id: "inv3", 
      strain: "Charlotte's Web", 
      batch_id: "BAT2023003", 
      type: "semente", 
      quantity: 200, 
      unit: "g", 
      location: "loc5"
    },
    { 
      id: "inv4", 
      strain: "CBD Rich", 
      batch_id: "BAT2023001", 
      type: "extrato", 
      quantity: 350, 
      unit: "ml", 
      location: "loc4"
    }
  ];
  
  // Load initial data
  useEffect(() => {
    if (editId) {
      // Simulate fetching transfer data
      setIsLoading(true);
      setTimeout(() => {
        // Mock data for editing
        setFormData({
          tipo: "interna",
          origem_location: "loc2",
          destino_location: "loc3",
          destino_entity: "",
          destino_address: "",
          destino_license: "",
          data_transferencia: "2023-11-25",
          status: "solicitada",
          motivo: "Transferência para secagem",
          observacoes: "Transferir com cuidado para evitar perda de material",
          responsavel: "Carlos Santos",
          itens: [
            { 
              id: "item1",
              inventory_id: "inv1", 
              batch_id: "BAT2023001", 
              strain: "CBD Rich", 
              type: "flor", 
              quantity: 500, 
              unit: "g"
            }
          ]
        });
        setIsLoading(false);
      }, 1000);
    } else if (loteId) {
      // Pre-fill form with batch data
      const locItem = mockInventoryItems.find(item => item.batch_id === loteId);
      if (locItem) {
        setFormData(prev => ({
          ...prev,
          origem_location: locItem.location
        }));
        
        setItemToAdd({
          inventory_id: locItem.id,
          batch_id: locItem.batch_id,
          strain: locItem.strain,
          type: locItem.type,
          quantity: "",
          unit: locItem.unit
        });
      }
    }
  }, [editId, loteId]);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear destination fields when changing transfer type
    if (name === "tipo") {
      if (value === "interna") {
        setFormData(prev => ({
          ...prev,
          destino_entity: "",
          destino_address: "",
          destino_license: ""
        }));
      } else {
        setFormData(prev => ({
          ...prev,
          destino_location: ""
        }));
      }
    }
  };
  
  const handleItemChange = (e) => {
    const { name, value } = e.target;
    setItemToAdd(prev => ({ ...prev, [name]: value }));
  };
  
  const handleItemSelectChange = (name, value) => {
    setItemToAdd(prev => ({ ...prev, [name]: value }));
    
    // If selecting inventory item, auto-fill other fields
    if (name === "inventory_id") {
      const selectedItem = mockInventoryItems.find(item => item.id === value);
      if (selectedItem) {
        setItemToAdd(prev => ({
          ...prev,
          batch_id: selectedItem.batch_id,
          strain: selectedItem.strain,
          type: selectedItem.type,
          unit: selectedItem.unit
        }));
      }
    }
  };
  
  const handleAddItem = () => {
    // Validate item
    if (!itemToAdd.inventory_id || !itemToAdd.quantity || parseFloat(itemToAdd.quantity) <= 0) {
      toast({
        title: "Erro ao adicionar item",
        description: "Selecione um item e informe uma quantidade válida",
        variant: "destructive",
      });
      return;
    }
    
    // Check if quantity exceeds available
    const selectedItem = mockInventoryItems.find(item => item.id === itemToAdd.inventory_id);
    if (selectedItem && parseFloat(itemToAdd.quantity) > selectedItem.quantity) {
      toast({
        title: "Quantidade excede estoque",
        description: `A quantidade máxima disponível é ${selectedItem.quantity} ${selectedItem.unit}`,
        variant: "destructive",
      });
      return;
    }
    
    // Add item to list
    const newItem = {
      ...itemToAdd,
      id: `item${Date.now()}`
    };
    
    setFormData(prev => ({
      ...prev,
      itens: [...prev.itens, newItem]
    }));
    
    // Reset item form
    setItemToAdd({
      inventory_id: "",
      batch_id: "",
      strain: "",
      type: "",
      quantity: "",
      unit: "g"
    });
    
    toast({
      title: "Item adicionado",
      description: "Item adicionado à transferência com sucesso"
    });
  };
  
  const handleRemoveItem = (itemId) => {
    setFormData(prev => ({
      ...prev,
      itens: prev.itens.filter(item => item.id !== itemId)
    }));
    
    toast({
      title: "Item removido",
      description: "Item removido da transferência"
    });
  };
  
  const getTotalQuantityByUnit = () => {
    const totals = {};
    formData.itens.forEach(item => {
      const unit = item.unit;
      totals[unit] = (totals[unit] || 0) + parseFloat(item.quantity);
    });
    
    return Object.entries(totals).map(([unit, total]) => (
      `${total.toLocaleString()} ${unit}`
    )).join(", ");
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.origem_location) {
      toast({
        title: "Origem não informada",
        description: "Selecione a localização de origem dos itens",
        variant: "destructive",
      });
      return;
    }
    
    if (formData.tipo === "interna" && !formData.destino_location) {
      toast({
        title: "Destino não informado",
        description: "Selecione a localização de destino dos itens",
        variant: "destructive",
      });
      return;
    }
    
    if (formData.tipo !== "interna" && !formData.destino_entity) {
      toast({
        title: "Entidade destino não informada",
        description: "Informe a entidade de destino para transferência externa",
        variant: "destructive",
      });
      return;
    }
    
    if (formData.itens.length === 0) {
      toast({
        title: "Nenhum item adicionado",
        description: "Adicione pelo menos um item à transferência",
        variant: "destructive",
      });
      return;
    }
    
    // Save transfer
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      
      toast({
        title: editId ? "Transferência atualizada" : "Transferência criada",
        description: editId 
          ? "A transferência foi atualizada com sucesso" 
          : "Nova transferência criada com sucesso"
      });
      
      // Redirect back to transfers list
      navigate(createPageUrl("CultivoTransferencias"));
    }, 1500);
  };
  
  const getItemTypeBadge = (type) => {
    const types = {
      "flor": { label: "Flor", color: "bg-green-100 text-green-800 border-green-200" },
      "folha": { label: "Folha", color: "bg-emerald-100 text-emerald-800 border-emerald-200" },
      "semente": { label: "Semente", color: "bg-amber-100 text-amber-800 border-amber-200" },
      "extrato": { label: "Extrato", color: "bg-blue-100 text-blue-800 border-blue-200" },
      "resina": { label: "Resina", color: "bg-purple-100 text-purple-800 border-purple-200" },
      "óleo": { label: "Óleo", color: "bg-indigo-100 text-indigo-800 border-indigo-200" }
    };
    
    const typeInfo = types[type] || { label: type, color: "bg-gray-100 text-gray-800 border-gray-200" };
    
    return (
      <Badge variant="outline" className={typeInfo.color}>
        {typeInfo.label}
      </Badge>
    );
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-green-600" />
          <p className="text-sm text-gray-500">Carregando dados da transferência...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <Breadcrumb className="mb-4">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href={createPageUrl("CultivoDashboard")}>Cultivo</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink href={createPageUrl("CultivoTransferencias")}>Transferências</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink>{editId ? "Editar" : "Nova"} Transferência</BreadcrumbLink>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">{editId ? "Editar" : "Nova"} Transferência</h1>
            <p className="text-gray-500 mt-1">
              {editId ? "Altere os dados da transferência" : "Registre uma nova transferência de materiais"}
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              className="gap-2"
              onClick={() => navigate(createPageUrl("CultivoTransferencias"))}
            >
              <X className="h-4 w-4" />
              Cancelar
            </Button>
            
            <Button 
              variant="default" 
              className="gap-2"
              onClick={handleSubmit}
              disabled={isSaving}
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  Salvar
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Dados da Transferência</CardTitle>
              <CardDescription>
                Informe os detalhes básicos da transferência
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="tipo">Tipo de Transferência</Label>
                <RadioGroup 
                  id="tipo" 
                  value={formData.tipo} 
                  onValueChange={(value) => handleSelectChange("tipo", value)}
                  className="flex flex-col space-y-1"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="interna" id="tipo-interna" />
                    <Label htmlFor="tipo-interna" className="font-normal">
                      Transferência Interna (entre setores)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="externa" id="tipo-externa" />
                    <Label htmlFor="tipo-externa" className="font-normal">
                      Transferência Externa (para outra entidade)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="laboratorio" id="tipo-lab" />
                    <Label htmlFor="tipo-lab" className="font-normal">
                      Envio para Laboratório (análise/teste)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="descarte" id="tipo-descarte" />
                    <Label htmlFor="tipo-descarte" className="font-normal">
                      Descarte (material inservível)
                    </Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="origem_location">Origem</Label>
                  <Select
                    value={formData.origem_location}
                    onValueChange={(value) => handleSelectChange("origem_location", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a origem" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockLocations.map(location => (
                        <SelectItem key={location.id} value={location.id}>
                          {location.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                {formData.tipo === "interna" ? (
                  <div className="space-y-2">
                    <Label htmlFor="destino_location">Destino</Label>
                    <Select
                      value={formData.destino_location}
                      onValueChange={(value) => handleSelectChange("destino_location", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o destino" />
                      </SelectTrigger>
                      <SelectContent>
                        {mockLocations
                          .filter(loc => loc.id !== formData.origem_location)
                          .map(location => (
                            <SelectItem key={location.id} value={location.id}>
                              {location.name}
                            </SelectItem>
                          ))
                        }
                      </SelectContent>
                    </Select>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="destino_entity">Entidade Destino</Label>
                    <Input
                      id="destino_entity"
                      name="destino_entity"
                      placeholder="Nome da entidade destino"
                      value={formData.destino_entity}
                      onChange={handleInputChange}
                    />
                  </div>
                )}
              </div>
              
              {formData.tipo !== "interna" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="destino_address">Endereço de Destino</Label>
                    <Input
                      id="destino_address"
                      name="destino_address"
                      placeholder="Endereço completo"
                      value={formData.destino_address}
                      onChange={handleInputChange}
                    />
                  </div>
                  
                  {(formData.tipo === "externa" || formData.tipo === "laboratorio") && (
                    <div className="space-y-2">
                      <Label htmlFor="destino_license">Licença/Autorização</Label>
                      <Input
                        id="destino_license"
                        name="destino_license"
                        placeholder="Número da licença/autorização"
                        value={formData.destino_license}
                        onChange={handleInputChange}
                      />
                    </div>
                  )}
                </div>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="data_transferencia">Data da Transferência</Label>
                  <Input
                    id="data_transferencia"
                    name="data_transferencia"
                    type="date"
                    value={formData.data_transferencia}
                    onChange={handleInputChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="responsavel">Responsável</Label>
                  <Input
                    id="responsavel"
                    name="responsavel"
                    placeholder="Nome do responsável pela transferência"
                    value={formData.responsavel}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="motivo">Motivo da Transferência</Label>
                <Input
                  id="motivo"
                  name="motivo"
                  placeholder="Motivo da transferência"
                  value={formData.motivo}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  name="observacoes"
                  placeholder="Observações adicionais"
                  value={formData.observacoes}
                  onChange={handleInputChange}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Itens para Transferência</CardTitle>
              <CardDescription>
                Adicione os itens que serão transferidos
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
                <div className="md:col-span-2 space-y-2">
                  <Label htmlFor="inventory_id">Item</Label>
                  <Select
                    value={itemToAdd.inventory_id}
                    onValueChange={(value) => handleItemSelectChange("inventory_id", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um item" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockInventoryItems
                        .filter(item => item.location === formData.origem_location || !formData.origem_location)
                        .map(item => (
                          <SelectItem key={item.id} value={item.id}>
                            {item.strain} - {item.type} - Lote: {item.batch_id}
                          </SelectItem>
                        ))
                      }
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantidade</Label>
                  <Input
                    id="quantity"
                    name="quantity"
                    type="number"
                    min="0.1"
                    step="0.1"
                    placeholder="Quantidade"
                    value={itemToAdd.quantity}
                    onChange={handleItemChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="unit">Unidade</Label>
                  <Select
                    value={itemToAdd.unit}
                    onValueChange={(value) => handleItemSelectChange("unit", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Unidade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="g">Gramas (g)</SelectItem>
                      <SelectItem value="kg">Quilogramas (kg)</SelectItem>
                      <SelectItem value="ml">Mililitros (ml)</SelectItem>
                      <SelectItem value="l">Litros (l)</SelectItem>
                      <SelectItem value="unidades">Unidades</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button 
                  type="button" 
                  onClick={handleAddItem}
                  variant="outline"
                  className="gap-2"
                >
                  <BadgePlus className="h-4 w-4" />
                  Adicionar Item
                </Button>
              </div>
              
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Strain/Variação</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Lote</TableHead>
                      <TableHead className="text-right">Quantidade</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {formData.itens.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-6 text-gray-500">
                          Nenhum item adicionado à transferência
                        </TableCell>
                      </TableRow>
                    ) : (
                      formData.itens.map(item => (
                        <TableRow key={item.id}>
                          <TableCell>{item.strain}</TableCell>
                          <TableCell>{getItemTypeBadge(item.type)}</TableCell>
                          <TableCell>{item.batch_id}</TableCell>
                          <TableCell className="text-right">
                            {parseFloat(item.quantity).toLocaleString()} {item.unit}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => handleRemoveItem(item.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Resumo da Transferência</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Tipo:</span>
                  <span className="font-medium">
                    {formData.tipo === "interna" && "Transferência Interna"}
                    {formData.tipo === "externa" && "Transferência Externa"}
                    {formData.tipo === "laboratorio" && "Envio para Laboratório"}
                    {formData.tipo === "descarte" && "Descarte"}
                  </span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Origem:</span>
                  <span className="font-medium">
                    {mockLocations.find(l => l.id === formData.origem_location)?.name || "-"}
                  </span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Destino:</span>
                  <span className="font-medium">
                    {formData.tipo === "interna" 
                      ? mockLocations.find(l => l.id === formData.destino_location)?.name 
                      : formData.destino_entity} {formData.destino_entity ? `(${formData.tipo})` : ""}
                  </span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Data:</span>
                  <span className="font-medium">
                    {formData.data_transferencia ? new Date(formData.data_transferencia).toLocaleDateString('pt-BR') : "-"}
                  </span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Total:</span>
                  <span className="font-medium">
                    {formData.itens.length} {formData.itens.length === 1 ? "item" : "itens"}
                  </span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Quantidade:</span>
                  <span className="font-medium">
                    {getTotalQuantityByUnit() || "-"}
                  </span>
                </div>
              </div>
              
              <div className="border-t pt-4 mt-4">
                <Badge variant="outline" className="bg-yellow-50 text-yellow-800 border-yellow-200">
                  {formData.status === "solicitada" && "Solicitada (Aguardando Aprovação)"}
                </Badge>
              </div>
              
              {formData.itens.length === 0 && (
                <div className="border rounded-md p-3 bg-amber-50 text-amber-800 border-amber-200 text-sm flex gap-2 items-start">
                  <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium">Adicione itens à transferência</p>
                    <p className="text-amber-700 text-xs mt-1">
                      Para salvar a transferência, adicione pelo menos um item.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ajuda</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-4">
              <div className="space-y-2">
                <h3 className="font-medium">Tipos de Transferência</h3>
                <ul className="space-y-1 text-gray-600">
                  <li className="flex gap-2">
                    <ArrowLeftRight className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                    <span><strong>Interna:</strong> Entre setores da mesma unidade</span>
                  </li>
                  <li className="flex gap-2">
                    <Truck className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span><strong>Externa:</strong> Para outras entidades</span>
                  </li>
                  <li className="flex gap-2">
                    <FileText className="h-4 w-4 text-purple-500 mt-0.5 flex-shrink-0" />
                    <span><strong>Laboratório:</strong> Para testes e análises</span>
                  </li>
                  <li className="flex gap-2">
                    <X className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                    <span><strong>Descarte:</strong> Material inservível</span>
                  </li>
                </ul>
              </div>
              
              <div className="space-y-1">
                <p>
                  Transferências entre setores são aprovadas automaticamente, enquanto transferências 
                  externas requerem aprovação do responsável pela qualidade.
                </p>
                <p>
                  Todas as transferências são rastreadas e registradas para fins de compliance com a ANVISA.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}