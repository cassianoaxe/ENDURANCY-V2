import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  FileText,
  Video,
  MoreVertical,
  Edit,
  Trash,
  Eye,
  Plus,
  Search
} from 'lucide-react';

export default function OnboardingContent() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedModule, setSelectedModule] = useState('all');
  const [tutorials, setTutorials] = useState([
    {
      id: 1,
      title: 'Introdução à Plataforma',
      type: 'video',
      module: 'Geral',
      status: 'published',
      lastUpdated: '2023-10-15'
    },
    {
      id: 2,
      title: 'Gestão de Cultivo',
      type: 'text',
      module: 'Cultivo',
      status: 'draft',
      lastUpdated: '2023-10-14'
    },
    // Add more mock tutorials...
  ]);

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gerenciar Conteúdos</h1>
          <p className="text-gray-500 mt-1">Gerencie tutoriais e materiais de treinamento</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Novo Conteúdo
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Tutoriais</CardTitle>
            <div className="flex gap-4">
              <div className="flex items-center gap-2">
                <Input
                  placeholder="Buscar tutoriais..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-64"
                />
                <Button variant="outline" size="icon">
                  <Search className="h-4 w-4" />
                </Button>
              </div>
              <Select value={selectedModule} onValueChange={setSelectedModule}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Filtrar por módulo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os módulos</SelectItem>
                  <SelectItem value="geral">Geral</SelectItem>
                  <SelectItem value="cultivo">Cultivo</SelectItem>
                  <SelectItem value="producao">Produção</SelectItem>
                  <SelectItem value="dispensario">Dispensário</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Título</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Módulo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Última Atualização</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tutorials.map((tutorial) => (
                <TableRow key={tutorial.id}>
                  <TableCell>{tutorial.title}</TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {tutorial.type === 'video' ? (
                        <Video className="w-4 h-4 mr-1" />
                      ) : (
                        <FileText className="w-4 h-4 mr-1" />
                      )}
                      {tutorial.type}
                    </Badge>
                  </TableCell>
                  <TableCell>{tutorial.module}</TableCell>
                  <TableCell>
                    <Badge
                      variant={tutorial.status === 'published' ? 'success' : 'secondary'}
                    >
                      {tutorial.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{tutorial.lastUpdated}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Eye className="w-4 h-4 mr-2" />
                          Visualizar
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="w-4 h-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash className="w-4 h-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}