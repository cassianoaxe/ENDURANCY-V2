
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { User } from '@/api/entities';
import {
  LayoutDashboard, Video, Users, ClipboardList, Brain, DollarSign,
  Settings, LogOut, Menu, X, Bell, Calendar, TrendingUp, Clock,
  AlertTriangle, CheckCircle2, UserCog, Wallet, FileText, UserPlus,
  CalendarRange, Star
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import DoctorLayout from '../components/DoctorLayout';

export default function DoctorDashboard() {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [dashboardData, setDashboardData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setTimeout(() => {
      setDashboardData({
        doctor: {
          name: "Dr. João Silva",
          specialty: "Clínico Geral",
          crm: "12345-SP",
          rating: 4.8,
          totalPatients: 128,
          totalPrescriptions: 456
        },
        todayStats: {
          appointments: 8,
          completed: 3,
          upcoming: 5,
          newPrescriptions: 4
        },
        monthlyStats: {
          totalAppointments: 96,
          totalRevenue: 15600,
          newPatients: 12,
          prescriptionsIssued: 84
        },
        upcomingAppointments: [
          {
            id: 1,
            patientName: "Maria Oliveira",
            time: "14:30",
            type: "Primeira Consulta",
            isVirtual: true
          },
          {
            id: 2,
            patientName: "Pedro Santos",
            time: "15:00",
            type: "Retorno",
            isVirtual: false
          },
          {
            id: 3,
            patientName: "Ana Costa",
            time: "16:00",
            type: "Avaliação",
            isVirtual: true
          }
        ],
        recentPrescriptions: [
          {
            id: 1,
            patientName: "Carlos Mendes",
            date: "2024-03-17",
            status: "approved",
            products: ["CBD Oil 5%", "THC Oil 1%"]
          },
          {
            id: 2,
            patientName: "Lúcia Ferreira",
            date: "2024-03-16",
            status: "pending",
            products: ["CBD Oil 10%"]
          }
        ],
        patientStats: {
          total: 128,
          active: 98,
          new: 12,
          returning: 86
        },
        appointmentTrends: [
          { month: 'Jan', virtual: 45, inPerson: 30 },
          { month: 'Fev', virtual: 52, inPerson: 28 },
          { month: 'Mar', virtual: 58, inPerson: 32 }
        ],
        financialStats: {
          currentMonth: 15600,
          lastMonth: 14200,
          growth: 9.8,
          pendingPayments: 2400
        }
      });
      setIsLoading(false);
    }, 1500);
  };

  const handleLogout = async () => {
    try {
      localStorage.removeItem('mockUserType');
      localStorage.removeItem('mockUserEmail');
      localStorage.removeItem('mockUserName');
      
      try {
        await User.logout();
      } catch (e) {
        console.log("Regular logout failed, but we still proceed with local logout");
      }
      
      navigate(createPageUrl("Access"));
    } catch (error) {
      console.error("Erro ao fazer logout:", error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-600"></div>
          <p className="text-sm text-gray-500">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <DoctorLayout>
      <div className="flex h-screen overflow-hidden bg-purple-50">
        {/* Main Content */}
        <div className="flex flex-1 flex-col overflow-hidden">
          {/* Top Navigation */}
          <header className="bg-white border-b px-4 py-2">
            <div className="flex items-center justify-between">
              <Button 
                variant="ghost" 
                size="icon"
                className="md:hidden"
                onClick={() => setIsMenuOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              
              <div className="flex items-center gap-4 ml-auto">
                <Button variant="outline" size="sm">
                  <Calendar className="mr-2 h-4 w-4" />
                  Agendar Consulta
                </Button>
                
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
                </Button>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                      <Avatar>
                        <AvatarFallback>{dashboardData.doctor.name.split(' ')[0][0] + dashboardData.doctor.name.split(' ')[1][0]}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <UserCog className="mr-2 h-4 w-4" />
                      <span>Perfil</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Configurações</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Sair</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </header>
          
          {/* Dashboard Content */}
          <div className="flex-1 overflow-auto p-6">
            {/* Cards de Estatísticas Principais */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Consultas Hoje</CardTitle>
                  <Calendar className="h-4 w-4 text-gray-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{dashboardData.todayStats.appointments}</div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    <span>{dashboardData.todayStats.completed} realizadas</span>
                    <span className="text-gray-300">|</span>
                    <Clock className="h-4 w-4 text-blue-500" />
                    <span>{dashboardData.todayStats.upcoming} pendentes</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Total de Pacientes</CardTitle>
                  <Users className="h-4 w-4 text-gray-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{dashboardData.patientStats.total}</div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <UserPlus className="h-4 w-4 text-green-500" />
                    <span>{dashboardData.patientStats.new} novos este mês</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Receita Mensal</CardTitle>
                  <Wallet className="h-4 w-4 text-gray-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    R$ {dashboardData.financialStats.currentMonth.toLocaleString()}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <TrendingUp className="h-4 w-4 text-green-500" />
                    <span>+{dashboardData.financialStats.growth}% vs. último mês</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Prescrições</CardTitle>
                  <FileText className="h-4 w-4 text-gray-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{dashboardData.monthlyStats.prescriptionsIssued}</div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    <span>{dashboardData.todayStats.newPrescriptions} hoje</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Próximas Consultas e Gráficos */}
            <div className="mt-6 grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Próximas Consultas</CardTitle>
                  <CardDescription>Consultas agendadas para hoje</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardData.upcomingAppointments.map((appointment) => (
                      <div key={appointment.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <Avatar>
                            <AvatarFallback>
                              {appointment.patientName.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{appointment.patientName}</div>
                            <div className="text-sm text-gray-500">{appointment.type}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={appointment.isVirtual ? "default" : "outline"}>
                            {appointment.isVirtual ? "Virtual" : "Presencial"}
                          </Badge>
                          <div className="text-sm font-medium">{appointment.time}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Tendência de Consultas</CardTitle>
                  <CardDescription>Comparativo mensal de consultas virtuais e presenciais</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={dashboardData.appointmentTrends}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="virtual" stroke="#8884d8" name="Virtuais" />
                      <Line type="monotone" dataKey="inPerson" stroke="#82ca9d" name="Presenciais" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Prescrições Recentes e Indicadores Financeiros */}
            <div className="mt-6 grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Prescrições Recentes</CardTitle>
                  <CardDescription>Últimas prescrições emitidas</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardData.recentPrescriptions.map((prescription) => (
                      <div key={prescription.id} className="flex items-center justify-between">
                        <div>
                          <div className="font-medium">{prescription.patientName}</div>
                          <div className="text-sm text-gray-500">
                            {prescription.products.join(", ")}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={prescription.status === "approved" ? "success" : "warning"}>
                            {prescription.status === "approved" ? "Aprovada" : "Pendente"}
                          </Badge>
                          <div className="text-sm text-gray-500">{prescription.date}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Desempenho Financeiro</CardTitle>
                  <CardDescription>Visão geral financeira do consultório</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium">Meta Mensal</div>
                        <div className="text-sm text-gray-500">78% atingida</div>
                      </div>
                      <Progress value={78} className="mt-2" />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Pagamentos Pendentes</div>
                        <div className="text-2xl font-bold">
                          R$ {dashboardData.financialStats.pendingPayments.toLocaleString()}
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Ver Detalhes</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </DoctorLayout>
  );
}
