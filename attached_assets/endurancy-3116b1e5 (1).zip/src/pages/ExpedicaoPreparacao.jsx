import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  PackageCheck, 
  Search, 
  CheckCircle2, 
  XCircle, 
  ArrowLeft, 
  PrinterIcon,
  Eye,
  AlertCircle,
  ScanBarcode,
  Filter,
  ChevronDown,
  FileText
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Dados simulados de pedidos
const mockOrders = [
  { 
    id: "1", 
    orderNumber: "PED-12345", 
    customer: "João Silva", 
    cpf: "123.456.789-00",
    status: "Aguardando preparação", 
    priority: "Urgente",
    date: "2023-11-15",
    items: [
      { id: "1-1", name: "Óleo CBD 10%", quantity: 1, lot: "LOT-2023-A", type: "medicinal" },
      { id: "1-2", name: "Óleo CBD 5%", quantity: 1, lot: "LOT-2023-B", type: "medicinal" }
    ]
  },
  { 
    id: "2", 
    orderNumber: "PED-12346", 
    customer: "Maria Oliveira", 
    cpf: "987.654.321-00",
    status: "Aguardando preparação", 
    priority: "Normal",
    date: "2023-11-15",
    items: [
      { id: "2-1", name: "Óleo CBD 20%", quantity: 1, lot: "LOT-2023-C", type: "medicinal" }
    ]
  },
  { 
    id: "3", 
    orderNumber: "PED-12347", 
    customer: "Carlos Santos", 
    cpf: "456.789.123-00",
    status: "Aguardando preparação", 
    priority: "Urgente",
    date: "2023-11-15",
    items: [
      { id: "3-1", name: "Óleo CBD 30%", quantity: 1, lot: "LOT-2023-D", type: "medicinal" },
      { id: "3-2", name: "Camiseta Abrace", quantity: 1, lot: "N/A", type: "souvenir" },
      { id: "3-3", name: "Pomada CBD", quantity: 2, lot: "LOT-2023-E", type: "medicinal" }
    ]
  },
  { 
    id: "4", 
    orderNumber: "PED-12348", 
    customer: "Ana Costa", 
    cpf: "321.654.987-00",
    status: "Aguardando preparação", 
    priority: "Normal",
    date: "2023-11-15",
    items: [
      { id: "4-1", name: "Óleo CBD 15%", quantity: 1, lot: "LOT-2023-F", type: "medicinal" }
    ]
  },
  { 
    id: "5", 
    orderNumber: "PED-12349", 
    customer: "Fernando Mendes", 
    cpf: "789.123.456-00",
    status: "Aguardando preparação", 
    priority: "Normal",
    date: "2023-11-15",
    items: [
      { id: "5-1", name: "Óleo CBD 10%", quantity: 2, lot: "LOT-2023-A", type: "medicinal" },
    ]
  }
];

export default function ExpedicaoPreparacao() {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [currentOrder, setCurrentOrder] = useState(null);
  const [isPreparingOrder, setIsPreparingOrder] = useState(false);
  const [checkedItems, setCheckedItems] = useState({});
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulando carregamento da API
    const loadOrders = async () => {
      setIsLoading(true);
      try {
        // Em uma implementação real, isso seria uma chamada à API
        setTimeout(() => {
          setOrders(mockOrders);
          setFilteredOrders(mockOrders);
          setIsLoading(false);
        }, 500);
      } catch (error) {
        console.error("Erro ao carregar pedidos:", error);
        setIsLoading(false);
      }
    };

    loadOrders();
  }, []);

  useEffect(() => {
    if (orders.length) {
      let result = [...orders];
      
      // Aplicar filtro de busca
      if (searchTerm) {
        result = result.filter(order => 
          order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
          order.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
          order.cpf.replace(/\D/g, '').includes(searchTerm.replace(/\D/g, ''))
        );
      }
      
      // Aplicar filtro de status
      if (statusFilter !== "all") {
        result = result.filter(order => order.status === statusFilter);
      }
      
      // Aplicar filtro de prioridade
      if (priorityFilter !== "all") {
        result = result.filter(order => order.priority === priorityFilter);
      }
      
      setFilteredOrders(result);
    }
  }, [orders, searchTerm, statusFilter, priorityFilter]);

  const handleStartPreparation = (order) => {
    setCurrentOrder(order);
    setIsPreparingOrder(true);
    
    // Inicializar o estado de itens checados
    const initialCheckedState = {};
    order.items.forEach(item => {
      initialCheckedState[item.id] = false;
    });
    setCheckedItems(initialCheckedState);
  };

  const handleCancelPreparation = () => {
    setCurrentOrder(null);
    setIsPreparingOrder(false);
    setCheckedItems({});
  };

  const handleCheckItem = (itemId, isChecked) => {
    setCheckedItems(prev => ({
      ...prev,
      [itemId]: isChecked
    }));
  };

  const isAllItemsChecked = () => {
    if (!currentOrder) return false;
    return currentOrder.items.every(item => checkedItems[item.id]);
  };

  const handleFinishPreparation = () => {
    if (isAllItemsChecked()) {
      setShowConfirmDialog(true);
    }
  };

  const confirmFinishPreparation = () => {
    // Atualizar o pedido para o próximo status (em uma aplicação real, isso seria uma chamada à API)
    const updatedOrders = orders.map(order => {
      if (order.id === currentOrder.id) {
        return {
          ...order,
          status: "Em revisão"
        };
      }
      return order;
    });
    
    setOrders(updatedOrders);
    setShowConfirmDialog(false);
    setCurrentOrder(null);
    setIsPreparingOrder(false);
    setCheckedItems({});
  };

  const renderOrdersList = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mb-4"></div>
          <p className="text-gray-600">Carregando pedidos...</p>
        </div>
      );
    }

    if (filteredOrders.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center py-12">
          <PackageCheck className="h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900">Nenhum pedido encontrado</h3>
          <p className="text-gray-500 mt-1">
            {searchTerm || statusFilter !== "all" || priorityFilter !== "all"
              ? "Tente ajustar os filtros de busca"
              : "Não há pedidos aguardando preparação no momento"}
          </p>
        </div>
      );
    }

    return (
      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Pedido</TableHead>
              <TableHead>Cliente</TableHead>
              <TableHead>CPF</TableHead>
              <TableHead>Prioridade</TableHead>
              <TableHead>Data</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredOrders.map(order => (
              <TableRow key={order.id}>
                <TableCell className="font-medium">{order.orderNumber}</TableCell>
                <TableCell>{order.customer}</TableCell>
                <TableCell>{order.cpf}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={
                    order.priority === 'Urgente' ? 'bg-red-50 text-red-700 border-red-200' :
                    'bg-gray-50 text-gray-700 border-gray-200'
                  }>
                    {order.priority}
                  </Badge>
                </TableCell>
                <TableCell>{order.date}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={
                    order.status === 'Aguardando preparação' ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                    order.status === 'Em revisão' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                    'bg-gray-50 text-gray-700 border-gray-200'
                  }>
                    {order.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleStartPreparation(order)}
                      disabled={order.status !== "Aguardando preparação"}
                    >
                      <PackageCheck className="w-4 h-4 mr-2" />
                      Preparar
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Eye className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  };

  const renderPreparationView = () => {
    if (!currentOrder) return null;

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleCancelPreparation}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
            <h2 className="text-xl font-bold">Preparando Pedido: {currentOrder.orderNumber}</h2>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <FileText className="w-4 h-4 mr-2" />
              Documentos
            </Button>
            <Button variant="outline" size="sm">
              <PrinterIcon className="w-4 h-4 mr-2" />
              Imprimir Etiqueta
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Detalhes do Pedido</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-gray-500">Cliente</p>
                <p className="font-medium">{currentOrder.customer}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">CPF</p>
                <p>{currentOrder.cpf}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Data do Pedido</p>
                <p>{currentOrder.date}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Prioridade</p>
                <Badge variant="outline" className={
                  currentOrder.priority === 'Urgente' ? 'bg-red-50 text-red-700 border-red-200' :
                  'bg-gray-50 text-gray-700 border-gray-200'
                }>
                  {currentOrder.priority}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Itens do Pedido</CardTitle>
            <CardDescription>Confira todos os itens e marque os que foram coletados</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="border rounded-md">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Item</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Quantidade</TableHead>
                    <TableHead>Lote</TableHead>
                    <TableHead>Coletado</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {currentOrder.items.map(item => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={
                          item.type === 'medicinal' ? 'bg-green-50 text-green-700 border-green-200' :
                          'bg-purple-50 text-purple-700 border-purple-200'
                        }>
                          {item.type === 'medicinal' ? 'Medicinal' : 'Souvenir'}
                        </Badge>
                      </TableCell>
                      <TableCell>{item.quantity}</TableCell>
                      <TableCell>{item.lot}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Checkbox 
                            id={`item-${item.id}`}
                            checked={checkedItems[item.id] || false}
                            onCheckedChange={(checked) => handleCheckItem(item.id, checked)}
                          />
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="ml-2"
                            onClick={() => handleCheckItem(item.id, !checkedItems[item.id])}
                          >
                            <ScanBarcode className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div>
              <p className="text-sm text-gray-500">
                {Object.values(checkedItems).filter(Boolean).length} de {currentOrder.items.length} itens coletados
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleCancelPreparation}>Cancelar</Button>
              <Button 
                onClick={handleFinishPreparation}
                disabled={!isAllItemsChecked()}
              >
                {isAllItemsChecked() ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Concluir Preparação
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 mr-2" />
                    Colete todos os itens
                  </>
                )}
              </Button>
            </div>
          </CardFooter>
        </Card>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {isPreparingOrder ? (
        renderPreparationView()
      ) : (
        <>
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">Preparação de Pedidos</h1>
              <p className="text-gray-500 dark:text-gray-400 mt-1">
                Gerencie a preparação de pedidos para expedição
              </p>
            </div>
            <Link to={createPageUrl("ExpedicaoDashboard")}>
              <Button variant="outline">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar ao Dashboard
              </Button>
            </Link>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar por pedido, cliente ou CPF"
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      <div className="flex items-center">
                        <Filter className="w-4 h-4 mr-2" />
                        Status: {statusFilter === "all" ? "Todos" : statusFilter}
                      </div>
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56">
                    <DropdownMenuItem onClick={() => setStatusFilter("all")}>
                      Todos os status
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => setStatusFilter("Aguardando preparação")}>
                      Aguardando preparação
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setStatusFilter("Em revisão")}>
                      Em revisão
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      <div className="flex items-center">
                        <Filter className="w-4 h-4 mr-2" />
                        Prioridade: {priorityFilter === "all" ? "Todas" : priorityFilter}
                      </div>
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56">
                    <DropdownMenuItem onClick={() => setPriorityFilter("all")}>
                      Todas as prioridades
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => setPriorityFilter("Urgente")}>
                      Urgente
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setPriorityFilter("Normal")}>
                      Normal
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Pedidos ({filteredOrders.length})</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              {renderOrdersList()}
            </CardContent>
          </Card>
        </>
      )}

      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar conclusão da preparação</DialogTitle>
            <DialogDescription>
              Todos os itens foram coletados e o pedido está pronto para revisão. Deseja prosseguir?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={confirmFinishPreparation}>
              Confirmar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}