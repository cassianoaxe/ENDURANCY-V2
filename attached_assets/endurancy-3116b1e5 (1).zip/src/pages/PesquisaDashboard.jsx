import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Microscope,
  FileSearch,
  Database,
  Brain,
  Activity,
  Users,
  BookMarked,
  Share2,
  FilePlus2,
  PieChart,
  ArrowUpRight,
  ExternalLink,
  ArrowRight,
  TrendingUp,
  Beaker,
  ChartBar,
  Group
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function PesquisaDashboard() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Dashboard de Pesquisa Científica</h1>
          <p className="text-muted-foreground">Acompanhe e gerencie todas as atividades de pesquisa</p>
        </div>
        <Link to={createPageUrl("NovaPesquisa")}>
          <Button className="bg-green-600 hover:bg-green-700">
            <FilePlus2 className="w-4 h-4 mr-2" />
            Nova Pesquisa
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pesquisas Ativas
            </CardTitle>
            <div className="text-2xl font-bold">12</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              +2 novas este mês
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Participantes
            </CardTitle>
            <div className="text-2xl font-bold">248</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              Em 8 estudos diferentes
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Publicações
            </CardTitle>
            <div className="text-2xl font-bold">18</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              3 em processo de revisão
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Colaborações
            </CardTitle>
            <div className="text-2xl font-bold">5</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              Com 3 instituições diferentes
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Acesso Rápido</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Link to={createPageUrl("CatalogoPesquisas")}>
              <Button variant="outline" className="w-full justify-start">
                <FileSearch className="w-4 h-4 mr-2" />
                Catálogo de Pesquisas
              </Button>
            </Link>
            <Link to={createPageUrl("BancoPacientes")}>
              <Button variant="outline" className="w-full justify-start">
                <Database className="w-4 h-4 mr-2" />
                Banco de Pacientes
              </Button>
            </Link>
            <Link to={createPageUrl("DoencasCondicoes")}>
              <Button variant="outline" className="w-full justify-start">
                <Brain className="w-4 h-4 mr-2" />
                Doenças e Condições
              </Button>
            </Link>
            <Link to={createPageUrl("EstatisticasPesquisa")}>
              <Button variant="outline" className="w-full justify-start">
                <Activity className="w-4 h-4 mr-2" />
                Estatísticas
              </Button>
            </Link>
            <Link to={createPageUrl("GruposPesquisa")}>
              <Button variant="outline" className="w-full justify-start">
                <Users className="w-4 h-4 mr-2" />
                Grupos de Pesquisa
              </Button>
            </Link>
            <Link to={createPageUrl("Protocolos")}>
              <Button variant="outline" className="w-full justify-start">
                <BookMarked className="w-4 h-4 mr-2" />
                Protocolos
              </Button>
            </Link>
            <Link to={createPageUrl("Colaboracoes")}>
              <Button variant="outline" className="w-full justify-start">
                <Share2 className="w-4 h-4 mr-2" />
                Colaborações
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pesquisas Recentes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              {
                titulo: "Eficácia do CBD na epilepsia refratária",
                status: "em_andamento",
                atualizacao: "Hoje"
              },
              {
                titulo: "Efeitos da cannabis em pacientes com dor crônica",
                status: "em_analise",
                atualizacao: "Ontem"
              },
              {
                titulo: "Estudo comparativo de diferentes cepas",
                status: "aprovada",
                atualizacao: "2 dias atrás"
              }
            ].map((pesquisa, index) => (
              <div key={index} className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-100">
                <div>
                  <div className="font-medium">{pesquisa.titulo}</div>
                  <div className="text-sm text-muted-foreground">
                    Atualizado {pesquisa.atualizacao}
                  </div>
                </div>
                <Badge 
                  variant={
                    pesquisa.status === "em_andamento" ? "default" :
                    pesquisa.status === "em_analise" ? "secondary" :
                    "success"
                  }
                >
                  {pesquisa.status === "em_andamento" ? "Em Andamento" :
                   pesquisa.status === "em_analise" ? "Em Análise" :
                   "Aprovada"}
                </Badge>
              </div>
            ))}
            <Link to={createPageUrl("CatalogoPesquisas")}>
              <Button variant="link" className="w-full">
                Ver todas as pesquisas
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Próximos Eventos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              {
                titulo: "Reunião do Comitê de Ética",
                data: "15/03/2024",
                tipo: "reuniao"
              },
              {
                titulo: "Apresentação de Resultados Preliminares",
                data: "20/03/2024",
                tipo: "apresentacao"
              },
              {
                titulo: "Workshop de Metodologia",
                data: "25/03/2024",
                tipo: "workshop"
              }
            ].map((evento, index) => (
              <div key={index} className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-100">
                <div>
                  <div className="font-medium">{evento.titulo}</div>
                  <div className="text-sm text-muted-foreground">{evento.data}</div>
                </div>
                <Button variant="ghost" size="icon">
                  <ArrowUpRight className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}