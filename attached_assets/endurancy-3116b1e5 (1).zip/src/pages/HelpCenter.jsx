import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Search, 
  HelpCircle, 
  Book, 
  MessageSquare, 
  PlayCircle, 
  FileText, 
  ChevronRight, 
  Send, 
  Info, 
  AlertTriangle,
  Check,
  Star,
  StarHalf,
  ThumbsUp,
  Lightbulb
} from "lucide-react";

// Sample FAQs
const faqs = [
  {
    id: 1,
    question: 'Como adicionar uma nova organização?',
    answer: 'Para adicionar uma nova organização, acesse o menu "Organizações" no painel lateral e clique no botão "Nova Organização". Preencha o formulário com as informações necessárias e clique em "Criar Organização".',
    category: 'organizations'
  },
  {
    id: 2,
    question: 'Como convidar novos usuários?',
    answer: 'Para convidar novos usuários, acesse o menu "Gerenciamento de Usuários" e clique no botão "Novo Usuário". Preencha o email e defina a função do usuário, então selecione a opção "Enviar convite por email".',
    category: 'users'
  },
  {
    id: 3,
    question: 'Como gerar relatórios personalizados?',
    answer: 'Para gerar relatórios personalizados, vá até a seção "Relatórios", selecione o tipo de relatório que deseja, escolha "Personalizado" na seleção de período e defina o intervalo de datas desejado.',
    category: 'reports'
  },
  {
    id: 4,
    question: 'Como verificar os logs de auditoria?',
    answer: 'Os logs de auditoria podem ser acessados através do menu "Logs de Auditoria". Lá você pode filtrar por tipo de ação, período de tempo e realizar buscas para encontrar registros específicos.',
    category: 'security'
  },
  {
    id: 5,
    question: 'Como fazer backup dos dados da plataforma?',
    answer: 'Para fazer backup dos dados, acesse o menu "Backups" e clique no botão "Novo Backup". Você pode escolher entre backup completo ou parcial, e configurar a frequência de backups automáticos nas configurações.',
    category: 'data'
  },
  {
    id: 6,
    question: 'Como alterar o plano de uma organização?',
    answer: 'Para alterar o plano de uma organização, vá até "Organizações", encontre a organização desejada, clique em "Ações" e selecione "Alterar Plano". Escolha o novo plano e confirme a alteração.',
    category: 'billing'
  }
];

// Sample documentation categories
const docCategories = [
  {
    id: 'getting-started',
    name: 'Primeiros Passos',
    icon: <Book className="w-4 h-4" />,
    count: 5
  },
  {
    id: 'organizations',
    name: 'Gerenciamento de Organizações',
    icon: <FileText className="w-4 h-4" />,
    count: 8
  },
  {
    id: 'users',
    name: 'Usuários e Permissões',
    icon: <FileText className="w-4 h-4" />,
    count: 6
  },
  {
    id: 'reports',
    name: 'Relatórios e Analytics',
    icon: <FileText className="w-4 h-4" />,
    count: 4
  },
  {
    id: 'security',
    name: 'Segurança e Compliance',
    icon: <FileText className="w-4 h-4" />,
    count: 7
  },
  {
    id: 'data',
    name: 'Dados e Backups',
    icon: <FileText className="w-4 h-4" />,
    count: 3
  },
  {
    id: 'billing',
    name: 'Faturamento e Planos',
    icon: <FileText className="w-4 h-4" />,
    count: 5
  }
];

// Sample video tutorials
const videoTutorials = [
  {
    id: 1,
    title: 'Introdução à Plataforma Endurancy',
    description: 'Conheça as principais funcionalidades e navegação do sistema.',
    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/hqdefault.jpg',
    duration: '5:32',
    views: 1245
  },
  {
    id: 2,
    title: 'Configurando sua Primeira Organização',
    description: 'Passo a passo para criar e configurar uma organização do zero.',
    thumbnail: 'https://img.youtube.com/vi/J---aiyznGQ/hqdefault.jpg',
    duration: '8:17',
    views: 876
  },
  {
    id: 3,
    title: 'Gerenciando Usuários e Permissões',
    description: 'Aprenda a adicionar usuários e configurar seus níveis de acesso.',
    thumbnail: 'https://img.youtube.com/vi/VID123456/hqdefault.jpg',
    duration: '6:45',
    views: 932
  },
  {
    id: 4,
    title: 'Como Gerar e Interpretar Relatórios',
    description: 'Tutorial completo sobre o sistema de relatórios e análises.',
    thumbnail: 'https://img.youtube.com/vi/VID789101/hqdefault.jpg',
    duration: '10:22',
    views: 654
  }
];

export default function HelpCenter() {
  const [searchQuery, setSearchQuery] = useState("");
  const [supportMessage, setSupportMessage] = useState("");
  const [activeTab, setActiveTab] = useState("faq");
  
  const filteredFaqs = faqs.filter(faq => 
    faq.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
    faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSendMessage = () => {
    if (supportMessage.trim()) {
      alert("Mensagem enviada ao suporte. Responderemos em breve!");
      setSupportMessage("");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Central de Ajuda</h1>
        <p className="text-gray-500 mt-1">
          Encontre respostas, tutoriais e suporte para a plataforma Endurancy
        </p>
      </div>

      <div className="relative max-w-2xl mx-auto mb-8">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <Input
          placeholder="Pesquisar na Central de Ajuda..."
          className="pl-12 h-12 text-lg"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 h-auto p-1">
          <TabsTrigger value="faq" className="py-3">
            <div className="flex flex-col items-center gap-1">
              <HelpCircle className="w-5 h-5" />
              <span>FAQ</span>
            </div>
          </TabsTrigger>
          <TabsTrigger value="docs" className="py-3">
            <div className="flex flex-col items-center gap-1">
              <Book className="w-5 h-5" />
              <span>Documentação</span>
            </div>
          </TabsTrigger>
          <TabsTrigger value="videos" className="py-3">
            <div className="flex flex-col items-center gap-1">
              <PlayCircle className="w-5 h-5" />
              <span>Vídeos</span>
            </div>
          </TabsTrigger>
          <TabsTrigger value="support" className="py-3">
            <div className="flex flex-col items-center gap-1">
              <MessageSquare className="w-5 h-5" />
              <span>Suporte</span>
            </div>
          </TabsTrigger>
        </TabsList>
        
        {/* FAQ Tab */}
        <TabsContent value="faq" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-yellow-500" />
                  Sugestões Populares
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="p-4">
                      <CardTitle className="text-sm">Como gerenciar backups?</CardTitle>
                    </CardHeader>
                    <CardFooter className="p-4 pt-0">
                      <Button variant="ghost" className="w-full justify-between">
                        <span>Ver resposta</span>
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card>
                    <CardHeader className="p-4">
                      <CardTitle className="text-sm">Como exportar relatórios?</CardTitle>
                    </CardHeader>
                    <CardFooter className="p-4 pt-0">
                      <Button variant="ghost" className="w-full justify-between">
                        <span>Ver resposta</span>
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </CardFooter>
                  </Card>
                  <Card>
                    <CardHeader className="p-4">
                      <CardTitle className="text-sm">Como ativar 2FA?</CardTitle>
                    </CardHeader>
                    <CardFooter className="p-4 pt-0">
                      <Button variant="ghost" className="w-full justify-between">
                        <span>Ver resposta</span>
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              </CardContent>
            </Card>
            
            {searchQuery && (
              <div className="md:col-span-2 mb-4">
                <p className="text-gray-500">
                  {filteredFaqs.length} resultados para "{searchQuery}"
                </p>
              </div>
            )}
            
            {filteredFaqs.map((faq) => (
              <Card key={faq.id}>
                <CardHeader>
                  <Badge className="w-fit">{faq.category}</Badge>
                  <CardTitle className="text-lg">{faq.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{faq.answer}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="text-sm text-gray-500">
                    Foi útil?
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <ThumbsUp className="h-4 w-4" />
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        {/* Documentation Tab */}
        <TabsContent value="docs" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Categorias</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ul className="divide-y">
                    {docCategories.map((category) => (
                      <li key={category.id}>
                        <Button variant="ghost" className="w-full justify-start rounded-none h-auto py-3 px-4">
                          <div className="flex items-center gap-3">
                            {category.icon}
                            <div>
                              <p className="font-medium text-left">{category.name}</p>
                              <p className="text-xs text-gray-500 text-left">{category.count} artigos</p>
                            </div>
                          </div>
                        </Button>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
            
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Documentação</CardTitle>
                  <CardDescription>
                    Selecione uma categoria para ver os artigos relacionados
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 bg-blue-50 text-blue-800 p-4 rounded-lg mb-4">
                    <Info className="w-5 h-5 text-blue-500" />
                    <span>Selecione uma categoria no menu à esquerda para ver os artigos.</span>
                  </div>
                  
                  <div className="p-8 text-center text-gray-500">
                    <Book className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                    <h3 className="text-lg font-medium text-gray-700">Documentação completa</h3>
                    <p className="max-w-md mx-auto mt-2">
                      Nossa documentação inclui guias detalhados, tutoriais passo a passo e referências técnicas para ajudá-lo a tirar o máximo proveito da plataforma Endurancy.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        {/* Videos Tab */}
        <TabsContent value="videos" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {videoTutorials.map((video) => (
              <Card key={video.id} className="overflow-hidden">
                <div className="relative h-48 bg-gray-100">
                  <img 
                    src={video.thumbnail} 
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <PlayCircle className="w-16 h-16 text-white" />
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                    {video.duration}
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{video.title}</CardTitle>
                  <CardDescription>{video.description}</CardDescription>
                </CardHeader>
                <CardFooter className="flex justify-between">
                  <div className="text-sm text-gray-500">
                    {video.views} visualizações
                  </div>
                  <div className="flex">
                    <Star className="w-4 h-4 text-yellow-400" />
                    <Star className="w-4 h-4 text-yellow-400" />
                    <Star className="w-4 h-4 text-yellow-400" />
                    <Star className="w-4 h-4 text-yellow-400" />
                    <StarHalf className="w-4 h-4 text-yellow-400" />
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        {/* Support Tab */}
        <TabsContent value="support" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Entre em contato com o suporte</CardTitle>
                <CardDescription>
                  Nossa equipe de suporte está disponível para ajudar com quaisquer dúvidas ou problemas.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    Descreva sua dúvida ou problema
                  </label>
                  <Textarea 
                    id="message" 
                    placeholder="Digite sua mensagem aqui..." 
                    rows={6}
                    value={supportMessage}
                    onChange={(e) => setSupportMessage(e.target.value)}
                  />
                </div>
                
                <div className="bg-yellow-50 text-yellow-800 p-4 rounded-lg flex items-start gap-2">
                  <AlertTriangle className="w-5 h-5 text-yellow-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Tempo de resposta</p>
                    <p className="text-sm">
                      Nossa equipe responde em até 24 horas em dias úteis. Para emergências relacionadas à segurança, use o canal de emergência.
                    </p>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Limpar</Button>
                <Button 
                  className="gap-2 bg-green-600 hover:bg-green-700"
                  onClick={handleSendMessage}
                  disabled={!supportMessage.trim()}
                >
                  <Send className="w-4 h-4" />
                  Enviar Mensagem
                </Button>
              </CardFooter>
            </Card>
            
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Informações de Contato</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p className="font-medium">suporte@endurancy.com</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Telefone</p>
                    <p className="font-medium">+55 (11) 4321-1234</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Horário de Atendimento</p>
                    <p className="font-medium">Segunda a Sexta, 9h às 18h</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Status do Suporte</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-green-500"></div>
                    <span className="text-green-600 font-medium">Online</span>
                  </div>
                  <Separator className="my-4" />
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-green-500" />
                    <span>Tempo médio de resposta: 4 horas</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}