import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  File, 
  FileText, 
  Search, 
  Filter, 
  FilePlus, 
  Calendar, 
  Download, 
  Upload, 
  FolderPlus, 
  Trash2, 
  Edit, 
  Eye, 
  MoreHorizontal, 
  CheckCircle2, 
  Clock, 
  FileCheck, 
  Lock, 
  Tag, 
  Users,
  UploadCloud,
  Folder,
  FileArchive,
  FileLock,
  User,
  CheckSquare,
  X
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Dados simulados de documentos de RH
const mockDocumentos = [
  {
    id: "doc-001",
    nome: "Política de Recursos Humanos",
    categoria: "políticas",
    tipo: "pdf",
    tamanho: 2560000,
    dataCriacao: "2022-06-10",
    dataAtualizacao: "2023-02-15",
    autor: "Diretoria de RH",
    versao: "2.1",
    status: "ativo",
    acesso: "público",
    departamentos: ["Todos"],
    descricao: "Documento que estabelece as diretrizes gerais para a gestão de recursos humanos na organização",
    url: "#",
    tags: ["política", "RH", "diretrizes"],
    visualizacoes: 145
  },
  {
    id: "doc-002",
    nome: "Formulário de Avaliação de Desempenho",
    categoria: "formulários",
    tipo: "docx",
    tamanho: 580000,
    dataCriacao: "2023-01-05",
    dataAtualizacao: "2023-01-05",
    autor: "Departamento de RH",
    versao: "1.0",
    status: "ativo",
    acesso: "restrito",
    departamentos: ["RH", "Gestores"],
    descricao: "Formulário padronizado para avaliação semestral de desempenho dos colaboradores",
    url: "#",
    tags: ["avaliação", "desempenho", "formulário"],
    visualizacoes: 87
  },
  {
    id: "doc-003",
    nome: "Manual do Colaborador",
    categoria: "manuais",
    tipo: "pdf",
    tamanho: 4850000,
    dataCriacao: "2022-03-20",
    dataAtualizacao: "2023-03-10",
    autor: "Departamento de RH",
    versao: "3.2",
    status: "ativo",
    acesso: "público",
    departamentos: ["Todos"],
    descricao: "Manual com todas as informações necessárias para novos colaboradores e referência para os atuais",
    url: "#",
    tags: ["manual", "onboarding", "referência"],
    visualizacoes: 210
  },
  {
    id: "doc-004",
    nome: "Procedimento de Recrutamento e Seleção",
    categoria: "procedimentos",
    tipo: "pdf",
    tamanho: 1320000,
    dataCriacao: "2022-08-15",
    dataAtualizacao: "2023-01-20",
    autor: "Coordenação de RH",
    versao: "2.3",
    status: "ativo",
    acesso: "restrito",
    departamentos: ["RH"],
    descricao: "Procedimento detalhado para condução de processos de recrutamento e seleção de novos colaboradores",
    url: "#",
    tags: ["recrutamento", "seleção", "procedimento"],
    visualizacoes: 65
  },
  {
    id: "doc-005",
    nome: "Acordo Coletivo de Trabalho 2023",
    categoria: "legais",
    tipo: "pdf",
    tamanho: 3650000,
    dataCriacao: "2023-03-01",
    dataAtualizacao: "2023-03-01",
    autor: "Departamento Jurídico",
    versao: "1.0",
    status: "ativo",
    acesso: "público",
    departamentos: ["Todos"],
    descricao: "Acordo coletivo firmado entre a empresa e o sindicato para o ano de 2023",
    url: "#",
    tags: ["acordo", "sindicato", "legal"],
    visualizacoes: 178
  },
  {
    id: "doc-006",
    nome: "Planilha de Cálculo de Férias",
    categoria: "planilhas",
    tipo: "xlsx",
    tamanho: 890000,
    dataCriacao: "2022-11-10",
    dataAtualizacao: "2023-02-05",
    autor: "Departamento de RH",
    versao: "1.2",
    status: "ativo",
    acesso: "restrito",
    departamentos: ["RH", "Financeiro"],
    descricao: "Planilha para cálculo automático de valores de férias conforme legislação vigente",
    url: "#",
    tags: ["férias", "cálculo", "planilha"],
    visualizacoes: 42
  },
  {
    id: "doc-007",
    nome: "Código de Ética e Conduta",
    categoria: "políticas",
    tipo: "pdf",
    tamanho: 1850000,
    dataCriacao: "2021-05-20",
    dataAtualizacao: "2023-04-10",
    autor: "Diretoria Executiva",
    versao: "2.5",
    status: "ativo",
    acesso: "público",
    departamentos: ["Todos"],
    descricao: "Documento que estabelece os princípios éticos e normas de conduta a serem seguidos por todos os colaboradores",
    url: "#",
    tags: ["ética", "conduta", "compliance"],
    visualizacoes: 230
  },
  {
    id: "doc-008",
    nome: "Programa de Integração de Novos Colaboradores",
    categoria: "programas",
    tipo: "pptx",
    tamanho: 6750000,
    dataCriacao: "2022-07-12",
    dataAtualizacao: "2023-02-28",
    autor: "Treinamento e Desenvolvimento",
    versao: "2.1",
    status: "ativo",
    acesso: "restrito",
    departamentos: ["RH", "Gestores"],
    descricao: "Apresentação detalhada do programa de integração e onboarding de novos colaboradores",
    url: "#",
    tags: ["integração", "onboarding", "treinamento"],
    visualizacoes: 89
  },
  {
    id: "doc-009",
    nome: "Termo de Confidencialidade",
    categoria: "modelos",
    tipo: "docx",
    tamanho: 420000,
    dataCriacao: "2022-09-05",
    dataAtualizacao: "2022-09-05",
    autor: "Departamento Jurídico",
    versao: "1.0",
    status: "ativo",
    acesso: "restrito",
    departamentos: ["RH", "Jurídico"],
    descricao: "Modelo de termo de confidencialidade a ser assinado por colaboradores com acesso a informações sensíveis",
    url: "#",
    tags: ["confidencialidade", "segurança", "termo"],
    visualizacoes: 54
  },
  {
    id: "doc-010",
    nome: "Política de Trabalho Remoto",
    categoria: "políticas",
    tipo: "pdf",
    tamanho: 1250000,
    dataCriacao: "2022-03-20",
    dataAtualizacao: "2023-01-15",
    autor: "Diretoria de RH",
    versao: "1.3",
    status: "ativo",
    acesso: "público",
    departamentos: ["Todos"],
    descricao: "Diretrizes e regras para o regime de trabalho remoto e híbrido na organização",
    url: "#",
    tags: ["remoto", "híbrido", "home office"],
    visualizacoes: 195
  },
  {
    id: "doc-011",
    nome: "Checklist de Desligamento",
    categoria: "formulários",
    tipo: "pdf",
    tamanho: 380000,
    dataCriacao: "2022-10-10",
    dataAtualizacao: "2022-10-10",
    autor: "Departamento de RH",
    versao: "1.0",
    status: "ativo",
    acesso: "restrito",
    departamentos: ["RH"],
    descricao: "Lista de verificação para procedimentos de desligamento de colaboradores",
    url: "#",
    tags: ["desligamento", "checklist", "offboarding"],
    visualizacoes: 38
  },
  {
    id: "doc-012",
    nome: "Plano de Cargos e Salários",
    categoria: "políticas",
    tipo: "pdf",
    tamanho: 2980000,
    dataCriacao: "2021-08-15",
    dataAtualizacao: "2023-03-20",
    autor: "Diretoria de RH",
    versao: "3.0",
    status: "ativo",
    acesso: "confidencial",
    departamentos: ["RH", "Diretoria"],
    descricao: "Estrutura completa de cargos e faixas salariais da organização",
    url: "#",
    tags: ["cargos", "salários", "carreira"],
    visualizacoes: 25
  }
];

// Categorias de documentos
const categorias = [
  { value: "todas", label: "Todas as categorias" },
  { value: "políticas", label: "Políticas e Normas" },
  { value: "procedimentos", label: "Procedimentos" },
  { value: "formulários", label: "Formulários" },
  { value: "manuais", label: "Manuais" },
  { value: "legais", label: "Documentos Legais" },
  { value: "planilhas", label: "Planilhas" },
  { value: "modelos", label: "Modelos de Documentos" },
  { value: "programas", label: "Programas e Apresentações" }
];

// Níveis de acesso
const niveisAcesso = [
  { value: "todos", label: "Todos os níveis" },
  { value: "público", label: "Público" },
  { value: "restrito", label: "Restrito" },
  { value: "confidencial", label: "Confidencial" }
];

export default function RhDocumentos() {
  const [documentos, setDocumentos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoriaFiltro, setCategoriaFiltro] = useState("todas");
  const [acessoFiltro, setAcessoFiltro] = useState("todos");
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [showPreviewDialog, setShowPreviewDialog] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [activeTab, setActiveTab] = useState("todos");
  const [versoesAnteriores, setVersoesAnteriores] = useState([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  // Estado para o novo documento
  const [newDocument, setNewDocument] = useState({
    nome: "",
    categoria: "",
    acesso: "público",
    departamentos: [],
    descricao: "",
    tags: ""
  });

  useEffect(() => {
    // Simular carregamento de dados
    setTimeout(() => {
      setDocumentos(mockDocumentos);
      setIsLoading(false);
    }, 800);
  }, []);

  // Filtrar documentos
  const filteredDocumentos = documentos.filter(doc => {
    // Filtro de texto
    const matchesSearch = 
      doc.nome.toLowerCase().includes(searchTerm.toLowerCase()) || 
      doc.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (doc.tags && doc.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())));
    
    // Filtro de categoria
    const matchesCategoria = categoriaFiltro === "todas" || doc.categoria === categoriaFiltro;
    
    // Filtro de acesso
    const matchesAcesso = acessoFiltro === "todos" || doc.acesso === acessoFiltro;
    
    // Filtro de aba (todos/meus/favoritos)
    const matchesTab = activeTab === "todos" ||
                       (activeTab === "meus" && doc.autor === "Departamento de RH") ||
                       (activeTab === "favoritos" && doc.id.includes("00")); // Simulação de favoritos
    
    return matchesSearch && matchesCategoria && matchesAcesso && matchesTab;
  });

  const handleViewDocument = (doc) => {
    setSelectedDocument(doc);
    
    // Simulação de versões anteriores
    const versoesSimilares = [
      {
        versao: "2.0",
        dataAtualizacao: "2022-12-05",
        autor: doc.autor,
        mudancas: "Atualização das seções 3 e 4 conforme nova legislação."
      },
      {
        versao: "1.5",
        dataAtualizacao: "2022-08-20",
        autor: doc.autor,
        mudancas: "Correções menores e melhorias na formatação."
      },
      {
        versao: "1.0",
        dataAtualizacao: "2022-02-15",
        autor: doc.autor,
        mudancas: "Versão inicial do documento."
      }
    ];
    
    setVersoesAnteriores(versoesSimilares);
    setShowPreviewDialog(true);
  };

  const handleStartUpload = () => {
    setIsUploading(true);
    
    // Simulação de progresso de upload
    let progress = 0;
    const interval = setInterval(() => {
      progress += 5;
      setUploadProgress(progress);
      
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsUploading(false);
          setShowUploadDialog(false);
          // Resetar formulário
          setNewDocument({
            nome: "",
            categoria: "",
            acesso: "público",
            departamentos: [],
            descricao: "",
            tags: ""
          });
          setUploadProgress(0);
          // Adicionar documento fictício à lista
          const novoDoc = {
            id: `doc-${Math.floor(Math.random() * 1000)}`,
            nome: newDocument.nome || "Novo Documento",
            categoria: newDocument.categoria || "políticas",
            tipo: "pdf",
            tamanho: 1250000,
            dataCriacao: new Date().toISOString().split('T')[0],
            dataAtualizacao: new Date().toISOString().split('T')[0],
            autor: "Departamento de RH",
            versao: "1.0",
            status: "ativo",
            acesso: newDocument.acesso,
            departamentos: newDocument.departamentos.length > 0 ? newDocument.departamentos : ["RH"],
            descricao: newDocument.descricao || "Descrição não fornecida",
            url: "#",
            tags: newDocument.tags ? newDocument.tags.split(',').map(tag => tag.trim()) : [],
            visualizacoes: 0
          };
          setDocumentos([novoDoc, ...documentos]);
        }, 500);
      }
    }, 200);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Documentos de RH</h1>
          <p className="text-gray-500 mt-1">
            Gerencie todos os documentos relacionados ao departamento de Recursos Humanos
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <FolderPlus className="mr-2 h-4 w-4" />
            Nova Pasta
          </Button>
          <Button className="bg-green-600 hover:bg-green-700" onClick={() => setShowUploadDialog(true)}>
            <FilePlus className="mr-2 h-4 w-4" />
            Novo Documento
          </Button>
        </div>
      </div>

      <Tabs defaultValue="todos" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="todos">Todos os Documentos</TabsTrigger>
          <TabsTrigger value="meus">Meus Documentos</TabsTrigger>
          <TabsTrigger value="favoritos">Favoritos</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row gap-4 sm:items-center justify-between">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar documentos..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={categoriaFiltro} onValueChange={setCategoriaFiltro}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Categoria" />
                </SelectTrigger>
                <SelectContent>
                  {categorias.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={acessoFiltro} onValueChange={setAcessoFiltro}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Nível de Acesso" />
                </SelectTrigger>
                <SelectContent>
                  {niveisAcesso.map((nivel) => (
                    <SelectItem key={nivel.value} value={nivel.value}>
                      {nivel.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
            </div>
          ) : filteredDocumentos.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40%]">Nome</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Versão</TableHead>
                    <TableHead>Atualizado</TableHead>
                    <TableHead>Acesso</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDocumentos.map((doc) => (
                    <TableRow key={doc.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-3">
                          {getDocumentIcon(doc.tipo)}
                          <div>
                            <p className="font-medium">{doc.nome}</p>
                            <p className="text-xs text-gray-500 line-clamp-1">{doc.descricao}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {doc.categoria}
                        </Badge>
                      </TableCell>
                      <TableCell className="uppercase">{doc.tipo}</TableCell>
                      <TableCell>v{doc.versao}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="text-sm">{formatDate(doc.dataAtualizacao)}</span>
                          <span className="text-xs text-gray-500">{doc.autor}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          doc.acesso === 'público' ? 'bg-green-100 text-green-800' : 
                          doc.acesso === 'restrito' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }>
                          {doc.acesso}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <span className="sr-only">Abrir menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewDocument(doc)}>
                              <Eye className="mr-2 h-4 w-4" />
                              Visualizar
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Download className="mr-2 h-4 w-4" />
                              Download
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <FileCheck className="mr-2 h-4 w-4" />
                              Verificar assinaturas
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Users className="mr-2 h-4 w-4" />
                              Gerenciar permissões
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-10">
              <FileText className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-medium">Nenhum documento encontrado</h3>
              <p className="text-gray-500 mt-1">
                Tente ajustar os filtros ou faça o upload de novos documentos.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Diálogo de Upload de Documento */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Adicionar Novo Documento</DialogTitle>
            <DialogDescription>
              Faça upload de um novo documento ou crie um documento no sistema.
            </DialogDescription>
          </DialogHeader>
          
          {isUploading ? (
            <div className="space-y-4 py-4">
              <div className="text-center">
                <UploadCloud className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-lg font-medium">Enviando documento...</h3>
                <p className="text-gray-500 mb-4">O upload está em andamento, não feche esta janela.</p>
                
                <Progress value={uploadProgress} className="h-2 mb-2" />
                <p className="text-sm text-gray-500">{uploadProgress}% concluído</p>
              </div>
            </div>
          ) : (
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="file">Arquivo</Label>
                <div className="border-2 border-dashed rounded-lg p-6 text-center border-gray-300 hover:border-green-600 transition-colors">
                  <UploadCloud className="h-10 w-10 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm font-medium mb-1">Clique para selecionar um arquivo ou arraste e solte</p>
                  <p className="text-xs text-gray-500 mb-3">PDF, DOCX, XLSX, PPTX (Max. 20MB)</p>
                  <Button size="sm" variant="outline">Escolher arquivo</Button>
                  <input type="file" id="file" className="hidden" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="doc-name">Nome do documento</Label>
                  <Input 
                    id="doc-name" 
                    placeholder="Digite o nome do documento" 
                    value={newDocument.nome}
                    onChange={(e) => setNewDocument({...newDocument, nome: e.target.value})}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="doc-category">Categoria</Label>
                    <Select
                      value={newDocument.categoria}
                      onValueChange={(value) => setNewDocument({...newDocument, categoria: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categorias.filter(cat => cat.value !== "todas").map((cat) => (
                          <SelectItem key={cat.value} value={cat.value}>
                            {cat.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="doc-access">Nível de acesso</Label>
                    <Select
                      value={newDocument.acesso}
                      onValueChange={(value) => setNewDocument({...newDocument, acesso: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o nível de acesso" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="público">Público</SelectItem>
                        <SelectItem value="restrito">Restrito</SelectItem>
                        <SelectItem value="confidencial">Confidencial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Departamentos com acesso</Label>
                  <div className="border rounded-md p-4 space-y-2">
                    {["RH", "Diretoria", "Produção", "Qualidade", "Cultivo", "Financeiro", "Marketing", "Jurídico", "TI"].map(dep => (
                      <div key={dep} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`department-${dep}`} 
                          checked={newDocument.departamentos.includes(dep)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setNewDocument({
                                ...newDocument, 
                                departamentos: [...newDocument.departamentos, dep]
                              });
                            } else {
                              setNewDocument({
                                ...newDocument, 
                                departamentos: newDocument.departamentos.filter(d => d !== dep)
                              });
                            }
                          }}
                        />
                        <label
                          htmlFor={`department-${dep}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {dep}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="doc-description">Descrição</Label>
                  <Input 
                    id="doc-description" 
                    placeholder="Digite uma breve descrição do documento" 
                    value={newDocument.descricao}
                    onChange={(e) => setNewDocument({...newDocument, descricao: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="doc-tags">Tags (separadas por vírgula)</Label>
                  <Input 
                    id="doc-tags" 
                    placeholder="Ex: política, manual, treinamento" 
                    value={newDocument.tags}
                    onChange={(e) => setNewDocument({...newDocument, tags: e.target.value})}
                  />
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUploadDialog(false)} disabled={isUploading}>
              Cancelar
            </Button>
            <Button onClick={handleStartUpload} disabled={isUploading}>
              {isUploading ? "Enviando..." : "Enviar documento"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de Visualização de Documento */}
      {selectedDocument && (
        <Dialog open={showPreviewDialog} onOpenChange={setShowPreviewDialog}>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Visualizar Documento</DialogTitle>
              <DialogDescription>
                {selectedDocument.nome}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Coluna 1: Preview do documento */}
              <div className="lg:col-span-2 space-y-4">
                <div className="bg-gray-100 rounded-md p-4 h-96 flex flex-col justify-center items-center">
                  <FileText className="h-16 w-16 text-gray-400 mb-4" />
                  <p className="text-center text-gray-500 mb-4">Pré-visualização não disponível</p>
                  <Button>
                    <Eye className="mr-2 h-4 w-4" />
                    Abrir documento
                  </Button>
                </div>
                
                <div className="flex justify-between">
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Edit className="mr-2 h-4 w-4" />
                      Editar
                    </Button>
                    <Button variant="outline" size="sm" className="text-red-600">
                      <Trash2 className="mr-2 h-4 w-4" />
                      Excluir
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Coluna 2: Detalhes do documento */}
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">{selectedDocument.nome}</h3>
                  <p className="text-gray-600 text-sm">{selectedDocument.descricao}</p>
                  
                  <div className="flex flex-wrap gap-1 mt-2">
                    {selectedDocument.tags && selectedDocument.tags.map((tag, index) => (
                      <Badge key={index} variant="outline" className="capitalize">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">DETALHES</h4>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-gray-500">Categoria:</div>
                    <div className="capitalize">{selectedDocument.categoria}</div>
                    
                    <div className="text-gray-500">Tipo:</div>
                    <div className="uppercase">{selectedDocument.tipo}</div>
                    
                    <div className="text-gray-500">Tamanho:</div>
                    <div>{formatFileSize(selectedDocument.tamanho)}</div>
                    
                    <div className="text-gray-500">Versão:</div>
                    <div>v{selectedDocument.versao}</div>
                    
                    <div className="text-gray-500">Criado em:</div>
                    <div>{formatDate(selectedDocument.dataCriacao)}</div>
                    
                    <div className="text-gray-500">Atualizado em:</div>
                    <div>{formatDate(selectedDocument.dataAtualizacao)}</div>
                    
                    <div className="text-gray-500">Autor:</div>
                    <div>{selectedDocument.autor}</div>
                    
                    <div className="text-gray-500">Nível de acesso:</div>
                    <div className="capitalize">{selectedDocument.acesso}</div>
                    
                    <div className="text-gray-500">Visualizações:</div>
                    <div>{selectedDocument.visualizacoes}</div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">DEPARTAMENTOS COM ACESSO</h4>
                  <div className="flex flex-wrap gap-1">
                    {selectedDocument.departamentos.map((dep, index) => (
                      <Badge key={index} variant="secondary" className="bg-gray-100">
                        {dep}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium text-sm text-gray-500">HISTÓRICO DE VERSÕES</h4>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm bg-green-50 p-2 rounded-md">
                      <div>
                        <span className="font-medium">v{selectedDocument.versao}</span>
                        <span className="mx-2">•</span>
                        <span>{formatDate(selectedDocument.dataAtualizacao)}</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Atual</Badge>
                    </div>
                    
                    {versoesAnteriores.map((versao, index) => (
                      <div key={index} className="flex justify-between items-center text-sm p-2 rounded-md hover:bg-gray-50">
                        <div>
                          <span className="font-medium">v{versao.versao}</span>
                          <span className="mx-2">•</span>
                          <span>{formatDate(versao.dataAtualizacao)}</span>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Eye className="h-3 w-3 mr-1" />
                          Ver
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowPreviewDialog(false)}>
                Fechar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// Função para formatar data
function formatDate(dateString) {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).format(date);
}

// Função para formatar tamanho de arquivo
function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Função para obter ícone baseado no tipo de documento
function getDocumentIcon(type) {
  switch (type.toLowerCase()) {
    case 'pdf':
      return <FileText className="h-8 w-8 text-red-500" />;
    case 'docx':
    case 'doc':
      return <FileText className="h-8 w-8 text-blue-500" />;
    case 'xlsx':
    case 'xls':
      return <FileText className="h-8 w-8 text-green-500" />;
    case 'pptx':
    case 'ppt':
      return <FileText className="h-8 w-8 text-orange-500" />;
    default:
      return <File className="h-8 w-8 text-gray-500" />;
  }
}