import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Save,
  Settings as SettingsIcon,
  Mail,
  Bell,
  Shield,
  KeyRound,
  UploadCloud,
  CheckCircle,
  AlertTriangle,
  FileText,
  Building2,
  Monitor,
  Terminal,
  Database,
  Info,
  FileDown
} from "lucide-react";
import { toast } from "@/components/ui/use-toast";

// Simple Document Viewer Component
const DocumentViewer = ({ content }) => {
  return (
    <div className="h-[500px] w-full rounded-md border p-4 overflow-auto prose prose-sm max-w-none">
      <pre className="whitespace-pre-wrap font-sans text-sm">{content}</pre>
    </div>
  );
};

export default function Settings() {
  const [activeTab, setActiveTab] = useState("general");
  const [isLoading, setIsLoading] = useState(false);

  // General Settings State
  const [generalSettings, setGeneralSettings] = useState({
    platformName: "Endurancy",
    logoUrl: "/assets/logo.png",
    primaryColor: "#10b981",
    enableMaintenance: false,
    enablePublicRegistration: true,
    defaultLanguage: "pt-BR",
    timezone: "America/Sao_Paulo"
  });

  // Security Settings State
  const [securitySettings, setSecuritySettings] = useState({
    passwordMinLength: 8,
    passwordRequireUppercase: true,
    passwordRequireNumbers: true,
    passwordRequireSymbols: false,
    passwordExpiryDays: 90,
    enableTwoFactor: true,
    sessionTimeout: 30,
    maxLoginAttempts: 5,
    ipLockoutTime: 15
  });

  // Notification Settings State
  const [notificationSettings, setNotificationSettings] = useState({
    enableEmailNotifications: true,
    enablePushNotifications: true,
    notifyOnNewRegistration: true,
    notifyOnLogin: false,
    notifyOnPasswordChange: true,
    digestFrequency: "daily",
    adminAlertEmails: "admin@endurancy.com.br"
  });

  // Integration Settings State
  const [integrationSettings, setIntegrationSettings] = useState({
    enableApiAccess: true,
    enableWebhooks: true,
    apiThrottleLimit: 100,
    webhookRetryAttempts: 3,
    webhookTimeout: 10
  });

  // Documentation content
  const documentationContent = {
    platform: `# Plataforma Endurancy

A plataforma Endurancy é uma solução completa para gestão de organizações no setor de cannabis medicinal no Brasil, integrando os processos de cultivo, produção, controle de qualidade, prescrição médica e atendimento ao paciente.

## Visão Geral

O Endurancy foi projetado especificamente para atender às necessidades únicas de:

- **Associações de cannabis medicinal**
- **Empresas produtoras e distribuidoras**
- **Médicos prescritores**
- **Pacientes e usuários finais**

A plataforma oferece uma experiência integrada que conecta todos os stakeholders do ecossistema, garantindo rastreabilidade completa, conformidade regulatória e eficiência operacional.

## Módulos Principais

1. **Super Admin** - Gestão central da plataforma, usuários e organizações
2. **Cultivo** - Controle de plantio, colheita e rastreabilidade
3. **Produção** - Gerenciamento de processos produtivos e controle de qualidade
4. **CRM** - Gerenciamento de relacionamento com pacientes e médicos
5. **Financeiro** - Gestão financeira completa com integração de pagamentos
6. **Jurídico** - Controle de processos jurídicos e compliance
7. **Transparência** - Portal de transparência para associações

## Benefícios

- Conformidade com regulamentações da ANVISA e legislação brasileira
- Rastreabilidade completa do cultivo ao paciente
- Redução de custos operacionais e administrativos
- Melhoria na experiência do paciente
- Integração com sistemas de telemedicina
- Suporte a múltiplos modelos de negócio no setor`,

    development: `# Guia de Desenvolvimento

Este guia fornece informações essenciais para desenvolvedores que trabalham na plataforma Endurancy.

## Arquitetura

A plataforma é construída com uma arquitetura modular baseada em:

- **Frontend**: React.js com Tailwind CSS e componentes Shadcn/UI
- **Backend**: APIs RESTful
- **Persistência**: Banco de dados relacional com esquemas JSON para flexibilidade
- **PWA**: Progressive Web App para o Portal do Paciente

## Stack Tecnológico

- React.js
- Tailwind CSS
- Shadcn/UI
- Lucide Icons
- React Router
- React Hook Form
- date-fns para manipulação de datas
- recharts para visualizações
- Integração com serviços de pagamento

## Estrutura do Código

O código está organizado da seguinte forma:

- **/entities** - Definições de entidades e esquemas
- **/pages** - Componentes de página
- **/components** - Componentes reutilizáveis
- **/integrations** - Integrações com serviços externos
- **/utils** - Funções utilitárias

## Padrões de Desenvolvimento

- Componentes funcionais com React Hooks
- Estrutura modular para facilitar manutenção
- Abordagem responsiva Mobile-First
- Separação clara entre UI e lógica de negócios
- Internacionalização pronta para múltiplos idiomas`,

    legal: `# Documentação Legal

## Licença

A plataforma Endurancy é fornecida sob a licença MIT, que permite uso, modificação e distribuição do software, desde que mantidos os avisos de copyright e licença.

## Termos de Uso

Os usuários da plataforma Endurancy devem aderir aos Termos de Uso, que incluem:

- Uso adequado da plataforma
- Responsabilidades do usuário
- Limitações de responsabilidade
- Políticas de confidencialidade
- Disposições sobre propriedade intelectual

## Política de Privacidade

A Política de Privacidade da Endurancy abrange:

- Dados coletados e sua finalidade
- Compartilhamento de informações
- Direitos dos usuários sobre seus dados
- Medidas de segurança implementadas
- Procedimentos em caso de incidentes

## Compliance Regulatório

A plataforma foi projetada para atender requisitos regulatórios específicos:

- LGPD (Lei Geral de Proteção de Dados)
- Regulamentações da ANVISA para cannabis medicinal
- RDC 327/2019 e legislação relacionada
- Requisitos para associações de pacientes
- Conformidade com prescrição médica digital`,

    pwa: `# Portal do Paciente (PWA)

O Portal do Paciente Endurancy é uma Progressive Web App (PWA) que permite aos pacientes acessarem suas informações médicas, prescrições e gerenciarem seu tratamento de forma integrada.

## Funcionalidades Principais

- Visualização e download de prescrições médicas
- Histórico de consultas e tratamentos
- Lembretes de medicação personalizados
- Registro de sintomas e efeitos colaterais
- Comunicação direta com equipe médica
- Solicitação de novas consultas

## Instalação e Uso

O Portal do Paciente pode ser instalado como um aplicativo nos dispositivos dos pacientes:

### No Android
1. Abra o Portal no Chrome
2. Toque em "Adicionar à tela inicial"
3. Siga as instruções na tela

### No iOS
1. Abra o Portal no Safari
2. Toque no ícone de compartilhamento
3. Selecione "Adicionar à Tela de Início"

### No Desktop
1. Acesse o Portal no Chrome ou Edge
2. Clique no ícone de instalação na barra de endereço
3. Confirme a instalação

## Recursos Offline

O Portal funciona mesmo sem conexão à internet:
- Acesso a prescrições já baixadas
- Registro de uso de medicamentos
- Diário de sintomas
- Sincronização automática quando online`,

    api: `# Documentação da API

A API Endurancy permite a integração com sistemas externos e o desenvolvimento de extensões para a plataforma.

## Autenticação

Todas as requisições à API requerem autenticação usando tokens JWT:

\`\`\`
Authorization: Bearer {seu_token_jwt}
\`\`\`

## Endpoints Principais

### Organizações

- GET /api/organizations - Lista organizações
- POST /api/organizations - Cria nova organização
- GET /api/organizations/{id} - Detalhes da organização
- PUT /api/organizations/{id} - Atualiza organização
- DELETE /api/organizations/{id} - Remove organização

### Pacientes

- GET /api/patients - Lista pacientes
- POST /api/patients - Cadastra novo paciente
- GET /api/patients/{id} - Detalhes do paciente
- PUT /api/patients/{id} - Atualiza dados do paciente

### Prescrições

- GET /api/prescriptions - Lista prescrições
- POST /api/prescriptions - Cria nova prescrição
- GET /api/prescriptions/{id} - Detalhes da prescrição
- PUT /api/prescriptions/{id} - Atualiza prescrição

### Produtos

- GET /api/products - Lista produtos
- POST /api/products - Cadastra novo produto
- GET /api/products/{id} - Detalhes do produto
- PUT /api/products/{id} - Atualiza produto

## Webhooks

A plataforma oferece webhooks para notificações em tempo real:

- organization.created
- prescription.approved
- prescription.rejected
- patient.registered
- order.created
- order.status_changed

## Limitações

- Rate limit: 100 requisições por minuto
- Tamanho máximo de payload: 10MB
- Timeout: 30 segundos`
  };

  // Handle input changes for different settings
  const handleGeneralChange = (e) => {
    const { name, value, type, checked } = e.target;
    setGeneralSettings({
      ...generalSettings,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSecurityChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSecuritySettings({
      ...securitySettings,
      [name]: type === 'checkbox' ? checked : type === 'number' ? parseInt(value) : value
    });
  };

  const handleNotificationChange = (e) => {
    const { name, value, type, checked } = e.target;
    setNotificationSettings({
      ...notificationSettings,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleIntegrationChange = (e) => {
    const { name, value, type, checked } = e.target;
    setIntegrationSettings({
      ...integrationSettings,
      [name]: type === 'checkbox' ? checked : type === 'number' ? parseInt(value) : value
    });
  };

  const handleSwitchChange = (settingsType, name, checked) => {
    switch (settingsType) {
      case 'general':
        setGeneralSettings({ ...generalSettings, [name]: checked });
        break;
      case 'security':
        setSecuritySettings({ ...securitySettings, [name]: checked });
        break;
      case 'notifications':
        setNotificationSettings({ ...notificationSettings, [name]: checked });
        break;
      case 'integrations':
        setIntegrationSettings({ ...integrationSettings, [name]: checked });
        break;
      default:
        break;
    }
  };

  const saveSettings = (settingsType) => {
    setIsLoading(true);
    
    // Simulando uma solicitação de API
    setTimeout(() => {
      toast({
        title: "Configurações salvas com sucesso",
        description: "As alterações foram aplicadas ao sistema.",
      });
      setIsLoading(false);
    }, 800);
  };

  // Function to download documentation
  const handleDownloadDoc = (content, filename) => {
    const element = document.createElement("a");
    const file = new Blob([content], {type: 'text/markdown'});
    element.href = URL.createObjectURL(file);
    element.download = filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Configurações do Sistema</h1>
          <p className="text-gray-500 mt-1">
            Gerencie as configurações da plataforma Endurancy
          </p>
        </div>
      </div>

      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-5 mb-8">
          <TabsTrigger value="general" className="flex items-center gap-2">
            <SettingsIcon className="w-4 h-4" />
            <span>Geral</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            <span>Segurança</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            <span>Notificações</span>
          </TabsTrigger>
          <TabsTrigger value="integrations" className="flex items-center gap-2">
            <Terminal className="w-4 h-4" />
            <span>Integrações</span>
          </TabsTrigger>
          <TabsTrigger value="documentation" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            <span>Documentação</span>
          </TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Configurações Gerais</CardTitle>
                  <CardDescription>
                    Configure as informações básicas da plataforma
                  </CardDescription>
                </div>
                <Button className="gap-2" onClick={() => saveSettings('general')}>
                  <Save className="w-4 h-4" />
                  Salvar Alterações
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* General settings form content goes here */}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Configurações de Segurança</CardTitle>
                  <CardDescription>
                    Defina as políticas de segurança e autenticação
                  </CardDescription>
                </div>
                <Button className="gap-2" onClick={() => saveSettings('security')}>
                  <Save className="w-4 h-4" />
                  Salvar Alterações
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Security settings form content goes here */}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Configurações de Notificações</CardTitle>
                  <CardDescription>
                    Configure as notificações do sistema
                  </CardDescription>
                </div>
                <Button className="gap-2" onClick={() => saveSettings('notifications')}>
                  <Save className="w-4 h-4" />
                  Salvar Alterações
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Notification settings form content goes here */}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Integration Settings */}
        <TabsContent value="integrations">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Configurações de Integrações</CardTitle>
                  <CardDescription>
                    Configure integrações e APIs
                  </CardDescription>
                </div>
                <Button className="gap-2" onClick={() => saveSettings('integrations')}>
                  <Save className="w-4 h-4" />
                  Salvar Alterações
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Integration settings form content goes here */}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Documentation Tab */}
        <TabsContent value="documentation">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Documentação da Plataforma</CardTitle>
                <CardDescription>
                  Acesse documentação técnica, guias de uso e informações legais da plataforma Endurancy
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="platform">
                  <TabsList className="mb-4">
                    <TabsTrigger value="platform">Plataforma</TabsTrigger>
                    <TabsTrigger value="development">Desenvolvimento</TabsTrigger>
                    <TabsTrigger value="legal">Legal</TabsTrigger>
                    <TabsTrigger value="pwa">Portal do Paciente (PWA)</TabsTrigger>
                    <TabsTrigger value="api-docs">API</TabsTrigger>
                  </TabsList>

                  {/* Platform Documentation */}
                  <TabsContent value="platform">
                    <div className="grid gap-6">
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                          <CardTitle>Visão Geral da Plataforma</CardTitle>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="gap-2"
                            onClick={() => handleDownloadDoc(documentationContent.platform, "plataforma-visao-geral.md")}
                          >
                            <FileDown className="w-4 h-4" /> 
                            Exportar
                          </Button>
                        </CardHeader>
                        <CardContent>
                          <DocumentViewer content={documentationContent.platform} />
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  {/* Development Documentation */}
                  <TabsContent value="development">
                    <div className="grid gap-6">
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                          <CardTitle>Guia de Desenvolvimento</CardTitle>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="gap-2"
                            onClick={() => handleDownloadDoc(documentationContent.development, "guia-desenvolvimento.md")}
                          >
                            <FileDown className="w-4 h-4" /> 
                            Exportar
                          </Button>
                        </CardHeader>
                        <CardContent>
                          <DocumentViewer content={documentationContent.development} />
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  {/* Legal Documentation */}
                  <TabsContent value="legal">
                    <div className="grid gap-6">
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                          <CardTitle>Documentação Legal</CardTitle>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="gap-2"
                            onClick={() => handleDownloadDoc(documentationContent.legal, "documentacao-legal.md")}
                          >
                            <FileDown className="w-4 h-4" /> 
                            Exportar
                          </Button>
                        </CardHeader>
                        <CardContent>
                          <DocumentViewer content={documentationContent.legal} />
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  {/* PWA Documentation */}
                  <TabsContent value="pwa">
                    <div className="grid gap-6">
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                          <CardTitle>Portal do Paciente (PWA)</CardTitle>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="gap-2"
                            onClick={() => handleDownloadDoc(documentationContent.pwa, "portal-paciente-pwa.md")}
                          >
                            <FileDown className="w-4 h-4" /> 
                            Exportar
                          </Button>
                        </CardHeader>
                        <CardContent>
                          <DocumentViewer content={documentationContent.pwa} />
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  {/* API Documentation */}
                  <TabsContent value="api-docs">
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle>Documentação da API</CardTitle>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="gap-2"
                          onClick={() => handleDownloadDoc(documentationContent.api, "documentacao-api.md")}
                        >
                          <FileDown className="w-4 h-4" /> 
                          Exportar
                        </Button>
                      </CardHeader>
                      <CardContent>
                        <DocumentViewer content={documentationContent.api} />
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}