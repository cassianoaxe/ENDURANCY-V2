import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowLeftRight,
  Save,
  X,
  Plus,
  Minus,
  Calendar
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function NovaMovimentacaoEstoque() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [tipoMovimentacao, setTipoMovimentacao] = useState("entrada");
  const [origem, setOrigem] = useState("");
  const [destino, setDestino] = useState("");
  const [motivo, setMotivo] = useState("");
  const [observacoes, setObservacoes] = useState("");
  const [documentoRef, setDocumentoRef] = useState("");
  const [items, setItems] = useState([
    { id: 1, produto_id: "", lote: "", quantidade: 1, unidade_medida: "" }
  ]);
  const [produtos, setProdutos] = useState([]);
  const [origens, setOrigens] = useState([]);
  const [destinos, setDestinos] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      // Mock produtos data
      const mockProdutos = [
        { id: "prod1", nome: "Extrato CBD Full Spectrum", tipo: "materia_prima" },
        { id: "prod2", nome: "Óleo MCT", tipo: "materia_prima" },
        { id: "prod3", nome: "Frasco Âmbar 30ml", tipo: "embalagem" },
        { id: "prod4", nome: "Óleo CBD 10% Full Spectrum", tipo: "produto_acabado" }
      ];

      // Mock locais
      const mockLocais = [
        "Fornecedor",
        "Almoxarifado MP",
        "Produção",
        "Controle de Qualidade",
        "Almoxarifado PA",
        "Expedição",
        "Descarte"
      ];

      setProdutos(mockProdutos);
      setOrigens(mockLocais);
      setDestinos(mockLocais);
      
      // Set default values based on movement type
      if (tipoMovimentacao === "entrada") {
        setOrigem("Fornecedor");
        setDestino("Almoxarifado MP");
      } else if (tipoMovimentacao === "saida") {
        setOrigem("Almoxarifado PA");
        setDestino("Expedição");
      } else if (tipoMovimentacao === "transferencia") {
        setOrigem("Almoxarifado MP");
        setDestino("Produção");
      } else if (tipoMovimentacao === "descarte") {
        setOrigem("Controle de Qualidade");
        setDestino("Descarte");
      }

      setLoading(false);
    };

    loadData();
  }, []);

  // Update defaults when movement type changes
  useEffect(() => {
    if (tipoMovimentacao === "entrada") {
      setOrigem("Fornecedor");
      setDestino("Almoxarifado MP");
    } else if (tipoMovimentacao === "saida") {
      setOrigem("Almoxarifado PA");
      setDestino("Expedição");
    } else if (tipoMovimentacao === "transferencia") {
      setOrigem("Almoxarifado MP");
      setDestino("Produção");
    } else if (tipoMovimentacao === "descarte") {
      setOrigem("Controle de Qualidade");
      setDestino("Descarte");
    }
  }, [tipoMovimentacao]);

  const handleAddItem = () => {
    const newId = items.length > 0 ? Math.max(...items.map(item => item.id)) + 1 : 1;
    setItems([...items, { id: newId, produto_id: "", lote: "", quantidade: 1, unidade_medida: "" }]);
  };

  const handleRemoveItem = (id) => {
    if (items.length > 1) {
      setItems(items.filter(item => item.id !== id));
    }
  };

  const handleItemChange = (id, field, value) => {
    setItems(items.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    // Here you would normally save the data to your backend
    
    // Simulate success response
    setTimeout(() => {
      toast({
        title: "Movimentação registrada com sucesso",
        description: `Movimentação do tipo ${tipoMovimentacao} registrada.`,
      });
      
      setLoading(false);
      navigate(createPageUrl("ProducaoMovimentacoes"));
    }, 1500);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Nova Movimentação de Estoque</h2>
          <p className="text-gray-500">Registre entradas, saídas, transferências ou descartes de materiais</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Detalhes da Movimentação</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tipoMovimentacao">Tipo de Movimentação</Label>
                <Select value={tipoMovimentacao} onValueChange={setTipoMovimentacao} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="entrada">Entrada</SelectItem>
                    <SelectItem value="saida">Saída</SelectItem>
                    <SelectItem value="transferencia">Transferência</SelectItem>
                    <SelectItem value="descarte">Descarte</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="documentoRef">Documento de Referência</Label>
                <Input
                  id="documentoRef"
                  placeholder="Ex: NF-123456, REQ-789, etc"
                  value={documentoRef}
                  onChange={(e) => setDocumentoRef(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="origem">Origem</Label>
                <Select value={origem} onValueChange={setOrigem} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Origem do material" />
                  </SelectTrigger>
                  <SelectContent>
                    {origens.map((local, index) => (
                      <SelectItem key={index} value={local}>{local}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="destino">Destino</Label>
                <Select value={destino} onValueChange={setDestino} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Destino do material" />
                  </SelectTrigger>
                  <SelectContent>
                    {destinos.map((local, index) => (
                      <SelectItem key={index} value={local}>{local}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="motivo">Motivo</Label>
                <Input
                  id="motivo"
                  placeholder="Motivo da movimentação"
                  value={motivo}
                  onChange={(e) => setMotivo(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="data">Data</Label>
                <div className="relative">
                  <Input
                    id="data"
                    type="date"
                    className="pl-10"
                    defaultValue={new Date().toISOString().split('T')[0]}
                  />
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="observacoes">Observações</Label>
              <Textarea
                id="observacoes"
                placeholder="Observações adicionais sobre a movimentação"
                value={observacoes}
                onChange={(e) => setObservacoes(e.target.value)}
                rows={3}
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Itens</h3>
                <Button type="button" onClick={handleAddItem} variant="outline" size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Item
                </Button>
              </div>

              <div className="space-y-4">
                {items.map((item) => (
                  <div 
                    key={item.id} 
                    className="grid grid-cols-1 md:grid-cols-12 gap-4 p-4 border rounded-md bg-gray-50"
                  >
                    <div className="md:col-span-5 space-y-2">
                      <Label htmlFor={`produto_${item.id}`}>Produto</Label>
                      <Select 
                        value={item.produto_id} 
                        onValueChange={(value) => handleItemChange(item.id, "produto_id", value)}
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione um produto" />
                        </SelectTrigger>
                        <SelectContent>
                          {produtos.map((produto) => (
                            <SelectItem key={produto.id} value={produto.id}>{produto.nome}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="md:col-span-2 space-y-2">
                      <Label htmlFor={`lote_${item.id}`}>Lote</Label>
                      <Input
                        id={`lote_${item.id}`}
                        placeholder="Lote"
                        value={item.lote}
                        onChange={(e) => handleItemChange(item.id, "lote", e.target.value)}
                        required
                      />
                    </div>

                    <div className="md:col-span-2 space-y-2">
                      <Label htmlFor={`quantidade_${item.id}`}>Quantidade</Label>
                      <Input
                        id={`quantidade_${item.id}`}
                        type="number"
                        min="0.01"
                        step="0.01"
                        value={item.quantidade}
                        onChange={(e) => handleItemChange(item.id, "quantidade", e.target.value)}
                        required
                      />
                    </div>

                    <div className="md:col-span-2 space-y-2">
                      <Label htmlFor={`unidade_${item.id}`}>Unidade</Label>
                      <Select 
                        value={item.unidade_medida} 
                        onValueChange={(value) => handleItemChange(item.id, "unidade_medida", value)}
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Unidade" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="unidade">Unidade</SelectItem>
                          <SelectItem value="ml">ml</SelectItem>
                          <SelectItem value="l">L</SelectItem>
                          <SelectItem value="g">g</SelectItem>
                          <SelectItem value="kg">kg</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="md:col-span-1 flex items-end">
                      <Button
                        type="button"
                        variant="ghost"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        onClick={() => handleRemoveItem(item.id)}
                        disabled={items.length <= 1}
                      >
                        <Minus className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(createPageUrl("ProducaoMovimentacoes"))}
            >
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              <Save className="w-4 h-4 mr-2" />
              {loading ? "Salvando..." : "Salvar Movimentação"}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  );
}