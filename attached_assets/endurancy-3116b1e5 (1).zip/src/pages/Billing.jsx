import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  CreditCard, 
  DollarSign, 
  Receipt, 
  Calendar, 
  BarChart4, 
  Download, 
  Plus, 
  Search, 
  Filter,
  ArrowUpDown,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Building2,
  MoreHorizontal,
  FileText,
  RefreshCcw,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

export default function Billing() {
  const [activeTab, setActiveTab] = useState("invoices");
  const [period, setPeriod] = useState("current");
  const [loading, setLoading] = useState(true);
  const [invoices, setInvoices] = useState([]);
  const [plans, setPlans] = useState([]);
  const [showInvoiceDetails, setShowInvoiceDetails] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [stats, setStats] = useState({
    total_revenue: 0,
    paid_invoices: 0,
    pending_invoices: 0,
    overdue_invoices: 0,
    revenue_growth: 0
  });
  
  useEffect(() => {
    // Simular carregamento de dados
    setTimeout(() => {
      setLoading(false);
      
      setInvoices([
        {
          id: "INV-001",
          organization: "Associação CannaVida",
          organization_id: "org1",
          amount: 850.00,
          status: "paid",
          date: "2023-07-05",
          due_date: "2023-07-20",
          payment_method: "credit_card",
          plan: "Associação Premium"
        },
        {
          id: "INV-002",
          organization: "MediCannabis Farma",
          organization_id: "org2",
          amount: 1200.00,
          status: "paid",
          date: "2023-07-10",
          due_date: "2023-07-25",
          payment_method: "bank_transfer",
          plan: "Empresarial Pro"
        },
        {
          id: "INV-003",
          organization: "Cannabis Brasil Sul",
          organization_id: "org5",
          amount: 650.00,
          status: "pending",
          date: "2023-07-15",
          due_date: "2023-07-30",
          payment_method: "pending",
          plan: "Empresarial Básico"
        },
        {
          id: "INV-004",
          organization: "Green Medical Brasil",
          organization_id: "org4",
          amount: 650.00,
          status: "overdue",
          date: "2023-06-15",
          due_date: "2023-06-30",
          payment_method: "pending",
          plan: "Empresarial Básico"
        },
        {
          id: "INV-005",
          organization: "Instituto CannaPesquisa",
          organization_id: "org3",
          amount: 750.00,
          status: "paid",
          date: "2023-07-01",
          due_date: "2023-07-15",
          payment_method: "pix",
          plan: "Associação Plus"
        }
      ]);
      
      setPlans([
        {
          id: "plan1",
          name: "Empresarial Básico",
          monthly_price: 650.00,
          annual_price: 6500.00,
          subscribers: 18,
          features: [
            "Cultivo Básico",
            "CRM Básico",
            "Suporte por email"
          ]
        },
        {
          id: "plan2",
          name: "Empresarial Pro",
          monthly_price: 1200.00,
          annual_price: 12000.00,
          subscribers: 12,
          features: [
            "Cultivo Avançado",
            "CRM Completo",
            "Módulo Jurídico",
            "Módulo Produção",
            "Suporte prioritário"
          ]
        },
        {
          id: "plan3",
          name: "Associação Plus",
          monthly_price: 750.00,
          annual_price: 7500.00,
          subscribers: 15,
          features: [
            "Cultivo Básico",
            "CRM Básico",
            "Transparência Basic",
            "Suporte por email"
          ]
        },
        {
          id: "plan4",
          name: "Associação Premium",
          monthly_price: 850.00,
          annual_price: 8500.00,
          subscribers: 9,
          features: [
            "Cultivo Avançado",
            "CRM Completo",
            "Transparência Completa",
            "Módulo Jurídico",
            "Suporte prioritário"
          ]
        }
      ]);
      
      setStats({
        total_revenue: 3450.00,
        paid_invoices: 3,
        pending_invoices: 1,
        overdue_invoices: 1,
        revenue_growth: 12.5
      });
      
    }, 1000);
  }, []);
  
  const getInvoiceStatusBadge = (status) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-green-100 text-green-800">Pago</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'overdue':
        return <Badge className="bg-red-100 text-red-800">Atrasado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  const handleViewInvoice = (invoice) => {
    setSelectedInvoice(invoice);
    setShowInvoiceDetails(true);
  };
  
  const monthlyRevenue = [
    { month: 'Jan', value: 2100 },
    { month: 'Fev', value: 2300 },
    { month: 'Mar', value: 2500 },
    { month: 'Abr', value: 2400 },
    { month: 'Mai', value: 2800 },
    { month: 'Jun', value: 3100 },
    { month: 'Jul', value: 3450 }
  ];
  
  const planDistribution = [
    { name: 'Empresarial Básico', value: 18 },
    { name: 'Empresarial Pro', value: 12 },
    { name: 'Associação Plus', value: 15 },
    { name: 'Associação Premium', value: 9 }
  ];
  
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];
  
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[500px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">Carregando informações de faturamento...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Faturamento</h1>
          <p className="text-gray-500">Gerencie faturamento e planos de assinatura</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Nova Fatura
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl font-bold">
              R$ {stats.total_revenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </CardTitle>
            <CardDescription>Faturamento Mensal</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-green-600">
              <BarChart4 className="w-4 h-4 mr-1" />
              <span>+{stats.revenue_growth}% vs. mês anterior</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl font-bold">{stats.paid_invoices}</CardTitle>
            <CardDescription>Faturas Pagas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-green-600">
              <CheckCircle2 className="w-4 h-4 mr-1" />
              <span>Última hoje</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl font-bold">{stats.pending_invoices}</CardTitle>
            <CardDescription>Faturas Pendentes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-yellow-600">
              <AlertTriangle className="w-4 h-4 mr-1" />
              <span>Vence em {new Date().getDate() + 7} de julho</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl font-bold">{stats.overdue_invoices}</CardTitle>
            <CardDescription>Faturas Atrasadas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center text-sm text-red-600">
              <XCircle className="w-4 h-4 mr-1" />
              <span>Atrasada há 5 dias</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="invoices">Faturas</TabsTrigger>
          <TabsTrigger value="plans">Planos</TabsTrigger>
          <TabsTrigger value="analytics">Análises</TabsTrigger>
        </TabsList>
        
        <TabsContent value="invoices" className="space-y-4">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div className="flex-1 flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Buscar faturas..."
                  className="pl-8"
                />
              </div>
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="current">Mês Atual</SelectItem>
                  <SelectItem value="last">Mês Anterior</SelectItem>
                  <SelectItem value="quarter">Trimestre</SelectItem>
                  <SelectItem value="year">Ano</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Filtros
              </Button>
            </div>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Faturas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <div className="grid grid-cols-6 bg-gray-50 p-4 text-sm font-medium text-gray-500">
                  <div className="col-span-2">Organização</div>
                  <div>Fatura</div>
                  <div>Valor</div>
                  <div>Status</div>
                  <div className="text-right">Ações</div>
                </div>
                
                <div className="divide-y">
                  {invoices.map((invoice) => (
                    <div key={invoice.id} className="grid grid-cols-6 p-4 text-sm">
                      <div className="col-span-2 flex items-center gap-3">
                        <div className="p-2 bg-blue-50 rounded-lg">
                          <Building2 className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium">{invoice.organization}</p>
                          <p className="text-gray-500">{invoice.plan}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <div>
                          <p className="font-medium">{invoice.id}</p>
                          <p className="text-gray-500">Venc: {new Date(invoice.due_date).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center font-medium">
                        R$ {invoice.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </div>
                      <div className="flex items-center">
                        {getInvoiceStatusBadge(invoice.status)}
                      </div>
                      <div className="flex items-center justify-end">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <span className="sr-only">Abrir menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewInvoice(invoice)}>
                              <FileText className="mr-2 h-4 w-4" />
                              <span>Ver Detalhes</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Download className="mr-2 h-4 w-4" />
                              <span>Download PDF</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <RefreshCcw className="mr-2 h-4 w-4" />
                              <span>Alterar Status</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex items-center justify-between">
              <p className="text-sm text-gray-500">
                Mostrando {invoices.length} de {invoices.length} faturas
              </p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" disabled>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="plans" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold">Planos de Assinatura</h2>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Novo Plano
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {plans.map((plan) => (
              <Card key={plan.id} className="overflow-hidden">
                <div className="bg-green-50 p-4">
                  <h3 className="font-bold text-lg">{plan.name}</h3>
                  <div className="mt-1">
                    <span className="text-2xl font-bold">R$ {plan.monthly_price.toLocaleString('pt-BR')}</span>
                    <span className="text-gray-500">/mês</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">
                    ou R$ {plan.annual_price.toLocaleString('pt-BR')}/ano
                  </p>
                </div>
                <CardContent className="pt-4">
                  <div className="space-y-2">
                    {plan.features.map((feature, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-4 pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-500">Assinantes</span>
                      <Badge>{plan.subscribers}</Badge>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline">Editar</Button>
                  <Button>Ver Assinantes</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Receita Mensal</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyRevenue}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`R$ ${value}`, 'Receita']}
                      />
                      <Bar dataKey="value" fill="#0ea5e9" name="Receita (R$)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Distribuição por Plano</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={planDistribution}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {planDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} assinantes`, 'Quantidade']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Indicadores de Faturamento</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">Valor Médio por Fatura</p>
                    <p className="text-2xl font-bold mt-1">R$ 800,00</p>
                    <div className="mt-2 flex items-center text-sm text-green-600">
                      <ArrowUpDown className="w-4 h-4 mr-1" />
                      <span>+5% vs. mês anterior</span>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">Taxa de Conversão</p>
                    <p className="text-2xl font-bold mt-1">75%</p>
                    <div className="mt-2 flex items-center text-sm text-green-600">
                      <ArrowUpDown className="w-4 h-4 mr-1" />
                      <span>+2% vs. mês anterior</span>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">Receita Recorrente Mensal</p>
                    <p className="text-2xl font-bold mt-1">R$ 42.500</p>
                    <div className="mt-2 flex items-center text-sm text-green-600">
                      <ArrowUpDown className="w-4 h-4 mr-1" />
                      <span>+8% vs. mês anterior</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {showInvoiceDetails && selectedInvoice && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-full max-w-2xl">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-xl font-bold">Detalhes da Fatura</h2>
                <p className="text-gray-500">{selectedInvoice.id}</p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setShowInvoiceDetails(false)}>
                <XCircle className="w-5 h-5" />
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <p className="text-sm text-gray-500">Organização</p>
                <p className="font-medium">{selectedInvoice.organization}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Plano</p>
                <p className="font-medium">{selectedInvoice.plan}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Data da Fatura</p>
                <p className="font-medium">{new Date(selectedInvoice.date).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Data de Vencimento</p>
                <p className="font-medium">{new Date(selectedInvoice.due_date).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Valor</p>
                <p className="font-medium">R$ {selectedInvoice.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Status</p>
                {getInvoiceStatusBadge(selectedInvoice.status)}
              </div>
            </div>
            
            <div className="border-t pt-4">
              <h3 className="font-medium mb-2">Itens</h3>
              <div className="space-y-2">
                <div className="flex justify-between py-2 border-b">
                  <span>{selectedInvoice.plan}</span>
                  <span>R$ {selectedInvoice.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>R$ {selectedInvoice.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end gap-2 mt-6">
              <Button variant="outline" onClick={() => setShowInvoiceDetails(false)}>
                Fechar
              </Button>
              <Button>
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}