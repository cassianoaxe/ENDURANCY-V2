import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Calendar,
  Wallet,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  Download,
  Filter,
  Plus,
  Search,
  ArrowRight,
  DollarSign,
  PieChart,
  LineChart,
  Users,
  Heart
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart as ReLineChart, Line, PieChart as RePieChart, Pie, Cell } from 'recharts';

export default function FinanceiroSocial() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [period, setPeriod] = useState('2023');
  const [isLoading, setIsLoading] = useState(false);

  // Dados de exemplo
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#FF8042'];
  
  const overviewData = {
    total_investido: 298000,
    total_doacoes: 125000,
    receita_comprometida: 32,
    beneficiarios_ativos: 145,
    custo_medio: 2055,
    evolucao_mensal: [
      { mes: 'Jan', valor: 23000 },
      { mes: 'Fev', valor: 24000 },
      { mes: 'Mar', valor: 25000 },
      { mes: 'Abr', valor: 24500 },
      { mes: 'Mai', valor: 25500 },
      { mes: 'Jun', valor: 25000 },
      { mes: 'Jul', valor: 25500 },
      { mes: 'Ago', valor: 25300 },
      { mes: 'Set', valor: 24900 },
      { mes: 'Out', valor: 25100 },
      { mes: 'Nov', valor: 25200 },
      { mes: 'Dez', valor: 25000 }
    ],
    distribuicao_beneficios: [
      { name: 'Isenção Total', value: 120000 },
      { name: 'Isenção 75%', value: 90000 },
      { name: 'Isenção 50%', value: 63000 },
      { name: 'Isenção 25%', value: 25000 }
    ],
    origem_recursos: [
      { name: 'Doações', value: 125000 },
      { name: 'Receita Operacional', value: 90000 },
      { name: 'Parcerias', value: 58000 },
      { name: 'Eventos', value: 25000 }
    ]
  };
  
  const doacoesRecentes = [
    { id: 1, data: '2023-12-15', valor: 500, doador: 'Maria Silva', metodo: 'PIX', campanha: 'Natal Solidário' },
    { id: 2, data: '2023-12-14', valor: 1000, doador: 'João Almeida', metodo: 'Cartão', campanha: 'Geral' },
    { id: 3, data: '2023-12-12', valor: 250, doador: 'Anônimo', metodo: 'PIX', campanha: 'Natal Solidário' },
    { id: 4, data: '2023-12-10', valor: 2000, doador: 'Empresa ABC', metodo: 'Transferência', campanha: 'Parceria Corporativa' },
    { id: 5, data: '2023-12-08', valor: 150, doador: 'Paulo Mendes', metodo: 'PIX', campanha: 'Geral' }
  ];
  
  const despesasRecentes = [
    { id: 1, data: '2023-12-16', valor: 15000, descricao: 'Subsídio - Medicamentos', categoria: 'Produtos' },
    { id: 2, data: '2023-12-15', valor: 5000, descricao: 'Consultas médicas', categoria: 'Serviços' },
    { id: 3, data: '2023-12-10', valor: 2500, descricao: 'Material educativo', categoria: 'Comunicação' },
    { id: 4, data: '2023-12-05', valor: 3000, descricao: 'Transporte de pacientes', categoria: 'Logística' },
    { id: 5, data: '2023-12-01', valor: 1500, descricao: 'Despesas administrativas', categoria: 'Administrativo' }
  ];

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Financeiro - Programa Social</h1>
          <p className="text-gray-500">Gestão financeira do programa de assistência social</p>
        </div>
        <div className="flex gap-2">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Selecione o período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2023">2023</SelectItem>
              <SelectItem value="2022">2022</SelectItem>
              <SelectItem value="2021">2021</SelectItem>
            </SelectContent>
          </Select>
          <Button>
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="doacoes">Doações</TabsTrigger>
          <TabsTrigger value="despesas">Despesas</TabsTrigger>
          <TabsTrigger value="orcamento">Orçamento</TabsTrigger>
          <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Investido
                </CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(overviewData.total_investido)}
                </div>
                <p className="text-xs text-muted-foreground">
                  No ano de {period}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Doações Recebidas
                </CardTitle>
                <Heart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(overviewData.total_doacoes)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {overviewData.total_doacoes / overviewData.total_investido * 100}% do total investido
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Receita Comprometida
                </CardTitle>
                <PieChart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {overviewData.receita_comprometida}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Da receita operacional
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Custo Médio por Beneficiário
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(overviewData.custo_medio)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {overviewData.beneficiarios_ativos} beneficiários ativos
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Evolução Mensal de Investimento</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={overviewData.evolucao_mensal}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="mes" />
                      <YAxis />
                      <Tooltip formatter={(value) => [formatCurrency(value), 'Valor']} />
                      <Legend />
                      <Bar dataKey="valor" fill="#8884d8" name="Valor Investido" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Distribuição por Tipo de Benefício</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={overviewData.distribuicao_beneficios}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {overviewData.distribuicao_beneficios.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [formatCurrency(value), 'Valor']} />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Origem dos Recursos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={overviewData.origem_recursos}
                    margin={{ top: 20, right: 30, left: 100, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" />
                    <Tooltip formatter={(value) => [formatCurrency(value), 'Valor']} />
                    <Legend />
                    <Bar dataKey="value" fill="#82ca9d" name="Valor" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="doacoes" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Doações Recebidas</h2>
            <div className="flex gap-2">
              <Button variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Registrar Doação
              </Button>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Nova Campanha
              </Button>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Resumo de Doações ({period})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Total de Doações</div>
                  <div className="text-2xl font-bold">{formatCurrency(125000)}</div>
                </div>
                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Número de Doadores</div>
                  <div className="text-2xl font-bold">73</div>
                </div>
                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Ticket Médio</div>
                  <div className="text-2xl font-bold">{formatCurrency(1712.33)}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Doações Recentes</CardTitle>
                <div className="flex gap-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="Buscar doação..." className="pl-8 w-64" />
                  </div>
                  <Button variant="outline">
                    <Filter className="w-4 h-4 mr-2" />
                    Filtros
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Doador</TableHead>
                    <TableHead>Método</TableHead>
                    <TableHead>Campanha</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {doacoesRecentes.map((doacao) => (
                    <TableRow key={doacao.id}>
                      <TableCell>{new Date(doacao.data).toLocaleDateString('pt-BR')}</TableCell>
                      <TableCell>{formatCurrency(doacao.valor)}</TableCell>
                      <TableCell>{doacao.doador}</TableCell>
                      <TableCell>{doacao.metodo}</TableCell>
                      <TableCell>{doacao.campanha}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">Ver</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Campanhas Ativas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-lg border hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">Natal Solidário</div>
                        <div className="text-sm text-muted-foreground">Encerra em 15 dias</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{formatCurrency(15000)}</div>
                        <div className="text-sm text-muted-foreground">Meta: {formatCurrency(30000)}</div>
                      </div>
                    </div>
                    <div className="mt-2">
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '50%' }}></div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">Medicamentos Infantis</div>
                        <div className="text-sm text-muted-foreground">Encerra em 45 dias</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{formatCurrency(8000)}</div>
                        <div className="text-sm text-muted-foreground">Meta: {formatCurrency(20000)}</div>
                      </div>
                    </div>
                    <div className="mt-2">
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '40%' }}></div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">Doações Permanentes</div>
                        <div className="text-sm text-muted-foreground">Campanha contínua</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{formatCurrency(3200)}</div>
                        <div className="text-sm text-muted-foreground">Este mês</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Métodos de Doação</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={[
                          { name: 'PIX', value: 65000 },
                          { name: 'Cartão', value: 35000 },
                          { name: 'Transferência', value: 20000 },
                          { name: 'Outros', value: 5000 }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {[
                          { name: 'PIX', value: 65000 },
                          { name: 'Cartão', value: 35000 },
                          { name: 'Transferência', value: 20000 },
                          { name: 'Outros', value: 5000 }
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [formatCurrency(value), 'Valor']} />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="despesas" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Gestão de Despesas</h2>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Nova Despesa
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Resumo de Despesas ({period})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Total de Despesas</div>
                  <div className="text-2xl font-bold">{formatCurrency(298000)}</div>
                </div>
                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Maior Categoria</div>
                  <div className="text-2xl font-bold">Produtos</div>
                </div>
                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Variação Mensal</div>
                  <div className="text-2xl font-bold text-green-600">+2.3%</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Despesas Recentes</CardTitle>
                <div className="flex gap-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="Buscar despesa..." className="pl-8 w-64" />
                  </div>
                  <Button variant="outline">
                    <Filter className="w-4 h-4 mr-2" />
                    Filtros
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {despesasRecentes.map((despesa) => (
                    <TableRow key={despesa.id}>
                      <TableCell>{new Date(despesa.data).toLocaleDateString('pt-BR')}</TableCell>
                      <TableCell>{formatCurrency(despesa.valor)}</TableCell>
                      <TableCell>{despesa.descricao}</TableCell>
                      <TableCell>{despesa.categoria}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">Ver</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Despesas por Categoria</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={[
                          { name: 'Produtos', value: 180000 },
                          { name: 'Serviços', value: 60000 },
                          { name: 'Logística', value: 25000 },
                          { name: 'Comunicação', value: 15000 },
                          { name: 'Administrativo', value: 18000 }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {[
                          { name: 'Produtos', value: 180000 },
                          { name: 'Serviços', value: 60000 },
                          { name: 'Logística', value: 25000 },
                          { name: 'Comunicação', value: 15000 },
                          { name: 'Administrativo', value: 18000 }
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [formatCurrency(value), 'Valor']} />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Evolução Mensal de Despesas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ReLineChart
                      data={[
                        { mes: 'Jan', produtos: 15000, servicos: 5000, outros: 3000 },
                        { mes: 'Fev', produtos: 14500, servicos: 5500, outros: 4000 },
                        { mes: 'Mar', produtos: 15000, servicos: 6000, outros: 4000 },
                        { mes: 'Abr', produtos: 15500, servicos: 5000, outros: 4000 },
                        { mes: 'Mai', produtos: 16000, servicos: 5500, outros: 4000 },
                        { mes: 'Jun', produtos: 15500, servicos: 5500, outros: 4000 }
                      ]}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="mes" />
                      <YAxis />
                      <Tooltip formatter={(value) => [formatCurrency(value), '']} />
                      <Legend />
                      <Line type="monotone" dataKey="produtos" stroke="#8884d8" name="Produtos" />
                      <Line type="monotone" dataKey="servicos" stroke="#82ca9d" name="Serviços" />
                      <Line type="monotone" dataKey="outros" stroke="#ffc658" name="Outros" />
                    </ReLineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="orcamento" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Gestão de Orçamento</h2>
            <div className="flex gap-2">
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Exportar Planilha
              </Button>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Novo Orçamento
              </Button>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Orçamento Anual ({period})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Orçamento Total</div>
                  <div className="text-2xl font-bold">{formatCurrency(350000)}</div>
                </div>
                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Realizado</div>
                  <div className="text-2xl font-bold">{formatCurrency(298000)}</div>
                </div>
                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Disponível</div>
                  <div className="text-2xl font-bold">{formatCurrency(52000)}</div>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Progresso do Orçamento</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Produtos</span>
                      <span className="text-sm font-medium">{formatCurrency(180000)} / {formatCurrency(200000)}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '90%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Serviços</span>
                      <span className="text-sm font-medium">{formatCurrency(60000)} / {formatCurrency(80000)}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '75%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Logística</span>
                      <span className="text-sm font-medium">{formatCurrency(25000)} / {formatCurrency(30000)}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-yellow-600 h-2.5 rounded-full" style={{ width: '83%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Comunicação</span>
                      <span className="text-sm font-medium">{formatCurrency(15000)} / {formatCurrency(20000)}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-purple-600 h-2.5 rounded-full" style={{ width: '75%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Administrativo</span>
                      <span className="text-sm font-medium">{formatCurrency(18000)} / {formatCurrency(20000)}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-red-600 h-2.5 rounded-full" style={{ width: '90%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Previsão e Realizado</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { mes: 'Jan', previsto: 25000, realizado: 23000 },
                      { mes: 'Fev', previsto: 25000, realizado: 24000 },
                      { mes: 'Mar', previsto: 25000, realizado: 25000 },
                      { mes: 'Abr', previsto: 25000, realizado: 24500 },
                      { mes: 'Mai', previsto: 25000, realizado: 25500 },
                      { mes: 'Jun', previsto: 25000, realizado: 25000 },
                      { mes: 'Jul', previsto: 25000, realizado: 25500 },
                      { mes: 'Ago', previsto: 25000, realizado: 25300 },
                      { mes: 'Set', previsto: 25000, realizado: 24900 },
                      { mes: 'Out', previsto: 25000, realizado: 25100 },
                      { mes: 'Nov', previsto: 25000, realizado: 25200 },
                      { mes: 'Dez', previsto: 25000, realizado: 25000 }
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="mes" />
                    <YAxis />
                    <Tooltip formatter={(value) => [formatCurrency(value), '']} />
                    <Legend />
                    <Bar dataKey="previsto" fill="#8884d8" name="Orçado" />
                    <Bar dataKey="realizado" fill="#82ca9d" name="Realizado" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="relatorios" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Relatórios Financeiros</h2>
            <div className="flex gap-2">
              <Select defaultValue="2023">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Ano" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2023">2023</SelectItem>
                  <SelectItem value="2022">2022</SelectItem>
                  <SelectItem value="2021">2021</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Exportar
              </Button>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Relatórios Disponíveis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div>
                    <div className="font-medium">Resumo Financeiro</div>
                    <div className="text-sm text-muted-foreground">Resumo das movimentações do programa social</div>
                  </div>
                  <Button variant="outline">Baixar</Button>
                </div>
                <div className="flex justify-between items-center p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div>
                    <div className="font-medium">Análise de Custo-Benefício</div>
                    <div className="text-sm text-muted-foreground">Análise detalhada do custo por beneficiário</div>
                  </div>
                  <Button variant="outline">Baixar</Button>
                </div>
                <div className="flex justify-between items-center p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div>
                    <div className="font-medium">Doações por Campanha</div>
                    <div className="text-sm text-muted-foreground">Detalhamento das doações por campanha</div>
                  </div>
                  <Button variant="outline">Baixar</Button>
                </div>
                <div className="flex justify-between items-center p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div>
                    <div className="font-medium">Despesas por Categoria</div>
                    <div className="text-sm text-muted-foreground">Detalhamento das despesas por categoria</div>
                  </div>
                  <Button variant="outline">Baixar</Button>
                </div>
                <div className="flex justify-between items-center p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div>
                    <div className="font-medium">Indicadores de Impacto Social</div>
                    <div className="text-sm text-muted-foreground">Análise do impacto social do programa</div>
                  </div>
                  <Button variant="outline">Baixar</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Indicadores de Desempenho</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Custo por Beneficiário</div>
                  <div className="text-2xl font-bold">{formatCurrency(2055)}</div>
                  <div className="text-xs text-muted-foreground flex items-center">
                    <ArrowDownRight className="w-3 h-3 text-green-500 mr-1" />
                    <span className="text-green-500">5% menor que ano anterior</span>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Custo Administrativo</div>
                  <div className="text-2xl font-bold">6.0%</div>
                  <div className="text-xs text-muted-foreground flex items-center">
                    <ArrowDownRight className="w-3 h-3 text-green-500 mr-1" />
                    <span className="text-green-500">Abaixo do limite de 10%</span>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Taxa de Rotatividade</div>
                  <div className="text-2xl font-bold">12%</div>
                  <div className="text-xs text-muted-foreground flex items-center">
                    <ArrowUpRight className="w-3 h-3 text-red-500 mr-1" />
                    <span className="text-red-500">2% maior que ano anterior</span>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg border">
                  <div className="text-sm text-muted-foreground">Satisfação Beneficiários</div>
                  <div className="text-2xl font-bold">4.8/5.0</div>
                  <div className="text-xs text-muted-foreground flex items-center">
                    <ArrowUpRight className="w-3 h-3 text-green-500 mr-1" />
                    <span className="text-green-500">Acima da meta de 4.5</span>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-center">
                <Button>
                  <ArrowRight className="w-4 h-4 mr-2" />
                  Ver Relatório Completo
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}