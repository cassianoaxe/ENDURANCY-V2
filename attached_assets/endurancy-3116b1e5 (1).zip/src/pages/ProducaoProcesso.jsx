
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ClipboardList,
  ArrowRight,
  Check,
  AlertTriangle,
  Clock,
  User,
  Calendar,
  Package,
  FlaskConical,
  Droplets,
  PackageOpen,
  Box,
  CheckSquare,
  MoreHorizontal,
  LayoutList,
  Beaker,
  Hourglass,
  FileText
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

// Componente para exibir uma etapa do processo
const ProcessStep = ({ step, onComplete, onView, isActive, isCompleted }) => {
  return (
    <div className={`border rounded-lg p-4 ${isActive ? 'border-blue-500 bg-blue-50' : isCompleted ? 'border-green-500 bg-green-50' : 'border-gray-200'}`}>
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center">
          <div className={`p-2 rounded-full mr-3 ${isCompleted ? 'bg-green-100' : isActive ? 'bg-blue-100' : 'bg-gray-100'}`}>
            {step.icon}
          </div>
          <div>
            <h3 className="font-semibold">{step.name}</h3>
            <p className="text-sm text-gray-500">{step.description}</p>
          </div>
        </div>
        <Badge className={isCompleted ? 'bg-green-100 text-green-800' : isActive ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}>
          {isCompleted ? 'Concluída' : isActive ? 'Em andamento' : 'Pendente'}
        </Badge>
      </div>
      
      {step.estimatedTime && (
        <div className="flex items-center text-sm text-gray-500 mb-2">
          <Clock className="w-4 h-4 mr-1" />
          <span>Tempo estimado: {step.estimatedTime}</span>
        </div>
      )}
      
      {step.responsibleUsers && (
        <div className="flex items-center text-sm text-gray-500 mb-3">
          <User className="w-4 h-4 mr-1" />
          <span>Responsável: {step.responsibleUsers}</span>
        </div>
      )}
      
      <div className="flex justify-end gap-2 mt-3">
        <Button variant="outline" size="sm" onClick={() => onView(step)}>
          Detalhes
        </Button>
        {isActive && (
          <Button size="sm" onClick={() => onComplete(step)}>
            Concluir Etapa
          </Button>
        )}
      </div>
    </div>
  );
};

export default function ProducaoProcesso() {
  const [loading, setLoading] = useState(true);
  const [ordemProducao, setOrdemProducao] = useState(null);
  const [etapasProcesso, setEtapasProcesso] = useState([]);
  const [etapaAtual, setEtapaAtual] = useState(1);
  const [activeTab, setActiveTab] = useState("processo");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [observacoes, setObservacoes] = useState("");
  const [selectedStep, setSelectedStep] = useState(null);
  
  useEffect(() => {
    const loadData = async () => {
      // Mock data para a ordem de produção
      const mockOP = {
        id: "OP-2023-125",
        produto: "Óleo CBD 5% 30ml",
        lote: "LOT-CBD-072",
        quantidade: 500,
        unidade: "frascos",
        data_inicio: "2023-08-05",
        data_prevista_conclusao: "2023-08-12",
        status: "em_processo",
        percentual_concluido: 40,
        responsavel: "João Silva"
      };
      
      // Mock data para as etapas do processo
      const mockEtapas = [
        {
          id: 1,
          name: "Diluição",
          description: "Diluição do extrato CBD em óleo MCT",
          status: "complete",
          icon: <Droplets className="w-4 h-4 text-blue-600" />,
          estimatedTime: "2 horas",
          responsibleUsers: "Carlos Santos",
          instructions: "1. Pesar 250g de extrato CBD\n2. Aquecer óleo MCT a 60°C\n3. Adicionar extrato lentamente sob agitação\n4. Manter agitação por 30 minutos",
          materials: [
            { name: "Extrato CBD Full Spectrum", quantity: "250g", batch: "EXT-056" },
            { name: "Óleo MCT", quantity: "15L", batch: "MCT-123" }
          ],
          equipment: ["Reator de 20L", "Agitador mecânico", "Balança analítica"],
          parameters: [
            { name: "Temperatura", value: "60°C", tolerance: "±5°C" },
            { name: "Tempo de agitação", value: "30 min", tolerance: "±5 min" }
          ],
          completed_date: "2023-08-06T14:30:00",
          completed_by: "Carlos Santos",
          notes: "Diluição realizada conforme procedimento. Temperatura mantida estável durante todo o processo."
        },
        {
          id: 2,
          name: "Envasamento",
          description: "Envase do óleo em frascos de 30ml",
          status: "active",
          icon: <FlaskConical className="w-4 h-4 text-purple-600" />,  
          estimatedTime: "3 horas",
          responsibleUsers: "Maria Oliveira",
          instructions: "1. Preparar linha de envase\n2. Calibrar equipamento para 30ml\n3. Verificar integridade dos frascos\n4. Realizar envase automatizado\n5. Verificar peso de 10 unidades a cada 50 frascos",
          materials: [
            { name: "Solução diluída", quantity: "15L", batch: "LOT-CBD-072-DIL" },
            { name: "Frascos âmbar 30ml", quantity: "520 unidades", batch: "FRA-457" },
            { name: "Conta-gotas", quantity: "520 unidades", batch: "CON-789" }
          ],
          equipment: ["Máquina de envase automática", "Balança de precisão"],
          parameters: [
            { name: "Volume", value: "30ml", tolerance: "±0.5ml" },
            { name: "Peso médio", value: "28.5g", tolerance: "±0.5g" }
          ]
        },
        {
          id: 3,
          name: "Embalagem Primária",
          description: "Fechamento, lacre e rotulagem dos frascos",
          status: "pending",
          icon: <PackageOpen className="w-4 h-4 text-orange-600" />,
          estimatedTime: "3 horas",
          responsibleUsers: "Pedro Mendes",
          instructions: "1. Aplicar conta-gotas e tampas nos frascos envasados\n2. Verificar vedação\n3. Aplicar lacre de segurança\n4. Imprimir e aplicar rótulos com lote e validade",
          materials: [
            { name: "Frascos envasados", quantity: "500 unidades", batch: "LOT-CBD-072-ENV" },
            { name: "Rótulos primários", quantity: "520 unidades", batch: "ROT-123" },
            { name: "Lacres de segurança", quantity: "520 unidades", batch: "LAC-456" }
          ],
          equipment: ["Máquina aplicadora de tampas", "Impressora de rótulos", "Aplicadora de rótulos"]
        },
        {
          id: 4,
          name: "Embalagem Secundária",
          description: "Inserção dos frascos em caixas e embalagem final",
          status: "pending",
          icon: <Box className="w-4 h-4 text-amber-600" />,
          estimatedTime: "2 horas",
          responsibleUsers: "Ana Costa",
          instructions: "1. Verificar integridade das embalagens primárias\n2. Inserir bula em cada caixa\n3. Acondicionar frasco na caixa individual\n4. Agrupar em embalagens de transporte de 20 unidades",
          materials: [
            { name: "Frascos rotulados", quantity: "500 unidades", batch: "LOT-CBD-072-ROT" },
            { name: "Caixas individuais", quantity: "520 unidades", batch: "CXI-789" },
            { name: "Bulas", quantity: "520 unidades", batch: "BUL-234" },
            { name: "Caixas de transporte", quantity: "25 unidades", batch: "CXT-567" }
          ],
          equipment: ["Máquina de selagem", "Esteira transportadora"]
        },
        {
          id: 5,
          name: "Quarentena",
          description: "Produto em quarentena para análise de qualidade",
          status: "pending",
          icon: <Hourglass className="w-4 h-4 text-gray-600" />,
          estimatedTime: "48 horas",
          responsibleUsers: "Controle de Qualidade",
          instructions: "1. Transferir lote para área de quarentena\n2. Registrar entrada no sistema\n3. Coletar amostras para análise\n4. Aguardar resultados do controle de qualidade",
          materials: [],
          equipment: []
        },
        {
          id: 6,
          name: "Liberação para Estoque",
          description: "Liberação final após aprovação da qualidade",
          status: "pending",
          icon: <CheckSquare className="w-4 h-4 text-green-600" />,
          estimatedTime: "4 horas",
          responsibleUsers: "Garantia da Qualidade",
          instructions: "1. Verificar resultados das análises\n2. Emitir certificado de análise\n3. Aprovar lote no sistema\n4. Transferir para estoque de produtos acabados",
          materials: [],
          equipment: ["Sistema ERP", "Impressora de certificados"]
        }
      ];
      
      setOrdemProducao(mockOP);
      setEtapasProcesso(mockEtapas);
      setLoading(false);
    };
    
    loadData();
  }, []);
  
  const handleCompleteStep = (step) => {
    // Lógica para completar uma etapa do processo
    const updatedEtapas = etapasProcesso.map(etapa => {
      if (etapa.id === step.id) {
        return { ...etapa, status: 'complete', completed_date: new Date().toISOString(), completed_by: "Usuário Atual" };
      }
      if (etapa.id === step.id + 1) {
        return { ...etapa, status: 'active' };
      }
      return etapa;
    });
    
    setEtapasProcesso(updatedEtapas);
    setEtapaAtual(etapaAtual + 1);
    
    // Atualizar progresso geral da ordem de produção
    if (ordemProducao) {
      const completedSteps = updatedEtapas.filter(e => e.status === 'complete').length;
      const totalSteps = updatedEtapas.length;
      const percentual = Math.round((completedSteps / totalSteps) * 100);
      
      setOrdemProducao({
        ...ordemProducao,
        percentual_concluido: percentual
      });
    }
  };
  
  const handleViewStep = (step) => {
    setSelectedStep(step);
    setIsFormOpen(true);
  };
  
  const closeForm = () => {
    setIsFormOpen(false);
    setSelectedStep(null);
  };
  
  const getStatusText = (status) => {
    const statusMapping = {
      em_processo: "Em Processo",
      completo: "Concluído",
      parado: "Parado",
      em_quarentena: "Em Quarentena",
      aprovado: "Aprovado"
    };
    
    return statusMapping[status] || status;
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
        <p className="ml-2">Carregando informações do processo...</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {ordemProducao && (
        <>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-bold">{ordemProducao.produto}</h1>
                  <Badge className="bg-blue-100 text-blue-800">
                    {getStatusText(ordemProducao.status)}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 mt-2 text-gray-500">
                  <div className="flex items-center">
                    <ClipboardList className="w-4 h-4 mr-1" />
                    <span>OP: {ordemProducao.id}</span>
                  </div>
                  <div className="flex items-center">
                    <Package className="w-4 h-4 mr-1" />
                    <span>Lote: {ordemProducao.lote}</span>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    <span>Início: {new Date(ordemProducao.data_inicio).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-gray-500">Quantidade: {ordemProducao.quantidade} {ordemProducao.unidade}</p>
                <p className="text-gray-500">Responsável: {ordemProducao.responsavel}</p>
              </div>
            </div>
            
            <div className="mt-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Progresso: {ordemProducao.percentual_concluido}%</span>
                <span className="text-sm text-gray-500">Conclusão prevista: {new Date(ordemProducao.data_prevista_conclusao).toLocaleDateString()}</span>
              </div>
              <Progress value={ordemProducao.percentual_concluido} className="h-2" />
            </div>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="processo">Processo</TabsTrigger>
              <TabsTrigger value="materiais">Materiais</TabsTrigger>
              <TabsTrigger value="qualidade">Controle de Qualidade</TabsTrigger>
              <TabsTrigger value="documentos">Documentos</TabsTrigger>
            </TabsList>
            
            <TabsContent value="processo" className="mt-4">
              <div className="grid grid-cols-1 gap-4">
                {etapasProcesso.map((step) => (
                  <ProcessStep
                    key={step.id}
                    step={step}
                    onComplete={handleCompleteStep}
                    onView={handleViewStep}
                    isActive={step.status === 'active'}
                    isCompleted={step.status === 'complete'}
                  />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="materiais" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Materiais Utilizados</CardTitle>
                  <CardDescription>Lista de matérias-primas e embalagens utilizadas neste processo</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Material</TableHead>
                        <TableHead>Lote</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Etapa</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {/* Consolidar materiais de todas as etapas */}
                      {etapasProcesso.flatMap(etapa => 
                        etapa.materials ? etapa.materials.map((material, index) => (
                          <TableRow key={`${etapa.id}-${index}`}>
                            <TableCell>{material.name}</TableCell>
                            <TableCell>{material.batch}</TableCell>
                            <TableCell>{material.quantity}</TableCell>
                            <TableCell>{etapa.name}</TableCell>
                            <TableCell>
                              {etapa.status === 'complete' ? (
                                <Badge className="bg-green-100 text-green-800">Consumido</Badge>
                              ) : etapa.status === 'active' ? (
                                <Badge className="bg-blue-100 text-blue-800">Em uso</Badge>
                              ) : (
                                <Badge className="bg-gray-100 text-gray-800">Pendente</Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        )) : []
                      )}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="qualidade" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Controle de Qualidade</CardTitle>
                  <CardDescription>Pontos de controle e análises realizadas durante o processo</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-6">
                    <h3 className="text-lg font-medium mb-3">Status de Qualidade</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card>
                        <CardContent className="p-6">
                          <div className="flex items-center gap-3">
                            <div className="p-3 bg-yellow-50 rounded-full">
                              <FlaskConical className="w-5 h-5 text-yellow-600" />
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Amostras Coletadas</p>
                              <p className="text-2xl font-bold">2/3</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-6">
                          <div className="flex items-center gap-3">
                            <div className="p-3 bg-blue-50 rounded-full">
                              <Beaker className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Testes Concluídos</p>
                              <p className="text-2xl font-bold">4/8</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-6">
                          <div className="flex items-center gap-3">
                            <div className="p-3 bg-green-50 rounded-full">
                              <CheckSquare className="w-5 h-5 text-green-600" />
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Aprovação Final</p>
                              <p className="text-2xl font-bold">Pendente</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                  
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Etapa</TableHead>
                        <TableHead>Ponto de Controle</TableHead>
                        <TableHead>Especificação</TableHead>
                        <TableHead>Resultado</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell>Diluição</TableCell>
                        <TableCell>Temperatura de diluição</TableCell>
                        <TableCell>60°C ±5°C</TableCell>
                        <TableCell>62°C</TableCell>
                        <TableCell>
                          <Badge className="bg-green-100 text-green-800">Aprovado</Badge>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Diluição</TableCell>
                        <TableCell>Aspecto visual</TableCell>
                        <TableCell>Líquido transparente</TableCell>
                        <TableCell>Líquido transparente</TableCell>
                        <TableCell>
                          <Badge className="bg-green-100 text-green-800">Aprovado</Badge>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Envasamento</TableCell>
                        <TableCell>Volume médio</TableCell>
                        <TableCell>30ml ±0.5ml</TableCell>
                        <TableCell>30.2ml</TableCell>
                        <TableCell>
                          <Badge className="bg-green-100 text-green-800">Aprovado</Badge>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Envasamento</TableCell>
                        <TableCell>Vedação</TableCell>
                        <TableCell>Sem vazamentos</TableCell>
                        <TableCell>Sem vazamentos</TableCell>
                        <TableCell>
                          <Badge className="bg-green-100 text-green-800">Aprovado</Badge>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Produto Final</TableCell>
                        <TableCell>Concentração CBD</TableCell>
                        <TableCell>5.0% ±0.5%</TableCell>
                        <TableCell>Pendente</TableCell>
                        <TableCell>
                          <Badge className="bg-yellow-100 text-yellow-800">Em análise</Badge>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Produto Final</TableCell>
                        <TableCell>Microbiológico</TableCell>
                        <TableCell>Conforme especificação</TableCell>
                        <TableCell>Pendente</TableCell>
                        <TableCell>
                          <Badge className="bg-yellow-100 text-yellow-800">Em análise</Badge>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="documentos" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Documentos do Processo</CardTitle>
                  <CardDescription>Documentos relacionados à produção do lote</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Documento</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell>Ordem de Produção {ordemProducao.id}</TableCell>
                        <TableCell>Ordem de Produção</TableCell>
                        <TableCell>{new Date(ordemProducao.data_inicio).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Badge className="bg-blue-100 text-blue-800">Ativo</Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm">
                            <FileText className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Registro de Fabricação</TableCell>
                        <TableCell>Registro de Processo</TableCell>
                        <TableCell>{new Date(ordemProducao.data_inicio).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Badge className="bg-blue-100 text-blue-800">Em andamento</Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm">
                            <FileText className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Etiquetas de Identificação</TableCell>
                        <TableCell>Etiquetas</TableCell>
                        <TableCell>{new Date(ordemProducao.data_inicio).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Badge className="bg-green-100 text-green-800">Gerado</Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm">
                            <FileText className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Certificado de Análise</TableCell>
                        <TableCell>Qualidade</TableCell>
                        <TableCell>-</TableCell>
                        <TableCell>
                          <Badge className="bg-gray-100 text-gray-800">Pendente</Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" disabled>
                            <FileText className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Certificado de Liberação</TableCell>
                        <TableCell>Garantia da Qualidade</TableCell>
                        <TableCell>-</TableCell>
                        <TableCell>
                          <Badge className="bg-gray-100 text-gray-800">Pendente</Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" disabled>
                            <FileText className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          
          {isFormOpen && selectedStep && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-white rounded-lg p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-start mb-4">
                  <h2 className="text-xl font-bold">{selectedStep.name}</h2>
                  <Button variant="ghost" size="sm" onClick={closeForm}>
                    &times;
                  </Button>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Descrição</h3>
                    <p>{selectedStep.description}</p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-2">Instruções</h3>
                    <div className="bg-gray-50 p-3 rounded whitespace-pre-line">
                      {selectedStep.instructions}
                    </div>
                  </div>
                  
                  {selectedStep.materials && selectedStep.materials.length > 0 && (
                    <div>
                      <h3 className="font-medium mb-2">Materiais</h3>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Material</TableHead>
                            <TableHead>Quantidade</TableHead>
                            <TableHead>Lote</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {selectedStep.materials.map((material, index) => (
                            <TableRow key={index}>
                              <TableCell>{material.name}</TableCell>
                              <TableCell>{material.quantity}</TableCell>
                              <TableCell>{material.batch}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                  
                  {selectedStep.equipment && selectedStep.equipment.length > 0 && (
                    <div>
                      <h3 className="font-medium mb-2">Equipamentos</h3>
                      <ul className="list-disc pl-5">
                        {selectedStep.equipment.map((equip, index) => (
                          <li key={index}>{equip}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {selectedStep.parameters && selectedStep.parameters.length > 0 && (
                    <div>
                      <h3 className="font-medium mb-2">Parâmetros de Controle</h3>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Parâmetro</TableHead>
                            <TableHead>Valor</TableHead>
                            <TableHead>Tolerância</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {selectedStep.parameters.map((param, index) => (
                            <TableRow key={index}>
                              <TableCell>{param.name}</TableCell>
                              <TableCell>{param.value}</TableCell>
                              <TableCell>{param.tolerance}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                  
                  {selectedStep.status === 'active' && (
                    <div>
                      <h3 className="font-medium mb-2">Observações</h3>
                      <Textarea 
                        placeholder="Adicione observações relevantes sobre esta etapa..." 
                        value={observacoes}
                        onChange={(e) => setObservacoes(e.target.value)}
                        rows={4}
                      />
                    </div>
                  )}
                  
                  {selectedStep.status === 'complete' && (
                    <div>
                      <h3 className="font-medium mb-2">Informações de Conclusão</h3>
                      <div className="bg-green-50 p-4 rounded">
                        <p><strong>Concluído em:</strong> {new Date(selectedStep.completed_date).toLocaleString()}</p>
                        <p><strong>Concluído por:</strong> {selectedStep.completed_by}</p>
                        {selectedStep.notes && (
                          <>
                            <p className="mt-2"><strong>Notas:</strong></p>
                            <p>{selectedStep.notes}</p>
                          </>
                        )}
                      </div>
                    </div>
                  )}
                  
                  <div className="flex justify-end gap-2 mt-4">
                    <Button variant="outline" onClick={closeForm}>
                      Fechar
                    </Button>
                    {selectedStep.status === 'active' && (
                      <Button onClick={() => {
                        handleCompleteStep(selectedStep);
                        closeForm();
                      }}>
                        Concluir Etapa
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
