import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Timeline,
  TimelineItem,
  TimelineConnector,
  TimelineHeader,
  TimelineIcon,
  TimelineBody,
} from "@/components/ui/timeline";
import {
  Search,
  Box,
  ArrowRight,
  CheckCircle,
  AlertTriangle,
  Package,
  Truck,
  Warehouse,
  Factory,
  Beaker,
  FileCheck
} from "lucide-react";

export default function ProducaoRastreabilidade() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchType, setSearchType] = useState("lote"); // lote, produto, ordem
  const [loading, setLoading] = useState(false);
  const [rastreabilidadeData, setRastreabilidadeData] = useState(null);

  const handleSearch = async () => {
    setLoading(true);
    // Mock data for demonstration
    const mockRastreabilidade = {
      codigo: "L202401-001",
      produto: "Óleo CBD 10% Full Spectrum",
      status: "Finalizado",
      data_inicio: "2024-01-10T08:00:00",
      data_fim: "2024-01-15T16:30:00",
      etapas: [
        {
          id: 1,
          tipo: "materia_prima",
          titulo: "Recebimento de Matéria Prima",
          data: "2024-01-10T08:00:00",
          status: "concluido",
          detalhes: {
            lote_mp: "MP2024-001",
            fornecedor: "CBD Solutions",
            nota_fiscal: "NF-123456"
          }
        },
        {
          id: 2,
          tipo: "analise",
          titulo: "Análise de Controle de Qualidade",
          data: "2024-01-11T10:15:00",
          status: "concluido",
          detalhes: {
            laudo: "CQ-2024-001",
            responsavel: "Maria Santos",
            resultado: "Aprovado"
          }
        },
        {
          id: 3,
          tipo: "producao",
          titulo: "Produção",
          data: "2024-01-12T09:00:00",
          status: "concluido",
          detalhes: {
            ordem_producao: "OP-2024-001",
            responsavel: "João Silva",
            quantidade: "1000 unidades"
          }
        },
        {
          id: 4,
          tipo: "qualidade",
          titulo: "Controle de Qualidade Final",
          data: "2024-01-14T14:20:00",
          status: "concluido",
          detalhes: {
            laudo: "CQ-2024-002",
            responsavel: "Pedro Costa",
            resultado: "Aprovado"
          }
        },
        {
          id: 5,
          tipo: "armazenamento",
          titulo: "Armazenamento",
          data: "2024-01-15T16:30:00",
          status: "concluido",
          detalhes: {
            localizacao: "Estoque PA - Setor A",
            responsavel: "Ana Oliveira"
          }
        }
      ]
    };

    setTimeout(() => {
      setRastreabilidadeData(mockRastreabilidade);
      setLoading(false);
    }, 1000);
  };

  const getIconForTipo = (tipo) => {
    switch (tipo) {
      case "materia_prima":
        return <Box />;
      case "analise":
        return <Beaker />;
      case "producao":
        return <Factory />;
      case "qualidade":
        return <FileCheck />;
      case "armazenamento":
        return <Warehouse />;
      default:
        return <Package />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Rastreabilidade</h2>
        <p className="text-gray-500">Rastreamento completo do processo produtivo</p>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Digite o número do lote, produto ou ordem de produção..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button onClick={handleSearch} disabled={loading}>
              <Search className="w-4 h-4 mr-2" />
              Buscar
            </Button>
          </div>

          {loading && (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800"></div>
            </div>
          )}

          {rastreabilidadeData && !loading && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <p className="text-sm text-gray-500">Código</p>
                  <p className="font-medium">{rastreabilidadeData.codigo}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Produto</p>
                  <p className="font-medium">{rastreabilidadeData.produto}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Data Início</p>
                  <p className="font-medium">
                    {new Date(rastreabilidadeData.data_inicio).toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Data Fim</p>
                  <p className="font-medium">
                    {new Date(rastreabilidadeData.data_fim).toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="border rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Linha do Tempo</h3>
                <div className="space-y-4">
                  {rastreabilidadeData.etapas.map((etapa, index) => (
                    <div key={etapa.id} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                          {getIconForTipo(etapa.tipo)}
                        </div>
                        {index < rastreabilidadeData.etapas.length - 1 && (
                          <div className="w-0.5 h-full bg-gray-200 my-2"></div>
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium">{etapa.titulo}</h4>
                          <Badge variant="outline">
                            {new Date(etapa.data).toLocaleString()}
                          </Badge>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-3">
                          {Object.entries(etapa.detalhes).map(([key, value]) => (
                            <div key={key} className="flex gap-2 text-sm">
                              <span className="text-gray-500 capitalize">
                                {key.replace('_', ' ')}:
                              </span>
                              <span>{value}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}