
import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Search, 
  Filter, 
  UserPlus, 
  Eye, 
  Edit, 
  Trash2, 
  Download,
  Mail,
  Phone,
  Calendar,
  FileText,
  ArrowUpDown,
  ChevronDown,
  Activity,
  FileInput,
  PlusCircle,
  Heart,
  Brain,
  FlaskConical,
  FileCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function BancoPacientes() {
  const [pacientes, setPacientes] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [condicaoFilter, setCondicaoFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [pacientesPerPage] = useState(10);
  const [selectedPaciente, setSelectedPaciente] = useState(null);
  const [showModal, setShowModal] = useState(false);

  // Mock data
  const mockPacientes = [
    {
      id: "1",
      nome: "Maria Silva",
      idade: 42,
      genero: "Feminino",
      data_nascimento: "1981-05-15",
      cpf: "123.456.789-00",
      telefone: "(11) 99999-8888",
      email: "maria.silva@exemplo.com",
      condicao_principal: "Epilepsia",
      condicoes_secundarias: ["Ansiedade", "Insônia"],
      status: "ativo",
      data_cadastro: "2023-01-10",
      ultima_atualizacao: "2023-11-22",
      prescricoes: 3,
      consultas: 5,
      pesquisas_associadas: ["Estudo sobre epilepsia refratária"],
      resultados_exames: [
        { id: "e1", tipo: "EEG", data: "2023-09-15", url: "#" },
        { id: "e2", tipo: "Ressonância", data: "2023-08-01", url: "#" }
      ],
      consentimentos: [
        { id: "c1", tipo: "TCLE", data_assinatura: "2023-01-10", valido: true }
      ],
      medicamentos_atuais: [
        { nome: "CBD Oil 5%", dosagem: "15mg 2x ao dia" },
        { nome: "Carbamazepina", dosagem: "200mg 3x ao dia" }
      ],
      observacoes: "Paciente com boa aderência ao tratamento. Redução significativa de crises epilépticas."
    },
    {
      id: "2",
      nome: "João Oliveira",
      idade: 58,
      genero: "Masculino",
      data_nascimento: "1965-11-22",
      cpf: "987.654.321-00",
      telefone: "(11) 98888-7777",
      email: "joao.oliveira@exemplo.com",
      condicao_principal: "Dor crônica",
      condicoes_secundarias: ["Artrite", "Fibromialgia"],
      status: "ativo",
      data_cadastro: "2023-02-05",
      ultima_atualizacao: "2023-10-18",
      prescricoes: 5,
      consultas: 8,
      pesquisas_associadas: ["Estudo sobre dor neuropática"],
      resultados_exames: [
        { id: "e3", tipo: "Raio-X", data: "2023-07-10", url: "#" }
      ],
      consentimentos: [
        { id: "c2", tipo: "TCLE", data_assinatura: "2023-02-05", valido: true },
        { id: "c3", tipo: "Uso de dados", data_assinatura: "2023-02-05", valido: true }
      ],
      medicamentos_atuais: [
        { nome: "CBD/THC 1:1", dosagem: "10mg 3x ao dia" },
        { nome: "Pregabalina", dosagem: "75mg 2x ao dia" }
      ],
      observacoes: "Relatou melhora significativa na dor e qualidade de sono. Redução de 60% no uso de opioides."
    },
    {
      id: "3",
      nome: "Ana Santos",
      idade: 35,
      genero: "Feminino",
      data_nascimento: "1988-04-12",
      cpf: "456.789.123-00",
      telefone: "(11) 97777-6666",
      email: "ana.santos@exemplo.com",
      condicao_principal: "Ansiedade",
      condicoes_secundarias: ["Depressão", "Insônia"],
      status: "ativo",
      data_cadastro: "2023-03-15",
      ultima_atualizacao: "2023-12-01",
      prescricoes: 2,
      consultas: 4,
      pesquisas_associadas: [],
      resultados_exames: [],
      consentimentos: [
        { id: "c4", tipo: "TCLE", data_assinatura: "2023-03-15", valido: true }
      ],
      medicamentos_atuais: [
        { nome: "CBD Oil 2.5%", dosagem: "25mg à noite" },
        { nome: "Escitalopram", dosagem: "10mg 1x ao dia" }
      ],
      observacoes: "Paciente relata melhora no controle da ansiedade e qualidade do sono."
    }
  ];

  useEffect(() => {
    const fetchPacientes = async () => {
      setIsLoading(true);
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        setPacientes(mockPacientes);
      } catch (error) {
        console.error("Erro ao carregar pacientes:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPacientes();
  }, []);

  // Filtering
  const filteredPacientes = pacientes.filter(paciente => {
    const matchesSearch = 
      paciente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      paciente.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      paciente.cpf.includes(searchTerm);
    
    const matchesCondicao = 
      condicaoFilter === 'all' || 
      paciente.condicao_principal.toLowerCase() === condicaoFilter.toLowerCase() ||
      paciente.condicoes_secundarias.some(c => c.toLowerCase() === condicaoFilter.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || paciente.status === statusFilter;
    
    return matchesSearch && matchesCondicao && matchesStatus;
  });

  // Pagination
  const indexOfLastPaciente = currentPage * pacientesPerPage;
  const indexOfFirstPaciente = indexOfLastPaciente - pacientesPerPage;
  const currentPacientes = filteredPacientes.slice(indexOfFirstPaciente, indexOfLastPaciente);
  const totalPages = Math.ceil(filteredPacientes.length / pacientesPerPage);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const handleViewPaciente = (paciente) => {
    setSelectedPaciente(paciente);
    setShowModal(true);
  };

  // Format date to dd/mm/yyyy
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Banco de Pacientes</h1>
          <p className="text-muted-foreground">Gerencie pacientes para pesquisas científicas</p>
        </div>
        <div className="flex gap-2">
          <Button>
            <UserPlus className="w-4 h-4 mr-2" />
            Novo Paciente
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar por nome, email ou CPF..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={condicaoFilter} onValueChange={setCondicaoFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Condição" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as Condições</SelectItem>
            <SelectItem value="epilepsia">Epilepsia</SelectItem>
            <SelectItem value="dor crônica">Dor Crônica</SelectItem>
            <SelectItem value="ansiedade">Ansiedade</SelectItem>
            <SelectItem value="insônia">Insônia</SelectItem>
            <SelectItem value="autismo">Autismo</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Status</SelectItem>
            <SelectItem value="ativo">Ativo</SelectItem>
            <SelectItem value="inativo">Inativo</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Patients Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Idade</TableHead>
                <TableHead>Condição Principal</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Consultas</TableHead>
                <TableHead>Prescr.</TableHead>
                <TableHead>Última Atualização</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-4">
                    Carregando pacientes...
                  </TableCell>
                </TableRow>
              ) : currentPacientes.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-4">
                    Nenhum paciente encontrado.
                  </TableCell>
                </TableRow>
              ) : (
                currentPacientes.map((paciente) => (
                  <TableRow key={paciente.id}>
                    <TableCell className="font-medium">{paciente.nome}</TableCell>
                    <TableCell>{paciente.idade}</TableCell>
                    <TableCell>
                      <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                        {paciente.condicao_principal}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={paciente.status === 'ativo' ? 'default' : 'secondary'}
                      >
                        {paciente.status === 'ativo' ? 'Ativo' : 'Inativo'}
                      </Badge>
                    </TableCell>
                    <TableCell>{paciente.consultas}</TableCell>
                    <TableCell>{paciente.prescricoes}</TableCell>
                    <TableCell>{formatDate(paciente.ultima_atualizacao)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <ChevronDown className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleViewPaciente(paciente)}>
                            <Eye className="mr-2 h-4 w-4" />
                            <span>Visualizar</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            <span>Editar</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <FileText className="mr-2 h-4 w-4" />
                            <span>Documentos</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="mr-2 h-4 w-4" />
                            <span>Excluir</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex items-center justify-between border-t px-6 py-4">
          <div className="text-sm text-muted-foreground">
            Mostrando {indexOfFirstPaciente + 1}-{Math.min(indexOfLastPaciente, filteredPacientes.length)} de {filteredPacientes.length} pacientes
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => paginate(currentPage - 1)}
              disabled={currentPage === 1}
            >
              Anterior
            </Button>
            {Array.from({ length: totalPages }, (_, i) => (
              <Button
                key={i + 1}
                variant={currentPage === i + 1 ? "default" : "outline"}
                size="sm"
                onClick={() => paginate(i + 1)}
              >
                {i + 1}
              </Button>
            ))}
            <Button
              variant="outline"
              size="sm"
              onClick={() => paginate(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              Próximo
            </Button>
          </div>
        </CardFooter>
      </Card>

      {/* Patient Detail Modal */}
      {selectedPaciente && (
        <Dialog open={showModal} onOpenChange={setShowModal}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Detalhes do Paciente</DialogTitle>
              <DialogDescription>
                Informações completas e histórico do paciente
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="info" className="mt-4">
              <TabsList className="grid grid-cols-4">
                <TabsTrigger value="info">Informações</TabsTrigger>
                <TabsTrigger value="medical">Dados Médicos</TabsTrigger>
                <TabsTrigger value="research">Pesquisas</TabsTrigger>
                <TabsTrigger value="documents">Documentos</TabsTrigger>
              </TabsList>
              
              <TabsContent value="info" className="mt-4 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Nome Completo</h3>
                    <p>{selectedPaciente.nome}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">CPF</h3>
                    <p>{selectedPaciente.cpf}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Data de Nascimento</h3>
                    <p>{formatDate(selectedPaciente.data_nascimento)} ({selectedPaciente.idade} anos)</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Gênero</h3>
                    <p>{selectedPaciente.genero}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Email</h3>
                    <p>{selectedPaciente.email}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Telefone</h3>
                    <p>{selectedPaciente.telefone}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Data de Cadastro</h3>
                    <p>{formatDate(selectedPaciente.data_cadastro)}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Última Atualização</h3>
                    <p>{formatDate(selectedPaciente.ultima_atualizacao)}</p>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="medical" className="mt-4 space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Condição Principal</h3>
                  <Badge className="mt-1 bg-blue-100 text-blue-800">{selectedPaciente.condicao_principal}</Badge>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Condições Secundárias</h3>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {selectedPaciente.condicoes_secundarias.map((condicao, index) => (
                      <Badge key={index} variant="outline">{condicao}</Badge>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Medicamentos Atuais</h3>
                  <div className="space-y-2 mt-1">
                    {selectedPaciente.medicamentos_atuais.map((med, index) => (
                      <div key={index} className="flex items-center gap-2 p-2 border rounded-md">
                        <FlaskConical className="h-4 w-4 text-green-500" />
                        <div>
                          <span className="font-medium">{med.nome}</span>
                          <span className="text-sm text-muted-foreground ml-2">({med.dosagem})</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Observações</h3>
                  <p className="mt-1 text-sm">{selectedPaciente.observacoes}</p>
                </div>
              </TabsContent>
              
              <TabsContent value="research" className="mt-4 space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Pesquisas Associadas</h3>
                  <div className="space-y-2 mt-1">
                    {selectedPaciente.pesquisas_associadas.length > 0 ? (
                      selectedPaciente.pesquisas_associadas.map((pesquisa, index) => (
                        <div key={index} className="flex items-center gap-2 p-2 border rounded-md">
                          <Heart className="h-4 w-4 text-purple-500" />
                          <span>{pesquisa}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">Nenhuma pesquisa associada.</p>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Consentimentos</h3>
                  <div className="space-y-2 mt-1">
                    {selectedPaciente.consentimentos.map((consentimento, index) => (
                      <div key={index} className="flex items-center justify-between p-2 border rounded-md">
                        <div className="flex items-center gap-2">
                          <FileCheck className="h-4 w-4 text-green-500" />
                          <span>{consentimento.tipo}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">
                            Assinado em: {formatDate(consentimento.data_assinatura)}
                          </span>
                          <Badge variant={consentimento.valido ? "default" : "destructive"}>
                            {consentimento.valido ? "Válido" : "Inválido"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="documents" className="mt-4 space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Resultados de Exames</h3>
                  <div className="space-y-2 mt-1">
                    {selectedPaciente.resultados_exames.length > 0 ? (
                      selectedPaciente.resultados_exames.map((exame, index) => (
                        <div key={index} className="flex items-center justify-between p-2 border rounded-md">
                          <div className="flex items-center gap-2">
                            <Activity className="h-4 w-4 text-blue-500" />
                            <span>{exame.tipo}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-muted-foreground">
                              Data: {formatDate(exame.data)}
                            </span>
                            <Button variant="outline" size="sm">
                              <Download className="h-3 w-3 mr-1" />
                              Baixar
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">Nenhum exame disponível.</p>
                    )}
                  </div>
                </div>
                
                <div className="mt-4">
                  <Button>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Adicionar Documento
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowModal(false)}>
                Fechar
              </Button>
              <Button>
                <Edit className="h-4 w-4 mr-2" />
                Editar Paciente
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
