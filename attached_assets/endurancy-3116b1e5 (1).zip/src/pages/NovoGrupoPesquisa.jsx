import React, { useState } from 'react';
import { 
  Save, 
  Plus, 
  Trash2, 
  XCircle,
  User,
  Users,
  Microscope,
  Building2,
  Mail,
  Phone,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function NovoGrupoPesquisa() {
  const navigate = useNavigate();
  const [membros, setMembros] = useState([{ nome: '', funcao: '', email: '' }]);

  const addMembro = () => {
    setMembros([...membros, { nome: '', funcao: '', email: '' }]);
  };

  const removeMembro = (index) => {
    const novosMembros = [...membros];
    novosMembros.splice(index, 1);
    setMembros(novosMembros);
  };

  const updateMembro = (index, field, value) => {
    const novosMembros = [...membros];
    novosMembros[index][field] = value;
    setMembros(novosMembros);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Implementar lógica de salvamento
    navigate(createPageUrl("GruposPesquisa"));
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Novo Grupo de Pesquisa</h1>
          <p className="text-muted-foreground">Cadastre um novo grupo de pesquisa</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => navigate(createPageUrl("GruposPesquisa"))}
          >
            <XCircle className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button 
            className="bg-green-600 hover:bg-green-700"
            onClick={handleSubmit}
          >
            <Save className="w-4 h-4 mr-2" />
            Salvar
          </Button>
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Informações Básicas</CardTitle>
            <CardDescription>
              Preencha as informações básicas do grupo de pesquisa
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Nome do Grupo</label>
              <Input placeholder="Digite o nome do grupo" />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Área de Atuação</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a área" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="neurologia">Neurologia</SelectItem>
                  <SelectItem value="psiquiatria">Psiquiatria</SelectItem>
                  <SelectItem value="dor_cronica">Dor Crônica</SelectItem>
                  <SelectItem value="oncologia">Oncologia</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Descrição</label>
              <Textarea 
                placeholder="Descreva o objetivo e foco do grupo"
                className="min-h-[100px]"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <Select defaultValue="ativo">
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativo">Ativo</SelectItem>
                  <SelectItem value="inativo">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Líder do Grupo</CardTitle>
            <CardDescription>
              Informações sobre o líder do grupo de pesquisa
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Nome do Líder</label>
              <Input placeholder="Nome completo do líder" />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Especialidade</label>
              <Input placeholder="Especialidade do líder" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Email</label>
                <Input placeholder="Email do líder" type="email" />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Telefone</label>
                <Input placeholder="Telefone do líder" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Membros da Equipe</CardTitle>
                <CardDescription>
                  Adicione os membros que farão parte do grupo
                </CardDescription>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={addMembro}
              >
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Membro
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {membros.map((membro, index) => (
                <div 
                  key={index} 
                  className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 border rounded-lg relative"
                >
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2"
                    onClick={() => removeMembro(index)}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Nome</label>
                    <Input
                      value={membro.nome}
                      onChange={(e) => updateMembro(index, 'nome', e.target.value)}
                      placeholder="Nome do membro"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Função</label>
                    <Input
                      value={membro.funcao}
                      onChange={(e) => updateMembro(index, 'funcao', e.target.value)}
                      placeholder="Função no grupo"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Email</label>
                    <Input
                      value={membro.email}
                      onChange={(e) => updateMembro(index, 'email', e.target.value)}
                      placeholder="Email do membro"
                      type="email"
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}