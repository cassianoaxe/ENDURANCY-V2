import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { PaymentIntegration } from '@/api/entities';
import {
  Zap,
  Plus,
  Edit,
  Trash2,
  ExternalLink,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Info,
  MoreHorizontal,
  Check,
  X,
  CreditCard,
  Shield
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/components/ui/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

import PaymentIntegrationForm from '@/components/complypay/PaymentIntegrationForm';

export default function ComplyPayIntegrations() {
  const navigate = useNavigate();
  const [integrations, setIntegrations] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [selectedIntegration, setSelectedIntegration] = useState(null);
  const [showEditDialog, setShowEditDialog] = useState(false);

  // Fetch integrations on component mount
  useEffect(() => {
    fetchIntegrations();
  }, []);

  const fetchIntegrations = async () => {
    setIsLoading(true);
    try {
      // In a real implementation, this would fetch from the API
      // For demonstration, we'll use mock data
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
      
      const mockIntegrations = [
        {
          id: 'int-1',
          name: 'Stripe Payments',
          provider: 'stripe',
          mode: 'sandbox',
          is_active: true,
          api_key: 'pk_test_51...',
          api_secret: 'sk_test_51...',
          supported_methods: ['credit_card', 'debit_card'],
          default_currency: 'BRL',
          connection_status: 'connected',
          last_tested: '2023-11-10T15:30:00Z'
        },
        {
          id: 'int-2',
          name: 'PagSeguro',
          provider: 'pagseguro',
          mode: 'sandbox',
          is_active: true,
          api_key: 'token',
          merchant_id: 'email@example.com',
          supported_methods: ['credit_card', 'boleto', 'pix'],
          default_currency: 'BRL',
          connection_status: 'connected',
          last_tested: '2023-11-12T09:45:00Z'
        },
        {
          id: 'int-3',
          name: 'PayPal Assinaturas',
          provider: 'paypal',
          mode: 'sandbox',
          is_active: false,
          client_id: 'client_id',
          client_secret: 'client_secret',
          supported_methods: ['credit_card'],
          default_currency: 'USD',
          connection_status: 'disconnected',
          last_tested: '2023-10-25T14:20:00Z'
        }
      ];
      
      setIntegrations(mockIntegrations);
    } catch (error) {
      toast({
        title: "Erro ao carregar integrações",
        description: error.message || "Não foi possível carregar as integrações de pagamento.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddIntegration = async (integrationData) => {
    try {
      // In a real implementation, this would call the API to create the integration
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      
      const newIntegration = {
        id: `int-${Date.now()}`,
        ...integrationData,
        connection_status: 'pending',
        last_tested: new Date().toISOString()
      };
      
      setIntegrations(prev => [...prev, newIntegration]);
      setShowAddDialog(false);
      
      toast({
        title: "Integração adicionada",
        description: `A integração '${integrationData.name}' foi adicionada com sucesso.`
      });
    } catch (error) {
      toast({
        title: "Erro ao adicionar integração",
        description: error.message || "Ocorreu um erro ao adicionar a integração.",
        variant: "destructive"
      });
    }
  };

  const handleUpdateIntegration = async (integrationData) => {
    try {
      // In a real implementation, this would call the API to update the integration
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      
      setIntegrations(prev => 
        prev.map(integration => 
          integration.id === selectedIntegration.id 
            ? { ...integration, ...integrationData, last_tested: new Date().toISOString() } 
            : integration
        )
      );
      setShowEditDialog(false);
      setSelectedIntegration(null);
      
      toast({
        title: "Integração atualizada",
        description: `A integração '${integrationData.name}' foi atualizada com sucesso.`
      });
    } catch (error) {
      toast({
        title: "Erro ao atualizar integração",
        description: error.message || "Ocorreu um erro ao atualizar a integração.",
        variant: "destructive"
      });
    }
  };

  const handleToggleStatus = async (integration) => {
    try {
      // In a real implementation, this would call the API to toggle the status
      await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API call
      
      setIntegrations(prev => 
        prev.map(item => 
          item.id === integration.id 
            ? { ...item, is_active: !item.is_active } 
            : item
        )
      );
      
      toast({
        title: integration.is_active ? "Integração desativada" : "Integração ativada",
        description: `A integração '${integration.name}' foi ${integration.is_active ? 'desativada' : 'ativada'} com sucesso.`
      });
    } catch (error) {
      toast({
        title: "Erro ao alterar status",
        description: error.message || "Ocorreu um erro ao alterar o status da integração.",
        variant: "destructive"
      });
    }
  };

  const handleTestConnection = async (integration) => {
    try {
      // In a real implementation, this would call the API to test the connection
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate API call
      
      // Simulate success or failure based on provider
      const success = ['stripe', 'paypal', 'mercadopago'].includes(integration.provider);
      
      if (success) {
        setIntegrations(prev => 
          prev.map(item => 
            item.id === integration.id 
              ? { ...item, connection_status: 'connected', last_tested: new Date().toISOString() } 
              : item
          )
        );
        
        toast({
          title: "Conexão estabelecida",
          description: `Conexão com ${getProviderName(integration.provider)} testada com sucesso.`
        });
      } else {
        setIntegrations(prev => 
          prev.map(item => 
            item.id === integration.id 
              ? { ...item, connection_status: 'error', last_tested: new Date().toISOString() } 
              : item
          )
        );
        
        toast({
          title: "Falha na conexão",
          description: "Não foi possível conectar com o provedor. Verifique suas credenciais.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Erro ao testar conexão",
        description: error.message || "Ocorreu um erro ao testar a conexão.",
        variant: "destructive"
      });
    }
  };

  const handleDeleteIntegration = async () => {
    try {
      if (!selectedIntegration) return;
      
      // In a real implementation, this would call the API to delete the integration
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      
      setIntegrations(prev => prev.filter(item => item.id !== selectedIntegration.id));
      setShowConfirmDelete(false);
      setSelectedIntegration(null);
      
      toast({
        title: "Integração removida",
        description: `A integração '${selectedIntegration.name}' foi removida com sucesso.`
      });
    } catch (error) {
      toast({
        title: "Erro ao remover integração",
        description: error.message || "Ocorreu um erro ao remover a integração.",
        variant: "destructive"
      });
    }
  };

  const getProviderName = (provider) => {
    const providers = {
      'stripe': 'Stripe',
      'paypal': 'PayPal',
      'pagseguro': 'PagSeguro',
      'mercadopago': 'Mercado Pago',
      'cielo': 'Cielo',
      'rede': 'Rede',
      'stone': 'Stone',
      'custom': 'Personalizado'
    };
    return providers[provider] || provider;
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'connected':
        return <Badge variant="success" className="flex items-center gap-1"><CheckCircle className="h-3 w-3" /> Conectado</Badge>;
      case 'disconnected':
        return <Badge variant="secondary" className="flex items-center gap-1"><XCircle className="h-3 w-3" /> Desconectado</Badge>;
      case 'error':
        return <Badge variant="destructive" className="flex items-center gap-1"><AlertTriangle className="h-3 w-3" /> Erro</Badge>;
      case 'pending':
        return <Badge variant="outline" className="flex items-center gap-1"><Info className="h-3 w-3" /> Pendente</Badge>;
      default:
        return <Badge variant="outline">Desconhecido</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Integrações de Pagamento</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Gerencie suas integrações com provedores de pagamento
          </p>
        </div>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Integração
        </Button>
      </div>

      {integrations.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>Nenhuma integração configurada</CardTitle>
            <CardDescription>
              Configure integrações com provedores de pagamento para habilitar transações no sistema.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-8 space-y-4">
              <div className="h-16 w-16 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                <Zap className="h-8 w-8 text-gray-400" />
              </div>
              <p className="text-center text-gray-500 max-w-md">
                Adicione integrações com provedores como Stripe, PayPal, PagSeguro e outros para processar pagamentos em seu negócio.
              </p>
              <Button onClick={() => setShowAddDialog(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Adicionar Integração
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Integrações Configuradas</CardTitle>
            <CardDescription>
              Lista de integrações com provedores de pagamento do sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Provedor</TableHead>
                  <TableHead>Ambiente</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Métodos de Pagamento</TableHead>
                  <TableHead>Última Verificação</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {integrations.map((integration) => (
                  <TableRow key={integration.id}>
                    <TableCell className="font-medium">{integration.name}</TableCell>
                    <TableCell>{getProviderName(integration.provider)}</TableCell>
                    <TableCell>
                      <Badge variant={integration.mode === 'production' ? 'default' : 'outline'}>
                        {integration.mode === 'production' ? 'Produção' : 'Sandbox'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <Badge variant={integration.is_active ? 'success' : 'secondary'}>
                          {integration.is_active ? 'Ativo' : 'Inativo'}
                        </Badge>
                        {getStatusBadge(integration.connection_status)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {integration.supported_methods?.map((method) => (
                          <Badge key={method} variant="outline" className="text-xs">
                            {method === 'credit_card' && 'Cartão de Crédito'}
                            {method === 'debit_card' && 'Cartão de Débito'}
                            {method === 'boleto' && 'Boleto'}
                            {method === 'pix' && 'PIX'}
                            {method === 'bank_transfer' && 'Transferência Bancária'}
                            {method === 'installments' && 'Parcelamento'}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      {integration.last_tested ? (
                        <span className="text-sm">
                          {format(new Date(integration.last_tested), 'dd/MM/yyyy HH:mm')}
                        </span>
                      ) : (
                        <span className="text-sm text-gray-500">Nunca testado</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => {
                              setSelectedIntegration(integration);
                              setShowEditDialog(true);
                            }}
                          >
                            <Edit className="mr-2 h-4 w-4" />
                            <span>Editar</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleToggleStatus(integration)}>
                            {integration.is_active ? (
                              <>
                                <X className="mr-2 h-4 w-4" />
                                <span>Desativar</span>
                              </>
                            ) : (
                              <>
                                <Check className="mr-2 h-4 w-4" />
                                <span>Ativar</span>
                              </>
                            )}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleTestConnection(integration)}>
                            <RefreshCw className="mr-2 h-4 w-4" />
                            <span>Testar Conexão</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-red-600 dark:text-red-400"
                            onClick={() => {
                              setSelectedIntegration(integration);
                              setShowConfirmDelete(true);
                            }}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            <span>Remover</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Add Integration Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Adicionar Nova Integração</DialogTitle>
            <DialogDescription>
              Configure uma nova integração com um provedor de pagamento
            </DialogDescription>
          </DialogHeader>
          
          <PaymentIntegrationForm
            isNew
            onSave={handleAddIntegration}
            onCancel={() => setShowAddDialog(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Integration Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Editar Integração</DialogTitle>
            <DialogDescription>
              Modifique as configurações da integração
            </DialogDescription>
          </DialogHeader>
          
          <PaymentIntegrationForm
            integration={selectedIntegration}
            onSave={handleUpdateIntegration}
            onCancel={() => {
              setShowEditDialog(false);
              setSelectedIntegration(null);
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Confirm Delete Dialog */}
      <Dialog open={showConfirmDelete} onOpenChange={setShowConfirmDelete}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Remoção</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja remover esta integração? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          
          {selectedIntegration && (
            <div className="py-4">
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Atenção</AlertTitle>
                <AlertDescription>
                  A remoção da integração "{selectedIntegration.name}" com {getProviderName(selectedIntegration.provider)} interromperá o processamento de pagamentos através deste provedor.
                </AlertDescription>
              </Alert>
            </div>
          )}
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowConfirmDelete(false);
                setSelectedIntegration(null);
              }}
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteIntegration}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Remover
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}