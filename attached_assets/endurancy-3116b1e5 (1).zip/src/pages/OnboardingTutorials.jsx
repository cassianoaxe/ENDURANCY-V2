
import React, { useState } from 'react';
import {
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress"; // Add this import
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Search,
  Leaf,
  Factory,
  ShoppingBag,
  Users,
  Settings,
  FileText,
  DollarSign,
  Scale,
  CheckCircle,
  Clock,
  BookOpen,
  PlayCircle,
  MousePointerClick,
  ArrowRight,
  BookMarked,
  Heart
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";

const tutorials = [
  {
    id: 'intro-platform',
    title: 'Introdução à Plataforma',
    description: 'Visão geral das funcionalidades e módulos',
    duration: '10 min',
    level: 'Iniciante',
    type: 'video',
    category: 'geral',
    tags: ['introdução', 'navegação', 'interface']
  },
  {
    id: 'cultivation-basics',
    title: 'Fundamentos do Cultivo',
    description: 'Aprenda a gerenciar o ciclo completo de cultivo',
    duration: '15 min',
    level: 'Iniciante',
    type: 'video',
    category: 'cultivo',
    tags: ['plantas', 'lotes', 'strains']
  },
  {
    id: 'production-quality',
    title: 'Controle de Qualidade na Produção',
    description: 'Processos de garantia de qualidade na produção',
    duration: '20 min',
    level: 'Intermediário',
    type: 'text',
    category: 'producao',
    tags: ['qualidade', 'testes', 'compliance']
  },
  {
    id: 'dispensary-management',
    title: 'Gestão de Dispensário',
    description: 'Operação completa do módulo de dispensário',
    duration: '25 min',
    level: 'Intermediário',
    type: 'interactive',
    category: 'dispensario',
    tags: ['PDV', 'estoque', 'vendas']
  },
  {
    id: 'financial-reports',
    title: 'Relatórios Financeiros',
    description: 'Como gerar e interpretar relatórios financeiros',
    duration: '15 min',
    level: 'Avançado',
    type: 'text',
    category: 'financeiro',
    tags: ['relatórios', 'DRE', 'fluxo de caixa']
  },
  {
    id: 'patient-registration',
    title: 'Cadastro de Pacientes',
    description: 'Processo completo de registro e gestão de pacientes',
    duration: '12 min',
    level: 'Iniciante',
    type: 'video',
    category: 'pacientes',
    tags: ['cadastro', 'documentos', 'prescrições']
  },
  {
    id: 'legal-compliance',
    title: 'Compliance Legal',
    description: 'Requisitos regulatórios e conformidade legal',
    duration: '30 min',
    level: 'Avançado',
    type: 'text',
    category: 'juridico',
    tags: ['regulação', 'documentação', 'legislação']
  },
  {
    id: 'task-workflow',
    title: 'Fluxo de Trabalho com Tarefas',
    description: 'Organização e gestão de tarefas com Kanban',
    duration: '15 min',
    level: 'Iniciante',
    type: 'interactive',
    category: 'tarefas',
    tags: ['kanban', 'produtividade', 'colaboração']
  },
  {
    id: 'social-program',
    title: 'Programa Social',
    description: 'Gestão de programas sociais e beneficiários',
    duration: '18 min',
    level: 'Intermediário',
    type: 'video',
    category: 'social',
    tags: ['beneficiários', 'assistência', 'relatórios']
  }
];

const modules = [
  {
    id: 'module1',
    title: 'Módulo de Introdução',
    description: 'Este módulo abrange os conceitos básicos da plataforma.',
    progress: 70,
    tutorials: tutorials.slice(0, 3),
  },
  {
    id: 'module2',
    title: 'Módulo de Cultivo',
    description: 'Neste módulo, você aprenderá sobre cultivo e produção.',
    progress: 50,
    tutorials: tutorials.slice(3, 6),
  },
  {
    id: 'module3',
    title: 'Módulo de Gestão',
    description: 'Você aprenderá sobre gestão financeira e de pacientes.',
    progress: 20,
    tutorials: tutorials.slice(6),
  },
];

export default function OnboardingTutorials() {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [activeTab, setActiveTab] = useState('module1');
  
  const filteredTutorials = tutorials.filter(tutorial => {
    const matchesSearch = tutorial.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         tutorial.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tutorial.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = activeCategory === 'all' || tutorial.category === activeCategory;

    return matchesSearch && matchesCategory;
  });
  
  const getCategoryIcon = (category) => {
    switch(category) {
      case 'cultivo': return <Leaf className="w-4 h-4" />;
      case 'producao': return <Factory className="w-4 h-4" />;
      case 'dispensario': return <ShoppingBag className="w-4 h-4" />;
      case 'pacientes': return <Users className="w-4 h-4" />;
      case 'financeiro': return <DollarSign className="w-4 h-4" />;
      case 'juridico': return <Scale className="w-4 h-4" />;
      case 'tarefas': return <CheckCircle className="w-4 h-4" />;
      case 'social': return <Heart className="w-4 h-4" />;
      default: return <BookOpen className="w-4 h-4" />;
    }
  };
  
  const getTypeIcon = (type) => {
    switch(type) {
      case 'video': return <PlayCircle className="w-4 h-4" />;
      case 'interactive': return <MousePointerClick className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };
  
  const getLevelColor = (level) => {
    switch(level) {
      case 'Iniciante': return 'bg-green-100 text-green-800';
      case 'Intermediário': return 'bg-amber-100 text-amber-800';
      case 'Avançado': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  const handleTutorialClick = (id) => {
    console.log(`Tutorial clicked: ${id}`);
    // Logic for handling tutorial click would go here
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Tutoriais</h1>
          <p className="text-gray-500 mt-1">
            Acesse tutoriais detalhados para cada módulo da plataforma
          </p>
        </div>
        
        <div className="relative w-72">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500 w-4 h-4" />
          <Input
            placeholder="Buscar tutoriais..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          {modules.map(module => (
            <TabsTrigger key={module.id} value={module.id} className="flex items-center gap-1">
              <BookMarked className="w-4 h-4" />
              {module.title}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {modules.map(module => (
          <TabsContent key={module.id} value={module.id} className="mt-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-gray-700" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">{module.title}</h2>
                  <p className="text-gray-500">{module.description}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium">{module.progress}%</span>
                  <Badge variant="outline">
                    {module.tutorials.filter(t => t.completed).length}/{module.tutorials.length} tutoriais
                  </Badge>
                </div>
                <Progress value={module.progress} className="h-2 w-32" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {module.tutorials.map(tutorial => (
                <Card 
                  key={tutorial.id}
                  className={`cursor-pointer hover:shadow-md transition-shadow ${tutorial.completed ? 'border-green-200' : ''}`}
                  onClick={() => handleTutorialClick(tutorial.id)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        {getTypeIcon(tutorial.type)}
                        <CardTitle className="text-base">{tutorial.title}</CardTitle>
                      </div>
                      {tutorial.completed && (
                        <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <p className="text-sm text-gray-500">{tutorial.description}</p>
                  </CardContent>
                  <CardFooter>
                    <div className="w-full flex justify-between items-center">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {tutorial.duration}
                      </Badge>
                      <Button 
                        variant={tutorial.completed ? "outline" : "default"} 
                        size="sm"
                      >
                        {tutorial.completed ? (
                          <>
                            <CheckCircle className="h-4 w-4" />
                            <span>Concluído</span>
                          </>
                        ) : (
                          <>
                            <PlayCircle className="h-4 w-4" />
                            <span>Iniciar</span>
                          </>
                        )}
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
