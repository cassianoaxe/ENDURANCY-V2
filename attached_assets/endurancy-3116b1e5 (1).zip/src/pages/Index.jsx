
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";

export default function Index() {
  const navigate = useNavigate();

  useEffect(() => {
    let isLoggingOut = false;
    
    try {
      isLoggingOut = sessionStorage.getItem('isLoggingOut') === 'true';
      if (isLoggingOut) {
        console.log("Logout state detected, redirecting to Access page");
        
        try {
          sessionStorage.removeItem('isLoggingOut');
          localStorage.removeItem('mockUserType');
          localStorage.removeItem('mockUserEmail');
          localStorage.removeItem('mockUserName');
          localStorage.removeItem('mockOrgType');
        } catch (error) {
          console.error("Error clearing storage during logout:", error);
        }
        
        navigate(createPageUrl("Access"));
        return;
      }
    } catch (error) {
      console.error("Error checking logout state:", error);
    }

    let userType = null;
    try {
      userType = localStorage.getItem('mockUserType');
    } catch (error) {
      console.error("Error reading localStorage:", error);
    }
    
    console.log("User type detected:", userType);
    
    if (!userType) {
      console.log("No user type detected, redirecting to Access page");
      navigate(createPageUrl("Access"));
    } else {
      console.log("User type detected:", userType);
      
      switch (userType) {
        case 'doctor':
          console.log("Redirecting to DoctorDashboard");
          navigate(createPageUrl("DoctorDashboard"));
          break;
        case 'patient':
          console.log("Redirecting to PatientDashboard");
          navigate(createPageUrl("PatientDashboard"));
          break;
        case 'comply':
          console.log("Redirecting to Dashboard");
          navigate(createPageUrl("Dashboard"));
          break;
        case 'orgadmin':
          console.log("Redirecting to OrgDashboard");
          navigate(createPageUrl("OrgDashboard"));
          break;
        default:
          console.log("Unknown user type, redirecting to Access page");
          navigate(createPageUrl("Access"));
      }
    }
  }, [navigate]);

  return <div>Redirecionando...</div>;
}
