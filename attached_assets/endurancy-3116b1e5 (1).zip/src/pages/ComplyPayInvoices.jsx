import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  Invoice, 
  PaymentTransaction 
} from '@/api/entities';
import {
  Receipt,
  Search,
  Download,
  FileText,
  Plus,
  Filter,
  Clock,
  CheckCircle,
  AlertCircle,
  XCircle,
  Calendar,
  ArrowUpRight,
  FileSearch,
  Mail,
  MoreHorizontal,
  Edit,
  Trash2,
  Copy,
  Printer,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from '@/components/ui/use-toast';

export default function ComplyPayInvoices() {
  const navigate = useNavigate();
  const [invoices, setInvoices] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  // Sample data for demonstration
  const mockInvoices = [
    {
      id: 'inv-001',
      invoice_number: 'FAT-2023-001',
      status: 'paid',
      customer: { 
        name: 'João Silva', 
        email: 'joao.silva@exemplo.com' 
      },
      total: 1250.00,
      issue_date: '2023-09-15',
      due_date: '2023-09-30',
      payment_date: '2023-09-28'
    },
    {
      id: 'inv-002',
      invoice_number: 'FAT-2023-002',
      status: 'pending',
      customer: { 
        name: 'Maria Oliveira', 
        email: 'maria.oliveira@exemplo.com' 
      },
      total: 875.50,
      issue_date: '2023-10-01',
      due_date: '2023-10-15',
      payment_date: null
    },
    {
      id: 'inv-003',
      invoice_number: 'FAT-2023-003',
      status: 'overdue',
      customer: { 
        name: 'Carlos Santos', 
        email: 'carlos.santos@exemplo.com' 
      },
      total: 2100.00,
      issue_date: '2023-09-20',
      due_date: '2023-10-05',
      payment_date: null
    },
    {
      id: 'inv-004',
      invoice_number: 'FAT-2023-004',
      status: 'draft',
      customer: { 
        name: 'Ana Pereira', 
        email: 'ana.pereira@exemplo.com' 
      },
      total: 560.75,
      issue_date: '2023-10-05',
      due_date: '2023-10-20',
      payment_date: null
    },
    {
      id: 'inv-005',
      invoice_number: 'FAT-2023-005',
      status: 'sent',
      customer: { 
        name: 'Pedro Almeida', 
        email: 'pedro.almeida@exemplo.com' 
      },
      total: 1875.25,
      issue_date: '2023-10-08',
      due_date: '2023-10-23',
      payment_date: null
    }
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setInvoices(mockInvoices);
      setIsLoading(false);
    }, 1000);
  }, []);

  const filteredInvoices = invoices.filter(invoice => {
    const matchesSearch = 
      invoice.invoice_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.customer.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || invoice.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status) => {
    switch(status) {
      case 'paid':
        return <Badge className="bg-green-100 text-green-800">Pago</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'overdue':
        return <Badge className="bg-red-100 text-red-800">Vencido</Badge>;
      case 'draft':
        return <Badge className="bg-gray-100 text-gray-800">Rascunho</Badge>;
      case 'sent':
        return <Badge className="bg-blue-100 text-blue-800">Enviado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return format(new Date(dateString), 'dd/MM/yyyy', { locale: ptBR });
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Faturas</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Gerencie as faturas emitidas no sistema ComplyPay
          </p>
        </div>
        <Button onClick={() => toast({
          title: "Funcionalidade em desenvolvimento",
          description: "A criação de novas faturas estará disponível em breve."
        })}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Fatura
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input 
            placeholder="Buscar faturas..." 
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Filtrar por status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="draft">Rascunho</SelectItem>
              <SelectItem value="sent">Enviado</SelectItem>
              <SelectItem value="pending">Pendente</SelectItem>
              <SelectItem value="paid">Pago</SelectItem>
              <SelectItem value="overdue">Vencido</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={() => toast({
            title: "Exportação de faturas",
            description: "A exportação de faturas estará disponível em breve."
          })}>
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="p-4 pb-0">
          <CardTitle>Lista de Faturas</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center items-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
          ) : filteredInvoices.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nº da Fatura</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Data de Emissão</TableHead>
                  <TableHead>Vencimento</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell className="font-medium">{invoice.invoice_number}</TableCell>
                    <TableCell>
                      <div>
                        <p>{invoice.customer.name}</p>
                        <p className="text-sm text-gray-500">{invoice.customer.email}</p>
                      </div>
                    </TableCell>
                    <TableCell>{formatDate(invoice.issue_date)}</TableCell>
                    <TableCell>{formatDate(invoice.due_date)}</TableCell>
                    <TableCell>{formatCurrency(invoice.total)}</TableCell>
                    <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Abrir menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Ações</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => toast({
                            title: "Visualizar fatura",
                            description: "Esta funcionalidade estará disponível em breve."
                          })}>
                            <Eye className="mr-2 h-4 w-4" />
                            <span>Visualizar</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toast({
                            title: "Editar fatura",
                            description: "Esta funcionalidade estará disponível em breve."
                          })}>
                            <Edit className="mr-2 h-4 w-4" />
                            <span>Editar</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toast({
                            title: "Baixar PDF",
                            description: "Esta funcionalidade estará disponível em breve."
                          })}>
                            <Download className="mr-2 h-4 w-4" />
                            <span>Baixar PDF</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => toast({
                            title: "Enviar por e-mail",
                            description: "Esta funcionalidade estará disponível em breve."
                          })}>
                            <Mail className="mr-2 h-4 w-4" />
                            <span>Enviar por e-mail</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toast({
                            title: "Marcar como paga",
                            description: "Esta funcionalidade estará disponível em breve."
                          })}>
                            <CheckCircle className="mr-2 h-4 w-4" />
                            <span>Marcar como paga</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600" onClick={() => toast({
                            title: "Excluir fatura",
                            description: "Esta funcionalidade estará disponível em breve.",
                            variant: "destructive"
                          })}>
                            <Trash2 className="mr-2 h-4 w-4" />
                            <span>Excluir</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center p-8 text-center">
              <FileSearch className="h-16 w-16 text-gray-300 mb-4" />
              <h3 className="text-lg font-medium">Nenhuma fatura encontrada</h3>
              <p className="text-gray-500 mt-1 max-w-md">
                {searchTerm || filterStatus !== 'all' 
                  ? "Nenhuma fatura corresponde aos filtros aplicados." 
                  : "Ainda não há faturas registradas no sistema."}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}