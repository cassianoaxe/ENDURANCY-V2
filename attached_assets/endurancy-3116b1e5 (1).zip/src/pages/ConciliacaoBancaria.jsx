
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { UploadFile, ExtractDataFromUploadedFile } from "@/api/integrations";
import {
  UploadCloud,
  FileText,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Search,
  Download,
  Filter,
  ArrowUpDown,
  RefreshCw,
  DollarSign,
  Calendar,
  CornerDownRight,
  Link as LinkIcon,
  File,
  Save,
  DownloadCloud,
  Send,
  BarChart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from '@/components/ui/use-toast';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function ConciliacaoBancaria() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('extrato');
  const [fileUploaded, setFileUploaded] = useState(false);
  const [fileUrl, setFileUrl] = useState(null);
  const [fileName, setFileName] = useState('');
  const [processedData, setProcessedData] = useState([]);
  const [matchedTransactions, setMatchedTransactions] = useState([]);
  const [unmatchedBankTransactions, setUnmatchedBankTransactions] = useState([]);
  const [unmatchedSystemTransactions, setUnmatchedSystemTransactions] = useState([]);
  const [selectedAccount, setSelectedAccount] = useState('conta-principal');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [processingProgress, setProcessingProgress] = useState(0);
  const [conciliationSummary, setConciliationSummary] = useState(null);
  const [showManualMatch, setShowManualMatch] = useState(false);
  const [selectedBankTransaction, setSelectedBankTransaction] = useState(null);
  const [selectedSystemTransaction, setSelectedSystemTransaction] = useState(null);
  const fileInputRef = useRef(null);

  // Dados simulados de contas bancárias
  const bankAccounts = [
    { id: 'conta-principal', name: 'Conta Principal', bank: 'Banco do Brasil', accountNumber: '12345-6' },
    { id: 'conta-investimentos', name: 'Conta Investimentos', bank: 'Itaú', accountNumber: '98765-4' },
    { id: 'conta-despesas', name: 'Conta Despesas', bank: 'Bradesco', accountNumber: '45678-9' }
  ];

  // Dados simulados do sistema
  const systemTransactions = [
    { id: 'sys-1', date: '2023-05-01', description: 'Pagamento Fornecedor ABC', amount: -1250.00, category: 'Fornecedores', reconciled: false },
    { id: 'sys-2', date: '2023-05-03', description: 'Recebimento Cliente XYZ', amount: 3500.00, category: 'Vendas', reconciled: false },
    { id: 'sys-3', date: '2023-05-05', description: 'Despesa Energia Elétrica', amount: -450.75, category: 'Despesas Operacionais', reconciled: false },
    { id: 'sys-4', date: '2023-05-07', description: 'Pagamento Aluguel', amount: -2800.00, category: 'Aluguel', reconciled: true },
    { id: 'sys-5', date: '2023-05-10', description: 'Pagamento Colaborador 123', amount: -3200.00, category: 'Folha Pagamento', reconciled: false },
    { id: 'sys-6', date: '2023-05-12', description: 'Recebimento Cliente ABC', amount: 1780.50, category: 'Vendas', reconciled: false },
    { id: 'sys-7', date: '2023-05-15', description: 'Pagamento Internet', amount: -199.90, category: 'Despesas Operacionais', reconciled: false },
    { id: 'sys-8', date: '2023-05-18', description: 'Pagamento Imposto', amount: -945.33, category: 'Impostos', reconciled: true },
    { id: 'sys-9', date: '2023-05-20', description: 'Recebimento Cliente DEF', amount: 4200.00, category: 'Vendas', reconciled: false }
  ];

  // Função para lidar com upload de arquivo
  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsLoading(true);
    setFileName(file.name);
    
    try {
      // Simular upload
      setProcessingProgress(30);
      
      // Simular a chamada da API para upload
      // const { file_url } = await UploadFile({ file });
      const file_url = "https://example.com/placeholder.csv"; // Placeholder
      setFileUrl(file_url);
      setProcessingProgress(50);
      
      // Simular processamento do arquivo
      setTimeout(() => {
        setProcessingProgress(80);
        
        // Dados simulados do arquivo do banco
        const bankData = [
          { id: 'bank-1', date: '2023-05-01', description: 'TED PARA FORNECEDOR ABC', amount: -1250.00, balance: 15750.00 },
          { id: 'bank-2', date: '2023-05-03', description: 'TED DE CLIENTE XYZ', amount: 3500.00, balance: 19250.00 },
          { id: 'bank-3', date: '2023-05-05', description: 'DÉBITO ENERGIA', amount: -450.75, balance: 18799.25 },
          { id: 'bank-4', date: '2023-05-07', description: 'PAGTO ALUGUEL', amount: -2800.00, balance: 15999.25 },
          { id: 'bank-5', date: '2023-05-10', description: 'PAGTO SALÁRIO FUNC 123', amount: -3200.00, balance: 12799.25 },
          { id: 'bank-7', date: '2023-05-15', description: 'INTERNET', amount: -199.90, balance: 12599.35 },
          { id: 'bank-8', date: '2023-05-18', description: 'PAGTO DARF', amount: -945.33, balance: 11654.02 },
          { id: 'bank-10', date: '2023-05-25', description: 'TARIFA BANCÁRIA', amount: -69.90, balance: 11584.12 }
        ];
        
        setProcessedData(bankData);
        
        // Auto-matching simulado
        const matched = [
          { bankTransaction: bankData[0], systemTransaction: systemTransactions[0] },
          { bankTransaction: bankData[1], systemTransaction: systemTransactions[1] },
          { bankTransaction: bankData[2], systemTransaction: systemTransactions[2] },
          { bankTransaction: bankData[3], systemTransaction: systemTransactions[3] },
          { bankTransaction: bankData[5], systemTransaction: systemTransactions[6] },
          { bankTransaction: bankData[6], systemTransaction: systemTransactions[7] }
        ];
        
        setMatchedTransactions(matched);
        
        // Unmatched transactions
        setUnmatchedBankTransactions([bankData[4], bankData[7]]);
        setUnmatchedSystemTransactions([
          systemTransactions[4],
          systemTransactions[5],
          systemTransactions[8]
        ]);
        
        // Set reconciliation summary
        setConciliationSummary({
          totalBankTransactions: bankData.length,
          totalSystemTransactions: systemTransactions.length,
          matchedCount: matched.length,
          unmatchedBankCount: 2,
          unmatchedSystemCount: 3,
          matchPercentage: 66.67,
          systemBalance: 9000.52,
          bankBalance: 11584.12,
          difference: 2583.60
        });
        
        setProcessingProgress(100);
        setFileUploaded(true);
        setIsLoading(false);
      }, 1500);
      
    } catch (error) {
      console.error("Error uploading file:", error);
      toast({
        title: "Erro ao processar arquivo",
        description: "Ocorreu um erro ao processar o arquivo. Tente novamente.",
        variant: "destructive"
      });
      setIsLoading(false);
    }
  };

  // Função simulada para exportar relatório
  const exportReport = (format) => {
    toast({
      title: "Relatório exportado",
      description: `O relatório foi exportado no formato ${format.toUpperCase()}.`,
      variant: "default"
    });
  };

  // Função para buscar transações
  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
    // Implementar lógica de busca real aqui
  };

  // Função para reconciliar manualmente
  const reconcileManually = () => {
    if (!selectedBankTransaction || !selectedSystemTransaction) {
      toast({
        title: "Selecione as transações",
        description: "Você precisa selecionar uma transação bancária e uma transação do sistema para conciliar.",
        variant: "destructive"
      });
      return;
    }

    // Adicionar às transações conciliadas
    setMatchedTransactions([
      ...matchedTransactions,
      { 
        bankTransaction: selectedBankTransaction, 
        systemTransaction: selectedSystemTransaction 
      }
    ]);

    // Remover das listas de não conciliadas
    setUnmatchedBankTransactions(
      unmatchedBankTransactions.filter(t => t.id !== selectedBankTransaction.id)
    );
    setUnmatchedSystemTransactions(
      unmatchedSystemTransactions.filter(t => t.id !== selectedSystemTransaction.id)
    );

    // Atualizar resumo
    const newMatchedCount = matchedTransactions.length + 1;
    const newUnmatchedBankCount = unmatchedBankTransactions.length - 1;
    const newUnmatchedSystemCount = unmatchedSystemTransactions.length - 1;
    const totalTransactions = processedData.length;
    
    setConciliationSummary({
      ...conciliationSummary,
      matchedCount: newMatchedCount,
      unmatchedBankCount: newUnmatchedBankCount,
      unmatchedSystemCount: newUnmatchedSystemCount,
      matchPercentage: (newMatchedCount / totalTransactions) * 100
    });

    // Limpar seleções e fechar diálogo
    setSelectedBankTransaction(null);
    setSelectedSystemTransaction(null);
    setShowManualMatch(false);

    toast({
      title: "Conciliação manual realizada",
      description: "As transações foram conciliadas com sucesso.",
      variant: "default"
    });
  };

  // Função para finalizar conciliação
  const finalizeConciliation = () => {
    toast({
      title: "Conciliação finalizada",
      description: "A conciliação bancária foi finalizada e salva com sucesso.",
      variant: "default"
    });
    
    // Simulando exportação para contador
    setTimeout(() => {
      toast({
        title: "Dados exportados",
        description: "Os dados da conciliação foram exportados para o sistema contábil.",
        variant: "default"
      });
    }, 1500);
  };

  // Renderiza o componente de upload de arquivo
  const renderFileUpload = () => (
    <Card>
      <CardHeader>
        <CardTitle>Importar Extrato Bancário</CardTitle>
        <CardDescription>
          Importe o arquivo de extrato bancário para conciliação
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            className="hidden"
            accept=".csv,.ofx,.xls,.xlsx"
          />
          
          {!isLoading ? (
            <>
              <UploadCloud className="mx-auto h-12 w-12 text-gray-400" />
              <div className="mt-4">
                <Button onClick={() => fileInputRef.current.click()}>
                  Selecionar Arquivo
                </Button>
              </div>
              <p className="mt-2 text-sm text-gray-500">
                Formatos suportados: OFX, CSV, XLS, XLSX
              </p>
            </>
          ) : (
            <div className="space-y-4">
              <div className="mx-auto flex items-center justify-center">
                <RefreshCw className="h-8 w-8 animate-spin text-primary" />
              </div>
              <p className="text-sm font-medium">Processando arquivo...</p>
              <Progress value={processingProgress} className="h-2 w-[60%] mx-auto" />
              <p className="text-xs text-gray-500">{fileName}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  // Renderiza as transações conciliadas
  const renderMatchedTransactions = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Transações Conciliadas</h3>
        <Badge variant="outline" className="bg-green-50 text-green-700 dark:bg-green-900 dark:text-green-300">
          {matchedTransactions.length} transações
        </Badge>
      </div>
      
      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data</TableHead>
              <TableHead>Descrição Bancária</TableHead>
              <TableHead>Descrição Sistema</TableHead>
              <TableHead className="text-right">Valor (R$)</TableHead>
              <TableHead className="text-right">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {matchedTransactions.map(({ bankTransaction, systemTransaction }) => (
              <TableRow key={`${bankTransaction.id}-${systemTransaction.id}`}>
                <TableCell>{bankTransaction.date}</TableCell>
                <TableCell>{bankTransaction.description}</TableCell>
                <TableCell>{systemTransaction.description}</TableCell>
                <TableCell className="text-right">
                  <span className={bankTransaction.amount < 0 ? "text-red-600" : "text-green-600"}>
                    {bankTransaction.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                    Conciliado
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
            {matchedTransactions.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-4 text-gray-500">
                  Nenhuma transação conciliada ainda
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );

  // Renderiza as transações não conciliadas
  const renderUnmatchedTransactions = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Transações Não Conciliadas</h3>
        <Button onClick={() => setShowManualMatch(true)} disabled={unmatchedBankTransactions.length === 0 || unmatchedSystemTransactions.length === 0}>
          Conciliar Manualmente
        </Button>
      </div>
      
      {/* Transações bancárias não conciliadas */}
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <h4 className="text-md font-medium">Extrato Bancário</h4>
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300">
            {unmatchedBankTransactions.length} pendentes
          </Badge>
        </div>
        
        <div className="border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead className="text-right">Valor (R$)</TableHead>
                <TableHead className="text-right">Saldo (R$)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {unmatchedBankTransactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell>{transaction.date}</TableCell>
                  <TableCell>{transaction.description}</TableCell>
                  <TableCell className="text-right">
                    <span className={transaction.amount < 0 ? "text-red-600" : "text-green-600"}>
                      {transaction.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    {transaction.balance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </TableCell>
                </TableRow>
              ))}
              {unmatchedBankTransactions.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-4 text-gray-500">
                    Não há transações bancárias pendentes
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
      
      {/* Transações do sistema não conciliadas */}
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <h4 className="text-md font-medium">Sistema</h4>
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300">
            {unmatchedSystemTransactions.length} pendentes
          </Badge>
        </div>
        
        <div className="border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead className="text-right">Valor (R$)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {unmatchedSystemTransactions.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell>{transaction.date}</TableCell>
                  <TableCell>{transaction.description}</TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {transaction.category}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <span className={transaction.amount < 0 ? "text-red-600" : "text-green-600"}>
                      {transaction.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
              {unmatchedSystemTransactions.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-4 text-gray-500">
                    Não há transações do sistema pendentes
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );

  // Renderiza o resumo da conciliação
  const renderConciliationSummary = () => (
    <Card>
      <CardHeader>
        <CardTitle>Resumo da Conciliação</CardTitle>
      </CardHeader>
      <CardContent>
        {conciliationSummary ? (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <div className="border rounded-lg p-4">
                <p className="text-sm text-gray-500">Taxa de Conciliação</p>
                <p className="text-2xl font-bold">{conciliationSummary.matchPercentage.toFixed(2)}%</p>
                <Progress 
                  value={conciliationSummary.matchPercentage} 
                  className="h-2 mt-2"
                  color={conciliationSummary.matchPercentage > 90 ? "bg-green-500" : 
                          conciliationSummary.matchPercentage > 70 ? "bg-yellow-500" : 
                          "bg-red-500"}
                />
              </div>
              <div className="border rounded-lg p-4">
                <p className="text-sm text-gray-500">Saldo no Extrato</p>
                <p className="text-2xl font-bold">
                  {conciliationSummary.bankBalance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </p>
              </div>
              <div className="border rounded-lg p-4">
                <p className="text-sm text-gray-500">Saldo no Sistema</p>
                <p className="text-2xl font-bold">
                  {conciliationSummary.systemBalance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </p>
              </div>
            </div>
            
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-3">Diferenças</h3>
              <div className="flex flex-col space-y-4">
                <div className="flex justify-between">
                  <span>Saldo Bancário:</span>
                  <span className="font-medium">
                    {conciliationSummary.bankBalance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Saldo Sistema:</span>
                  <span className="font-medium">
                    {conciliationSummary.systemBalance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg">
                  <span>Diferença:</span>
                  <span className={conciliationSummary.difference === 0 ? "text-green-600 font-bold" : "text-red-600 font-bold"}>
                    {conciliationSummary.difference.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-3">Estatísticas</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Total de Transações</p>
                  <p className="text-xl font-semibold">{conciliationSummary.totalBankTransactions}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Conciliadas</p>
                  <p className="text-xl font-semibold text-green-600">{conciliationSummary.matchedCount}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Pendentes Banco</p>
                  <p className="text-xl font-semibold text-yellow-600">{conciliationSummary.unmatchedBankCount}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Pendentes Sistema</p>
                  <p className="text-xl font-semibold text-yellow-600">{conciliationSummary.unmatchedSystemCount}</p>
                </div>
              </div>
            </div>
            
            {conciliationSummary.matchPercentage === 100 && conciliationSummary.difference === 0 ? (
              <div className="bg-green-50 text-green-800 dark:bg-green-900 dark:text-green-100 p-4 rounded-lg flex items-center">
                <CheckCircle2 className="h-5 w-5 mr-2" />
                <span>Conciliação completa! Todos os itens estão conciliados e não há diferenças de saldo.</span>
              </div>
            ) : (
              <div className="bg-yellow-50 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100 p-4 rounded-lg flex items-center">
                <AlertCircle className="h-5 w-5 mr-2" />
                <span>Conciliação pendente. Existem itens não conciliados ou diferenças de saldo.</span>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-6 text-gray-500">
            <FileText className="h-12 w-12 mx-auto text-gray-300 mb-3" />
            <p>Importe um extrato para visualizar o resumo da conciliação</p>
          </div>
        )}
      </CardContent>
      {conciliationSummary && (
        <CardFooter>
          <div className="flex justify-end w-full gap-3">
            <Button variant="outline" onClick={() => exportReport('excel')}>
              <Download className="mr-2 h-4 w-4" />
              Exportar Relatório
            </Button>
            <Button onClick={finalizeConciliation}>
              <CheckCircle2 className="mr-2 h-4 w-4" />
              Finalizar Conciliação
            </Button>
          </div>
        </CardFooter>
      )}
    </Card>
  );

  // Modal de conciliação manual
  const renderManualMatchDialog = () => (
    <Dialog open={showManualMatch} onOpenChange={setShowManualMatch}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Conciliação Manual</DialogTitle>
          <DialogDescription>
            Selecione uma transação bancária e uma transação do sistema para conciliar manualmente.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="bank-transaction">Transação Bancária</Label>
            <Select
              value={selectedBankTransaction ? selectedBankTransaction.id : ""}
              onValueChange={(value) => {
                const transaction = unmatchedBankTransactions.find(t => t.id === value);
                setSelectedBankTransaction(transaction);
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma transação bancária" />
              </SelectTrigger>
              <SelectContent>
                {unmatchedBankTransactions.map((transaction) => (
                  <SelectItem key={transaction.id} value={transaction.id}>
                    {transaction.date} - {transaction.description.substring(0, 30)}... ({transaction.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="system-transaction">Transação do Sistema</Label>
            <Select
              value={selectedSystemTransaction ? selectedSystemTransaction.id : ""}
              onValueChange={(value) => {
                const transaction = unmatchedSystemTransactions.find(t => t.id === value);
                setSelectedSystemTransaction(transaction);
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma transação do sistema" />
              </SelectTrigger>
              <SelectContent>
                {unmatchedSystemTransactions.map((transaction) => (
                  <SelectItem key={transaction.id} value={transaction.id}>
                    {transaction.date} - {transaction.description.substring(0, 30)}... ({transaction.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {selectedBankTransaction && selectedSystemTransaction && (
            <div className="p-4 border rounded-lg space-y-4">
              <h4 className="font-medium">Comparativo</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Transação Bancária</p>
                  <p className="font-medium">{selectedBankTransaction.description}</p>
                  <p>Data: {selectedBankTransaction.date}</p>
                  <p>Valor: {selectedBankTransaction.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Transação Sistema</p>
                  <p className="font-medium">{selectedSystemTransaction.description}</p>
                  <p>Data: {selectedSystemTransaction.date}</p>
                  <p>Valor: {selectedSystemTransaction.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                </div>
              </div>
              
              {selectedBankTransaction.amount !== selectedSystemTransaction.amount && (
                <div className="bg-yellow-50 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100 p-3 rounded-lg flex items-center text-sm">
                  <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span>Os valores das transações são diferentes. Verifique se realmente são a mesma transação.</span>
                </div>
              )}
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setShowManualMatch(false)}>Cancelar</Button>
          <Button onClick={reconcileManually} disabled={!selectedBankTransaction || !selectedSystemTransaction}>
            Conciliar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Conciliação Bancária</h1>
          <p className="text-gray-500 mt-1">
            Importe extratos bancários e concilie com os lançamentos do sistema
          </p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedAccount} onValueChange={setSelectedAccount}>
            <SelectTrigger className="w-[220px]">
              <SelectValue placeholder="Selecione a conta" />
            </SelectTrigger>
            <SelectContent>
              {bankAccounts.map((account) => (
                <SelectItem key={account.id} value={account.id}>
                  {account.name} ({account.bank})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="extrato" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="extrato">
            <FileText className="w-4 h-4 mr-2" />
            Extrato
          </TabsTrigger>
          <TabsTrigger value="conciliacao" disabled={!fileUploaded}>
            <CheckCircle2 className="w-4 h-4 mr-2" />
            Conciliação
          </TabsTrigger>
          <TabsTrigger value="resumo" disabled={!fileUploaded}>
            <BarChart className="w-4 h-4 mr-2" />
            Resumo
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="extrato" className="mt-6">
          {!fileUploaded ? (
            renderFileUpload()
          ) : (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-medium">Extrato Bancário</h3>
                  <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
                    Importado
                  </Badge>
                </div>
                <div className="flex gap-2">
                  <div className="relative max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      type="search"
                      placeholder="Buscar transações..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={handleSearch}
                    />
                  </div>
                  <Select defaultValue="all" value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-[160px]">
                      <SelectValue placeholder="Filtrar por tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="credit">Créditos</SelectItem>
                      <SelectItem value="debit">Débitos</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead className="text-right">Valor (R$)</TableHead>
                      <TableHead className="text-right">Saldo (R$)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {processedData.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>{transaction.date}</TableCell>
                        <TableCell>{transaction.description}</TableCell>
                        <TableCell className="text-right">
                          <span className={transaction.amount < 0 ? "text-red-600" : "text-green-600"}>
                            {transaction.amount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          {transaction.balance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setActiveTab('conciliacao')}>
                  Iniciar Conciliação
                </Button>
              </div>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="conciliacao" className="mt-6">
          <div className="space-y-6">
            {renderMatchedTransactions()}
            
            <Separator />
            
            {renderUnmatchedTransactions()}
            
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setActiveTab('extrato')}>
                Voltar
              </Button>
              <Button onClick={() => setActiveTab('resumo')}>
                Ver Resumo
              </Button>
            </div>
            
            {renderManualMatchDialog()}
          </div>
        </TabsContent>
        
        <TabsContent value="resumo" className="mt-6">
          {renderConciliationSummary()}
        </TabsContent>
      </Tabs>
    </div>
  );
}
