import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Download, 
  Calendar, 
  Filter, 
  Plus, 
  DollarSign, 
  CreditCard, 
  Receipt, 
  Percent, 
  FileText, 
  Clock,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Building2,
  User,
  ArrowUpRight
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

// Sample revenue data
const revenueData = [
  { month: 'Jan', valor: 12500 },
  { month: 'Fev', valor: 14700 },
  { month: 'Mar', valor: 16200 },
  { month: 'Abr', valor: 16800 },
  { month: 'Mai', valor: 18500 },
  { month: 'Jun', valor: 22300 },
  { month: 'Jul', valor: 24600 }
];

// Sample distribution data
const distributionData = [
  { name: 'Empresarial Básico', value: 22 },
  { name: 'Empresarial Pro', value: 38 },
  { name: 'Associação Plus', value: 25 },
  { name: 'Associação Premium', value: 15 }
];

// Sample invoices data
const invoicesData = [
  {
    id: 'INV-2023-001',
    organization: 'Cannabis Brasil Medicinal',
    plan: 'Empresarial Pro',
    amount: 599.00,
    status: 'paid',
    issue_date: '2023-07-01T10:30:00Z',
    payment_date: '2023-07-05T14:45:00Z',
    payment_method: 'credit_card'
  },
  {
    id: 'INV-2023-002',
    organization: 'Associação Médica Verde',
    plan: 'Associação Plus',
    amount: 399.00,
    status: 'paid',
    issue_date: '2023-07-01T11:15:00Z',
    payment_date: '2023-07-03T09:30:00Z',
    payment_method: 'pix'
  },
  {
    id: 'INV-2023-003',
    organization: 'Cultivo Sustentável Ltda',
    plan: 'Empresarial Básico',
    amount: 299.00,
    status: 'pending',
    issue_date: '2023-07-01T12:00:00Z',
    payment_date: null,
    due_date: '2023-07-15T23:59:59Z',
    payment_method: null
  },
  {
    id: 'INV-2023-004',
    organization: 'Cannabis Terapêutica Sul',
    plan: 'Associação Premium',
    amount: 799.00,
    status: 'overdue',
    issue_date: '2023-06-01T10:30:00Z',
    payment_date: null,
    due_date: '2023-06-15T23:59:59Z',
    payment_method: null
  },
  {
    id: 'INV-2023-005',
    organization: 'MediCannabis Farma',
    plan: 'Empresarial Pro',
    amount: 599.00,
    status: 'paid',
    issue_date: '2023-07-01T14:30:00Z',
    payment_date: '2023-07-02T16:20:00Z',
    payment_method: 'bank_transfer'
  },
  {
    id: 'INV-2023-006',
    organization: 'Apoio Médico Cannabis',
    plan: 'Associação Premium',
    amount: 799.00,
    status: 'paid',
    issue_date: '2023-07-01T15:45:00Z',
    payment_date: '2023-07-10T11:30:00Z',
    payment_method: 'pix'
  },
  {
    id: 'INV-2023-007',
    organization: 'CannaPesquisa Instituto',
    plan: 'Associação Plus',
    amount: 399.00,
    status: 'pending',
    issue_date: '2023-07-01T16:20:00Z',
    payment_date: null,
    due_date: '2023-07-15T23:59:59Z',
    payment_method: null
  }
];

const COLORS = ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0'];

export default function Financial() {
  const [invoices, setInvoices] = useState(invoicesData);
  const [filteredInvoices, setFilteredInvoices] = useState(invoicesData);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [monthFilter, setMonthFilter] = useState('all');
  
  // Calculate financial metrics
  const totalRevenue = invoices.filter(inv => inv.status === 'paid').reduce((sum, inv) => sum + inv.amount, 0);
  const pendingRevenue = invoices.filter(inv => inv.status === 'pending').reduce((sum, inv) => sum + inv.amount, 0);
  const overdueRevenue = invoices.filter(inv => inv.status === 'overdue').reduce((sum, inv) => sum + inv.amount, 0);
  const invoicesPaid = invoices.filter(inv => inv.status === 'paid').length;
  const invoicesPending = invoices.filter(inv => inv.status === 'pending').length;
  const invoicesOverdue = invoices.filter(inv => inv.status === 'overdue').length;
  
  React.useEffect(() => {
    applyFilters();
  }, [searchTerm, statusFilter, monthFilter, invoices]);
  
  const applyFilters = () => {
    let filtered = [...invoices];
    
    if (searchTerm.trim() !== '') {
      filtered = filtered.filter(inv => 
        inv.organization.toLowerCase().includes(searchTerm.toLowerCase()) ||
        inv.id.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(inv => inv.status === statusFilter);
    }
    
    if (monthFilter !== 'all') {
      filtered = filtered.filter(inv => {
        const month = new Date(inv.issue_date).getMonth();
        return month === parseInt(monthFilter);
      });
    }
    
    setFilteredInvoices(filtered);
  };
  
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  const getStatusBadge = (status) => {
    switch (status) {
      case 'paid':
        return (
          <Badge className="bg-green-100 text-green-800">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Pago
          </Badge>
        );
      case 'pending':
        return (
          <Badge className="bg-yellow-100 text-yellow-800">
            <Clock className="w-3 h-3 mr-1" />
            Pendente
          </Badge>
        );
      case 'overdue':
        return (
          <Badge className="bg-red-100 text-red-800">
            <XCircle className="w-3 h-3 mr-1" />
            Vencido
          </Badge>
        );
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  const getPaymentMethodIcon = (method) => {
    switch (method) {
      case 'credit_card':
        return <CreditCard className="w-4 h-4 text-gray-500" />;
      case 'pix':
        return <DollarSign className="w-4 h-4 text-gray-500" />;
      case 'bank_transfer':
        return <Building2 className="w-4 h-4 text-gray-500" />;
      default:
        return null;
    }
  };
  
  const getPaymentMethodText = (method) => {
    switch (method) {
      case 'credit_card':
        return 'Cartão de Crédito';
      case 'pix':
        return 'PIX';
      case 'bank_transfer':
        return 'Transferência';
      default:
        return '-';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Financeiro</h1>
          <p className="text-gray-500 mt-1">
            Gerencie faturas e acompanhe métricas financeiras
          </p>
        </div>
        <Button className="gap-2 bg-green-600 hover:bg-green-700">
          <Plus className="w-4 h-4" />
          Nova Fatura
        </Button>
      </div>

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="invoices">Faturas</TabsTrigger>
          <TabsTrigger value="reports">Relatórios</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Faturamento Mensal</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl font-bold">{formatCurrency(totalRevenue)}</p>
                    <p className="text-sm text-green-600 flex items-center">
                      <TrendingUp className="w-4 h-4 mr-1" />
                      12% acima do mês anterior
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-full">
                    <DollarSign className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Pendente</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl font-bold">{formatCurrency(pendingRevenue)}</p>
                    <p className="text-sm text-gray-600 flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {invoicesPending} faturas
                    </p>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded-full">
                    <CreditCard className="w-6 h-6 text-yellow-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Vencido</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl font-bold">{formatCurrency(overdueRevenue)}</p>
                    <p className="text-sm text-red-600 flex items-center">
                      <ArrowUpRight className="w-4 h-4 mr-1" />
                      {invoicesOverdue} faturas
                    </p>
                  </div>
                  <div className="p-3 bg-red-50 rounded-full">
                    <Receipt className="w-6 h-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Receita Mensal</CardTitle>
                <CardDescription>
                  Receita total por mês
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={revenueData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis tickFormatter={(value) => `R$${value / 1000}k`} />
                      <Tooltip formatter={(value) => [`R$${value.toFixed(2)}`, 'Receita']} />
                      <Bar dataKey="valor" name="Receita" fill="#4CAF50" barSize={30} radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Distribuição por Plano</CardTitle>
                <CardDescription>
                  Receita por tipo de plano
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={distributionData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {distributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, 'Porcentagem']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="invoices" className="space-y-4 mt-6">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative md:w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar fatura..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Select
                defaultValue="all"
                onValueChange={setStatusFilter}
              >
                <SelectTrigger className="md:w-40">
                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4" />
                    <SelectValue placeholder="Status" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos Status</SelectItem>
                  <SelectItem value="paid">Pagos</SelectItem>
                  <SelectItem value="pending">Pendentes</SelectItem>
                  <SelectItem value="overdue">Vencidos</SelectItem>
                </SelectContent>
              </Select>
              
              <Select
                defaultValue="all"
                onValueChange={setMonthFilter}
              >
                <SelectTrigger className="md:w-40">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <SelectValue placeholder="Mês" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Meses</SelectItem>
                  <SelectItem value="0">Janeiro</SelectItem>
                  <SelectItem value="1">Fevereiro</SelectItem>
                  <SelectItem value="2">Março</SelectItem>
                  <SelectItem value="3">Abril</SelectItem>
                  <SelectItem value="4">Maio</SelectItem>
                  <SelectItem value="5">Junho</SelectItem>
                  <SelectItem value="6">Julho</SelectItem>
                  <SelectItem value="7">Agosto</SelectItem>
                  <SelectItem value="8">Setembro</SelectItem>
                  <SelectItem value="9">Outubro</SelectItem>
                  <SelectItem value="10">Novembro</SelectItem>
                  <SelectItem value="11">Dezembro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Exportar
            </Button>
          </div>
          
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fatura</TableHead>
                    <TableHead>Organização</TableHead>
                    <TableHead>Plano</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Pagamento</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInvoices.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        <FileText className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                        <h3 className="text-lg font-medium">Nenhuma fatura encontrada</h3>
                        <p className="text-gray-500 mt-1">
                          Tente ajustar os filtros de busca
                        </p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredInvoices.map(invoice => (
                      <TableRow key={invoice.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <Receipt className="w-4 h-4 text-gray-400" />
                            <span>{invoice.id}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Building2 className="w-4 h-4 text-gray-400" />
                            <span>{invoice.organization}</span>
                          </div>
                        </TableCell>
                        <TableCell>{invoice.plan}</TableCell>
                        <TableCell className="font-semibold">
                          {formatCurrency(invoice.amount)}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col text-sm">
                            <span>Emissão: {formatDate(invoice.issue_date)}</span>
                            {invoice.status === 'paid' ? (
                              <span className="text-green-600">
                                Pago em: {formatDate(invoice.payment_date)}
                              </span>
                            ) : (
                              <span className={invoice.status === 'overdue' ? 'text-red-600' : 'text-yellow-600'}>
                                Vencimento: {formatDate(invoice.due_date)}
                              </span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(invoice.status)}
                        </TableCell>
                        <TableCell>
                          {invoice.payment_method ? (
                            <div className="flex items-center gap-1">
                              {getPaymentMethodIcon(invoice.payment_method)}
                              <span>{getPaymentMethodText(invoice.payment_method)}</span>
                            </div>
                          ) : (
                            '-'
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="reports" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Relatórios Financeiros</CardTitle>
                <CardDescription>
                  Gere relatórios detalhados
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 border rounded-lg flex items-start gap-4">
                  <FileText className="w-8 h-8 text-blue-500" />
                  <div className="flex-1">
                    <h3 className="font-medium">Relatório de Faturamento Mensal</h3>
                    <p className="text-sm text-gray-500 mb-3">
                      Relatório detalhado de todas as faturas do mês
                    </p>
                    <Button size="sm">Gerar Relatório</Button>
                  </div>
                </div>
                
                <div className="p-4 border rounded-lg flex items-start gap-4">
                  <FileText className="w-8 h-8 text-green-500" />
                  <div className="flex-1">
                    <h3 className="font-medium">Relatório de Pagamentos</h3>
                    <p className="text-sm text-gray-500 mb-3">
                      Resumo de todos os pagamentos recebidos
                    </p>
                    <Button size="sm">Gerar Relatório</Button>
                  </div>
                </div>
                
                <div className="p-4 border rounded-lg flex items-start gap-4">
                  <FileText className="w-8 h-8 text-purple-500" />
                  <div className="flex-1">
                    <h3 className="font-medium">Relatório por Organização</h3>
                    <p className="text-sm text-gray-500 mb-3">
                      Histórico financeiro por organização
                    </p>
                    <Button size="sm">Gerar Relatório</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Configurações de Faturamento</CardTitle>
                <CardDescription>
                  Gerenciar preferências de faturamento
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="billing-day">Dia de Faturamento</Label>
                  <Select defaultValue="1">
                    <SelectTrigger id="billing-day">
                      <SelectValue placeholder="Selecione o dia" />
                    </SelectTrigger>
                    <SelectContent>
                      {[...Array(28)].map((_, i) => (
                        <SelectItem key={i} value={(i + 1).toString()}>
                          Dia {i + 1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500">
                    As faturas serão geradas neste dia de cada mês
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="payment-deadline">Prazo de Pagamento</Label>
                  <Select defaultValue="15">
                    <SelectTrigger id="payment-deadline">
                      <SelectValue placeholder="Selecione o prazo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 dias</SelectItem>
                      <SelectItem value="10">10 dias</SelectItem>
                      <SelectItem value="15">15 dias</SelectItem>
                      <SelectItem value="30">30 dias</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500">
                    Prazo para pagamento após a emissão da fatura
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="currency">Moeda</Label>
                  <Select defaultValue="BRL">
                    <SelectTrigger id="currency">
                      <SelectValue placeholder="Selecione a moeda" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BRL">Real Brasileiro (R$)</SelectItem>
                      <SelectItem value="USD">Dólar Americano ($)</SelectItem>
                      <SelectItem value="EUR">Euro (€)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="pt-4">
                  <Button className="w-full">Salvar Configurações</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}