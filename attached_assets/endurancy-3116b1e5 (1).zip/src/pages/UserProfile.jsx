import React, { useState, useEffect } from 'react';
import { User } from "@/api/entities";
import { 
  User as UserIcon, 
  Mail, 
  Phone, 
  Shield, 
  Key, 
  Calendar, 
  LogOut, 
  Building2,
  Save,
  Edit,
  Camera
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";

export default function UserProfile() {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("profile");
  const [isEditMode, setIsEditMode] = useState(false);
  const [userForm, setUserForm] = useState({
    full_name: "",
    job_title: "",
    phone: "",
    email: "",
    bio: ""
  });

  useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    try {
      setLoading(true);
      
      // Get user from localStorage in demo mode
      const mockUserType = localStorage.getItem('mockUserType');
      const mockUserEmail = localStorage.getItem('mockUserEmail');
      const mockUserName = localStorage.getItem('mockUserName');
      
      let userData;
      
      if (mockUserType && mockUserEmail) {
        userData = {
          id: "mock-user-1",
          full_name: mockUserName || "Usuário Demonstração",
          email: mockUserEmail,
          role: "admin",
          user_type: mockUserType,
          job_title: "Gestor de Plataforma",
          phone: "+55 (11) 98765-4321",
          bio: "Profissional com experiência na gestão de plataformas de saúde e cannabis medicinal.",
          created_date: "2023-01-15T10:30:00Z",
          last_login: "2023-07-22T08:45:00Z",
          preferences: {
            email_notifications: true,
            sms_notifications: false,
            two_factor_auth: false,
            dark_mode: false
          }
        };
      } else {
        try {
          userData = await User.me();
        } catch (error) {
          console.error("Error getting user", error);
          userData = null;
        }
      }
      
      setCurrentUser(userData);
      if (userData) {
        setUserForm({
          full_name: userData.full_name || "",
          job_title: userData.job_title || "",
          phone: userData.phone || "",
          email: userData.email || "",
          bio: userData.bio || ""
        });
      }
    } catch (error) {
      console.error("Error loading user profile", error);
      toast({
        title: "Erro ao carregar perfil",
        description: "Não foi possível carregar as informações do seu perfil.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    try {
      // In a real app, you would update the user data on the backend
      // For demo, we'll update the mock data in localStorage
      localStorage.setItem('mockUserName', userForm.full_name);
      
      setCurrentUser({
        ...currentUser,
        ...userForm
      });
      
      setIsEditMode(false);
      
      toast({
        title: "Perfil atualizado",
        description: "Suas informações foram atualizadas com sucesso.",
      });
    } catch (error) {
      console.error("Error updating profile", error);
      toast({
        title: "Erro ao atualizar perfil",
        description: "Não foi possível atualizar suas informações.",
        variant: "destructive"
      });
    }
  };

  const togglePreference = (preference) => {
    if (!currentUser || !currentUser.preferences) return;
    
    const updatedUser = { 
      ...currentUser,
      preferences: {
        ...currentUser.preferences,
        [preference]: !currentUser.preferences[preference]
      }
    };
    
    setCurrentUser(updatedUser);
    
    toast({
      title: "Preferência atualizada",
      description: `A preferência ${preference} foi atualizada.`,
    });
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Meu Perfil</h1>
          <p className="text-gray-500 mt-1">
            Gerencie suas informações pessoais e preferências
          </p>
        </div>
        {!isEditMode && (
          <Button 
            onClick={() => setIsEditMode(true)}
            className="gap-2"
          >
            <Edit className="w-4 h-4" />
            Editar Perfil
          </Button>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-gray-100">
          <TabsTrigger value="profile" className="data-[state=active]:bg-white">
            Perfil
          </TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-white">
            Segurança
          </TabsTrigger>
          <TabsTrigger value="preferences" className="data-[state=active]:bg-white">
            Preferências
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-1">
              <CardHeader className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="relative">
                    <Avatar className="w-24 h-24">
                      <AvatarFallback className="text-2xl">
                        {currentUser?.full_name?.split(' ')
                          .map(n => n[0])
                          .slice(0, 2)
                          .join('')}
                      </AvatarFallback>
                    </Avatar>
                    {isEditMode && (
                      <Button 
                        className="absolute bottom-0 right-0 w-8 h-8 p-0 rounded-full"
                        variant="secondary"
                        size="icon"
                      >
                        <Camera className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
                <CardTitle>{currentUser?.full_name}</CardTitle>
                <CardDescription>{currentUser?.job_title}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Tipo de Usuário</p>
                    <p className="font-medium">
                      {currentUser?.user_type === 'superadmin' 
                        ? 'Super Admin' 
                        : currentUser?.user_type === 'orgadmin' 
                          ? 'Administrador de Organização' 
                          : 'Usuário'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p className="font-medium">{currentUser?.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Telefone</p>
                    <p className="font-medium">{currentUser?.phone || "Não informado"}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Membro desde</p>
                    <p className="font-medium">{formatDate(currentUser?.created_date)}</p>
                  </div>
                </div>
                {currentUser?.user_type === 'orgadmin' && (
                  <div className="flex items-center gap-3">
                    <Building2 className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm text-gray-500">Organização</p>
                      <p className="font-medium">Organização Demonstração</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Informações do Perfil</CardTitle>
                <CardDescription>
                  {isEditMode 
                    ? "Edite suas informações pessoais" 
                    : "Suas informações pessoais e de contato"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {isEditMode ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="full_name">Nome Completo</Label>
                        <Input 
                          id="full_name" 
                          value={userForm.full_name}
                          onChange={(e) => setUserForm({...userForm, full_name: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="job_title">Cargo</Label>
                        <Input 
                          id="job_title" 
                          value={userForm.job_title}
                          onChange={(e) => setUserForm({...userForm, job_title: e.target.value})}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input 
                          id="email" 
                          value={userForm.email}
                          onChange={(e) => setUserForm({...userForm, email: e.target.value})}
                          disabled
                        />
                        <p className="text-xs text-gray-500">O email não pode ser alterado</p>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Telefone</Label>
                        <Input 
                          id="phone" 
                          value={userForm.phone}
                          onChange={(e) => setUserForm({...userForm, phone: e.target.value})}
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="bio">Biografia</Label>
                      <Textarea 
                        id="bio"
                        rows={4}
                        value={userForm.bio}
                        onChange={(e) => setUserForm({...userForm, bio: e.target.value})}
                        placeholder="Conte um pouco sobre você..."
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium">Biografia</h3>
                      <p className="mt-2 text-gray-700">{currentUser?.bio || "Nenhuma biografia informada."}</p>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium">Último Acesso</h3>
                      <p className="mt-2 text-gray-700">{formatDate(currentUser?.last_login)}</p>
                    </div>
                  </div>
                )}
              </CardContent>
              {isEditMode && (
                <CardFooter className="flex justify-end gap-3">
                  <Button variant="outline" onClick={() => setIsEditMode(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleSaveProfile}>
                    <Save className="w-4 h-4 mr-2" />
                    Salvar Alterações
                  </Button>
                </CardFooter>
              )}
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Segurança da Conta</CardTitle>
              <CardDescription>
                Gerencie sua senha e configurações de segurança
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Alterar Senha</h3>
                    <p className="text-sm text-gray-500">Atualize sua senha para manter sua conta segura</p>
                  </div>
                  <Button>
                    <Key className="w-4 h-4 mr-2" />
                    Alterar Senha
                  </Button>
                </div>
                
                <Separator />
                
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Autenticação de Dois Fatores</h3>
                    <p className="text-sm text-gray-500">Adicione uma camada extra de segurança à sua conta</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className={currentUser?.preferences?.two_factor_auth 
                      ? "bg-green-100 text-green-800" 
                      : "bg-gray-100 text-gray-800"}>
                      {currentUser?.preferences?.two_factor_auth ? "Ativado" : "Desativado"}
                    </Badge>
                    <Switch 
                      checked={currentUser?.preferences?.two_factor_auth || false}
                      onCheckedChange={() => togglePreference('two_factor_auth')}
                    />
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium">Sessões Ativas</h3>
                  <p className="text-sm text-gray-500 mb-4">Dispositivos onde sua conta está conectada atualmente</p>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Shield className="w-5 h-5 text-green-600" />
                        <div>
                          <p className="font-medium">Este Dispositivo</p>
                          <p className="text-xs text-gray-500">Windows • Chrome • São Paulo, BR</p>
                        </div>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Atual</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preferences" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Preferências</CardTitle>
              <CardDescription>
                Personalize sua experiência no sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="font-medium">Notificações</h3>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Notificações por Email</p>
                      <p className="text-sm text-gray-500">Receba atualizações importantes por email</p>
                    </div>
                    <Switch 
                      checked={currentUser?.preferences?.email_notifications || false}
                      onCheckedChange={() => togglePreference('email_notifications')}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Notificações por SMS</p>
                      <p className="text-sm text-gray-500">Receba alertas urgentes por SMS</p>
                    </div>
                    <Switch 
                      checked={currentUser?.preferences?.sms_notifications || false}
                      onCheckedChange={() => togglePreference('sms_notifications')}
                    />
                  </div>
                </div>
                
                <Separator className="my-6" />
                
                <h3 className="font-medium">Aparência</h3>
                
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Modo Escuro</p>
                    <p className="text-sm text-gray-500">Alterne entre o tema claro e escuro</p>
                  </div>
                  <Switch 
                    checked={currentUser?.preferences?.dark_mode || false}
                    onCheckedChange={() => togglePreference('dark_mode')}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}