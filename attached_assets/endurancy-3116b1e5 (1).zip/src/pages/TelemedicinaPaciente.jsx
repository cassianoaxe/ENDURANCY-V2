import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Video,
  Mic,
  MicOff,
  VideoOff,
  Phone,
  MessageSquare,
  Share2,
  FileText,
  Settings,
  Users,
  Clock,
  Calendar,
  AlertTriangle,
  CheckCircle,
  HelpCircle,
  Loader,
  Camera
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Spinner } from '@/components/ui/spinner';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { 
  Alert, 
  AlertDescription, 
  AlertTitle 
} from '@/components/ui/alert';
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from '@/components/ui/tooltip';
import { toast } from '@/components/ui/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { format, addMinutes, isAfter, isBefore, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function TelemedicinaPaciente() {
  const navigate = useNavigate();
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);
  const consultaId = urlParams.get('id');
  
  const [loading, setLoading] = useState(true);
  const [consultation, setConsultation] = useState(null);
  const [doctor, setDoctor] = useState(null);
  const [patient, setPatient] = useState(null);
  const [callStatus, setCallStatus] = useState('waiting'); // waiting, connecting, connected, ended, error
  const [localStream, setLocalStream] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [localVideo, setLocalVideo] = useState(true);
  const [localAudio, setLocalAudio] = useState(true);
  const [showConfirmEnd, setShowConfirmEnd] = useState(false);
  const [showPreCall, setShowPreCall] = useState(true);
  const [showDeviceSettings, setShowDeviceSettings] = useState(false);
  const [countdown, setCountdown] = useState(null);
  const [feedbackDialog, setFeedbackDialog] = useState(false);
  const [consentDialog, setConsentDialog] = useState(false);
  const [consentAccepted, setConsentAccepted] = useState(false);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const loadConsultation = async () => {
      if (!consultaId) {
        setError("ID da consulta não fornecido");
        setLoading(false);
        return;
      }
      
      try {
        // Simulação de chamada à API
        setTimeout(() => {
          // Dados simulados
          const mockConsultation = {
            id: consultaId,
            data_hora: '2025-01-15T14:30:00',
            tipo_consulta: 'telemedicina',
            duracao: 30,
            status: 'confirmada',
            medico_id: 'med123',
            paciente_id: 'pac456',
            tipo_paciente: 'associado',
            provedor_telemedicina: 'interno',
            link_telemedicina: 'https://meet.example.com/abc123',
            termo_consentimento_aceito: false
          };
          
          const mockDoctor = {
            id: 'med123',
            nome_completo: 'Dra. Mariana Cardoso',
            especialidade: 'Neurologia',
            foto_url: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80'
          };
          
          const mockPatient = {
            id: 'pac456',
            nome_completo: 'João Silva',
            data_nascimento: '1985-05-10'
          };
          
          setConsultation(mockConsultation);
          setDoctor(mockDoctor);
          setPatient(mockPatient);
          
          // Verificar se o termo de consentimento foi aceito
          if (!mockConsultation.termo_consentimento_aceito) {
            setConsentDialog(true);
          }
          
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error("Erro ao carregar consulta:", error);
        setError("Não foi possível carregar os dados da consulta. Por favor, tente novamente.");
        setLoading(false);
      }
    };
    
    loadConsultation();
  }, [consultaId]);
  
  // Iniciar dispositivos de mídia
  const startMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
      setLocalStream(stream);
      setShowPreCall(false);
      
      // Simular conexão e timer de espera pelo médico
      setCallStatus('connecting');
      const timer = setTimeout(() => {
        setCallStatus('connected');
        // Criar um stream simulado para o médico
        const mockRemoteStream = stream.clone();
        setRemoteStream(mockRemoteStream);
      }, 3000);
      
      return () => clearTimeout(timer);
    } catch (err) {
      console.error("Erro ao acessar câmera e microfone:", err);
      setError("Não foi possível acessar sua câmera e microfone. Verifique as permissões do navegador.");
    }
  };
  
  // Alternar vídeo
  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = !localVideo;
      });
      setLocalVideo(!localVideo);
    }
  };
  
  // Alternar áudio
  const toggleAudio = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !localAudio;
      });
      setLocalAudio(!localAudio);
    }
  };
  
  // Encerrar chamada
  const endCall = () => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    setCallStatus('ended');
    setFeedbackDialog(true);
  };
  
  // Aceitar termo de consentimento
  const acceptConsent = async () => {
    setConsentAccepted(true);
    setConsentDialog(false);
    
    // Simulação de atualização do termo de consentimento
    toast({
      title: "Termo aceito com sucesso",
      description: "O termo de consentimento para telemedicina foi aceito.",
      duration: 3000
    });
  };
  
  // Enviar feedback
  const submitFeedback = (rating) => {
    // Simulação de envio de feedback
    toast({
      title: "Obrigado pelo seu feedback!",
      description: "Sua avaliação foi registrada com sucesso.",
      duration: 3000
    });
    
    setFeedbackDialog(false);
    navigate(createPageUrl("MinhaPagina"));
  };
  
  // Formatar horário da consulta
  const formatConsultationTime = (dateTime) => {
    if (!dateTime) return '';
    return format(parseISO(dateTime), "dd 'de' MMMM 'de' yyyy, 'às' HH:mm", { locale: ptBR });
  };
  
  // Verificar se está na hora da consulta
  const isTimeForConsultation = () => {
    if (!consultation?.data_hora) return false;
    
    const consultationTime = parseISO(consultation.data_hora);
    const consultationEnd = addMinutes(consultationTime, consultation.duracao || 30);
    const now = new Date();
    
    // Permitir acesso 10 minutos antes do horário marcado
    const allowedEarlyAccess = addMinutes(consultationTime, -10);
    
    return isAfter(now, allowedEarlyAccess) && isBefore(now, consultationEnd);
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Spinner size="large" className="mx-auto" />
          <p className="mt-4 text-gray-500">Carregando dados da consulta...</p>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="container mx-auto max-w-3xl p-6">
        <Alert variant="destructive" className="mb-6">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Erro</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        
        <Button onClick={() => navigate(-1)}>Voltar</Button>
      </div>
    );
  }
  
  if (!isTimeForConsultation() && consultation) {
    return (
      <div className="container mx-auto max-w-3xl p-6">
        <Card>
          <CardHeader>
            <CardTitle>Consulta por Telemedicina</CardTitle>
            <CardDescription>
              Esta consulta está agendada para {formatConsultationTime(consultation.data_hora)}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 mb-6">
              <Avatar className="h-16 w-16">
                {doctor?.foto_url ? (
                  <AvatarImage src={doctor.foto_url} alt={doctor.nome_completo} />
                ) : (
                  <AvatarFallback className="bg-green-100 text-green-800">
                    {doctor?.nome_completo?.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </AvatarFallback>
                )}
              </Avatar>
              <div>
                <h3 className="text-lg font-medium">{doctor?.nome_completo}</h3>
                <p className="text-gray-500">{doctor?.especialidade}</p>
              </div>
            </div>
            
            <Alert className="mb-6">
              <Clock className="h-4 w-4" />
              <AlertTitle>Consulta ainda não disponível</AlertTitle>
              <AlertDescription>
                A sala de consulta estará disponível 10 minutos antes do horário agendado.
                Por favor, retorne mais próximo ao horário da sua consulta.
              </AlertDescription>
            </Alert>
            
            <div className="flex flex-col gap-2">
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-2 text-gray-500" />
                <span>Data e hora: {formatConsultationTime(consultation.data_hora)}</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-2 text-gray-500" />
                <span>Duração: {consultation.duracao} minutos</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" onClick={() => navigate(-1)}>Voltar</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-100 dark:bg-gray-900 min-h-screen">
      {/* Diálogo de consentimento */}
      <Dialog open={consentDialog} onOpenChange={setConsentDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Termo de Consentimento para Telemedicina</DialogTitle>
            <DialogDescription>
              Por favor, leia e aceite os termos abaixo para continuar com a consulta virtual.
            </DialogDescription>
          </DialogHeader>
          
          <div className="max-h-96 overflow-y-auto border rounded-md p-4 my-4">
            <h3 className="font-semibold mb-2">Consentimento para Consulta por Telemedicina</h3>
            <p className="mb-4">
              Eu entendo que a telemedicina envolve o uso de comunicação eletrônica para permitir
              que profissionais de saúde em diferentes locais compartilhem informações médicas
              individuais do paciente com a finalidade de melhorar o atendimento ao paciente.
            </p>
            
            <h3 className="font-semibold mb-2">Os sistemas de telemedicina incluem:</h3>
            <ul className="list-disc pl-5 mb-4">
              <li>Videoconferências seguras com profissionais de saúde</li>
              <li>Transmissão de imagens médicas para avaliação especializada</li>
              <li>Armazenamento e encaminhamento de dados médicos</li>
              <li>Monitoramento remoto de sinais vitais</li>
            </ul>
            
            <h3 className="font-semibold mb-2">Entendo que:</h3>
            <ul className="list-disc pl-5 mb-4">
              <li>Existem benefícios potenciais da telemedicina, incluindo acesso melhorado ao atendimento médico reduzindo o tempo de viagem e as ausências do trabalho ou escola.</li>
              <li>Como em qualquer procedimento médico, existem riscos potenciais associados ao uso da telemedicina. Esses riscos incluem, mas não estão limitados a, interrupções na transferência de informações devido a falhas tecnológicas.</li>
              <li>As informações transmitidas podem não ser suficientes para permitir decisões médicas apropriadas pelo médico.</li>
              <li>Em casos raros, problemas técnicos podem atrasar a avaliação médica e o tratamento.</li>
              <li>Em casos raros, a falta de acesso a registros médicos completos pode resultar em reações adversas a medicamentos ou erros de julgamento clínico.</li>
            </ul>
            
            <h3 className="font-semibold mb-2">Direito à Privacidade e Confidencialidade:</h3>
            <p className="mb-4">
              Todas as leis existentes relativas ao acesso às suas informações médicas e cópias
              dessas informações se aplicam a esta consulta de telemedicina.
            </p>
            
            <p className="mb-4">
              Além disso, entendo que as informações divulgadas por mim durante minha consulta
              de telemedicina são geralmente confidenciais. No entanto, há exceções obrigatórias
              e permitidas à confidencialidade, incluindo, mas não se limitando a, denúncia de abuso
              infantil, de idosos e adultos com deficiência; e perigo direto para si ou para os outros.
            </p>
            
            <p className="font-semibold">
              Ao aceitar este termo, confirmo que li, compreendi e concordo com os termos acima.
            </p>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => navigate(-1)}>Recusar e Voltar</Button>
            <Button onClick={acceptConsent}>Aceitar e Continuar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Tela de pré-chamada */}
      {showPreCall && (
        <div className="container mx-auto max-w-4xl p-6">
          <Card>
            <CardHeader>
              <CardTitle>Preparando sua consulta</CardTitle>
              <CardDescription>
                Verifique sua câmera e microfone antes de iniciar
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <div className="aspect-video bg-black rounded-lg mb-4 flex items-center justify-center">
                    <Camera className="h-12 w-12 text-gray-400" />
                    <p className="text-gray-400 mt-2">Visualização da câmera aparecerá aqui</p>
                  </div>
                  <div className="flex justify-center gap-4">
                    <Button variant="outline" size="sm" onClick={() => setShowDeviceSettings(true)}>
                      <Settings className="h-4 w-4 mr-2" />
                      Configurações
                    </Button>
                    <Button variant="outline" size="sm" onClick={toggleVideo}>
                      {localVideo ? (
                        <>
                          <VideoOff className="h-4 w-4 mr-2" />
                          Desativar Vídeo
                        </>
                      ) : (
                        <>
                          <Video className="h-4 w-4 mr-2" />
                          Ativar Vídeo
                        </>
                      )}
                    </Button>
                    <Button variant="outline" size="sm" onClick={toggleAudio}>
                      {localAudio ? (
                        <>
                          <MicOff className="h-4 w-4 mr-2" />
                          Desativar Áudio
                        </>
                      ) : (
                        <>
                          <Mic className="h-4 w-4 mr-2" />
                          Ativar Áudio
                        </>
                      )}
                    </Button>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Detalhes da Consulta</h3>
                  <div className="flex items-center gap-4 mb-6">
                    <Avatar className="h-16 w-16">
                      {doctor?.foto_url ? (
                        <AvatarImage src={doctor.foto_url} alt={doctor.nome_completo} />
                      ) : (
                        <AvatarFallback className="bg-green-100 text-green-800">
                          {doctor?.nome_completo?.split(' ').map(n => n[0]).join('').slice(0, 2)}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    <div>
                      <h3 className="text-lg font-medium">{doctor?.nome_completo}</h3>
                      <p className="text-gray-500">{doctor?.especialidade}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2 text-gray-500" />
                      <span>Data e hora: {formatConsultationTime(consultation?.data_hora)}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-gray-500" />
                      <span>Duração: {consultation?.duracao} minutos</span>
                    </div>
                    
                    <Alert>
                      <HelpCircle className="h-4 w-4" />
                      <AlertTitle>Dicas para uma melhor consulta</AlertTitle>
                      <AlertDescription>
                        <ul className="list-disc pl-5 mt-2 space-y-1">
                          <li>Encontre um local silencioso e bem iluminado</li>
                          <li>Garanta uma conexão de internet estável</li>
                          <li>Tenha em mãos documentos médicos relevantes</li>
                          <li>Anote suas dúvidas e questões antes da consulta</li>
                        </ul>
                      </AlertDescription>
                    </Alert>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => navigate(-1)}>Cancelar</Button>
              <Button onClick={startMedia}>Iniciar Consulta</Button>
            </CardFooter>
          </Card>
        </div>
      )}
      
      {/* Interface da chamada */}
      {!showPreCall && (
        <div className="h-screen flex flex-col bg-black relative">
          {/* Barra superior */}
          <div className="p-4 bg-gray-800 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="h-8 w-8">
                {doctor?.foto_url ? (
                  <AvatarImage src={doctor.foto_url} alt={doctor.nome_completo} />
                ) : (
                  <AvatarFallback className="bg-green-100 text-green-800">
                    {doctor?.nome_completo?.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </AvatarFallback>
                )}
              </Avatar>
              <div>
                <p className="font-medium">{doctor?.nome_completo}</p>
                <p className="text-xs text-gray-300">{doctor?.especialidade}</p>
              </div>
            </div>
            
            <div>
              <Badge variant={callStatus === 'connected' ? 'success' : callStatus === 'connecting' ? 'outline' : 'destructive'}>
                {callStatus === 'connected' ? 'Conectado' : 
                 callStatus === 'connecting' ? 'Conectando...' : 
                 callStatus === 'ended' ? 'Encerrada' : 'Erro'}
              </Badge>
            </div>
          </div>
          
          {/* Área principal do vídeo */}
          <div className="flex-1 relative">
            {callStatus === 'connecting' && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
                <div className="text-center">
                  <Spinner size="large" className="mx-auto text-white" />
                  <p className="mt-4 text-white">Aguardando o médico entrar na sala...</p>
                </div>
              </div>
            )}
            
            {callStatus === 'connected' && (
              <div className="h-full w-full">
                {/* Vídeo do médico (remoto) */}
                <div className="h-full w-full bg-gray-900 relative">
                  {/* Placeholder para o vídeo do médico */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <Avatar className="h-32 w-32 mx-auto">
                        {doctor?.foto_url ? (
                          <AvatarImage src={doctor.foto_url} alt={doctor.nome_completo} />
                        ) : (
                          <AvatarFallback className="bg-green-100 text-green-800 text-4xl">
                            {doctor?.nome_completo?.split(' ').map(n => n[0]).join('').slice(0, 2)}
                          </AvatarFallback>
                        )}
                      </Avatar>
                      <p className="mt-4 text-white text-xl">{doctor?.nome_completo}</p>
                    </div>
                  </div>
                  
                  {/* Vídeo do paciente (local) - miniatura */}
                  <div className="absolute bottom-4 right-4 w-48 h-36 bg-gray-800 rounded-lg overflow-hidden border-2 border-white">
                    {/* Placeholder para o vídeo do paciente */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      {!localVideo ? (
                        <div className="text-center">
                          <Avatar className="h-16 w-16 mx-auto">
                            <AvatarFallback className="bg-green-100 text-green-800">
                              {patient?.nome_completo?.split(' ').map(n => n[0]).join('').slice(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <p className="mt-2 text-white text-xs">Câmera desativada</p>
                        </div>
                      ) : (
                        <div className="absolute inset-0 bg-gray-600"></div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Barra inferior de controles */}
          <div className="p-4 bg-gray-800 text-white">
            <div className="max-w-3xl mx-auto flex items-center justify-center gap-4">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" className="rounded-full h-12 w-12" onClick={toggleAudio}>
                      {localAudio ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5 text-red-500" />}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{localAudio ? 'Desativar Microfone' : 'Ativar Microfone'}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" className="rounded-full h-12 w-12" onClick={toggleVideo}>
                      {localVideo ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5 text-red-500" />}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{localVideo ? 'Desativar Câmera' : 'Ativar Câmera'}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" className="rounded-full h-12 w-12">
                      <MessageSquare className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Chat</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" className="rounded-full h-12 w-12">
                      <Share2 className="h-5 w-5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Compartilhar Tela</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <Button variant="destructive" size="icon" className="rounded-full h-12 w-12" onClick={() => setShowConfirmEnd(true)}>
                <Phone className="h-5 w-5" />
              </Button>
            </div>
          </div>
          
          {/* Diálogo de confirmação para encerrar chamada */}
          <Dialog open={showConfirmEnd} onOpenChange={setShowConfirmEnd}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Encerrar Consulta</DialogTitle>
                <DialogDescription>
                  Tem certeza que deseja encerrar esta consulta?
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowConfirmEnd(false)}>Cancelar</Button>
                <Button variant="destructive" onClick={endCall}>Encerrar Consulta</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          {/* Diálogo de feedback pós-consulta */}
          <Dialog open={feedbackDialog} onOpenChange={setFeedbackDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Avalie sua consulta</DialogTitle>
                <DialogDescription>
                  Como foi sua experiência com {doctor?.nome_completo}?
                </DialogDescription>
              </DialogHeader>
              
              <div className="flex justify-center gap-4 my-6">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <Button
                    key={rating}
                    variant="outline"
                    className="h-14 w-14 rounded-full text-lg font-bold"
                    onClick={() => submitFeedback(rating)}
                  >
                    {rating}
                  </Button>
                ))}
              </div>
              
              <div className="text-center text-sm text-gray-500">
                <p>1 = Insatisfeito, 5 = Muito Satisfeito</p>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => navigate(createPageUrl("MinhaPagina"))}>Pular</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      )}
    </div>
  );
}