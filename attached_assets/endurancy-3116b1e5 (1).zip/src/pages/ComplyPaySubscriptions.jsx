import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  RecurringPayment
} from '@/api/entities';
import {
  RefreshCw,
  Search,
  Download,
  Plus,
  Calendar,
  Filter,
  User,
  DollarSign,
  Clock,
  CheckCircle,
  Pause,
  XCircle,
  ArrowUpRight,
  FileSearch,
  MoreHorizontal,
  Eye,
  Edit,
  Play,
  Trash2,
  Zap,
  Calendar as CalendarIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from '@/components/ui/use-toast';

export default function ComplyPaySubscriptions() {
  const navigate = useNavigate();
  const [subscriptions, setSubscriptions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterFrequency, setFilterFrequency] = useState('all');

  // Sample data for demonstration
  const mockSubscriptions = [
    {
      id: 'sub-001',
      profile_id: 'ASSIN-2023-001',
      name: 'Plano Pro Mensal',
      status: 'active',
      customer: { 
        id: 'cust-001',
        name: 'João Silva', 
        email: 'joao.silva@exemplo.com' 
      },
      amount: 99.90,
      currency: 'BRL',
      frequency: 'monthly',
      start_date: '2023-09-01',
      next_billing_date: '2023-11-01',
      last_billing_date: '2023-10-01',
      cycles_completed: 1,
      total_cycles: null,
      payment_method_id: 'pm-001'
    },
    {
      id: 'sub-002',
      profile_id: 'ASSIN-2023-002',
      name: 'Plano Básico Anual',
      status: 'active',
      customer: { 
        id: 'cust-002',
        name: 'Maria Oliveira', 
        email: 'maria.oliveira@exemplo.com' 
      },
      amount: 599.90,
      currency: 'BRL',
      frequency: 'yearly',
      start_date: '2023-08-15',
      next_billing_date: '2024-08-15',
      last_billing_date: '2023-08-15',
      cycles_completed: 0,
      total_cycles: 2,
      payment_method_id: 'pm-002'
    },
    {
      id: 'sub-003',
      profile_id: 'ASSIN-2023-003',
      name: 'Plano Pro Trimestral',
      status: 'paused',
      customer: { 
        id: 'cust-003',
        name: 'Carlos Santos', 
        email: 'carlos.santos@exemplo.com' 
      },
      amount: 269.90,
      currency: 'BRL',
      frequency: 'custom',
      interval: 3,
      start_date: '2023-07-10',
      next_billing_date: '2023-12-10',
      last_billing_date: '2023-09-10',
      cycles_completed: 1,
      total_cycles: 4,
      payment_method_id: 'pm-003'
    },
    {
      id: 'sub-004',
      profile_id: 'ASSIN-2023-004',
      name: 'Plano Premium Mensal',
      status: 'cancelled',
      customer: { 
        id: 'cust-004',
        name: 'Ana Pereira', 
        email: 'ana.pereira@exemplo.com' 
      },
      amount: 149.90,
      currency: 'BRL',
      frequency: 'monthly',
      start_date: '2023-06-20',
      next_billing_date: null,
      last_billing_date: '2023-09-20',
      cycles_completed: 3,
      total_cycles: 12,
      payment_method_id: 'pm-004'
    },
    {
      id: 'sub-005',
      profile_id: 'ASSIN-2023-005',
      name: 'Plano Basic Mensal',
      status: 'failed',
      customer: { 
        id: 'cust-005',
        name: 'Pedro Almeida', 
        email: 'pedro.almeida@exemplo.com' 
      },
      amount: 49.90,
      currency: 'BRL',
      frequency: 'monthly',
      start_date: '2023-09-05',
      next_billing_date: '2023-11-05',
      last_billing_date: '2023-10-05',
      cycles_completed: 1,
      failure_count: 2,
      total_cycles: null,
      payment_method_id: 'pm-005'
    }
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setSubscriptions(mockSubscriptions);
      setIsLoading(false);
    }, 1000);
  }, []);

  const filteredSubscriptions = subscriptions.filter(subscription => {
    const matchesSearch = 
      subscription.profile_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      subscription.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      subscription.customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      subscription.customer.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || subscription.status === filterStatus;
    const matchesFrequency = filterFrequency === 'all' || subscription.frequency === filterFrequency;
    
    return matchesSearch && matchesStatus && matchesFrequency;
  });

  const getStatusBadge = (status) => {
    switch(status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Ativo</Badge>;
      case 'paused':
        return <Badge className="bg-yellow-100 text-yellow-800">Pausado</Badge>;
      case 'failed':
        return <Badge className="bg-red-100 text-red-800">Falhou</Badge>;
      case 'completed':
        return <Badge className="bg-blue-100 text-blue-800">Concluído</Badge>;
      case 'cancelled':
        return <Badge className="bg-gray-100 text-gray-800">Cancelado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getFrequencyLabel = (frequency, interval = 1) => {
    switch(frequency) {
      case 'daily':
        return interval === 1 ? 'Diário' : `A cada ${interval} dias`;
      case 'weekly':
        return interval === 1 ? 'Semanal' : `A cada ${interval} semanas`;
      case 'monthly':
        return interval === 1 ? 'Mensal' : `A cada ${interval} meses`;
      case 'yearly':
        return interval === 1 ? 'Anual' : `A cada ${interval} anos`;
      case 'custom':
        if (interval === 3) return 'Trimestral';
        if (interval === 6) return 'Semestral';
        return `A cada ${interval} meses`;
      default:
        return frequency;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return format(new Date(dateString), 'dd/MM/yyyy', { locale: ptBR });
  };

  const formatCurrency = (value, currency = 'BRL') => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: currency
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Assinaturas</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Gerencie os pagamentos recorrentes no sistema ComplyPay
          </p>
        </div>
        <Button onClick={() => toast({
          title: "Funcionalidade em desenvolvimento",
          description: "A criação de novas assinaturas estará disponível em breve."
        })}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Assinatura
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input 
            placeholder="Buscar assinaturas..." 
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="active">Ativo</SelectItem>
              <SelectItem value="paused">Pausado</SelectItem>
              <SelectItem value="failed">Falhou</SelectItem>
              <SelectItem value="completed">Concluído</SelectItem>
              <SelectItem value="cancelled">Cancelado</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={filterFrequency} onValueChange={setFilterFrequency}>
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue placeholder="Frequência" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              <SelectItem value="monthly">Mensal</SelectItem>
              <SelectItem value="yearly">Anual</SelectItem>
              <SelectItem value="custom">Personalizada</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" onClick={() => toast({
            title: "Exportação de assinaturas",
            description: "A exportação de assinaturas estará disponível em breve."
          })}>
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="p-4 pb-0">
          <CardTitle>Lista de Assinaturas</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center items-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
          ) : filteredSubscriptions.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Plano</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Frequência</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Próxima Cobrança</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSubscriptions.map((subscription) => (
                  <TableRow key={subscription.id}>
                    <TableCell className="font-medium">{subscription.profile_id}</TableCell>
                    <TableCell>{subscription.name}</TableCell>
                    <TableCell>
                      <div>
                        <p>{subscription.customer.name}</p>
                        <p className="text-sm text-gray-500">{subscription.customer.email}</p>
                      </div>
                    </TableCell>
                    <TableCell>{getFrequencyLabel(subscription.frequency, subscription.interval)}</TableCell>
                    <TableCell>{formatCurrency(subscription.amount, subscription.currency)}</TableCell>
                    <TableCell>{formatDate(subscription.next_billing_date)}</TableCell>
                    <TableCell>{getStatusBadge(subscription.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Abrir menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Ações</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => toast({
                            title: "Visualizar assinatura",
                            description: "Esta funcionalidade estará disponível em breve."
                          })}>
                            <Eye className="mr-2 h-4 w-4" />
                            <span>Detalhes</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toast({
                            title: "Editar assinatura",
                            description: "Esta funcionalidade estará disponível em breve."
                          })}>
                            <Edit className="mr-2 h-4 w-4" />
                            <span>Editar</span>
                          </DropdownMenuItem>
                          
                          {subscription.status === 'active' && (
                            <DropdownMenuItem onClick={() => toast({
                              title: "Pausar assinatura",
                              description: "Esta funcionalidade estará disponível em breve."
                            })}>
                              <Pause className="mr-2 h-4 w-4" />
                              <span>Pausar</span>
                            </DropdownMenuItem>
                          )}
                          
                          {subscription.status === 'paused' && (
                            <DropdownMenuItem onClick={() => toast({
                              title: "Retomar assinatura",
                              description: "Esta funcionalidade estará disponível em breve."
                            })}>
                              <Play className="mr-2 h-4 w-4" />
                              <span>Retomar</span>
                            </DropdownMenuItem>
                          )}
                          
                          {['active', 'paused'].includes(subscription.status) && (
                            <DropdownMenuItem onClick={() => toast({
                              title: "Cobrar agora",
                              description: "Esta funcionalidade estará disponível em breve."
                            })}>
                              <Zap className="mr-2 h-4 w-4" />
                              <span>Cobrar agora</span>
                            </DropdownMenuItem>
                          )}
                          
                          <DropdownMenuSeparator />
                          
                          {['active', 'paused', 'failed'].includes(subscription.status) && (
                            <DropdownMenuItem className="text-red-600" onClick={() => toast({
                              title: "Cancelar assinatura",
                              description: "Esta funcionalidade estará disponível em breve.",
                              variant: "destructive"
                            })}>
                              <Trash2 className="mr-2 h-4 w-4" />
                              <span>Cancelar</span>
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center p-8 text-center">
              <FileSearch className="h-16 w-16 text-gray-300 mb-4" />
              <h3 className="text-lg font-medium">Nenhuma assinatura encontrada</h3>
              <p className="text-gray-500 mt-1 max-w-md">
                {searchTerm || filterStatus !== 'all' || filterFrequency !== 'all'
                  ? "Nenhuma assinatura corresponde aos filtros aplicados." 
                  : "Ainda não há assinaturas registradas no sistema."}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}