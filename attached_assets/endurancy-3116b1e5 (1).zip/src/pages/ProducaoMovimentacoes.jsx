import React, { useState, useEffect } from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeftRight, 
  Plus, 
  Search,
  Filter,
  ArrowUpCircle,
  ArrowDownCircle,
  ArrowRightLeft,
  Trash2
} from "lucide-react";

export default function ProducaoMovimentacoes() {
  const [loading, setLoading] = useState(true);
  const [movimentacoes, setMovimentacoes] = useState([]);
  const [tipoFilter, setTipoFilter] = useState("all");

  useEffect(() => {
    const loadData = async () => {
      // Mock data
      const mockMovimentacoes = [
        {
          id: "MOV001",
          data: "2024-01-15T10:30:00",
          tipo: "entrada",
          origem: "Fornecedor",
          destino: "Almoxarifado MP",
          produto: "Extrato CBD Full Spectrum",
          quantidade: 5000,
          unidade: "ml",
          lote: "L202401",
          responsavel: "João Silva",
          documento: "NF-123456"
        },
        {
          id: "MOV002",
          data: "2024-01-15T11:45:00",
          tipo: "transferencia",
          origem: "Almoxarifado MP",
          destino: "Produção",
          produto: "Óleo MCT",
          quantidade: 2000,
          unidade: "ml",
          lote: "L202402",
          responsavel: "Maria Santos",
          documento: "REQ-789"
        },
        {
          id: "MOV003",
          data: "2024-01-15T14:20:00",
          tipo: "saida",
          origem: "Produção",
          destino: "Descarte",
          produto: "Lote Reprovado",
          quantidade: 100,
          unidade: "unidades",
          lote: "L202403",
          responsavel: "Pedro Costa",
          documento: "DSC-456"
        }
      ];

      setMovimentacoes(mockMovimentacoes);
      setLoading(false);
    };

    loadData();
  }, []);

  const getTipoIcon = (tipo) => {
    switch (tipo) {
      case "entrada":
        return <ArrowDownCircle className="w-4 h-4 text-green-600" />;
      case "saida":
        return <ArrowUpCircle className="w-4 h-4 text-red-600" />;
      case "transferencia":
        return <ArrowRightLeft className="w-4 h-4 text-blue-600" />;
      case "descarte":
        return <Trash2 className="w-4 h-4 text-yellow-600" />;
      default:
        return <ArrowLeftRight className="w-4 h-4" />;
    }
  };

  const getTipoBadge = (tipo) => {
    const config = {
      entrada: "bg-green-100 text-green-800",
      saida: "bg-red-100 text-red-800",
      transferencia: "bg-blue-100 text-blue-800",
      descarte: "bg-yellow-100 text-yellow-800"
    };

    return (
      <Badge className={config[tipo]}>
        <span className="flex items-center gap-1">
          {getTipoIcon(tipo)}
          {tipo.charAt(0).toUpperCase() + tipo.slice(1)}
        </span>
      </Badge>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Movimentações de Estoque</h2>
          <p className="text-gray-500">Controle e rastreamento de todas as movimentações</p>
        </div>
        <Button onClick={() => console.log("Nova movimentação")}>
          <Plus className="w-4 h-4 mr-2" />
          Nova Movimentação
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Buscar movimentações..."
                className="pl-10"
              />
            </div>
            
            <Select value={tipoFilter} onValueChange={setTipoFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Tipos</SelectItem>
                <SelectItem value="entrada">Entradas</SelectItem>
                <SelectItem value="saida">Saídas</SelectItem>
                <SelectItem value="transferencia">Transferências</SelectItem>
                <SelectItem value="descarte">Descartes</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {loading ? (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Produto</TableHead>
                  <TableHead>Quantidade</TableHead>
                  <TableHead>Origem</TableHead>
                  <TableHead>Destino</TableHead>
                  <TableHead>Lote</TableHead>
                  <TableHead>Responsável</TableHead>
                  <TableHead>Documento</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {movimentacoes.map((mov) => (
                  <TableRow key={mov.id}>
                    <TableCell>{new Date(mov.data).toLocaleString()}</TableCell>
                    <TableCell>{getTipoBadge(mov.tipo)}</TableCell>
                    <TableCell>{mov.produto}</TableCell>
                    <TableCell>{mov.quantidade} {mov.unidade}</TableCell>
                    <TableCell>{mov.origem}</TableCell>
                    <TableCell>{mov.destino}</TableCell>
                    <TableCell>{mov.lote}</TableCell>
                    <TableCell>{mov.responsavel}</TableCell>
                    <TableCell>{mov.documento}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}