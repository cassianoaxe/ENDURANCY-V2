import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Search, 
  CheckCircle, 
  ShoppingCart, 
  Building, 
  Calendar, 
  Clock, 
  Save, 
  Send, 
  FileText,
  AlertTriangle,
  X,
  ShoppingBag,
  DollarSign
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import { Separator } from "@/components/ui/separator";

// Dados simulados de fornecedores
const mockFornecedores = [
  { 
    id: "forn-001", 
    razao_social: "Sigma Aldrich Química Brasil Ltda", 
    nome_fantasia: "Sigma Aldrich", 
    cnpj: "53.290.035/0001-69",
    categorias: ["Laboratório", "Reagentes", "Equipamentos"],
    avaliacao: 4.8
  },
  { 
    id: "forn-002", 
    razao_social: "EmbalaFarma Embalagens Farmacêuticas S.A.", 
    nome_fantasia: "EmbalaFarma", 
    cnpj: "45.876.543/0001-21",
    categorias: ["Embalagens", "Primárias", "Secundárias"],
    avaliacao: 4.2
  },
  { 
    id: "forn-003", 
    razao_social: "Dell Computadores do Brasil Ltda", 
    nome_fantasia: "Dell Computadores", 
    cnpj: "72.381.189/0001-10",
    categorias: ["TI", "Computadores", "Periféricos"],
    avaliacao: 4.5
  },
  { 
    id: "forn-004", 
    razao_social: "Papelaria Express Comercial S.A.", 
    nome_fantasia: "Papelaria Express", 
    cnpj: "12.345.678/0001-90",
    categorias: ["Escritório", "Papelaria", "Material de Expediente"],
    avaliacao: 3.9
  },
  { 
    id: "forn-005", 
    razao_social: "GraficaPharma Indústria Gráfica Ltda", 
    nome_fantasia: "GraficaPharma", 
    cnpj: "98.765.432/0001-10",
    categorias: ["Embalagens", "Rotulagem", "Material Gráfico"],
    avaliacao: 4.0
  },
  { 
    id: "forn-006", 
    razao_social: "ThermoFisher Scientific Brasil Ltda", 
    nome_fantasia: "Thermofisher", 
    cnpj: "63.025.874/0001-50",
    categorias: ["Laboratório", "Equipamentos", "Reagentes"],
    avaliacao: 4.7
  },
  { 
    id: "forn-007", 
    razao_social: "LabSupply Equipamentos Laboratoriais Ltda", 
    nome_fantasia: "LabSupply", 
    cnpj: "28.496.573/0001-21",
    categorias: ["Laboratório", "Material de Consumo", "Vidraria"],
    avaliacao: 4.3
  }
];

// Dados simulados para solicitações
const mockSolicitacoes = [
  {
    id: "sol-001",
    numero_solicitacao: "SC-2023-0001",
    tipo: "produto",
    solicitante: {
      id: "user-001",
      nome: "Carlos Mendes",
      setor: "Laboratório"
    },
    data_solicitacao: "2023-06-09T14:30:00Z",
    status: "aprovada",
    justificativa: "Reposição de estoque de reagentes para PCR",
    centro_custo: "CC-LAB-001 - Laboratório Controle de Qualidade",
    data_necessidade: "2023-06-19",
    valor_total: 7250.30,
    itens: [
      {
        id: "item-001",
        produto_id: "LAB-R001",
        descricao: "Reagente para PCR",
        quantidade: 15,
        unidade_medida: "unidade",
        valor_estimado: 450.50,
        valor_total_estimado: 6757.50,
        categoria: "Laboratório",
        fornecedor_selecionado_id: "forn-001"
      },
      {
        id: "item-002",
        produto_id: "LAB-AUX001",
        descricao: "Pipetas descartáveis",
        quantidade: 100,
        unidade_medida: "unidade",
        valor_estimado: 4.928,
        valor_total_estimado: 492.80,
        categoria: "Laboratório",
        fornecedor_selecionado_id: "forn-001"
      }
    ]
  },
  {
    id: "sol-002",
    numero_solicitacao: "SC-2023-0002",
    tipo: "produto",
    solicitante: {
      id: "user-002",
      nome: "Ana Silva",
      setor: "Produção"
    },
    data_solicitacao: "2023-06-11T10:15:00Z",
    status: "aprovada",
    justificativa: "Compra de embalagens para nova linha de produtos",
    centro_custo: "CC-PROD-001 - Produção Linha 1",
    data_necessidade: "2023-06-21",
    valor_total: 3850.00,
    itens: [
      {
        id: "item-003",
        produto_id: "EMB-001",
        descricao: "Embalagens Primárias 100ml",
        quantidade: 1000,
        unidade_medida: "unidade",
        valor_estimado: 3.85,
        valor_total_estimado: 3850.00,
        categoria: "Embalagens",
        fornecedor_selecionado_id: "forn-002"
      }
    ]
  },
  {
    id: "sol-003",
    numero_solicitacao: "SC-2023-0003",
    tipo: "produto",
    solicitante: {
      id: "user-003",
      nome: "Paulo Sousa",
      setor: "TI"
    },
    data_solicitacao: "2023-06-15T09:30:00Z",
    status: "aprovada",
    justificativa: "Notebooks para novos colaboradores",
    centro_custo: "CC-TI-001 - Tecnologia da Informação",
    data_necessidade: "2023-06-30",
    valor_total: 10400.00,
    itens: [
      {
        id: "item-004",
        produto_id: "TI-002",
        descricao: "Notebook Dell Latitude",
        quantidade: 2,
        unidade_medida: "unidade",
        valor_estimado: 5200.00,
        valor_total_estimado: 10400.00,
        categoria: "TI",
        fornecedor_selecionado_id: "forn-003"
      }
    ]
  },
  {
    id: "sol-004",
    numero_solicitacao: "SC-2023-0004",
    tipo: "produto",
    solicitante: {
      id: "user-004",
      nome: "Maria Oliveira",
      setor: "Administrativo"
    },
    data_solicitacao: "2023-06-07T14:20:00Z",
    status: "aprovada",
    justificativa: "Reposição de material de escritório",
    centro_custo: "CC-ADM-001 - Administrativo Geral",
    data_necessidade: "2023-06-15",
    valor_total: 1295.00,
    itens: [
      {
        id: "item-005",
        produto_id: "ESC-001",
        descricao: "Papel A4",
        quantidade: 50,
        unidade_medida: "resma",
        valor_estimado: 25.90,
        valor_total_estimado: 1295.00,
        categoria: "Escritório",
        fornecedor_selecionado_id: "forn-004"
      }
    ]
  }
];

export default function NovoPedido() {
  const navigate = useNavigate();
  
  const [pedido, setPedido] = useState({
    fornecedor_id: "",
    solicitacao_id: "",
    previsao_entrega: "",
    observacoes: "",
    condicoes_pagamento: "",
    itens: []
  });
  
  const [solicitacoes, setSolicitacoes] = useState([]);
  const [solicitacaoSelecionada, setSolicitacaoSelecionada] = useState(null);
  const [fornecedores, setFornecedores] = useState([]);
  const [fornecedorSelecionado, setFornecedorSelecionado] = useState(null);
  
  const [searchFornecedor, setSearchFornecedor] = useState("");
  const [searchSolicitacao, setSearchSolicitacao] = useState("");
  
  const [fornecedoresDialog, setFornecedoresDialog] = useState(false);
  const [solicitacoesDialog, setSolicitacoesDialog] = useState(false);
  
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  
  // Carregar dados simulados
  useEffect(() => {
    setLoading(true);
    // Simula carregamento
    setTimeout(() => {
      setFornecedores(mockFornecedores);
      setSolicitacoes(mockSolicitacoes);
      setLoading(false);
    }, 1000);
  }, []);
  
  // Filtrar fornecedores com base na busca
  const filteredFornecedores = fornecedores.filter(fornecedor => 
    fornecedor.nome_fantasia.toLowerCase().includes(searchFornecedor.toLowerCase()) ||
    fornecedor.razao_social.toLowerCase().includes(searchFornecedor.toLowerCase()) ||
    fornecedor.cnpj.includes(searchFornecedor)
  );
  
  // Filtrar solicitações com base na busca
  const filteredSolicitacoes = solicitacoes.filter(solicitacao => 
    solicitacao.numero_solicitacao.toLowerCase().includes(searchSolicitacao.toLowerCase()) ||
    solicitacao.solicitante.nome.toLowerCase().includes(searchSolicitacao.toLowerCase()) ||
    (solicitacao.justificativa && solicitacao.justificativa.toLowerCase().includes(searchSolicitacao.toLowerCase()))
  );
  
  const selecionarFornecedor = (fornecedor) => {
    setFornecedorSelecionado(fornecedor);
    setPedido({
      ...pedido,
      fornecedor_id: fornecedor.id
    });
    setFornecedoresDialog(false);
  };
  
  const selecionarSolicitacao = (solicitacao) => {
    setSolicitacaoSelecionada(solicitacao);
    
    // Verifica se a solicitação tem um fornecedor já selecionado para algum item
    if (solicitacao.itens && solicitacao.itens.length > 0) {
      const primaryFornecedorId = solicitacao.itens[0].fornecedor_selecionado_id;
      
      if (primaryFornecedorId) {
        const fornecedor = fornecedores.find(f => f.id === primaryFornecedorId);
        if (fornecedor) {
          setFornecedorSelecionado(fornecedor);
        }
      }
    }
    
    setPedido({
      ...pedido,
      solicitacao_id: solicitacao.id,
      fornecedor_id: solicitacao.itens[0]?.fornecedor_selecionado_id || "",
      itens: solicitacao.itens.map(item => ({
        ...item,
        valor_unitario: item.valor_estimado,
        valor_total: item.valor_total_estimado
      }))
    });
    
    setSolicitacoesDialog(false);
  };
  
  const alterarQuantidadeItem = (itemId, novaQuantidade) => {
    const quantidade = parseInt(novaQuantidade);
    if (isNaN(quantidade) || quantidade <= 0) return;
    
    setPedido(prev => {
      const novosItens = prev.itens.map(item => {
        if (item.id === itemId) {
          const valorTotal = quantidade * item.valor_unitario;
          return {
            ...item,
            quantidade,
            valor_total: valorTotal
          };
        }
        return item;
      });
      
      return {
        ...prev,
        itens: novosItens
      };
    });
  };
  
  const alterarValorUnitarioItem = (itemId, novoValor) => {
    const valor = parseFloat(novoValor);
    if (isNaN(valor) || valor <= 0) return;
    
    setPedido(prev => {
      const novosItens = prev.itens.map(item => {
        if (item.id === itemId) {
          const valorTotal = item.quantidade * valor;
          return {
            ...item,
            valor_unitario: valor,
            valor_total: valorTotal
          };
        }
        return item;
      });
      
      return {
        ...prev,
        itens: novosItens
      };
    });
  };
  
  const removerItem = (itemId) => {
    setPedido(prev => ({
      ...prev,
      itens: prev.itens.filter(item => item.id !== itemId)
    }));
  };
  
  const calcularValorTotal = () => {
    return pedido.itens.reduce((total, item) => total + item.valor_total, 0);
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!fornecedorSelecionado) {
      toast({
        title: "Erro de validação",
        description: "Selecione um fornecedor para continuar.",
        variant: "destructive"
      });
      return;
    }
    
    if (!solicitacaoSelecionada) {
      toast({
        title: "Erro de validação",
        description: "Selecione uma solicitação de compra para continuar.",
        variant: "destructive"
      });
      return;
    }
    
    if (pedido.itens.length === 0) {
      toast({
        title: "Erro de validação",
        description: "O pedido deve conter pelo menos um item.",
        variant: "destructive"
      });
      return;
    }
    
    if (!pedido.previsao_entrega) {
      toast({
        title: "Erro de validação",
        description: "Informe a previsão de entrega para continuar.",
        variant: "destructive"
      });
      return;
    }
    
    setSubmitting(true);
    
    // Simulação de envio do pedido
    setTimeout(() => {
      setSubmitting(false);
      toast({
        title: "Pedido criado com sucesso",
        description: "O pedido de compra foi registrado e enviado ao fornecedor.",
      });
      
      navigate(createPageUrl("PedidosCompra"));
    }, 2000);
  };
  
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return "";
    
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => navigate(createPageUrl("PedidosCompra"))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Novo Pedido de Compra</h1>
            <p className="text-gray-500 mt-1">
              Crie um novo pedido de compra baseado em solicitações aprovadas
            </p>
          </div>
        </div>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card Solicitação de Compra */}
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Solicitação de Compra
              </CardTitle>
              <CardDescription>
                Selecione uma solicitação de compra aprovada
              </CardDescription>
            </CardHeader>
            <CardContent>
              {solicitacaoSelecionada ? (
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium text-lg">{solicitacaoSelecionada.numero_solicitacao}</h3>
                      <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                        <Badge className="bg-green-100 text-green-800">Aprovada</Badge>
                        <span>{formatDate(solicitacaoSelecionada.data_solicitacao)}</span>
                      </div>
                    </div>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={() => setSolicitacoesDialog(true)}
                    >
                      Trocar
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <Label className="text-gray-500">Solicitante</Label>
                      <p>{solicitacaoSelecionada.solicitante.nome}</p>
                      <p className="text-gray-500">{solicitacaoSelecionada.solicitante.setor}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Centro de Custo</Label>
                      <p>{solicitacaoSelecionada.centro_custo}</p>
                    </div>
                    <div className="col-span-2">
                      <Label className="text-gray-500">Justificativa</Label>
                      <p>{solicitacaoSelecionada.justificativa}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6">
                  <FileText className="w-12 h-12 text-gray-200 mx-auto mb-3" />
                  <p className="text-gray-500 mb-3">Nenhuma solicitação selecionada</p>
                  <Button type="button" onClick={() => setSolicitacoesDialog(true)}>
                    Selecionar Solicitação
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Card Fornecedor */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="w-5 h-5" />
                Fornecedor
              </CardTitle>
              <CardDescription>
                Fornecedor selecionado na cotação
              </CardDescription>
            </CardHeader>
            <CardContent>
              {fornecedorSelecionado ? (
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium text-lg">{fornecedorSelecionado.nome_fantasia}</h3>
                      <p className="text-sm text-gray-500">{fornecedorSelecionado.razao_social}</p>
                    </div>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={() => setFornecedoresDialog(true)}
                    >
                      Trocar
                    </Button>
                  </div>
                  <div className="text-sm">
                    <Label className="text-gray-500">CNPJ</Label>
                    <p>{fornecedorSelecionado.cnpj}</p>
                  </div>
                  <div className="text-sm">
                    <Label className="text-gray-500">Categorias</Label>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {fornecedorSelecionado.categorias.map((categoria, index) => (
                        <Badge key={index} variant="outline">{categoria}</Badge>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6">
                  <Building className="w-12 h-12 text-gray-200 mx-auto mb-3" />
                  <p className="text-gray-500 mb-3">Nenhum fornecedor selecionado</p>
                  <Button type="button" onClick={() => setFornecedoresDialog(true)}>
                    Selecionar Fornecedor
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Itens do Pedido */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5" />
              Itens do Pedido
            </CardTitle>
            <CardDescription>
              Itens incluídos no pedido de compra
            </CardDescription>
          </CardHeader>
          <CardContent>
            {pedido.itens.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Código</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead className="text-center">Quantidade</TableHead>
                    <TableHead className="text-center">Unidade</TableHead>
                    <TableHead className="text-right">Valor Unitário</TableHead>
                    <TableHead className="text-right">Valor Total</TableHead>
                    <TableHead className="w-[100px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pedido.itens.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.produto_id}</TableCell>
                      <TableCell>{item.descricao}</TableCell>
                      <TableCell>{item.categoria}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          min="1"
                          className="w-20 mx-auto text-center"
                          value={item.quantidade}
                          onChange={(e) => alterarQuantidadeItem(item.id, e.target.value)}
                        />
                      </TableCell>
                      <TableCell className="text-center">{item.unidade_medida}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          min="0.01"
                          step="0.01"
                          className="w-28 ml-auto text-right"
                          value={item.valor_unitario}
                          onChange={(e) => alterarValorUnitarioItem(item.id, e.target.value)}
                        />
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {formatCurrency(item.valor_total)}
                      </TableCell>
                      <TableCell>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="text-red-500 hover:text-red-700"
                          onClick={() => removerItem(item.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  <TableRow>
                    <TableCell colSpan={6} className="text-right font-bold">
                      Valor Total:
                    </TableCell>
                    <TableCell className="text-right font-bold">
                      {formatCurrency(calcularValorTotal())}
                    </TableCell>
                    <TableCell></TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-12">
                <ShoppingCart className="w-12 h-12 text-gray-200 mx-auto mb-3" />
                <p className="text-gray-500 mb-3">
                  Nenhum item adicionado ao pedido.
                </p>
                <p className="text-gray-500">
                  Selecione uma solicitação de compra para adicionar itens automaticamente.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Informações do Pedido */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Informações do Pedido
            </CardTitle>
            <CardDescription>
              Preencha as informações complementares do pedido
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="previsao_entrega">Previsão de Entrega</Label>
                  <Input
                    id="previsao_entrega"
                    type="date"
                    value={pedido.previsao_entrega}
                    onChange={(e) => setPedido({...pedido, previsao_entrega: e.target.value})}
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="condicoes_pagamento">Condições de Pagamento</Label>
                  <Select
                    value={pedido.condicoes_pagamento}
                    onValueChange={(value) => setPedido({...pedido, condicoes_pagamento: value})}
                  >
                    <SelectTrigger id="condicoes_pagamento">
                      <SelectValue placeholder="Selecione..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="a_vista">À Vista</SelectItem>
                      <SelectItem value="30_dias">30 dias</SelectItem>
                      <SelectItem value="2x_30_60">2x (30/60 dias)</SelectItem>
                      <SelectItem value="3x_30_60_90">3x (30/60/90 dias)</SelectItem>
                      <SelectItem value="personalizado">Personalizado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  placeholder="Informe observações adicionais sobre o pedido..."
                  className="min-h-[120px]"
                  value={pedido.observacoes}
                  onChange={(e) => setPedido({...pedido, observacoes: e.target.value})}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t px-6 py-4 flex justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(createPageUrl("PedidosCompra"))}
            >
              Cancelar
            </Button>
            
            <div className="flex gap-2">
              <Button
                type="submit"
                disabled={submitting}
                className="gap-2 bg-green-600 hover:bg-green-700"
              >
                {submitting ? (
                  <>
                    <Clock className="w-4 h-4 animate-spin" />
                    Processando...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Criar Pedido
                  </>
                )}
              </Button>
            </div>
          </CardFooter>
        </Card>
      </form>
      
      {/* Diálogo para seleção de Fornecedor */}
      <Dialog open={fornecedoresDialog} onOpenChange={setFornecedoresDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Selecionar Fornecedor</DialogTitle>
            <DialogDescription>
              Escolha um fornecedor para este pedido de compra
            </DialogDescription>
          </DialogHeader>
          
          <div className="mb-4 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Buscar fornecedor por nome, CNPJ..."
              className="pl-10"
              value={searchFornecedor}
              onChange={(e) => setSearchFornecedor(e.target.value)}
            />
          </div>
          
          <ScrollArea className="flex-1 max-h-[50vh]">
            {loading ? (
              <div className="space-y-2">
                {Array(5).fill(0).map((_, i) => (
                  <div key={i} className="p-4 border rounded-lg animate-pulse">
                    <div className="h-5 bg-gray-200 rounded w-1/2 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                  </div>
                ))}
              </div>
            ) : filteredFornecedores.length === 0 ? (
              <div className="text-center py-8">
                <Building className="mx-auto h-10 w-10 text-gray-300" />
                <p className="mt-2 text-gray-500">Nenhum fornecedor encontrado</p>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredFornecedores.map((fornecedor) => (
                  <div 
                    key={fornecedor.id}
                    className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => selecionarFornecedor(fornecedor)}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">{fornecedor.nome_fantasia}</h4>
                        <p className="text-sm text-gray-500">{fornecedor.razao_social}</p>
                        <p className="text-sm text-gray-500 mt-1">CNPJ: {fornecedor.cnpj}</p>
                        
                        <div className="flex flex-wrap gap-1 mt-2">
                          {fornecedor.categorias.map((categoria, index) => (
                            <Badge key={index} variant="outline" className="text-xs">{categoria}</Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex items-center text-sm">
                        <span className="font-medium mr-1">{fornecedor.avaliacao}</span>
                        <span className="text-yellow-500">★</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
          
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setFornecedoresDialog(false)}>
              Cancelar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Diálogo para seleção de Solicitação */}
      <Dialog open={solicitacoesDialog} onOpenChange={setSolicitacoesDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Selecionar Solicitação de Compra</DialogTitle>
            <DialogDescription>
              Escolha uma solicitação aprovada para criar o pedido
            </DialogDescription>
          </DialogHeader>
          
          <div className="mb-4 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Buscar solicitação por número, solicitante..."
              className="pl-10"
              value={searchSolicitacao}
              onChange={(e) => setSearchSolicitacao(e.target.value)}
            />
          </div>
          
          <ScrollArea className="flex-1 max-h-[50vh]">
            {loading ? (
              <div className="space-y-2">
                {Array(5).fill(0).map((_, i) => (
                  <div key={i} className="p-4 border rounded-lg animate-pulse">
                    <div className="h-5 bg-gray-200 rounded w-1/2 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                  </div>
                ))}
              </div>
            ) : filteredSolicitacoes.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="mx-auto h-10 w-10 text-gray-300" />
                <p className="mt-2 text-gray-500">Nenhuma solicitação encontrada</p>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredSolicitacoes.map((solicitacao) => (
                  <div 
                    key={solicitacao.id}
                    className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => selecionarSolicitacao(solicitacao)}
                  >
                    <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium">{solicitacao.numero_solicitacao}</h4>
                          <Badge className="bg-green-100 text-green-800">Aprovada</Badge>
                        </div>
                        
                        <p className="text-sm text-gray-500 mt-1">
                          Solicitado por {solicitacao.solicitante.nome} ({solicitacao.solicitante.setor})
                        </p>
                        
                        <p className="text-sm mt-1">
                          {solicitacao.justificativa}
                        </p>
                        
                        <div className="flex flex-wrap gap-2 mt-2 text-sm text-gray-500">
                          <div className="flex items-center">
                            <Calendar className="w-3.5 h-3.5 mr-1" />
                            {formatDate(solicitacao.data_solicitacao)}
                          </div>
                          <div className="flex items-center">
                            <DollarSign className="w-3.5 h-3.5 mr-1" />
                            {formatCurrency(solicitacao.valor_total)}
                          </div>
                          <div>
                            {solicitacao.itens.length} {solicitacao.itens.length === 1 ? 'item' : 'itens'}
                          </div>
                        </div>
                      </div>
                      
                      <Button variant="outline" size="sm" className="self-start">
                        Selecionar
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
          
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setSolicitacoesDialog(false)}>
              Cancelar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}