import React, { useState, useEffect } from 'react';
import { Task } from '@/api/entities';
import { User } from '@/api/entities';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  CheckSquare, 
  Clock, 
  AlertCircle, 
  CheckCircle,
  Calendar,
  Plus,
  Search
} from 'lucide-react';
import TaskForm from "../components/tasks/TaskForm";
import TaskDetail from "../components/tasks/TaskDetail";

const STATUS_COLORS = {
  backlog: "bg-slate-200 text-slate-800",
  todo: "bg-indigo-100 text-indigo-800",
  in_progress: "bg-purple-100 text-purple-800",
  review: "bg-amber-100 text-amber-800",
  done: "bg-green-100 text-green-800"
};

const PRIORITY_COLORS = {
  low: "bg-blue-100 text-blue-800",
  medium: "bg-yellow-100 text-yellow-800",
  high: "bg-orange-100 text-orange-800",
  urgent: "bg-red-100 text-red-800"
};

export default function MyTasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [showTaskDetail, setShowTaskDetail] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Get current user
      const user = await User.me();
      setCurrentUser(user);
      
      // Get all tasks
      const allTasks = await Task.list();
      
      // Filter tasks assigned to current user
      setTasks(allTasks);
    } catch (error) {
      console.error('Error loading tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTask = async (taskData) => {
    try {
      await Task.create(taskData);
      loadData();
    } catch (error) {
      console.error('Error creating task:', error);
    }
  };

  const handleTaskUpdate = (updatedTask) => {
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === updatedTask.id ? updatedTask : task
      )
    );
  };

  const handleTaskDelete = (taskId) => {
    setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
  };

  const getFilteredTasks = (status) => {
    return tasks.filter(task => 
      task.assigned_to === currentUser?.id && 
      (status === 'all' || task.status === status) &&
      (searchTerm === '' || 
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.description?.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  };

  const getOverdueTasks = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return tasks.filter(task => 
      task.assigned_to === currentUser?.id && 
      task.status !== 'done' &&
      task.due_date && 
      new Date(task.due_date) < today &&
      (searchTerm === '' || 
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.description?.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  };

  const getDueSoonTasks = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const nextWeek = new Date(today);
    nextWeek.setDate(today.getDate() + 7);
    
    return tasks.filter(task => 
      task.assigned_to === currentUser?.id && 
      task.status !== 'done' &&
      task.due_date && 
      new Date(task.due_date) >= today &&
      new Date(task.due_date) <= nextWeek &&
      (searchTerm === '' || 
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.description?.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  };

  const openTaskDetail = (task) => {
    setSelectedTask(task);
    setShowTaskDetail(true);
  };

  const renderTaskList = (tasksList) => {
    if (tasksList.length === 0) {
      return (
        <div className="p-8 text-center">
          <p className="text-gray-500">Nenhuma tarefa encontrada</p>
        </div>
      );
    }
    
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tasksList.map(task => (
          <Card 
            key={task.id} 
            className="hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => openTaskDetail(task)}
          >
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{task.title}</CardTitle>
                <Badge className={PRIORITY_COLORS[task.priority]}>
                  {task.priority}
                </Badge>
              </div>
              <div className="flex gap-2 mt-2">
                <Badge className={STATUS_COLORS[task.status]}>
                  {task.status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </Badge>
                {task.due_date && new Date(task.due_date) < new Date() && task.status !== 'done' && (
                  <Badge variant="destructive">Atrasada</Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500 line-clamp-2">{task.description}</p>
              
              {task.due_date && (
                <div className="flex items-center mt-4 text-sm text-gray-500">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>Vencimento: {new Date(task.due_date).toLocaleDateString()}</span>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-200px)]">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <h1 className="text-2xl font-bold">Minhas Tarefas</h1>
        
        <div className="flex flex-col md:flex-row items-center gap-3 w-full md:w-auto">
          <div className="flex items-center bg-white rounded-lg border px-3 py-1 w-full md:w-64">
            <Search className="w-4 h-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Buscar tarefas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="border-0 focus-visible:ring-0"
            />
          </div>
          
          <Button onClick={() => setShowTaskForm(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Nova Tarefa
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total de Tarefas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{getFilteredTasks('all').length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Tarefas Pendentes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{getFilteredTasks('todo').length + getFilteredTasks('in_progress').length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Em Progresso</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{getFilteredTasks('in_progress').length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Atrasadas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{getOverdueTasks().length}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="all">Todas</TabsTrigger>
          <TabsTrigger value="overdue">Atrasadas</TabsTrigger>
          <TabsTrigger value="duesoon">Prazo Próximo</TabsTrigger>
          <TabsTrigger value="inprogress">Em Progresso</TabsTrigger>
          <TabsTrigger value="complete">Concluídas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          {renderTaskList(getFilteredTasks('all'))}
        </TabsContent>
        
        <TabsContent value="overdue">
          {renderTaskList(getOverdueTasks())}
        </TabsContent>
        
        <TabsContent value="duesoon">
          {renderTaskList(getDueSoonTasks())}
        </TabsContent>
        
        <TabsContent value="inprogress">
          {renderTaskList(getFilteredTasks('in_progress'))}
        </TabsContent>
        
        <TabsContent value="complete">
          {renderTaskList(getFilteredTasks('done'))}
        </TabsContent>
      </Tabs>
      
      {/* Task Form Dialog */}
      <TaskForm 
        open={showTaskForm}
        onOpenChange={setShowTaskForm}
        onSubmit={handleCreateTask}
      />
      
      {/* Task Detail Dialog */}
      {selectedTask && (
        <TaskDetail
          taskId={selectedTask.id}
          open={showTaskDetail}
          onOpenChange={setShowTaskDetail}
          onTaskUpdate={handleTaskUpdate}
          onTaskDelete={handleTaskDelete}
        />
      )}
    </div>
  );
}