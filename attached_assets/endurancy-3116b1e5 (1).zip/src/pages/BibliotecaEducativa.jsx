import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Search,
  FileText,
  Video,
  Info,
  BookOpen,
  Podcast,
  Filter,
  ChevronDown,
  Tag,
  Bookmark,
  Share2,
  Eye,
  ThumbsUp,
  Clock,
  Plus,
  Pencil,
  MessageSquare
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuGroup,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { Spinner } from '@/components/ui/spinner';
import { toast } from '@/components/ui/use-toast';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function BibliotecaEducativa() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [conteudos, setConteudos] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [activeTab, setActiveTab] = useState('destaque');
  const [savedContents, setSavedContents] = useState([]);
  
  const tiposConteudo = [
    { value: 'all', label: 'Todos os tipos' },
    { value: 'artigo', label: 'Artigos', icon: FileText },
    { value: 'video', label: 'Vídeos', icon: Video },
    { value: 'infografico', label: 'Infográficos', icon: Info },
    { value: 'faq', label: 'FAQs', icon: MessageSquare },
    { value: 'podcast', label: 'Podcasts', icon: Podcast }
  ];
  
  const categorias = [
    { value: 'all', label: 'Todas as categorias' },
    { value: 'cannabis_medicinal', label: 'Cannabis Medicinal' },
    { value: 'dor_cronica', label: 'Dor Crônica' },
    { value: 'ansiedade', label: 'Ansiedade' },
    { value: 'insonia', label: 'Insônia' },
    { value: 'tratamentos', label: 'Tratamentos' },
    { value: 'pesquisas', label: 'Pesquisas e Estudos' },
    { value: 'saude_geral', label: 'Saúde Geral' }
  ];
  
  useEffect(() => {
    loadConteudos();
  }, []);
  
  const loadConteudos = async () => {
    setLoading(true);
    try {
      // Simulação de carregamento de dados
      setTimeout(() => {
        const mockConteudos = [
          {
            id: 'cont_1',
            titulo: 'Entendendo o CBD e seus benefícios terapêuticos',
            subtitulo: 'Um guia completo sobre canabidiol e seu potencial medicinal',
            tipo: 'artigo',
            categoria: 'cannabis_medicinal',
            tags: ['CBD', 'terapêutico', 'canabidiol', 'benefícios'],
            url_midia: 'https://images.unsplash.com/photo-1628755847614-c8ba86130db3?q=80&w=2070',
            autor_nome: 'Dra. Ana Silva',
            nivel_complexidade: 'intermediario',
            data_publicacao: '2023-08-15T14:30:00Z',
            tempo_leitura: 12,
            visualizacoes: 1280,
            curtidas: 157,
            destaque: true
          },
          {
            id: 'cont_2',
            titulo: 'Cannabis no tratamento da dor crônica: Evidências científicas',
            subtitulo: 'Pesquisas recentes sobre a eficácia dos canabinoides para dor',
            tipo: 'artigo',
            categoria: 'dor_cronica',
            tags: ['dor crônica', 'evidências', 'tratamento', 'canabinoides'],
            url_midia: 'https://images.unsplash.com/photo-1584305574647-ac6507f1abbe?q=80&w=2070',
            autor_nome: 'Dr. Carlos Santos',
            nivel_complexidade: 'avancado',
            data_publicacao: '2023-09-22T10:15:00Z',
            tempo_leitura: 18,
            visualizacoes: 945,
            curtidas: 89,
            destaque: true
          },
          {
            id: 'cont_3',
            titulo: 'Como funciona o sistema endocanabinoide?',
            subtitulo: 'Entenda como seu corpo interage com os canabinoides',
            tipo: 'video',
            categoria: 'cannabis_medicinal',
            tags: ['sistema endocanabinoide', 'fisiologia', 'receptores', 'CB1', 'CB2'],
            url_midia: 'https://images.unsplash.com/photo-1631651852602-739ca1cce743?q=80&w=2070',
            url_video: 'https://www.youtube.com/embed/example',
            autor_nome: 'Dr. Roberto Oliveira',
            nivel_complexidade: 'intermediario',
            data_publicacao: '2023-10-05T16:45:00Z',
            tempo_leitura: 25, // duração do vídeo
            visualizacoes: 2430,
            curtidas: 312,
            destaque: true
          },
          {
            id: 'cont_4',
            titulo: 'Dúvidas Frequentes sobre Cannabis Medicinal',
            subtitulo: 'Respostas para as perguntas mais comuns de pacientes',
            tipo: 'faq',
            categoria: 'tratamentos',
            tags: ['dúvidas', 'iniciantes', 'tratamento', 'orientação'],
            url_midia: 'https://images.unsplash.com/photo-1611600382499-8f14e80d1a9f?q=80&w=2070',
            autor_nome: 'Equipe Médica Endurancy',
            nivel_complexidade: 'basico',
            data_publicacao: '2023-11-10T09:20:00Z',
            tempo_leitura: 10,
            visualizacoes: 3150,
            curtidas: 246,
            destaque: false,
            faq_items: [
              {
                pergunta: 'A cannabis medicinal causa dependência?',
                resposta: 'Os produtos de cannabis medicinal são formulados para minimizar efeitos psicoativos. Quando usados conforme prescrito, o risco de dependência é baixo, especialmente em produtos ricos em CBD com baixo THC.'
              },
              {
                pergunta: 'Como é a forma de administração?',
                resposta: 'Existem várias formas: óleos sublinguais, cápsulas orais, sprays, produtos tópicos e flores secas para vaporização (mediante autorização específica). Seu médico irá recomendar a forma mais adequada.'
              }
            ]
          },
          {
            id: 'cont_5',
            titulo: 'Diferenças entre THC e CBD explicadas',
            subtitulo: 'Entenda como cada composto age e seus efeitos terapêuticos',
            tipo: 'infografico',
            categoria: 'cannabis_medicinal',
            tags: ['THC', 'CBD', 'diferenças', 'efeitos'],
            url_midia: 'https://images.unsplash.com/photo-1602350190789-94ac54127df5?q=80&w=2070',
            autor_nome: 'Dra. Luciana Ferreira',
            nivel_complexidade: 'basico',
            data_publicacao: '2023-07-20T11:10:00Z',
            tempo_leitura: 5,
            visualizacoes: 4210,
            curtidas: 325,
            destaque: false
          },
          {
            id: 'cont_6',
            titulo: 'Podcast: Conversas sobre Cannabis Medicinal',
            subtitulo: 'Entrevista com especialistas sobre avanços no tratamento',
            tipo: 'podcast',
            categoria: 'pesquisas',
            tags: ['entrevista', 'especialistas', 'avanços', 'pesquisa'],
            url_midia: 'https://images.unsplash.com/photo-1589903308904-1010c2294adc?q=80&w=2070',
            autor_nome: 'Marcos Almeida',
            nivel_complexidade: 'intermediario',
            data_publicacao: '2023-12-01T15:30:00Z',
            tempo_leitura: 45, // duração do podcast
            visualizacoes: 760,
            curtidas: 98,
            destaque: false
          }
        ];
        
        setConteudos(mockConteudos);
        setLoading(false);
        
        // Simular alguns conteúdos salvos
        setSavedContents(['cont_1', 'cont_3']);
      }, 1000);
    } catch (error) {
      console.error('Erro ao carregar conteúdos:', error);
      toast({
        title: "Erro ao carregar biblioteca",
        description: "Não foi possível carregar os conteúdos. Tente novamente mais tarde.",
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  const getFilteredContent = () => {
    return conteudos.filter(content => {
      const matchesSearch = content.titulo.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            content.subtitulo.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = selectedCategory === 'all' || content.categoria === selectedCategory;
      
      const matchesType = selectedType === 'all' || content.tipo === selectedType;
      
      const matchesTab = 
        (activeTab === 'destaque' && content.destaque) ||
        (activeTab === 'recentes' && true) ||
        (activeTab === 'populares' && content.visualizacoes > 1000) ||
        (activeTab === 'salvos' && savedContents.includes(content.id));
      
      return matchesSearch && matchesCategory && matchesType && matchesTab;
    });
  };

  const handleToggleSaved = (contentId) => {
    if (savedContents.includes(contentId)) {
      setSavedContents(savedContents.filter(id => id !== contentId));
      toast({
        title: "Conteúdo removido",
        description: "O conteúdo foi removido dos seus itens salvos.",
      });
    } else {
      setSavedContents([...savedContents, contentId]);
      toast({
        title: "Conteúdo salvo",
        description: "O conteúdo foi adicionado aos seus itens salvos.",
      });
    }
  };

  const getContentIcon = (type) => {
    switch (type) {
      case 'artigo': return <FileText className="h-5 w-5 text-blue-600" />;
      case 'video': return <Video className="h-5 w-5 text-red-600" />;
      case 'infografico': return <Info className="h-5 w-5 text-purple-600" />;
      case 'faq': return <MessageSquare className="h-5 w-5 text-green-600" />;
      case 'podcast': return <Podcast className="h-5 w-5 text-orange-600" />;
      default: return <BookOpen className="h-5 w-5 text-gray-600" />;
    }
  };

  const getContentTypeBadge = (type) => {
    const typeConfig = {
      artigo: { color: "bg-blue-100 text-blue-800", label: "Artigo" },
      video: { color: "bg-red-100 text-red-800", label: "Vídeo" },
      infografico: { color: "bg-purple-100 text-purple-800", label: "Infográfico" },
      faq: { color: "bg-green-100 text-green-800", label: "FAQ" },
      podcast: { color: "bg-orange-100 text-orange-800", label: "Podcast" },
    };

    const config = typeConfig[type] || { color: "bg-gray-100 text-gray-800", label: type };

    return (
      <Badge className={`${config.color}`}>
        {config.label}
      </Badge>
    );
  };

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true, locale: ptBR });
    } catch (e) {
      console.error("Erro ao formatar data:", e);
      return dateString;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Biblioteca Educativa</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Artigos, vídeos e outros conteúdos para sua educação sobre saúde e tratamentos
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button 
            onClick={() => navigate(createPageUrl("FaqPacientes"))}
            variant="outline"
            className="flex items-center gap-2"
          >
            <MessageSquare className="h-4 w-4" />
            Perguntas Frequentes
          </Button>
          <Button 
            onClick={() => navigate(createPageUrl("NovoConteudo"))}
            className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
          >
            <Plus className="h-4 w-4" />
            Novo Conteúdo
          </Button>
        </div>
      </div>

      {/* Barra de pesquisa e filtros */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar por título ou assunto..."
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex gap-2 flex-wrap">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    <span>Tipo</span>
                    <ChevronDown className="h-3 w-3 opacity-50" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  {tiposConteudo.map((tipo) => (
                    <DropdownMenuItem 
                      key={tipo.value}
                      onClick={() => setSelectedType(tipo.value)}
                      className={selectedType === tipo.value ? "bg-gray-100 dark:bg-gray-800" : ""}
                    >
                      {tipo.icon && <tipo.icon className="h-4 w-4 mr-2" />}
                      {tipo.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Tag className="h-4 w-4" />
                    <span>Categoria</span>
                    <ChevronDown className="h-3 w-3 opacity-50" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  {categorias.map((categoria) => (
                    <DropdownMenuItem 
                      key={categoria.value}
                      onClick={() => setSelectedCategory(categoria.value)}
                      className={selectedCategory === categoria.value ? "bg-gray-100 dark:bg-gray-800" : ""}
                    >
                      {categoria.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Abas e Conteúdo */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="destaque">Em Destaque</TabsTrigger>
          <TabsTrigger value="recentes">Recentes</TabsTrigger>
          <TabsTrigger value="populares">Mais Populares</TabsTrigger>
          <TabsTrigger value="salvos">Salvos</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-4">
          {loading ? (
            <div className="flex justify-center items-center py-12">
              <Spinner size="lg" />
            </div>
          ) : (
            <>
              {getFilteredContent().length === 0 ? (
                <div className="text-center py-12">
                  <BookOpen className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-700 mb-3" />
                  <h3 className="text-lg font-medium">Nenhum conteúdo encontrado</h3>
                  <p className="text-gray-500 dark:text-gray-400 mt-1">
                    Tente ajustar seus filtros ou buscar por outro termo.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {getFilteredContent().map((content) => (
                    <Card key={content.id} className="overflow-hidden flex flex-col h-full hover:shadow-md transition-shadow">
                      <div className="relative h-48 overflow-hidden">
                        <img 
                          src={content.url_midia} 
                          alt={content.titulo}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-2 left-2 flex gap-2">
                          {getContentTypeBadge(content.tipo)}
                          {content.nivel_complexidade === 'basico' && (
                            <Badge className="bg-green-100 text-green-800">Básico</Badge>
                          )}
                          {content.nivel_complexidade === 'avancado' && (
                            <Badge className="bg-orange-100 text-orange-800">Avançado</Badge>
                          )}
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="absolute top-2 right-2 bg-white/80 hover:bg-white"
                          onClick={() => handleToggleSaved(content.id)}
                        >
                          <Bookmark 
                            className={`h-5 w-5 ${savedContents.includes(content.id) ? 'fill-current text-amber-500' : 'text-gray-600'}`}
                          />
                        </Button>
                      </div>
                      <CardContent className="p-5 flex-1 flex flex-col">
                        <div className="flex items-start justify-between gap-4 mb-3">
                          <h3 className="font-semibold text-lg leading-tight">{content.titulo}</h3>
                          {getContentIcon(content.tipo)}
                        </div>
                        <p className="text-gray-500 dark:text-gray-400 text-sm mb-4 flex-1">
                          {content.subtitulo}
                        </p>
                        <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            <span>{content.tempo_leitura} min</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Eye className="h-4 w-4" />
                            <span>{content.visualizacoes}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <ThumbsUp className="h-4 w-4" />
                            <span>{content.curtidas}</span>
                          </div>
                        </div>
                      </CardContent>
                      <Separator />
                      <CardFooter className="p-5">
                        <div className="flex items-center justify-between w-full">
                          <div className="flex items-center gap-2">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback>
                                {content.autor_nome.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            <div className="text-sm">
                              <p className="font-medium">{content.autor_nome}</p>
                              <p className="text-gray-500 dark:text-gray-400">
                                {formatDate(content.data_publicacao)}
                              </p>
                            </div>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => navigate(`${createPageUrl("ConteudoDetalhes")}?id=${content.id}`)}
                          >
                            Ler mais
                          </Button>
                        </div>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}