import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  LayoutGrid, 
  FileText, 
  FlaskConical, 
  ClipboardCheck, 
  ShieldCheck, 
  Package, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  Truck, 
  ArrowRightLeft, 
  Search, 
  Filter, 
  BarChart2, 
  Factory,
  Beaker,
  Microscope,
  Clipboard,
  FileCheck,
  ListChecks,
  ScrollText,
  Users,
  CalendarClock,
  Building,
  MessageSquare,
  Bell,
  Layers,
  History,
  Settings,
  HelpCircle,
  Plus,
  Circle
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";

export default function ModuloLaboratorio() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("home");

  const loteStatus = {
    emProducao: 3,
    quarentena: 5,
    aprovados: 12,
    reprovados: 1
  };

  const lotesRecentes = [
    {
      id: "LOT-2023-001",
      produto: "Óleo de CBD 5%",
      dataInicio: "2023-10-10",
      status: "liberado",
      responsavel: "Maria Oliveira"
    },
    {
      id: "LOT-2023-002",
      produto: "Óleo de CBD 10%",
      dataInicio: "2023-10-12",
      status: "quarentena",
      responsavel: "João Silva"
    },
    {
      id: "LOT-2023-003",
      produto: "Cápsulas CBD 25mg",
      dataInicio: "2023-10-15",
      status: "em_producao",
      responsavel: "Ana Costa"
    },
    {
      id: "LOT-2023-004",
      produto: "Pomada CBD 2%",
      dataInicio: "2023-10-05",
      status: "reprovado",
      responsavel: "Carlos Santos"
    }
  ];

  const etapasProducao = [
    { nome: "Diluição", concluido: true },
    { nome: "Envase", concluido: true },
    { nome: "Rotulagem", concluido: false },
    { nome: "Embalagem", concluido: false }
  ];

  const menuItems = [
    {
      title: "Home",
      icon: <LayoutGrid className="h-5 w-5" />,
      tab: "home"
    },
    {
      title: "Ordem de Processo",
      icon: <FileText className="h-5 w-5" />,
      tab: "ordemProcesso",
      subMenu: [
        { title: "Consulta", tab: "consulta" },
        { title: "Demanda", tab: "demanda" },
        { title: "Iniciar Processos", tab: "iniciarProcessos" }
      ]
    },
    {
      title: "Fabricar Produtos",
      icon: <Factory className="h-5 w-5" />,
      tab: "fabricarProdutos",
      subMenu: [
        { title: "Timeline de Fabricação", tab: "timelineFabricacao" },
        { title: "Suspender Produção", tab: "suspenderProducao" },
        { title: "Finalizar Processo", tab: "finalizarProcesso" },
        { title: "Reconciliar", tab: "reconciliar" },
        { title: "Movimentar", tab: "movimentar" }
      ]
    },
    {
      title: "Controle de Estoque",
      icon: <Package className="h-5 w-5" />,
      tab: "controleEstoque",
      subMenu: [
        { title: "Logística", tab: "logistica" },
        { title: "Pedido de Compras", tab: "pedidoCompras" },
        { title: "Descarte", tab: "descarte" }
      ]
    },
    {
      title: "Controle de Qualidade",
      icon: <FlaskConical className="h-5 w-5" />,
      tab: "controleQualidade",
      subMenu: [
        { title: "Análises", tab: "analises" },
        { title: "Amostragem", tab: "amostragem" },
        { title: "Aprovação", tab: "aprovacao" }
      ]
    },
    {
      title: "Garantia da Qualidade",
      icon: <ShieldCheck className="h-5 w-5" />,
      tab: "garantiaQualidade",
      subMenu: [
        { title: "Monitoramento", tab: "monitoramento" },
        { title: "Liberações", tab: "liberacoes" },
        { title: "Documentação", tab: "documentacao" },
        { title: "Treinamento", tab: "treinamento" },
        { title: "Fornecedores", tab: "fornecedores" },
        { title: "Relatórios", tab: "relatorios" }
      ]
    },
    {
      title: "POP Digital",
      icon: <ScrollText className="h-5 w-5" />,
      tab: "popDigital",
      subMenu: [
        { title: "Adicionar", tab: "adicionarPop" },
        { title: "Versões", tab: "versoesPop" },
        { title: "Consulta", tab: "consultaPop" }
      ]
    },
    {
      title: "SAC",
      icon: <MessageSquare className="h-5 w-5" />,
      tab: "sac",
      subMenu: [
        { title: "Abrir Atendimento", tab: "abrirAtendimento" },
        { title: "Farmacovigilância", tab: "farmacovigilancia" },
        { title: "Recolhimento", tab: "recolhimento" }
      ]
    },
    {
      title: "Audit Trail",
      icon: <History className="h-5 w-5" />,
      tab: "auditTrail"
    },
    {
      title: "Config",
      icon: <Settings className="h-5 w-5" />,
      tab: "config"
    },
    {
      title: "Ajuda",
      icon: <HelpCircle className="h-5 w-5" />,
      tab: "ajuda"
    }
  ];

  const getStatusBadge = (status) => {
    switch (status) {
      case "liberado":
        return <Badge className="bg-green-100 text-green-800">Liberado</Badge>;
      case "quarentena":
        return <Badge className="bg-yellow-100 text-yellow-800">Quarentena</Badge>;
      case "em_producao":
        return <Badge className="bg-blue-100 text-blue-800">Em Produção</Badge>;
      case "reprovado":
        return <Badge className="bg-red-100 text-red-800">Reprovado</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Módulo Laboratório (LAB)</h1>
          <p className="text-gray-500 mt-1">
            Gestão da produção de medicamentos e controle de qualidade
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <FileText className="h-4 w-4" /> Documentação
          </Button>
          <Button className="gap-2">
            <Plus className="h-4 w-4" /> Nova Ordem
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Em Produção
            </CardTitle>
            <div className="text-2xl font-bold">{loteStatus.emProducao}</div>
          </CardHeader>
          <CardContent>
            <div className="h-2 bg-blue-100 rounded">
              <div className="h-2 bg-blue-500 rounded" style={{ width: '30%' }}></div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Em Quarentena
            </CardTitle>
            <div className="text-2xl font-bold">{loteStatus.quarentena}</div>
          </CardHeader>
          <CardContent>
            <div className="h-2 bg-yellow-100 rounded">
              <div className="h-2 bg-yellow-500 rounded" style={{ width: '50%' }}></div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Aprovados
            </CardTitle>
            <div className="text-2xl font-bold">{loteStatus.aprovados}</div>
          </CardHeader>
          <CardContent>
            <div className="h-2 bg-green-100 rounded">
              <div className="h-2 bg-green-500 rounded" style={{ width: '70%' }}></div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Reprovados
            </CardTitle>
            <div className="text-2xl font-bold">{loteStatus.reprovados}</div>
          </CardHeader>
          <CardContent>
            <div className="h-2 bg-red-100 rounded">
              <div className="h-2 bg-red-500 rounded" style={{ width: '10%' }}></div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-12 md:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle>Navegação</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                {menuItems.map((item, index) => (
                  <div key={index} className="space-y-1">
                    <Button
                      variant={activeTab === item.tab ? "secondary" : "ghost"}
                      className="w-full justify-start gap-2"
                      onClick={() => setActiveTab(item.tab)}
                    >
                      {item.icon}
                      <span>{item.title}</span>
                    </Button>
                    
                    {item.subMenu && activeTab === item.tab && (
                      <div className="pl-8 space-y-1">
                        {item.subMenu.map((subItem, idx) => (
                          <Button
                            key={idx}
                            variant="ghost"
                            size="sm"
                            className="w-full justify-start text-sm text-muted-foreground"
                            onClick={() => setActiveTab(subItem.tab)}
                          >
                            {subItem.title}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="col-span-12 md:col-span-9">
          <Card>
            <CardHeader>
              <CardTitle>
                {activeTab === "home" ? "Dashboard" : 
                 menuItems.find(item => item.tab === activeTab)?.title || 
                 menuItems.find(item => item.subMenu?.some(sub => sub.tab === activeTab))?.subMenu.find(sub => sub.tab === activeTab)?.title ||
                 "Painel de Controle"}
              </CardTitle>
              <CardDescription>
                {activeTab === "home" ? "Visão geral da produção de medicamentos" : ""}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {activeTab === "home" && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-4">Lotes Recentes</h3>
                    <div className="rounded-md border">
                      <div className="grid grid-cols-5 font-medium p-3 border-b">
                        <div>ID Lote</div>
                        <div>Produto</div>
                        <div>Data Início</div>
                        <div>Responsável</div>
                        <div>Status</div>
                      </div>
                      {lotesRecentes.map((lote, idx) => (
                        <div key={idx} className="grid grid-cols-5 p-3 border-b last:border-b-0 hover:bg-muted/50">
                          <div>{lote.id}</div>
                          <div>{lote.produto}</div>
                          <div>{lote.dataInicio}</div>
                          <div>{lote.responsavel}</div>
                          <div>{getStatusBadge(lote.status)}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium mb-4">Timeline de Produção: LOT-2023-003</h3>
                    <div className="relative border p-4 rounded-md">
                      <div className="absolute left-8 top-4 bottom-4 w-0.5 bg-gray-200"></div>
                      {etapasProducao.map((etapa, idx) => (
                        <div key={idx} className="mb-4 last:mb-0 relative flex items-center ml-8 pl-4">
                          <div className="absolute left-[-32px] rounded-full w-6 h-6 flex items-center justify-center">
                            {etapa.concluido ? (
                              <CheckCircle2 className="w-6 h-6 text-green-500" />
                            ) : (
                              <Circle className="w-6 h-6 text-gray-300" />
                            )}
                          </div>
                          <p className={`${etapa.concluido ? 'text-black' : 'text-gray-500'}`}>
                            {etapa.nome}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium mb-2">Estoque de Materiais Críticos</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Matérias-primas com estoque abaixo do mínimo recomendado
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <Card className="bg-amber-50 border-amber-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm text-amber-800">Reagente para PCR</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex justify-between text-amber-800">
                            <span>Estoque: 2 unidades</span>
                            <span>Mínimo: 5</span>
                          </div>
                          <Progress value={40} className="h-2 mt-2" />
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-red-50 border-red-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm text-red-800">Óleo de CBD 30%</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex justify-between text-red-800">
                            <span>Estoque: 1 unidade</span>
                            <span>Mínimo: 10</span>
                          </div>
                          <Progress value={10} className="h-2 mt-2" />
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-amber-50 border-amber-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm text-amber-800">Frascos 30ml</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex justify-between text-amber-800">
                            <span>Estoque: 45 unidades</span>
                            <span>Mínimo: 100</span>
                          </div>
                          <Progress value={45} className="h-2 mt-2" />
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-amber-50 border-amber-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm text-amber-800">Rótulos Óleo 5%</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex justify-between text-amber-800">
                            <span>Estoque: 65 unidades</span>
                            <span>Mínimo: 100</span>
                          </div>
                          <Progress value={65} className="h-2 mt-2" />
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              )}
              
              {activeTab === "ordemProcesso" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Ordens de Processo</h3>
                  <p className="text-muted-foreground">
                    Gerencie a produção de lotes, desde a abertura até o monitoramento de estoque
                  </p>
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" /> Nova Ordem de Processo
                  </Button>
                </div>
              )}

              {activeTab === "fabricarProdutos" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Fabricação de Produtos</h3>
                  <p className="text-muted-foreground">
                    Acompanhe e gerencie todo o processo de produção, desde diluição até embalagem
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Lotes em Produção</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm">Selecione um lote para continuar a produção</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Timeline de Fabricação</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm">Visualize as etapas de produção do lote selecionado</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}
              
              {activeTab === "controleQualidade" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Controle de Qualidade</h3>
                  <p className="text-muted-foreground">
                    Realize análises, amostragens e aprovações de materiais e produtos
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Análises Pendentes</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold">7</span>
                          <Button variant="outline" size="sm">Ver todos</Button>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Lotes em Quarentena</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold">5</span>
                          <Button variant="outline" size="sm">Ver todos</Button>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Materiais Aprovados</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold">18</span>
                          <Button variant="outline" size="sm">Ver todos</Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}

              {activeTab === "garantiaQualidade" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Garantia da Qualidade</h3>
                  <p className="text-muted-foreground">
                    Gerencie o sistema de qualidade, documentação, treinamentos e fornecedores
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Lotes para Liberação</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold">3</span>
                          <Button variant="outline" size="sm">Liberar</Button>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Documentos para Revisão</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold">8</span>
                          <Button variant="outline" size="sm">Revisar</Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}

              {/* Conteúdo para outras abas seria implementado de forma semelhante */}
              
              {/* Mensagem genérica para abas sem conteúdo específico implementado */}
              {["consulta", "demanda", "iniciarProcessos", "timelineFabricacao", "suspenderProducao", 
                "finalizarProcesso", "reconciliar", "movimentar", "logistica", "pedidoCompras", 
                "descarte", "analises", "amostragem", "aprovacao", "monitoramento", "liberacoes", 
                "documentacao", "treinamento", "fornecedores", "relatorios", "popDigital", 
                "adicionarPop", "versoesPop", "consultaPop", "sac", "abrirAtendimento", 
                "farmacovigilancia", "recolhimento", "auditTrail", "config", "ajuda"].includes(activeTab) && (
                <div className="flex flex-col items-center justify-center p-12">
                  <Settings className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">Funcionalidade em Desenvolvimento</h3>
                  <p className="text-muted-foreground text-center max-w-md">
                    Esta funcionalidade está em desenvolvimento conforme os requisitos do módulo COMPLY LEGACY 2.0 - Laboratório (LAB).
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}