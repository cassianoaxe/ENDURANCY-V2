import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  LayoutDashboard, Video, Users, ClipboardList, Brain, DollarSign, 
  Settings, LogOut, Menu, X, Bell, ChevronDown, Calendar, Clock, 
  FileText, Stethoscope, CreditCard, Wallet, UserCog
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Links de navegação centralizados que serão usados em todo o portal
export const doctorNavigationLinks = [
  {
    name: "Dashboard",
    path: "DoctorDashboard",
    icon: LayoutDashboard
  },
  {
    name: "Pacientes",
    path: "DoctorPatients",
    icon: Users
  },
  {
    name: "Consultas",
    path: "DoctorAppointments",
    icon: Calendar
  },
  {
    name: "Prescrições",
    path: "DoctorPrescriptions",
    icon: FileText
  },
  {
    name: "Telemedicina",
    path: "ConsultaVirtual",
    icon: Video
  },
  {
    name: "Financeiro",
    path: "DoctorFinancial",
    icon: DollarSign
  },
  {
    name: "Configurações",
    path: "DoctorSettings",
    icon: Settings
  }
];

export default function DoctorPortal() {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Renderiza a navegação lateral
  const renderNavigation = () => {
    return (
      <nav className={`bg-white border-r border-gray-200 w-64 min-h-screen fixed top-0 left-0 transform transition-transform duration-200 ease-in-out ${isMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}>
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center">
              <span className="text-pink-600 font-bold">EC</span>
            </div>
            <span className="ml-2 text-xl font-semibold">Portal Médico</span>
          </div>
        </div>

        <div className="p-4">
          {doctorNavigationLinks.map((link) => {
            const Icon = link.icon;
            return (
              <Link
                key={link.path}
                to={createPageUrl(link.path)}
                className="flex items-center px-4 py-2 text-gray-700 hover:bg-pink-50 hover:text-pink-600 rounded-lg mb-1"
              >
                <Icon className="h-5 w-5 mr-3" />
                <span>{link.name}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Mobile */}
      <div className="md:hidden bg-white border-b border-gray-200 fixed top-0 left-0 right-0 z-50">
        <div className="flex items-center justify-between p-4">
          <Button variant="ghost" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
          <span className="text-xl font-semibold">Portal Médico</span>
        </div>
      </div>

      {/* Navigation Sidebar */}
      {renderNavigation()}

      {/* Main Content */}
      <div className="md:ml-64 p-4 pt-16 md:pt-4">
        {/* Área de conteúdo onde as páginas serão renderizadas */}
      </div>
    </div>
  );
}