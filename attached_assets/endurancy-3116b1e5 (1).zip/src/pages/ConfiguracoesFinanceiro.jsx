import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { CentroCusto, PlanoContas, FormaPagamento } from '@/api/entities';
import {
  DollarSign,
  Building2,
  Tag,
  FileText,
  CreditCard,
  Plus,
  Edit,
  Trash2,
  Check,
  X,
  MoreHorizontal,
  AlertTriangle,
  ClipboardList,
  Layers,
  ArrowRightLeft,
  Settings,
  ArrowLeft,
  ArrowUp,
  Clock,
  Percent,
  Calendar,
  Eye,
  EyeOff,
  Search,
  ChevronRight,
  ChevronsUpDown,
  RefreshCw,
  Binary,
  BarChart2,
  BarChart,
  PieChart,
  Copy,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { toast } from '@/components/ui/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

export default function ConfiguracoesFinanceiro() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('centros');
  const [loading, setLoading] = useState(true);
  
  // Estados para Centros de Custo
  const [centrosCusto, setCentrosCusto] = useState([]);
  const [showAddCentroDialog, setShowAddCentroDialog] = useState(false);
  const [showEditCentroDialog, setShowEditCentroDialog] = useState(false);
  const [centroSelecionado, setCentroSelecionado] = useState(null);
  const [confirmDeleteCentro, setConfirmDeleteCentro] = useState(false);
  
  // Estados para Plano de Contas
  const [planoContas, setPlanoContas] = useState([]);
  const [showAddPlanoDialog, setShowAddPlanoDialog] = useState(false);
  const [showEditPlanoDialog, setShowEditPlanoDialog] = useState(false);
  const [contaContabilSelecionada, setContaContabilSelecionada] = useState(null);
  const [confirmDeleteContaContabil, setConfirmDeleteContaContabil] = useState(false);
  
  // Estados para Formas de Pagamento
  const [formasPagamento, setFormasPagamento] = useState([]);
  const [showAddFormaDialog, setShowAddFormaDialog] = useState(false);
  const [showEditFormaDialog, setShowEditFormaDialog] = useState(false);
  const [formaSelecionada, setFormaSelecionada] = useState(null);
  const [confirmDeleteForma, setConfirmDeleteForma] = useState(false);
  
  const [expandedCentros, setExpandedCentros] = useState({});

  // Carregamento de dados
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        await loadCentrosCusto();
        await loadPlanoContas();
        await loadFormasPagamento();
      } catch (error) {
        console.error("Erro ao carregar configurações financeiras:", error);
        toast({
          title: "Erro ao carregar dados",
          description: "Não foi possível carregar algumas configurações financeiras.",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);

  // ----- Funções para Centros de Custo -----
  const loadCentrosCusto = async () => {
    // Simulando carregamento de dados
    const mockCentros = [
      {
        id: "cc1",
        codigo: "CC-ADM",
        nome: "Administrativo",
        descricao: "Despesas administrativas gerais",
        pai_id: null,
        ativo: true,
        responsavel_nome: "Carlos Mendes",
        orcamento_anual: 120000,
        tipo: "despesa",
        nivel: 1,
        cor: "#607D8B"
      },
      {
        id: "cc2",
        codigo: "CC-ADM-RH",
        nome: "Recursos Humanos",
        descricao: "Despesas com pessoal e recrutamento",
        pai_id: "cc1",
        ativo: true,
        responsavel_nome: "Maria Oliveira",
        orcamento_anual: 80000,
        tipo: "despesa",
        nivel: 2,
        cor: "#78909C"
      },
      {
        id: "cc3",
        codigo: "CC-ADM-FIN",
        nome: "Financeiro",
        descricao: "Despesas com financeiro e contabilidade",
        pai_id: "cc1",
        ativo: true,
        responsavel_nome: "João Paulo",
        orcamento_anual: 40000,
        tipo: "despesa",
        nivel: 2,
        cor: "#90A4AE"
      },
      {
        id: "cc4",
        codigo: "CC-COM",
        nome: "Comercial",
        descricao: "Despesas comerciais e de vendas",
        pai_id: null,
        ativo: true,
        responsavel_nome: "Ana Silva",
        orcamento_anual: 150000,
        tipo: "despesa",
        nivel: 1,
        cor: "#FF9800"
      },
      {
        id: "cc5",
        codigo: "CC-COM-MKT",
        nome: "Marketing",
        descricao: "Despesas com marketing e publicidade",
        pai_id: "cc4",
        ativo: true,
        responsavel_nome: "Paulo Santos",
        orcamento_anual: 100000,
        tipo: "despesa",
        nivel: 2,
        cor: "#FFA726"
      },
      {
        id: "cc6",
        codigo: "CC-PROD",
        nome: "Produção",
        descricao: "Despesas com produção e operação",
        pai_id: null,
        ativo: true,
        responsavel_nome: "Roberto Alves",
        orcamento_anual: 300000,
        tipo: "despesa",
        nivel: 1,
        cor: "#2196F3"
      },
      {
        id: "cc7",
        codigo: "CC-PROD-LAB",
        nome: "Laboratório",
        descricao: "Despesas com laboratório e pesquisa",
        pai_id: "cc6",
        ativo: true,
        responsavel_nome: "Lúcia Ferreira",
        orcamento_anual: 150000,
        tipo: "despesa",
        nivel: 2,
        cor: "#42A5F5"
      },
      {
        id: "cc8",
        codigo: "CC-PROD-QA",
        nome: "Controle de Qualidade",
        descricao: "Despesas com controle de qualidade",
        pai_id: "cc6",
        ativo: true,
        responsavel_nome: "Marcos Souza",
        orcamento_anual: 120000,
        tipo: "despesa",
        nivel: 2,
        cor: "#64B5F6"
      },
      {
        id: "cc9",
        codigo: "CC-VENDAS",
        nome: "Vendas",
        descricao: "Receitas de vendas",
        pai_id: null,
        ativo: true,
        responsavel_nome: "Ricardo Gomes",
        orcamento_anual: 1200000,
        tipo: "receita",
        nivel: 1,
        cor: "#4CAF50"
      }
    ];

    // Organizar hierarquicamente
    const hierarquicos = mockCentros.filter(centro => centro.pai_id === null);
    mockCentros.forEach(centro => {
      if (centro.pai_id) {
        const pai = mockCentros.find(c => c.id === centro.pai_id);
        if (pai) {
          pai.children = pai.children || [];
          pai.children.push(centro);
        }
      }
    });

    setCentrosCusto(mockCentros);
  };

  // ----- Funções para Plano de Contas -----
  const loadPlanoContas = async () => {
    // Simulando carregamento de dados
    const mockPlanoContas = [
      {
        id: "pc1",
        codigo: "1",
        nome: "Ativo",
        descricao: "Bens e direitos",
        tipo: "ativo",
        natureza: "devedora",
        pai_id: null,
        nivel: 1,
        ativa: true,
        analitica: false
      },
      {
        id: "pc2",
        codigo: "1.1",
        nome: "Ativo Circulante",
        descricao: "Ativos de curto prazo",
        tipo: "ativo",
        natureza: "devedora",
        pai_id: "pc1",
        nivel: 2,
        ativa: true,
        analitica: false
      },
      {
        id: "pc3",
        codigo: "1.1.01",
        nome: "Caixa e Equivalentes",
        descricao: "Dinheiro e equivalentes de caixa",
        tipo: "ativo",
        natureza: "devedora",
        pai_id: "pc2",
        nivel: 3,
        ativa: true,
        analitica: false
      },
      {
        id: "pc4",
        codigo: "1.1.01.01",
        nome: "Caixa",
        descricao: "Dinheiro em espécie",
        tipo: "ativo",
        natureza: "devedora",
        pai_id: "pc3",
        nivel: 4,
        ativa: true,
        analitica: true
      },
      {
        id: "pc5",
        codigo: "1.1.01.02",
        nome: "Bancos Conta Movimento",
        descricao: "Valores em contas bancárias",
        tipo: "ativo",
        natureza: "devedora",
        pai_id: "pc3",
        nivel: 4,
        ativa: true,
        analitica: true
      },
      {
        id: "pc6",
        codigo: "2",
        nome: "Passivo",
        descricao: "Obrigações",
        tipo: "passivo",
        natureza: "credora",
        pai_id: null,
        nivel: 1,
        ativa: true,
        analitica: false
      },
      {
        id: "pc7",
        codigo: "2.1",
        nome: "Passivo Circulante",
        descricao: "Obrigações de curto prazo",
        tipo: "passivo",
        natureza: "credora",
        pai_id: "pc6",
        nivel: 2,
        ativa: true,
        analitica: false
      },
      {
        id: "pc8",
        codigo: "2.1.01",
        nome: "Fornecedores",
        descricao: "Valores a pagar a fornecedores",
        tipo: "passivo",
        natureza: "credora",
        pai_id: "pc7",
        nivel: 3,
        ativa: true,
        analitica: true
      },
      {
        id: "pc9",
        codigo: "3",
        nome: "Receitas",
        descricao: "Receitas operacionais",
        tipo: "receita",
        natureza: "credora",
        pai_id: null,
        nivel: 1,
        ativa: true,
        analitica: false
      },
      {
        id: "pc10",
        codigo: "3.1",
        nome: "Receitas Operacionais",
        descricao: "Receitas da atividade principal",
        tipo: "receita",
        natureza: "credora",
        pai_id: "pc9",
        nivel: 2,
        ativa: true,
        analitica: false
      },
      {
        id: "pc11",
        codigo: "3.1.01",
        nome: "Venda de Produtos",
        descricao: "Receitas com vendas de produtos",
        tipo: "receita",
        natureza: "credora",
        pai_id: "pc10",
        nivel: 3,
        ativa: true,
        analitica: true
      },
      {
        id: "pc12",
        codigo: "4",
        nome: "Despesas",
        descricao: "Despesas operacionais",
        tipo: "despesa",
        natureza: "devedora",
        pai_id: null,
        nivel: 1,
        ativa: true,
        analitica: false
      },
      {
        id: "pc13",
        codigo: "4.1",
        nome: "Despesas Operacionais",
        descricao: "Despesas da atividade principal",
        tipo: "despesa",
        natureza: "devedora",
        pai_id: "pc12",
        nivel: 2,
        ativa: true,
        analitica: false
      },
      {
        id: "pc14",
        codigo: "4.1.01",
        nome: "Despesas Administrativas",
        descricao: "Despesas com administração",
        tipo: "despesa",
        natureza: "devedora",
        pai_id: "pc13",
        nivel: 3,
        ativa: true,
        analitica: true
      },
      {
        id: "pc15",
        codigo: "4.1.02",
        nome: "Despesas com Pessoal",
        descricao: "Despesas com folha de pagamento",
        tipo: "despesa",
        natureza: "devedora",
        pai_id: "pc13",
        nivel: 3,
        ativa: true,
        analitica: true
      }
    ];

    setPlanoContas(mockPlanoContas);
  };

  // ----- Funções para Formas de Pagamento -----
  const loadFormasPagamento = async () => {
    // Simulando carregamento de dados
    const mockFormas = [
      {
        id: "fp1",
        nome: "Dinheiro",
        tipo: "dinheiro",
        ativa: true,
        padrao: true,
        dias_prazo: 0,
        taxa_percentual: 0,
        taxa_fixa: 0,
        permite_parcelamento: false,
        parcelas_maximo: 1,
        icone: "banknote",
        cor: "#4CAF50"
      },
      {
        id: "fp2",
        nome: "Cartão de Crédito",
        tipo: "cartao_credito",
        ativa: true,
        padrao: false,
        dias_prazo: 30,
        taxa_percentual: 2.5,
        taxa_fixa: 0.5,
        permite_parcelamento: true,
        parcelas_maximo: 12,
        icone: "credit-card",
        cor: "#2196F3"
      },
      {
        id: "fp3",
        nome: "Boleto Bancário",
        tipo: "boleto",
        ativa: true,
        padrao: false,
        dias_prazo: 3,
        taxa_percentual: 0,
        taxa_fixa: 3.8,
        permite_parcelamento: false,
        parcelas_maximo: 1,
        icone: "file-text",
        cor: "#FFC107"
      },
      {
        id: "fp4",
        nome: "PIX",
        tipo: "pix",
        ativa: true,
        padrao: false,
        dias_prazo: 0,
        taxa_percentual: 0,
        taxa_fixa: 0,
        permite_parcelamento: false,
        parcelas_maximo: 1,
        icone: "qr-code",
        cor: "#9C27B0"
      }
    ];

    setFormasPagamento(mockFormas);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Configurações Financeiras</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Gerencie centros de custo e outras configurações financeiras
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-2 md:grid-cols-3 w-full">
          <TabsTrigger value="centros">
            <Tag className="w-4 h-4 mr-2" />
            Centros de Custo
          </TabsTrigger>
          <TabsTrigger value="plano">
            <ClipboardList className="w-4 h-4 mr-2" />
            Plano de Contas
          </TabsTrigger>
          <TabsTrigger value="formas">
            <CreditCard className="w-4 h-4 mr-2" />
            Formas de Pagamento
          </TabsTrigger>
        </TabsList>

        {/* TAB: Centros de Custo */}
        <TabsContent value="centros" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Centros de Custo</CardTitle>
                <CardDescription>
                  Gerencie os centros de custo para classificar suas despesas e receitas
                </CardDescription>
              </div>
              <Button onClick={() => setShowAddCentroDialog(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Novo Centro de Custo
              </Button>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                </div>
              ) : centrosCusto.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 space-y-4">
                  <Tag className="h-12 w-12 text-gray-300" />
                  <p className="text-center text-gray-500 max-w-md">
                    Nenhum centro de custo cadastrado. Adicione centros de custo para classificar seus lançamentos financeiros.
                  </p>
                  <Button onClick={() => setShowAddCentroDialog(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Adicionar Centro de Custo
                  </Button>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Código</TableHead>
                      <TableHead>Nome</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Orçamento Anual</TableHead>
                      <TableHead>Responsável</TableHead>
                      <TableHead className="text-center">Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {centrosCusto.map((centro) => (
                      <TableRow key={centro.id}>
                        <TableCell className="font-mono">{centro.codigo}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: centro.cor || '#999' }}></div>
                            <span
                              className={`font-medium ${centro.nivel > 1 ? 'ml-' + (centro.nivel * 4) : ''}`}
                              style={{ marginLeft: (centro.nivel - 1) * 20 + 'px' }}
                            >
                              {centro.nome}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={centro.tipo === 'receita' ? 'success' : 'default'}>
                            {centro.tipo === 'receita' ? 'Receita' : centro.tipo === 'despesa' ? 'Despesa' : 'Ambos'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {centro.orcamento_anual ? (
                            `R$ ${centro.orcamento_anual.toFixed(2).replace('.', ',')}`
                          ) : (
                            <span className="text-gray-500">Não definido</span>
                          )}
                        </TableCell>
                        <TableCell>{centro.responsavel_nome || "-"}</TableCell>
                        <TableCell className="text-center">
                          {centro.ativo ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Ativo
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                              Inativo
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => {
                                setCentroSelecionado(centro);
                                setShowEditCentroDialog(true);
                              }}>
                                <Edit className="mr-2 h-4 w-4" />
                                <span>Editar</span>
                              </DropdownMenuItem>
                              
                              <DropdownMenuItem onClick={() => {
                                setShowAddCentroDialog(true);
                                // Pre-populate parent
                                // In a real implementation, you'd pre-populate the form
                              }}>
                                <Plus className="mr-2 h-4 w-4" />
                                <span>Adicionar Subcentro</span>
                              </DropdownMenuItem>
                              
                              <DropdownMenuItem onClick={() => {
                                // Toggle status
                                setCentrosCusto(prev => 
                                  prev.map(c => 
                                    c.id === centro.id 
                                      ? { ...c, ativo: !c.ativo } 
                                      : c
                                  )
                                );
                              }}>
                                {centro.ativo ? (
                                  <>
                                    <X className="mr-2 h-4 w-4" />
                                    <span>Desativar</span>
                                  </>
                                ) : (
                                  <>
                                    <Check className="mr-2 h-4 w-4" />
                                    <span>Ativar</span>
                                  </>
                                )}
                              </DropdownMenuItem>
                              
                              <DropdownMenuSeparator />
                              
                              <DropdownMenuItem 
                                className="text-red-600 dark:text-red-400"
                                onClick={() => {
                                  setCentroSelecionado(centro);
                                  setConfirmDeleteCentro(true);
                                }}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                <span>Excluir</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* TAB: Plano de Contas */}
        <TabsContent value="plano" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Plano de Contas</CardTitle>
                <CardDescription>
                  Gerencie o plano de contas contábil da sua organização
                </CardDescription>
              </div>
              <Button onClick={() => setShowAddPlanoDialog(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Nova Conta Contábil
              </Button>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                </div>
              ) : planoContas.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 space-y-4">
                  <ClipboardList className="h-12 w-12 text-gray-300" />
                  <p className="text-center text-gray-500 max-w-md">
                    Nenhuma conta contábil cadastrada. Configure seu plano de contas para organizar seus relatórios financeiros.
                  </p>
                  <Button onClick={() => setShowAddPlanoDialog(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Adicionar Conta Contábil
                  </Button>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Código</TableHead>
                      <TableHead>Nome</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Natureza</TableHead>
                      <TableHead>Analítica</TableHead>
                      <TableHead className="text-center">Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {planoContas.map((conta) => (
                      <TableRow key={conta.id}>
                        <TableCell className="font-mono">{conta.codigo}</TableCell>
                        <TableCell className="font-medium" style={{ paddingLeft: (conta.nivel - 1) * 20 + 16 + 'px' }}>
                          {conta.nome}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {conta.tipo === 'ativo' && 'Ativo'}
                            {conta.tipo === 'passivo' && 'Passivo'}
                            {conta.tipo === 'receita' && 'Receita'}
                            {conta.tipo === 'despesa' && 'Despesa'}
                            {conta.tipo === 'patrimonio_liquido' && 'Patrimônio Líquido'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={conta.natureza === 'devedora' ? 'default' : 'secondary'}>
                            {conta.natureza === 'devedora' ? 'Devedora' : 'Credora'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {conta.analitica ? (
                            <Check className="h-4 w-4 text-green-600" />
                          ) : (
                            <X className="h-4 w-4 text-gray-400" />
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          {conta.ativa ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Ativa
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                              Inativa
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => {
                                setContaContabilSelecionada(conta);
                                setShowEditPlanoDialog(true);
                              }}>
                                <Edit className="mr-2 h-4 w-4" />
                                <span>Editar</span>
                              </DropdownMenuItem>
                              
                              <DropdownMenuItem onClick={() => {
                                setShowAddPlanoDialog(true);
                                // Pre-populate parent
                              }}>
                                <Plus className="mr-2 h-4 w-4" />
                                <span>Adicionar Subconta</span>
                              </DropdownMenuItem>
                              
                              <DropdownMenuItem onClick={() => {
                                // Toggle status
                                setPlanoContas(prev => 
                                  prev.map(c => 
                                    c.id === conta.id 
                                      ? { ...c, ativa: !c.ativa } 
                                      : c
                                  )
                                );
                              }}>
                                {conta.ativa ? (
                                  <>
                                    <X className="mr-2 h-4 w-4" />
                                    <span>Desativar</span>
                                  </>
                                ) : (
                                  <>
                                    <Check className="mr-2 h-4 w-4" />
                                    <span>Ativar</span>
                                  </>
                                )}
                              </DropdownMenuItem>
                              
                              <DropdownMenuSeparator />
                              
                              <DropdownMenuItem 
                                className="text-red-600 dark:text-red-400"
                                onClick={() => {
                                  setContaContabilSelecionada(conta);
                                  setConfirmDeleteContaContabil(true);
                                }}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                <span>Excluir</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* TAB: Formas de Pagamento */}
        <TabsContent value="formas" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Formas de Pagamento</CardTitle>
                <CardDescription>
                  Configure as formas de pagamento disponíveis
                </CardDescription>
              </div>
              <Button onClick={() => setShowAddFormaDialog(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Nova Forma de Pagamento
              </Button>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                </div>
              ) : formasPagamento.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 space-y-4">
                  <CreditCard className="h-12 w-12 text-gray-300" />
                  <p className="text-center text-gray-500 max-w-md">
                    Nenhuma forma de pagamento cadastrada. Adicione formas de pagamento para registrar suas transações financeiras.
                  </p>
                  <Button onClick={() => setShowAddFormaDialog(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Adicionar Forma de Pagamento
                  </Button>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Prazo (dias)</TableHead>
                      <TableHead>Taxa</TableHead>
                      <TableHead>Parcelamento</TableHead>
                      <TableHead className="text-center">Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {formasPagamento.map((forma) => (
                      <TableRow key={forma.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-6 h-6 rounded-full flex items-center justify-center" 
                              style={{ backgroundColor: forma.cor || '#999' }}
                            >
                              {forma.tipo === 'dinheiro' && <DollarSign className="w-3 h-3 text-white" />}
                              {forma.tipo === 'cartao_credito' && <CreditCard className="w-3 h-3 text-white" />}
                              {forma.tipo === 'boleto' && <FileText className="w-3 h-3 text-white" />}
                              {forma.tipo === 'pix' && <Binary className="w-3 h-3 text-white" />}
                            </div>
                            {forma.nome}
                            {forma.padrao && (
                              <Badge variant="secondary" className="ml-1">Padrão</Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {forma.tipo === 'dinheiro' && 'Dinheiro'}
                            {forma.tipo === 'cartao_credito' && 'Cartão de Crédito'}
                            {forma.tipo === 'cartao_debito' && 'Cartão de Débito'}
                            {forma.tipo === 'boleto' && 'Boleto'}
                            {forma.tipo === 'pix' && 'PIX'}
                            {forma.tipo === 'transferencia' && 'Transferência'}
                            {forma.tipo === 'cheque' && 'Cheque'}
                            {forma.tipo === 'outro' && 'Outro'}
                          </Badge>
                        </TableCell>
                        <TableCell>{forma.dias_prazo || 0}</TableCell>
                        <TableCell>
                          {forma.taxa_percentual > 0 && `${forma.taxa_percentual}%`}
                          {forma.taxa_percentual > 0 && forma.taxa_fixa > 0 && ' + '}
                          {forma.taxa_fixa > 0 && `R$ ${forma.taxa_fixa.toFixed(2).replace('.', ',')}`}
                          {forma.taxa_percentual === 0 && forma.taxa_fixa === 0 && 'Sem taxa'}
                        </TableCell>
                        <TableCell>
                          {forma.permite_parcelamento ? (
                            `Até ${forma.parcelas_maximo}x`
                          ) : (
                            'Não permitido'
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          {forma.ativa ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Ativa
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                              Inativa
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => {
                                setFormaSelecionada(forma);
                                setShowEditFormaDialog(true);
                              }}>
                                <Edit className="mr-2 h-4 w-4" />
                                <span>Editar</span>
                              </DropdownMenuItem>
                              
                              {!forma.padrao && (
                                <DropdownMenuItem onClick={() => {
                                  // Set as default
                                  setFormasPagamento(prev => 
                                    prev.map(fp => ({
                                      ...fp,
                                      padrao: fp.id === forma.id
                                    }))
                                  );
                                }}>
                                  <Check className="mr-2 h-4 w-4" />
                                  <span>Definir como Padrão</span>
                                </DropdownMenuItem>
                              )}
                              
                              <DropdownMenuItem onClick={() => {
                                // Toggle status
                                setFormasPagamento(prev => 
                                  prev.map(fp => 
                                    fp.id === forma.id 
                                      ? { ...fp, ativa: !fp.ativa } 
                                      : fp
                                  )
                                );
                              }}>
                                {forma.ativa ? (
                                  <>
                                    <X className="mr-2 h-4 w-4" />
                                    <span>Desativar</span>
                                  </>
                                ) : (
                                  <>
                                    <Check className="mr-2 h-4 w-4" />
                                    <span>Ativar</span>
                                  </>
                                )}
                              </DropdownMenuItem>
                              
                              <DropdownMenuSeparator />
                              
                              <DropdownMenuItem 
                                className="text-red-600 dark:text-red-400"
                                onClick={() => {
                                  setFormaSelecionada(forma);
                                  setConfirmDeleteForma(true);
                                }}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                <span>Excluir</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}