import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ShoppingCart, 
  Save, 
  X, 
  Calendar, 
  User, 
  CreditCard, 
  Truck, 
  MapPin, 
  Package, 
  BadgePlus,
  BarChart4,
  FileText,
  Clock,
  ChevronLeft,
  ChevronRight,
  Check,
  AlertTriangle,
  ShoppingBag,
  Loader2,
  Tag,
  Trash2
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";

export default function EditarPedido() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showAddProduto, setShowAddProduto] = useState(false);
  
  // Get pedido ID from URL
  const urlParams = new URLSearchParams(location.search);
  const pedidoId = urlParams.get('id');
  
  // Estado para o pedido
  const [pedido, setPedido] = useState({
    id: "",
    numero_pedido: "",
    status: "pendente",
    data_pedido: "",
    cliente: {
      id: "",
      nome: "",
      email: "",
      telefone: ""
    },
    forma_pagamento: "pix",
    endereco_entrega: {
      cep: "",
      logradouro: "",
      numero: "",
      complemento: "",
      bairro: "",
      cidade: "",
      estado: ""
    },
    frete: {
      metodo: "sedex",
      valor: 0,
      prazo: "",
      codigo_rastreio: ""
    },
    itens: [],
    subtotal: 0,
    desconto: 0,
    total: 0,
    observacoes: "",
    prescricao_id: "",
    historico: []
  });
  
  // Estado para novo item sendo adicionado
  const [novoItem, setNovoItem] = useState({
    produto_id: "",
    quantidade: 1
  });
  
  // Mock data
  const mockClientes = [
    { id: "cli1", nome: "Maria Silva", email: "maria@email.com", telefone: "(11) 98765-4321" },
    { id: "cli2", nome: "João Oliveira", email: "joao@email.com", telefone: "(11) 97654-3210" },
    { id: "cli3", nome: "Ana Souza", email: "ana@email.com", telefone: "(21) 99876-5432" }
  ];
  
  const mockProdutos = [
    { 
      id: "prod1", 
      nome: "Óleo de CBD 5%", 
      preco: 250.00, 
      estoque: 50,
      tipo: "óleo",
      concentracao: "5%",
      volume: "30ml",
      imagem_url: "https://images.unsplash.com/photo-1618014160361-bf15fdc18755?q=80&w=150"
    },
    { 
      id: "prod2", 
      nome: "Óleo de CBD 10%", 
      preco: 350.00, 
      estoque: 35,
      tipo: "óleo",
      concentracao: "10%",
      volume: "30ml",
      imagem_url: "https://images.unsplash.com/photo-1618014144694-6c19e7028929?q=80&w=150"
    },
    { 
      id: "prod3", 
      nome: "Cápsulas de CBD 25mg", 
      preco: 180.00, 
      estoque: 100,
      tipo: "cápsula",
      concentracao: "25mg",
      quantidade: "30 cápsulas",
      imagem_url: "https://images.unsplash.com/photo-1584367369853-8b966cf223f4?q=80&w=150"
    },
    { 
      id: "prod4", 
      nome: "Pomada de CBD 200mg", 
      preco: 120.00, 
      estoque: 45,
      tipo: "tópico",
      concentracao: "200mg",
      volume: "60g",
      imagem_url: "https://images.unsplash.com/photo-1623000221315-13a3a7833969?q=80&w=150"
    }
  ];
  
  const mockPrescricoes = [
    { id: "presc1", doctor_name: "Dr. Carlos Santos", patient_id: "cli1", data: "2023-10-15" },
    { id: "presc2", doctor_name: "Dra. Ana Costa", patient_id: "cli2", data: "2023-11-05" },
    { id: "presc3", doctor_name: "Dr. Mario Oliveira", patient_id: "cli3", data: "2023-10-22" }
  ];
  
  useEffect(() => {
    // Load pedido data
    if (pedidoId) {
      setIsLoading(true);
      
      // Simulate API call
      setTimeout(() => {
        // Mock data de um pedido existente
        const mockPedido = {
          id: "ped1",
          numero_pedido: "PED-2023-001",
          status: "em_processamento",
          data_pedido: "2023-11-10T14:30:00Z",
          cliente: mockClientes[0],
          forma_pagamento: "pix",
          endereco_entrega: {
            cep: "01310-200",
            logradouro: "Avenida Paulista",
            numero: "1000",
            complemento: "Apto 123",
            bairro: "Bela Vista",
            cidade: "São Paulo",
            estado: "SP"
          },
          frete: {
            metodo: "sedex",
            valor: 25.50,
            prazo: "3 dias úteis",
            codigo_rastreio: ""
          },
          itens: [
            {
              id: "item1",
              produto_id: "prod1",
              produto: mockProdutos[0],
              quantidade: 2,
              preco_unitario: mockProdutos[0].preco,
              subtotal: mockProdutos[0].preco * 2
            }
          ],
          subtotal: mockProdutos[0].preco * 2,
          desconto: 0,
          total: (mockProdutos[0].preco * 2) + 25.50,
          observacoes: "Cliente pediu para entregar no período da tarde",
          prescricao_id: "presc1",
          historico: [
            {
              data: "2023-11-10T14:30:00Z",
              usuario: "Maria (cliente)",
              tipo: "criacao",
              descricao: "Pedido criado"
            },
            {
              data: "2023-11-10T15:45:00Z",
              usuario: "Sistema",
              tipo: "pagamento",
              descricao: "Pagamento via PIX confirmado"
            },
            {
              data: "2023-11-11T09:20:00Z",
              usuario: "Carlos Santos",
              tipo: "status",
              descricao: "Status atualizado para Em Processamento"
            }
          ]
        };
        
        setPedido(mockPedido);
        setIsLoading(false);
      }, 1500);
    } else {
      // Redirect back to list if no ID provided
      navigate(createPageUrl("Pedidos"));
    }
  }, [pedidoId, navigate]);
  
  // Calculate price values
  useEffect(() => {
    const subtotal = pedido.itens.reduce((total, item) => total + item.subtotal, 0);
    const total = subtotal - pedido.desconto + (pedido.frete?.valor || 0);
    
    setPedido(prev => ({
      ...prev,
      subtotal,
      total
    }));
  }, [pedido.itens, pedido.desconto, pedido.frete]);
  
  const handlePedidoChange = (e) => {
    const { name, value } = e.target;
    setPedido(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleAddressChange = (e) => {
    const { name, value } = e.target;
    setPedido(prev => ({
      ...prev,
      endereco_entrega: {
        ...prev.endereco_entrega,
        [name]: value
      }
    }));
  };
  
  const handleFreteChange = (e) => {
    const { name, value } = e.target;
    setPedido(prev => ({
      ...prev,
      frete: {
        ...prev.frete,
        [name]: value
      }
    }));
  };
  
  const handleSelectChange = (field, value) => {
    if (field === "cliente") {
      const cliente = mockClientes.find(c => c.id === value);
      setPedido(prev => ({
        ...prev,
        cliente
      }));
    } else if (field === "forma_pagamento") {
      setPedido(prev => ({
        ...prev,
        forma_pagamento: value
      }));
    } else if (field === "metodo") {
      setPedido(prev => ({
        ...prev,
        frete: {
          ...prev.frete,
          metodo: value
        }
      }));
    } else if (field === "status") {
      setPedido(prev => ({
        ...prev,
        status: value
      }));
      
      // Add to history
      const newHistoryEntry = {
        data: new Date().toISOString(),
        usuario: "Administrador",
        tipo: "status",
        descricao: `Status atualizado para ${getStatusLabel(value)}`
      };
      
      setPedido(prev => ({
        ...prev,
        historico: [...prev.historico, newHistoryEntry]
      }));
    } else if (field === "prescricao_id") {
      setPedido(prev => ({
        ...prev,
        prescricao_id: value
      }));
    }
  };
  
  const handleNovoItemChange = (e) => {
    const { name, value } = e.target;
    setNovoItem(prev => ({
      ...prev,
      [name]: name === "quantidade" ? parseInt(value) : value
    }));
  };
  
  const handleSelectProduto = (produtoId) => {
    setNovoItem(prev => ({
      ...prev,
      produto_id: produtoId
    }));
  };
  
  const handleAddProduto = () => {
    if (!novoItem.produto_id || novoItem.quantidade < 1) {
      toast({
        title: "Erro ao adicionar produto",
        description: "Selecione um produto e informe uma quantidade válida",
        variant: "destructive"
      });
      return;
    }
    
    const produto = mockProdutos.find(p => p.id === novoItem.produto_id);
    if (!produto) {
      toast({
        title: "Produto não encontrado",
        description: "O produto selecionado não está disponível",
        variant: "destructive"
      });
      return;
    }
    
    // Check if product already exists in order
    const existingItemIndex = pedido.itens.findIndex(item => item.produto_id === novoItem.produto_id);
    
    if (existingItemIndex >= 0) {
      // Update quantity of existing item
      const updatedItens = [...pedido.itens];
      const newQuantity = updatedItens[existingItemIndex].quantidade + novoItem.quantidade;
      
      if (newQuantity > produto.estoque) {
        toast({
          title: "Quantidade excede estoque",
          description: `Há apenas ${produto.estoque} unidades disponíveis deste produto`,
          variant: "destructive"
        });
        return;
      }
      
      updatedItens[existingItemIndex] = {
        ...updatedItens[existingItemIndex],
        quantidade: newQuantity,
        subtotal: produto.preco * newQuantity
      };
      
      setPedido(prev => ({
        ...prev,
        itens: updatedItens
      }));
      
      toast({
        title: "Produto atualizado",
        description: `Quantidade de ${produto.nome} atualizada no pedido`
      });
    } else {
      // Add new product
      if (novoItem.quantidade > produto.estoque) {
        toast({
          title: "Quantidade excede estoque",
          description: `Há apenas ${produto.estoque} unidades disponíveis deste produto`,
          variant: "destructive"
        });
        return;
      }
      
      const newItem = {
        id: `item${Date.now()}`,
        produto_id: produto.id,
        produto,
        quantidade: novoItem.quantidade,
        preco_unitario: produto.preco,
        subtotal: produto.preco * novoItem.quantidade
      };
      
      setPedido(prev => ({
        ...prev,
        itens: [...prev.itens, newItem]
      }));
      
      toast({
        title: "Produto adicionado",
        description: `${produto.nome} adicionado ao pedido`
      });
    }
    
    // Reset form and close dialog
    setNovoItem({
      produto_id: "",
      quantidade: 1
    });
    setShowAddProduto(false);
  };
  
  const handleRemoveItem = (itemId) => {
    setPedido(prev => ({
      ...prev,
      itens: prev.itens.filter(item => item.id !== itemId)
    }));
    
    toast({
      title: "Produto removido",
      description: "Produto removido do pedido"
    });
  };
  
  const handleUpdateItemQuantity = (itemId, newQuantity) => {
    if (newQuantity < 1) {
      handleRemoveItem(itemId);
      return;
    }
    
    const item = pedido.itens.find(item => item.id === itemId);
    if (!item) return;
    
    const produto = mockProdutos.find(p => p.id === item.produto_id);
    if (!produto) return;
    
    if (newQuantity > produto.estoque) {
      toast({
        title: "Quantidade excede estoque",
        description: `Há apenas ${produto.estoque} unidades disponíveis deste produto`,
        variant: "destructive"
      });
      return;
    }
    
    const updatedItens = pedido.itens.map(item => {
      if (item.id === itemId) {
        return {
          ...item,
          quantidade: newQuantity,
          subtotal: item.preco_unitario * newQuantity
        };
      }
      return item;
    });
    
    setPedido(prev => ({
      ...prev,
      itens: updatedItens
    }));
  };
  
  const handleSave = () => {
    if (pedido.itens.length === 0) {
      toast({
        title: "Pedido sem produtos",
        description: "Adicione pelo menos um produto ao pedido",
        variant: "destructive"
      });
      return;
    }
    
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      
      toast({
        title: "Pedido atualizado",
        description: `Pedido ${pedido.numero_pedido} atualizado com sucesso`
      });
      
      navigate(createPageUrl("Pedidos"));
    }, 1500);
  };
  
  const getStatusLabel = (status) => {
    const statusMap = {
      "pendente": "Pendente",
      "aguardando_pagamento": "Aguardando Pagamento",
      "pagamento_confirmado": "Pagamento Confirmado",
      "em_processamento": "Em Processamento",
      "enviado": "Enviado",
      "entregue": "Entregue",
      "cancelado": "Cancelado",
      "estornado": "Estornado"
    };
    
    return statusMap[status] || status;
  };
  
  const getStatusBadge = (status) => {
    const statusClasses = {
      "pendente": "bg-gray-100 text-gray-800 border-gray-200",
      "aguardando_pagamento": "bg-blue-100 text-blue-800 border-blue-200",
      "pagamento_confirmado": "bg-emerald-100 text-emerald-800 border-emerald-200",
      "em_processamento": "bg-amber-100 text-amber-800 border-amber-200",
      "enviado": "bg-indigo-100 text-indigo-800 border-indigo-200",
      "entregue": "bg-green-100 text-green-800 border-green-200",
      "cancelado": "bg-red-100 text-red-800 border-red-200",
      "estornado": "bg-purple-100 text-purple-800 border-purple-200"
    };
    
    return (
      <Badge variant="outline" className={statusClasses[status] || ""}>
        {getStatusLabel(status)}
      </Badge>
    );
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-green-600" />
          <p className="text-sm text-gray-500">Carregando dados do pedido...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <Breadcrumb className="mb-4">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href={createPageUrl("VendasDashboard")}>Vendas</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink href={createPageUrl("Pedidos")}>Pedidos</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink>Editar Pedido</BreadcrumbLink>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Editar Pedido {pedido.numero_pedido}</h1>
            <p className="text-gray-500 mt-1">
              Atualize os detalhes do pedido e os produtos incluídos
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              className="gap-2"
              onClick={() => navigate(createPageUrl("Pedidos"))}
            >
              <X className="h-4 w-4" />
              Cancelar
            </Button>
            
            <Button 
              variant="default" 
              className="gap-2"
              onClick={handleSave}
              disabled={isSaving}
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  Salvar Alterações
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Status Card */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Status do Pedido</CardTitle>
            </CardHeader>
            <CardContent>
              <Select
                value={pedido.status}
                onValueChange={(value) => handleSelectChange("status", value)}
              >
                <SelectTrigger className="w-full sm:w-72">
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pendente">Pendente</SelectItem>
                  <SelectItem value="aguardando_pagamento">Aguardando Pagamento</SelectItem>
                  <SelectItem value="pagamento_confirmado">Pagamento Confirmado</SelectItem>
                  <SelectItem value="em_processamento">Em Processamento</SelectItem>
                  <SelectItem value="enviado">Enviado</SelectItem>
                  <SelectItem value="entregue">Entregue</SelectItem>
                  <SelectItem value="cancelado">Cancelado</SelectItem>
                  <SelectItem value="estornado">Estornado</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
          
          {/* Cliente Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Cliente</CardTitle>
              <CardDescription>
                Informações do cliente que realizou o pedido
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cliente">Cliente</Label>
                  <Select
                    value={pedido.cliente.id}
                    onValueChange={(value) => handleSelectChange("cliente", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o cliente" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockClientes.map(cliente => (
                        <SelectItem key={cliente.id} value={cliente.id}>
                          {cliente.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="prescricao_id">Prescrição</Label>
                  <Select
                    value={pedido.prescricao_id}
                    onValueChange={(value) => handleSelectChange("prescricao_id", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a prescrição" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Nenhuma prescrição</SelectItem>
                      {mockPrescricoes
                        .filter(p => p.patient_id === pedido.cliente.id)
                        .map(prescricao => (
                          <SelectItem key={prescricao.id} value={prescricao.id}>
                            {prescricao.doctor_name} - {new Date(prescricao.data).toLocaleDateString()}
                          </SelectItem>
                        ))
                      }
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    value={pedido.cliente.email}
                    disabled
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone</Label>
                  <Input
                    id="telefone"
                    value={pedido.cliente.telefone}
                    disabled
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Produtos Card */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-lg">Produtos</CardTitle>
                  <CardDescription>
                    Produtos incluídos no pedido
                  </CardDescription>
                </div>
                
                <Button 
                  onClick={() => setShowAddProduto(true)}
                  className="gap-2"
                >
                  <BadgePlus className="h-4 w-4" />
                  Adicionar Produto
                </Button>
                
                <Dialog open={showAddProduto} onOpenChange={setShowAddProduto}>
                  <DialogContent className="max-w-3xl">
                    <DialogHeader>
                      <DialogTitle>Adicionar Produto ao Pedido</DialogTitle>
                      <DialogDescription>
                        Selecione o produto e informe a quantidade desejada
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="produto_id">Produto</Label>
                          <Select
                            value={novoItem.produto_id}
                            onValueChange={(value) => handleSelectProduto(value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione um produto" />
                            </SelectTrigger>
                            <SelectContent>
                              {mockProdutos.map(produto => (
                                <SelectItem key={produto.id} value={produto.id}>
                                  {produto.nome}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="quantidade">Quantidade</Label>
                          <Input
                            id="quantidade"
                            name="quantidade"
                            type="number"
                            min="1"
                            value={novoItem.quantidade}
                            onChange={handleNovoItemChange}
                          />
                        </div>
                      </div>
                      
                      {novoItem.produto_id && (
                        <div className="border rounded-lg p-4 space-y-3">
                          <div className="flex items-center gap-3">
                            {mockProdutos.find(p => p.id === novoItem.produto_id)?.imagem_url && (
                              <img 
                                src={mockProdutos.find(p => p.id === novoItem.produto_id)?.imagem_url} 
                                alt={mockProdutos.find(p => p.id === novoItem.produto_id)?.nome}
                                className="w-16 h-16 object-cover rounded-md"
                              />
                            )}
                            
                            <div>
                              <h3 className="font-medium">
                                {mockProdutos.find(p => p.id === novoItem.produto_id)?.nome}
                              </h3>
                              <div className="flex gap-2 mt-1">
                                <Badge variant="outline" className="bg-gray-50">
                                  {mockProdutos.find(p => p.id === novoItem.produto_id)?.concentracao}
                                </Badge>
                                <Badge variant="outline" className="bg-gray-50">
                                  {mockProdutos.find(p => p.id === novoItem.produto_id)?.volume || 
                                   mockProdutos.find(p => p.id === novoItem.produto_id)?.quantidade}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex justify-between text-sm text-gray-500">
                            <span>Preço:</span>
                            <span className="font-medium text-black">
                              {formatCurrency(mockProdutos.find(p => p.id === novoItem.produto_id)?.preco || 0)}
                            </span>
                          </div>
                          
                          <div className="flex justify-between text-sm text-gray-500">
                            <span>Estoque:</span>
                            <span className="font-medium text-black">
                              {mockProdutos.find(p => p.id === novoItem.produto_id)?.estoque || 0} un
                            </span>
                          </div>
                          
                          <div className="flex justify-between text-sm text-gray-500">
                            <span>Subtotal:</span>
                            <span className="font-medium text-black">
                              {formatCurrency((mockProdutos.find(p => p.id === novoItem.produto_id)?.preco || 0) * 
                                (novoItem.quantidade || 0))}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setShowAddProduto(false)}>
                        Cancelar
                      </Button>
                      <Button onClick={handleAddProduto}>
                        Adicionar ao Pedido
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-md overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50%]">Produto</TableHead>
                      <TableHead className="text-center">Qtd.</TableHead>
                      <TableHead className="text-right">Preço Un.</TableHead>
                      <TableHead className="text-right">Subtotal</TableHead>
                      <TableHead className="w-[80px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pedido.itens.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-6 text-gray-500">
                          Nenhum produto adicionado ao pedido
                        </TableCell>
                      </TableRow>
                    ) : (
                      pedido.itens.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              {item.produto.imagem_url && (
                                <img 
                                  src={item.produto.imagem_url} 
                                  alt={item.produto.nome}
                                  className="w-10 h-10 object-cover rounded-md"
                                />
                              )}
                              <div>
                                <div className="font-medium">{item.produto.nome}</div>
                                <div className="text-xs text-gray-500">{item.produto.concentracao} • {item.produto.volume || item.produto.quantidade}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex items-center justify-center">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => handleUpdateItemQuantity(item.id, item.quantidade - 1)}
                              >
                                <ChevronLeft className="h-3 w-3" />
                              </Button>
                              <span className="mx-2 min-w-[30px] text-center">{item.quantidade}</span>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => handleUpdateItemQuantity(item.id, item.quantidade + 1)}
                              >
                                <ChevronRight className="h-3 w-3" />
                              </Button>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            {formatCurrency(item.preco_unitario)}
                          </TableCell>
                          <TableCell className="text-right">
                            {formatCurrency(item.subtotal)}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => handleRemoveItem(item.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
          
          {/* Entrega e Pagamento */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Endereço de Entrega</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="cep">CEP</Label>
                    <Input
                      id="cep"
                      name="cep"
                      value={pedido.endereco_entrega.cep}
                      onChange={handleAddressChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="estado">Estado</Label>
                    <Input
                      id="estado"
                      name="estado"
                      value={pedido.endereco_entrega.estado}
                      onChange={handleAddressChange}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="logradouro">Logradouro</Label>
                  <Input
                    id="logradouro"
                    name="logradouro"
                    value={pedido.endereco_entrega.logradouro}
                    onChange={handleAddressChange}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="numero">Número</Label>
                    <Input
                      id="numero"
                      name="numero"
                      value={pedido.endereco_entrega.numero}
                      onChange={handleAddressChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="complemento">Complemento</Label>
                    <Input
                      id="complemento"
                      name="complemento"
                      value={pedido.endereco_entrega.complemento}
                      onChange={handleAddressChange}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="bairro">Bairro</Label>
                    <Input
                      id="bairro"
                      name="bairro"
                      value={pedido.endereco_entrega.bairro}
                      onChange={handleAddressChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="cidade">Cidade</Label>
                    <Input
                      id="cidade"
                      name="cidade"
                      value={pedido.endereco_entrega.cidade}
                      onChange={handleAddressChange}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Pagamento e Envio</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="forma_pagamento">Forma de Pagamento</Label>
                  <Select
                    value={pedido.forma_pagamento}
                    onValueChange={(value) => handleSelectChange("forma_pagamento", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a forma de pagamento" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pix">PIX</SelectItem>
                      <SelectItem value="cartao_credito">Cartão de Crédito</SelectItem>
                      <SelectItem value="boleto">Boleto Bancário</SelectItem>
                      <SelectItem value="transferencia">Transferência Bancária</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Separator className="my-2" />
                
                <div className="space-y-2">
                  <Label htmlFor="metodo">Método de Envio</Label>
                  <Select
                    value={pedido.frete.metodo}
                    onValueChange={(value) => handleSelectChange("metodo", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o método de envio" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedex">SEDEX</SelectItem>
                      <SelectItem value="pac">PAC</SelectItem>
                      <SelectItem value="transportadora">Transportadora</SelectItem>
                      <SelectItem value="retirada">Retirada na Loja</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="valor">Valor do Frete</Label>
                    <Input
                      id="valor"
                      name="valor"
                      type="number"
                      min="0"
                      step="0.01"
                      value={pedido.frete.valor}
                      onChange={(e) => handleFreteChange({
                        ...e,
                        target: {
                          ...e.target,
                          value: parseFloat(e.target.value) || 0
                        }
                      })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="prazo">Prazo de Entrega</Label>
                    <Input
                      id="prazo"
                      name="prazo"
                      value={pedido.frete.prazo}
                      onChange={handleFreteChange}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="codigo_rastreio">Código de Rastreio</Label>
                  <div className="flex gap-2">
                    <Input
                      id="codigo_rastreio"
                      name="codigo_rastreio"
                      value={pedido.frete.codigo_rastreio}
                      onChange={handleFreteChange}
                      placeholder="Digite o código de rastreio"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="desconto">Desconto</Label>
                  <Input
                    id="desconto"
                    name="desconto"
                    type="number"
                    min="0"
                    step="0.01"
                    value={pedido.desconto}
                    onChange={(e) => handlePedidoChange({
                      ...e,
                      target: {
                        ...e.target,
                        value: parseFloat(e.target.value) || 0
                      }
                    })}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Observações */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Observações</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                name="observacoes"
                value={pedido.observacoes}
                onChange={handlePedidoChange}
                placeholder="Observações adicionais sobre o pedido"
                rows={3}
              />
            </CardContent>
          </Card>
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Summary Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Resumo do Pedido</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center py-2">
                <span className="text-sm text-gray-500">Data do Pedido:</span>
                <span className="font-medium">{formatDate(pedido.data_pedido)}</span>
              </div>
              
              <div className="flex justify-between items-center py-2">
                <span className="text-sm text-gray-500">Número do Pedido:</span>
                <span className="font-medium">{pedido.numero_pedido}</span>
              </div>
              
              <div className="flex justify-between items-center py-2">
                <span className="text-sm text-gray-500">Status:</span>
                <span>{getStatusBadge(pedido.status)}</span>
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal:</span>
                  <span className="font-medium">{formatCurrency(pedido.subtotal)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-600">Frete:</span>
                  <span className="font-medium">{formatCurrency(pedido.frete?.valor || 0)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-600">Desconto:</span>
                  <span className="font-medium">- {formatCurrency(pedido.desconto)}</span>
                </div>
                
                <Separator />
                
                <div className="flex justify-between">
                  <span className="font-medium">Total:</span>
                  <span className="font-bold text-lg">{formatCurrency(pedido.total)}</span>
                </div>
              </div>
              
              <div className="pt-4">
                <div className="rounded-md p-3 bg-amber-50 border border-amber-100 text-amber-800 text-sm flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 mt-0.5" />
                  <div>
                    <p>Alterações nos valores do pedido podem exigir ajustes no pagamento.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Histórico Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Histórico do Pedido</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pedido.historico.map((evento, index) => (
                  <div key={index} className="flex gap-3">
                    <div className="relative mt-0.5">
                      <div className="h-6 w-6 rounded-full bg-gray-100 flex items-center justify-center">
                        {evento.tipo === "criacao" && <ShoppingCart className="h-3 w-3 text-blue-600" />}
                        {evento.tipo === "status" && <Check className="h-3 w-3 text-green-600" />}
                        {evento.tipo === "pagamento" && <CreditCard className="h-3 w-3 text-purple-600" />}
                      </div>
                      {index < pedido.historico.length - 1 && (
                        <div className="absolute left-1/2 top-6 bottom-0 w-px -ml-px h-full bg-gray-200"></div>
                      )}
                    </div>
                    
                    <div className="pb-5">
                      <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3">
                        <p className="text-sm font-medium">{evento.descricao}</p>
                        <span className="text-xs text-gray-500">{formatDate(evento.data)}</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {evento.usuario}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}