
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Organization } from '@/api/entities';
import { ModuloDispensario } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { toast } from '@/components/ui/use-toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Package,
  ShoppingBag,
  FileText,
  Check,
  X,
  Settings,
  RefreshCw,
  Plus,
  Edit,
  DollarSign,
  Calendar,
  BarChart,
  Search,
  Filter,
  Download,
  AlertTriangle,
  ArchiveIcon
} from 'lucide-react';
import { format } from 'date-fns';

const superAdminMenuSections = [
  {
    title: "MÓDULOS",
    items: [
      { icon: ShoppingBag, label: 'Dispensário', path: 'AdminModuloDispensario' }
    ]
  },
];

export default function AdminModuloDispensario() {
  const navigate = useNavigate();
  const [organizations, setOrganizations] = useState([]);
  const [moduleInstances, setModuleInstances] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedOrganization, setSelectedOrganization] = useState('');
  const [trialPeriod, setTrialPeriod] = useState(30);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch organizations
        const orgs = await Organization.list();
        setOrganizations(orgs);
        
        // Fetch dispensario module instances
        const modules = await ModuloDispensario.list();
        setModuleInstances(modules);
        
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          title: 'Erro',
          description: 'Falha ao carregar dados. Por favor, tente novamente.',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);

  const filteredModules = moduleInstances.filter(module => {
    // Find associated organization
    const org = organizations.find(o => o.id === module.organization_id);
    if (!org) return false;
    
    // Apply search filter
    const searchMatch = 
      org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (org.contact_email && org.contact_email.toLowerCase().includes(searchTerm.toLowerCase()));
      
    // Apply status filter
    const statusMatch = 
      filterStatus === 'all' || 
      (filterStatus === 'active' && module.is_active) ||
      (filterStatus === 'inactive' && !module.is_active);
      
    // Apply type filter
    const typeMatch = 
      filterType === 'all' || 
      (org.type && org.type.toLowerCase() === filterType.toLowerCase());
      
    return searchMatch && statusMatch && typeMatch;
  });
  
  const handleAddModule = async () => {
    if (!selectedOrganization) {
      toast({
        title: 'Erro',
        description: 'Selecione uma organização.',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      const now = new Date();
      const endDate = new Date();
      endDate.setDate(now.getDate() + trialPeriod);
      
      // Create module instance
      await ModuloDispensario.create({
        organization_id: selectedOrganization,
        is_active: true,
        subscription_start: now.toISOString(),
        subscription_end: endDate.toISOString(),
        status: 'trial'
      });
      
      // Refresh data
      const modules = await ModuloDispensario.list();
      setModuleInstances(modules);
      
      toast({
        title: 'Sucesso',
        description: 'Módulo Dispensário adicionado com sucesso.',
      });
      
      setIsAddDialogOpen(false);
      setSelectedOrganization('');
      setTrialPeriod(30);
      
    } catch (error) {
      console.error('Error adding module:', error);
      toast({
        title: 'Erro',
        description: 'Falha ao adicionar módulo. Por favor, tente novamente.',
        variant: 'destructive',
      });
    }
  };
  
  const handleToggleStatus = async (moduleId, currentStatus) => {
    try {
      await ModuloDispensario.update(moduleId, { is_active: !currentStatus });
      
      // Refresh data
      const modules = await ModuloDispensario.list();
      setModuleInstances(modules);
      
      toast({
        title: 'Sucesso',
        description: `Módulo ${!currentStatus ? 'ativado' : 'desativado'} com sucesso.`,
      });
      
    } catch (error) {
      console.error('Error toggling module status:', error);
      toast({
        title: 'Erro',
        description: 'Falha ao alterar status do módulo. Por favor, tente novamente.',
        variant: 'destructive',
      });
    }
  };
  
  const handleExtendSubscription = async (moduleId, months) => {
    try {
      const module = moduleInstances.find(m => m.id === moduleId);
      if (!module) return;
      
      const currentEnd = module.subscription_end ? new Date(module.subscription_end) : new Date();
      const newEnd = new Date(currentEnd);
      newEnd.setMonth(newEnd.getMonth() + months);
      
      await ModuloDispensario.update(moduleId, { 
        subscription_end: newEnd.toISOString(),
        status: 'active',
        last_payment: new Date().toISOString()
      });
      
      // Refresh data
      const modules = await ModuloDispensario.list();
      setModuleInstances(modules);
      
      toast({
        title: 'Sucesso',
        description: `Assinatura estendida por ${months} ${months === 1 ? 'mês' : 'meses'}.`,
      });
      
    } catch (error) {
      console.error('Error extending subscription:', error);
      toast({
        title: 'Erro',
        description: 'Falha ao estender assinatura. Por favor, tente novamente.',
        variant: 'destructive',
      });
    }
  };

  const getEligibleOrganizations = () => {
    // Organizations without the module already
    const orgIds = moduleInstances.map(m => m.organization_id);
    return organizations.filter(org => !orgIds.includes(org.id));
  };
  
  const getSubscriptionStatus = (module) => {
    if (!module.is_active) return 'Inativo';
    
    if (module.status === 'trial') {
      return 'Período de Teste';
    }
    
    const endDate = module.subscription_end ? new Date(module.subscription_end) : null;
    if (!endDate) return 'Ativo';
    
    const now = new Date();
    const daysRemaining = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));
    
    if (daysRemaining < 0) return 'Expirado';
    if (daysRemaining <= 15) return `Expira em ${daysRemaining} dias`;
    return 'Ativo';
  };
  
  const getStatusColor = (status) => {
    if (status === 'Inativo' || status === 'Expirado') return 'text-red-500';
    if (status.includes('Expira em')) return 'text-amber-500';
    if (status === 'Período de Teste') return 'text-blue-500';
    return 'text-green-500';
  };

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Gerenciar Módulo Dispensário</h1>
          <p className="text-gray-500">
            Controle as organizações que têm acesso ao módulo de Dispensário
          </p>
        </div>
        
        <Button 
          onClick={() => setIsAddDialogOpen(true)}
          className="bg-green-600 hover:bg-green-700"
        >
          <Plus className="mr-2 h-4 w-4" />
          Ativar Novo Módulo
        </Button>
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Visão Geral do Módulo</CardTitle>
          <CardDescription>
            O módulo de Dispensário permite às organizações operar como uma farmácia com PDV para dispensação de medicamentos.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-blue-900">Total de Licenças</p>
                  <p className="text-2xl font-bold text-blue-700">{moduleInstances.length}</p>
                </div>
                <ShoppingBag className="h-8 w-8 text-blue-500" />
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-green-900">Licenças Ativas</p>
                  <p className="text-2xl font-bold text-green-700">
                    {moduleInstances.filter(m => m.is_active).length}
                  </p>
                </div>
                <Check className="h-8 w-8 text-green-500" />
              </div>
            </div>
            
            <div className="bg-amber-50 p-4 rounded-lg">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-amber-900">Em Período de Teste</p>
                  <p className="text-2xl font-bold text-amber-700">
                    {moduleInstances.filter(m => m.is_active && m.status === 'trial').length}
                  </p>
                </div>
                <Calendar className="h-8 w-8 text-amber-500" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Buscar por organização..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filtrar por status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os status</SelectItem>
            <SelectItem value="active">Ativos</SelectItem>
            <SelectItem value="inactive">Inativos</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filtrar por tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os tipos</SelectItem>
            <SelectItem value="empresa">Empresas</SelectItem>
            <SelectItem value="associação">Associações</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Organização</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Início</TableHead>
                <TableHead>Término</TableHead>
                <TableHead>Preço Mensal</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-10">
                    <div className="flex justify-center">
                      <div className="h-8 w-8 animate-spin rounded-full border-4 border-gray-200 border-t-blue-600"></div>
                    </div>
                    <p className="mt-2 text-sm text-gray-500">Carregando...</p>
                  </TableCell>
                </TableRow>
              ) : filteredModules.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-10">
                    <p className="text-gray-500">Nenhum módulo Dispensário encontrado</p>
                  </TableCell>
                </TableRow>
              ) : (
                filteredModules.map(module => {
                  const org = organizations.find(o => o.id === module.organization_id);
                  const statusText = getSubscriptionStatus(module);
                  const statusColor = getStatusColor(statusText);
                  
                  return (
                    <TableRow key={module.id}>
                      <TableCell className="font-medium">{org?.name || 'Organização desconhecida'}</TableCell>
                      <TableCell>{org?.type || '-'}</TableCell>
                      <TableCell>
                        <span className={statusColor}>{statusText}</span>
                      </TableCell>
                      <TableCell>
                        {module.subscription_start 
                          ? format(new Date(module.subscription_start), 'dd/MM/yyyy')
                          : '-'}
                      </TableCell>
                      <TableCell>
                        {module.subscription_end 
                          ? format(new Date(module.subscription_end), 'dd/MM/yyyy')
                          : '-'}
                      </TableCell>
                      <TableCell>R$ 299,00</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant={module.is_active ? "destructive" : "default"}
                            size="sm"
                            onClick={() => handleToggleStatus(module.id, module.is_active)}
                          >
                            {module.is_active ? 'Desativar' : 'Ativar'}
                          </Button>
                          
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <DollarSign className="h-4 w-4 mr-1" />
                                Renovar
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Renovar Assinatura</DialogTitle>
                                <DialogDescription>
                                  Escolha por quanto tempo deseja estender a assinatura da organização {org?.name}.
                                </DialogDescription>
                              </DialogHeader>
                              <div className="grid grid-cols-2 gap-4 py-4">
                                <Button onClick={() => handleExtendSubscription(module.id, 1)}>
                                  1 mês (R$ 299,00)
                                </Button>
                                <Button onClick={() => handleExtendSubscription(module.id, 6)}>
                                  6 meses (R$ 1.794,00)
                                </Button>
                                <Button onClick={() => handleExtendSubscription(module.id, 3)}>
                                  3 meses (R$ 897,00)
                                </Button>
                                <Button onClick={() => handleExtendSubscription(module.id, 12)}>
                                  12 meses (R$ 3.289,00)
                                </Button>
                              </div>
                              <DialogFooter>
                                <Button variant="outline">Cancelar</Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Módulo Dispensário</DialogTitle>
            <DialogDescription>
              Selecione uma organização para ativar o módulo Dispensário.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="organization">Organização</Label>
              <Select value={selectedOrganization} onValueChange={setSelectedOrganization}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma organização" />
                </SelectTrigger>
                <SelectContent>
                  {getEligibleOrganizations().map(org => (
                    <SelectItem key={org.id} value={org.id}>
                      {org.name} ({org.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="trial">Período de teste (dias)</Label>
              <Input
                id="trial"
                type="number"
                value={trialPeriod}
                onChange={(e) => setTrialPeriod(parseInt(e.target.value) || 0)}
                min="0"
                max="90"
              />
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-700 mb-2">Informações do Módulo</h4>
              <ul className="text-sm space-y-1 text-blue-700">
                <li>• Valor mensal: R$ 299,00</li>
                <li>• PDV para vendas no balcão</li>
                <li>• Controle de estoque</li>
                <li>• Integração com SNGPC</li>
                <li>• Gestão de receituário</li>
              </ul>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddModule}>
              Ativar Módulo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
