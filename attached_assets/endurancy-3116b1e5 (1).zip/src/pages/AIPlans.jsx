import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  BrainCircuit,
  Check,
  X,
  Sparkles,
  Zap,
  Rocket,
  Star
} from 'lucide-react';

export default function AIPlans() {
  const [plans] = useState([
    {
      id: 'ai-free',
      name: 'Free Trial',
      description: 'Experimente por 7 dias gratuitamente',
      price: 0,
      period: '7 dias',
      features: [
        'Acesso básico ao Copilot',
        'Respostas baseadas em conhecimento geral',
        'Limite de 50 perguntas/dia',
        'Integração básica com módulos',
      ],
      limitations: [
        'Sem acesso a análises avançadas',
        'Sem personalização de RAG',
        'Sem integração com documentos próprios',
        'Sem acesso a APIs especializadas'
      ],
      recommended: false,
      tag: 'TRIAL'
    },
    {
      id: 'ai-basic',
      name: 'Basic',
      description: 'Para organizações iniciando com IA',
      price: 299,
      period: 'mensal',
      features: [
        'Todas as features do Free',
        'Respostas personalizadas',
        'Integração completa com módulos',
        'Upload de até 100 documentos para RAG',
        'Limite de 500 perguntas/dia',
        'Análises básicas'
      ],
      limitations: [
        'Sem análises avançadas',
        'Sem multi-language support',
        'API calls limitadas'
      ],
      recommended: false,
      tag: 'POPULAR'
    },
    {
      id: 'ai-pro',
      name: 'Professional',
      description: 'Para uso profissional intensivo',
      price: 599,
      period: 'mensal',
      features: [
        'Todas as features do Basic',
        'Upload ilimitado de documentos',
        'Análises avançadas com IA',
        'Perguntas ilimitadas',
        'Suporte multi-language',
        'Personalização completa do RAG',
        'API calls ilimitadas',
        'Prioridade no suporte'
      ],
      limitations: [],
      recommended: true,
      tag: 'RECOMENDADO'
    }
  ]);

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Planos de Inteligência Artificial</h1>
        <p className="text-gray-500 mt-2">
          Escolha o melhor plano de IA para sua organização
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card key={plan.id} className={`relative ${plan.recommended ? 'border-primary shadow-lg' : ''}`}>
            {plan.tag && (
              <Badge className="absolute top-4 right-4 bg-primary">
                {plan.tag}
              </Badge>
            )}
            
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BrainCircuit className="h-5 w-5 text-primary" />
                {plan.name}
              </CardTitle>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="mb-4">
                <span className="text-3xl font-bold">
                  {plan.price === 0 ? 'Grátis' : `R$ ${plan.price}`}
                </span>
                <span className="text-gray-500">/{plan.period}</span>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Inclui:</h4>
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {plan.limitations.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">Limitações:</h4>
                    <ul className="space-y-2">
                      {plan.limitations.map((limitation, index) => (
                        <li key={index} className="flex items-center gap-2 text-sm text-gray-500">
                          <X className="h-4 w-4 text-red-500" />
                          {limitation}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <Button className="w-full mt-6">
                  {plan.price === 0 ? 'Começar Trial' : 'Contratar'}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}