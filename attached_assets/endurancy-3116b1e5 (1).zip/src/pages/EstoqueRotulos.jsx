import React, { useState, useEffect } from 'react';
import EstoqueBaseView from '../components/estoque/EstoqueBaseView';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function EstoqueRotulos() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [produtoFilter, setProdutoFilter] = useState("all");

  useEffect(() => {
    const loadData = async () => {
      const mockData = [
        {
          id: "1",
          codigo: "ROT-CBD10-001",
          nome: "Rótulo Óleo CBD 10%",
          lote: "L202301",
          quantidade_atual: 10000,
          quantidade_minima: 5000,
          unidade_medida: "unidade",
          status: "disponivel",
          data_validade: "2025-12-31",
          produto: "oleo_cbd_10"
        },
        {
          id: "2",
          codigo: "ROT-CBD5-001",
          nome: "Rótulo Óleo CBD 5%",
          lote: "L202302",
          quantidade_atual: 8000,
          quantidade_minima: 5000,
          unidade_medida: "unidade",
          status: "disponivel",
          data_validade: "2025-12-31",
          produto: "oleo_cbd_5"
        }
      ];
      
      setData(mockData);
      setLoading(false);
    };

    setTimeout(loadData, 1000);
  }, []);

  const customFilters = (
    <Select value={produtoFilter} onValueChange={setProdutoFilter}>
      <SelectTrigger className="w-48">
        <SelectValue placeholder="Produto" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">Todos Produtos</SelectItem>
        <SelectItem value="oleo_cbd_5">Óleo CBD 5%</SelectItem>
        <SelectItem value="oleo_cbd_10">Óleo CBD 10%</SelectItem>
        <SelectItem value="oleo_cbd_20">Óleo CBD 20%</SelectItem>
        <SelectItem value="capsulas">Cápsulas CBD</SelectItem>
      </SelectContent>
    </Select>
  );

  return (
    <EstoqueBaseView
      title="Estoque de Rótulos"
      description="Gestão de estoque de rótulos e materiais de identificação"
      tipoEstoque="rotulo"
      data={data}
      loading={loading}
      onAddItem={() => console.log("Adicionar item")}
      onEditItem={(item) => console.log("Editar item", item)}
      onViewDetails={(item) => console.log("Ver detalhes", item)}
      customFilters={customFilters}
    />
  );
}