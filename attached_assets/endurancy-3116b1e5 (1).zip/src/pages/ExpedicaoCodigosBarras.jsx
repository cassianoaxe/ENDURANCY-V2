import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  ScanBarcode,
  Search,
  Package,
  Check,
  XCircle,
  AlertCircle,
  CheckCircle,
  ArrowLeftRight,
  FlaskConical,
  Calendar,
  Box,
  Truck,
  RefreshCw,
  AlertTriangle,
  ArrowLeft,
  Info,
  Camera,
  Play,
  Pause,
  ExternalLink
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Dados simulados para pedidos
const mockOrders = [
  {
    id: "1",
    orderNumber: "PED-12345",
    customer: "João Silva",
    status: "aguardando_separacao",
    items: [
      { id: "1-1", name: "Óleo CBD 10%", code: "PROD001", quantity: 1, scanned: false },
      { id: "1-2", name: "Óleo CBD 5%", code: "PROD002", quantity: 1, scanned: false }
    ],
    created_date: "2023-11-14T10:30:00",
    shipping_method: "SEDEX",
    priority: "normal"
  },
  {
    id: "2",
    orderNumber: "PED-12346",
    customer: "Maria Oliveira",
    status: "em_separacao",
    items: [
      { id: "2-1", name: "Óleo CBD 20%", code: "PROD003", quantity: 1, scanned: true }
    ],
    created_date: "2023-11-14T11:45:00",
    shipping_method: "PAC",
    priority: "normal"
  },
  {
    id: "3",
    orderNumber: "PED-12347",
    customer: "Carlos Santos",
    status: "aguardando_separacao",
    items: [
      { id: "3-1", name: "Óleo CBD 30%", code: "PROD004", quantity: 1, scanned: false },
      { id: "3-2", name: "Camiseta Abrace", code: "PROD005", quantity: 1, scanned: false },
      { id: "3-3", name: "Pomada CBD", code: "PROD006", quantity: 2, scanned: false }
    ],
    created_date: "2023-11-14T09:15:00",
    shipping_method: "SEDEX",
    priority: "alta"
  },
  {
    id: "4",
    orderNumber: "PED-12348",
    customer: "Ana Costa",
    status: "em_separacao",
    items: [
      { id: "4-1", name: "Óleo CBD 15%", code: "PROD007", quantity: 1, scanned: false }
    ],
    created_date: "2023-11-14T14:30:00",
    shipping_method: "Transportadora",
    priority: "normal"
  }
];

// Dados simulados para conteúdo de malotes
const mockShipmentContents = [
  {
    id: "1",
    name: "Malote #12345",
    status: "em_preparacao",
    orders: [
      { orderNumber: "PED-12350", scanned: true },
      { orderNumber: "PED-12351", scanned: true },
      { orderNumber: "PED-12352", scanned: false },
      { orderNumber: "PED-12353", scanned: false }
    ],
    createdAt: "2023-11-15T09:00:00"
  },
  {
    id: "2",
    name: "Malote #12346",
    status: "concluido",
    orders: [
      { orderNumber: "PED-12340", scanned: true },
      { orderNumber: "PED-12341", scanned: true },
      { orderNumber: "PED-12342", scanned: true },
      { orderNumber: "PED-12343", scanned: true }
    ],
    createdAt: "2023-11-14T14:00:00"
  }
];

// Dados simulados de lotes de controle
const mockBatchChecks = [
  {
    id: "1",
    batchNumber: "LOT2023-A",
    productName: "Óleo CBD 10%",
    status: "pendente",
    totalItems: 20,
    scannedItems: 0,
    expiryDate: "2025-11-30"
  },
  {
    id: "2",
    batchNumber: "LOT2023-B",
    productName: "Óleo CBD 20%",
    status: "em_andamento",
    totalItems: 15,
    scannedItems: 8,
    expiryDate: "2025-10-31"
  },
  {
    id: "3",
    batchNumber: "LOT2023-C",
    productName: "Óleo CBD 5%",
    status: "concluido",
    totalItems: 25,
    scannedItems: 25,
    expiryDate: "2025-12-15"
  }
];

const mockScanHistory = [
  {
    id: "1",
    code: "PROD001",
    productName: "Óleo CBD 10%",
    timestamp: "2023-11-15T14:30:45",
    order: "PED-12345",
    user: "Ana Silva",
    status: "success",
    note: "Produto confirmado para pedido #12345"
  },
  {
    id: "2",
    code: "PROD003",
    productName: "Óleo CBD 20%",
    timestamp: "2023-11-15T14:28:12",
    order: "PED-12346",
    user: "Ana Silva",
    status: "success",
    note: "Produto confirmado para pedido #12346"
  },
  {
    id: "3",
    code: "PROD009",
    productName: "N/A",
    timestamp: "2023-11-15T14:25:30",
    order: "N/A",
    user: "Ana Silva",
    status: "error",
    note: "Código de barras não reconhecido no sistema"
  },
  {
    id: "4",
    code: "PROD005",
    productName: "Camiseta Abrace",
    timestamp: "2023-11-15T14:20:15",
    order: "N/A",
    user: "Ana Silva",
    status: "warning",
    note: "Produto não associado a nenhum pedido ativo"
  }
];

export default function ExpedicaoCodigosBarras() {
  const [activeTab, setActiveTab] = useState("separacao");
  const [currentOrderId, setCurrentOrderId] = useState(null);
  const [currentShipmentId, setCurrentShipmentId] = useState(null);
  const [currentBatchId, setCurrentBatchId] = useState(null);
  const [scanMode, setScanMode] = useState("manual"); // manual ou camera
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [scannedCode, setScannedCode] = useState("");
  const [scanResult, setScanResult] = useState(null);
  const [scanHistory, setScanHistory] = useState(mockScanHistory);
  const [showScanResult, setShowScanResult] = useState(false);
  const [orders, setOrders] = useState(mockOrders);
  const [shipments, setShipments] = useState(mockShipmentContents);
  const [batches, setBatches] = useState(mockBatchChecks);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showHelp, setShowHelp] = useState(false);

  const videoRef = useRef(null);
  const scanInputRef = useRef(null);
  
  // Efeito para focar no campo de entrada do scanner quando necessário
  useEffect(() => {
    if (scanMode === 'manual' && scanInputRef.current && !currentOrderId && !currentShipmentId && !currentBatchId) {
      scanInputRef.current.focus();
    }
  }, [scanMode, currentOrderId, currentShipmentId, currentBatchId]);

  // Efeito para lidar com a câmera
  useEffect(() => {
    let stream = null;

    const setupCamera = async () => {
      try {
        if (isCameraActive && videoRef.current) {
          stream = await navigator.mediaDevices.getUserMedia({ video: true });
          videoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Erro ao acessar a câmera:', error);
        setScanMode('manual');
        setIsCameraActive(false);
        // Em uma implementação real, mostraria uma mensagem de erro ao usuário
      }
    };

    if (scanMode === 'camera') {
      setupCamera();
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isCameraActive, scanMode]);

  const handleScanSubmit = (e) => {
    e.preventDefault();
    processScannedCode(scannedCode);
  };

  const processScannedCode = (code) => {
    setIsLoading(true);
    
    // Simula processamento do código escaneado
    setTimeout(() => {
      if (currentOrderId) {
        processScanForOrder(code);
      } else if (currentShipmentId) {
        processScanForShipment(code);
      } else if (currentBatchId) {
        processScanForBatch(code);
      } else {
        // Verificar em qual contexto o código se encaixa
        determineCodeContext(code);
      }
      
      setIsLoading(false);
      setScannedCode("");
      
      // Foca novamente no campo de entrada após o processamento
      if (scanInputRef.current) {
        scanInputRef.current.focus();
      }
    }, 500);
  };

  const determineCodeContext = (code) => {
    // Verifica se o código corresponde a um produto em algum pedido
    const foundOrder = orders.find(order => 
      order.items.some(item => item.code === code)
    );

    if (foundOrder) {
      // É um produto de um pedido
      const item = foundOrder.items.find(item => item.code === code);
      
      setScanResult({
        success: true,
        message: `Produto "${item.name}" encontrado no pedido ${foundOrder.orderNumber}`,
        details: {
          type: "product",
          orderNumber: foundOrder.orderNumber,
          orderId: foundOrder.id,
          productName: item.name,
          productCode: item.code
        }
      });
      
      addToScanHistory({
        code: code,
        productName: item.name,
        order: foundOrder.orderNumber,
        status: "success",
        note: `Produto localizado no pedido ${foundOrder.orderNumber}`
      });
    }
    // Verifica se é um número de pedido
    else if (code.startsWith("PED-")) {
      const foundOrder = orders.find(order => order.orderNumber === code);
      
      if (foundOrder) {
        setScanResult({
          success: true,
          message: `Pedido ${code} encontrado`,
          details: {
            type: "order",
            orderNumber: foundOrder.orderNumber,
            orderId: foundOrder.id,
            customer: foundOrder.customer
          }
        });
        
        addToScanHistory({
          code: code,
          productName: "N/A",
          order: code,
          status: "success",
          note: `Pedido ${code} localizado`
        });
      } else {
        setScanResult({
          success: false,
          message: `Pedido ${code} não encontrado no sistema`,
          details: {
            type: "unknown",
            code: code
          }
        });
        
        addToScanHistory({
          code: code,
          productName: "N/A",
          order: "N/A",
          status: "error",
          note: `Pedido ${code} não encontrado`
        });
      }
    }
    // Verifica se é um número de lote
    else if (code.startsWith("LOT")) {
      const foundBatch = batches.find(batch => batch.batchNumber === code);
      
      if (foundBatch) {
        setScanResult({
          success: true,
          message: `Lote ${code} encontrado: ${foundBatch.productName}`,
          details: {
            type: "batch",
            batchNumber: foundBatch.batchNumber,
            batchId: foundBatch.id,
            productName: foundBatch.productName
          }
        });
        
        addToScanHistory({
          code: code,
          productName: foundBatch.productName,
          order: "N/A",
          status: "success",
          note: `Lote ${code} localizado`
        });
      } else {
        setScanResult({
          success: false,
          message: `Lote ${code} não encontrado no sistema`,
          details: {
            type: "unknown",
            code: code
          }
        });
        
        addToScanHistory({
          code: code,
          productName: "N/A",
          order: "N/A",
          status: "error",
          note: `Lote ${code} não encontrado`
        });
      }
    }
    // Não foi possível determinar o contexto
    else {
      setScanResult({
        success: false,
        message: `Código ${code} não reconhecido pelo sistema`,
        details: {
          type: "unknown",
          code: code
        }
      });
      
      addToScanHistory({
        code: code,
        productName: "N/A",
        order: "N/A",
        status: "error",
        note: `Código não reconhecido: ${code}`
      });
    }
    
    setShowScanResult(true);
  };

  const processScanForOrder = (code) => {
    const order = orders.find(order => order.id === currentOrderId);
    if (!order) return;
    
    const item = order.items.find(item => item.code === code);
    
    if (item) {
      // Atualiza o status do item
      const updatedOrders = orders.map(o => {
        if (o.id === currentOrderId) {
          return {
            ...o,
            items: o.items.map(i => {
              if (i.id === item.id) {
                return { ...i, scanned: true };
              }
              return i;
            })
          };
        }
        return o;
      });
      
      setOrders(updatedOrders);
      
      setScanResult({
        success: true,
        message: `Item "${item.name}" confirmado para o pedido ${order.orderNumber}`,
        details: {
          type: "product",
          orderNumber: order.orderNumber,
          productName: item.name,
          productCode: item.code
        }
      });
      
      addToScanHistory({
        code: code,
        productName: item.name,
        order: order.orderNumber,
        status: "success",
        note: `Produto confirmado para pedido ${order.orderNumber}`
      });
    } else {
      setScanResult({
        success: false,
        message: `Código ${code} não corresponde a nenhum item do pedido ${order.orderNumber}`,
        details: {
          type: "unknown",
          code: code,
          orderNumber: order.orderNumber
        }
      });
      
      addToScanHistory({
        code: code,
        productName: "N/A",
        order: order.orderNumber,
        status: "error",
        note: `Código não corresponde a nenhum item do pedido ${order.orderNumber}`
      });
    }
    
    setShowScanResult(true);
  };

  const processScanForShipment = (code) => {
    const shipment = shipments.find(s => s.id === currentShipmentId);
    if (!shipment) return;
    
    // Verifica se o código é um número de pedido incluído no malote
    const orderInShipment = shipment.orders.find(o => o.orderNumber === code);
    
    if (orderInShipment) {
      // Atualiza o status do pedido no malote
      const updatedShipments = shipments.map(s => {
        if (s.id === currentShipmentId) {
          return {
            ...s,
            orders: s.orders.map(o => {
              if (o.orderNumber === code) {
                return { ...o, scanned: true };
              }
              return o;
            })
          };
        }
        return s;
      });
      
      setShipments(updatedShipments);
      
      setScanResult({
        success: true,
        message: `Pedido ${code} confirmado para o malote ${shipment.name}`,
        details: {
          type: "order",
          orderNumber: code,
          shipmentName: shipment.name
        }
      });
      
      addToScanHistory({
        code: code,
        productName: "N/A",
        order: code,
        status: "success",
        note: `Pedido confirmado para malote ${shipment.name}`
      });
    } else {
      setScanResult({
        success: false,
        message: `Pedido ${code} não pertence ao malote ${shipment.name}`,
        details: {
          type: "unknown",
          code: code,
          shipmentName: shipment.name
        }
      });
      
      addToScanHistory({
        code: code,
        productName: "N/A",
        order: code,
        status: "warning",
        note: `Pedido não pertence ao malote ${shipment.name}`
      });
    }
    
    setShowScanResult(true);
  };

  const processScanForBatch = (code) => {
    const batch = batches.find(b => b.id === currentBatchId);
    if (!batch) return;
    
    // Em uma implementação real, aqui verificaríamos se o código corresponde a um produto no lote
    // Para esta demonstração, vamos considerar que qualquer código que começa com "PROD" é válido
    if (code.startsWith("PROD")) {
      // Incrementa o contador de itens escaneados
      const updatedBatches = batches.map(b => {
        if (b.id === currentBatchId) {
          const newScannedItems = Math.min(b.scannedItems + 1, b.totalItems);
          return {
            ...b,
            scannedItems: newScannedItems,
            status: newScannedItems === b.totalItems ? "concluido" : "em_andamento"
          };
        }
        return b;
      });
      
      setBatches(updatedBatches);
      
      setScanResult({
        success: true,
        message: `Item do lote ${batch.batchNumber} verificado com sucesso`,
        details: {
          type: "batch_item",
          batchNumber: batch.batchNumber,
          productName: batch.productName
        }
      });
      
      addToScanHistory({
        code: code,
        productName: batch.productName,
        order: "N/A",
        status: "success",
        note: `Item do lote ${batch.batchNumber} verificado`
      });
    } else {
      setScanResult({
        success: false,
        message: `Código ${code} não é um produto válido para o lote ${batch.batchNumber}`,
        details: {
          type: "unknown",
          code: code,
          batchNumber: batch.batchNumber
        }
      });
      
      addToScanHistory({
        code: code,
        productName: "N/A",
        order: "N/A",
        status: "error",
        note: `Código inválido para lote ${batch.batchNumber}`
      });
    }
    
    setShowScanResult(true);
  };

  const addToScanHistory = (scan) => {
    const newScan = {
      id: (scanHistory.length + 1).toString(),
      timestamp: new Date().toISOString(),
      user: "Ana Silva", // Em uma aplicação real seria o usuário atual
      ...scan
    };
    
    setScanHistory([newScan, ...scanHistory]);
  };

  const handleOrderSelect = (orderId) => {
    setCurrentOrderId(orderId);
    setCurrentShipmentId(null);
    setCurrentBatchId(null);
    
    if (scanInputRef.current) {
      scanInputRef.current.focus();
    }
  };

  const handleShipmentSelect = (shipmentId) => {
    setCurrentShipmentId(shipmentId);
    setCurrentOrderId(null);
    setCurrentBatchId(null);
    
    if (scanInputRef.current) {
      scanInputRef.current.focus();
    }
  };

  const handleBatchSelect = (batchId) => {
    setCurrentBatchId(batchId);
    setCurrentOrderId(null);
    setCurrentShipmentId(null);
    
    if (scanInputRef.current) {
      scanInputRef.current.focus();
    }
  };

  const resetCurrentSelection = () => {
    setCurrentOrderId(null);
    setCurrentShipmentId(null);
    setCurrentBatchId(null);
    
    if (scanInputRef.current) {
      scanInputRef.current.focus();
    }
  };

  const toggleCameraMode = () => {
    const newMode = scanMode === 'manual' ? 'camera' : 'manual';
    setScanMode(newMode);
    setIsCameraActive(newMode === 'camera');
  };

  const formatDateTime = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const renderScannerInterface = () => {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Leitor de Código de Barras</CardTitle>
          <CardDescription>
            {currentOrderId 
              ? `Escaneie os produtos do pedido selecionado` 
              : currentShipmentId 
                ? `Escaneie os pedidos do malote selecionado`
                : currentBatchId
                  ? `Escaneie os produtos do lote selecionado`
                  : `Escaneie qualquer código para identificar`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Label htmlFor="camera-mode">Usar câmera</Label>
                <Switch
                  id="camera-mode"
                  checked={scanMode === 'camera'}
                  onCheckedChange={toggleCameraMode}
                />
              </div>
              
              <Button variant="outline" size="sm" onClick={() => setShowHelp(true)}>
                <Info className="w-4 h-4 mr-2" />
                Ajuda
              </Button>
            </div>
            
            {scanMode === 'manual' ? (
              <form onSubmit={handleScanSubmit} className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Input
                    ref={scanInputRef}
                    value={scannedCode}
                    onChange={(e) => setScannedCode(e.target.value)}
                    placeholder="Digite ou escaneie o código de barras"
                    className="flex-1"
                    disabled={isLoading}
                    autoFocus
                  />
                  <Button type="submit" disabled={!scannedCode || isLoading}>
                    {isLoading ? (
                      <span className="animate-spin mr-2">
                        <RefreshCw className="h-4 w-4" />
                      </span>
                    ) : (
                      <ScanBarcode className="h-4 w-4 mr-2" />
                    )}
                    Verificar
                  </Button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden">
                  <video 
                    ref={videoRef} 
                    className="w-full h-full object-cover" 
                    autoPlay 
                    playsInline
                  />
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="border-2 border-white w-3/4 h-1/2 opacity-50"></div>
                  </div>
                </div>
                
                <div className="flex justify-center">
                  <Button onClick={() => processScannedCode("DEMO-CODE")} disabled={isLoading}>
                    {isLoading ? (
                      <span className="animate-spin mr-2">
                        <RefreshCw className="h-4 w-4" />
                      </span>
                    ) : (
                      <Camera className="h-4 w-4 mr-2" />
                    )}
                    Simular Escaneamento
                  </Button>
                </div>
                
                <p className="text-xs text-center text-gray-500">
                  Posicione o código de barras no centro da câmera
                </p>
              </div>
            )}
            
            {currentOrderId && (
              <Alert variant="info" className="bg-blue-50 text-blue-800 border-blue-200">
                <Info className="h-4 w-4" />
                <AlertTitle className="text-blue-800">Pedido em processamento</AlertTitle>
                <AlertDescription className="text-blue-700">
                  {`Escaneando produtos para o pedido ${orders.find(o => o.id === currentOrderId)?.orderNumber}`}
                  <Button 
                    variant="link" 
                    className="text-blue-800 p-0 h-auto text-sm" 
                    onClick={resetCurrentSelection}
                  >
                    Cancelar
                  </Button>
                </AlertDescription>
              </Alert>
            )}
            
            {currentShipmentId && (
              <Alert variant="info" className="bg-blue-50 text-blue-800 border-blue-200">
                <Info className="h-4 w-4" />
                <AlertTitle className="text-blue-800">Malote em processamento</AlertTitle>
                <AlertDescription className="text-blue-700">
                  {`Escaneando pedidos para o malote ${shipments.find(s => s.id === currentShipmentId)?.name}`}
                  <Button 
                    variant="link" 
                    className="text-blue-800 p-0 h-auto text-sm" 
                    onClick={resetCurrentSelection}
                  >
                    Cancelar
                  </Button>
                </AlertDescription>
              </Alert>
            )}
            
            {currentBatchId && (
              <Alert variant="info" className="bg-blue-50 text-blue-800 border-blue-200">
                <Info className="h-4 w-4" />
                <AlertTitle className="text-blue-800">Lote em verificação</AlertTitle>
                <AlertDescription className="text-blue-700">
                  {`Verificando produtos do lote ${batches.find(b => b.id === currentBatchId)?.batchNumber}`}
                  <Button 
                    variant="link" 
                    className="text-blue-800 p-0 h-auto text-sm" 
                    onClick={resetCurrentSelection}
                  >
                    Cancelar
                  </Button>
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderScanResult = () => {
    if (!scanResult) return null;
    
    return (
      <Dialog open={showScanResult} onOpenChange={setShowScanResult}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {scanResult.success ? "Leitura Bem-sucedida" : "Problema na Leitura"}
            </DialogTitle>
          </DialogHeader>
          
          <div className="flex items-center gap-4 py-4">
            <div className={`p-3 rounded-full ${
              scanResult.success 
                ? "bg-green-100 text-green-600" 
                : "bg-red-100 text-red-600"
            }`}>
              {scanResult.success ? (
                <CheckCircle className="h-6 w-6" />
              ) : (
                <XCircle className="h-6 w-6" />
              )}
            </div>
            
            <div className="flex-1">
              <p className="font-medium">{scanResult.message}</p>
              {scanResult.details?.type === "product" && (
                <p className="text-sm text-gray-500">Código: {scanResult.details.productCode}</p>
              )}
            </div>
          </div>
          
          <DialogFooter>
            {scanResult.success && scanResult.details?.type === "order" && !currentShipmentId && (
              <Button 
                variant="outline"
                onClick={() => {
                  setShowScanResult(false);
                  handleOrderSelect(scanResult.details.orderId);
                }}
              >
                Processar Este Pedido
              </Button>
            )}
            
            {scanResult.success && scanResult.details?.type === "batch" && (
              <Button 
                variant="outline"
                onClick={() => {
                  setShowScanResult(false);
                  handleBatchSelect(scanResult.details.batchId);
                }}
              >
                Verificar Este Lote
              </Button>
            )}
            
            <Button 
              onClick={() => setShowScanResult(false)}
              autoFocus
            >
              Continuar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  };

  const renderOrderProcessingContent = () => {
    if (!currentOrderId) return null;
    
    const order = orders.find(o => o.id === currentOrderId);
    if (!order) return null;
    
    const completedItems = order.items.filter(item => item.scanned).length;
    const totalItems = order.items.length;
    const progress = (completedItems / totalItems) * 100;
    
    return (
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Processando Pedido {order.orderNumber}</CardTitle>
              <CardDescription>Cliente: {order.customer}</CardDescription>
            </div>
            <Badge 
              variant="outline" 
              className={
                order.priority === 'alta' 
                  ? 'bg-red-50 text-red-700 border-red-200' 
                  : 'bg-gray-50 text-gray-700 border-gray-200'
              }
            >
              {order.priority === 'alta' ? 'Prioridade Alta' : 'Prioridade Normal'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <Label>Progresso</Label>
                <span className="text-sm text-gray-500">{completedItems}/{totalItems} itens</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
            
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item</TableHead>
                  <TableHead>Código</TableHead>
                  <TableHead>Qtd</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {order.items.map(item => (
                  <TableRow key={item.id}>
                    <TableCell>{item.name}</TableCell>
                    <TableCell className="font-mono">{item.code}</TableCell>
                    <TableCell>{item.quantity}</TableCell>
                    <TableCell>
                      {item.scanned ? (
                        <Badge className="bg-green-50 text-green-700 border-green-200">
                          <Check className="h-3 w-3 mr-1" />
                          Verificado
                        </Badge>
                      ) : (
                        <Badge variant="outline">Pendente</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {completedItems === totalItems && (
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-700">Pedido completo</AlertTitle>
                <AlertDescription className="text-green-600">
                  Todos os itens foram verificados com sucesso.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={resetCurrentSelection}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          
          <Button disabled={completedItems !== totalItems}>
            Finalizar Pedido
          </Button>
        </CardFooter>
      </Card>
    );
  };

  const renderShipmentProcessingContent = () => {
    if (!currentShipmentId) return null;
    
    const shipment = shipments.find(s => s.id === currentShipmentId);
    if (!shipment) return null;
    
    const completedOrders = shipment.orders.filter(order => order.scanned).length;
    const totalOrders = shipment.orders.length;
    const progress = (completedOrders / totalOrders) * 100;
    
    return (
      <Card>
        <CardHeader>
          <CardTitle>Processando Malote {shipment.name}</CardTitle>
          <CardDescription>Verifique se todos os pedidos estão incluídos</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <Label>Progresso</Label>
                <span className="text-sm text-gray-500">{completedOrders}/{totalOrders} pedidos</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
            
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pedido</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {shipment.orders.map((order, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{order.orderNumber}</TableCell>
                    <TableCell>
                      {order.scanned ? (
                        <Badge className="bg-green-50 text-green-700 border-green-200">
                          <Check className="h-3 w-3 mr-1" />
                          Verificado
                        </Badge>
                      ) : (
                        <Badge variant="outline">Pendente</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {completedOrders === totalOrders && (
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-700">Malote completo</AlertTitle>
                <AlertDescription className="text-green-600">
                  Todos os pedidos foram verificados com sucesso.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={resetCurrentSelection}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          
          <Button disabled={completedOrders !== totalOrders}>
            Finalizar Malote
          </Button>
        </CardFooter>
      </Card>
    );
  };

  const renderBatchProcessingContent = () => {
    if (!currentBatchId) return null;
    
    const batch = batches.find(b => b.id === currentBatchId);
    if (!batch) return null;
    
    const progress = (batch.scannedItems / batch.totalItems) * 100;
    
    return (
      <Card>
        <CardHeader>
          <CardTitle>Verificando Lote {batch.batchNumber}</CardTitle>
          <CardDescription>{batch.productName}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <Label>Produto</Label>
                <p className="text-sm font-medium">{batch.productName}</p>
              </div>
              <div>
                <Label>Data de Validade</Label>
                <p className="text-sm font-medium">{new Date(batch.expiryDate).toLocaleDateString()}</p>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-2">
                <Label>Progresso da Verificação</Label>
                <span className="text-sm text-gray-500">{batch.scannedItems}/{batch.totalItems} itens</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
            
            {batch.scannedItems === batch.totalItems && (
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-700">Verificação completa</AlertTitle>
                <AlertDescription className="text-green-600">
                  Todos os itens do lote foram verificados com sucesso.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={resetCurrentSelection}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          
          <Button disabled={batch.scannedItems !== batch.totalItems}>
            Finalizar Verificação
          </Button>
        </CardFooter>
      </Card>
    );
  };

  const renderSeparacaoTab = () => {
    const filteredOrders = orders.filter(order => 
      (order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
       order.customer.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    
    return (
      <div className="space-y-6">
        {renderScannerInterface()}
        
        {currentOrderId ? (
          renderOrderProcessingContent()
        ) : (
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Pedidos para Preparação</CardTitle>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar pedidos..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredOrders.length === 0 ? (
                  <div className="text-center py-4">
                    <Package className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhum pedido encontrado</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Não há pedidos que correspondam aos critérios de busca.
                    </p>
                  </div>
                ) : (
                  filteredOrders.map(order => {
                    const completedItems = order.items.filter(item => item.scanned).length;
                    const totalItems = order.items.length;
                    const progress = (completedItems / totalItems) * 100;
                    
                    return (
                      <div 
                        key={order.id} 
                        className="border rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                        onClick={() => handleOrderSelect(order.id)}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-medium">{order.orderNumber}</h3>
                            <p className="text-sm text-gray-500">{order.customer}</p>
                          </div>
                          <Badge 
                            variant="outline" 
                            className={
                              order.priority === 'alta' 
                                ? 'bg-red-50 text-red-700 border-red-200' 
                                : 'bg-gray-50 text-gray-700 border-gray-200'
                            }
                          >
                            {order.priority === 'alta' ? 'Prioridade Alta' : 'Prioridade Normal'}
                          </Badge>
                        </div>
                        
                        <div className="flex justify-between items-center text-sm">
                          <span>{completedItems}/{totalItems} itens verificados</span>
                          <span>{order.shipping_method}</span>
                        </div>
                        
                        <Progress value={progress} className="h-1 mt-2" />
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
          </Card>
        )}
        
        {renderScanResult()}
      </div>
    );
  };

  const renderMalotesTab = () => {
    const filteredShipments = shipments.filter(shipment => 
      shipment.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    return (
      <div className="space-y-6">
        {renderScannerInterface()}
        
        {currentShipmentId ? (
          renderShipmentProcessingContent()
        ) : (
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Malotes para Conferência</CardTitle>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar malotes..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredShipments.length === 0 ? (
                  <div className="text-center py-4">
                    <Box className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhum malote encontrado</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Não há malotes que correspondam aos critérios de busca.
                    </p>
                  </div>
                ) : (
                  filteredShipments.map(shipment => {
                    const completedOrders = shipment.orders.filter(order => order.scanned).length;
                    const totalOrders = shipment.orders.length;
                    const progress = (completedOrders / totalOrders) * 100;
                    
                    return (
                      <div 
                        key={shipment.id} 
                        className="border rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                        onClick={() => handleShipmentSelect(shipment.id)}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-medium">{shipment.name}</h3>
                            <p className="text-sm text-gray-500">
                              Criado em: {formatDateTime(shipment.createdAt)}
                            </p>
                          </div>
                          <Badge 
                            variant="outline" 
                            className={
                              shipment.status === 'em_preparacao' 
                                ? 'bg-yellow-50 text-yellow-700 border-yellow-200' 
                                : 'bg-green-50 text-green-700 border-green-200'
                            }
                          >
                            {shipment.status === 'em_preparacao' ? 'Em Preparação' : 'Concluído'}
                          </Badge>
                        </div>
                        
                        <div className="flex justify-between items-center text-sm">
                          <span>{completedOrders}/{totalOrders} pedidos verificados</span>
                          <span>{totalOrders} pedidos total</span>
                        </div>
                        
                        <Progress value={progress} className="h-1 mt-2" />
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
          </Card>
        )}
        
        {renderScanResult()}
      </div>
    );
  };

  const renderLotesTab = () => {
    const filteredBatches = batches.filter(batch => 
      batch.batchNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      batch.productName.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    return (
      <div className="space-y-6">
        {renderScannerInterface()}
        
        {currentBatchId ? (
          renderBatchProcessingContent()
        ) : (
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Lotes para Verificação</CardTitle>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar lotes..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredBatches.length === 0 ? (
                  <div className="text-center py-4">
                    <FlaskConical className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhum lote encontrado</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Não há lotes que correspondam aos critérios de busca.
                    </p>
                  </div>
                ) : (
                  filteredBatches.map(batch => {
                    const progress = (batch.scannedItems / batch.totalItems) * 100;
                    
                    return (
                      <div 
                        key={batch.id} 
                        className="border rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                        onClick={() => handleBatchSelect(batch.id)}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-medium">{batch.batchNumber}</h3>
                            <p className="text-sm text-gray-500">{batch.productName}</p>
                          </div>
                          <Badge 
                            variant="outline" 
                            className={
                              batch.status === 'pendente' 
                                ? 'bg-gray-50 text-gray-700 border-gray-200' :
                              batch.status === 'em_andamento'
                                ? 'bg-yellow-50 text-yellow-700 border-yellow-200'
                                : 'bg-green-50 text-green-700 border-green-200'
                            }
                          >
                            {batch.status === 'pendente' 
                              ? 'Pendente' 
                              : batch.status === 'em_andamento'
                                ? 'Em Andamento'
                                : 'Concluído'}
                          </Badge>
                        </div>
                        
                        <div className="flex justify-between items-center text-sm">
                          <span>
                            {batch.scannedItems}/{batch.totalItems} itens verificados
                          </span>
                          <span>
                            Validade: {new Date(batch.expiryDate).toLocaleDateString()}
                          </span>
                        </div>
                        
                        <Progress value={progress} className="h-1 mt-2" />
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
          </Card>
        )}
        
        {renderScanResult()}
      </div>
    );
  };

  const renderHistoricoTab = () => {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Escaneamento</CardTitle>
          <CardDescription>
            Registros das últimas leituras realizadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar no histórico..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data/Hora</TableHead>
                  <TableHead>Código</TableHead>
                  <TableHead>Produto</TableHead>
                  <TableHead>Pedido</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Observação</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {scanHistory
                  .filter(scan => 
                    scan.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    scan.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    scan.order.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    scan.note.toLowerCase().includes(searchQuery.toLowerCase())
                  )
                  .map(scan => (
                    <TableRow key={scan.id}>
                      <TableCell className="whitespace-nowrap">
                        {formatDateTime(scan.timestamp)}
                      </TableCell>
                      <TableCell className="font-mono">{scan.code}</TableCell>
                      <TableCell>{scan.productName !== "N/A" ? scan.productName : "-"}</TableCell>
                      <TableCell>{scan.order !== "N/A" ? scan.order : "-"}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            scan.status === 'success'
                              ? 'bg-green-50 text-green-700 border-green-200'
                              : scan.status === 'warning'
                                ? 'bg-yellow-50 text-yellow-700 border-yellow-200'
                                : 'bg-red-50 text-red-700 border-red-200'
                          }
                        >
                          {scan.status === 'success'
                            ? 'Sucesso'
                            : scan.status === 'warning'
                              ? 'Alerta'
                              : 'Erro'}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{scan.note}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Leitura de Códigos</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            Use o leitor para verificar pedidos, malotes e lotes
          </p>
        </div>
        
        <div className="flex gap-2">
          <Link to={createPageUrl("ExpedicaoDashboard")}>
            <Button variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar ao Dashboard
            </Button>
          </Link>
        </div>
      </div>

      <Tabs 
        defaultValue="separacao" 
        value={activeTab} 
        onValueChange={(tab) => {
          setActiveTab(tab);
          setCurrentOrderId(null);
          setCurrentShipmentId(null);
          setCurrentBatchId(null);
          setSearchQuery("");
        }}
      >
        <TabsList>
          <TabsTrigger value="separacao">
            <Package className="h-4 w-4 mr-2" />
            Separação de Pedidos
          </TabsTrigger>
          <TabsTrigger value="malotes">
            <Box className="h-4 w-4 mr-2" />
            Conferência de Malotes
          </TabsTrigger>
          <TabsTrigger value="lotes">
            <FlaskConical className="h-4 w-4 mr-2" />
            Verificação de Lotes
          </TabsTrigger>
          <TabsTrigger value="historico">
            <Calendar className="h-4 w-4 mr-2" />
            Histórico
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="separacao">
          {renderSeparacaoTab()}
        </TabsContent>
        
        <TabsContent value="malotes">
          {renderMalotesTab()}
        </TabsContent>
        
        <TabsContent value="lotes">
          {renderLotesTab()}
        </TabsContent>
        
        <TabsContent value="historico">
          {renderHistoricoTab()}
        </TabsContent>
      </Tabs>
      
      <Dialog open={showHelp} onOpenChange={setShowHelp}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Ajuda de Leitura de Códigos</DialogTitle>
            <DialogDescription>
              Como utilizar o leitor de códigos de barras
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <h3 className="font-medium">Modos de Leitura</h3>
              <p className="text-sm text-gray-500">
                Você pode usar o leitor manual ou a câmera para escanear. Alterne entre os modos usando o switch.
              </p>
            </div>
            
            <div className="space-y-2">
              <h3 className="font-medium">Tipos de Códigos</h3>
              <ul className="text-sm text-gray-500 space-y-2">
                <li className="flex gap-2">
                  <Package className="h-4 w-4 flex-shrink-0 text-gray-600" />
                  <span><strong>Produtos:</strong> Começam com PROD (ex: PROD001)</span>
                </li>
                <li className="flex gap-2">
                  <Box className="h-4 w-4 flex-shrink-0 text-gray-600" />
                  <span><strong>Pedidos:</strong> Começam com PED- (ex: PED-12345)</span>
                </li>
                <li className="flex gap-2">
                  <FlaskConical className="h-4 w-4 flex-shrink-0 text-gray-600" />
                  <span><strong>Lotes:</strong> Começam com LOT (ex: LOT2023-A)</span>
                </li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <h3 className="font-medium">Fluxo de Trabalho</h3>
              <ol className="text-sm text-gray-500 space-y-2 list-decimal ml-5">
                <li>Selecione a aba apropriada para sua tarefa</li>
                <li>Escaneie o código ou selecione um item da lista</li>
                <li>Siga as instruções para completar a verificação</li>
              </ol>
            </div>
          </div>
          
          <DialogFooter>
            <Button onClick={() => setShowHelp(false)}>Entendi</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}