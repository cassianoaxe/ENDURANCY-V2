import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Download, Calendar, Filter, TrendingUp, ChevronRight, ChevronDown, FileText, Brain, Microscope } from 'lucide-react';

export default function EstatisticasPesquisa() {
  const [activeTab, setActiveTab] = useState("overview");
  const [period, setPeriod] = useState("anual");
  const [isLoading, setIsLoading] = useState(false);
  
  // Mock data para diversos gráficos
  const condicoesPesquisadas = [
    { name: 'Epilepsia', value: 18 },
    { name: 'Dor crônica', value: 27 },
    { name: 'Ansiedade', value: 16 },
    { name: 'Esclerose múltipla', value: 12 },
    { name: 'Parkinson', value: 8 },
    { name: 'Autismo', value: 7 },
    { name: 'Outros', value: 12 },
  ];
  
  const tiposTratamento = [
    { name: 'CBD isolado', value: 35 },
    { name: 'Espectro completo', value: 45 },
    { name: 'THC isolado', value: 10 },
    { name: 'Outros canabinoides', value: 10 },
  ];
  
  const evolucaoPesquisas = [
    { month: 'Jan', pesquisas: 5 },
    { month: 'Fev', pesquisas: 6 },
    { month: 'Mar', pesquisas: 7 },
    { month: 'Abr', pesquisas: 8 },
    { month: 'Mai', pesquisas: 7 },
    { month: 'Jun', pesquisas: 9 },
    { month: 'Jul', pesquisas: 12 },
    { month: 'Ago', pesquisas: 15 },
    { month: 'Set', pesquisas: 16 },
    { month: 'Out', pesquisas: 15 },
    { month: 'Nov', pesquisas: 14 },
    { month: 'Dez', pesquisas: 16 },
  ];
  
  const faixaEtariaPacientes = [
    { name: '0-18', value: 10 },
    { name: '19-30', value: 20 },
    { name: '31-45', value: 35 },
    { name: '46-60', value: 25 },
    { name: '60+', value: 10 },
  ];
  
  const eficaciaTratamentos = [
    { name: 'Alta eficácia', value: 35, color: '#10B981' },
    { name: 'Eficácia moderada', value: 40, color: '#60A5FA' },
    { name: 'Baixa eficácia', value: 15, color: '#F59E0B' },
    { name: 'Sem eficácia', value: 10, color: '#EF4444' },
  ];

  const publicacoesAcademicas = [
    { ano: 2018, quantidade: 12 },
    { ano: 2019, quantidade: 18 },
    { ano: 2020, quantidade: 24 },
    { ano: 2021, quantidade: 32 },
    { ano: 2022, quantidade: 38 },
    { ano: 2023, quantidade: 42 },
  ];

  const COLORS = ['#10B981', '#60A5FA', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#6366F1'];

  // Dados para a comparação de eficácia
  const eficaciaComparativa = [
    { name: 'Dor crônica', tradicional: 70, cannabis: 85 },
    { name: 'Epilepsia', tradicional: 75, cannabis: 80 },
    { name: 'Ansiedade', tradicional: 65, cannabis: 75 },
    { name: 'Esclerose', tradicional: 60, cannabis: 70 },
    { name: 'Parkinson', tradicional: 55, cannabis: 65 },
  ];

  // Lista de pesquisas recentes
  const pesquisasRecentes = [
    { id: 1, titulo: "Eficácia do CBD no tratamento da epilepsia refratária", pesquisador: "Dra. Mariana Santos", status: "Em andamento", pacientes: 45, data_inicio: "2023-02-15" },
    { id: 2, titulo: "Uso de canabinoides no manejo da dor crônica", pesquisador: "Dr. Carlos Oliveira", status: "Concluída", pacientes: 120, data_inicio: "2022-08-10" },
    { id: 3, titulo: "Cannabis medicinal no tratamento de sintomas da esclerose múltipla", pesquisador: "Dra. Fernanda Lima", status: "Em andamento", pacientes: 60, data_inicio: "2023-04-22" },
    { id: 4, titulo: "Efeitos do THC em pacientes com Parkinson", pesquisador: "Dr. Roberto Mendes", status: "Concluída", pacientes: 35, data_inicio: "2022-11-05" },
    { id: 5, titulo: "Canabinoides e qualidade do sono em pacientes com ansiedade", pesquisador: "Dra. Luciana Ferreira", status: "Em análise", pacientes: 85, data_inicio: "2023-01-18" },
  ];

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Estatísticas de Pesquisa</h1>
          <p className="text-muted-foreground">Análise e visualização de dados das pesquisas científicas com cannabis medicinal</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-36">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <SelectValue placeholder="Período" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mensal">Mensal</SelectItem>
              <SelectItem value="trimestral">Trimestral</SelectItem>
              <SelectItem value="semestral">Semestral</SelectItem>
              <SelectItem value="anual">Anual</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Exportar Dados
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="conditions">Condições</TabsTrigger>
          <TabsTrigger value="demographics">Demografia</TabsTrigger>
          <TabsTrigger value="treatments">Tratamentos</TabsTrigger>
          <TabsTrigger value="publications">Publicações</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          {/* Cards com estatísticas chave */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Total de Pesquisas</CardDescription>
                <CardTitle className="text-3xl">78</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-green-600">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  <span>+12% vs. ano anterior</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Pacientes Participantes</CardDescription>
                <CardTitle className="text-3xl">1,245</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-green-600">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  <span>+8% vs. ano anterior</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Publicações Científicas</CardDescription>
                <CardTitle className="text-3xl">42</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-green-600">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  <span>+15% vs. ano anterior</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Taxa de Eficácia</CardDescription>
                <CardTitle className="text-3xl">75%</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center text-sm text-green-600">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  <span>+5% vs. ano anterior</span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Gráfico de evolução de pesquisas */}
            <Card>
              <CardHeader>
                <CardTitle>Evolução de Pesquisas</CardTitle>
                <CardDescription>Número de pesquisas iniciadas por mês</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={evolucaoPesquisas}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="pesquisas" 
                        stroke="#8884d8" 
                        activeDot={{ r: 8 }} 
                        name="Pesquisas" 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Gráfico de condições pesquisadas */}
            <Card>
              <CardHeader>
                <CardTitle>Condições Mais Pesquisadas</CardTitle>
                <CardDescription>Distribuição de pesquisas por condição médica</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={condicoesPesquisadas}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {condicoesPesquisadas.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Tabela de pesquisas recentes */}
          <Card>
            <CardHeader>
              <CardTitle>Pesquisas Recentes</CardTitle>
              <CardDescription>Listagem das pesquisas mais recentes</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Título</TableHead>
                    <TableHead>Pesquisador</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Pacientes</TableHead>
                    <TableHead>Data de Início</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pesquisasRecentes.map((pesquisa) => (
                    <TableRow key={pesquisa.id}>
                      <TableCell className="font-medium">{pesquisa.titulo}</TableCell>
                      <TableCell>{pesquisa.pesquisador}</TableCell>
                      <TableCell>
                        <Badge variant={
                          pesquisa.status === "Em andamento" ? "default" : 
                          pesquisa.status === "Concluída" ? "success" : 
                          "warning"
                        }>
                          {pesquisa.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{pesquisa.pacientes}</TableCell>
                      <TableCell>{new Date(pesquisa.data_inicio).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <FileText className="h-4 w-4 mr-1" />
                          Detalhes
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="conditions" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Condições por Categoria</CardTitle>
                <CardDescription>Agrupamento de condições médicas estudadas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={[
                      { category: "Neurológicas", count: 35 },
                      { category: "Psiquiátricas", count: 28 },
                      { category: "Dor", count: 27 },
                      { category: "Autoimunes", count: 15 },
                      { category: "Outras", count: 10 }
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="category" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="count" fill="#8884d8" name="Pesquisas" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Eficácia por Condição</CardTitle>
                <CardDescription>Comparação entre tratamentos tradicionais e com cannabis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={eficaciaComparativa}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="tradicional" fill="#60A5FA" name="Tratamento Tradicional (%)" />
                      <Bar dataKey="cannabis" fill="#10B981" name="Tratamento com Cannabis (%)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="demographics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Distribuição por Faixa Etária</CardTitle>
                <CardDescription>Pacientes participantes por idade</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={faixaEtariaPacientes}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {faixaEtariaPacientes.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Distribuição por Gênero</CardTitle>
                <CardDescription>Pacientes participantes por gênero</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Feminino', value: 52 },
                          { name: 'Masculino', value: 47 },
                          { name: 'Outro', value: 1 }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        <Cell fill="#EC4899" />
                        <Cell fill="#60A5FA" />
                        <Cell fill="#8B5CF6" />
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Distribuição Geográfica</CardTitle>
              <CardDescription>Pacientes por região do país</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart layout="vertical" data={[
                    { region: "Sudeste", count: 42 },
                    { region: "Sul", count: 25 },
                    { region: "Nordeste", count: 18 },
                    { region: "Centro-Oeste", count: 10 },
                    { region: "Norte", count: 5 }
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="region" type="category" />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="count" fill="#6366F1" name="Pacientes (%)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="treatments" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Tipos de Tratamentos</CardTitle>
                <CardDescription>Distribuição por tipo de tratamento com cannabis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={tiposTratamento}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {tiposTratamento.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Eficácia dos Tratamentos</CardTitle>
                <CardDescription>Nível de eficácia reportado pelos pacientes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={eficaciaTratamentos}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {eficaciaTratamentos.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Efeitos Secundários Reportados</CardTitle>
              <CardDescription>Frequência de efeitos secundários nos tratamentos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={[
                    { effect: "Sonolência", frequency: 35 },
                    { effect: "Boca seca", frequency: 30 },
                    { effect: "Tonturas", frequency: 20 },
                    { effect: "Alterações de apetite", frequency: 18 },
                    { effect: "Alterações de humor", frequency: 15 },
                    { effect: "Náusea", frequency: 12 },
                    { effect: "Diarreia", frequency: 10 }
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="effect" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="frequency" fill="#F59E0B" name="Frequência (%)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="publications" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Publicações por Ano</CardTitle>
                <CardDescription>Evolução de publicações científicas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={publicacoesAcademicas}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="ano" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="quantidade" fill="#6366F1" name="Publicações" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Publicações por Tipo</CardTitle>
                <CardDescription>Tipos de publicações científicas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Artigos revisados', value: 45 },
                          { name: 'Estudos clínicos', value: 30 },
                          { name: 'Revisões sistemáticas', value: 15 },
                          { name: 'Outros', value: 10 }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        <Cell fill="#8B5CF6" />
                        <Cell fill="#10B981" />
                        <Cell fill="#F59E0B" />
                        <Cell fill="#60A5FA" />
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Publicações por Área de Pesquisa</CardTitle>
              <CardDescription>Distribuição por área científica</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={[
                    { area: "Neurologia", count: 28 },
                    { area: "Farmacologia", count: 22 },
                    { area: "Psiquiatria", count: 18 },
                    { area: "Imunologia", count: 12 },
                    { area: "Oncologia", count: 10 },
                    { area: "Outras", count: 10 }
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="area" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="count" fill="#EC4899" name="Publicações" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}