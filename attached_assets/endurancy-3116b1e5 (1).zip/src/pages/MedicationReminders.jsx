
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { LembretesMedicacao } from '@/api/entities';
import { toast } from '@/components/ui/use-toast';
import {
  Calendar,
  Clock,
  Plus,
  Bell,
  Mail,
  Smartphone,
  Pill,
  Trash2,
  Save,
  Edit,
  Copy,
  ArrowLeft,
  Check,
  CheckCircle2,
  AlertCircle,
  X,
  ChevronRight,
  MessageSquare,
  MoreHorizontal,
  Settings,
  Pencil,
  PlusCircle,
  MinusCircle,
  Palette,
  HelpCircle,
  Phone,
  MessageCircle,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Popover,
  PopoverContent,
  PopoverTrigger
} from '@/components/ui/popover';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { Spinner } from '@/components/ui/spinner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function MedicationReminders() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [activeTab, setActiveTab] = useState('all');
  const [reminders, setReminders] = useState([]);
  const [selectedReminder, setSelectedReminder] = useState(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  
  // Form states for add/edit reminder
  const [formData, setFormData] = useState({
    medicamento: '',
    dosagem: '',
    instrucoes: '',
    quantidade_por_dose: 1,
    unidade: 'comprimido',
    com_alimento: false,
    frequencia: 'diario',
    dias_semana: [1, 2, 3, 4, 5],
    intervalo_dias: 1,
    data_inicio: format(new Date(), 'yyyy-MM-dd'),
    data_fim: '',
    horarios: ['08:00'],
    categoria: 'outro',
    cor: '#4f46e5',
    icone: 'pill',
    notificacoes: {
      tipo: ['app'],
      antecedencia_minutos: 15,
      som: 'default',
      vibracao: true,
      mensagem_personalizada: ''
    }
  });
  
  // Notification template suggestions
  const notificationTemplates = [
    "Hora de tomar {{medicamento}}! Dose: {{dosagem}}",
    "Lembrete: Não esqueça de tomar seu {{medicamento}} agora.",
    "É hora da sua medicação! Tome {{quantidade}} {{unidade}} de {{medicamento}}.",
    "Seu medicamento está programado para agora. Tome {{dosagem}} conforme orientado.",
    "Lembrete importante de medicação: {{medicamento}} - {{dosagem}}."
  ];

  useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      await loadReminders(user.id);
    } catch (error) {
      console.error("Erro ao carregar usuário", error);
      toast({
        title: "Erro de autenticação",
        description: "Você precisa estar logado para acessar esta página.",
        variant: "destructive",
      });
      navigate(createPageUrl("Access"));
    }
  };

  const loadReminders = async (userId) => {
    setLoading(true);
    try {
      const mockReminders = [
        {
          id: "1",
          medicamento: "Óleo CBD 2,5%",
          dosagem: "1 ml",
          instrucoes: "Usar por via sublingual",
          horarios: ["08:00", "20:00"],
          frequencia: "diario",
          data_inicio: "2023-08-15",
          status: "ativo",
          quantidade_por_dose: 1,
          unidade: "ml",
          categoria: "cannabis",
          cor: "#22c55e",
          notificacoes: {
            tipo: ["app", "email"],
            antecedencia_minutos: 10,
            mensagem_personalizada: "Hora de tomar seu óleo CBD!"
          },
          estatisticas: {
            taxa_adesao: 92
          }
        },
        {
          id: "2",
          medicamento: "Ibuprofeno",
          dosagem: "400mg",
          instrucoes: "Tomar após as refeições",
          horarios: ["12:00"],
          frequencia: "dias_especificos",
          dias_semana: [1, 3, 5],
          data_inicio: "2023-08-10",
          data_fim: "2023-09-10",
          status: "ativo",
          quantidade_por_dose: 1,
          unidade: "comprimido",
          com_alimento: true,
          categoria: "anti-inflamatorio",
          cor: "#f97316",
          notificacoes: {
            tipo: ["app"],
            antecedencia_minutos: 15
          },
          estatisticas: {
            taxa_adesao: 80
          }
        },
        {
          id: "3",
          medicamento: "Loratadina",
          dosagem: "10mg",
          horarios: ["10:00"],
          frequencia: "diario",
          data_inicio: "2023-08-01",
          status: "ativo",
          quantidade_por_dose: 1,
          unidade: "comprimido",
          categoria: "outro",
          cor: "#3b82f6",
          notificacoes: {
            tipo: ["app", "sms"],
            antecedencia_minutos: 5,
            mensagem_personalizada: "Lembrete: tomar sua medicação para alergia"
          },
          estatisticas: {
            taxa_adesao: 95
          }
        }
      ];
      
      setReminders(mockReminders);
    } catch (error) {
      console.error("Erro ao carregar lembretes", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar seus lembretes de medicação.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddReminder = async () => {
    if (!formData.medicamento) {
      toast({
        title: "Erro",
        description: "Por favor, informe o nome do medicamento.",
        variant: "destructive",
      });
      return;
    }

    if (formData.horarios.length === 0) {
      toast({
        title: "Erro",
        description: "Por favor, adicione pelo menos um horário.",
        variant: "destructive",
      });
      return;
    }

    try {
      const newReminder = {
        id: `${Date.now()}`,
        ...formData,
        status: "ativo",
        estatisticas: {
          taxa_adesao: 100
        }
      };
      
      setReminders([...reminders, newReminder]);
      setShowAddDialog(false);
      
      toast({
        title: "Lembrete criado",
        description: `Lembrete para ${formData.medicamento} criado com sucesso.`,
      });
      
      setFormData({
        medicamento: '',
        dosagem: '',
        instrucoes: '',
        quantidade_por_dose: 1,
        unidade: 'comprimido',
        com_alimento: false,
        frequencia: 'diario',
        dias_semana: [1, 2, 3, 4, 5],
        intervalo_dias: 1,
        data_inicio: format(new Date(), 'yyyy-MM-dd'),
        data_fim: '',
        horarios: ['08:00'],
        categoria: 'outro',
        cor: '#4f46e5',
        icone: 'pill',
        notificacoes: {
          tipo: ['app'],
          antecedencia_minutos: 15,
          som: 'default',
          vibracao: true,
          mensagem_personalizada: ''
        }
      });
      
    } catch (error) {
      console.error("Erro ao criar lembrete", error);
      toast({
        title: "Erro",
        description: "Não foi possível criar o lembrete. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleUpdateReminder = async () => {
    if (!selectedReminder) return;
    
    try {
      const updatedReminders = reminders.map(reminder => 
        reminder.id === selectedReminder.id 
          ? { ...reminder, ...formData } 
          : reminder
      );
      
      setReminders(updatedReminders);
      setShowEditDialog(false);
      
      toast({
        title: "Lembrete atualizado",
        description: `Lembrete para ${formData.medicamento} atualizado com sucesso.`,
      });
      
    } catch (error) {
      console.error("Erro ao atualizar lembrete", error);
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o lembrete. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteReminder = async (id) => {
    try {
      const filteredReminders = reminders.filter(reminder => reminder.id !== id);
      setReminders(filteredReminders);
      
      toast({
        title: "Lembrete removido",
        description: "O lembrete foi removido com sucesso.",
      });
      
    } catch (error) {
      console.error("Erro ao remover lembrete", error);
      toast({
        title: "Erro",
        description: "Não foi possível remover o lembrete. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleEditReminder = (reminder) => {
    setSelectedReminder(reminder);
    setFormData({
      medicamento: reminder.medicamento,
      dosagem: reminder.dosagem || '',
      instrucoes: reminder.instrucoes || '',
      quantidade_por_dose: reminder.quantidade_por_dose || 1,
      unidade: reminder.unidade || 'comprimido',
      com_alimento: reminder.com_alimento || false,
      frequencia: reminder.frequencia || 'diario',
      dias_semana: reminder.dias_semana || [1, 2, 3, 4, 5],
      intervalo_dias: reminder.intervalo_dias || 1,
      data_inicio: reminder.data_inicio || format(new Date(), 'yyyy-MM-dd'),
      data_fim: reminder.data_fim || '',
      horarios: reminder.horarios || ['08:00'],
      categoria: reminder.categoria || 'outro',
      cor: reminder.cor || '#4f46e5',
      icone: reminder.icone || 'pill',
      notificacoes: {
        tipo: reminder.notificacoes?.tipo || ['app'],
        antecedencia_minutos: reminder.notificacoes?.antecedencia_minutos || 15,
        som: reminder.notificacoes?.som || 'default',
        vibracao: reminder.notificacoes?.vibracao !== false,
        mensagem_personalizada: reminder.notificacoes?.mensagem_personalizada || ''
      }
    });
    setShowEditDialog(true);
  };

  const addTimeSlot = () => {
    setFormData({
      ...formData,
      horarios: [...formData.horarios, '12:00']
    });
  };

  const removeTimeSlot = (index) => {
    const updatedHorarios = [...formData.horarios];
    updatedHorarios.splice(index, 1);
    setFormData({
      ...formData,
      horarios: updatedHorarios
    });
  };

  const updateTimeSlot = (index, value) => {
    const updatedHorarios = [...formData.horarios];
    updatedHorarios[index] = value;
    setFormData({
      ...formData,
      horarios: updatedHorarios
    });
  };

  const updateNotificationType = (type, checked) => {
    const currentTypes = formData.notificacoes.tipo || [];
    let newTypes;

    if (checked) {
      newTypes = [...currentTypes, type];
    } else {
      newTypes = currentTypes.filter(t => t !== type);
    }

    setFormData({
      ...formData,
      notificacoes: {
        ...formData.notificacoes,
        tipo: newTypes
      }
    });
  };

  const handleSelectNotificationTemplate = (template) => {
    let message = template
      .replace('{{medicamento}}', formData.medicamento || 'seu medicamento')
      .replace('{{dosagem}}', formData.dosagem || '')
      .replace('{{quantidade}}', formData.quantidade_por_dose?.toString() || '1')
      .replace('{{unidade}}', formData.unidade || 'dose');
      
    setFormData({
      ...formData,
      notificacoes: {
        ...formData.notificacoes,
        mensagem_personalizada: message
      }
    });
  };

  const filteredReminders = activeTab === 'all' 
    ? reminders 
    : reminders.filter(r => r.categoria === activeTab);

  if (loading) {
    return (
      <div className="container mx-auto py-12 flex justify-center items-center">
        <Spinner className="mr-2" />
        <span>Carregando lembretes de medicação...</span>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Lembretes de Medicação</h1>
            <p className="text-gray-500 mt-1">
              Gerencie e personalize lembretes para seus medicamentos
            </p>
          </div>
        </div>
        
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Novo Lembrete
        </Button>
      </div>

      <div className="mb-6">
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="all">Todos</TabsTrigger>
            <TabsTrigger value="cannabis">Cannabis</TabsTrigger>
            <TabsTrigger value="analgesico">Analgésicos</TabsTrigger>
            <TabsTrigger value="outro">Outros</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {filteredReminders.length === 0 ? (
        <Card className="text-center p-8">
          <Pill className="w-12 h-12 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium">Nenhum lembrete encontrado</h3>
          <p className="text-gray-500 mt-2 mb-6 max-w-md mx-auto">
            Você ainda não tem lembretes de medicação configurados.
            Adicione seu primeiro lembrete para ajudar a manter sua rotina de medicação.
          </p>
          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Adicionar Lembrete
          </Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredReminders.map((reminder) => (
            <Card key={reminder.id} className="overflow-hidden">
              <div 
                className="h-2" 
                style={{ backgroundColor: reminder.cor || '#4f46e5' }}
              />
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Pill className="h-4 w-4" style={{ color: reminder.cor || '#4f46e5' }} />
                      {reminder.medicamento}
                    </CardTitle>
                    <CardDescription>
                      {reminder.dosagem && `${reminder.dosagem} - `}
                      {reminder.frequencia === 'diario' && 'Diariamente'}
                      {reminder.frequencia === 'dias_especificos' && 'Dias específicos'}
                      {reminder.frequencia === 'intervalo_dias' && `A cada ${reminder.intervalo_dias} dias`}
                    </CardDescription>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleEditReminder(reminder)}>
                        <Edit className="h-4 w-4 mr-2" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Copy className="h-4 w-4 mr-2" />
                        Duplicar
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        className="text-red-600"
                        onClick={() => handleDeleteReminder(reminder.id)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Remover
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <Clock className="h-4 w-4 text-gray-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">Horários:</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {reminder.horarios.map((horario, idx) => (
                          <Badge key={idx} variant="outline">
                            {horario}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  {reminder.instrucoes && (
                    <div className="flex items-start gap-2">
                      <MessageSquare className="h-4 w-4 text-gray-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Instruções:</p>
                        <p className="text-sm text-gray-600">{reminder.instrucoes}</p>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex items-start gap-2">
                    <Bell className="h-4 w-4 text-gray-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">Notificações:</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {reminder.notificacoes.tipo.includes('app') && 
                          <Badge variant="secondary" className="bg-blue-100 text-blue-800">App</Badge>
                        }
                        {reminder.notificacoes.tipo.includes('email') && 
                          <Badge variant="secondary" className="bg-purple-100 text-purple-800">Email</Badge>
                        }
                        {reminder.notificacoes.tipo.includes('sms') && 
                          <Badge variant="secondary" className="bg-green-100 text-green-800">SMS</Badge>
                        }
                        {reminder.notificacoes.tipo.includes('whatsapp') && 
                          <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">WhatsApp</Badge>
                        }
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                <div className="w-full">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs text-gray-500">Taxa de adesão</span>
                    <span className="text-xs font-medium">
                      {reminder.estatisticas?.taxa_adesao || 0}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div 
                      className="h-1.5 rounded-full" 
                      style={{ 
                        width: `${reminder.estatisticas?.taxa_adesao || 0}%`,
                        backgroundColor: reminder.cor || '#4f46e5'
                      }}
                    />
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* Add New Reminder Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Novo Lembrete de Medicação</DialogTitle>
            <DialogDescription>
              Configure um novo lembrete para ajudar a seguir seu tratamento medicamentoso.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 my-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="medicamento">Nome do Medicamento*</Label>
                <Input
                  id="medicamento"
                  value={formData.medicamento}
                  onChange={(e) => setFormData({...formData, medicamento: e.target.value})}
                  placeholder="Ex: Óleo CBD"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="dosagem">Dosagem</Label>
                <Input
                  id="dosagem"
                  value={formData.dosagem}
                  onChange={(e) => setFormData({...formData, dosagem: e.target.value})}
                  placeholder="Ex: 1ml ou 10mg"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quantidade">Quantidade por Dose</Label>
                <div className="flex items-center">
                  <Input
                    id="quantidade"
                    type="number"
                    min="0.1"
                    step="0.1"
                    value={formData.quantidade_por_dose}
                    onChange={(e) => setFormData({...formData, quantidade_por_dose: parseFloat(e.target.value)})}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="unidade">Unidade</Label>
                <Select
                  value={formData.unidade}
                  onValueChange={(value) => setFormData({...formData, unidade: value})}
                >
                  <SelectTrigger id="unidade">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="comprimido">Comprimido</SelectItem>
                    <SelectItem value="cápsula">Cápsula</SelectItem>
                    <SelectItem value="ml">Mililitro (ml)</SelectItem>
                    <SelectItem value="gotas">Gotas</SelectItem>
                    <SelectItem value="unidade">Unidade</SelectItem>
                    <SelectItem value="spray">Spray</SelectItem>
                    <SelectItem value="adesivo">Adesivo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="categoria">Categoria</Label>
                <Select
                  value={formData.categoria}
                  onValueChange={(value) => setFormData({...formData, categoria: value})}
                >
                  <SelectTrigger id="categoria">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cannabis">Cannabis</SelectItem>
                    <SelectItem value="analgesico">Analgésico</SelectItem>
                    <SelectItem value="antibiotico">Antibiótico</SelectItem>
                    <SelectItem value="anti-inflamatorio">Anti-inflamatório</SelectItem>
                    <SelectItem value="antidepressivo">Antidepressivo</SelectItem>
                    <SelectItem value="ansiolítico">Ansiolítico</SelectItem>
                    <SelectItem value="outro">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="instrucoes">Instruções</Label>
              <Textarea
                id="instrucoes"
                value={formData.instrucoes}
                onChange={(e) => setFormData({...formData, instrucoes: e.target.value})}
                placeholder="Ex: Tomar com água, usar por via sublingual, etc."
                rows={2}
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="com_alimento"
                checked={formData.com_alimento}
                onCheckedChange={(checked) => setFormData({...formData, com_alimento: checked})}
              />
              <label
                htmlFor="com_alimento"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Tomar com alimento
              </label>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <Label htmlFor="frequencia">Frequência</Label>
              <Select
                value={formData.frequencia}
                onValueChange={(value) => setFormData({...formData, frequencia: value})}
              >
                <SelectTrigger id="frequencia">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="diario">Diariamente</SelectItem>
                  <SelectItem value="dias_especificos">Dias específicos</SelectItem>
                  <SelectItem value="intervalo_dias">Intervalo de dias</SelectItem>
                  <SelectItem value="conforme_necessario">Conforme necessário</SelectItem>
                </SelectContent>
              </Select>
              
              {formData.frequencia === 'dias_especificos' && (
                <div className="mt-2 space-y-2">
                  <Label>Dias da Semana</Label>
                  <div className="flex flex-wrap gap-2">
                    {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day, index) => (
                      <Button
                        key={index}
                        type="button"
                        variant={formData.dias_semana.includes(index) ? "default" : "outline"}
                        className="w-12 h-10 p-0"
                        onClick={() => {
                          const updatedDays = formData.dias_semana.includes(index)
                            ? formData.dias_semana.filter(d => d !== index)
                            : [...formData.dias_semana, index];
                          setFormData({...formData, dias_semana: updatedDays});
                        }}
                      >
                        {day}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
              
              {formData.frequencia === 'intervalo_dias' && (
                <div className="mt-2">
                  <Label htmlFor="intervalo_dias">A cada quantos dias</Label>
                  <Input
                    id="intervalo_dias"
                    type="number"
                    min="1"
                    value={formData.intervalo_dias}
                    onChange={(e) => setFormData({...formData, intervalo_dias: parseInt(e.target.value)})}
                  />
                </div>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="data_inicio">Data de Início</Label>
                <Input
                  id="data_inicio"
                  type="date"
                  value={formData.data_inicio}
                  onChange={(e) => setFormData({...formData, data_inicio: e.target.value})}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="data_fim">
                  Data de Término
                  <span className="text-gray-500 text-xs ml-1">(opcional)</span>
                </Label>
                <Input
                  id="data_fim"
                  type="date"
                  value={formData.data_fim}
                  onChange={(e) => setFormData({...formData, data_fim: e.target.value})}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Horários de Administração*</Label>
                <Button type="button" variant="outline" size="sm" onClick={addTimeSlot}>
                  <Plus className="h-3.5 w-3.5 mr-1" />
                  Adicionar Horário
                </Button>
              </div>
              
              <div className="space-y-2">
                {formData.horarios.map((horario, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      type="time"
                      value={horario}
                      onChange={(e) => updateTimeSlot(index, e.target.value)}
                      className="w-40"
                    />
                    {formData.horarios.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeTimeSlot(index)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex items-center justify-between mt-4">
              <h3 className="text-sm font-medium">Configurações Avançadas</h3>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setShowAdvancedSettings(!showAdvancedSettings)}
              >
                {showAdvancedSettings ? 'Ocultar' : 'Mostrar'}
                <ChevronRight className={`ml-2 h-4 w-4 transition-transform ${showAdvancedSettings ? 'rotate-90' : ''}`} />
              </Button>
            </div>
            
            {showAdvancedSettings && (
              <div className="bg-gray-50 p-4 rounded-lg space-y-4">
                <h3 className="font-medium text-lg mb-4">Personalização de Notificações</h3>
                
                <div className="space-y-2">
                  <Label className="text-base">Métodos de Notificação</Label>
                  <p className="text-sm text-gray-500 mb-2">Selecione como deseja receber os lembretes</p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="notif_app"
                        checked={formData.notificacoes.tipo.includes('app')}
                        onCheckedChange={(checked) => updateNotificationType('app', checked)}
                      />
                      <label
                        htmlFor="notif_app"
                        className="text-sm font-medium leading-none flex items-center gap-1"
                      >
                        <Bell className="h-3.5 w-3.5 text-blue-500" />
                        Notificação no Aplicativo
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="notif_email"
                        checked={formData.notificacoes.tipo.includes('email')}
                        onCheckedChange={(checked) => updateNotificationType('email', checked)}
                      />
                      <label
                        htmlFor="notif_email"
                        className="text-sm font-medium leading-none flex items-center gap-1"
                      >
                        <Mail className="h-3.5 w-3.5 text-purple-500" />
                        Email
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="notif_sms"
                        checked={formData.notificacoes.tipo.includes('sms')}
                        onCheckedChange={(checked) => updateNotificationType('sms', checked)}
                      />
                      <label
                        htmlFor="notif_sms"
                        className="text-sm font-medium leading-none flex items-center gap-1"
                      >
                        <Phone className="h-3.5 w-3.5 text-green-500" />
                        SMS
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="notif_whatsapp"
                        checked={formData.notificacoes.tipo.includes('whatsapp')}
                        onCheckedChange={(checked) => updateNotificationType('whatsapp', checked)}
                      />
                      <label
                        htmlFor="notif_whatsapp"
                        className="text-sm font-medium leading-none flex items-center gap-1"
                      >
                        <MessageCircle className="h-3.5 w-3.5 text-emerald-500" />
                        WhatsApp
                      </label>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="antecedencia">Antecedência do Lembrete</Label>
                    <Select
                      value={formData.notificacoes.antecedencia_minutos.toString()}
                      onValueChange={(value) => setFormData({
                        ...formData, 
                        notificacoes: {
                          ...formData.notificacoes,
                          antecedencia_minutos: parseInt(value)
                        }
                      })}
                    >
                      <SelectTrigger id="antecedencia">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">No momento exato</SelectItem>
                        <SelectItem value="5">5 minutos antes</SelectItem>
                        <SelectItem value="10">10 minutos antes</SelectItem>
                        <SelectItem value="15">15 minutos antes</SelectItem>
                        <SelectItem value="30">30 minutos antes</SelectItem>
                        <SelectItem value="60">1 hora antes</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="som">Som da Notificação</Label>
                    <Select
                      value={formData.notificacoes.som}
                      onValueChange={(value) => setFormData({
                        ...formData, 
                        notificacoes: {
                          ...formData.notificacoes,
                          som: value
                        }
                      })}
                    >
                      <SelectTrigger id="som">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="default">Padrão</SelectItem>
                        <SelectItem value="bell">Campainha</SelectItem>
                        <SelectItem value="chime">Sino</SelectItem>
                        <SelectItem value="alert">Alerta</SelectItem>
                        <SelectItem value="soft">Suave</SelectItem>
                        <SelectItem value="none">Sem som</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="vibracao"
                    checked={formData.notificacoes.vibracao}
                    onCheckedChange={(checked) => setFormData({
                      ...formData, 
                      notificacoes: {
                        ...formData.notificacoes,
                        vibracao: checked
                      }
                    })}
                  />
                  <Label htmlFor="vibracao">Vibração em dispositivos móveis</Label>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="mensagem_personalizada">Mensagem Personalizada</Label>
                  <div className="flex justify-between items-center">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="sm">
                          Usar Modelo
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-80">
                        <div className="space-y-4">
                          <h4 className="font-medium">Modelos de Mensagem</h4>
                          <div className="space-y-2">
                            {notificationTemplates.map((template, idx) => (
                              <div
                                key={idx}
                                className="p-2 text-sm border rounded-md cursor-pointer hover:bg-gray-50"
                                onClick={() => handleSelectNotificationTemplate(template)}
                              >
                                {template}
                              </div>
                            ))}
                          </div>
                          <p className="text-xs text-gray-500">
                            Clique em um modelo para aplicá-lo. Use {{medicamento}}, {{dosagem}}, 
                            {{quantidade}} como marcadores que serão substituídos.
                          </p>
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <Textarea
                    id="mensagem_personalizada"
                    value={formData.notificacoes.mensagem_personalizada}
                    onChange={(e) => setFormData({
                      ...formData, 
                      notificacoes: {
                        ...formData.notificacoes,
                        mensagem_personalizada: e.target.value
                      }
                    })}
                    placeholder="Ex: Hora de tomar seu medicamento! Lembre-se de seguir as instruções médicas."
                    rows={3}
                  />
                  <p className="text-xs text-gray-500">
                    Personalize a mensagem que você receberá com seus lembretes.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cor">Cor de Identificação</Label>
                  <div className="flex space-x-2">
                    {['#4f46e5', '#22c55e', '#f97316', '#ef4444', '#3b82f6', '#8b5cf6', '#ec4899'].map(color => (
                      <button
                        key={color}
                        type="button"
                        className={`w-8 h-8 rounded-full ${formData.cor === color ? 'ring-2 ring-offset-2 ring-gray-400' : ''}`}
                        style={{ backgroundColor: color }}
                        onClick={() => setFormData({...formData, cor: color})}
                      />
                    ))}
                    <input
                      type="color"
                      value={formData.cor}
                      onChange={(e) => setFormData({...formData, cor: e.target.value})}
                      className="w-8 h-8 p-0 border-0"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddReminder}>
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Lembrete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Reminder Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Editar Lembrete</DialogTitle>
            <DialogDescription>
              Atualize as configurações do seu lembrete de medicação.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 my-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="medicamento">Nome do Medicamento*</Label>
                <Input
                  id="medicamento"
                  value={formData.medicamento}
                  onChange={(e) => setFormData({...formData, medicamento: e.target.value})}
                  placeholder="Ex: Óleo CBD"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="dosagem">Dosagem</Label>
                <Input
                  id="dosagem"
                  value={formData.dosagem}
                  onChange={(e) => setFormData({...formData, dosagem: e.target.value})}
                  placeholder="Ex: 1ml ou 10mg"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quantidade">Quantidade por Dose</Label>
                <div className="flex items-center">
                  <Input
                    id="quantidade"
                    type="number"
                    min="0.1"
                    step="0.1"
                    value={formData.quantidade_por_dose}
                    onChange={(e) => setFormData({...formData, quantidade_por_dose: parseFloat(e.target.value)})}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="unidade">Unidade</Label>
                <Select
                  value={formData.unidade}
                  onValueChange={(value) => setFormData({...formData, unidade: value})}
                >
                  <SelectTrigger id="unidade">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="comprimido">Comprimido</SelectItem>
                    <SelectItem value="cápsula">Cápsula</SelectItem>
                    <SelectItem value="ml">Mililitro (ml)</SelectItem>
                    <SelectItem value="gotas">Gotas</SelectItem>
                    <SelectItem value="unidade">Unidade</SelectItem>
                    <SelectItem value="spray">Spray</SelectItem>
                    <SelectItem value="adesivo">Adesivo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="categoria">Categoria</Label>
                <Select
                  value={formData.categoria}
                  onValueChange={(value) => setFormData({...formData, categoria: value})}
                >
                  <SelectTrigger id="categoria">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cannabis">Cannabis</SelectItem>
                    <SelectItem value="analgesico">Analgésico</SelectItem>
                    <SelectItem value="antibiotico">Antibiótico</SelectItem>
                    <SelectItem value="anti-inflamatorio">Anti-inflamatório</SelectItem>
                    <SelectItem value="antidepressivo">Antidepressivo</SelectItem>
                    <SelectItem value="ansiolítico">Ansiolítico</SelectItem>
                    <SelectItem value="outro">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="instrucoes">Instruções</Label>
              <Textarea
                id="instrucoes"
                value={formData.instrucoes}
                onChange={(e) => setFormData({...formData, instrucoes: e.target.value})}
                placeholder="Ex: Tomar com água, usar por via sublingual, etc."
                rows={2}
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="com_alimento"
                checked={formData.com_alimento}
                onCheckedChange={(checked) => setFormData({...formData, com_alimento: checked})}
              />
              <label
                htmlFor="com_alimento"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Tomar com alimento
              </label>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <Label htmlFor="frequencia">Frequência</Label>
              <Select
                value={formData.frequencia}
                onValueChange={(value) => setFormData({...formData, frequencia: value})}
              >
                <SelectTrigger id="frequencia">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="diario">Diariamente</SelectItem>
                  <SelectItem value="dias_especificos">Dias específicos</SelectItem>
                  <SelectItem value="intervalo_dias">Intervalo de dias</SelectItem>
                  <SelectItem value="conforme_necessario">Conforme necessário</SelectItem>
                </SelectContent>
              </Select>
              
              {formData.frequencia === 'dias_especificos' && (
                <div className="mt-2 space-y-2">
                  <Label>Dias da Semana</Label>
                  <div className="flex flex-wrap gap-2">
                    {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day, index) => (
                      <Button
                        key={index}
                        type="button"
                        variant={formData.dias_semana.includes(index) ? "default" : "outline"}
                        className="w-12 h-10 p-0"
                        onClick={() => {
                          const updatedDays = formData.dias_semana.includes(index)
                            ? formData.dias_semana.filter(d => d !== index)
                            : [...formData.dias_semana, index];
                          setFormData({...formData, dias_semana: updatedDays});
                        }}
                      >
                        {day}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
              
              {formData.frequencia === 'intervalo_dias' && (
                <div className="mt-2">
                  <Label htmlFor="intervalo_dias">A cada quantos dias</Label>
                  <Input
                    id="intervalo_dias"
                    type="number"
                    min="1"
                    value={formData.intervalo_dias}
                    onChange={(e) => setFormData({...formData, intervalo_dias: parseInt(e.target.value)})}
                  />
                </div>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="data_inicio">Data de Início</Label>
                <Input
                  id="data_inicio"
                  type="date"
                  value={formData.data_inicio}
                  onChange={(e) => setFormData({...formData, data_inicio: e.target.value})}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="data_fim">
                  Data de Término
                  <span className="text-gray-500 text-xs ml-1">(opcional)</span>
                </Label>
                <Input
                  id="data_fim"
                  type="date"
                  value={formData.data_fim}
                  onChange={(e) => setFormData({...formData, data_fim: e.target.value})}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Horários de Administração*</Label>
                <Button type="button" variant="outline" size="sm" onClick={addTimeSlot}>
                  <Plus className="h-3.5 w-3.5 mr-1" />
                  Adicionar Horário
                </Button>
              </div>
              
              <div className="space-y-2">
                {formData.horarios.map((horario, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      type="time"
                      value={horario}
                      onChange={(e) => updateTimeSlot(index, e.target.value)}
                      className="w-40"
                    />
                    {formData.horarios.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeTimeSlot(index)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex items-center justify-between mt-4">
              <h3 className="text-sm font-medium">Configurações Avançadas</h3>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setShowAdvancedSettings(!showAdvancedSettings)}
              >
                {showAdvancedSettings ? 'Ocultar' : 'Mostrar'}
                <ChevronRight className={`ml-2 h-4 w-4 transition-transform ${showAdvancedSettings ? 'rotate-90' : ''}`} />
              </Button>
            </div>
            
            {showAdvancedSettings && (
              <div className="bg-gray-50 p-4 rounded-lg space-y-4">
                <h3 className="font-medium text-lg mb-4">Personalização de Notificações</h3>
                
                <div className="space-y-2">
                  <Label className="text-base">Métodos de Notificação</Label>
                  <p className="text-sm text-gray-500 mb-2">Selecione como deseja receber os lembretes</p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="notif_app"
                        checked={formData.notificacoes.tipo.includes('app')}
                        onCheckedChange={(checked) => updateNotificationType('app', checked)}
                      />
                      <label
                        htmlFor="notif_app"
                        className="text-sm font-medium leading-none flex items-center gap-1"
                      >
                        <Bell className="h-3.5 w-3.5 text-blue-500" />
                        Notificação no Aplicativo
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="notif_email"
                        checked={formData.notificacoes.tipo.includes('email')}
                        onCheckedChange={(checked) => updateNotificationType('email', checked)}
                      />
                      <label
                        htmlFor="notif_email"
                        className="text-sm font-medium leading-none flex items-center gap-1"
                      >
                        <Mail className="h-3.5 w-3.5 text-purple-500" />
                        Email
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="notif_sms"
                        checked={formData.notificacoes.tipo.includes('sms')}
                        onCheckedChange={(checked) => updateNotificationType('sms', checked)}
                      />
                      <label
                        htmlFor="notif_sms"
                        className="text-sm font-medium leading-none flex items-center gap-1"
                      >
                        <Phone className="h-3.5 w-3.5 text-green-500" />
                        SMS
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="notif_whatsapp"
                        checked={formData.notificacoes.tipo.includes('whatsapp')}
                        onCheckedChange={(checked) => updateNotificationType('whatsapp', checked)}
                      />
                      <label
                        htmlFor="notif_whatsapp"
                        className="text-sm font-medium leading-none flex items-center gap-1"
                      >
                        <MessageCircle className="h-3.5 w-3.5 text-emerald-500" />
                        WhatsApp
                      </label>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="antecedencia">Antecedência do Lembrete</Label>
                    <Select
                      value={formData.notificacoes.antecedencia_minutos.toString()}
                      onValueChange={(value) => setFormData({
                        ...formData, 
                        notificacoes: {
                          ...formData.notificacoes,
                          antecedencia_minutos: parseInt(value)
                        }
                      })}
                    >
                      <SelectTrigger id="antecedencia">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">No momento exato</SelectItem>
                        <SelectItem value="5">5 minutos antes</SelectItem>
                        <SelectItem value="10">10 minutos antes</SelectItem>
                        <SelectItem value="15">15 minutos antes</SelectItem>
                        <SelectItem value="30">30 minutos antes</SelectItem>
                        <SelectItem value="60">1 hora antes</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="som">Som da Notificação</Label>
                    <Select
                      value={formData.notificacoes.som}
                      onValueChange={(value) => setFormData({
                        ...formData, 
                        notificacoes: {
                          ...formData.notificacoes,
                          som: value
                        }
                      })}
                    >
                      <SelectTrigger id="som">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="default">Padrão</SelectItem>
                        <SelectItem value="bell">Campainha</SelectItem>
                        <SelectItem value="chime">Sino</SelectItem>
                        <SelectItem value="alert">Alerta</SelectItem>
                        <SelectItem value="soft">Suave</SelectItem>
                        <SelectItem value="none">Sem som</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="vibracao"
                    checked={formData.notificacoes.vibracao}
                    onCheckedChange={(checked) => setFormData({
                      ...formData, 
                      notificacoes: {
                        ...formData.notificacoes,
                        vibracao: checked
                      }
                    })}
                  />
                  <Label htmlFor="vibracao">Vibração em dispositivos móveis</Label>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="mensagem_personalizada">Mensagem Personalizada</Label>
                  <div className="flex justify-between items-center">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="sm">
                          Usar Modelo
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-80">
                        <div className="space-y-4">
                          <h4 className="font-medium">Modelos de Mensagem</h4>
                          <div className="space-y-2">
                            {notificationTemplates.map((template, idx) => (
                              <div
                                key={idx}
                                className="p-2 text-sm border rounded-md cursor-pointer hover:bg-gray-50"
                                onClick={() => handleSelectNotificationTemplate(template)}
                              >
                                {template}
                              </div>
                            ))}
                          </div>
                          <p className="text-xs text-gray-500">
                            Clique em um modelo para aplicá-lo. Use {{medicamento}}, {{dosagem}}, 
                            {{quantidade}} como marcadores que serão substituídos.
                          </p>
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <Textarea
                    id="mensagem_personalizada"
                    value={formData.notificacoes.mensagem_personalizada}
                    onChange={(e) => setFormData({
                      ...formData, 
                      notificacoes: {
                        ...formData.notificacoes,
                        mensagem_personalizada: e.target.value
                      }
                    })}
                    placeholder="Ex: Hora de tomar seu medicamento! Lembre-se de seguir as instruções médicas."
                    rows={3}
                  />
                  <p className="text-xs text-gray-500">
                    Personalize a mensagem que você receberá com seus lembretes.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cor">Cor de Identificação</Label>
                  <div className="flex space-x-2">
                    {['#4f46e5', '#22c55e', '#f97316', '#ef4444', '#3b82f6', '#8b5cf6', '#ec4899'].map(color => (
                      <button
                        key={color}
                        type="button"
                        className={`w-8 h-8 rounded-full ${formData.cor === color ? 'ring-2 ring-offset-2 ring-gray-400' : ''}`}
                        style={{ backgroundColor: color }}
                        onClick={() => setFormData({...formData, cor: color})}
                      />
                    ))}
                    <input
                      type="color"
                      value={formData.cor}
                      onChange={(e) => setFormData({...formData, cor: e.target.value})}
                      className="w-8 h-8 p-0 border-0"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleUpdateReminder}>
              <Save className="w-4 h-4 mr-2" />
              Salvar Alterações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
