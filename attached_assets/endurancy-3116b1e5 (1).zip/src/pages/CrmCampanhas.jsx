import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  BadgePercent, 
  Search, 
  Filter, 
  ChevronDown,
  Mail,
  Smartphone,
  SendHorizonal,
  Bell,
  Clock,
  Calendar,
  Users,
  CheckCircle,
  XCircle,
  Pause,
  MoreHorizontal,
  Edit,
  Copy,
  Trash,
  Eye,
  RefreshCw,
  Plus,
  ArrowUpDown,
  BarChart4
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Dados simulados para campanhas
const mockCampaigns = [
  {
    id: "1",
    title: "Newsletter Mensal - Outubro",
    type: "email",
    subject: "Novidades e Promoções de Outubro",
    status: "sent",
    created_date: "2023-09-28T10:20:00",
    sent_date: "2023-10-01T09:00:00",
    audience: "all_patients",
    recipients_count: 1235,
    open_rate: 42.5,
    click_rate: 18.2,
    scheduled: false
  },
  {
    id: "2",
    title: "Lembrete de Consulta",
    type: "sms",
    content: "Lembrete: Sua consulta está agendada para amanhã às 14h. Qualquer dúvida, entre em contato.",
    status: "sending",
    created_date: "2023-10-15T14:30:00",
    audience: "custom_filter",
    recipients_count: 87,
    delivery_rate: 95.4,
    scheduled: false
  },
  {
    id: "3",
    title: "Black Friday - Promoção Antecipada",
    type: "email",
    subject: "Promoção Exclusiva: 30% OFF em Produtos Selecionados",
    status: "scheduled",
    created_date: "2023-10-20T16:45:00",
    scheduled_date: "2023-11-20T08:00:00",
    audience: "all_patients",
    recipients_count: 1250,
    open_rate: null,
    click_rate: null,
    scheduled: true
  },
  {
    id: "4",
    title: "Novos Produtos - Lançamento",
    type: "notification",
    content: "Conheça nossa nova linha de produtos naturais!",
    status: "draft",
    created_date: "2023-10-25T11:15:00",
    audience: "active_patients",
    recipients_count: 980,
    scheduled: false
  },
  {
    id: "5",
    title: "Lembrete de Renovação de Prescrição",
    type: "email",
    subject: "Sua prescrição está prestes a expirar",
    status: "recurring",
    created_date: "2023-09-15T09:20:00",
    last_sent_date: "2023-10-15T09:00:00",
    next_send_date: "2023-11-15T09:00:00",
    recurring_type: "monthly",
    audience: "custom_filter",
    recipients_count: 158,
    open_rate: 56.3,
    click_rate: 22.8,
    scheduled: true
  },
  {
    id: "6",
    title: "Feedback pós-compra",
    type: "email",
    subject: "Como foi sua experiência?",
    status: "paused",
    created_date: "2023-10-10T13:40:00",
    audience: "custom_filter",
    recipients_count: 430,
    open_rate: 38.6,
    click_rate: 12.3,
    scheduled: true
  }
];

export default function CrmCampanhas() {
  const [campaigns, setCampaigns] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [sortBy, setSortBy] = useState("created_date");
  const [sortDirection, setSortDirection] = useState("desc");
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [campaignToDelete, setCampaignToDelete] = useState(null);

  useEffect(() => {
    loadCampaigns();
  }, []);

  const loadCampaigns = async () => {
    setIsLoading(true);
    try {
      // Simulando o carregamento dos dados
      setTimeout(() => {
        setCampaigns(mockCampaigns);
        setIsLoading(false);
      }, 800);
    } catch (error) {
      console.error("Erro ao carregar campanhas:", error);
      setIsLoading(false);
    }
  };

  const handleDeleteConfirm = () => {
    setCampaigns(campaigns.filter(campaign => campaign.id !== campaignToDelete));
    setShowDeleteDialog(false);
    setCampaignToDelete(null);
  };

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortBy(field);
      setSortDirection("desc");
    }
  };

  const getFilteredCampaigns = () => {
    let filtered = [...campaigns];

    // Filtrar por tab
    if (activeTab !== "all") {
      filtered = filtered.filter(campaign => {
        if (activeTab === "draft") return campaign.status === "draft";
        if (activeTab === "scheduled") return campaign.status === "scheduled" || campaign.status === "recurring";
        if (activeTab === "sent") return campaign.status === "sent";
        if (activeTab === "active") return campaign.status === "sending" || campaign.status === "recurring";
        return true;
      });
    }

    // Filtrar por pesquisa
    if (searchQuery) {
      filtered = filtered.filter(campaign => 
        campaign.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (campaign.subject && campaign.subject.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (campaign.content && campaign.content.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Filtrar por status
    if (statusFilter !== "all") {
      filtered = filtered.filter(campaign => campaign.status === statusFilter);
    }

    // Filtrar por tipo
    if (typeFilter !== "all") {
      filtered = filtered.filter(campaign => campaign.type === typeFilter);
    }

    // Ordenar
    filtered.sort((a, b) => {
      let valueA = a[sortBy];
      let valueB = b[sortBy];
      
      // Tratamento especial para datas
      if (sortBy.includes('date')) {
        valueA = new Date(valueA || 0).getTime();
        valueB = new Date(valueB || 0).getTime();
      }
      
      if (valueA === null || valueA === undefined) return 1;
      if (valueB === null || valueB === undefined) return -1;
      
      if (sortDirection === "asc") {
        return valueA < valueB ? -1 : 1;
      } else {
        return valueA > valueB ? -1 : 1;
      }
    });

    return filtered;
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "draft":
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-200">
            <Clock className="mr-1 h-3 w-3" />
            Rascunho
          </Badge>
        );
      case "scheduled":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
            <Calendar className="mr-1 h-3 w-3" />
            Agendado
          </Badge>
        );
      case "sending":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
            <RefreshCw className="mr-1 h-3 w-3 animate-spin" />
            Enviando
          </Badge>
        );
      case "sent":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            <CheckCircle className="mr-1 h-3 w-3" />
            Enviado
          </Badge>
        );
      case "recurring":
        return (
          <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">
            <RefreshCw className="mr-1 h-3 w-3" />
            Recorrente
          </Badge>
        );
      case "paused":
        return (
          <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-200">
            <Pause className="mr-1 h-3 w-3" />
            Pausado
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-200">
            {status}
          </Badge>
        );
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case "email":
        return <Mail className="h-4 w-4 text-blue-500" />;
      case "sms":
        return <Smartphone className="h-4 w-4 text-green-500" />;
      case "notification":
        return <Bell className="h-4 w-4 text-purple-500" />;
      default:
        return <SendHorizonal className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const filteredCampaigns = getFilteredCampaigns();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Campanhas</h1>
          <p className="text-gray-500 mt-1">
            Gerencie suas campanhas de marketing por e-mail, SMS e notificações
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <BarChart4 className="mr-2 h-4 w-4" />
            Relatórios
          </Button>
          <Link to={createPageUrl("CrmNovaCampanha")}>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Nova Campanha
            </Button>
          </Link>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList>
                <TabsTrigger value="all">Todas</TabsTrigger>
                <TabsTrigger value="draft">Rascunhos</TabsTrigger>
                <TabsTrigger value="scheduled">Agendadas</TabsTrigger>
                <TabsTrigger value="active">Ativas</TabsTrigger>
                <TabsTrigger value="sent">Enviadas</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row justify-between mb-6 gap-4">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar campanhas..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-10">
                    <Filter className="mr-2 h-4 w-4" />
                    Status
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setStatusFilter("all")}>
                    Todos
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("draft")}>
                    Rascunhos
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("scheduled")}>
                    Agendadas
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("sending")}>
                    Enviando
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("sent")}>
                    Enviadas
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("recurring")}>
                    Recorrentes
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("paused")}>
                    Pausadas
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-10">
                    <Filter className="mr-2 h-4 w-4" />
                    Tipo
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setTypeFilter("all")}>
                    Todos
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTypeFilter("email")}>
                    E-mail
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTypeFilter("sms")}>
                    SMS
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTypeFilter("notification")}>
                    Notificação
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
          ) : filteredCampaigns.length === 0 ? (
            <div className="text-center py-12">
              <SendHorizonal className="mx-auto h-12 w-12 text-gray-300" />
              <h3 className="mt-4 text-lg font-semibold text-gray-900">Nenhuma campanha encontrada</h3>
              <p className="mt-1 text-gray-500">
                {searchQuery || statusFilter !== "all" || typeFilter !== "all" 
                  ? "Tente ajustar os filtros de busca" 
                  : "Comece criando uma nova campanha de marketing"}
              </p>
              {!(searchQuery || statusFilter !== "all" || typeFilter !== "all") && (
                <Link to={createPageUrl("CrmNovaCampanha")}>
                  <Button className="mt-4">
                    <Plus className="mr-2 h-4 w-4" />
                    Nova Campanha
                  </Button>
                </Link>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[300px]">
                      <div 
                        className="flex items-center cursor-pointer"
                        onClick={() => handleSort("title")}
                      >
                        Título / Assunto
                        {sortBy === "title" && (
                          <ArrowUpDown className="ml-1 h-4 w-4" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead className="w-[100px]">Tipo</TableHead>
                    <TableHead className="w-[120px]">Status</TableHead>
                    <TableHead className="w-[150px]">
                      <div 
                        className="flex items-center cursor-pointer"
                        onClick={() => handleSort("created_date")}
                      >
                        Data de Criação
                        {sortBy === "created_date" && (
                          <ArrowUpDown className="ml-1 h-4 w-4" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead className="w-[120px]">
                      <div 
                        className="flex items-center cursor-pointer"
                        onClick={() => handleSort("recipients_count")}
                      >
                        Destinatários
                        {sortBy === "recipients_count" && (
                          <ArrowUpDown className="ml-1 h-4 w-4" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead className="w-[120px]">
                      <div 
                        className="flex items-center cursor-pointer"
                        onClick={() => handleSort("open_rate")}
                      >
                        Desempenho
                        {sortBy === "open_rate" && (
                          <ArrowUpDown className="ml-1 h-4 w-4" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead className="text-right w-[100px]">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCampaigns.map((campaign) => (
                    <TableRow key={campaign.id}>
                      <TableCell className="font-medium">
                        <div>
                          <div className="font-medium">{campaign.title}</div>
                          <div className="text-sm text-gray-500 truncate max-w-[300px]">
                            {campaign.subject || campaign.content || "Sem conteúdo"}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          {getTypeIcon(campaign.type)}
                          <span className="ml-2 capitalize">{campaign.type === "email" ? "E-mail" : campaign.type === "sms" ? "SMS" : "Notificação"}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(campaign.status)}</TableCell>
                      <TableCell>{formatDate(campaign.created_date)}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Users className="mr-2 h-4 w-4 text-gray-400" />
                          {campaign.recipients_count}
                        </div>
                      </TableCell>
                      <TableCell>
                        {campaign.status === "sent" || campaign.status === "recurring" ? (
                          <div className="space-y-1">
                            <div className="text-xs text-gray-500">Abertura: <span className="font-medium text-gray-900">{campaign.open_rate}%</span></div>
                            <div className="text-xs text-gray-500">Cliques: <span className="font-medium text-gray-900">{campaign.click_rate}%</span></div>
                          </div>
                        ) : campaign.status === "sending" ? (
                          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                            <RefreshCw className="mr-1 h-3 w-3 animate-spin" />
                            Em andamento
                          </Badge>
                        ) : (
                          <span className="text-gray-500 text-sm">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              Visualizar
                            </DropdownMenuItem>
                            {campaign.status === "draft" && (
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" />
                                Editar
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem>
                              <Copy className="mr-2 h-4 w-4" />
                              Duplicar
                            </DropdownMenuItem>
                            {(campaign.status === "recurring" || campaign.status === "scheduled") && (
                              <DropdownMenuItem>
                                <Pause className="mr-2 h-4 w-4" />
                                Pausar
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-red-600"
                              onClick={() => {
                                setCampaignToDelete(campaign.id);
                                setShowDeleteDialog(true);
                              }}
                            >
                              <Trash className="mr-2 h-4 w-4" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Excluir Campanha</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir esta campanha? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleDeleteConfirm}>
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}