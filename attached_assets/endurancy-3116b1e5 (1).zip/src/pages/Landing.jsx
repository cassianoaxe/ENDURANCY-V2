import React from 'react';
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowRight, Shield, Building2, User, Check, Server, CheckCircle2, Lock, BarChart4, Leaf, Microscope, FileCheck, Activity } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="w-full py-4 px-6 bg-white border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
              <span className="text-green-600 font-semibold">E</span>
            </div>
            <span className="font-semibold text-xl">Endurancy</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-gray-600 hover:text-gray-900">Recursos</a>
            <a href="#solutions" className="text-gray-600 hover:text-gray-900">Soluções</a>
            <a href="#pricing" className="text-gray-600 hover:text-gray-900">Planos</a>
            <a href="#contact" className="text-gray-600 hover:text-gray-900">Contato</a>
          </div>
          
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Login")}>
              <Button variant="outline">Entrar</Button>
            </Link>
            <Button className="bg-green-600 hover:bg-green-700">
              Começar agora
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </header>
      
      {/* Hero */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-gray-900 mb-6">
            Plataforma completa para gestão<br />
            <span className="bg-gradient-to-r from-green-600 to-emerald-500 bg-clip-text text-transparent">
              de organizações canábicas
            </span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-10">
            Simplifique a gestão de pacientes, controle de vendas de medicamentos e o monitoramento de produção
            com rastreabilidade de ponta a ponta.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-16">
            <Link to={createPageUrl("Login")}>
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg h-12 px-8">
                Acessar plataforma
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="text-lg h-12 px-8">
              Agendar demonstração
            </Button>
          </div>
          
          <div className="relative bg-gray-100 rounded-xl overflow-hidden h-96 max-w-5xl mx-auto">
            <div className="absolute inset-0 flex items-center justify-center bg-gray-200">
              <p className="text-gray-500 text-lg">Dashboard da plataforma Endurancy</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Solutions */}
      <section id="solutions" className="py-16 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Soluções para cada perfil</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            O Endurancy oferece interfaces específicas para administradores, organizações e pacientes.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          <div className="bg-white p-8 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
            <div className="p-3 bg-purple-100 rounded-xl inline-block mb-4">
              <Shield className="w-8 h-8 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold mb-3">Painel CPLY</h3>
            <p className="text-gray-600 mb-6">
              Painel de administração para superusuários, com controle total sobre organizações, aprovações e configurações do sistema.
            </p>
            <ul className="space-y-3 mb-8">
              {[
                "Gestão completa de organizações",
                "Análise de solicitações",
                "Relatórios avançados",
                "Controle de usuários"
              ].map((item, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <Link to={`${createPageUrl("Login")}?type=admin`}>
              <Button variant="outline" className="w-full">
                Acessar como admin
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
          
          <div className="bg-white p-8 rounded-xl shadow-md border border-green-200 hover:shadow-lg transition-shadow relative">
            <div className="absolute top-0 right-0 bg-green-600 text-white text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-lg">
              Mais popular
            </div>
            <div className="p-3 bg-green-100 rounded-xl inline-block mb-4">
              <Building2 className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-bold mb-3">Painel da Organização</h3>
            <p className="text-gray-600 mb-6">
              Interface completa para gestão de organizações canábicas, com controle de pacientes, produtos e prescrições.
            </p>
            <ul className="space-y-3 mb-8">
              {[
                "Cadastro e gestão de pacientes",
                "Controle de produtos e estoque",
                "Aprovação de prescrições médicas",
                "Rastreabilidade da produção",
                "Relatórios financeiros e de vendas",
                "Multiusuários com níveis de acesso"
              ].map((item, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <Link to={`${createPageUrl("Login")}?type=organization`}>
              <Button className="w-full bg-green-600 hover:bg-green-700">
                Acessar como organização
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
          
          <div className="bg-white p-8 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
            <div className="p-3 bg-blue-100 rounded-xl inline-block mb-4">
              <User className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold mb-3">Portal do Paciente</h3>
            <p className="text-gray-600 mb-6">
              Aplicativo PWA para pacientes realizarem pedidos de produtos prescritos com facilidade e praticidade.
            </p>
            <ul className="space-y-3 mb-8">
              {[
                "Visualização de prescrições ativas",
                "Pedidos em apenas 3 cliques",
                "Histórico de compras",
                "Acompanhamento de entregas",
                "Aplicativo PWA para celular"
              ].map((item, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <Check className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <Link to={`${createPageUrl("Login")}?type=patient`}>
              <Button variant="outline" className="w-full">
                Acessar como paciente
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Features */}
      <section id="features" className="py-16 px-6">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Recursos principais</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Conheça os diferenciais que fazem do Endurancy a plataforma mais completa para o setor.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {[
            {
              icon: <Shield className="w-6 h-6 text-purple-600" />,
              title: "Segurança e Compliance",
              description: "Conformidade com regulamentações e segurança de dados de nível bancário."
            },
            {
              icon: <Activity className="w-6 h-6 text-green-600" />,
              title: "Rastreabilidade Total",
              description: "Acompanhe todo o ciclo de vida, da planta à entrega ao paciente."
            },
            {
              icon: <Leaf className="w-6 h-6 text-green-600" />,
              title: "Gestão de Cultivo",
              description: "Controle cada fase do cultivo com dados precisos de lotes e safras."
            },
            {
              icon: <Microscope className="w-6 h-6 text-blue-600" />,
              title: "Análises Laboratoriais",
              description: "Integração com resultados de análises, garantindo a qualidade dos produtos."
            },
            {
              icon: <FileCheck className="w-6 h-6 text-yellow-600" />,
              title: "Aprovação de Prescrições",
              description: "Fluxo simplificado de verificação e aprovação de prescrições médicas."
            },
            {
              icon: <Server className="w-6 h-6 text-gray-600" />,
              title: "API Aberta",
              description: "Integração com outros sistemas e dispositivos para maior flexibilidade."
            },
            {
              icon: <BarChart4 className="w-6 h-6 text-indigo-600" />,
              title: "Relatórios Avançados",
              description: "Análises e insights para tomada de decisão baseada em dados."
            },
            {
              icon: <Lock className="w-6 h-6 text-red-600" />,
              title: "Controle de Acesso",
              description: "Permissões granulares para diferentes perfis de usuários."
            },
            {
              icon: <CheckCircle2 className="w-6 h-6 text-green-600" />,
              title: "Certificação Digital",
              description: "Documentos assinados digitalmente com validade jurídica."
            }
          ].map((feature, idx) => (
            <div key={idx} className="bg-white p-6 rounded-xl border hover:shadow-md transition-shadow">
              <div className="p-2 bg-gray-100 rounded-lg inline-block mb-4">
                {feature.icon}
              </div>
              <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>
      
      {/* Call to Action */}
      <section className="py-16 px-6 bg-green-600 text-white">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Pronto para transformar sua operação?</h2>
          <p className="text-xl opacity-90 max-w-3xl mx-auto mb-8">
            Acesse agora a plataforma Endurancy e descubra como podemos ajudar sua organização a crescer com segurança e eficiência.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to={createPageUrl("Login")}>
              <Button size="lg" className="bg-white text-green-600 hover:bg-gray-100 text-lg h-12 px-8">
                Acessar plataforma
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-green-700 text-lg h-12 px-8">
              Solicitar demonstração
            </Button>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-12 px-6 bg-gray-900 text-gray-400">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-green-800 rounded-lg flex items-center justify-center">
                <span className="text-green-400 font-semibold">E</span>
              </div>
              <span className="font-semibold text-xl text-white">Endurancy</span>
            </div>
            <p className="mb-4">
              Plataforma completa para gestão de organizações canábicas, focada em segurança e compliance.
            </p>
            <div className="flex gap-4">
              {/* Social icons would go here */}
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">Plataforma</h3>
            <ul className="space-y-3">
              <li><a href="#" className="hover:text-white transition-colors">Recursos</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Preços</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Integrações</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Status</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">Suporte</h3>
            <ul className="space-y-3">
              <li><a href="#" className="hover:text-white transition-colors">Centro de ajuda</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Documentação</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contato</a></li>
              <li><a href="#" className="hover:text-white transition-colors">API</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">Empresa</h3>
            <ul className="space-y-3">
              <li><a href="#" className="hover:text-white transition-colors">Sobre nós</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Carreiras</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Termos de uso</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacidade</a></li>
            </ul>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto border-t border-gray-800 mt-12 pt-8 text-center">
          <p>© 2023 Endurancy. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}