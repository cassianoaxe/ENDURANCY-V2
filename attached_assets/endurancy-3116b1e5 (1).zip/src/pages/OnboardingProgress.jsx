import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  GraduationCap, 
  CheckCircle, 
  Clock, 
  Calendar,
  Sparkles,
  Award,
  ChevronRight,
  BookOpen,
  ArrowUpRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";

// Mock data
const mockData = {
  userProgress: {
    completedModules: 2,
    totalModules: 8,
    completedTutorials: 12,
    totalTutorials: 36,
    averageTimePerTutorial: 8.5,
    lastActivity: "2023-10-18T14:32:00Z",
    certificatesEarned: 1
  },
  modules: [
    {
      id: "getting-started",
      title: "Começando",
      progress: 100,
      completedTutorials: 3,
      totalTutorials: 3,
      completed: true,
      lastActivity: "2023-10-15T09:45:00Z"
    },
    {
      id: "cultivation",
      title: "Módulo Cultivo",
      progress: 75,
      completedTutorials: 3,
      totalTutorials: 4,
      completed: false,
      lastActivity: "2023-10-18T14:32:00Z"
    },
    {
      id: "production",
      title: "Módulo Produção",
      progress: 33,
      completedTutorials: 1,
      totalTutorials: 3,
      completed: false,
      lastActivity: "2023-10-16T11:20:00Z"
    },
    {
      id: "dispensary",
      title: "Dispensário",
      progress: 25,
      completedTutorials: 1,
      totalTutorials: 4,
      completed: false,
      lastActivity: "2023-10-14T16:05:00Z"
    },
    {
      id: "patients",
      title: "Pacientes",
      progress: 0,
      completedTutorials: 0,
      totalTutorials: 3,
      completed: false,
      lastActivity: null
    },
    {
      id: "financial",
      title: "Financeiro",
      progress: 0,
      completedTutorials: 0,
      totalTutorials: 3,
      completed: false,
      lastActivity: null
    }
  ],
  recentActivity: [
    {
      id: 1,
      tutorialId: "cultivation-basic",
      tutorialTitle: "Fundamentos do Cultivo",
      moduleId: "cultivation",
      moduleName: "Módulo Cultivo",
      action: "completed",
      date: "2023-10-18T14:32:00Z"
    },
    {
      id: 2,
      tutorialId: "production-quality",
      tutorialTitle: "Controle de Qualidade",
      moduleId: "production",
      moduleName: "Módulo Produção",
      action: "started",
      date: "2023-10-16T11:20:00Z"
    },
    {
      id: 3,
      tutorialId: "dispensary-intro",
      tutorialTitle: "Introdução ao Dispensário",
      moduleId: "dispensary",
      moduleName: "Dispensário",
      action: "completed",
      date: "2023-10-14T16:05:00Z"
    }
  ],
  certificates: [
    {
      id: "cert-1",
      title: "Fundamentos da Plataforma",
      issueDate: "2023-10-15T10:00:00Z",
      moduleId: "getting-started",
      moduleName: "Começando",
      url: "#"
    }
  ],
  recommendedTutorials: [
    {
      id: "quality-management",
      title: "Gestão da Qualidade na Produção",
      moduleId: "production",
      moduleName: "Módulo Produção",
      type: "interactive",
      duration: "12 min"
    },
    {
      id: "batch-tracking",
      title: "Rastreamento de Lotes",
      moduleId: "cultivation",
      moduleName: "Módulo Cultivo",
      type: "text",
      duration: "5 min"
    },
    {
      id: "dispensary-inventory",
      title: "Gestão de Estoque no Dispensário",
      moduleId: "dispensary",
      moduleName: "Dispensário",
      type: "video",
      duration: "8 min"
    }
  ]
};

export default function OnboardingProgress() {
  const [data, setData] = useState(mockData);
  const [activeTab, setActiveTab] = useState("overview");
  
  // Format date to a readable format
  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  // Calculate days since last activity
  const calculateDaysSince = (dateString) => {
    if (!dateString) return null;
    
    const date = new Date(dateString);
    const today = new Date();
    const diffTime = Math.abs(today - date);
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };
  
  const overallProgress = Math.round(
    (data.userProgress.completedTutorials / data.userProgress.totalTutorials) * 100
  );

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Meu Progresso</h1>
          <p className="text-gray-500">Acompanhe seu progresso nos treinamentos</p>
        </div>
        <Link to={createPageUrl("OnboardingTutorials")}>
          <Button>
            <BookOpen className="w-4 h-4 mr-2" />
            Continuar Aprendendo
          </Button>
        </Link>
      </div>
      
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="modules">Módulos</TabsTrigger>
          <TabsTrigger value="certificates">Certificados</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Progresso Geral</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between mb-2">
                  <span className="text-3xl font-bold">{overallProgress}%</span>
                  <span className="text-sm text-gray-500">
                    {data.userProgress.completedTutorials}/{data.userProgress.totalTutorials} tutoriais
                  </span>
                </div>
                <Progress value={overallProgress} className="h-2" />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Módulos Concluídos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between">
                  <span className="text-3xl font-bold">{data.userProgress.completedModules}</span>
                  <span className="text-sm text-gray-500">de {data.userProgress.totalModules} módulos</span>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className="text-sm text-gray-600">
                    {Math.round((data.userProgress.completedModules / data.userProgress.totalModules) * 100)}% concluído
                  </span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Tempo Médio</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between">
                  <span className="text-3xl font-bold">{data.userProgress.averageTimePerTutorial}</span>
                  <span className="text-sm text-gray-500">minutos por tutorial</span>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <Clock className="w-4 h-4 text-blue-500" />
                  <span className="text-sm text-gray-600">
                    Bom ritmo de aprendizado
                  </span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Certificados</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between">
                  <span className="text-3xl font-bold">{data.userProgress.certificatesEarned}</span>
                  <span className="text-sm text-gray-500">conquistados</span>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <Award className="w-4 h-4 text-amber-500" />
                  <span className="text-sm text-gray-600">
                    {data.userProgress.totalModules - data.userProgress.certificatesEarned} disponíveis para conquistar
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Atividade Recente</CardTitle>
              </CardHeader>
              <CardContent>
                {data.recentActivity.length > 0 ? (
                  <div className="space-y-4">
                    {data.recentActivity.map(activity => (
                      <div key={activity.id} className="flex items-start gap-4 pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                          activity.action === 'completed' ? 'bg-green-100' : 'bg-blue-100'
                        }`}>
                          {activity.action === 'completed' ? (
                            <CheckCircle className="w-5 h-5 text-green-600" />
                          ) : (
                            <BookOpen className="w-5 h-5 text-blue-600" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between mb-1">
                            <h4 className="font-medium">{activity.tutorialTitle}</h4>
                            <span className="text-sm text-gray-500">
                              {calculateDaysSince(activity.date) === 0 
                                ? 'Hoje' 
                                : calculateDaysSince(activity.date) === 1 
                                  ? 'Ontem' 
                                  : `${calculateDaysSince(activity.date)} dias atrás`}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500">{activity.moduleName}</p>
                          <div className="mt-1">
                            <Badge 
                              variant={activity.action === 'completed' ? 'outline' : 'default'}
                              className={activity.action === 'completed' 
                                ? 'bg-green-100 text-green-800 hover:bg-green-100' 
                                : 'bg-blue-100 text-blue-800 hover:bg-blue-100'}
                            >
                              {activity.action === 'completed' ? 'Concluído' : 'Iniciado'}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <p>Nenhuma atividade recente para exibir.</p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Recomendado para Você</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {data.recommendedTutorials.map(tutorial => (
                    <Link 
                      key={tutorial.id} 
                      to={`${createPageUrl("OnboardingTutorialView")}?id=${tutorial.id}`}
                      className="block"
                    >
                      <div className="p-3 border rounded-lg flex justify-between items-center hover:bg-gray-50 transition-colors group">
                        <div className="space-y-1">
                          <p className="font-medium group-hover:text-primary">{tutorial.title}</p>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-500">{tutorial.moduleName}</span>
                            <Badge variant="outline" className="text-xs">
                              <Clock className="w-3 h-3 mr-1" />
                              {tutorial.duration}
                            </Badge>
                          </div>
                        </div>
                        <ArrowUpRight className="w-4 h-4 text-gray-400 group-hover:text-primary" />
                      </div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="modules" className="space-y-6">
          <div className="grid gap-6">
            {data.modules.map(module => (
              <Card key={module.id}>
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-semibold">{module.title}</h3>
                        {module.completed && (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Concluído
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4 mb-4">
                        <div className="flex items-center gap-1 text-sm text-gray-500">
                          <BookOpen className="w-4 h-4" />
                          <span>{module.completedTutorials}/{module.totalTutorials} tutoriais</span>
                        </div>
                        
                        {module.lastActivity && (
                          <div className="flex items-center gap-1 text-sm text-gray-500">
                            <Calendar className="w-4 h-4" />
                            <span>Última atividade: {calculateDaysSince(module.lastActivity) === 0 
                              ? 'Hoje' 
                              : calculateDaysSince(module.lastActivity) === 1 
                                ? 'Ontem' 
                                : `${calculateDaysSince(module.lastActivity)} dias atrás`}</span>
                          </div>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between items-center text-sm">
                          <span>Progresso</span>
                          <span className="font-medium">{module.progress}%</span>
                        </div>
                        <Progress value={module.progress} className="h-2" />
                      </div>
                    </div>
                    
                    <Link to={createPageUrl("OnboardingTutorials")}>
                      <Button variant={module.progress > 0 ? "default" : "outline"}>
                        {module.progress > 0 ? "Continuar" : "Iniciar"}
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="certificates" className="space-y-6">
          {data.certificates.length > 0 ? (
            <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
              {data.certificates.map(certificate => (
                <Card key={certificate.id} className="bg-gradient-to-br from-gray-50 to-white">
                  <CardContent className="p-6">
                    <div className="flex justify-center mb-4">
                      <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center">
                        <Award className="w-8 h-8 text-amber-600" />
                      </div>
                    </div>
                    
                    <div className="text-center mb-4">
                      <h3 className="text-lg font-semibold">{certificate.title}</h3>
                      <p className="text-sm text-gray-500">{certificate.moduleName}</p>
                    </div>
                    
                    <div className="text-center mb-6">
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Concluído
                      </Badge>
                      <p className="text-sm text-gray-500 mt-2">
                        Emitido em {formatDate(certificate.issueDate)}
                      </p>
                    </div>
                    
                    <div className="flex justify-center">
                      <Button variant="outline" className="w-full">
                        <Sparkles className="w-4 h-4 mr-2" />
                        Ver Certificado
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                    <Award className="w-8 h-8 text-gray-400" />
                  </div>
                </div>
                
                <h3 className="text-lg font-semibold mb-2">Nenhum certificado ainda</h3>
                <p className="text-gray-500 mb-6">
                  Complete os módulos de treinamento para conquistar certificados
                </p>
                
                <Link to={createPageUrl("OnboardingTutorials")}>
                  <Button>
                    <BookOpen className="w-4 h-4 mr-2" />
                    Iniciar Treinamentos
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}