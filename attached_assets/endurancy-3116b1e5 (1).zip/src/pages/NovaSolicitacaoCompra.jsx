import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, 
  PackagePlus, 
  Calendar, 
  Clock, 
  AlertTriangle, 
  Plus, 
  Trash2, 
  FileText, 
  Building, 
  Send, 
  Save, 
  Loader2, 
  PlusCircle,
  Search as SearchIcon,
  Check,
  XCircle
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "@/components/ui/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";

// Dados simulados para o catálogo de produtos
const produtosCatalogo = [
  { 
    id: 'ITEM-0001', 
    nome: 'Reagente para PCR', 
    categoria: 'Laboratório',
    unidade_medida: 'unid',
    valor_estimado: 450.50,
    fornecedores: ['Fornecedor A', 'Fornecedor B', 'Fornecedor C'],
    item_laboratorio: true
  },
  { 
    id: 'ITEM-0002', 
    nome: 'Kit de pipetas', 
    categoria: 'Laboratório',
    unidade_medida: 'kit',
    valor_estimado: 890.75,
    fornecedores: ['Fornecedor A', 'Fornecedor D'],
    item_laboratorio: true
  },
  { 
    id: 'ITEM-0003', 
    nome: 'Embalagens primárias 100ml', 
    categoria: 'Embalagens',
    unidade_medida: 'unid',
    valor_estimado: 3.50,
    fornecedores: ['Fornecedor B', 'Fornecedor E'],
    item_laboratorio: false
  },
  { 
    id: 'ITEM-0004', 
    nome: 'Rótulos adesivos', 
    categoria: 'Embalagens',
    unidade_medida: 'unid',
    valor_estimado: 1.20,
    fornecedores: ['Fornecedor E', 'Fornecedor F'],
    item_laboratorio: false
  },
  { 
    id: 'ITEM-0005', 
    nome: 'Licença Adobe Creative Cloud', 
    categoria: 'TI',
    unidade_medida: 'unid',
    valor_estimado: 1800.00,
    fornecedores: ['Fornecedor G'],
    item_laboratorio: false
  },
  { 
    id: 'ITEM-0006', 
    nome: 'Notebook Dell Latitude', 
    categoria: 'TI',
    unidade_medida: 'unid',
    valor_estimado: 5200.00,
    fornecedores: ['Fornecedor H', 'Fornecedor I'],
    item_laboratorio: false
  },
  { 
    id: 'ITEM-0007', 
    nome: 'Papel A4', 
    categoria: 'Escritório',
    unidade_medida: 'resma',
    valor_estimado: 25.90,
    fornecedores: ['Fornecedor J', 'Fornecedor K'],
    item_laboratorio: false
  },
  { 
    id: 'ITEM-0008', 
    nome: 'Canetas esferográficas', 
    categoria: 'Escritório',
    unidade_medida: 'unid',
    valor_estimado: 1.50,
    fornecedores: ['Fornecedor J', 'Fornecedor K', 'Fornecedor L'],
    item_laboratorio: false
  },
  { 
    id: 'ITEM-0087', 
    nome: 'Reagente Padrão A-455', 
    categoria: 'Laboratório',
    unidade_medida: 'unid',
    valor_estimado: 780.20,
    fornecedores: ['Fornecedor A', 'Fornecedor M'],
    item_laboratorio: true
  }
];

// Dados simulados para setores
const setores = [
  "Laboratório",
  "Produção",
  "TI",
  "Administrativo",
  "Marketing",
  "Recursos Humanos",
  "Financeiro",
  "Jurídico",
  "Comercial"
];

// Dados simulados para centros de custo
const centrosCusto = [
  "CC-LAB-001 - Laboratório Controle de Qualidade",
  "CC-LAB-002 - Laboratório de Pesquisa",
  "CC-PROD-001 - Produção Linha 1",
  "CC-PROD-002 - Produção Linha 2",
  "CC-ADM-001 - Administrativo Geral",
  "CC-TI-001 - Tecnologia da Informação",
  "CC-MKT-001 - Marketing e Comunicação",
  "CC-RH-001 - Recursos Humanos",
  "CC-FIN-001 - Financeiro"
];

export default function NovaSolicitacaoCompra() {
  const navigate = useNavigate();
  const location = useLocation();
  const [solicitacao, setSolicitacao] = useState({
    descricao: '',
    justificativa: '',
    setor: '',
    centro_custo: '',
    data_necessidade: '',
    urgencia: 'media',
    observacoes: '',
    itens: []
  });
  const [produtoSelecionado, setProdutoSelecionado] = useState(null);
  const [quantidade, setQuantidade] = useState(1);
  const [dialogProdutosOpen, setDialogProdutosOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [produtosFiltrados, setProdutosFiltrados] = useState(produtosCatalogo);
  const [carregandoProdutos, setCarregandoProdutos] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});

  useEffect(() => {
    // Verifica se há um item específico para adicionar (passado por estado de navegação)
    if (location.state?.item_id) {
      const itemId = location.state.item_id;
      const produto = produtosCatalogo.find(p => p.id === itemId);
      
      if (produto) {
        handleAddItem(produto);
        // Ajustar descrição automaticamente
        setSolicitacao(prev => ({
          ...prev,
          descricao: `Solicitação de compra: ${produto.nome}`,
          justificativa: `Reposição de estoque em nível crítico: ${produto.nome}`
        }));
      }
    }
  }, [location.state]);

  useEffect(() => {
    if (searchTerm) {
      setCarregandoProdutos(true);
      
      // Simular atraso de carregamento
      setTimeout(() => {
        const filtered = produtosCatalogo.filter(produto => 
          produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
          produto.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
          produto.categoria.toLowerCase().includes(searchTerm.toLowerCase())
        );
        setProdutosFiltrados(filtered);
        setCarregandoProdutos(false);
      }, 300);
    } else {
      setProdutosFiltrados(produtosCatalogo);
    }
  }, [searchTerm]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSolicitacao(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Limpar erro de validação ao editar
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: null
      }));
    }
  };

  const handleSelectChange = (name, value) => {
    setSolicitacao(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Limpar erro de validação ao editar
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: null
      }));
    }
  };

  const handleAddItem = (produto) => {
    // Verificar se o produto já está na lista
    const existingItemIndex = solicitacao.itens.findIndex(
      item => item.produto_id === produto.id
    );
    
    if (existingItemIndex >= 0) {
      // Atualizar quantidade se o produto já existir
      const updatedItens = [...solicitacao.itens];
      updatedItens[existingItemIndex].quantidade += quantidade;
      updatedItens[existingItemIndex].valor_total = 
        updatedItens[existingItemIndex].quantidade * updatedItens[existingItemIndex].valor_unitario;
        
      setSolicitacao(prev => ({
        ...prev,
        itens: updatedItens
      }));
    } else {
      // Adicionar novo item
      setSolicitacao(prev => ({
        ...prev,
        itens: [
          ...prev.itens,
          {
            produto_id: produto.id,
            nome: produto.nome,
            quantidade: quantidade,
            unidade_medida: produto.unidade_medida,
            categoria: produto.categoria,
            valor_unitario: produto.valor_estimado,
            valor_total: quantidade * produto.valor_estimado,
            item_laboratorio: produto.item_laboratorio
          }
        ]
      }));
    }
    
    setQuantidade(1);
    setProdutoSelecionado(null);
    setDialogProdutosOpen(false);
  };

  const handleRemoveItem = (index) => {
    setSolicitacao(prev => ({
      ...prev,
      itens: prev.itens.filter((_, i) => i !== index)
    }));
  };

  const calcularValorTotal = () => {
    return solicitacao.itens.reduce((total, item) => total + item.valor_total, 0);
  };

  const validateForm = () => {
    const errors = {};
    
    if (!solicitacao.descricao) {
      errors.descricao = "A descrição é obrigatória";
    }
    
    if (!solicitacao.justificativa) {
      errors.justificativa = "A justificativa é obrigatória";
    }
    
    if (!solicitacao.setor) {
      errors.setor = "O setor é obrigatório";
    }
    
    if (!solicitacao.centro_custo) {
      errors.centro_custo = "O centro de custo é obrigatório";
    }
    
    if (!solicitacao.data_necessidade) {
      errors.data_necessidade = "A data de necessidade é obrigatória";
    }
    
    if (solicitacao.itens.length === 0) {
      errors.itens = "É necessário adicionar pelo menos um item";
    }
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (asDraft = false) => {
    if (!asDraft && !validateForm()) {
      toast({
        title: "Erro de validação",
        description: "Por favor, corrija os campos destacados.",
        variant: "destructive"
      });
      return;
    }
    
    setSubmitting(true);
    
    // Simular envio
    setTimeout(() => {
      setSubmitting(false);
      toast({
        title: asDraft ? "Rascunho salvo com sucesso" : "Solicitação enviada com sucesso",
        description: asDraft 
          ? "Seu rascunho foi salvo e poderá ser editado posteriormente." 
          : "Sua solicitação foi enviada e está aguardando aprovação.",
      });
      navigate(createPageUrl("SolicitacoesCompra"));
    }, 1500);
  };

  const temItemLaboratorio = solicitacao.itens.some(item => item.item_laboratorio);
  const valorTotal = calcularValorTotal();
  const precisaCotacao = valorTotal > 5000; // Valor configurável

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Nova Solicitação de Compra</h1>
            <p className="text-gray-500 mt-1">
              Preencha as informações abaixo para solicitar a compra de produtos ou serviços
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações da Solicitação</CardTitle>
              <CardDescription>
                Detalhes básicos sobre a solicitação de compra
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="descricao">Descrição <span className="text-red-500">*</span></Label>
                  <Input
                    id="descricao"
                    name="descricao"
                    placeholder="Ex: Materiais para laboratório de controle de qualidade"
                    value={solicitacao.descricao}
                    onChange={handleInputChange}
                    className={validationErrors.descricao ? "border-red-500" : ""}
                  />
                  {validationErrors.descricao && (
                    <p className="text-sm text-red-500">{validationErrors.descricao}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="justificativa">Justificativa <span className="text-red-500">*</span></Label>
                  <Textarea
                    id="justificativa"
                    name="justificativa"
                    placeholder="Explique por que esta compra é necessária"
                    value={solicitacao.justificativa}
                    onChange={handleInputChange}
                    className={`min-h-20 ${validationErrors.justificativa ? "border-red-500" : ""}`}
                  />
                  {validationErrors.justificativa && (
                    <p className="text-sm text-red-500">{validationErrors.justificativa}</p>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="setor">Setor <span className="text-red-500">*</span></Label>
                    <Select 
                      value={solicitacao.setor} 
                      onValueChange={(value) => handleSelectChange("setor", value)}
                    >
                      <SelectTrigger id="setor" className={validationErrors.setor ? "border-red-500" : ""}>
                        <SelectValue placeholder="Selecione o setor" />
                      </SelectTrigger>
                      <SelectContent>
                        {setores.map((setor) => (
                          <SelectItem key={setor} value={setor}>{setor}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {validationErrors.setor && (
                      <p className="text-sm text-red-500">{validationErrors.setor}</p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="centro_custo">Centro de Custo <span className="text-red-500">*</span></Label>
                    <Select 
                      value={solicitacao.centro_custo} 
                      onValueChange={(value) => handleSelectChange("centro_custo", value)}
                    >
                      <SelectTrigger id="centro_custo" className={validationErrors.centro_custo ? "border-red-500" : ""}>
                        <SelectValue placeholder="Selecione o centro de custo" />
                      </SelectTrigger>
                      <SelectContent>
                        {centrosCusto.map((cc) => (
                          <SelectItem key={cc} value={cc}>{cc}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {validationErrors.centro_custo && (
                      <p className="text-sm text-red-500">{validationErrors.centro_custo}</p>
                    )}
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="data_necessidade">Data de Necessidade <span className="text-red-500">*</span></Label>
                    <div className="flex items-center">
                      <Input
                        id="data_necessidade"
                        name="data_necessidade"
                        type="date"
                        value={solicitacao.data_necessidade}
                        onChange={handleInputChange}
                        className={validationErrors.data_necessidade ? "border-red-500" : ""}
                      />
                    </div>
                    {validationErrors.data_necessidade && (
                      <p className="text-sm text-red-500">{validationErrors.data_necessidade}</p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="urgencia">Nível de Urgência</Label>
                    <Select 
                      value={solicitacao.urgencia} 
                      onValueChange={(value) => handleSelectChange("urgencia", value)}
                    >
                      <SelectTrigger id="urgencia">
                        <SelectValue placeholder="Selecione a urgência" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="baixa">Baixa</SelectItem>
                        <SelectItem value="media">Média</SelectItem>
                        <SelectItem value="alta">Alta</SelectItem>
                        <SelectItem value="critica">Crítica</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="observacoes">Observações Adicionais</Label>
                  <Textarea
                    id="observacoes"
                    name="observacoes"
                    placeholder="Informações adicionais que possam ser relevantes"
                    value={solicitacao.observacoes}
                    onChange={handleInputChange}
                    className="min-h-20"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle>Itens Solicitados</CardTitle>
                <CardDescription>
                  Lista de produtos ou serviços solicitados
                </CardDescription>
              </div>
              <Dialog open={dialogProdutosOpen} onOpenChange={setDialogProdutosOpen}>
                <DialogTrigger asChild>
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" />
                    Adicionar Item
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Selecionar Item</DialogTitle>
                    <DialogDescription>
                      Busque e selecione um item do catálogo para adicionar à solicitação
                    </DialogDescription>
                  </DialogHeader>
                  <div className="py-4 space-y-4">
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                        <Input
                          placeholder="Buscar por nome, código ou categoria..."
                          className="pl-8"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                        />
                      </div>
                      <Select defaultValue="todos">
                        <SelectTrigger className="w-40">
                          <SelectValue placeholder="Categoria" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todos">Todas categorias</SelectItem>
                          <SelectItem value="laboratorio">Laboratório</SelectItem>
                          <SelectItem value="embalagens">Embalagens</SelectItem>
                          <SelectItem value="ti">TI</SelectItem>
                          <SelectItem value="escritorio">Escritório</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <ScrollArea className="h-72 rounded-md border">
                      {carregandoProdutos ? (
                        <div className="flex justify-center items-center h-full">
                          <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
                        </div>
                      ) : produtosFiltrados.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full p-4">
                          <SearchIcon className="h-12 w-12 text-gray-300 mb-2" />
                          <p className="text-gray-500 text-center">Nenhum produto encontrado.</p>
                        </div>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Código</TableHead>
                              <TableHead>Nome</TableHead>
                              <TableHead>Categoria</TableHead>
                              <TableHead>Valor Est.</TableHead>
                              <TableHead className="text-right">Ações</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {produtosFiltrados.map((produto) => (
                              <TableRow key={produto.id}>
                                <TableCell>{produto.id}</TableCell>
                                <TableCell className="font-medium">{produto.nome}</TableCell>
                                <TableCell>
                                  {produto.categoria}
                                  {produto.item_laboratorio && (
                                    <Badge className="ml-2 bg-purple-100 text-purple-800">Laboratório</Badge>
                                  )}
                                </TableCell>
                                <TableCell>
                                  {new Intl.NumberFormat('pt-BR', {
                                    style: 'currency',
                                    currency: 'BRL'
                                  }).format(produto.valor_estimado)}
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => {
                                      setProdutoSelecionado(produto);
                                    }}
                                  >
                                    <Plus className="h-4 w-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </ScrollArea>
                    
                    {produtoSelecionado && (
                      <div className="p-4 border rounded-lg bg-gray-50">
                        <div className="grid gap-4">
                          <div className="flex justify-between">
                            <div>
                              <h4 className="font-medium">{produtoSelecionado.nome}</h4>
                              <p className="text-sm text-gray-500">
                                {produtoSelecionado.id} • {produtoSelecionado.categoria}
                              </p>
                            </div>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => setProdutoSelecionado(null)}
                            >
                              <XCircle className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          <div className="flex gap-4 items-end">
                            <div className="space-y-2 flex-1">
                              <Label htmlFor="quantidade">Quantidade</Label>
                              <Input
                                id="quantidade"
                                type="number"
                                min="1"
                                value={quantidade}
                                onChange={(e) => setQuantidade(parseInt(e.target.value) || 1)}
                              />
                            </div>
                            <div className="flex-1">
                              <Button 
                                className="w-full gap-2"
                                onClick={() => handleAddItem(produtoSelecionado)}
                              >
                                <Check className="h-4 w-4" />
                                Adicionar
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {solicitacao.itens.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-8 border border-dashed rounded-lg">
                  <PackagePlus className="h-12 w-12 text-gray-300 mb-4" />
                  <h3 className="text-lg font-medium">Nenhum item adicionado</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    Clique em "Adicionar Item" para selecionar produtos ou serviços
                  </p>
                  {validationErrors.itens && (
                    <p className="text-sm text-red-500 mt-3">{validationErrors.itens}</p>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Item</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Valor Unit.</TableHead>
                        <TableHead>Subtotal</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {solicitacao.itens.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{item.nome}</div>
                              <div className="text-xs text-gray-500">
                                {item.produto_id} • {item.categoria}
                                {item.item_laboratorio && (
                                  <Badge className="ml-1 text-xs bg-purple-100 text-purple-800">
                                    Laboratório
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            {item.quantidade} {item.unidade_medida}
                          </TableCell>
                          <TableCell>
                            {new Intl.NumberFormat('pt-BR', {
                              style: 'currency',
                              currency: 'BRL'
                            }).format(item.valor_unitario)}
                          </TableCell>
                          <TableCell>
                            {new Intl.NumberFormat('pt-BR', {
                              style: 'currency',
                              currency: 'BRL'
                            }).format(item.valor_total)}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleRemoveItem(index)}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  
                  <div className="flex justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="text-gray-500">Valor Total</div>
                    <div className="font-medium text-lg">
                      {new Intl.NumberFormat('pt-BR', {
                        style: 'currency',
                        currency: 'BRL'
                      }).format(calcularValorTotal())}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Resumo da Solicitação</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Itens</span>
                  <span className="font-medium">{solicitacao.itens.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Status</span>
                  <Badge>Rascunho</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Valor Total</span>
                  <span className="font-medium">
                    {new Intl.NumberFormat('pt-BR', {
                      style: 'currency',
                      currency: 'BRL'
                    }).format(calcularValorTotal())}
                  </span>
                </div>
                {solicitacao.data_necessidade && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Data de Necessidade</span>
                    <span className="font-medium">
                      {new Date(solicitacao.data_necessidade).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                )}
                {solicitacao.urgencia && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Urgência</span>
                    <Badge
                      className={`
                        ${solicitacao.urgencia === 'baixa' ? 'bg-green-100 text-green-800' : ''}
                        ${solicitacao.urgencia === 'media' ? 'bg-blue-100 text-blue-800' : ''}
                        ${solicitacao.urgencia === 'alta' ? 'bg-red-100 text-red-800' : ''}
                        ${solicitacao.urgencia === 'critica' ? 'bg-red-600 text-white' : ''}
                      `}
                    >
                      {solicitacao.urgencia === 'baixa' && 'Baixa'}
                      {solicitacao.urgencia === 'media' && 'Média'}
                      {solicitacao.urgencia === 'alta' && 'Alta'}
                      {solicitacao.urgencia === 'critica' && 'Crítica'}
                    </Badge>
                  </div>
                )}
              </div>
              
              <Separator />
              
              {precisaCotacao && (
                <div className="flex items-start gap-2 p-3 bg-yellow-50 rounded-lg">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-yellow-800">Cotações necessárias</p>
                    <p className="text-yellow-700">
                      Esta solicitação necessita de pelo menos {valorTotal > 10000 ? '3' : '2'} cotações 
                      por ter valor superior a {valorTotal > 10000 ? 'R$ 10.000' : 'R$ 5.000'}.
                    </p>
                  </div>
                </div>
              )}
              
              {temItemLaboratorio && (
                <div className="flex items-start gap-2 p-3 bg-purple-50 rounded-lg">
                  <FileText className="h-5 w-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-purple-800">Item de laboratório</p>
                    <p className="text-purple-700">
                      Um ou mais itens são específicos para laboratório e requerem aprovação técnica adicional.
                    </p>
                  </div>
                </div>
              )}
              
              <div className="pt-2">
                <Button 
                  className="w-full gap-2 mb-2"
                  onClick={() => handleSubmit(false)}
                  disabled={submitting}
                >
                  {submitting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                  Enviar Solicitação
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full gap-2"
                  onClick={() => handleSubmit(true)}
                  disabled={submitting}
                >
                  {submitting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                  Salvar como Rascunho
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Fornecedores Sugeridos</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {solicitacao.itens.length === 0 ? (
                <p className="text-sm text-gray-500">
                  Adicione itens para ver fornecedores sugeridos
                </p>
              ) : (
                <>
                  {['Fornecedor A', 'Fornecedor B', 'Fornecedor E'].map((fornecedor, index) => (
                    <div key={index} className="flex items-center justify-between py-1">
                      <div className="flex items-center gap-2">
                        <Building className="w-4 h-4 text-gray-500" />
                        <span className="text-sm">{fornecedor}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">4.5 ★</Badge>
                    </div>
                  ))}
                  <Button variant="link" className="text-xs w-full mt-2">
                    Ver mais fornecedores
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}