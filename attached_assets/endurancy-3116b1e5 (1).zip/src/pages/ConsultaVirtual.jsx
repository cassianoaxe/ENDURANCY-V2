import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { User } from '@/api/entities';
import { 
  LayoutDashboard, Video, Users, ClipboardList, Brain, DollarSign, 
  Settings, LogOut, Menu, X, Bell, Mic, MicOff, Camera, CameraOff,
  MessageSquare, Phone, Share2, User as UserIcon, FileText, Clipboard,
  ScreenShare, StopCircle, PanelLeft, PanelLeftClose, InfoIcon,
  Clock, Calendar, ChevronRight, Plus, Send, AlertCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "@/components/ui/use-toast";
import { Separator } from "@/components/ui/separator";

export default function ConsultaVirtual() {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [consultationStatus, setConsultationStatus] = useState('waiting'); // waiting, active, completed
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('patientInfo');
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [chatMessages, setChatMessages] = useState([]);
  const [messageText, setMessageText] = useState('');
  const [patientInfo, setPatientInfo] = useState(null);
  const [showNewPrescriptionDialog, setShowNewPrescriptionDialog] = useState(false);
  const [showEndCallDialog, setShowEndCallDialog] = useState(false);
  const [doctorSchedule, setDoctorSchedule] = useState([]);
  const timerRef = useRef(null);
  const chatContainerRef = useRef(null);
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);

  // Dados para nova prescrição
  const [newPrescription, setNewPrescription] = useState({
    products: [{ product: '', dosage: '', instructions: '' }],
    duration: '90',
    notes: '',
  });

  useEffect(() => {
    // Simular carregamento dos dados
    setTimeout(() => {
      setLoading(false);
      
      // Simular dados do paciente
      setPatientInfo({
        id: "PAC001",
        name: "Maria Oliveira",
        age: 39,
        gender: "Feminino",
        dateOfBirth: "1985-03-12",
        email: "maria.oliveira@email.com",
        phone: "(11) 98765-4321",
        medicalConditions: ["Ansiedade", "Insônia"],
        allergies: ["Dipirona"],
        medications: ["Fluoxetina 20mg", "CBD Oil 5%"],
        lastVisit: "2024-02-10",
        consultationReason: "Acompanhamento para avaliação da eficácia do tratamento com CBD Oil para insônia",
        notes: "Paciente relatou melhora no sono, mas ainda apresenta episódios de insônia 2-3 vezes por semana."
      });
      
      // Simular agenda do médico para hoje
      setDoctorSchedule([
        { 
          time: "14:00", 
          patient: "João Santos", 
          type: "Retorno", 
          status: "completed" 
        },
        { 
          time: "14:30", 
          patient: "Maria Oliveira", 
          type: "Retorno", 
          status: "active" 
        },
        { 
          time: "15:00", 
          patient: "Carlos Mendes", 
          type: "Primeira Consulta", 
          status: "scheduled" 
        },
        { 
          time: "15:30", 
          patient: "Ana Silva", 
          type: "Avaliação", 
          status: "scheduled" 
        }
      ]);
      
    }, 2000);
    
    return () => {
      // Limpar timer ao desmontar componente
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);
  
  useEffect(() => {
    // Rolar para o final do chat quando novas mensagens chegarem
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatMessages]);

  // Iniciar consulta
  const startConsultation = () => {
    setConsultationStatus('active');
    
    // Simular stream de vídeo local (webcam do médico)
    if (localVideoRef.current) {
      // Note: Aqui usamos apenas uma cor de fundo para simular o vídeo
      // Em uma implementação real, você usaria navigator.mediaDevices.getUserMedia
      localVideoRef.current.style.backgroundColor = '#6200ea';
    }
    
    // Simular stream de vídeo remoto (webcam do paciente)
    if (remoteVideoRef.current) {
      // Note: Aqui usamos apenas uma cor de fundo para simular o vídeo
      // Em uma implementação real, você receberia o stream do paciente via WebRTC
      remoteVideoRef.current.style.backgroundColor = '#3700b3';
    }
    
    // Iniciar timer para contagem de tempo da consulta
    timerRef.current = setInterval(() => {
      setElapsedTime(prev => prev + 1);
    }, 1000);
    
    // Adicionar mensagem de sistema no chat
    setChatMessages([
      {
        id: Date.now(),
        sender: 'system',
        text: 'Consulta iniciada. Conexão estabelecida com o paciente.',
        timestamp: new Date(),
      }
    ]);
  };
  
  // Formatar o tempo decorrido
  const formatElapsedTime = () => {
    const minutes = Math.floor(elapsedTime / 60);
    const seconds = elapsedTime % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  // Enviar mensagem no chat
  const sendChatMessage = () => {
    if (!messageText.trim()) return;
    
    const newMessage = {
      id: Date.now(),
      sender: 'doctor',
      text: messageText,
      timestamp: new Date(),
    };
    
    setChatMessages(prev => [...prev, newMessage]);
    setMessageText('');
    
    // Simular resposta do paciente
    if (consultationStatus === 'active') {
      setTimeout(() => {
        const responseMessage = {
          id: Date.now() + 1,
          sender: 'patient',
          text: 'Entendi, doutor. Obrigada pelas informações!',
          timestamp: new Date(),
        };
        setChatMessages(prev => [...prev, responseMessage]);
      }, 3000);
    }
  };
  
  // Adicionar mais um produto à prescrição
  const addProduct = () => {
    setNewPrescription({
      ...newPrescription,
      products: [...newPrescription.products, { product: '', dosage: '', instructions: '' }]
    });
  };
  
  // Remover um produto da prescrição
  const removeProduct = (index) => {
    const updatedProducts = newPrescription.products.filter((_, i) => i !== index);
    setNewPrescription({
      ...newPrescription,
      products: updatedProducts
    });
  };
  
  // Atualizar campo de produto na prescrição
  const updateProduct = (index, field, value) => {
    const updatedProducts = [...newPrescription.products];
    updatedProducts[index] = { ...updatedProducts[index], [field]: value };
    setNewPrescription({
      ...newPrescription,
      products: updatedProducts
    });
  };
  
  // Salvar nova prescrição
  const saveNewPrescription = () => {
    // Aqui você enviaria a prescrição para o servidor
    toast({
      title: "Prescrição criada com sucesso",
      description: "A prescrição foi enviada ao paciente.",
    });
    
    setShowNewPrescriptionDialog(false);
    
    // Adicionar mensagem de sistema no chat
    setChatMessages(prev => [
      ...prev, 
      {
        id: Date.now(),
        sender: 'system',
        text: 'Nova prescrição criada e compartilhada com o paciente.',
        timestamp: new Date(),
      }
    ]);
  };
  
  // Finalizar consulta
  const endConsultation = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    setConsultationStatus('completed');
    
    // Adicionar mensagem de sistema no chat
    setChatMessages(prev => [
      ...prev, 
      {
        id: Date.now(),
        sender: 'system',
        text: 'Consulta finalizada. Obrigado por utilizar nosso serviço de telemedicina.',
        timestamp: new Date(),
      }
    ]);
    
    setShowEndCallDialog(false);
  };
  
  const toggleCamera = () => {
    setIsCameraOn(!isCameraOn);
    // Em uma implementação real, aqui você desativaria/ativaria a câmera real
  };
  
  const toggleMic = () => {
    setIsMicOn(!isMicOn);
    // Em uma implementação real, aqui você desativaria/ativaria o microfone real
  };
  
  const toggleScreenShare = () => {
    setIsScreenSharing(!isScreenSharing);
    // Em uma implementação real, aqui você iniciaria/pararia o compartilhamento de tela
    
    if (!isScreenSharing) {
      setChatMessages(prev => [
        ...prev, 
        {
          id: Date.now(),
          sender: 'system',
          text: 'Compartilhamento de tela iniciado.',
          timestamp: new Date(),
        }
      ]);
    } else {
      setChatMessages(prev => [
        ...prev, 
        {
          id: Date.now(),
          sender: 'system',
          text: 'Compartilhamento de tela finalizado.',
          timestamp: new Date(),
        }
      ]);
    }
  };

  const handleLogout = async () => {
    try {
      // Usar localStorage para simular logout
      localStorage.removeItem('mockUserType');
      localStorage.removeItem('mockUserEmail');
      localStorage.removeItem('mockUserName');
      
      // Tentar logout real se estiver disponível
      try {
        await User.logout();
      } catch (e) {
        console.log("Regular logout failed, but we still proceed with local logout");
      }
      
      navigate(createPageUrl("Access"));
    } catch (error) {
      console.error("Erro ao fazer logout:", error);
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-purple-200 border-t-purple-600"></div>
          <p className="text-sm text-gray-500">Carregando consulta virtual...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-purple-50">
      {/* Sidebar (Apenas escondido em visualização móvel, mas sempre presente em desktop) */}
      <div className={`fixed top-0 left-0 z-40 h-screen w-64 transform bg-white shadow-lg transition-transform duration-300 ${isMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0`}>
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between p-4 border-b">
            <Link to={createPageUrl("DoctorDashboard")} className="flex items-center gap-2">
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                <span className="text-purple-600 font-bold text-xl">E</span>
              </div>
              <div>
                <h1 className="font-semibold text-gray-900">Portal Médico</h1>
                <p className="text-xs text-gray-500">Telemedicina</p>
              </div>
            </Link>
            <Button 
              variant="ghost" 
              size="icon" 
              className="md:hidden"
              onClick={() => setIsMenuOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          <div className="flex flex-col gap-1 px-3 py-4">
            <Link 
              to={createPageUrl("DoctorDashboard")} 
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-purple-50 hover:text-purple-700"
            >
              <LayoutDashboard className="h-5 w-5" />
              <span>Dashboard</span>
            </Link>
            <Link 
              to={createPageUrl("ConsultaVirtual")} 
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-purple-50 hover:text-purple-700 bg-purple-50 text-purple-700"
            >
              <Video className="h-5 w-5" />
              <span>Telemedicina</span>
            </Link>
            <Link 
              to={createPageUrl("DoctorPatients")} 
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-purple-50 hover:text-purple-700"
            >
              <Users className="h-5 w-5" />
              <span>Pacientes</span>
            </Link>
            <Link 
              to={createPageUrl("DoctorPrescriptions")} 
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-purple-50 hover:text-purple-700"
            >
              <ClipboardList className="h-5 w-5" />
              <span>Prescrições</span>
            </Link>
            <Link 
              to={createPageUrl("SymptomChecker")} 
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-purple-50 hover:text-purple-700"
            >
              <Brain className="h-5 w-5" />
              <span>Analisador de Sintomas</span>
            </Link>
            <Link 
              to={createPageUrl("DoctorFinancial")} 
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-purple-50 hover:text-purple-700"
            >
              <DollarSign className="h-5 w-5" />
              <span>Financeiro</span>
            </Link>
            <Link 
              to={createPageUrl("DoctorSettings")} 
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-purple-50 hover:text-purple-700"
            >
              <Settings className="h-5 w-5" />
              <span>Configurações</span>
            </Link>
          </div>
          
          {/* Agenda do dia */}
          <div className="px-3 py-4 border-t mt-2">
            <h3 className="font-medium text-sm mb-3 flex items-center">
              <Calendar className="w-4 h-4 mr-2" />
              Agenda de Hoje
            </h3>
            <div className="space-y-3">
              {doctorSchedule.map((appointment, index) => (
                <div 
                  key={index} 
                  className={`p-2 rounded-lg text-xs ${
                    appointment.status === 'active' 
                      ? 'bg-purple-100 border border-purple-300' 
                      : appointment.status === 'completed'
                        ? 'text-gray-500'
                        : ''
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">{appointment.time}</span>
                    <Badge 
                      variant={
                        appointment.status === 'active' 
                          ? 'default' 
                          : appointment.status === 'completed'
                            ? 'secondary'
                            : 'outline'
                      }
                      className="text-[10px] h-5"
                    >
                      {appointment.status === 'active' 
                        ? 'Agora' 
                        : appointment.status === 'completed'
                          ? 'Concluída'
                          : 'Agendada'
                      }
                    </Badge>
                  </div>
                  <div className="mt-1">{appointment.patient}</div>
                  <div className="text-gray-500">{appointment.type}</div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-auto p-4 border-t">
            <Button 
              variant="ghost" 
              className="w-full justify-start text-red-600 hover:bg-red-50 hover:text-red-700"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-5 w-5" />
              Sair
            </Button>
          </div>
        </div>
      </div>

      {/* Main Telemedicine Content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Top Navigation */}
        <header className="bg-white border-b px-4 py-2">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              size="icon"
              className="md:hidden"
              onClick={() => setIsMenuOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            
            <div className="flex items-center gap-2">
              <Badge variant={consultationStatus === 'active' ? 'default' : 'secondary'} className="gap-1">
                <Clock className="h-3 w-3" />
                {consultationStatus === 'waiting' ? 'Aguardando paciente' : 
                 consultationStatus === 'active' ? formatElapsedTime() : 
                 'Consulta finalizada'}
              </Badge>
              
              {consultationStatus === 'active' && (
                <Button variant="outline" size="sm" className="gap-1 text-red-600 border-red-200 hover:bg-red-50" onClick={() => setShowEndCallDialog(true)}>
                  <Phone className="h-4 w-4" />
                  Finalizar
                </Button>
              )}
            </div>
            
            <div className="flex items-center gap-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <Avatar>
                      <AvatarFallback>JS</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Dr. João Silva</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>Perfil</DropdownMenuItem>
                  <DropdownMenuItem>Configurações</DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Sair</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>
        
        {/* Telemedicine Interface */}
        <div className="flex flex-1 overflow-hidden">
          {/* Video Conferencing Area */}
          <div className="flex-1 flex flex-col">
            {/* Main Video Area */}
            <div className="flex-1 relative">
              {consultationStatus === 'waiting' ? (
                <div className="flex h-full items-center justify-center bg-gray-800">
                  <div className="text-center p-6">
                    <Video className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                    <h2 className="text-xl font-bold text-white mb-1">Sala de Consulta</h2>
                    <p className="text-gray-400 mb-6">Aguardando o paciente se conectar...</p>
                    <Button onClick={startConsultation}>Iniciar Consulta</Button>
                  </div>
                </div>
              ) : (
                <div className="h-full bg-gray-800 flex items-center justify-center">
                  {/* Stream de vídeo do paciente (remoto) */}
                  <div 
                    ref={remoteVideoRef} 
                    className="h-full w-full bg-gray-900 flex items-center justify-center"
                  >
                    {!isCameraOn ? (
                      <div className="text-center text-white">
                        <CameraOff className="h-10 w-10 mx-auto mb-2" />
                        <p>Câmera desativada</p>
                      </div>
                    ) : consultationStatus === 'completed' ? (
                      <div className="text-center text-white">
                        <CheckCircle className="h-16 w-16 mx-auto mb-4" />
                        <h3 className="text-xl font-bold mb-2">Consulta Finalizada</h3>
                        <p>Duração total: {formatElapsedTime()}</p>
                      </div>
                    ) : (
                      <Avatar className="h-24 w-24">
                        <AvatarFallback className="text-3xl bg-purple-700">
                          {patientInfo.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                  
                  {/* Preview do próprio vídeo (local) */}
                  {consultationStatus === 'active' && (
                    <div 
                      ref={localVideoRef}
                      className="absolute bottom-4 right-4 w-48 h-36 rounded-lg overflow-hidden border-2 border-white bg-gray-900 flex items-center justify-center"
                    >
                      {!isCameraOn ? (
                        <div className="text-center text-white">
                          <CameraOff className="h-6 w-6 mx-auto mb-1" />
                          <p className="text-xs">Câmera desativada</p>
                        </div>
                      ) : (
                        <Avatar className="h-16 w-16">
                          <AvatarFallback className="text-xl bg-purple-600">JS</AvatarFallback>
                        </Avatar>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
            
            {/* Video Controls */}
            {consultationStatus !== 'waiting' && (
              <div className="bg-gray-900 p-3 flex items-center justify-center gap-2">
                <Button
                  variant={isMicOn ? "secondary" : "destructive"}
                  size="icon"
                  onClick={toggleMic}
                  className="rounded-full h-10 w-10"
                >
                  {isMicOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
                </Button>
                <Button
                  variant={isCameraOn ? "secondary" : "destructive"}
                  size="icon"
                  onClick={toggleCamera}
                  className="rounded-full h-10 w-10"
                >
                  {isCameraOn ? <Camera className="h-5 w-5" /> : <CameraOff className="h-5 w-5" />}
                </Button>
                <Button
                  variant={isScreenSharing ? "destructive" : "secondary"}
                  size="icon"
                  onClick={toggleScreenShare}
                  className="rounded-full h-10 w-10"
                  disabled={consultationStatus !== 'active'}
                >
                  {isScreenSharing ? <StopCircle className="h-5 w-5" /> : <ScreenShare className="h-5 w-5" />}
                </Button>
                <Button
                  variant="secondary"
                  size="icon"
                  className="rounded-full h-10 w-10"
                  onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                >
                  {isSidebarOpen ? <PanelLeftClose className="h-5 w-5" /> : <PanelLeft className="h-5 w-5" />}
                </Button>
                {consultationStatus === 'active' && (
                  <>
                    <Button
                      variant="default"
                      className="rounded-full px-4"
                      onClick={() => setShowNewPrescriptionDialog(true)}
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Nova Prescrição
                    </Button>
                    <Button
                      variant="destructive"
                      className="rounded-full px-4"
                      onClick={() => setShowEndCallDialog(true)}
                    >
                      <Phone className="h-4 w-4 mr-2" />
                      Finalizar Consulta
                    </Button>
                  </>
                )}
              </div>
            )}
          </div>
          
          {/* Sidebar with patient info and chat */}
          {isSidebarOpen && (
            <div className="w-80 bg-white border-l flex flex-col">
              {consultationStatus !== 'waiting' && (
                <Tabs defaultValue="patientInfo" value={activeTab} onValueChange={setActiveTab} className="flex flex-col h-full">
                  <TabsList className="bg-gray-100 p-1 mx-2 mt-2">
                    <TabsTrigger value="patientInfo" className="flex-1">
                      <UserIcon className="h-4 w-4 mr-1" />
                      Paciente
                    </TabsTrigger>
                    <TabsTrigger value="chat" className="flex-1">
                      <MessageSquare className="h-4 w-4 mr-1" />
                      Chat
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="patientInfo" className="flex-1 overflow-auto p-3">
                    {patientInfo && (
                      <div className="space-y-4">
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback>
                              {patientInfo.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-medium">{patientInfo.name}</h3>
                            <p className="text-sm text-gray-500">{patientInfo.age} anos • {patientInfo.gender}</p>
                          </div>
                        </div>
                        
                        <Separator />
                        
                        <div>
                          <h4 className="text-sm font-medium mb-2">Motivo da Consulta</h4>
                          <p className="text-sm">{patientInfo.consultationReason}</p>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium mb-2">Condições Médicas</h4>
                          <div className="flex flex-wrap gap-1">
                            {patientInfo.medicalConditions.map((condition, index) => (
                              <Badge key={index} variant="outline">{condition}</Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium mb-2">Alergias</h4>
                          <div className="flex flex-wrap gap-1">
                            {patientInfo.allergies.length > 0 ? (
                              patientInfo.allergies.map((allergy, index) => (
                                <Badge key={index} variant="destructive">{allergy}</Badge>
                              ))
                            ) : (
                              <span className="text-sm text-gray-500">Nenhuma alergia registrada</span>
                            )}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium mb-2">Medicamentos Atuais</h4>
                          <div className="flex flex-col gap-2">
                            {patientInfo.medications.map((medication, index) => (
                              <div key={index} className="flex items-center gap-2 text-sm">
                                <div className="bg-blue-100 p-1 rounded">
                                  <Clipboard className="h-3 w-3 text-blue-600" />
                                </div>
                                {medication}
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium mb-2">Última Consulta</h4>
                          <div className="text-sm flex items-center gap-1">
                            <Calendar className="h-3 w-3 text-gray-500" />
                            {new Date(patientInfo.lastVisit).toLocaleDateString()}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium mb-2">Observações Anteriores</h4>
                          <p className="text-sm text-gray-700 bg-gray-50 p-2 rounded-lg">
                            {patientInfo.notes}
                          </p>
                        </div>
                        
                        <div className="flex justify-between mt-4">
                          <Button variant="outline" size="sm">
                            <FileText className="h-4 w-4 mr-2" />
                            Histórico Completo
                          </Button>
                          <Button variant="outline" size="sm">
                            <Share2 className="h-4 w-4 mr-2" />
                            Compartilhar
                          </Button>
                        </div>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="chat" className="flex-1 flex flex-col p-0">
                    <div 
                      ref={chatContainerRef}
                      className="flex-1 overflow-auto p-3 space-y-3"
                    >
                      {chatMessages.map((message) => (
                        <div 
                          key={message.id} 
                          className={`flex ${message.sender === 'doctor' ? 'justify-end' : 'justify-start'}`}
                        >
                          {message.sender === 'system' ? (
                            <div className="bg-gray-100 text-gray-600 text-xs p-2 rounded-lg max-w-[85%]">
                              <InfoIcon className="h-3 w-3 inline-block mr-1" />
                              {message.text}
                            </div>
                          ) : (
                            <div 
                              className={`p-3 rounded-lg max-w-[85%] ${
                                message.sender === 'doctor' 
                                  ? 'bg-purple-100 text-purple-800' 
                                  : 'bg-gray-200 text-gray-800'
                              }`}
                            >
                              {message.text}
                              <div className="text-xs opacity-70 mt-1">
                                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                      
                      {chatMessages.length === 0 && (
                        <div className="h-full flex items-center justify-center text-center p-6">
                          <div>
                            <MessageSquare className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                            <h3 className="font-medium text-gray-600 mb-1">Chat da Consulta</h3>
                            <p className="text-sm text-gray-500">
                              Envie mensagens para o paciente durante a consulta.
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="p-3 border-t">
                      <div className="flex gap-2">
                        <Input 
                          placeholder="Digite uma mensagem..." 
                          value={messageText}
                          onChange={(e) => setMessageText(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && sendChatMessage()}
                          disabled={consultationStatus !== 'active'}
                        />
                        <Button 
                          size="icon" 
                          onClick={sendChatMessage}
                          disabled={consultationStatus !== 'active' || !messageText.trim()}
                        >
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              )}
              
              {consultationStatus === 'waiting' && (
                <div className="p-4">
                  <h3 className="font-medium text-lg mb-3">Próxima Consulta</h3>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <Avatar>
                          <AvatarFallback>
                            {patientInfo.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium">{patientInfo.name}</h4>
                          <p className="text-sm text-gray-500">{patientInfo.age} anos • {patientInfo.gender}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <div className="text-sm text-gray-500">Horário</div>
                          <div className="font-medium flex items-center">
                            <Clock className="w-4 h-4 mr-1 text-blue-600" />
                            14:30 - 15:00
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm text-gray-500">Tipo de Consulta</div>
                          <div className="font-medium">Retorno</div>
                        </div>
                        
                        <div>
                          <div className="text-sm text-gray-500">Motivo</div>
                          <div className="text-sm">{patientInfo.consultationReason}</div>
                        </div>
                        
                        <Button className="w-full" onClick={startConsultation}>
                          Iniciar Consulta
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* New Prescription Dialog */}
      <Dialog open={showNewPrescriptionDialog} onOpenChange={setShowNewPrescriptionDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Nova Prescrição</DialogTitle>
            <DialogDescription>
              Crie uma nova prescrição para {patientInfo?.name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4">
            <div>
              <Label htmlFor="duration" className="flex items-center justify-between">
                <span>Validade da Prescrição</span>
                <Select 
                  value={newPrescription.duration} 
                  onValueChange={(value) => setNewPrescription({...newPrescription, duration: value})}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 dias</SelectItem>
                    <SelectItem value="60">60 dias</SelectItem>
                    <SelectItem value="90">90 dias</SelectItem>
                    <SelectItem value="180">6 meses</SelectItem>
                  </SelectContent>
                </Select>
              </Label>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label>Produtos Prescritos</Label>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={addProduct}
                  className="h-8 gap-1"
                >
                  <Plus className="h-3 w-3" />
                  Adicionar Produto
                </Button>
              </div>
              
              <div className="space-y-3">
                {newPrescription.products.map((product, index) => (
                  <div key={index} className="grid gap-3 p-3 border rounded-lg bg-gray-50">
                    <div className="flex items-center justify-between">
                      <Label className="font-medium">Produto {index + 1}</Label>
                      {newPrescription.products.length > 1 && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => removeProduct(index)}
                          className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50 gap-1"
                        >
                          <X className="h-3 w-3" />
                          Remover
                        </Button>
                      )}
                    </div>
                    
                    <div className="grid gap-3 md:grid-cols-2">
                      <div>
                        <Label htmlFor={`product-${index}`}>Produto</Label>
                        <Select 
                          value={product.product} 
                          onValueChange={(value) => updateProduct(index, 'product', value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o produto" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="cbd_oil_5">CBD Oil 5%</SelectItem>
                            <SelectItem value="cbd_oil_10">CBD Oil 10%</SelectItem>
                            <SelectItem value="cbd_oil_20">CBD Oil 20%</SelectItem>
                            <SelectItem value="thc_oil_1">THC Oil 1%</SelectItem>
                            <SelectItem value="thc_oil_5">THC Oil 5%</SelectItem>
                            <SelectItem value="balanced_oil">Balanced Oil (1:1)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor={`dosage-${index}`}>Dosagem</Label>
                        <Input 
                          id={`dosage-${index}`} 
                          placeholder="Ex: 1ml 2x ao dia"
                          value={product.dosage}
                          onChange={(e) => updateProduct(index, 'dosage', e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor={`instructions-${index}`}>Instruções</Label>
                      <Textarea 
                        id={`instructions-${index}`} 
                        placeholder="Instruções específicas para este produto"
                        value={product.instructions}
                        onChange={(e) => updateProduct(index, 'instructions', e.target.value)}
                        rows={2}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <Label htmlFor="notes">Observações Gerais</Label>
              <Textarea 
                id="notes"
                placeholder="Observações adicionais para o paciente"
                value={newPrescription.notes}
                onChange={(e) => setNewPrescription({...newPrescription, notes: e.target.value})}
                rows={3}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewPrescriptionDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={saveNewPrescription}>
              Salvar Prescrição
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* End Call Dialog */}
      <Dialog open={showEndCallDialog} onOpenChange={setShowEndCallDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Finalizar Consulta</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja finalizar esta consulta?
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback>
                    {patientInfo.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-medium">{patientInfo.name}</h4>
                  <p className="text-sm text-gray-500">Consulta em andamento</p>
                </div>
              </div>
              <Badge>
                <Clock className="h-3 w-3 mr-1" />
                {formatElapsedTime()}
              </Badge>
            </div>
            
            <div>
              <Label htmlFor="endNotes">Observações Finais</Label>
              <Textarea 
                id="endNotes" 
                placeholder="Adicione observações finais sobre a consulta"
                rows={3}
              />
            </div>
            
            <div className="flex items-center">
              <AlertCircle className="h-4 w-4 text-amber-600 mr-2" />
              <p className="text-sm text-gray-600">
                Ao finalizar, o paciente será notificado e a consulta será encerrada.
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEndCallDialog(false)}>
              Voltar para a Consulta
            </Button>
            <Button variant="destructive" onClick={endConsultation}>
              Finalizar Consulta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}