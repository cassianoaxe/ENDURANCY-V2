import React, { useState, useEffect } from 'react';
import { Comissao } from '@/api/entities';
import { ComissaoMedica } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { 
  BarChart, 
  Calendar, 
  DollarSign, 
  Download, 
  FileText, 
  Filter, 
  MoreHorizontal, 
  Printer, 
  Search, 
  User, 
  UserCheck, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Tag, 
  Users 
} from "lucide-react";

export default function Comissoes() {
  const [comissoes, setComissoes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');
  const [tipoFilter, setTipoFilter] = useState('todos');
  const [periodoFilter, setPeriodoFilter] = useState('atual');
  const [activeTab, setActiveTab] = useState('geral');

  useEffect(() => {
    loadComissoes();
  }, [activeTab]);

  const loadComissoes = async () => {
    try {
      setIsLoading(true);
      
      // Carregar comissões de representantes ou médicos dependendo da aba ativa
      if (activeTab === 'geral' || activeTab === 'representantes') {
        const representantesComissoes = await Comissao.list('-data_calculo');
        if (activeTab === 'geral') {
          setComissoes(representantesComissoes);
        } else {
          setComissoes(representantesComissoes.filter(c => c.tipo_origem === 'representante'));
        }
      } else if (activeTab === 'medicos') {
        const medicosComissoes = await ComissaoMedica.list('-data_calculo');
        setComissoes(medicosComissoes);
      }
    } catch (error) {
      console.error('Erro ao carregar comissões:', error);
      // Usar dados de demonstração caso a API falhe
      setComissoes([
        {
          id: '1',
          tipo_origem: 'representante',
          nome_origem: 'Carlos Oliveira',
          pedido_id: 'PED-001',
          valor_pedido: 1850.50,
          percentual_comissao: 7.5,
          valor_comissao: 138.79,
          data_pedido: '2023-07-15T14:30:00Z',
          data_calculo: '2023-07-16T10:00:00Z',
          status: 'paga',
          mes_referencia: '2023-07',
          data_pagamento: '2023-08-05T10:00:00Z'
        },
        {
          id: '2',
          tipo_origem: 'medico',
          nome_origem: 'Dra. Maria Santos',
          pedido_id: 'PED-002',
          valor_pedido: 2200.00,
          percentual_comissao: 5,
          valor_comissao: 110.00,
          data_pedido: '2023-07-18T09:45:00Z',
          data_calculo: '2023-07-19T11:30:00Z',
          status: 'aprovada',
          mes_referencia: '2023-07'
        },
        {
          id: '3',
          tipo_origem: 'representante',
          nome_origem: 'Ana Silva',
          pedido_id: 'PED-003',
          valor_pedido: 1500.00,
          percentual_comissao: 6,
          valor_comissao: 90.00,
          data_pedido: '2023-08-02T16:20:00Z',
          data_calculo: '2023-08-03T10:15:00Z',
          status: 'pendente',
          mes_referencia: '2023-08'
        },
        {
          id: '4',
          tipo_origem: 'medico',
          nome_origem: 'Dr. João Oliveira',
          pedido_id: 'PED-004',
          valor_pedido: 3500.00,
          percentual_comissao: 5,
          valor_comissao: 175.00,
          data_pedido: '2023-08-05T11:30:00Z',
          data_calculo: '2023-08-06T09:00:00Z',
          status: 'pendente',
          mes_referencia: '2023-08'
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredComissoes = comissoes.filter(com => {
    const matchesSearch = 
      com.nome_origem?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      com.pedido_id?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'todos' || com.status === statusFilter;
    const matchesTipo = tipoFilter === 'todos' || com.tipo_origem === tipoFilter;
    
    // Filtro por período (mês atual, mês anterior, etc.)
    let matchesPeriodo = true;
    if (periodoFilter !== 'todos') {
      const now = new Date();
      const mesAtual = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
      
      if (periodoFilter === 'atual' && com.mes_referencia !== mesAtual) {
        matchesPeriodo = false;
      } else if (periodoFilter === 'anterior') {
        const lastMonth = now.getMonth() === 0 
          ? `${now.getFullYear() - 1}-12` 
          : `${now.getFullYear()}-${String(now.getMonth()).padStart(2, '0')}`;
        matchesPeriodo = com.mes_referencia === lastMonth;
      }
    }
    
    return matchesSearch && matchesStatus && matchesTipo && matchesPeriodo;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'paga':
        return <Badge className="bg-green-100 text-green-800">Paga</Badge>;
      case 'aprovada':
        return <Badge className="bg-blue-100 text-blue-800">Aprovada</Badge>;
      case 'pendente':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'cancelada':
        return <Badge className="bg-red-100 text-red-800">Cancelada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  const formatMesReferencia = (mesRef) => {
    if (!mesRef) return '';
    const [ano, mes] = mesRef.split('-');
    const meses = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ];
    return `${meses[parseInt(mes) - 1]} ${ano}`;
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getTipoOrigemIcon = (tipo) => {
    switch (tipo) {
      case 'representante':
        return <UserCheck className="h-4 w-4 text-blue-500" />;
      case 'medico':
        return <User className="h-4 w-4 text-purple-500" />;
      case 'parceiro':
        return <Users className="h-4 w-4 text-green-500" />;
      default:
        return <User className="h-4 w-4" />;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'paga':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'aprovada':
        return <CheckCircle2 className="h-4 w-4 text-blue-500" />;
      case 'pendente':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'cancelada':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  // Cálculo de estatísticas
  const totalComissoes = filteredComissoes.reduce((acc, com) => acc + com.valor_comissao, 0);
  const totalPendente = filteredComissoes
    .filter(com => com.status === 'pendente')
    .reduce((acc, com) => acc + com.valor_comissao, 0);
  const totalAprovada = filteredComissoes
    .filter(com => com.status === 'aprovada')
    .reduce((acc, com) => acc + com.valor_comissao, 0);
  const totalPaga = filteredComissoes
    .filter(com => com.status === 'paga')
    .reduce((acc, com) => acc + com.valor_comissao, 0);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Comissões</h1>
          <p className="text-gray-500 mt-1">Gerenciamento de comissões para representantes e médicos</p>
        </div>
        
        <div className="flex gap-3">
          <Button variant="outline" className="flex gap-2 items-center">
            <Download className="w-4 h-4" />
            Exportar
          </Button>
          <Button variant="outline" className="flex gap-2 items-center">
            <Printer className="w-4 h-4" />
            Imprimir
          </Button>
          <Link to={createPageUrl("NovaComissao")}>
            <Button className="flex gap-2 items-center">
              <DollarSign className="w-4 h-4" />
              Nova Comissão
            </Button>
          </Link>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="py-4">
            <CardTitle className="text-sm font-medium text-gray-500">Total de Comissões</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold">{formatCurrency(totalComissoes)}</div>
            <p className="text-xs text-gray-500 mt-1">Total calculado para todas as comissões</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="py-4">
            <CardTitle className="text-sm font-medium text-gray-500">Comissões Pendentes</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold text-yellow-600">{formatCurrency(totalPendente)}</div>
            <p className="text-xs text-gray-500 mt-1">Aguardando aprovação</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="py-4">
            <CardTitle className="text-sm font-medium text-gray-500">Comissões Aprovadas</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold text-blue-600">{formatCurrency(totalAprovada)}</div>
            <p className="text-xs text-gray-500 mt-1">Aguardando pagamento</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="py-4">
            <CardTitle className="text-sm font-medium text-gray-500">Comissões Pagas</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalPaga)}</div>
            <p className="text-xs text-gray-500 mt-1">Neste período</p>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="geral" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="geral">Visão Geral</TabsTrigger>
          <TabsTrigger value="representantes">Representantes</TabsTrigger>
          <TabsTrigger value="medicos">Médicos</TabsTrigger>
        </TabsList>
        
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 my-4">
          <div className="flex flex-wrap gap-3">
            <div className="w-full md:w-auto">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos os status</SelectItem>
                  <SelectItem value="pendente">Pendentes</SelectItem>
                  <SelectItem value="aprovada">Aprovadas</SelectItem>
                  <SelectItem value="paga">Pagas</SelectItem>
                  <SelectItem value="cancelada">Canceladas</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {activeTab === 'geral' && (
              <div className="w-full md:w-auto">
                <Select value={tipoFilter} onValueChange={setTipoFilter}>
                  <SelectTrigger className="w-full md:w-40">
                    <SelectValue placeholder="Tipo de Origem" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os tipos</SelectItem>
                    <SelectItem value="representante">Representantes</SelectItem>
                    <SelectItem value="medico">Médicos</SelectItem>
                    <SelectItem value="parceiro">Parceiros</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div className="w-full md:w-auto">
              <Select value={periodoFilter} onValueChange={setPeriodoFilter}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos os períodos</SelectItem>
                  <SelectItem value="atual">Mês atual</SelectItem>
                  <SelectItem value="anterior">Mês anterior</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Buscar comissão..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        {/* Conteúdo das tabs */}
        <TabsContent value="geral" className="m-0">
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="flex flex-col items-center">
                    <div className="animate-spin h-8 w-8 border-4 border-green-500 rounded-full border-t-transparent"></div>
                    <p className="mt-4 text-gray-500">Carregando comissões...</p>
                  </div>
                </div>
              ) : filteredComissoes.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Origem</TableHead>
                      <TableHead>Pedido</TableHead>
                      <TableHead>Valor do Pedido</TableHead>
                      <TableHead>Comissão</TableHead>
                      <TableHead>Data do Pedido</TableHead>
                      <TableHead>Mês Ref.</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredComissoes.map((comissao) => (
                      <TableRow key={comissao.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getTipoOrigemIcon(comissao.tipo_origem)}
                            <div>
                              <div className="font-medium">{comissao.nome_origem}</div>
                              <div className="text-xs text-gray-500 capitalize">{comissao.tipo_origem}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Link to={createPageUrl(`DetalhePedido?id=${comissao.pedido_id}`)} className="hover:text-blue-600">
                            {comissao.pedido_id}
                          </Link>
                        </TableCell>
                        <TableCell>{formatCurrency(comissao.valor_pedido)}</TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-medium">{formatCurrency(comissao.valor_comissao)}</span>
                            <span className="text-xs text-gray-500">{comissao.percentual_comissao}%</span>
                          </div>
                        </TableCell>
                        <TableCell>{formatDate(comissao.data_pedido)}</TableCell>
                        <TableCell>{formatMesReferencia(comissao.mes_referencia)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(comissao.status)}
                            {getStatusBadge(comissao.status)}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Abrir menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Link to={createPageUrl(`DetalheComissao?id=${comissao.id}`)} className="w-full">
                                  Ver detalhes
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Link to={createPageUrl(`EditarComissao?id=${comissao.id}`)} className="w-full">
                                  Editar
                                </Link>
                              </DropdownMenuItem>
                              {comissao.status === 'pendente' && (
                                <DropdownMenuItem>
                                  <Link to={createPageUrl(`AprovarComissao?id=${comissao.id}`)} className="w-full">
                                    Aprovar
                                  </Link>
                                </DropdownMenuItem>
                              )}
                              {comissao.status === 'aprovada' && (
                                <DropdownMenuItem>
                                  <Link to={createPageUrl(`PagarComissao?id=${comissao.id}`)} className="w-full">
                                    Marcar como paga
                                  </Link>
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center h-64">
                  <DollarSign className="h-12 w-12 text-gray-300 mb-4" />
                  <h3 className="text-lg font-semibold">Nenhuma comissão encontrada</h3>
                  <p className="text-gray-500 text-center mt-2 max-w-md">
                    {searchTerm
                      ? `Não encontramos comissões correspondentes à sua busca.`
                      : `Comece registrando comissões para seus representantes e médicos.`}
                  </p>
                  <Button className="mt-4">Gerar Nova Comissão</Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="representantes" className="m-0">
          {/* Mesmo conteúdo da aba "geral", mas filtrado apenas para representantes */}
        </TabsContent>
        
        <TabsContent value="medicos" className="m-0">
          {/* Mesmo conteúdo da aba "geral", mas filtrado apenas para médicos */}
        </TabsContent>
      </Tabs>
    </div>
  );
}