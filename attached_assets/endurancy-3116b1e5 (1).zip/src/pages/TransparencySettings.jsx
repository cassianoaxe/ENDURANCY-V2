import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  FileBadge, 
  Award, 
  LineChart, 
  Users, 
  CheckCircle2, 
  XCircle, 
  RefreshCw,
  Info,
  Check,
  Search,
  ArrowRight, 
  EyeOff,
  Eye,
  ShieldCheck,
  FileText,
  Building2
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";

// Sample data for organizations
const mockOrganizations = [
  {
    id: "org1",
    name: "MediCannabis Farma",
    type: "Empresa",
    plan: "Empresarial Pro",
    transparency_enabled: true,
    modules: [
      { name: "Portal de Transparência", enabled: true },
      { name: "Documentos Públicos", enabled: true },
      { name: "Certificações", enabled: false },
      { name: "Relatórios Financeiros", enabled: true },
      { name: "Membros e Governança", enabled: true }
    ]
  },
  {
    id: "org2",
    name: "Associação Médica Verde",
    type: "Associação",
    plan: "Associação Premium",
    transparency_enabled: true,
    modules: [
      { name: "Portal de Transparência", enabled: true },
      { name: "Documentos Públicos", enabled: true },
      { name: "Certificações", enabled: true },
      { name: "Relatórios Financeiros", enabled: true },
      { name: "Membros e Governança", enabled: true }
    ]
  },
  {
    id: "org3",
    name: "CannaPesquisa Instituto",
    type: "Associação",
    plan: "Associação Plus",
    transparency_enabled: false,
    modules: [
      { name: "Portal de Transparência", enabled: false },
      { name: "Documentos Públicos", enabled: false },
      { name: "Certificações", enabled: false },
      { name: "Relatórios Financeiros", enabled: false },
      { name: "Membros e Governança", enabled: false }
    ]
  },
  {
    id: "org4",
    name: "Green Medical Brasil",
    type: "Empresa",
    plan: "Empresarial Básico",
    transparency_enabled: false,
    modules: [
      { name: "Portal de Transparência", enabled: false },
      { name: "Documentos Públicos", enabled: false },
      { name: "Certificações", enabled: false },
      { name: "Relatórios Financeiros", enabled: false },
      { name: "Membros e Governança", enabled: false }
    ]
  },
  {
    id: "org5",
    name: "Cannabis Brasil Sul",
    type: "Empresa",
    plan: "Empresarial Pro",
    transparency_enabled: true,
    modules: [
      { name: "Portal de Transparência", enabled: true },
      { name: "Documentos Públicos", enabled: true },
      { name: "Certificações", enabled: true },
      { name: "Relatórios Financeiros", enabled: false },
      { name: "Membros e Governança", enabled: false }
    ]
  }
];

export default function TransparencySettings() {
  const [organizations, setOrganizations] = useState([]);
  const [filteredOrgs, setFilteredOrgs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedOrg, setSelectedOrg] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setOrganizations(mockOrganizations);
      setFilteredOrgs(mockOrganizations);
      setIsLoading(false);
    }, 800);
  }, []);

  useEffect(() => {
    let filtered = organizations;

    // Apply text search
    if (searchTerm) {
      filtered = filtered.filter(org => 
        org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        org.type.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply filter
    if (filter === "enabled") {
      filtered = filtered.filter(org => org.transparency_enabled);
    } else if (filter === "disabled") {
      filtered = filtered.filter(org => !org.transparency_enabled);
    }

    setFilteredOrgs(filtered);
  }, [searchTerm, organizations, filter]);

  const handleToggleTransparency = (orgId, enabled) => {
    const updatedOrgs = organizations.map(org => {
      if (org.id === orgId) {
        const updatedOrg = {
          ...org,
          transparency_enabled: enabled
        };

        // If enabling transparency, set default Portal to enabled
        if (enabled) {
          updatedOrg.modules = org.modules.map((module, index) => 
            index === 0 ? { ...module, enabled: true } : module
          );
        }

        return updatedOrg;
      }
      return org;
    });

    setOrganizations(updatedOrgs);
    setFilteredOrgs(updatedOrgs);

    toast({
      title: enabled ? "Módulo de Transparência Ativado" : "Módulo de Transparência Desativado",
      description: `O módulo de transparência para ${organizations.find(org => org.id === orgId).name} foi ${enabled ? 'ativado' : 'desativado'} com sucesso.`,
    });
  };

  const handleToggleModule = (orgId, moduleName, enabled) => {
    const updatedOrgs = organizations.map(org => {
      if (org.id === orgId) {
        const updatedModules = org.modules.map(module => 
          module.name === moduleName ? { ...module, enabled } : module
        );
        return { ...org, modules: updatedModules };
      }
      return org;
    });

    setOrganizations(updatedOrgs);
    if (selectedOrg) {
      setSelectedOrg(updatedOrgs.find(org => org.id === selectedOrg.id));
    }

    toast({
      title: `Módulo ${enabled ? 'Ativado' : 'Desativado'}`,
      description: `O módulo ${moduleName} foi ${enabled ? 'ativado' : 'desativado'} com sucesso.`,
    });
  };

  const openOrgSettings = (org) => {
    setSelectedOrg(org);
    setShowDialog(true);
  };

  const renderModuleIcon = (moduleName) => {
    switch (moduleName) {
      case "Portal de Transparência": return <Globe className="w-5 h-5 text-blue-500" />;
      case "Documentos Públicos": return <FileBadge className="w-5 h-5 text-green-500" />;
      case "Certificações": return <Award className="w-5 h-5 text-purple-500" />;
      case "Relatórios Financeiros": return <LineChart className="w-5 h-5 text-orange-500" />;
      case "Membros e Governança": return <Users className="w-5 h-5 text-indigo-500" />;
      default: return <FileText className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Configurações de Transparência</h1>
          <p className="text-gray-500 mt-1">
            Gerencie o módulo de transparência para organizações
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => setFilter("all")}>
            <RefreshCw className="w-4 h-4" />
            Limpar Filtros
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Sobre o Módulo de Transparência</CardTitle>
          <CardDescription>
            Este módulo oferece funcionalidades para que as organizações compartilhem informações relevantes com o público.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-blue-50 p-4 rounded-md border border-blue-100">
            <div className="flex gap-3">
              <Info className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium text-blue-900">Funções do Módulo de Transparência</h3>
                <ul className="mt-2 space-y-1 text-blue-800 text-sm">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-blue-500" />
                    Portal público de transparência com fácil acesso
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-blue-500" />
                    Publicação de documentos, estatutos e atas
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-blue-500" />
                    Divulgação de certificações e licenças
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-blue-500" />
                    Compartilhamento de relatórios financeiros e balanços
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-blue-500" />
                    Informações sobre membros, diretoria e governança
                  </li>
                </ul>
                <p className="mt-3 text-sm text-blue-700">
                  <ShieldCheck className="w-4 h-4 inline mr-1" />
                  Apenas administradores podem ativar ou desativar este módulo para as organizações.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar organização..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2 w-full md:w-auto">
          <Button 
            variant={filter === "all" ? "default" : "outline"} 
            className="flex-1 md:flex-none"
            onClick={() => setFilter("all")}
          >
            Todas
          </Button>
          <Button 
            variant={filter === "enabled" ? "default" : "outline"} 
            className="flex-1 md:flex-none"
            onClick={() => setFilter("enabled")}
          >
            Transparência Ativa
          </Button>
          <Button 
            variant={filter === "disabled" ? "default" : "outline"} 
            className="flex-1 md:flex-none"
            onClick={() => setFilter("disabled")}
          >
            Transparência Inativa
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Organizações</CardTitle>
          <CardDescription>
            Gerencie o módulo de transparência para cada organização
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3, 4].map((item) => (
                <div key={item} className="flex justify-between items-center border-b pb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                    <div>
                      <div className="h-4 bg-gray-200 rounded w-40 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-24"></div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <div className="h-6 bg-gray-200 rounded w-20"></div>
                    <div className="h-9 bg-gray-200 rounded w-24"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredOrgs.length === 0 ? (
            <div className="text-center py-8">
              <EyeOff className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-700">Nenhuma organização encontrada</h3>
              <p className="text-gray-500 mt-1">Tente ajustar seus filtros de busca</p>
            </div>
          ) : (
            <div className="space-y-5">
              {filteredOrgs.map((org) => (
                <div key={org.id} className="flex flex-col md:flex-row md:items-center justify-between border-b pb-5 gap-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-blue-100 text-blue-800">
                        {org.name.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{org.name}</div>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Badge variant="outline" className="text-xs font-normal">
                          {org.type}
                        </Badge>
                        <Badge variant="outline" className="text-xs font-normal">
                          {org.plan}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Switch 
                        id={`transparency-${org.id}`}
                        checked={org.transparency_enabled}
                        onCheckedChange={(checked) => handleToggleTransparency(org.id, checked)}
                      />
                      <Label 
                        htmlFor={`transparency-${org.id}`} 
                        className={`text-sm ${org.transparency_enabled ? 'text-green-600' : 'text-gray-500'}`}
                      >
                        {org.transparency_enabled ? 'Ativo' : 'Inativo'}
                      </Label>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      onClick={() => openOrgSettings(org)}
                      disabled={!org.transparency_enabled}
                      className="gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      Detalhes
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog for module settings */}
      {selectedOrg && (
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5" />
                Configurações de Transparência: {selectedOrg.name}
              </DialogTitle>
              <DialogDescription>
                Configure quais módulos de transparência estarão disponíveis para esta organização.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-5 my-2">
              <div className="flex items-center justify-between">
                <div className="flex gap-2 items-center">
                  <Badge className={selectedOrg.transparency_enabled ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                    {selectedOrg.transparency_enabled ? "Módulo Ativo" : "Módulo Inativo"}
                  </Badge>
                  <Badge variant="outline">
                    {selectedOrg.type}
                  </Badge>
                  <Badge variant="outline">
                    {selectedOrg.plan}
                  </Badge>
                </div>
                
                <Switch 
                  id="main-toggle"
                  checked={selectedOrg.transparency_enabled}
                  onCheckedChange={(checked) => handleToggleTransparency(selectedOrg.id, checked)}
                />
              </div>
              
              <Separator />
              
              <div className="space-y-5">
                <h3 className="font-medium">Submódulos Disponíveis</h3>
                
                {selectedOrg.modules.map((module, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {renderModuleIcon(module.name)}
                      <span>{module.name}</span>
                    </div>
                    <Switch 
                      disabled={!selectedOrg.transparency_enabled || (module.name === "Portal de Transparência" && module.enabled)}
                      checked={module.enabled}
                      onCheckedChange={(checked) => handleToggleModule(selectedOrg.id, module.name, checked)}
                    />
                  </div>
                ))}
              </div>
              
              {selectedOrg.transparency_enabled && (
                <div className="bg-blue-50 p-3 rounded border border-blue-100 text-sm text-blue-700">
                  <Info className="w-4 h-4 inline mr-1" /> 
                  O módulo Portal de Transparência é obrigatório e não pode ser desativado enquanto o módulo principal estiver ativo.
                </div>
              )}
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDialog(false)}>
                Fechar
              </Button>
              <Link to={`${createPageUrl("AssociacaoTransparencia")}?org=${selectedOrg.id}`} target="_blank">
                <Button className="gap-1">
                  <Eye className="w-4 h-4" />
                  Visualizar Portal
                </Button>
              </Link>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}