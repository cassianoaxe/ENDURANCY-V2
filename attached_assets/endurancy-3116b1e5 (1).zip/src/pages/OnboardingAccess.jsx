import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Users,
  Shield,
  Lock,
  Plus,
  Edit,
  Trash
} from 'lucide-react';

export default function OnboardingAccess() {
  const [accessRules, setAccessRules] = useState([
    {
      id: 1,
      role: 'Administrador',
      modules: ['Todos'],
      users: 15,
      lastUpdated: '2023-10-15'
    },
    {
      id: 2,
      role: 'Cultivo',
      modules: ['Cultivo', 'Qualidade'],
      users: 25,
      lastUpdated: '2023-10-14'
    },
    {
      id: 3,
      role: 'Dispensário',
      modules: ['Dispensário', 'Pacientes'],
      users: 30,
      lastUpdated: '2023-10-13'
    }
  ]);

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Permissões de Acesso</h1>
          <p className="text-gray-500 mt-1">Gerencie o acesso aos módulos de treinamento</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Nova Regra de Acesso
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Regras de Acesso</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Função</TableHead>
                <TableHead>Módulos</TableHead>
                <TableHead>Usuários</TableHead>
                <TableHead>Última Atualização</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {accessRules.map((rule) => (
                <TableRow key={rule.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4" />
                      {rule.role}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {rule.modules.map((module) => (
                        <Badge key={module} variant="outline">
                          {module}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge>
                      <Users className="w-3 h-3 mr-1" />
                      {rule.users} usuários
                    </Badge>
                  </TableCell>
                  <TableCell>{rule.lastUpdated}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-red-600">
                        <Trash className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}