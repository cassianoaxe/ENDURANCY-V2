import React, { useState, useEffect } from 'react';
import { 
  History, 
  Search, 
  Calendar, 
  User, 
  FileText, 
  Filter, 
  Download,
  Clock,
  Activity
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

export default function ProducaoAuditTrail() {
  const [searchTerm, setSearchTerm] = useState("");
  const [moduleFilter, setModuleFilter] = useState("all");
  const [activityTypeFilter, setActivityTypeFilter] = useState("all");
  const [dateRangeFilter, setDateRangeFilter] = useState("7d");
  const [isLoading, setIsLoading] = useState(true);
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    setTimeout(() => {
      setActivities(mockActivities);
      setIsLoading(false);
    }, 800);
  };

  const filteredActivities = activities.filter(activity => {
    const matchesSearch = 
      activity.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
      activity.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
      activity.context.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesModule = moduleFilter === "all" || activity.module === moduleFilter;
    const matchesType = activityTypeFilter === "all" || activity.type === activityTypeFilter;
    
    return matchesSearch && matchesModule && matchesType;
  });

  const getModuleBadge = (module) => {
    switch (module) {
      case "producao":
        return <Badge className="bg-blue-100 text-blue-800">Produção</Badge>;
      case "qualidade":
        return <Badge className="bg-green-100 text-green-800">Qualidade</Badge>;
      case "laboratorio":
        return <Badge className="bg-purple-100 text-purple-800">Laboratório</Badge>;
      case "estoque":
        return <Badge className="bg-orange-100 text-orange-800">Estoque</Badge>;
      default:
        return <Badge>{module}</Badge>;
    }
  };

  const getTypeBadge = (type) => {
    switch (type) {
      case "create":
        return <Badge className="bg-green-100 text-green-800">Criação</Badge>;
      case "update":
        return <Badge className="bg-blue-100 text-blue-800">Atualização</Badge>;
      case "delete":
        return <Badge className="bg-red-100 text-red-800">Exclusão</Badge>;
      case "login":
        return <Badge className="bg-purple-100 text-purple-800">Login</Badge>;
      case "logout":
        return <Badge className="bg-gray-100 text-gray-800">Logout</Badge>;
      case "export":
        return <Badge className="bg-yellow-100 text-yellow-800">Exportação</Badge>;
      default:
        return <Badge>{type}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Audit Trail</h1>
          <p className="text-muted-foreground">
            Registro detalhado de todas as atividades no sistema para fins de auditoria e rastreabilidade
          </p>
        </div>
        <Button variant="outline" className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Exportar Logs
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filtros</CardTitle>
          <CardDescription>Refine os registros de auditoria por módulo, tipo de atividade ou período</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar por descrição, usuário..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={moduleFilter} onValueChange={setModuleFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Módulo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Módulos</SelectItem>
                <SelectItem value="producao">Produção</SelectItem>
                <SelectItem value="qualidade">Qualidade</SelectItem>
                <SelectItem value="laboratorio">Laboratório</SelectItem>
                <SelectItem value="estoque">Estoque</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={activityTypeFilter} onValueChange={setActivityTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo de Atividade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Tipos</SelectItem>
                <SelectItem value="create">Criação</SelectItem>
                <SelectItem value="update">Atualização</SelectItem>
                <SelectItem value="delete">Exclusão</SelectItem>
                <SelectItem value="login">Login</SelectItem>
                <SelectItem value="logout">Logout</SelectItem>
                <SelectItem value="export">Exportação</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={dateRangeFilter} onValueChange={setDateRangeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">Últimas 24 horas</SelectItem>
                <SelectItem value="7d">Últimos 7 dias</SelectItem>
                <SelectItem value="30d">Últimos 30 dias</SelectItem>
                <SelectItem value="90d">Últimos 90 dias</SelectItem>
                <SelectItem value="all">Todo o período</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Registro de Atividades</CardTitle>
          <CardDescription>
            {filteredActivities.length} atividades encontradas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data e Hora</TableHead>
                <TableHead>Usuário</TableHead>
                <TableHead>Módulo</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Contexto</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center">
                    Carregando...
                  </TableCell>
                </TableRow>
              ) : filteredActivities.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center">
                    Nenhuma atividade encontrada
                  </TableCell>
                </TableRow>
              ) : (
                filteredActivities.map((activity) => (
                  <TableRow key={activity.id}>
                    <TableCell>{activity.timestamp}</TableCell>
                    <TableCell>{activity.user}</TableCell>
                    <TableCell>{getModuleBadge(activity.module)}</TableCell>
                    <TableCell>{getTypeBadge(activity.type)}</TableCell>
                    <TableCell>{activity.description}</TableCell>
                    <TableCell className="max-w-xs truncate">{activity.context}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

const mockActivities = [
  {
    id: "1",
    timestamp: "23/07/2023 14:35:22",
    user: "Carlos Santos",
    module: "producao",
    type: "create",
    description: "Criação de ordem de produção",
    context: "Ordem de produção #OP-2023-125 para Óleo CBD 10%"
  },
  {
    id: "2",
    timestamp: "23/07/2023 13:22:10",
    user: "Ana Lima",
    module: "qualidade",
    type: "update",
    description: "Atualização de análise de qualidade",
    context: "Análise QC-2023-055 atualizada para status Aprovado"
  },
  {
    id: "3",
    timestamp: "23/07/2023 10:15:45",
    user: "Marcelo Oliveira",
    module: "estoque",
    type: "update",
    description: "Movimentação de estoque",
    context: "Transferência de 10kg de CBD isolado para setor de produção"
  },
  {
    id: "4",
    timestamp: "22/07/2023 17:05:33",
    user: "Juliana Costa",
    module: "laboratorio",
    type: "create",
    description: "Novo teste laboratorial",
    context: "Teste de potência para lote LOTE-CBD-072"
  },
  {
    id: "5",
    timestamp: "22/07/2023 14:30:09",
    user: "Rafael Souza",
    module: "producao",
    type: "update",
    description: "Atualização de processo produtivo",
    context: "Etapa de extração concluída para ordem OP-2023-124"
  }
];