import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  User, 
  ArrowLeft, 
  Save, 
  Plus, 
  Calendar, 
  FileText, 
  Mail, 
  Phone, 
  MapPin, 
  AlertCircle, 
  Info, 
  Upload,
  CircleCheck, 
  UserCheck,
  UserPlus,
  X,
  HeartPulse,
  Pill
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "@/components/ui/use-toast";
import { UploadFile } from "@/api/integrations";

// Estados brasileiros
const estados = [
  "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", 
  "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"
];

// Lista de condições médicas comuns
const condicoesMedicas = [
  "Epilepsia", "Epilepsia Refratária", "Parkinson", "Alzheimer", "Dor Crônica", 
  "Fibromialgia", "Esclerose Múltipla", "Ansiedade", "Depressão", "Insônia", 
  "Autismo", "TDAH", "Câncer", "HIV/AIDS", "Artrite", "Artrite Reumatóide",
  "Esclerose Lateral Amiotrófica", "Glaucoma", "Hipertensão", "Diabetes",
  "Síndrome de Tourette", "Esquizofrenia", "TOC", "Síndrome do Pânico"
];

export default function CrmPacienteCadastro() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditMode = Boolean(id);
  const [isLoading, setIsLoading] = useState(isEditMode);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [currentTab, setCurrentTab] = useState("dados-pessoais");
  
  // Estado do formulário
  const [form, setForm] = useState({
    nome_completo: "",
    cpf: "",
    rg: "",
    data_nascimento: null,
    genero: "",
    email: "",
    telefone: "",
    telefone_alternativo: "",
    cep: "",
    endereco: "",
    numero: "",
    complemento: "",
    bairro: "",
    cidade: "",
    estado: "",
    condicoes_medicas: [],
    medicamentos_atuais: [],
    observacoes: "",
    como_conheceu: "",
    documentos: []
  });
  
  // Estado para condições médicas
  const [novaCondicao, setNovaCondicao] = useState("");
  
  // Estado para medicamentos
  const [novoMedicamento, setNovoMedicamento] = useState("");
  
  useEffect(() => {
    if (isEditMode) {
      loadPatientData();
    }
  }, [id]);
  
  const loadPatientData = async () => {
    setIsLoading(true);
    try {
      // Simular busca de dados de um paciente
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Dados mockados para edição
      setForm({
        nome_completo: "Maria Silva Oliveira",
        cpf: "123.456.789-00",
        rg: "12.345.678-9",
        data_nascimento: new Date(1975, 4, 15),
        genero: "feminino",
        email: "maria.silva@email.com",
        telefone: "(11) 98765-4321",
        telefone_alternativo: "",
        cep: "01234-567",
        endereco: "Rua das Flores",
        numero: "123",
        complemento: "",
        bairro: "Jardim Primavera",
        cidade: "São Paulo",
        estado: "SP",
        condicoes_medicas: ["Epilepsia Refratária", "Ansiedade"],
        medicamentos_atuais: ["Rivotril 2mg", "Carbamazepina 200mg"],
        observacoes: "Paciente apresenta episódios de crises convulsivas semanais.",
        como_conheceu: "indicacao",
        documentos: [
          { 
            tipo: "cpf", 
            nome: "CPF.pdf", 
            url: "#", 
            data_upload: new Date(2022, 2, 10).toISOString() 
          },
          { 
            tipo: "laudo_medico", 
            nome: "Laudo_Neurologico.pdf",
            url: "#",
            data_upload: new Date(2022, 2, 10).toISOString()
          }
        ]
      });
      
    } catch (error) {
      console.error("Erro ao carregar dados do paciente:", error);
      toast({
        title: "Erro ao carregar dados",
        description: "Não foi possível obter as informações do paciente.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };
  
  const handleDateChange = (date) => {
    setForm(prev => ({ ...prev, data_nascimento: date }));
  };
  
  const handleAddCondicao = () => {
    if (novaCondicao.trim() === "") return;
    
    if (!form.condicoes_medicas.includes(novaCondicao)) {
      setForm(prev => ({
        ...prev,
        condicoes_medicas: [...prev.condicoes_medicas, novaCondicao]
      }));
    }
    
    setNovaCondicao("");
  };
  
  const handleRemoveCondicao = (condition) => {
    setForm(prev => ({
      ...prev,
      condicoes_medicas: prev.condicoes_medicas.filter(c => c !== condition)
    }));
  };
  
  const handleAddMedicamento = () => {
    if (novoMedicamento.trim() === "") return;
    
    if (!form.medicamentos_atuais.includes(novoMedicamento)) {
      setForm(prev => ({
        ...prev,
        medicamentos_atuais: [...prev.medicamentos_atuais, novoMedicamento]
      }));
    }
    
    setNovoMedicamento("");
  };
  
  const handleRemoveMedicamento = (medication) => {
    setForm(prev => ({
      ...prev,
      medicamentos_atuais: prev.medicamentos_atuais.filter(m => m !== medication)
    }));
  };
  
  const handleDocumentUpload = async (event, tipo) => {
    const file = event.target.files[0];
    if (!file) return;
    
    setIsUploading(true);
    try {
      const result = await UploadFile({ file });
      
      const newDocument = {
        tipo,
        nome: file.name,
        url: result.file_url,
        data_upload: new Date().toISOString()
      };
      
      setForm(prev => ({
        ...prev,
        documentos: [...prev.documentos, newDocument]
      }));
      
      toast({
        title: "Documento enviado",
        description: "O documento foi anexado com sucesso."
      });
    } catch (error) {
      console.error("Erro ao fazer upload:", error);
      toast({
        title: "Erro ao enviar documento",
        description: "Não foi possível enviar o arquivo. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  const handleRemoveDocument = (index) => {
    setForm(prev => ({
      ...prev,
      documentos: prev.documentos.filter((_, i) => i !== index)
    }));
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validação básica
    if (!form.nome_completo || !form.cpf || !form.data_nascimento || !form.telefone || !form.email) {
      toast({
        title: "Dados incompletos",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Simulação de envio para a API
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      console.log("Dados do paciente:", form);
      
      toast({
        title: isEditMode ? "Paciente atualizado" : "Paciente cadastrado",
        description: isEditMode 
          ? "Os dados do paciente foram atualizados com sucesso." 
          : "O paciente foi cadastrado com sucesso."
      });
      
      navigate(createPageUrl("CrmPacientes"));
    } catch (error) {
      console.error("Erro ao salvar paciente:", error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar os dados do paciente. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const formatDate = (date) => {
    if (!date) return "";
    return format(date, "dd/MM/yyyy", { locale: pt });
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-500">Carregando informações do paciente...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate(createPageUrl("CrmPacientes"))}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">
              {isEditMode ? "Editar Paciente" : "Novo Paciente"}
            </h1>
            <p className="text-gray-500">
              {isEditMode ? "Atualize as informações do paciente" : "Cadastre um novo paciente no sistema"}
            </p>
          </div>
        </div>
      </div>
      
      <form onSubmit={handleSubmit}>
        <Tabs value={currentTab} onValueChange={setCurrentTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-1 md:grid-cols-3">
            <TabsTrigger value="dados-pessoais" className="gap-2">
              <User className="h-4 w-4" />
              Dados Pessoais
            </TabsTrigger>
            <TabsTrigger value="endereco" className="gap-2">
              <MapPin className="h-4 w-4" />
              Endereço
            </TabsTrigger>
            <TabsTrigger value="saude" className="gap-2">
              <HeartPulse className="h-4 w-4" />
              Informações de Saúde
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="dados-pessoais" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Informações Pessoais</CardTitle>
                <CardDescription>Dados básicos do paciente</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="nome_completo">
                      Nome Completo <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="nome_completo"
                      name="nome_completo"
                      value={form.nome_completo}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="data_nascimento">
                      Data de Nascimento <span className="text-red-500">*</span>
                    </Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <Calendar className="mr-2 h-4 w-4" />
                          {form.data_nascimento ? formatDate(form.data_nascimento) : "Selecione uma data"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={form.data_nascimento}
                          onSelect={handleDateChange}
                          locale={pt}
                          disabled={(date) => date > new Date()}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  
                  <div>
                    <Label htmlFor="cpf">
                      CPF <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="cpf"
                      name="cpf"
                      value={form.cpf}
                      onChange={handleInputChange}
                      placeholder="000.000.000-00"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="rg">RG</Label>
                    <Input
                      id="rg"
                      name="rg"
                      value={form.rg}
                      onChange={handleInputChange}
                      placeholder="00.000.000-0"
                    />
                  </div>
                  
                  <div>
                    <Label>Gênero <span className="text-red-500">*</span></Label>
                    <RadioGroup
                      value={form.genero}
                      onValueChange={(value) => setForm(prev => ({ ...prev, genero: value }))}
                      className="flex space-x-4 mt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="masculino" id="masculino" />
                        <Label htmlFor="masculino" className="cursor-pointer">Masculino</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="feminino" id="feminino" />
                        <Label htmlFor="feminino" className="cursor-pointer">Feminino</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="outro" id="outro" />
                        <Label htmlFor="outro" className="cursor-pointer">Outro</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div>
                    <Label htmlFor="como_conheceu">Como conheceu a clínica</Label>
                    <Select
                      value={form.como_conheceu}
                      onValueChange={(value) => setForm(prev => ({ ...prev, como_conheceu: value }))}
                    >
                      <SelectTrigger id="como_conheceu">
                        <SelectValue placeholder="Selecione uma opção" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="indicacao">Indicação de amigo/familiar</SelectItem>
                        <SelectItem value="redes_sociais">Redes Sociais</SelectItem>
                        <SelectItem value="site">Site da empresa</SelectItem>
                        <SelectItem value="eventos">Eventos/Palestras</SelectItem>
                        <SelectItem value="midia">Mídia/Imprensa</SelectItem>
                        <SelectItem value="outros">Outros</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Informações de Contato</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="email">
                        Email <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={form.email}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="telefone">
                        Telefone <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="telefone"
                        name="telefone"
                        value={form.telefone}
                        onChange={handleInputChange}
                        placeholder="(00) 00000-0000"
                        required
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="telefone_alternativo">Telefone Alternativo</Label>
                      <Input
                        id="telefone_alternativo"
                        name="telefone_alternativo"
                        value={form.telefone_alternativo}
                        onChange={handleInputChange}
                        placeholder="(00) 00000-0000"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex justify-between">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate(createPageUrl("CrmPacientes"))}
              >
                Cancelar
              </Button>
              
              <Button 
                type="button" 
                onClick={() => setCurrentTab("endereco")}
              >
                Próximo: Endereço
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="endereco" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Endereço</CardTitle>
                <CardDescription>Informações de endereço do paciente</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="md:col-span-1">
                    <Label htmlFor="cep">CEP <span className="text-red-500">*</span></Label>
                    <Input
                      id="cep"
                      name="cep"
                      value={form.cep}
                      onChange={handleInputChange}
                      placeholder="00000-000"
                      required
                    />
                  </div>
                  
                  <div className="md:col-span-3">
                    <Label htmlFor="endereco">Endereço <span className="text-red-500">*</span></Label>
                    <Input
                      id="endereco"
                      name="endereco"
                      value={form.endereco}
                      onChange={handleInputChange}
                      placeholder="Rua, Avenida, etc."
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="numero">Número <span className="text-red-500">*</span></Label>
                    <Input
                      id="numero"
                      name="numero"
                      value={form.numero}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="complemento">Complemento</Label>
                    <Input
                      id="complemento"
                      name="complemento"
                      value={form.complemento}
                      onChange={handleInputChange}
                      placeholder="Apto, Bloco, etc."
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="bairro">Bairro <span className="text-red-500">*</span></Label>
                    <Input
                      id="bairro"
                      name="bairro"
                      value={form.bairro}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="cidade">Cidade <span className="text-red-500">*</span></Label>
                    <Input
                      id="cidade"
                      name="cidade"
                      value={form.cidade}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="estado">Estado <span className="text-red-500">*</span></Label>
                    <Select
                      value={form.estado}
                      onValueChange={(value) => setForm(prev => ({ ...prev, estado: value }))}
                    >
                      <SelectTrigger id="estado">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {estados.map(estado => (
                          <SelectItem key={estado} value={estado}>{estado}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex justify-between">
              <Button
                type="button"
                variant="outline"
                onClick={() => setCurrentTab("dados-pessoais")}
              >
                Voltar: Dados Pessoais
              </Button>
              
              <Button 
                type="button" 
                onClick={() => setCurrentTab("saude")}
              >
                Próximo: Informações de Saúde
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="saude" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Informações de Saúde</CardTitle>
                <CardDescription>Dados médicos do paciente</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label>Condições Médicas</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {form.condicoes_medicas.map((condition, index) => (
                      <Badge key={index} variant="secondary" className="gap-1 pl-2">
                        {condition}
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-4 w-4 rounded-full text-gray-500 hover:text-red-500"
                          onClick={() => handleRemoveCondicao(condition)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2 mt-3">
                    <Select
                      value={novaCondicao}
                      onValueChange={setNovaCondicao}
                    >
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Selecione ou digite uma condição" />
                      </SelectTrigger>
                      <SelectContent>
                        {condicoesMedicas
                          .filter(condition => !form.condicoes_medicas.includes(condition))
                          .map(condition => (
                            <SelectItem key={condition} value={condition}>
                              {condition}
                            </SelectItem>
                          ))
                        }
                      </SelectContent>
                    </Select>
                    <Button
                      type="button"
                      onClick={handleAddCondicao}
                      size="sm"
                    >
                      <Plus className="h-4 w-4 mr-1" /> Adicionar
                    </Button>
                  </div>
                </div>
                
                <div>
                  <Label>Medicamentos em Uso</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {form.medicamentos_atuais.map((medication, index) => (
                      <Badge key={index} variant="outline" className="gap-1 pl-2">
                        <Pill className="h-3 w-3 mr-1" />
                        {medication}
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-4 w-4 rounded-full text-gray-500 hover:text-red-500"
                          onClick={() => handleRemoveMedicamento(medication)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2 mt-3">
                    <Input
                      placeholder="Nome e dosagem do medicamento"
                      value={novoMedicamento}
                      onChange={(e) => setNovoMedicamento(e.target.value)}
                      className="flex-1"
                    />
                    <Button
                      type="button"
                      onClick={handleAddMedicamento}
                      size="sm"
                    >
                      <Plus className="h-4 w-4 mr-1" /> Adicionar
                    </Button>
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea
                    id="observacoes"
                    name="observacoes"
                    value={form.observacoes}
                    onChange={handleInputChange}
                    placeholder="Observações clínicas relevantes"
                    rows={4}
                  />
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Documentos</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label>Documentos Pessoais</Label>
                      <div className="mt-2 space-y-4">
                        <div className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <p className="font-medium">RG e CPF</p>
                            <Input
                              type="file"
                              id="doc-cpf"
                              className="hidden"
                              accept=".pdf,.jpg,.jpeg,.png"
                              onChange={(e) => handleDocumentUpload(e, "cpf")}
                            />
                            <Label
                              htmlFor="doc-cpf"
                              className="cursor-pointer text-sm text-blue-600 hover:text-blue-800"
                            >
                              Anexar
                            </Label>
                          </div>
                          
                          {form.documentos
                            .filter(doc => doc.tipo === "cpf")
                            .map((doc, index) => (
                              <div 
                                key={index} 
                                className="text-sm bg-gray-50 p-2 rounded flex justify-between items-center"
                              >
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-gray-500" />
                                  <span>{doc.nome}</span>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6 text-red-500"
                                  onClick={() => handleRemoveDocument(form.documentos.indexOf(doc))}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ))
                          }
                        </div>
                        
                        <div className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <p className="font-medium">Comprovante de Residência</p>
                            <Input
                              type="file"
                              id="doc-residencia"
                              className="hidden"
                              accept=".pdf,.jpg,.jpeg,.png"
                              onChange={(e) => handleDocumentUpload(e, "comprovante_residencia")}
                            />
                            <Label
                              htmlFor="doc-residencia"
                              className="cursor-pointer text-sm text-blue-600 hover:text-blue-800"
                            >
                              Anexar
                            </Label>
                          </div>
                          
                          {form.documentos
                            .filter(doc => doc.tipo === "comprovante_residencia")
                            .map((doc, index) => (
                              <div 
                                key={index} 
                                className="text-sm bg-gray-50 p-2 rounded flex justify-between items-center"
                              >
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-gray-500" />
                                  <span>{doc.nome}</span>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6 text-red-500"
                                  onClick={() => handleRemoveDocument(form.documentos.indexOf(doc))}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ))
                          }
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <Label>Documentos Médicos</Label>
                      <div className="mt-2 space-y-4">
                        <div className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <p className="font-medium">Laudo Médico</p>
                            <Input
                              type="file"
                              id="doc-laudo"
                              className="hidden"
                              accept=".pdf,.jpg,.jpeg,.png"
                              onChange={(e) => handleDocumentUpload(e, "laudo_medico")}
                            />
                            <Label
                              htmlFor="doc-laudo"
                              className="cursor-pointer text-sm text-blue-600 hover:text-blue-800"
                            >
                              Anexar
                            </Label>
                          </div>
                          
                          {form.documentos
                            .filter(doc => doc.tipo === "laudo_medico")
                            .map((doc, index) => (
                              <div 
                                key={index} 
                                className="text-sm bg-gray-50 p-2 rounded flex justify-between items-center"
                              >
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-gray-500" />
                                  <span>{doc.nome}</span>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6 text-red-500"
                                  onClick={() => handleRemoveDocument(form.documentos.indexOf(doc))}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ))
                          }
                        </div>
                        
                        <div className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <p className="font-medium">Receita Médica</p>
                            <Input
                              type="file"
                              id="doc-receita"
                              className="hidden"
                              accept=".pdf,.jpg,.jpeg,.png"
                              onChange={(e) => handleDocumentUpload(e, "receita")}
                            />
                            <Label
                              htmlFor="doc-receita"
                              className="cursor-pointer text-sm text-blue-600 hover:text-blue-800"
                            >
                              Anexar
                            </Label>
                          </div>
                          
                          {form.documentos
                            .filter(doc => doc.tipo === "receita")
                            .map((doc, index) => (
                              <div 
                                key={index} 
                                className="text-sm bg-gray-50 p-2 rounded flex justify-between items-center"
                              >
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-gray-500" />
                                  <span>{doc.nome}</span>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6 text-red-500"
                                  onClick={() => handleRemoveDocument(form.documentos.indexOf(doc))}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ))
                          }
                        </div>
                        
                        <div className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <p className="font-medium">Outros Documentos</p>
                            <Input
                              type="file"
                              id="doc-outros"
                              className="hidden"
                              accept=".pdf,.jpg,.jpeg,.png"
                              onChange={(e) => handleDocumentUpload(e, "outros")}
                            />
                            <Label
                              htmlFor="doc-outros"
                              className="cursor-pointer text-sm text-blue-600 hover:text-blue-800"
                            >
                              Anexar
                            </Label>
                          </div>
                          
                          {form.documentos
                            .filter(doc => doc.tipo === "outros")
                            .map((doc, index) => (
                              <div 
                                key={index} 
                                className="text-sm bg-gray-50 p-2 rounded flex justify-between items-center"
                              >
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-gray-500" />
                                  <span>{doc.nome}</span>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6 text-red-500"
                                  onClick={() => handleRemoveDocument(form.documentos.indexOf(doc))}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ))
                          }
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex justify-between">
              <Button
                type="button"
                variant="outline"
                onClick={() => setCurrentTab("endereco")}
              >
                Voltar: Endereço
              </Button>
              
              <Button 
                type="submit" 
                className="gap-2"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    Salvar Paciente
                  </>
                )}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </form>
    </div>
  );
}