
import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  PackageCheck, 
  ArrowLeft, 
  Save, 
  Calendar, 
  Warehouse,
  Upload,
  Info,
  CheckSquare,
  AlertTriangle,
  FileText
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { toast } from "@/components/ui/use-toast";
import { UploadFile } from "@/api/integrations";

// Dados simulados para materiais
const mockMaterials = [
  {
    id: "mp001",
    codigo: "MP-CBD-001",
    nome: "Extrato CBD Isolado",
    tipo: "materia_prima",
    fabricante: "CannabEx",
    unidade_medida: "kg",
    requer_analise_qualidade: true
  },
  {
    id: "mp002",
    codigo: "MP-MCT-001",
    nome: "Óleo MCT",
    tipo: "materia_prima",
    fabricante: "NatureOils",
    unidade_medida: "L",
    requer_analise_qualidade: true
  },
  {
    id: "mp003",
    codigo: "MP-HEM-001",
    nome: "Óleo Semente de Cânhamo",
    tipo: "materia_prima",
    fabricante: "HempHarvest",
    unidade_medida: "L",
    requer_analise_qualidade: true
  },
  {
    id: "mp004",
    codigo: "EM-VID-001",
    nome: "Embalagens Vidro Âmbar 30ml",
    tipo: "embalagem",
    fabricante: "GlassPack",
    unidade_medida: "un",
    requer_analise_qualidade: false
  }
];

// Dados simulados para fornecedores
const mockFornecedores = [
  { id: "f001", nome: "CannabTech Distribuidora", contato: "contato@cannabtech.com.br" },
  { id: "f002", nome: "Insumos Farmacêuticos SA", contato: "comercial@insumosfarmaceuticos.com.br" },
  { id: "f003", nome: "Insumos Naturais Ltda", contato: "vendas@insumosnaturais.com.br" }
];

export default function ProducaoNovoLoteMaterial() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const loteId = searchParams.get('id');
  const materialIdParam = searchParams.get('material_id');
  const isEditMode = Boolean(loteId);
  
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadingDoc, setUploadingDoc] = useState(false);
  
  const [formData, setFormData] = useState({
    material_id: materialIdParam || "",
    codigo_lote: `LMP-${String(Math.floor(Math.random() * 1000)).padStart(3, '0')}-${new Date().getFullYear()}`,
    lote_fabricante: "",
    quantidade_total: "",
    unidade_medida: "",
    data_recebimento: new Date().toISOString().split('T')[0],
    data_fabricacao: "",
    data_validade: "",
    fornecedor: "",
    nota_fiscal: "",
    observacao: "",
    requer_analise: true
  });
  
  const [selectedMaterial, setSelectedMaterial] = useState(null);
  const [documentos, setDocumentos] = useState([]);
  
  useEffect(() => {
    if (isEditMode) {
      loadLoteData(loteId);
    } else if (materialIdParam) {
      const material = mockMaterials.find(m => m.id === materialIdParam);
      if (material) {
        handleMaterialChange(materialIdParam);
      }
    }
  }, [loteId, materialIdParam]);
  
  const loadLoteData = async (id) => {
    try {
      setIsLoading(true);
      
      // Em um cenário real, buscaríamos os dados do servidor
      // Aqui simulamos um carregamento
      setTimeout(() => {
        // Mock data para edição
        const loteMock = {
          id,
          material_id: "mp001",
          codigo_lote: "LMP-001-2023",
          lote_fabricante: "CBX-202305-12",
          quantidade_total: "10",
          unidade_medida: "kg",
          data_recebimento: "2023-05-15",
          data_fabricacao: "2023-05-01",
          data_validade: "2024-05-01",
          fornecedor: "f001",
          nota_fiscal: "NF-12345",
          observacao: "Recebido em temperatura controlada",
          requer_analise: true
        };
        
        const documentosMock = [
          { id: "doc1", nome: "Nota Fiscal 12345.pdf", tipo: "nota_fiscal", url: "#" },
          { id: "doc2", nome: "Certificado de Análise.pdf", tipo: "certificado", url: "#" }
        ];
        
        setFormData(loteMock);
        setDocumentos(documentosMock);
        handleMaterialChange(loteMock.material_id);
        
        setIsLoading(false);
      }, 1000);
    } catch (error) {
      console.error("Erro ao carregar dados do lote:", error);
      toast({
        title: "Erro ao carregar dados",
        description: "Não foi possível carregar os dados do lote.",
        variant: "destructive"
      });
      setIsLoading(false);
    }
  };
  
  const handleMaterialChange = (materialId) => {
    const material = mockMaterials.find(m => m.id === materialId);
    if (material) {
      setSelectedMaterial(material);
      setFormData({
        ...formData,
        material_id: materialId,
        unidade_medida: material.unidade_medida,
        requer_analise: material.requer_analise_qualidade
      });
    }
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  const handleSwitchChange = (name, checked) => {
    setFormData({
      ...formData,
      [name]: checked
    });
  };
  
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    try {
      setUploadingDoc(true);
      
      // Em produção, usaríamos a integração real para fazer upload
      // Simulamos um upload bem-sucedido após um delay
      setTimeout(() => {
        const newDoc = {
          id: `doc-${Date.now()}`,
          nome: file.name,
          tipo: file.name.toLowerCase().includes('nota') ? 'nota_fiscal' : 'certificado',
          url: "#"
        };
        
        setDocumentos([...documentos, newDoc]);
        setUploadingDoc(false);
        
        toast({
          title: "Documento enviado",
          description: `O arquivo ${file.name} foi enviado com sucesso.`
        });
      }, 1500);
    } catch (error) {
      console.error("Erro ao fazer upload do arquivo:", error);
      toast({
        title: "Erro no upload",
        description: "Não foi possível enviar o arquivo.",
        variant: "destructive"
      });
      setUploadingDoc(false);
    }
  };
  
  const removeDocumento = (docId) => {
    setDocumentos(documentos.filter(doc => doc.id !== docId));
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validação básica
    if (!formData.material_id || !formData.codigo_lote || !formData.quantidade_total || 
        !formData.data_recebimento || !formData.fornecedor) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // Em um cenário real, enviaríamos os dados para o servidor
      // Aqui simulamos o envio
      setTimeout(() => {
        toast({
          title: isEditMode ? "Lote atualizado" : "Lote cadastrado",
          description: isEditMode 
            ? `O lote ${formData.codigo_lote} foi atualizado com sucesso.` 
            : `O lote ${formData.codigo_lote} foi cadastrado com sucesso.`,
        });
        
        setIsSubmitting(false);
        navigate(createPageUrl("ProducaoMateriasPrimas"));
      }, 1500);
    } catch (error) {
      console.error("Erro ao salvar lote:", error);
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar o lote.",
        variant: "destructive"
      });
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => navigate(createPageUrl("ProducaoMateriasPrimas"))}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <PackageCheck className="h-6 w-6" />
              {isEditMode ? "Editar Lote" : "Novo Lote de Material"}
            </h1>
            <p className="text-gray-500 mt-1">
              {isEditMode 
                ? "Atualize as informações do lote existente" 
                : "Registre a entrada de um novo lote de material no sistema"}
            </p>
          </div>
        </div>
        
        <Button className="gap-2" onClick={handleSubmit} disabled={isSubmitting}>
          <Save className="h-4 w-4" />
          {isSubmitting ? "Salvando..." : "Salvar Lote"}
        </Button>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center h-60">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações do Lote</CardTitle>
              <CardDescription>
                Detalhes do lote de material recebido
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="material_id">Material <span className="text-red-500">*</span></Label>
                  <Select
                    value={formData.material_id}
                    onValueChange={(value) => handleMaterialChange(value)}
                    disabled={isEditMode}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o material" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockMaterials.map(material => (
                        <SelectItem key={material.id} value={material.id}>
                          {material.codigo} - {material.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="codigo_lote">Código do Lote <span className="text-red-500">*</span></Label>
                  <Input
                    id="codigo_lote"
                    name="codigo_lote"
                    value={formData.codigo_lote}
                    onChange={handleInputChange}
                    placeholder="Ex: LMP-001-2023"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="lote_fabricante">Lote do Fabricante</Label>
                  <Input
                    id="lote_fabricante"
                    name="lote_fabricante"
                    value={formData.lote_fabricante}
                    onChange={handleInputChange}
                    placeholder="Número do lote atribuído pelo fabricante"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="fornecedor">Fornecedor <span className="text-red-500">*</span></Label>
                  <Select
                    value={formData.fornecedor}
                    onValueChange={(value) => handleSelectChange("fornecedor", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o fornecedor" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockFornecedores.map(fornecedor => (
                        <SelectItem key={fornecedor.id} value={fornecedor.id}>
                          {fornecedor.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="quantidade_total">Quantidade Total <span className="text-red-500">*</span></Label>
                  <div className="flex gap-2">
                    <Input
                      id="quantidade_total"
                      name="quantidade_total"
                      type="number"
                      value={formData.quantidade_total}
                      onChange={handleInputChange}
                      placeholder="Quantidade recebida"
                    />
                    <div className="w-20 flex-shrink-0">
                      <Input 
                        value={formData.unidade_medida} 
                        readOnly 
                        disabled
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="nota_fiscal">Nota Fiscal</Label>
                  <Input
                    id="nota_fiscal"
                    name="nota_fiscal"
                    value={formData.nota_fiscal}
                    onChange={handleInputChange}
                    placeholder="Número da nota fiscal"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="data_recebimento">Data de Recebimento <span className="text-red-500">*</span></Label>
                  <div className="flex gap-2 items-center">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <Input
                      id="data_recebimento"
                      name="data_recebimento"
                      type="date"
                      value={formData.data_recebimento}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="data_fabricacao">Data de Fabricação</Label>
                  <div className="flex gap-2 items-center">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <Input
                      id="data_fabricacao"
                      name="data_fabricacao"
                      type="date"
                      value={formData.data_fabricacao}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="data_validade">Data de Validade</Label>
                  <div className="flex gap-2 items-center">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <Input
                      id="data_validade"
                      name="data_validade"
                      type="date"
                      value={formData.data_validade}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                
                <div className="space-y-2 flex items-center gap-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="requer_analise"
                      checked={formData.requer_analise}
                      onCheckedChange={(checked) => handleSwitchChange("requer_analise", checked)}
                      disabled={selectedMaterial && selectedMaterial.requer_analise_qualidade}
                    />
                    <Label htmlFor="requer_analise">Requer Análise de Qualidade</Label>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="observacao">Observações</Label>
                <Textarea
                  id="observacao"
                  name="observacao"
                  value={formData.observacao}
                  onChange={handleInputChange}
                  placeholder="Observações adicionais sobre o lote"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Documentos do Lote</CardTitle>
              <CardDescription>
                Carregue a nota fiscal, certificado de análise e outros documentos relacionados
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col items-center justify-center gap-4 p-6 border-2 border-dashed rounded-lg">
                <Upload className="h-10 w-10 text-gray-400" />
                <div className="text-center">
                  <h3 className="font-medium">Arraste e solte ou clique para enviar</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    PDF, JPG, PNG até 10MB
                  </p>
                </div>
                <Button variant="outline" disabled={uploadingDoc} onClick={() => document.getElementById('fileInput').click()}>
                  {uploadingDoc ? "Enviando..." : "Selecionar Arquivo"}
                </Button>
                <Input 
                  id="fileInput" 
                  type="file" 
                  className="hidden" 
                  onChange={handleFileUpload}
                  accept=".pdf,.jpg,.jpeg,.png"
                />
              </div>
              
              {documentos.length > 0 ? (
                <div className="space-y-4">
                  <h3 className="text-sm font-medium">Documentos Enviados</h3>
                  {documentos.map((doc) => (
                    <div key={doc.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-gray-100 rounded-md">
                          <FileText className="h-5 w-5 text-gray-600" />
                        </div>
                        <div>
                          <p className="font-medium">{doc.nome}</p>
                          <p className="text-sm text-gray-500">
                            {doc.tipo === 'nota_fiscal' ? 'Nota Fiscal' : 
                             doc.tipo === 'certificado' ? 'Certificado de Análise' : 'Documento'}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm" className="text-blue-600">
                          Visualizar
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-600" onClick={() => removeDocumento(doc.id)}>
                          Remover
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertTitle>Nenhum documento</AlertTitle>
                  <AlertDescription>
                    Recomendamos enviar a nota fiscal e o certificado de análise do fabricante.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
          
          {formData.requer_analise && (
            <Alert className="bg-yellow-50 border-yellow-200">
              <AlertTriangle className="h-4 w-4 text-yellow-700" />
              <AlertTitle className="text-yellow-800">Este material requer análise de qualidade</AlertTitle>
              <AlertDescription className="text-yellow-700">
                Após o cadastro, este lote entrará automaticamente na fila do Controle de Qualidade para análise e aprovação antes de ser liberado para uso.
              </AlertDescription>
            </Alert>
          )}
        </div>
      )}
    </div>
  );
}
