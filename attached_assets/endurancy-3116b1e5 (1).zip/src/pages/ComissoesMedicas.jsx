import React, { useState, useEffect } from 'react';
import { ComissaoMedica } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { 
  BarChart, 
  Calendar, 
  DollarSign, 
  Download, 
  FileText, 
  Filter, 
  MoreHorizontal, 
  Printer, 
  Search, 
  User, 
  UserCheck, 
  CheckCircle2, 
  XCircle, 
  Clock 
} from "lucide-react";

export default function ComissoesMedicas() {
  const [comissoes, setComissoes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');
  const [periodoFilter, setPeriodoFilter] = useState('atual');

  useEffect(() => {
    loadComissoes();
  }, []);

  const loadComissoes = async () => {
    try {
      setIsLoading(true);
      const result = await ComissaoMedica.list('-data_calculo');
      setComissoes(result);
    } catch (error) {
      console.error('Erro ao carregar comissões médicas:', error);
      // Usar dados de demonstração caso a API falhe
      setComissoes([
        {
          id: '1',
          medico_id: 'med1',
          nome_medico: 'Dra. Maria Santos',
          crm: '123456/SP',
          pedido_id: 'PED-002',
          paciente_id: 'pac1',
          nome_paciente: 'José Silva',
          prescricao_id: 'PRESC-001',
          valor_pedido: 2200.00,
          percentual_comissao: 5,
          valor_comissao: 110.00,
          data_pedido: '2023-07-18T09:45:00Z',
          data_calculo: '2023-07-19T11:30:00Z',
          status: 'aprovada',
          mes_referencia: '2023-07'
        },
        {
          id: '2',
          medico_id: 'med2',
          nome_medico: 'Dr. João Oliveira',
          crm: '654321/SP',
          pedido_id: 'PED-004',
          paciente_id: 'pac2',
          nome_paciente: 'Ana Pereira',
          prescricao_id: 'PRESC-002',
          valor_pedido: 3500.00,
          percentual_comissao: 5,
          valor_comissao: 175.00,
          data_pedido: '2023-08-05T11:30:00Z',
          data_calculo: '2023-08-06T09:00:00Z',
          status: 'pendente',
          mes_referencia: '2023-08'
        },
        {
          id: '3',
          medico_id: 'med1',
          nome_medico: 'Dra. Maria Santos',
          crm: '123456/SP',
          pedido_id: 'PED-007',
          paciente_id: 'pac3',
          nome_paciente: 'Pedro Souza',
          prescricao_id: 'PRESC-005',
          valor_pedido: 1850.00,
          percentual_comissao: 5,
          valor_comissao: 92.50,
          data_pedido: '2023-08-12T14:25:00Z',
          data_calculo: '2023-08-13T10:00:00Z',
          status: 'pendente',
          mes_referencia: '2023-08'
        },
        {
          id: '4',
          medico_id: 'med3',
          nome_medico: 'Dr. Roberto Costa',
          crm: '789012/SP',
          pedido_id: 'PED-005',
          paciente_id: 'pac4',
          nome_paciente: 'Carla Oliveira',
          prescricao_id: 'PRESC-003',
          valor_pedido: 2700.00,
          percentual_comissao: 5,
          valor_comissao: 135.00,
          data_pedido: '2023-07-25T16:10:00Z',
          data_calculo: '2023-07-26T09:30:00Z',
          status: 'paga',
          mes_referencia: '2023-07',
          data_pagamento: '2023-08-10T14:00:00Z'
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredComissoes = comissoes.filter(com => {
    const matchesSearch = 
      com.nome_medico?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      com.nome_paciente?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      com.pedido_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      com.crm?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'todos' || com.status === statusFilter;
    
    // Filtro por período (mês atual, mês anterior, etc.)
    let matchesPeriodo = true;
    if (periodoFilter !== 'todos') {
      const now = new Date();
      const mesAtual = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
      
      if (periodoFilter === 'atual' && com.mes_referencia !== mesAtual) {
        matchesPeriodo = false;
      } else if (periodoFilter === 'anterior') {
        const lastMonth = now.getMonth() === 0 
          ? `${now.getFullYear() - 1}-12` 
          : `${now.getFullYear()}-${String(now.getMonth()).padStart(2, '0')}`;
        matchesPeriodo = com.mes_referencia === lastMonth;
      }
    }
    
    return matchesSearch && matchesStatus && matchesPeriodo;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'paga':
        return <Badge className="bg-green-100 text-green-800">Paga</Badge>;
      case 'aprovada':
        return <Badge className="bg-blue-100 text-blue-800">Aprovada</Badge>;
      case 'pendente':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'cancelada':
        return <Badge className="bg-red-100 text-red-800">Cancelada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  const formatMesReferencia = (mesRef) => {
    if (!mesRef) return '';
    const [ano, mes] = mesRef.split('-');
    const meses = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ];
    return `${meses[parseInt(mes) - 1]} ${ano}`;
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'paga':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'aprovada':
        return <CheckCircle2 className="h-4 w-4 text-blue-500" />;
      case 'pendente':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'cancelada':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  // Cálculo de estatísticas
  const totalComissoes = filteredComissoes.reduce((acc, com) => acc + com.valor_comissao, 0);
  const totalPendente = filteredComissoes
    .filter(com => com.status === 'pendente')
    .reduce((acc, com) => acc + com.valor_comissao, 0);
  const totalAprovada = filteredComissoes
    .filter(com => com.status === 'aprovada')
    .reduce((acc, com) => acc + com.valor_comissao, 0);
  const totalPaga = filteredComissoes
    .filter(com => com.status === 'paga')
    .reduce((acc, com) => acc + com.valor_comissao, 0);
    
  // Agrupar por médico para mostrar estatísticas
  const comissoesPorMedico = filteredComissoes.reduce((acc, com) => {
    if (!acc[com.medico_id]) {
      acc[com.medico_id] = {
        nome: com.nome_medico,
        crm: com.crm,
        total: 0,
        count: 0
      };
    }
    acc[com.medico_id].total += com.valor_comissao;
    acc[com.medico_id].count += 1;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Comissões Médicas</h1>
          <p className="text-gray-500 mt-1">Gerenciamento de comissões para médicos parceiros</p>
        </div>
        
        <div className="flex gap-3">
          <Button variant="outline" className="flex gap-2 items-center">
            <Download className="w-4 h-4" />
            Exportar
          </Button>
          <Button variant="outline" className="flex gap-2 items-center">
            <Printer className="w-4 h-4" />
            Imprimir
          </Button>
          <Link to={createPageUrl("NovaComissaoMedica")}>
            <Button className="flex gap-2 items-center">
              <DollarSign className="w-4 h-4" />
              Nova Comissão
            </Button>
          </Link>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="py-4">
            <CardTitle className="text-sm font-medium text-gray-500">Total de Comissões</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold">{formatCurrency(totalComissoes)}</div>
            <p className="text-xs text-gray-500 mt-1">Total calculado para médicos</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="py-4">
            <CardTitle className="text-sm font-medium text-gray-500">Comissões Pendentes</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold text-yellow-600">{formatCurrency(totalPendente)}</div>
            <p className="text-xs text-gray-500 mt-1">Aguardando aprovação</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="py-4">
            <CardTitle className="text-sm font-medium text-gray-500">Comissões Aprovadas</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold text-blue-600">{formatCurrency(totalAprovada)}</div>
            <p className="text-xs text-gray-500 mt-1">Aguardando pagamento</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="py-4">
            <CardTitle className="text-sm font-medium text-gray-500">Comissões Pagas</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalPaga)}</div>
            <p className="text-xs text-gray-500 mt-1">Neste período</p>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="lista" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="lista">Lista de Comissões</TabsTrigger>
          <TabsTrigger value="medicos">Por Médico</TabsTrigger>
        </TabsList>
        
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 my-4">
          <div className="flex flex-wrap gap-3">
            <div className="w-full md:w-auto">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos os status</SelectItem>
                  <SelectItem value="pendente">Pendentes</SelectItem>
                  <SelectItem value="aprovada">Aprovadas</SelectItem>
                  <SelectItem value="paga">Pagas</SelectItem>
                  <SelectItem value="cancelada">Canceladas</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full md:w-auto">
              <Select value={periodoFilter} onValueChange={setPeriodoFilter}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos os períodos</SelectItem>
                  <SelectItem value="atual">Mês atual</SelectItem>
                  <SelectItem value="anterior">Mês anterior</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Buscar comissão..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        {/* Conteúdo das tabs */}
        <TabsContent value="lista" className="m-0">
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="flex flex-col items-center">
                    <div className="animate-spin h-8 w-8 border-4 border-green-500 rounded-full border-t-transparent"></div>
                    <p className="mt-4 text-gray-500">Carregando comissões...</p>
                  </div>
                </div>
              ) : filteredComissoes.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Médico</TableHead>
                      <TableHead>Paciente</TableHead>
                      <TableHead>Pedido</TableHead>
                      <TableHead>Valor do Pedido</TableHead>
                      <TableHead>Comissão</TableHead>
                      <TableHead>Data do Pedido</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredComissoes.map((comissao) => (
                      <TableRow key={comissao.id}>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-medium">{comissao.nome_medico}</span>
                            <span className="text-xs text-gray-500">{comissao.crm}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-medium">{comissao.nome_paciente}</span>
                            <span className="text-xs text-gray-500 hover:text-blue-600">
                              <Link to={createPageUrl(`Prescricao?id=${comissao.prescricao_id}`)}>
                                Prescrição: {comissao.prescricao_id}
                              </Link>
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Link to={createPageUrl(`DetalhePedido?id=${comissao.pedido_id}`)} className="hover:text-blue-600">
                            {comissao.pedido_id}
                          </Link>
                        </TableCell>
                        <TableCell>{formatCurrency(comissao.valor_pedido)}</TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-medium">{formatCurrency(comissao.valor_comissao)}</span>
                            <span className="text-xs text-gray-500">{comissao.percentual_comissao}%</span>
                          </div>
                        </TableCell>
                        <TableCell>{formatDate(comissao.data_pedido)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(comissao.status)}
                            {getStatusBadge(comissao.status)}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Abrir menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Link to={createPageUrl(`DetalheComissaoMedica?id=${comissao.id}`)} className="w-full">
                                  Ver detalhes
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Link to={createPageUrl(`EditarComissaoMedica?id=${comissao.id}`)} className="w-full">
                                  Editar
                                </Link>
                              </DropdownMenuItem>
                              {comissao.status === 'pendente' && (
                                <DropdownMenuItem>
                                  <Link to={createPageUrl(`AprovarComissaoMedica?id=${comissao.id}`)} className="w-full">
                                    Aprovar
                                  </Link>
                                </DropdownMenuItem>
                              )}
                              {comissao.status === 'aprovada' && (
                                <DropdownMenuItem>
                                  <Link to={createPageUrl(`PagarComissaoMedica?id=${comissao.id}`)} className="w-full">
                                    Marcar como paga
                                  </Link>
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center h-64">
                  <DollarSign className="h-12 w-12 text-gray-300 mb-4" />
                  <h3 className="text-lg font-semibold">Nenhuma comissão médica encontrada</h3>
                  <p className="text-gray-500 text-center mt-2 max-w-md">
                    {searchTerm
                      ? `Não encontramos comissões correspondentes à sua busca.`
                      : `Comece registrando comissões para seus médicos parceiros.`}
                  </p>
                  <Link to={createPageUrl("NovaComissaoMedica")}>
                    <Button className="mt-4">Nova Comissão Médica</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="medicos" className="m-0">
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin h-8 w-8 border-4 border-green-500 rounded-full border-t-transparent"></div>
                  <p className="mt-4 text-gray-500">Carregando estatísticas...</p>
                </div>
              ) : Object.keys(comissoesPorMedico).length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Médico</TableHead>
                      <TableHead>CRM</TableHead>
                      <TableHead>Quantidade de Comissões</TableHead>
                      <TableHead>Valor Total</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(comissoesPorMedico).map(([id, medico]) => (
                      <TableRow key={id}>
                        <TableCell className="font-medium">
                          <Link to={createPageUrl(`Medico?id=${id}`)} className="hover:text-blue-600">
                            {medico.nome}
                          </Link>
                        </TableCell>
                        <TableCell>{medico.crm}</TableCell>
                        <TableCell>{medico.count} comissões</TableCell>
                        <TableCell className="font-medium">{formatCurrency(medico.total)}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm">
                            <Link to={createPageUrl(`ComissoesMedicoPorId?id=${id}`)}>
                              Ver detalhes
                            </Link>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center h-64">
                  <UserCheck className="h-12 w-12 text-gray-300 mb-4" />
                  <h3 className="text-lg font-semibold">Nenhum médico com comissões encontrado</h3>
                  <p className="text-gray-500 text-center mt-2 max-w-md">
                    Não há registros de comissões para médicos no período selecionado.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}