import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { InvokeLLM } from "@/api/integrations";
import {
  BarChart4,
  TrendingUp,
  Calendar,
  FileText,
  Search,
  Download,
  Brain,
  CornerUpRight,
  DollarSign,
  PieChart,
  RefreshCw,
  Filter,
  Zap,
  AlertCircle,
  CheckCircle,
  ArrowUp,
  ArrowDown,
  HelpCircle,
  Lightbulb
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/components/ui/use-toast";
import { Progress } from "@/components/ui/progress";

// Componente para visualização de gráfico de linha
const LineChart = ({ data, height = 100, color = "blue" }) => {
  return (
    <div style={{ height: `${height}px` }} className="w-full bg-gray-50 dark:bg-gray-800 rounded-md border flex items-end">
      {data.map((value, index) => (
        <div 
          key={index} 
          className="h-full flex-1 flex flex-col justify-end px-1"
        >
          <div 
            style={{ 
              height: `${Math.max(value, 5)}%`,
              backgroundColor: color === "blue" ? "#3b82f6" : 
                              color === "green" ? "#10b981" : 
                              color === "red" ? "#ef4444" : 
                              color === "purple" ? "#8b5cf6" : "#3b82f6"
            }} 
            className="w-full rounded-t-sm"
          ></div>
          <div className="text-[10px] text-center mt-1 text-gray-500">
            {index + 1}
          </div>
        </div>
      ))}
    </div>
  );
};

export default function AnaliseFinanceiraIA() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [analysisType, setAnalysisType] = useState("automated");
  const [timePeriod, setTimePeriod] = useState("current-quarter");
  const [dataFocus, setDataFocus] = useState("all");
  const [customQuestion, setCustomQuestion] = useState("");
  const [fileType, setFileType] = useState("pdf");
  const [analysisResult, setAnalysisResult] = useState(null);
  const [insightProgress, setInsightProgress] = useState(0);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [focusedInsight, setFocusedInsight] = useState(null);
  
  // Dados simulados para demonstração
  const financialMetrics = {
    revenue: {
      current: 485000,
      previous: 410000,
      trend: 18.3,
      forecast_next: 520000,
      monthly: [38000, 41000, 42500, 39800, 43200, 45000, 39500, 42000, 42800, 44500, 47500, 49200]
    },
    expenses: {
      current: 352000,
      previous: 310000,
      trend: 13.5,
      forecast_next: 378000,
      monthly: [28000, 30500, 32000, 29800, 31200, 33000, 30500, 30000, 31800, 33500, 37500, 34200]
    },
    profit: {
      current: 133000,
      previous: 100000,
      trend: 33.0,
      forecast_next: 142000,
      monthly: [10000, 10500, 10500, 10000, 12000, 12000, 9000, 12000, 11000, 11000, 10000, 15000]
    },
    cash_flow: {
      current: 96000,
      previous: 85000,
      trend: 12.9,
      forecast_next: 105000
    },
    accounts_receivable: {
      current: 145000,
      previous: 132000,
      trend: 9.8,
      aging: {
        "0-30": 68000,
        "31-60": 42000,
        "61-90": 25000,
        "90+": 10000
      }
    },
    accounts_payable: {
      current: 112000,
      previous: 98000,
      trend: 14.3,
      aging: {
        "0-30": 72000,
        "31-60": 32000,
        "61-90": 8000,
        "90+": 0
      }
    }
  };
  
  // Dados simulados para insights de IA
  const sampleInsights = [
    {
      id: 1,
      title: "Crescimento de Receita Acima do Mercado",
      description: "Sua receita cresceu 18.3% em relação ao período anterior, superando a média do setor que é de 12.5%. Esse crescimento foi impulsionado principalmente pelos segmentos de vendas diretas e serviços especializados.",
      impact: "high",
      category: "revenue",
      action_items: [
        "Aumentar investimento nos canais de vendas diretas que apresentaram melhor desempenho",
        "Expandir oferta de serviços especializados que tiveram maior margem",
        "Considerar ajustes de preço em produtos de alto desempenho"
      ],
      metrics: {
        key_driver: "Serviços Especializados",
        growth_contribution: "42%",
        projected_impact: "+5.2% na receita Q4"
      }
    },
    {
      id: 2,
      title: "Aumento Significativo nas Despesas Operacionais",
      description: "As despesas operacionais aumentaram 13.5%, impactando a margem de lucro. A análise indica que os principais contribuintes foram custos logísticos (+22%) e despesas com marketing digital (+18%).",
      impact: "medium",
      category: "expenses",
      action_items: [
        "Revisar contratos com fornecedores logísticos e buscar alternativas",
        "Otimizar campanhas de marketing digital focando nos canais com melhor ROI",
        "Implementar controle de custos mais rigoroso para despesas discricionárias"
      ],
      metrics: {
        key_driver: "Custos Logísticos",
        expense_increase: "R$ 24.500",
        optimization_potential: "8-12% de redução possível"
      }
    },
    {
      id: 3,
      title: "Oportunidade de Otimização de Contas a Receber",
      description: "Há R$ 35.000 em contas a receber com mais de 60 dias, representando 24% do total. Este valor está 8% acima do benchmark do setor e impacta negativamente o fluxo de caixa.",
      impact: "medium",
      category: "cash_flow",
      action_items: [
        "Implementar processos de cobrança mais eficientes para faturas acima de 30 dias",
        "Oferecer descontos para pagamentos antecipados",
        "Revisar política de crédito para clientes com histórico de atrasos"
      ],
      metrics: {
        aging_concern: "60+ dias",
        sector_benchmark: "16%",
        cash_flow_impact: "R$ 35.000"
      }
    },
    {
      id: 4,
      title: "Projeção de Crescimento Sustentado",
      description: "A análise de tendência indica crescimento sustentado de receita nos próximos dois trimestres, com projeção de aumento de 7.2% no próximo trimestre. Este crescimento está alinhado com a expansão do mercado e suas iniciativas estratégicas.",
      impact: "positive",
      category: "forecast",
      action_items: [
        "Preparar operações para maior volume de vendas",
        "Antecipar necessidades de estoque para os produtos mais vendidos",
        "Considerar contratações estratégicas para áreas de alta demanda"
      ],
      metrics: {
        forecast_confidence: "85%",
        growth_projection: "7.2% Q4, 5.8% Q1",
        market_alignment: "Acima da média em 2.1 pontos percentuais"
      }
    },
    {
      id: 5,
      title: "Sazonalidade Identificada nos Padrões de Venda",
      description: "A análise temporal identificou um padrão sazonal claro, com picos nos meses 6, 11 e 12, e queda no mês 7. Estas flutuações são 22% mais pronunciadas que no ano anterior.",
      impact: "informational",
      category: "patterns",
      action_items: [
        "Ajustar planejamento de estoque considerando sazonalidade",
        "Implementar campanhas promocionais nos períodos de baixa demanda",
        "Otimizar alocação de pessoal conforme flutuação da demanda"
      ],
      metrics: {
        peak_months: "Junho, Novembro, Dezembro",
        low_month: "Julho",
        seasonal_variation: "22% (ano a ano)"
      }
    }
  ];
  
  useEffect(() => {
    // Simula carregamento inicial de dados
    setIsLoading(true);
    const currentDate = new Date();
    setLastUpdated(currentDate.toLocaleString());
    
    setTimeout(() => {
      setAnalysisResult({
        insights: sampleInsights,
        metrics: financialMetrics,
        summary: "A análise financeira do período atual mostra um desempenho positivo, com crescimento de receita de 18.3% e aumento de lucro de 33.0% em comparação com o período anterior. Existem oportunidades de otimização em despesas operacionais e gerenciamento de contas a receber que, se implementadas, podem melhorar ainda mais o desempenho."
      });
      setIsLoading(false);
    }, 1500);
  }, []);
  
  // Simula a geração de nova análise com IA
  const generateAnalysis = async () => {
    setIsLoading(true);
    setInsightProgress(0);
    
    // Simula o progresso da análise
    const progressInterval = setInterval(() => {
      setInsightProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 5;
      });
    }, 200);
    
    try {
      // Aqui seria feita a chamada real para a IA com InvokeLLM
      // Para demo, usamos timeout para simular processamento
      setTimeout(async () => {
        if (analysisType === "custom" && customQuestion) {
          // Se for uma pergunta personalizada, simula uma resposta da IA
          try {
            const response = await InvokeLLM({
              prompt: `Você é um analista financeiro especializado. O usuário está analisando dados financeiros e fez a seguinte pergunta: "${customQuestion}". 
              Com base nos seguintes dados financeiros da empresa: Receita: R$485.000 (aumento de 18.3%), 
              Despesas: R$352.000 (aumento de 13.5%), Lucro: R$133.000 (aumento de 33.0%), 
              Contas a receber: R$145.000 (R$35.000 com mais de 60 dias), 
              Contas a pagar: R$112.000. 
              
              Forneça uma análise detalhada, insights estratégicos e recomendações acionáveis.`,
              response_json_schema: {
                type: "object",
                properties: {
                  analysis: { type: "string" },
                  key_insights: { type: "array", items: { type: "string" } },
                  recommendations: { type: "array", items: { type: "string" } },
                  metrics_to_monitor: { type: "array", items: { type: "string" } }
                }
              }
            });
            
            // Atualiza o resultado com a resposta da AI
            setAnalysisResult({
              ...analysisResult,
              custom_analysis: response
            });
            
            toast({
              title: "Análise personalizada concluída",
              description: "A IA analisou sua pergunta e gerou insights específicos."
            });
          } catch (error) {
            console.error("Erro ao gerar análise com IA:", error);
            // Em caso de erro na API, usamos uma resposta simulada
            setAnalysisResult({
              ...analysisResult,
              custom_analysis: {
                analysis: `Analisando sua pergunta "${customQuestion}": Os dados financeiros mostram um crescimento sólido da receita (18.3%) superando o aumento de despesas (13.5%), resultando em um expressivo aumento do lucro (33%). Isso indica uma melhoria na eficiência operacional e alavancagem de escala. Porém, 24% das contas a receber estão com mais de 60 dias de atraso, o que pode afetar o fluxo de caixa.`,
                key_insights: [
                  "A margem de lucro aumentou de 24.4% para 27.4%, mostrando maior eficiência operacional",
                  "O crescimento do lucro (33%) sendo maior que o da receita (18.3%) indica boa alavancagem operacional",
                  "A gestão de contas a receber precisa de atenção, com R$35.000 acima de 60 dias"
                ],
                recommendations: [
                  "Focar em análise de rentabilidade por produto/serviço para identificar os maiores contribuintes para esse aumento de margem",
                  "Implementar um programa de otimização de despesas para manter a tendência de crescimento do lucro",
                  "Revisar política de cobrança e considerar descontos para pagamentos antecipados"
                ],
                metrics_to_monitor: [
                  "Margem de lucro por linha de produto",
                  "Prazo médio de recebimento",
                  "Relação entre crescimento de despesas e receitas"
                ]
              }
            });
          }
        } else {
          // Para análise automática, atualiza com insights atualizados
          const currentDate = new Date();
          setLastUpdated(currentDate.toLocaleString());
          
          // Simula atualização dos insights
          const updatedInsights = [...sampleInsights];
          updatedInsights.push({
            id: 6,
            title: "Tendência de Crescimento Sustentável no Segmento Principal",
            description: "Análise detalhada dos últimos 12 meses indica que seu segmento principal de produtos mantém crescimento constante de 4.2% ao mês, superando a inflação e crescimento médio do setor. Esta tendência sugere potencial para expansão.",
            impact: "positive",
            category: "revenue",
            action_items: [
              "Aumentar capacidade produtiva para este segmento",
              "Considerar expansão geográfica dentro do mesmo segmento",
              "Desenvolver produtos complementares para cross-selling"
            ],
            metrics: {
              monthly_growth: "4.2%",
              industry_comparison: "+2.1% vs. média do setor",
              product_contribution: "37% da receita total"
            }
          });
          
          setAnalysisResult({
            ...analysisResult,
            insights: updatedInsights,
            summary: "A análise financeira atualizada confirma a tendência positiva de crescimento, com destaque para o desempenho do segmento principal de produtos. A otimização de despesas operacionais teve efeito positivo, mas ainda há oportunidades significativas no gerenciamento de contas a receber."
          });
          
          toast({
            title: "Análise atualizada com sucesso",
            description: "Novos insights e tendências foram identificados nos dados financeiros."
          });
        }
        
        clearInterval(progressInterval);
        setInsightProgress(100);
        setIsLoading(false);
      }, 3000);
      
    } catch (error) {
      console.error("Erro ao gerar análise:", error);
      toast({
        title: "Erro ao gerar análise",
        description: "Ocorreu um erro ao processar os dados. Tente novamente.",
        variant: "destructive"
      });
      clearInterval(progressInterval);
      setIsLoading(false);
    }
  };
  
  // Função para exportar análise
  const exportAnalysis = () => {
    toast({
      title: `Exportando análise em ${fileType.toUpperCase()}`,
      description: "O download começará em breve."
    });
  };
  
  // Renderiza cartões de métricas principais
  const renderMetricCards = () => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Receita</CardTitle>
            <CardDescription>
              Comparado ao período anterior
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {financialMetrics.revenue.current.toLocaleString()}</div>
            <div className="flex items-center text-sm mt-1">
              <ArrowUp className="w-4 h-4 text-green-600 mr-1" />
              <span className="text-green-600 font-medium">{financialMetrics.revenue.trend}%</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Despesas</CardTitle>
            <CardDescription>
              Comparado ao período anterior
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {financialMetrics.expenses.current.toLocaleString()}</div>
            <div className="flex items-center text-sm mt-1">
              <ArrowUp className="w-4 h-4 text-amber-600 mr-1" />
              <span className="text-amber-600 font-medium">{financialMetrics.expenses.trend}%</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Lucro</CardTitle>
            <CardDescription>
              Comparado ao período anterior
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {financialMetrics.profit.current.toLocaleString()}</div>
            <div className="flex items-center text-sm mt-1">
              <ArrowUp className="w-4 h-4 text-green-600 mr-1" />
              <span className="text-green-600 font-medium">{financialMetrics.profit.trend}%</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium">Fluxo de Caixa</CardTitle>
            <CardDescription>
              Comparado ao período anterior
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {financialMetrics.cash_flow.current.toLocaleString()}</div>
            <div className="flex items-center text-sm mt-1">
              <ArrowUp className="w-4 h-4 text-green-600 mr-1" />
              <span className="text-green-600 font-medium">{financialMetrics.cash_flow.trend}%</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };
  
  // Renderiza cartões de insights baseados em IA
  const renderInsights = () => {
    if (!analysisResult || !analysisResult.insights) return null;
    
    const getImpactColor = (impact) => {
      switch (impact) {
        case 'high': return 'bg-red-100 text-red-800';
        case 'medium': return 'bg-amber-100 text-amber-800';
        case 'positive': return 'bg-green-100 text-green-800';
        case 'informational': return 'bg-blue-100 text-blue-800';
        default: return 'bg-gray-100 text-gray-800';
      }
    };
    
    const getImpactIcon = (impact) => {
      switch (impact) {
        case 'high': return <AlertCircle className="w-4 h-4" />;
        case 'medium': return <AlertCircle className="w-4 h-4" />;
        case 'positive': return <CheckCircle className="w-4 h-4" />;
        case 'informational': return <HelpCircle className="w-4 h-4" />;
        default: return <HelpCircle className="w-4 h-4" />;
      }
    };
    
    const filteredInsights = analysisResult.insights.filter(insight => {
      if (dataFocus === 'all') return true;
      return insight.category === dataFocus;
    });
    
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredInsights.map(insight => (
          <Card key={insight.id} className="relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-1 ${
              insight.impact === 'high' ? 'bg-red-500' : 
              insight.impact === 'medium' ? 'bg-amber-500' : 
              insight.impact === 'positive' ? 'bg-green-500' : 
              'bg-blue-500'
            }`}></div>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{insight.title}</CardTitle>
                  <CardDescription>{insight.category.charAt(0).toUpperCase() + insight.category.slice(1)}</CardDescription>
                </div>
                <Badge className={getImpactColor(insight.impact)}>
                  <div className="flex items-center gap-1">
                    {getImpactIcon(insight.impact)}
                    <span className="capitalize">
                      {insight.impact === 'high' ? 'Alto impacto' : 
                      insight.impact === 'medium' ? 'Médio impacto' : 
                      insight.impact === 'positive' ? 'Positivo' : 
                      'Informativo'}
                    </span>
                  </div>
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                {insight.description}
              </p>
              
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Ações Recomendadas:</h4>
                <ul className="space-y-1">
                  {insight.action_items.map((action, idx) => (
                    <li key={idx} className="text-sm flex items-start gap-2">
                      <CornerUpRight className="w-4 h-4 mt-0.5 text-green-600 flex-shrink-0" />
                      <span>{action}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              {insight.metrics && (
                <div className="mt-4 pt-4 border-t">
                  <div className="grid grid-cols-2 gap-2">
                    {Object.entries(insight.metrics).map(([key, value], idx) => (
                      <div key={idx} className="text-sm">
                        <span className="text-gray-500 dark:text-gray-400">{key.replace(/_/g, ' ')}:</span>{' '}
                        <span className="font-medium">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => setFocusedInsight(insight)}
              >
                <Zap className="w-4 h-4 mr-2" />
                Explorar Detalhes
              </Button>
            </CardFooter>
          </Card>
        ))}
        
        {filteredInsights.length === 0 && (
          <div className="col-span-2 flex flex-col items-center justify-center py-12">
            <Lightbulb className="w-12 h-12 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">Nenhum insight encontrado</h3>
            <p className="text-gray-500 dark:text-gray-400 text-center mt-2 max-w-md">
              {dataFocus !== 'all' ? 
                `Não encontramos insights específicos para a categoria "${dataFocus}". Tente mudar os filtros ou gerar uma nova análise.` : 
                "Não encontramos insights com os filtros atuais. Tente gerar uma nova análise ou mudar os critérios."}
            </p>
          </div>
        )}
      </div>
    );
  };
  
  // Renderiza análise personalizada
  const renderCustomAnalysis = () => {
    if (!analysisResult || !analysisResult.custom_analysis) return null;
    
    const analysis = analysisResult.custom_analysis;
    
    return (
      <Card>
        <CardHeader>
          <CardTitle>Análise Personalizada</CardTitle>
          <CardDescription>
            Resposta para: "{customQuestion}"
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
            <p className="text-gray-700 dark:text-gray-200">
              {analysis.analysis}
            </p>
          </div>
          
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-medium mb-2">Principais Insights</h3>
              <ul className="space-y-2">
                {analysis.key_insights.map((insight, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <Lightbulb className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                    <span>{insight}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <Separator />
            
            <div>
              <h3 className="text-lg font-medium mb-2">Recomendações</h3>
              <ul className="space-y-2">
                {analysis.recommendations.map((recommendation, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <CornerUpRight className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span>{recommendation}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <Separator />
            
            <div>
              <h3 className="text-lg font-medium mb-2">Métricas para Monitorar</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {analysis.metrics_to_monitor.map((metric, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-blue-600" />
                    <span>{metric}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <div className="flex justify-between w-full">
            <Button 
              variant="outline" 
              onClick={() => setAnalysisResult({...analysisResult, custom_analysis: null})}
            >
              Nova Consulta
            </Button>
            <Button 
              variant="outline" 
              onClick={exportAnalysis}
            >
              <Download className="w-4 h-4 mr-2" />
              Exportar Análise
            </Button>
          </div>
        </CardFooter>
      </Card>
    );
  };
  
  // Renderiza gráficos de tendências
  const renderTrendCharts = () => {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Tendência de Receita</CardTitle>
            <CardDescription>Últimos 12 meses</CardDescription>
          </CardHeader>
          <CardContent>
            <LineChart data={[78, 84, 87, 81, 88, 92, 81, 86, 87, 91, 97, 100]} height={150} color="green" />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Tendência de Despesas</CardTitle>
            <CardDescription>Últimos 12 meses</CardDescription>
          </CardHeader>
          <CardContent>
            <LineChart data={[90, 98,103, 96, 101, 106, 98, 97, 103, 108, 121, 110]} height={150} color="red" />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Tendência de Lucro</CardTitle>
            <CardDescription>Últimos 12 meses</CardDescription>
          </CardHeader>
          <CardContent>
            <LineChart data={[67, 70, 70, 67, 80, 80, 60, 80, 73, 73, 67, 100]} height={150} color="blue" />
          </CardContent>
        </Card>
      </div>
    );
  };
  
  // Modal de detalhes do insight
  const renderInsightDetailModal = () => {
    if (!focusedInsight) return null;
    
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
        <div className="bg-white dark:bg-gray-800 rounded-lg w-full max-w-3xl max-h-[90vh] overflow-auto">
          <div className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-xl font-bold">{focusedInsight.title}</h2>
                <Badge className={
                  focusedInsight.impact === 'high' ? 'bg-red-100 text-red-800' : 
                  focusedInsight.impact === 'medium' ? 'bg-amber-100 text-amber-800' : 
                  focusedInsight.impact === 'positive' ? 'bg-green-100 text-green-800' : 
                  'bg-blue-100 text-blue-800'
                }>
                  {focusedInsight.impact === 'high' ? 'Alto impacto' : 
                   focusedInsight.impact === 'medium' ? 'Médio impacto' : 
                   focusedInsight.impact === 'positive' ? 'Positivo' : 
                   'Informativo'}
                </Badge>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setFocusedInsight(null)}
              >
                ✕
              </Button>
            </div>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-2">Descrição Detalhada</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  {focusedInsight.description}
                </p>
                
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(focusedInsight.metrics).map(([key, value], idx) => (
                    <Card key={idx} className="p-4">
                      <div className="text-sm text-gray-500 dark:text-gray-400">{key.replace(/_/g, ' ')}</div>
                      <div className="font-bold text-lg">{value}</div>
                    </Card>
                  ))}
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-2">Análise de Impacto</h3>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Este insight tem implicações significativas para sua organização. Aqui está uma análise aprofundada:
                </p>
                
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="financial-impact">
                    <AccordionTrigger>Impacto Financeiro</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2">
                        {focusedInsight.category === 'revenue' && (
                          <p>O crescimento de receita identificado pode contribuir para um aumento projetado de aproximadamente {(focusedInsight.metrics.projected_impact || "3-5%").replace("+", "")} no próximo trimestre, assumindo que as condições atuais se mantenham.</p>
                        )}
                        {focusedInsight.category === 'expenses' && (
                          <p>A otimização de despesas sugerida pode levar a uma redução de custos de aproximadamente {focusedInsight.metrics.optimization_potential || "8-12%"}, melhorando diretamente a margem de lucro.</p>
                        )}
                        {focusedInsight.category === 'cash_flow' && (
                          <p>A melhoria na gestão de contas a receber pode liberar cerca de R$ {parseFloat(focusedInsight.metrics.cash_flow_impact?.replace("R$ ", "").replace(".", "").replace(",", ".")) || 35000} em capital de giro, reduzindo necessidade de financiamento de curto prazo.</p>
                        )}
                        {focusedInsight.category === 'forecast' && (
                          <p>Com um nível de confiança de {focusedInsight.metrics.forecast_confidence || "85%"}, projetamos um crescimento de {focusedInsight.metrics.growth_projection?.split(",")[0] || "7.2%"} no próximo trimestre, o que representa um impacto adicional de aproximadamente R$ 35.000 em receita.</p>
                        )}
                        {focusedInsight.category === 'patterns' && (
                          <p>Os padrões de sazonalidade identificados representam uma variação de {focusedInsight.metrics.seasonal_variation || "22%"} no volume de negócios, com impacto direto no planejamento financeiro e de recursos.</p>
                        )}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="operational-impact">
                    <AccordionTrigger>Impacto Operacional</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2">
                        <p>As mudanças sugeridas requerem ajustes operacionais em:</p>
                        <ul className="list-disc pl-5 space-y-1">
                          {focusedInsight.category === 'revenue' && (
                            <>
                              <li>Capacidade produtiva para atender ao aumento de demanda</li>
                              <li>Processos de vendas e atendimento ao cliente</li>
                              <li>Gestão da cadeia de suprimentos</li>
                            </>
                          )}
                          {focusedInsight.category === 'expenses' && (
                            <>
                              <li>Revisão de processos e contratos com fornecedores</li>
                              <li>Otimização de recursos internos</li>
                              <li>Renegociação de prazos e condições</li>
                            </>
                          )}
                          {focusedInsight.category === 'cash_flow' && (
                            <>
                              <li>Processos de cobrança e acompanhamento</li>
                              <li>Política de crédito e avaliação de clientes</li>
                              <li>Integração entre vendas e financeiro</li>
                            </>
                          )}
                          {focusedInsight.category === 'forecast' || focusedInsight.category === 'patterns' && (
                            <>
                              <li>Planejamento de capacidade e recursos</li>
                              <li>Gestão de estoque e logística</li>
                              <li>Estratégias de marketing e vendas sazonais</li>
                            </>
                          )}
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="strategic-impact">
                    <AccordionTrigger>Impacto Estratégico</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2">
                        <p>Do ponto de vista estratégico, este insight:</p>
                        {focusedInsight.category === 'revenue' && (
                          <>
                            <p>Confirma a eficácia da estratégia de crescimento atual e sugere oportunidades de expansão em áreas de alto desempenho.</p>
                            <p>Sinaliza potencial para investimentos em produtos/serviços que estão gerando maiores margens.</p>
                          </>
                        )}
                        {focusedInsight.category === 'expenses' && (
                          <>
                            <p>Aponta para a necessidade de revisão estrutural de custos operacionais fundamentais.</p>
                            <p>Sugere oportunidades para melhoria de eficiência através de processos mais otimizados ou tecnologia.</p>
                          </>
                        )}
                        {focusedInsight.category === 'cash_flow' && (
                          <>
                            <p>Indica a necessidade de fortalecimento da função financeira e maior integração com vendas.</p>
                            <p>Sugere revisão da política comercial e alinhamento com a estratégia financeira da empresa.</p>
                          </>
                        )}
                        {focusedInsight.category === 'forecast' && (
                          <>
                            <p>Valida o direcionamento estratégico atual e sugere momento oportuno para iniciativas de crescimento.</p>
                            <p>Permite planejamento antecipado de investimentos necessários para sustentar o crescimento.</p>
                          </>
                        )}
                        {focusedInsight.category === 'patterns' && (
                          <>
                            <p>Permite ajuste do planejamento estratégico considerando ciclos de mercado.</p>
                            <p>Oferece oportunidades para desenvolvimento de estratégias contra-cíclicas.</p>
                          </>
                        )}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-2">Plano de Ação Detalhado</h3>
                <div className="space-y-4">
                  {focusedInsight.action_items.map((action, idx) => (
                    <div key={idx} className="border rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-green-100 p-2 rounded-full">
                          <CornerUpRight className="w-5 h-5 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium">{action}</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                            {idx === 0 ? "Alta prioridade - Implementar em 30 dias" : 
                             idx === 1 ? "Média prioridade - Implementar em 60 dias" : 
                             "Prioridade de planejamento - Avaliar em 90 dias"}
                          </p>
                          <div className="mt-2">
                            <div className="flex items-center gap-2">
                              <Checkbox id={`action-${idx}`} />
                              <Label htmlFor={`action-${idx}`} className="text-sm">Marcar como concluído</Label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-end gap-3 mt-4">
                <Button variant="outline" onClick={() => setFocusedInsight(null)}>
                  Fechar
                </Button>
                <Button onClick={() => {
                  toast({
                    title: "Relatório detalhado gerado",
                    description: "O relatório detalhado deste insight foi gerado com sucesso."
                  });
                  setFocusedInsight(null);
                }}>
                  <FileText className="w-4 h-4 mr-2" />
                  Gerar Relatório Detalhado
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Análise Financeira com IA</h1>
          <p className="text-gray-500 mt-1">
            Insights inteligentes para tomada de decisão financeira
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Select value={fileType} onValueChange={setFileType}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Formato" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pdf">PDF</SelectItem>
              <SelectItem value="excel">Excel</SelectItem>
              <SelectItem value="csv">CSV</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="gap-2" onClick={exportAnalysis}>
            <Download className="w-4 h-4" />
            Exportar
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-wrap justify-between items-center gap-4">
            <div>
              <CardTitle>Configurações de Análise</CardTitle>
              <CardDescription>
                Personalize os parâmetros para análise inteligente
              </CardDescription>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button 
                variant={isLoading ? "secondary" : "default"} 
                onClick={generateAnalysis}
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Analisando Dados...
                  </>
                ) : (
                  <>
                    <Brain className="w-4 h-4 mr-2" />
                    Gerar Análise
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Tipo de Análise</Label>
              <Select value={analysisType} onValueChange={setAnalysisType}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo de análise" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="automated">Análise Automatizada</SelectItem>
                  <SelectItem value="custom">Pergunta Personalizada</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Período de Análise</Label>
              <Select value={timePeriod} onValueChange={setTimePeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="current-month">Mês Atual</SelectItem>
                  <SelectItem value="current-quarter">Trimestre Atual</SelectItem>
                  <SelectItem value="current-year">Ano Atual</SelectItem>
                  <SelectItem value="year-to-date">Acumulado do Ano</SelectItem>
                  <SelectItem value="last-12-months">Últimos 12 Meses</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Foco dos Dados</Label>
              <Select value={dataFocus} onValueChange={setDataFocus}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o foco" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Visão Completa</SelectItem>
                  <SelectItem value="revenue">Receitas</SelectItem>
                  <SelectItem value="expenses">Despesas</SelectItem>
                  <SelectItem value="cash_flow">Fluxo de Caixa</SelectItem>
                  <SelectItem value="forecast">Projeções</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {analysisType === "custom" && (
            <div className="pt-2">
              <Label>Sua Pergunta para a IA Financeira</Label>
              <Textarea 
                placeholder="Ex: Quais são os principais fatores impactando a margem de lucro atual? Como posso melhorar o fluxo de caixa?" 
                className="mt-1"
                value={customQuestion}
                onChange={(e) => setCustomQuestion(e.target.value)}
              />
              <p className="text-xs text-gray-500 mt-1">
                Faça perguntas específicas sobre seus dados financeiros para obter análises personalizadas.
              </p>
            </div>
          )}
          
          {isLoading && (
            <div className="pt-2">
              <Label className="flex justify-between">
                <span>Progresso da Análise</span>
                <span>{insightProgress}%</span>
              </Label>
              <Progress value={insightProgress} className="mt-1" />
              <p className="text-xs text-gray-500 mt-1">
                A IA está analisando seus dados financeiros...
              </p>
            </div>
          )}
        </CardContent>
        {!isLoading && lastUpdated && (
          <CardFooter>
            <div className="text-xs text-gray-500">
              Última atualização: {lastUpdated}
            </div>
          </CardFooter>
        )}
      </Card>
      
      {analysisResult && analysisResult.custom_analysis ? (
        renderCustomAnalysis()
      ) : (
        <>
          <Tabs defaultValue="insights">
            <TabsList>
              <TabsTrigger value="insights" className="flex items-center gap-2">
                <Lightbulb className="w-4 h-4" />
                <span>Insights</span>
              </TabsTrigger>
              <TabsTrigger value="trends" className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                <span>Tendências</span>
              </TabsTrigger>
              <TabsTrigger value="projection" className="flex items-center gap-2">
                <PieChart className="w-4 h-4" />
                <span>Projeções</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="insights">
              {analysisResult && analysisResult.summary && (
                <Card className="mb-6">
                  <CardHeader className="pb-2">
                    <CardTitle>Resumo da Análise</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{analysisResult.summary}</p>
                  </CardContent>
                </Card>
              )}
              
              {renderMetricCards()}
              {renderInsights()}
            </TabsContent>
            
            <TabsContent value="trends">
              {renderTrendCharts()}
              
              <Card>
                <CardHeader>
                  <CardTitle>Análise de Tendências</CardTitle>
                  <CardDescription>
                    Comparativo de desempenho financeiro ao longo do tempo
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-3">Análise de Crescimento</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                      A análise dos últimos 12 meses mostra um padrão consistente de crescimento em receitas, com uma média de 4.2% de crescimento mês a mês. As despesas também apresentam crescimento, porém a uma taxa menor de 3.5%, resultando em expansão da margem de lucro.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-center">
                            <h4 className="text-sm font-medium mb-1">Crescimento de Receita (YoY)</h4>
                            <div className="text-2xl font-bold text-green-600">+18.3%</div>
                            <p className="text-xs text-gray-500 mt-1">
                              Acima da média do setor (12.5%)
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-center">
                            <h4 className="text-sm font-medium mb-1">Crescimento de Despesas (YoY)</h4>
                            <div className="text-2xl font-bold text-amber-600">+13.5%</div>
                            <p className="text-xs text-gray-500 mt-1">
                              Próximo à média do setor (12.2%)
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-center">
                            <h4 className="text-sm font-medium mb-1">Crescimento de Lucro (YoY)</h4>
                            <div className="text-2xl font-bold text-blue-600">+33.0%</div>
                            <p className="text-xs text-gray-500 mt-1">
                              Significativamente acima do setor (18.7%)
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-lg font-medium mb-3">Padrões Sazonais</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                      A análise de dados históricos revela padrões sazonais significativos no seu modelo de negócio. Identificamos picos de receita nos meses 6, 11 e 12, com queda no mês 7. Este padrão é 22% mais pronunciado que no ano anterior.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium mb-2">Meses de Alto Desempenho</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span>Junho (Mês 6)</span>
                            <Badge className="bg-green-100 text-green-800">+15% vs. média</Badge>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>Novembro (Mês 11)</span>
                            <Badge className="bg-green-100 text-green-800">+22% vs. média</Badge>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>Dezembro (Mês 12)</span>
                            <Badge className="bg-green-100 text-green-800">+25% vs. média</Badge>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-2">Meses de Baixo Desempenho</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span>Julho (Mês 7)</span>
                            <Badge className="bg-red-100 text-red-800">-12% vs. média</Badge>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>Janeiro (Mês 1)</span>
                            <Badge className="bg-amber-100 text-amber-800">-5% vs. média</Badge>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>Agosto (Mês 8)</span>
                            <Badge className="bg-amber-100 text-amber-800">-3% vs. média</Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="projection">
              <Card>
                <CardHeader>
                  <CardTitle>Projeções Financeiras</CardTitle>
                  <CardDescription>
                    Previsões baseadas em análise de tendências históricas
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">Receita Projetada</CardTitle>
                        <CardDescription>Próximo trimestre</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-green-600">
                          R$ {financialMetrics.revenue.forecast_next.toLocaleString()}
                        </div>
                        <div className="flex items-center text-sm mt-1">
                          <ArrowUp className="w-4 h-4 text-green-600 mr-1" />
                          <span className="text-green-600 font-medium">
                            +7.2%
                          </span>
                          <span className="text-gray-500 ml-1">vs. trimestre atual</span>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">Despesas Projetadas</CardTitle>
                        <CardDescription>Próximo trimestre</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-amber-600">
                          R$ {financialMetrics.expenses.forecast_next.toLocaleString()}
                        </div>
                        <div className="flex items-center text-sm mt-1">
                          <ArrowUp className="w-4 h-4 text-amber-600 mr-1" />
                          <span className="text-amber-600 font-medium">
                            +7.4%
                          </span>
                          <span className="text-gray-500 ml-1">vs. trimestre atual</span>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">Lucro Projetado</CardTitle>
                        <CardDescription>Próximo trimestre</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-blue-600">
                          R$ {financialMetrics.profit.forecast_next.toLocaleString()}
                        </div>
                        <div className="flex items-center text-sm mt-1">
                          <ArrowUp className="w-4 h-4 text-blue-600 mr-1" />
                          <span className="text-blue-600 font-medium">
                            +6.8%
                          </span>
                          <span className="text-gray-500 ml-1">vs. trimestre atual</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium mb-3">Projeção Detalhada para Próximos 4 Trimestres</h3>
                    <div className="relative overflow-x-auto rounded-md border">
                      <table className="w-full text-sm text-left">
                        <thead className="bg-gray-50 dark:bg-gray-800">
                          <tr>
                            <th className="px-4 py-3">Trimestre</th>
                            <th className="px-4 py-3 text-right">Receita (R$)</th>
                            <th className="px-4 py-3 text-right">Despesas (R$)</th>
                            <th className="px-4 py-3 text-right">Lucro (R$)</th>
                            <th className="px-4 py-3 text-right">Margem (%)</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-t">
                            <td className="px-4 py-3 font-medium">Q4 2023</td>
                            <td className="px-4 py-3 text-right">520.000</td>
                            <td className="px-4 py-3 text-right">378.000</td>
                            <td className="px-4 py-3 text-right">142.000</td>
                            <td className="px-4 py-3 text-right">27.3%</td>
                          </tr>
                          <tr className="border-t">
                            <td className="px-4 py-3 font-medium">Q1 2024</td>
                            <td className="px-4 py-3 text-right">550.000</td>
                            <td className="px-4 py-3 text-right">395.000</td>
                            <td className="px-4 py-3 text-right">155.000</td>
                            <td className="px-4 py-3 text-right">28.2%</td>
                          </tr>
                          <tr className="border-t">
                            <td className="px-4 py-3 font-medium">Q2 2024</td>
                            <td className="px-4 py-3 text-right">590.000</td>
                            <td className="px-4 py-3 text-right">420.000</td>
                            <td className="px-4 py-3 text-right">170.000</td>
                            <td className="px-4 py-3 text-right">28.8%</td>
                          </tr>
                          <tr className="border-t">
                            <td className="px-4 py-3 font-medium">Q3 2024</td>
                            <td className="px-4 py-3 text-right">610.000</td>
                            <td className="px-4 py-3 text-right">435.000</td>
                            <td className="px-4 py-3 text-right">175.000</td>
                            <td className="px-4 py-3 text-right">28.7%</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Projeções baseadas em tendências históricas, sazonalidade e análise de mercado. Confiança da projeção: 85%.
                    </p>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-lg font-medium mb-3">Fatores de Impacto na Projeção</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-medium mb-2">Fatores Positivos</h4>
                        <div className="space-y-2">
                          <div className="flex items-start gap-2">
                            <ArrowUp className="w-4 h-4 text-green-600 mt-0.5" />
                            <div>
                              <span className="font-medium">Crescimento consistente do segmento principal (4.2% mensal)</span>
                              <p className="text-xs text-gray-500 mt-0.5">
                                Contribui significativamente para a projeção positiva de receita.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start gap-2">
                            <ArrowUp className="w-4 h-4 text-green-600 mt-0.5" />
                            <div>
                              <span className="font-medium">Expansão da margem operacional</span>
                              <p className="text-xs text-gray-500 mt-0.5">
                                Melhorias operacionais estão diminuindo a proporção de despesas variáveis.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start gap-2">
                            <ArrowUp className="w-4 h-4 text-green-600 mt-0.5" />
                            <div>
                              <span className="font-medium">Efeito sazonal positivo em Q4 e Q1</span>
                              <p className="text-xs text-gray-500 mt-0.5">
                                Padrão histórico indica picos de receita nesses trimestres.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-2">Fatores de Risco</h4>
                        <div className="space-y-2">
                          <div className="flex items-start gap-2">
                            <ArrowDown className="w-4 h-4 text-red-600 mt-0.5" />
                            <div>
                              <span className="font-medium">Aumento potencial de custos logísticos</span>
                              <p className="text-xs text-gray-500 mt-0.5">
                                Tendência de alta nos custos de transporte pode afetar margens.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start gap-2">
                            <ArrowDown className="w-4 h-4 text-red-600 mt-0.5" />
                            <div>
                              <span className="font-medium">Contas a receber acima de 60 dias</span>
                              <p className="text-xs text-gray-500 mt-0.5">
                                Pode impactar fluxo de caixa necessário para crescimento.
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start gap-2">
                            <ArrowDown className="w-4 h-4 text-red-600 mt-0.5" />
                            <div>
                              <span className="font-medium">Pressão inflacionária em insumos</span>
                              <p className="text-xs text-gray-500 mt-0.5">
                                Pode exigir ajustes de preço ou absorção de custos.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" onClick={exportAnalysis}>
                    <FileText className="w-4 h-4 mr-2" />
                    Exportar Relatório Completo de Projeções
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
      
      {/* Detalhe do insight quando um é selecionado */}
      {focusedInsight && renderInsightDetailModal()}
    </div>
  );
}