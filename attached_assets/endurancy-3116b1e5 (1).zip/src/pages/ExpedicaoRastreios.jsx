import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  ScanLine,
  Search,
  Filter,
  FileText,
  CheckCircle,
  Clock,
  AlertCircle,
  Package,
  TruckIcon,
  Home,
  CheckCheck,
  Package as PackageIcon,
  ChevronDown,
  ChevronRight,
  X,
  Plus,
  Upload,
  Download,
  RefreshCw,
  Eye,
  ClipboardList,
  Mail,
  MessageSquare,
  ExternalLink,
  MoreHorizontal
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';

// Dados simulados de rastreios
const mockTrackings = [
  {
    id: "1",
    tracking_code: "BR123456789BR",
    order_number: "PED-12345",
    customer_name: "João Silva",
    shipping_date: "2023-11-14",
    shipping_method: "SEDEX",
    status: "em_transito",
    last_update: "2023-11-15T14:30:00",
    estimated_delivery: "2023-11-17",
    delivery_address: "Rua das Flores, 123 - São Paulo, SP",
    last_event: {
      date: "2023-11-15T14:30:00",
      location: "São Paulo/SP",
      description: "Objeto em trânsito - de São Paulo/SP para Campinas/SP"
    },
    events: [
      {
        date: "2023-11-15T14:30:00",
        location: "São Paulo/SP",
        description: "Objeto em trânsito - de São Paulo/SP para Campinas/SP"
      },
      {
        date: "2023-11-14T18:45:00",
        location: "São Paulo/SP",
        description: "Objeto postado"
      }
    ],
    carrier: "Correios",
    carrier_url: "https://www.correios.com.br",
    is_notified: true,
    has_issue: false
  },
  {
    id: "2",
    tracking_code: "BR987654321BR",
    order_number: "PED-12346",
    customer_name: "Maria Oliveira",
    shipping_date: "2023-11-14",
    shipping_method: "PAC",
    status: "postado",
    last_update: "2023-11-14T16:20:00",
    estimated_delivery: "2023-11-21",
    delivery_address: "Av. Paulista, 1000 - São Paulo, SP",
    last_event: {
      date: "2023-11-14T16:20:00",
      location: "São Paulo/SP",
      description: "Objeto postado"
    },
    events: [
      {
        date: "2023-11-14T16:20:00",
        location: "São Paulo/SP",
        description: "Objeto postado"
      }
    ],
    carrier: "Correios",
    carrier_url: "https://www.correios.com.br",
    is_notified: false,
    has_issue: false
  },
  {
    id: "3",
    tracking_code: "JD123456789",
    order_number: "PED-12347",
    customer_name: "Carlos Santos",
    shipping_date: "2023-11-13",
    shipping_method: "Jadlog",
    status: "entregue",
    last_update: "2023-11-15T10:15:00",
    estimated_delivery: "2023-11-16",
    delivery_address: "Rua dos Pinheiros, 500 - Porto Alegre, RS",
    last_event: {
      date: "2023-11-15T10:15:00",
      location: "Porto Alegre/RS",
      description: "Objeto entregue ao destinatário"
    },
    events: [
      {
        date: "2023-11-15T10:15:00",
        location: "Porto Alegre/RS",
        description: "Objeto entregue ao destinatário"
      },
      {
        date: "2023-11-14T08:30:00",
        location: "Porto Alegre/RS",
        description: "Objeto saiu para entrega ao destinatário"
      },
      {
        date: "2023-11-13T20:45:00",
        location: "São Paulo/SP",
        description: "Objeto postado"
      }
    ],
    carrier: "Jadlog",
    carrier_url: "https://www.jadlog.com.br",
    is_notified: true,
    has_issue: false
  },
  {
    id: "4",
    tracking_code: "AZ987654321",
    order_number: "PED-12348",
    customer_name: "Ana Costa",
    shipping_date: "2023-11-12",
    shipping_method: "Transportadora",
    status: "problema",
    last_update: "2023-11-14T09:45:00",
    estimated_delivery: "2023-11-15",
    delivery_address: "Rua Augusta, 700 - Rio de Janeiro, RJ",
    last_event: {
      date: "2023-11-14T09:45:00",
      location: "Rio de Janeiro/RJ",
      description: "Endereço insuficiente para entrega"
    },
    events: [
      {
        date: "2023-11-14T09:45:00",
        location: "Rio de Janeiro/RJ",
        description: "Endereço insuficiente para entrega"
      },
      {
        date: "2023-11-13T14:30:00",
        location: "Rio de Janeiro/RJ",
        description: "Objeto saiu para entrega ao destinatário"
      },
      {
        date: "2023-11-12T16:20:00",
        location: "São Paulo/SP",
        description: "Objeto postado"
      }
    ],
    carrier: "Azul Cargo",
    carrier_url: "https://www.azulcargo.com.br",
    is_notified: true,
    has_issue: true
  },
  {
    id: "5",
    tracking_code: "XY123789456",
    order_number: "PED-12349",
    customer_name: "Fernando Mendes",
    shipping_date: "2023-11-15",
    shipping_method: "SEDEX",
    status: "postado",
    last_update: "2023-11-15T15:10:00",
    estimated_delivery: "2023-11-18",
    delivery_address: "Av. Brasil, 1500 - Belo Horizonte, MG",
    last_event: {
      date: "2023-11-15T15:10:00",
      location: "São Paulo/SP",
      description: "Objeto postado"
    },
    events: [
      {
        date: "2023-11-15T15:10:00",
        location: "São Paulo/SP",
        description: "Objeto postado"
      }
    ],
    carrier: "Correios",
    carrier_url: "https://www.correios.com.br",
    is_notified: false,
    has_issue: false
  }
];

export default function ExpedicaoRastreios() {
  const [trackings, setTrackings] = useState([]);
  const [filteredTrackings, setFilteredTrackings] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [carrierFilter, setCarrierFilter] = useState("all");
  const [selectedTracking, setSelectedTracking] = useState(null);
  const [showTrackingDetails, setShowTrackingDetails] = useState(false);
  const [showUpdateDialog, setShowUpdateDialog] = useState(false);
  const [showBulkUpdateDialog, setShowBulkUpdateDialog] = useState(false);
  const [showNotifyCustomerDialog, setShowNotifyCustomerDialog] = useState(false);
  const [selectedTrackings, setSelectedTrackings] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [updateStatus, setUpdateStatus] = useState("");
  const [updateLocation, setUpdateLocation] = useState("");
  const [updateDescription, setUpdateDescription] = useState("");
  const [notificationMessage, setNotificationMessage] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  // Status para estatísticas
  const [stats, setStats] = useState({
    total: 0,
    postado: 0,
    em_transito: 0,
    entregue: 0,
    problema: 0
  });

  useEffect(() => {
    // Simulando carregamento da API
    const loadTrackings = async () => {
      setIsLoading(true);
      try {
        // Em uma implementação real, isso seria uma chamada à API
        setTimeout(() => {
          setTrackings(mockTrackings);
          setFilteredTrackings(mockTrackings);
          updateStats(mockTrackings);
          setIsLoading(false);
        }, 500);
      } catch (error) {
        console.error("Erro ao carregar rastreios:", error);
        setIsLoading(false);
      }
    };

    loadTrackings();
  }, []);

  useEffect(() => {
    if (trackings.length) {
      let result = [...trackings];
      
      // Filtrar por aba ativa
      if (activeTab === "issues") {
        result = result.filter(tracking => tracking.has_issue);
      } else if (activeTab === "delivered") {
        result = result.filter(tracking => tracking.status === "entregue");
      } else if (activeTab === "in_transit") {
        result = result.filter(tracking => tracking.status === "em_transito");
      } else if (activeTab === "posted") {
        result = result.filter(tracking => tracking.status === "postado");
      }
      
      // Aplicar filtro de busca
      if (searchTerm) {
        result = result.filter(tracking => 
          tracking.tracking_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
          tracking.order_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
          tracking.customer_name.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }
      
      // Aplicar filtro de status
      if (statusFilter !== "all") {
        result = result.filter(tracking => tracking.status === statusFilter);
      }
      
      // Aplicar filtro de transportadora
      if (carrierFilter !== "all") {
        result = result.filter(tracking => tracking.carrier === carrierFilter);
      }
      
      setFilteredTrackings(result);
    }
  }, [trackings, searchTerm, statusFilter, carrierFilter, activeTab]);

  const updateStats = (data) => {
    const newStats = {
      total: data.length,
      postado: data.filter(t => t.status === "postado").length,
      em_transito: data.filter(t => t.status === "em_transito").length,
      entregue: data.filter(t => t.status === "entregue").length,
      problema: data.filter(t => t.has_issue).length
    };
    setStats(newStats);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  const formatDateTime = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "postado":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Postado</Badge>;
      case "em_transito":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Em Trânsito</Badge>;
      case "entregue":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Entregue</Badge>;
      case "problema":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Problema</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getStatusIcon = (status, hasIssue) => {
    if (hasIssue) return <AlertCircle className="w-5 h-5 text-red-500" />;
    
    switch (status) {
      case "postado":
        return <Package className="w-5 h-5 text-blue-500" />;
      case "em_transito":
        return <TruckIcon className="w-5 h-5 text-yellow-500" />;
      case "entregue":
        return <Home className="w-5 h-5 text-green-500" />;
      default:
        return <Package className="w-5 h-5 text-gray-500" />;
    }
  };

  const handleOpenTrackingDetails = (tracking) => {
    setSelectedTracking(tracking);
    setShowTrackingDetails(true);
  };

  const handleOpenUpdateDialog = (tracking) => {
    setSelectedTracking(tracking);
    setUpdateStatus(tracking.status);
    setUpdateLocation("");
    setUpdateDescription("");
    setShowUpdateDialog(true);
  };

  const handleUpdateTracking = () => {
    // Em uma implementação real, isso seria uma chamada à API
    const newEvent = {
      date: new Date().toISOString(),
      location: updateLocation,
      description: updateDescription
    };

    const updatedTrackings = trackings.map(tracking => {
      if (tracking.id === selectedTracking.id) {
        return {
          ...tracking,
          status: updateStatus,
          last_update: newEvent.date,
          last_event: newEvent,
          events: [newEvent, ...tracking.events],
          has_issue: updateStatus === "problema"
        };
      }
      return tracking;
    });

    setTrackings(updatedTrackings);
    updateStats(updatedTrackings);
    setShowUpdateDialog(false);
    toast("Rastreio atualizado com sucesso!");
  };

  const handleBulkUpdate = () => {
    // Em uma implementação real, isso seria uma chamada à API
    const selectedIds = Object.keys(selectedTrackings).filter(id => selectedTrackings[id]);
    
    if (selectedIds.length === 0) {
      alert("Selecione pelo menos um rastreio para atualizar em massa.");
      return;
    }

    const newEvent = {
      date: new Date().toISOString(),
      location: updateLocation,
      description: updateDescription
    };

    const updatedTrackings = trackings.map(tracking => {
      if (selectedIds.includes(tracking.id)) {
        return {
          ...tracking,
          status: updateStatus,
          last_update: newEvent.date,
          last_event: newEvent,
          events: [newEvent, ...tracking.events],
          has_issue: updateStatus === "problema"
        };
      }
      return tracking;
    });

    setTrackings(updatedTrackings);
    updateStats(updatedTrackings);
    setSelectedTrackings({});
    setShowBulkUpdateDialog(false);
    // Em uma implementação real seria usado um componente de toast
    alert(`${selectedIds.length} rastreios atualizados com sucesso!`);
  };

  const handleNotifyCustomer = () => {
    // Em uma implementação real, isso seria uma chamada à API para enviar email
    const updatedTrackings = trackings.map(tracking => {
      if (tracking.id === selectedTracking.id) {
        return {
          ...tracking,
          is_notified: true
        };
      }
      return tracking;
    });

    setTrackings(updatedTrackings);
    setShowNotifyCustomerDialog(false);
    // Em uma implementação real seria usado um componente de toast
    alert("Cliente notificado com sucesso!");
  };

  const handleSelectAllChange = (e) => {
    const isChecked = e.target.checked;
    const newSelected = {};
    
    filteredTrackings.forEach(tracking => {
      newSelected[tracking.id] = isChecked;
    });
    
    setSelectedTrackings(newSelected);
  };

  const handleTrackingSelection = (trackingId) => {
    setSelectedTrackings(prev => ({
      ...prev,
      [trackingId]: !prev[trackingId]
    }));
  };

  const areAllSelected = () => {
    return filteredTrackings.length > 0 && 
      filteredTrackings.every(tracking => selectedTrackings[tracking.id]);
  };

  const getSelectedCount = () => {
    return Object.values(selectedTrackings).filter(Boolean).length;
  };

  // Função auxiliar para simular toasts já que a biblioteca não está importada
  const toast = (message) => {
    alert(message);
  };

  const renderTrackingsList = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mb-4"></div>
          <p className="text-gray-600">Carregando rastreios...</p>
        </div>
      );
    }

    if (filteredTrackings.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center py-12">
          <ScanLine className="h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900">Nenhum rastreio encontrado</h3>
          <p className="text-gray-500 mt-1">
            {searchTerm || statusFilter !== "all" || carrierFilter !== "all"
              ? "Tente ajustar os filtros de busca"
              : activeTab !== "all" 
                ? "Não há rastreios nesta categoria"
                : "Não há rastreios cadastrados ainda"}
          </p>
        </div>
      );
    }

    return (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[40px]">
              <Checkbox 
                checked={areAllSelected()}
                onCheckedChange={handleSelectAllChange}
              />
            </TableHead>
            <TableHead>Código de Rastreio</TableHead>
            <TableHead>Pedido</TableHead>
            <TableHead>Cliente</TableHead>
            <TableHead>Data de Envio</TableHead>
            <TableHead>Transportadora</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Última Atualização</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredTrackings.map(tracking => (
            <TableRow key={tracking.id}>
              <TableCell>
                <Checkbox 
                  checked={!!selectedTrackings[tracking.id]} 
                  onCheckedChange={() => handleTrackingSelection(tracking.id)}
                />
              </TableCell>
              <TableCell className="font-medium">{tracking.tracking_code}</TableCell>
              <TableCell>
                <Link to={`${createPageUrl("DetalhePedido")}?id=${tracking.order_number}`} className="text-blue-600 hover:underline">
                  {tracking.order_number}
                </Link>
              </TableCell>
              <TableCell>{tracking.customer_name}</TableCell>
              <TableCell>{formatDate(tracking.shipping_date)}</TableCell>
              <TableCell>{tracking.carrier}</TableCell>
              <TableCell>
                <div className="flex items-center gap-2">
                  {getStatusIcon(tracking.status, tracking.has_issue)}
                  {getStatusBadge(tracking.status)}
                </div>
              </TableCell>
              <TableCell>{formatDateTime(tracking.last_update)}</TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleOpenTrackingDetails(tracking)}>
                      <Eye className="mr-2 h-4 w-4" />
                      Detalhes
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleOpenUpdateDialog(tracking)}>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Atualizar Status
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => {
                      setSelectedTracking(tracking);
                      setNotificationMessage("");
                      setShowNotifyCustomerDialog(true);
                    }}>
                      <Mail className="mr-2 h-4 w-4" />
                      Notificar Cliente
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <ExternalLink className="mr-2 h-4 w-4" />
                      <a 
                        href={tracking.carrier_url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="w-full"
                      >
                        Ver no site da transportadora
                      </a>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Atualização de Rastreios</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            Gerencie e atualize os rastreios de envios e notifique os clientes
          </p>
        </div>
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            onClick={() => {
              setUpdateStatus("");
              setUpdateLocation("");
              setUpdateDescription("");
              setShowBulkUpdateDialog(true);
            }}
            disabled={getSelectedCount() === 0}
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Atualizar Selecionados ({getSelectedCount()})
          </Button>
          <Button>
            <ScanLine className="mr-2 h-4 w-4" />
            Novo Rastreio
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-600">Total de Rastreios</CardTitle>
            <div className="text-2xl font-bold text-blue-700">{stats.total}</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-blue-600 flex items-center mt-2">
              <Package className="w-3 h-3 mr-1" />
              <span>Todos os envios registrados</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-yellow-50 border-yellow-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-yellow-600">Em Trânsito</CardTitle>
            <div className="text-2xl font-bold text-yellow-700">{stats.em_transito}</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-yellow-600 flex items-center mt-2">
              <TruckIcon className="w-3 h-3 mr-1" />
              <span>{Math.round((stats.em_transito / stats.total) * 100) || 0}% dos envios</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-green-50 border-green-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-600">Entregues</CardTitle>
            <div className="text-2xl font-bold text-green-700">{stats.entregue}</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-green-600 flex items-center mt-2">
              <CheckCheck className="w-3 h-3 mr-1" />
              <span>{Math.round((stats.entregue / stats.total) * 100) || 0}% dos envios</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-50 border-red-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-red-600">Com Problemas</CardTitle>
            <div className="text-2xl font-bold text-red-700">{stats.problema}</div>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-red-600 flex items-center mt-2">
              <AlertCircle className="w-3 h-3 mr-1" />
              <span>{Math.round((stats.problema / stats.total) * 100) || 0}% dos envios</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar por código, pedido ou cliente"
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <Select
              value={statusFilter}
              onValueChange={setStatusFilter}
            >
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="postado">Postado</SelectItem>
                <SelectItem value="em_transito">Em Trânsito</SelectItem>
                <SelectItem value="entregue">Entregue</SelectItem>
                <SelectItem value="problema">Com Problema</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={carrierFilter}
              onValueChange={setCarrierFilter}
            >
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por transportadora" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as transportadoras</SelectItem>
                <SelectItem value="Correios">Correios</SelectItem>
                <SelectItem value="Jadlog">Jadlog</SelectItem>
                <SelectItem value="Azul Cargo">Azul Cargo</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">
                <Package className="w-4 h-4 mr-2" />
                Todos
              </TabsTrigger>
              <TabsTrigger value="in_transit">
                <TruckIcon className="w-4 h-4 mr-2" />
                Em Trânsito
              </TabsTrigger>
              <TabsTrigger value="posted">
                <Clock className="w-4 h-4 mr-2" />
                Postados
              </TabsTrigger>
              <TabsTrigger value="delivered">
                <CheckCheck className="w-4 h-4 mr-2" />
                Entregues
              </TabsTrigger>
              <TabsTrigger value="issues">
                <AlertCircle className="w-4 h-4 mr-2" />
                Problemas
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          <div className="border rounded-md">
            {renderTrackingsList()}
          </div>
        </CardContent>
      </Card>

      {/* Dialog para detalhes do rastreio */}
      <Dialog open={showTrackingDetails} onOpenChange={setShowTrackingDetails}>
        <DialogContent className="sm:max-w-[700px]">
          {selectedTracking && (
            <>
              <DialogHeader>
                <DialogTitle>Detalhes do Rastreio</DialogTitle>
                <DialogDescription>
                  Informações detalhadas do envio e histórico de eventos
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-6 py-4">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-gray-100 rounded-lg">
                    {getStatusIcon(selectedTracking.status, selectedTracking.has_issue)}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">{selectedTracking.tracking_code}</h3>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(selectedTracking.status)}
                      <span className="text-sm text-gray-500">
                        Última atualização: {formatDateTime(selectedTracking.last_update)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-x-6 gap-y-4">
                  <div>
                    <Label>Pedido</Label>
                    <p className="text-sm font-medium mt-1">{selectedTracking.order_number}</p>
                  </div>
                  <div>
                    <Label>Cliente</Label>
                    <p className="text-sm font-medium mt-1">{selectedTracking.customer_name}</p>
                  </div>
                  <div>
                    <Label>Transportadora</Label>
                    <p className="text-sm font-medium mt-1">{selectedTracking.carrier}</p>
                  </div>
                  <div>
                    <Label>Método de Envio</Label>
                    <p className="text-sm font-medium mt-1">{selectedTracking.shipping_method}</p>
                  </div>
                  <div>
                    <Label>Data de Envio</Label>
                    <p className="text-sm font-medium mt-1">{formatDate(selectedTracking.shipping_date)}</p>
                  </div>
                  <div>
                    <Label>Previsão de Entrega</Label>
                    <p className="text-sm font-medium mt-1">{formatDate(selectedTracking.estimated_delivery)}</p>
                  </div>
                  <div className="col-span-2">
                    <Label>Endereço de Entrega</Label>
                    <p className="text-sm font-medium mt-1">{selectedTracking.delivery_address}</p>
                  </div>
                </div>

                <div>
                  <Label>Histórico de Eventos</Label>
                  <div className="mt-2 space-y-4">
                    {selectedTracking.events.map((event, index) => (
                      <div key={index} className="flex gap-4">
                        <div className="w-36 shrink-0 text-sm text-gray-500">
                          {formatDateTime(event.date)}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{event.description}</p>
                          <p className="text-sm text-gray-500">{event.location}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setShowTrackingDetails(false)}>
                  Fechar
                </Button>
                <Button onClick={() => {
                  setShowTrackingDetails(false);
                  handleOpenUpdateDialog(selectedTracking);
                }}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Atualizar Status
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Dialog para atualizar rastreio */}
      <Dialog open={showUpdateDialog} onOpenChange={setShowUpdateDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Atualizar Rastreio</DialogTitle>
            <DialogDescription>
              Atualize o status e adicione um novo evento ao rastreio
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>Rastreio</Label>
              <div className="flex items-center gap-2 p-2 border rounded-md">
                <ScanLine className="h-5 w-5 text-gray-500" />
                <div>
                  <p className="font-medium">{selectedTracking?.tracking_code}</p>
                  <p className="text-sm text-gray-500">{selectedTracking?.order_number}</p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Novo Status</Label>
              <Select
                value={updateStatus}
                onValueChange={setUpdateStatus}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="postado">Postado</SelectItem>
                  <SelectItem value="em_transito">Em Trânsito</SelectItem>
                  <SelectItem value="entregue">Entregue</SelectItem>
                  <SelectItem value="problema">Problema</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Localização</Label>
              <Input
                id="location"
                value={updateLocation}
                onChange={(e) => setUpdateLocation(e.target.value)}
                placeholder="Ex: São Paulo/SP"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descrição do Evento</Label>
              <Textarea
                id="description"
                value={updateDescription}
                onChange={(e) => setUpdateDescription(e.target.value)}
                placeholder="Ex: Objeto em trânsito - de São Paulo/SP para Campinas/SP"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUpdateDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleUpdateTracking}
              disabled={!updateStatus || !updateLocation || !updateDescription}
            >
              Atualizar Rastreio
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog para atualização em massa */}
      <Dialog open={showBulkUpdateDialog} onOpenChange={setShowBulkUpdateDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Atualização em Massa</DialogTitle>
            <DialogDescription>
              Atualize o status de múltiplos rastreios simultaneamente
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>Rastreios Selecionados</Label>
              <div className="p-2 border rounded-md bg-gray-50">
                <p className="text-sm text-gray-600">
                  {getSelectedCount()} rastreios selecionados para atualização
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Novo Status</Label>
              <Select
                value={updateStatus}
                onValueChange={setUpdateStatus}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="postado">Postado</SelectItem>
                  <SelectItem value="em_transito">Em Trânsito</SelectItem>
                  <SelectItem value="entregue">Entregue</SelectItem>
                  <SelectItem value="problema">Problema</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Localização</Label>
              <Input
                id="location"
                value={updateLocation}
                onChange={(e) => setUpdateLocation(e.target.value)}
                placeholder="Ex: São Paulo/SP"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descrição do Evento</Label>
              <Textarea
                id="description"
                value={updateDescription}
                onChange={(e) => setUpdateDescription(e.target.value)}
                placeholder="Ex: Objeto em trânsito - de São Paulo/SP para Campinas/SP"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBulkUpdateDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleBulkUpdate}
              disabled={!updateStatus || !updateLocation || !updateDescription}
            >
              Atualizar {getSelectedCount()} Rastreios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog para notificar cliente */}
      <Dialog open={showNotifyCustomerDialog} onOpenChange={setShowNotifyCustomerDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Notificar Cliente</DialogTitle>
            <DialogDescription>
              Envie uma notificação por email ao cliente sobre o status do envio
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            {selectedTracking && (
              <div className="space-y-2">
                <Label>Cliente</Label>
                <div className="flex items-center gap-2 p-2 border rounded-md">
                  <div>
                    <p className="font-medium">{selectedTracking.customer_name}</p>
                    <p className="text-sm text-gray-500">Pedido: {selectedTracking.order_number}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="message">Mensagem Adicional (opcional)</Label>
              <Textarea
                id="message"
                value={notificationMessage}
                onChange={(e) => setNotificationMessage(e.target.value)}
                placeholder="Digite uma mensagem personalizada para o cliente..."
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNotifyCustomerDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleNotifyCustomer}>
              <Mail className="mr-2 h-4 w-4" />
              Enviar Notificação
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}