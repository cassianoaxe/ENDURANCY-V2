import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ShoppingCart, 
  FileText, 
  Building2, 
  Package, 
  ArrowUpRight, 
  AlertTriangle, 
  BarChart3, 
  Clock, 
  Plus, 
  Search, 
  Filter, 
  Calendar, 
  DollarSign, 
  BarChart, 
  TrendingUp,
  User,
  CheckCircle2,
  XCircle
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Dados simulados
const solicitacoesRecentes = [
  {
    id: "SOL-1001",
    descricao: "Material para laboratório de análise",
    solicitante: "Carlos Santos",
    setor: "Laboratório",
    data: "2023-07-28T10:30:00Z",
    valor: 4589.90,
    status: "aprovada",
    urgencia: "alta"
  },
  {
    id: "SOL-1000",
    descricao: "Equipamentos de escritório",
    solicitante: "Ana Silva",
    setor: "Administrativo",
    data: "2023-07-27T15:45:00Z",
    valor: 2750.00,
    status: "pendente",
    urgencia: "media"
  },
  {
    id: "SOL-0999",
    descricao: "Insumos para produção",
    solicitante: "Marcos Oliveira",
    setor: "Produção",
    data: "2023-07-27T09:15:00Z",
    valor: 12350.75,
    status: "em_cotacao",
    urgencia: "alta"
  },
  {
    id: "SOL-0998",
    descricao: "Material de limpeza",
    solicitante: "Juliana Lima",
    setor: "Infraestrutura",
    data: "2023-07-26T14:20:00Z",
    valor: 1850.30,
    status: "aprovada",
    urgencia: "baixa"
  },
  {
    id: "SOL-0997",
    descricao: "Licenças de software",
    solicitante: "Ricardo Gomes",
    setor: "TI",
    data: "2023-07-25T11:10:00Z",
    valor: 7890.00,
    status: "aguardando_entrega",
    urgencia: "media"
  }
];

const itensBaixoEstoque = [
  {
    id: "ITEM-0034",
    nome: "Reagente para extração",
    quantidade_atual: 5,
    quantidade_minima: 20,
    categoria: "Laboratório",
    unidade: "unid",
    ultima_compra: "2023-06-15"
  },
  {
    id: "ITEM-0102",
    nome: "Frascos de vidro âmbar 100ml",
    quantidade_atual: 32,
    quantidade_minima: 100,
    categoria: "Embalagens",
    unidade: "unid",
    ultima_compra: "2023-07-05"
  },
  {
    id: "ITEM-0208",
    nome: "Papel filtro",
    quantidade_atual: 10,
    quantidade_minima: 50,
    categoria: "Laboratório",
    unidade: "pacote",
    ultima_compra: "2023-05-20"
  }
];

const fornecedoresAtivos = [
  {
    id: "FORN-001",
    nome: "Suprimentos Laboratoriais SA",
    tipo: "Laboratório",
    avaliacao: 4.8,
    pedidos: 25,
    ultima_compra: "2023-07-15"
  },
  {
    id: "FORN-012",
    nome: "TechSupply LTDA",
    tipo: "Equipamentos",
    avaliacao: 4.5,
    pedidos: 18,
    ultima_compra: "2023-07-10"
  },
  {
    id: "FORN-008",
    nome: "Embalagens Express",
    tipo: "Embalagens",
    avaliacao: 4.2,
    pedidos: 32,
    ultima_compra: "2023-07-22"
  }
];

// Dados para gráficos
const dadosComprasMensais = [
  { mes: 'Jan', valor: 45000 },
  { mes: 'Fev', valor: 52000 },
  { mes: 'Mar', valor: 48000 },
  { mes: 'Abr', valor: 61000 },
  { mes: 'Mai', valor: 55000 },
  { mes: 'Jun', valor: 68000 },
  { mes: 'Jul', valor: 72000 }
];

export default function ComprasDashboard() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("geral");
  const [periodo, setPeriodo] = useState("mes");
  
  const [resumo, setResumo] = useState({
    solicitacoes_pendentes: 0,
    solicitacoes_aprovadas: 0,
    solicitacoes_cotacao: 0,
    valor_total: 0,
    economia_estimada: 0,
    tempo_medio_aprovacao: 0,
    fornecedores_ativos: 0,
    itens_estoque_critico: 0
  });

  useEffect(() => {
    // Simulando carregamento dos dados
    setTimeout(() => {
      const pendentes = solicitacoesRecentes.filter(s => s.status === "pendente").length;
      const aprovadas = solicitacoesRecentes.filter(s => s.status === "aprovada").length;
      const cotacao = solicitacoesRecentes.filter(s => s.status === "em_cotacao").length;
      const valorTotal = solicitacoesRecentes.reduce((total, s) => total + s.valor, 0);
      
      setResumo({
        solicitacoes_pendentes: pendentes,
        solicitacoes_aprovadas: aprovadas,
        solicitacoes_cotacao: cotacao,
        valor_total: valorTotal,
        economia_estimada: valorTotal * 0.12, // 12% de economia estimada
        tempo_medio_aprovacao: 1.8, // em dias
        fornecedores_ativos: fornecedoresAtivos.length,
        itens_estoque_critico: itensBaixoEstoque.length
      });
      
      setLoading(false);
    }, 500);
  }, []);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "aprovada":
        return <Badge className="bg-green-100 text-green-800">Aprovada</Badge>;
      case "pendente":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case "em_cotacao":
        return <Badge className="bg-blue-100 text-blue-800">Em Cotação</Badge>;
      case "aguardando_entrega":
        return <Badge className="bg-purple-100 text-purple-800">Aguardando Entrega</Badge>;
      case "recebida":
        return <Badge className="bg-indigo-100 text-indigo-800">Recebida</Badge>;
      case "rejeitada":
        return <Badge className="bg-red-100 text-red-800">Rejeitada</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  const getUrgenciaBadge = (urgencia) => {
    switch (urgencia) {
      case "baixa":
        return <Badge className="bg-blue-100 text-blue-800">Baixa</Badge>;
      case "media":
        return <Badge className="bg-yellow-100 text-yellow-800">Média</Badge>;
      case "alta":
        return <Badge className="bg-red-100 text-red-800">Alta</Badge>;
      case "critica":
        return <Badge className="bg-red-600 text-white">Crítica</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{urgencia}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Dashboard de Compras</h1>
          <p className="text-gray-500 mt-1">
            Visão geral das solicitações de compra, fornecedores e estoque
          </p>
        </div>
        
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <Calendar className="w-4 h-4" />
            {periodo === "mes" ? "Este Mês" : periodo === "trimestre" ? "Este Trimestre" : "Este Ano"}
          </Button>
          <Link to={createPageUrl("NovaSolicitacaoCompra")}>
            <Button className="gap-2 bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4" />
              Nova Solicitação
            </Button>
          </Link>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="geral">Visão Geral</TabsTrigger>
          <TabsTrigger value="solicitacoes">Solicitações</TabsTrigger>
          <TabsTrigger value="estoque">Estoque</TabsTrigger>
          <TabsTrigger value="fornecedores">Fornecedores</TabsTrigger>
        </TabsList>

        <TabsContent value="geral">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Solicitações Pendentes</CardTitle>
                <div className="text-3xl font-bold">
                  {loading ? "..." : resumo.solicitacoes_pendentes}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-xs text-muted-foreground">
                  <span className="flex items-center text-yellow-600">
                    <Clock className="h-3 w-3 mr-1" />
                    Aguardando aprovação
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Valor Total em Análise</CardTitle>
                <div className="text-3xl font-bold">
                  {loading ? "..." : formatCurrency(resumo.valor_total)}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-xs text-muted-foreground">
                  <span className="flex items-center text-green-600">
                    <DollarSign className="h-3 w-3 mr-1" />
                    Economia potencial: {loading ? "..." : formatCurrency(resumo.economia_estimada)}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Fornecedores Ativos</CardTitle>
                <div className="text-3xl font-bold">
                  {loading ? "..." : resumo.fornecedores_ativos}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-xs text-muted-foreground">
                  <span className="flex items-center text-blue-600">
                    <Building2 className="h-3 w-3 mr-1" />
                    Últimos 30 dias
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Itens em Estoque Crítico</CardTitle>
                <div className="text-3xl font-bold">
                  {loading ? "..." : resumo.itens_estoque_critico}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-xs text-muted-foreground">
                  <span className="flex items-center text-red-600">
                    <AlertTriangle className="h-3 w-3 mr-1" />
                    Ação recomendada
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Volume de Compras</CardTitle>
                <CardDescription>
                  Total de compras nos últimos 7 meses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  {/* Chart placeholder - in a real app, use recharts BarChart */}
                  <div className="bg-gray-50 rounded-md p-4 h-full flex items-center justify-center">
                    <BarChart className="h-16 w-16 text-gray-300" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Solicitações por Status</CardTitle>
                <CardDescription>
                  Distribuição de solicitações por status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  {/* Chart placeholder - in a real app, use recharts PieChart */}
                  <div className="bg-gray-50 rounded-md p-4 h-full flex items-center justify-center">
                    <BarChart3 className="h-16 w-16 text-gray-300" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 gap-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Solicitações Recentes</CardTitle>
                  <Link to={createPageUrl("SolicitacoesCompra")}>
                    <Button variant="ghost" size="sm">Ver todas</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Solicitante</TableHead>
                      <TableHead>Setor</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Urgência</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array(3).fill(0).map((_, i) => (
                        <TableRow key={i} className="animate-pulse">
                          <TableCell colSpan={8}>
                            <div className="h-5 bg-gray-200 rounded w-full"></div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      solicitacoesRecentes.map((solicitacao) => (
                        <TableRow key={solicitacao.id} className="cursor-pointer hover:bg-gray-50" onClick={() => navigate(`${createPageUrl("SolicitacaoDetalhe")}?id=${solicitacao.id}`)}>
                          <TableCell className="font-medium">{solicitacao.id}</TableCell>
                          <TableCell>{solicitacao.descricao}</TableCell>
                          <TableCell>{solicitacao.solicitante}</TableCell>
                          <TableCell>{solicitacao.setor}</TableCell>
                          <TableCell>{formatDate(solicitacao.data)}</TableCell>
                          <TableCell>{formatCurrency(solicitacao.valor)}</TableCell>
                          <TableCell>{getStatusBadge(solicitacao.status)}</TableCell>
                          <TableCell>{getUrgenciaBadge(solicitacao.urgencia)}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Itens com Estoque Crítico</CardTitle>
                  <Link to={createPageUrl("Estoque")}>
                    <Button variant="ghost" size="sm">Ver todos</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Código</TableHead>
                      <TableHead>Item</TableHead>
                      <TableHead>Quantidade</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array(3).fill(0).map((_, i) => (
                        <TableRow key={i} className="animate-pulse">
                          <TableCell colSpan={5}>
                            <div className="h-5 bg-gray-200 rounded w-full"></div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      itensBaixoEstoque.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{item.id}</TableCell>
                          <TableCell>{item.nome}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Badge className="bg-red-100 text-red-800">
                                {item.quantidade_atual} / {item.quantidade_minima}
                              </Badge>
                              <span className="text-xs text-gray-500">{item.unidade}</span>
                            </div>
                          </TableCell>
                          <TableCell>{item.categoria}</TableCell>
                          <TableCell>
                            <Link to={`${createPageUrl("NovaSolicitacaoCompra")}?item_id=${item.id}`}>
                              <Button variant="outline" size="sm">
                                Solicitar
                              </Button>
                            </Link>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Fornecedores Principais</CardTitle>
                  <Link to={createPageUrl("ProducaoFornecedores")}>
                    <Button variant="ghost" size="sm">Ver todos</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fornecedor</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Avaliação</TableHead>
                      <TableHead>Pedidos</TableHead>
                      <TableHead>Última Compra</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      Array(3).fill(0).map((_, i) => (
                        <TableRow key={i} className="animate-pulse">
                          <TableCell colSpan={5}>
                            <div className="h-5 bg-gray-200 rounded w-full"></div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      fornecedoresAtivos.map((fornecedor) => (
                        <TableRow key={fornecedor.id}>
                          <TableCell className="font-medium">{fornecedor.nome}</TableCell>
                          <TableCell>{fornecedor.tipo}</TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {fornecedor.avaliacao.toFixed(1)} ★
                            </Badge>
                          </TableCell>
                          <TableCell>{fornecedor.pedidos}</TableCell>
                          <TableCell>{formatDate(fornecedor.ultima_compra)}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="solicitacoes">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Todas as Solicitações</CardTitle>
                  <CardDescription>
                    Gerencie todas as solicitações de compra
                  </CardDescription>
                </div>
                <div className="flex gap-3">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      placeholder="Buscar solicitação..."
                      className="pl-8 w-full md:w-64"
                    />
                  </div>
                  <Button variant="outline" className="gap-2">
                    <Filter className="w-4 h-4" />
                    Filtrar
                  </Button>
                  <Link to={createPageUrl("NovaSolicitacaoCompra")}>
                    <Button className="gap-2">
                      <Plus className="w-4 h-4" />
                      Nova
                    </Button>
                  </Link>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <FileText className="h-16 w-16 text-gray-300 mx-auto mb-2" />
                <h3 className="font-medium text-lg">Visualização Estendida</h3>
                <p className="text-gray-500 max-w-md mx-auto mt-1">
                  Acesse a página de Solicitações de Compra para ver a lista completa com mais opções de gerenciamento.
                </p>
                <Button 
                  className="mt-4"
                  onClick={() => navigate(createPageUrl("SolicitacoesCompra"))}
                >
                  Ver Todas as Solicitações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="estoque">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Controle de Estoque</CardTitle>
                  <CardDescription>
                    Gerenciar estoque de materiais e produtos
                  </CardDescription>
                </div>
                <div className="flex gap-3">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      placeholder="Buscar item..."
                      className="pl-8 w-full md:w-64"
                    />
                  </div>
                  <Button variant="outline" className="gap-2">
                    <Filter className="w-4 h-4" />
                    Filtrar
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <Package className="h-16 w-16 text-gray-300 mx-auto mb-2" />
                <h3 className="font-medium text-lg">Visualização Estendida</h3>
                <p className="text-gray-500 max-w-md mx-auto mt-1">
                  Acesse a página de Estoque para ver o inventário completo com ferramentas adicionais de gerenciamento.
                </p>
                <Button 
                  className="mt-4"
                  onClick={() => navigate(createPageUrl("Estoque"))}
                >
                  Gerenciar Estoque
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fornecedores">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Fornecedores</CardTitle>
                  <CardDescription>
                    Gerenciar cadastro de fornecedores e avaliações
                  </CardDescription>
                </div>
                <div className="flex gap-3">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      placeholder="Buscar fornecedor..."
                      className="pl-8 w-full md:w-64"
                    />
                  </div>
                  <Button variant="outline" className="gap-2">
                    <Filter className="w-4 h-4" />
                    Filtrar
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <Building2 className="h-16 w-16 text-gray-300 mx-auto mb-2" />
                <h3 className="font-medium text-lg">Visualização Estendida</h3>
                <p className="text-gray-500 max-w-md mx-auto mt-1">
                  Acesse a página de Fornecedores para gerenciar todos os seus fornecedores, avaliações e histórico.
                </p>
                <Button 
                  className="mt-4"
                  onClick={() => navigate(createPageUrl("ProducaoFornecedores"))}
                >
                  Gerenciar Fornecedores
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}