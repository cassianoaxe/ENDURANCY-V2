
import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Download, 
  Upload, 
  DownloadCloud, 
  UploadCloud, 
  Check, 
  AlertTriangle, 
  MoreHorizontal, 
  Save, 
  RefreshCw, 
  Clock, 
  Calendar, 
  Server, 
  HardDrive, 
  FileCheck, 
  FileX, 
  Settings as SettingsIcon,
  Shield,
  Lock,
  FileArchive,
  History,
  Eye,
  ChevronDown,
  ChevronUp,
  Filter
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "@/components/ui/use-toast";

// Dados simulados de backups
const mockBackups = [
  {
    id: "backup-001",
    name: "Backup Diário - Completo",
    type: "complete",
    status: "completed",
    size: "2.3 GB",
    created_date: "2023-07-14T03:00:00Z",
    duration: "45 min",
    retention: "30 days",
    location: "AWS S3",
    files: 12453,
    entities: ["Organizations", "Documents", "Users", "Activities"],
    metadata: {
      compressed: true,
      encrypted: true,
      version: "1.2.5"
    }
  },
  {
    id: "backup-002",
    name: "Backup Diário - Incremental",
    type: "incremental",
    status: "completed",
    size: "450 MB",
    created_date: "2023-07-15T03:00:00Z",
    duration: "12 min",
    retention: "15 days",
    location: "AWS S3",
    files: 1245,
    entities: ["Organizations", "Documents", "Users", "Activities"],
    metadata: {
      compressed: true,
      encrypted: true,
      version: "1.2.5"
    }
  },
  {
    id: "backup-003",
    name: "Backup Diário - Incremental",
    type: "incremental",
    status: "completed",
    size: "320 MB",
    created_date: "2023-07-16T03:00:00Z",
    duration: "10 min",
    retention: "15 days",
    location: "AWS S3",
    files: 982,
    entities: ["Organizations", "Documents", "Users", "Activities"],
    metadata: {
      compressed: true,
      encrypted: true,
      version: "1.2.5"
    }
  },
  {
    id: "backup-004",
    name: "Backup Semanal - Completo",
    type: "complete",
    status: "completed",
    size: "2.5 GB",
    created_date: "2023-07-17T02:00:00Z",
    duration: "52 min",
    retention: "90 days",
    location: "AWS S3",
    files: 13245,
    entities: ["Organizations", "Documents", "Users", "Activities"],
    metadata: {
      compressed: true,
      encrypted: true,
      version: "1.2.5"
    }
  },
  {
    id: "backup-005",
    name: "Backup Mensal - Arquivamento",
    type: "archive",
    status: "completed",
    size: "2.8 GB",
    created_date: "2023-07-01T01:00:00Z",
    duration: "65 min",
    retention: "365 days",
    location: "AWS Glacier",
    files: 14536,
    entities: ["Organizations", "Documents", "Users", "Activities"],
    metadata: {
      compressed: true,
      encrypted: true,
      version: "1.2.5"
    }
  },
  {
    id: "backup-006",
    name: "Backup Manual - Pré-atualização",
    type: "manual",
    status: "completed",
    size: "2.4 GB",
    created_date: "2023-07-10T15:30:00Z",
    duration: "48 min",
    retention: "60 days",
    location: "AWS S3",
    files: 12904,
    entities: ["Organizations", "Documents", "Users", "Activities"],
    metadata: {
      compressed: true,
      encrypted: true,
      version: "1.2.5"
    }
  },
  {
    id: "backup-007",
    name: "Backup Diário - Completo",
    type: "complete",
    status: "in_progress",
    size: null,
    created_date: "2023-07-18T03:00:00Z",
    duration: null,
    retention: "30 days",
    location: "AWS S3",
    files: null,
    entities: ["Organizations", "Documents", "Users", "Activities"],
    metadata: {
      compressed: true,
      encrypted: true,
      version: "1.2.5"
    }
  },
  {
    id: "backup-008",
    name: "Backup Manual - Emergência",
    type: "manual",
    status: "failed",
    size: null,
    created_date: "2023-07-12T18:45:00Z",
    duration: "5 min",
    retention: "60 days",
    location: "AWS S3",
    files: null,
    entities: ["Organizations", "Documents", "Users", "Activities"],
    metadata: {
      compressed: true,
      encrypted: true,
      version: "1.2.5",
      error: "Connection timeout"
    }
  }
];

// Configurações de backup
const backupSettings = {
  automated: {
    daily: {
      enabled: true,
      time: "03:00",
      type: "incremental",
      retention: 30,
      days: ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    },
    weekly: {
      enabled: true,
      day: "sunday",
      time: "02:00",
      type: "complete",
      retention: 90
    },
    monthly: {
      enabled: true,
      day: 1,
      time: "01:00",
      type: "archive",
      retention: 365
    }
  },
  storage: {
    provider: "aws_s3",
    compression: true,
    encryption: true,
    region: "us-east-1"
  },
  notifications: {
    on_completion: true,
    on_failure: true,
    recipients: ["admin@endurancy.com"]
  }
};

export default function Backups() {
  const [backups, setBackups] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState("history");
  const [sortOrder, setSortOrder] = useState("desc");
  const [backupInProgress, setBackupInProgress] = useState(false);
  const [progressValue, setProgressValue] = useState(0);
  const [settings, setSettings] = useState(backupSettings);
  
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      setTimeout(() => {
        const sortedBackups = [...mockBackups].sort((a, b) => {
          return new Date(b.created_date) - new Date(a.created_date);
        });
        
        setBackups(sortedBackups);
        
        const inProgressBackup = sortedBackups.find(b => b.status === "in_progress");
        if (inProgressBackup) {
          setBackupInProgress(true);
          simulateBackupProgress();
        }
        
        setIsLoading(false);
      }, 1000);
    };
    
    loadData();
  }, []);
  
  const simulateBackupProgress = () => {
    setProgressValue(0);
    const interval = setInterval(() => {
      setProgressValue(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setBackupInProgress(false);
          setBackups(prev => prev.map(b => {
            if (b.status === "in_progress") {
              return {
                ...b, 
                status: "completed",
                size: "2.2 GB",
                duration: "43 min",
                files: 12356
              };
            }
            return b;
          }));
          
          toast({
            title: "Backup concluído",
            description: "O backup diário foi concluído com sucesso.",
          });
          
          return 100;
        }
        return prev + 1;
      });
    }, 300);
  };
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  const handleStartBackup = () => {
    if (!backupInProgress) {
      setBackupInProgress(true);
      
      const newBackup = {
        id: `backup-${Date.now()}`,
        name: "Backup Manual",
        type: "manual",
        status: "in_progress",
        size: null,
        created_date: new Date().toISOString(),
        duration: null,
        retention: "60 days",
        location: "AWS S3",
        files: null,
        entities: ["Organizations", "Documents", "Users", "Activities"],
        metadata: {
          compressed: true,
          encrypted: true,
          version: "1.2.5"
        }
      };
      
      setBackups(prev => [newBackup, ...prev]);
      simulateBackupProgress();
      
      toast({
        title: "Backup iniciado",
        description: "O backup manual foi iniciado e está em andamento.",
      });
    } else {
      toast({
        title: "Backup em andamento",
        description: "Aguarde a conclusão do backup atual.",
        variant: "destructive",
      });
    }
  };
  
  const getStatusBadge = (status) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Concluído</Badge>;
      case "in_progress":
        return <Badge className="bg-blue-100 text-blue-800">Em Andamento</Badge>;
      case "failed":
        return <Badge className="bg-red-100 text-red-800">Falhou</Badge>;
      case "scheduled":
        return <Badge className="bg-yellow-100 text-yellow-800">Agendado</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };
  
  const getTypeIcon = (type) => {
    switch (type) {
      case "complete":
        return <Database className="w-4 h-4 text-purple-500" />;
      case "incremental":
        return <RefreshCw className="w-4 h-4 text-blue-500" />;
      case "archive":
        return <FileArchive className="w-4 h-4 text-amber-500" />;
      case "manual":
        return <Save className="w-4 h-4 text-green-500" />;
      default:
        return <Database className="w-4 h-4 text-gray-500" />;
    }
  };
  
  const getNextScheduledBackups = () => {
    const now = new Date();
    const nextBackups = [];
    
    if (settings.automated.daily.enabled) {
      const [hours, minutes] = settings.automated.daily.time.split(':').map(Number);
      const nextDaily = new Date(now);
      nextDaily.setHours(hours, minutes, 0, 0);
      if (nextDaily <= now) {
        nextDaily.setDate(nextDaily.getDate() + 1);
      }
      nextBackups.push({
        id: "next-daily",
        name: "Backup Diário",
        type: settings.automated.daily.type,
        scheduled_time: nextDaily.toISOString()
      });
    }
    
    if (settings.automated.weekly.enabled) {
      const days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
      const targetDay = days.indexOf(settings.automated.weekly.day);
      const [hours, minutes] = settings.automated.weekly.time.split(':').map(Number);
      const nextWeekly = new Date(now);
      nextWeekly.setHours(hours, minutes, 0, 0);
      
      const currentDay = nextWeekly.getDay();
      const daysToAdd = (targetDay + 7 - currentDay) % 7;
      
      nextWeekly.setDate(nextWeekly.getDate() + daysToAdd);
      if (daysToAdd === 0 && nextWeekly <= now) {
        nextWeekly.setDate(nextWeekly.getDate() + 7);
      }
      
      nextBackups.push({
        id: "next-weekly",
        name: "Backup Semanal",
        type: settings.automated.weekly.type,
        scheduled_time: nextWeekly.toISOString()
      });
    }
    
    if (settings.automated.monthly.enabled) {
      const [hours, minutes] = settings.automated.monthly.time.split(':').map(Number);
      const targetDay = settings.automated.monthly.day;
      
      let nextMonthly = new Date(now.getFullYear(), now.getMonth(), targetDay, hours, minutes, 0, 0);
      if (nextMonthly <= now) {
        nextMonthly = new Date(now.getFullYear(), now.getMonth() + 1, targetDay, hours, minutes, 0, 0);
      }
      
      nextBackups.push({
        id: "next-monthly",
        name: "Backup Mensal",
        type: settings.automated.monthly.type,
        scheduled_time: nextMonthly.toISOString()
      });
    }
    
    return nextBackups.sort((a, b) => new Date(a.scheduled_time) - new Date(b.scheduled_time));
  };
  
  const nextScheduledBackups = getNextScheduledBackups();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Backups do Sistema</h1>
          <p className="text-gray-500 mt-1">
            Gerencie backups automáticos e manuais da plataforma
          </p>
        </div>
        <Button 
          onClick={handleStartBackup} 
          disabled={backupInProgress}
          className="gap-2"
        >
          <Save className="w-4 h-4" />
          Iniciar Backup Manual
        </Button>
      </div>
      
      {backupInProgress && (
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-6">
            <div className="flex gap-4 items-center mb-4">
              <div className="bg-blue-100 p-2 rounded-full">
                <UploadCloud className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium">Backup em Andamento</h3>
                <p className="text-sm text-gray-500">Criando snapshot dos dados do sistema</p>
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>Progresso</span>
                <span>{progressValue}%</span>
              </div>
              <Progress value={progressValue} className="h-2" />
            </div>
          </CardContent>
        </Card>
      )}
      
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList>
          <TabsTrigger value="history" className="gap-2">
            <History className="w-4 h-4" />
            Histórico de Backups
          </TabsTrigger>
          <TabsTrigger value="schedule" className="gap-2">
            <Calendar className="w-4 h-4" />
            Agendamento
          </TabsTrigger>
          <TabsTrigger value="settings" className="gap-2">
            <SettingsIcon className="w-4 h-4" />
            Configurações
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="history" className="mt-6">
          {isLoading ? (
            <div className="h-96 flex items-center justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-800" />
            </div>
          ) : (
            <Card>
              <CardHeader className="pb-0">
                <div className="flex justify-between">
                  <CardTitle>Histórico</CardTitle>
                  <Select value={sortOrder} onValueChange={setSortOrder}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="desc">Mais recentes primeiro</SelectItem>
                      <SelectItem value="asc">Mais antigos primeiro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Tamanho</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Duração</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {backups
                      .slice()
                      .sort((a, b) => {
                        const dateA = new Date(a.created_date);
                        const dateB = new Date(b.created_date);
                        return sortOrder === "desc" ? dateB - dateA : dateA - dateB;
                      })
                      .map((backup) => (
                        <TableRow key={backup.id}>
                          <TableCell className="font-medium">{backup.name}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1.5">
                              {getTypeIcon(backup.type)}
                              <span className="capitalize">
                                {backup.type === "complete" && "Completo"}
                                {backup.type === "incremental" && "Incremental"}
                                {backup.type === "archive" && "Arquivo"}
                                {backup.type === "manual" && "Manual"}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>{getStatusBadge(backup.status)}</TableCell>
                          <TableCell>{backup.size || "-"}</TableCell>
                          <TableCell>{formatDate(backup.created_date)}</TableCell>
                          <TableCell>{backup.duration || "-"}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                  <span className="sr-only">Abrir menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                <DropdownMenuItem 
                                  onClick={() => {
                                    toast({
                                      title: "Detalhes do backup",
                                      description: `Visualizando detalhes do backup ${backup.name}`,
                                    });
                                  }}
                                >
                                  <Eye className="w-4 h-4 mr-2" />
                                  Detalhes
                                </DropdownMenuItem>
                                {backup.status === "completed" && (
                                  <DropdownMenuItem 
                                    onClick={() => {
                                      toast({
                                        title: "Download iniciado",
                                        description: `O download do backup ${backup.name} foi iniciado`,
                                      });
                                    }}
                                  >
                                    <Download className="w-4 h-4 mr-2" />
                                    Download
                                  </DropdownMenuItem>
                                )}
                                {backup.status === "failed" && (
                                  <DropdownMenuItem 
                                    onClick={() => {
                                      toast({
                                        title: "Tentar novamente",
                                        description: `Tentando executar o backup ${backup.name} novamente`,
                                      });
                                    }}
                                  >
                                    <RefreshCw className="w-4 h-4 mr-2" />
                                    Tentar novamente
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="schedule" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Próximos Backups Agendados</CardTitle>
                <CardDescription>
                  Lista dos próximos backups automáticos programados
                </CardDescription>
              </CardHeader>
              <CardContent>
                {nextScheduledBackups.length === 0 ? (
                  <div className="text-center py-8">
                    <Clock className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                    <h3 className="text-lg font-medium text-gray-900">Nenhum backup agendado</h3>
                    <p className="text-gray-500 mt-1">
                      Configure os backups automáticos na aba de configurações.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {nextScheduledBackups.map((backup) => (
                      <div key={backup.id} className="flex items-start gap-4">
                        <div className="bg-blue-50 p-3 rounded-full">
                          {getTypeIcon(backup.type)}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{backup.name}</h3>
                          <p className="text-sm text-gray-500">
                            Agendado para {formatDate(backup.scheduled_time)}
                          </p>
                        </div>
                        <Badge className="bg-yellow-100 text-yellow-800">
                          Agendado
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Configuração de Agendamento</CardTitle>
                <CardDescription>
                  Configurações atuais para backups automáticos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium mb-2">Diário</h3>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="space-y-1">
                        <p className="text-gray-500">Status</p>
                        <p>
                          {settings.automated.daily.enabled ? (
                            <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                          ) : (
                            <Badge className="bg-gray-100 text-gray-800">Inativo</Badge>
                          )}
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-gray-500">Hora</p>
                        <p>{settings.automated.daily.time}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-gray-500">Tipo</p>
                        <p className="capitalize">{settings.automated.daily.type === "incremental" ? "Incremental" : "Completo"}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-gray-500">Retenção</p>
                        <p>{settings.automated.daily.retention} dias</p>
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-sm font-medium mb-2">Semanal</h3>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="space-y-1">
                        <p className="text-gray-500">Status</p>
                        <p>
                          {settings.automated.weekly.enabled ? (
                            <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                          ) : (
                            <Badge className="bg-gray-100 text-gray-800">Inativo</Badge>
                          )}
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-gray-500">Dia e Hora</p>
                        <p>
                          {settings.automated.weekly.day === "sunday" && "Domingo"}
                          {settings.automated.weekly.day === "monday" && "Segunda"}
                          {settings.automated.weekly.day === "tuesday" && "Terça"}
                          {settings.automated.weekly.day === "wednesday" && "Quarta"}
                          {settings.automated.weekly.day === "thursday" && "Quinta"}
                          {settings.automated.weekly.day === "friday" && "Sexta"}
                          {settings.automated.weekly.day === "saturday" && "Sábado"}
                          {" às "}
                          {settings.automated.weekly.time}
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-gray-500">Tipo</p>
                        <p className="capitalize">{settings.automated.weekly.type === "complete" ? "Completo" : "Incremental"}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-gray-500">Retenção</p>
                        <p>{settings.automated.weekly.retention} dias</p>
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-sm font-medium mb-2">Mensal</h3>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="space-y-1">
                        <p className="text-gray-500">Status</p>
                        <p>
                          {settings.automated.monthly.enabled ? (
                            <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                          ) : (
                            <Badge className="bg-gray-100 text-gray-800">Inativo</Badge>
                          )}
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-gray-500">Dia e Hora</p>
                        <p>Dia {settings.automated.monthly.day} às {settings.automated.monthly.time}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-gray-500">Tipo</p>
                        <p className="capitalize">{settings.automated.monthly.type === "archive" ? "Arquivamento" : "Completo"}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-gray-500">Retenção</p>
                        <p>{settings.automated.monthly.retention} dias</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => setSelectedTab("settings")}>
                  <SettingsIcon className="w-4 h-4 mr-2" />
                  Editar Configurações
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="settings" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Backup</CardTitle>
              <CardDescription>
                Configure as opções de armazenamento e automação dos backups
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div>
                  <h3 className="text-lg font-medium mb-4">Armazenamento</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="storage-provider">Provedor de Armazenamento</Label>
                        <Select defaultValue={settings.storage.provider}>
                          <SelectTrigger id="storage-provider">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="aws_s3">AWS S3</SelectItem>
                            <SelectItem value="google_cloud">Google Cloud Storage</SelectItem>
                            <SelectItem value="azure">Azure Blob Storage</SelectItem>
                            <SelectItem value="local">Armazenamento Local</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="storage-region">Região</Label>
                        <Select defaultValue={settings.storage.region}>
                          <SelectTrigger id="storage-region">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="us-east-1">US East (N. Virginia)</SelectItem>
                            <SelectItem value="us-west-1">US West (N. California)</SelectItem>
                            <SelectItem value="eu-west-1">EU (Ireland)</SelectItem>
                            <SelectItem value="sa-east-1">South America (São Paulo)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="compression"
                        checked={settings.storage.compression}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <Label htmlFor="compression" className="text-sm">Compressão de dados</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="encryption"
                        checked={settings.storage.encryption}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <Label htmlFor="encryption" className="text-sm">Criptografia de dados</Label>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Automação</h3>
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">Backup Diário</h4>
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="daily-enabled"
                            checked={settings.automated.daily.enabled}
                            className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                          />
                          <Label htmlFor="daily-enabled" className="text-sm">Ativar</Label>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="daily-time" className="text-sm">Horário</Label>
                          <Select defaultValue={settings.automated.daily.time}>
                            <SelectTrigger id="daily-time">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="00:00">00:00</SelectItem>
                              <SelectItem value="01:00">01:00</SelectItem>
                              <SelectItem value="02:00">02:00</SelectItem>
                              <SelectItem value="03:00">03:00</SelectItem>
                              <SelectItem value="04:00">04:00</SelectItem>
                              <SelectItem value="22:00">22:00</SelectItem>
                              <SelectItem value="23:00">23:00</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="daily-type" className="text-sm">Tipo</Label>
                          <Select defaultValue={settings.automated.daily.type}>
                            <SelectTrigger id="daily-type">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="incremental">Incremental</SelectItem>
                              <SelectItem value="complete">Completo</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="daily-retention" className="text-sm">Retenção (dias)</Label>
                          <Select defaultValue={settings.automated.daily.retention.toString()}>
                            <SelectTrigger id="daily-retention">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="7">7 dias</SelectItem>
                              <SelectItem value="15">15 dias</SelectItem>
                              <SelectItem value="30">30 dias</SelectItem>
                              <SelectItem value="60">60 dias</SelectItem>
                              <SelectItem value="90">90 dias</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">Backup Semanal</h4>
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="weekly-enabled"
                            checked={settings.automated.weekly.enabled}
                            className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                          />
                          <Label htmlFor="weekly-enabled" className="text-sm">Ativar</Label>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="weekly-day" className="text-sm">Dia da Semana</Label>
                          <Select defaultValue={settings.automated.weekly.day}>
                            <SelectTrigger id="weekly-day">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="sunday">Domingo</SelectItem>
                              <SelectItem value="monday">Segunda-feira</SelectItem>
                              <SelectItem value="tuesday">Terça-feira</SelectItem>
                              <SelectItem value="wednesday">Quarta-feira</SelectItem>
                              <SelectItem value="thursday">Quinta-feira</SelectItem>
                              <SelectItem value="friday">Sexta-feira</SelectItem>
                              <SelectItem value="saturday">Sábado</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="weekly-time" className="text-sm">Horário</Label>
                          <Select defaultValue={settings.automated.weekly.time}>
                            <SelectTrigger id="weekly-time">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="00:00">00:00</SelectItem>
                              <SelectItem value="01:00">01:00</SelectItem>
                              <SelectItem value="02:00">02:00</SelectItem>
                              <SelectItem value="03:00">03:00</SelectItem>
                              <SelectItem value="04:00">04:00</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="weekly-type" className="text-sm">Tipo</Label>
                          <Select defaultValue={settings.automated.weekly.type}>
                            <SelectTrigger id="weekly-type">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="complete">Completo</SelectItem>
                              <SelectItem value="incremental">Incremental</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="weekly-retention" className="text-sm">Retenção (dias)</Label>
                          <Select defaultValue={settings.automated.weekly.retention.toString()}>
                            <SelectTrigger id="weekly-retention">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="30">30 dias</SelectItem>
                              <SelectItem value="60">60 dias</SelectItem>
                              <SelectItem value="90">90 dias</SelectItem>
                              <SelectItem value="180">180 dias</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">Backup Mensal</h4>
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="monthly-enabled"
                            checked={settings.automated.monthly.enabled}
                            className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                          />
                          <Label htmlFor="monthly-enabled" className="text-sm">Ativar</Label>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="monthly-day" className="text-sm">Dia do Mês</Label>
                          <Select defaultValue={settings.automated.monthly.day.toString()}>
                            <SelectTrigger id="monthly-day">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1">Dia 1</SelectItem>
                              <SelectItem value="5">Dia 5</SelectItem>
                              <SelectItem value="10">Dia 10</SelectItem>
                              <SelectItem value="15">Dia 15</SelectItem>
                              <SelectItem value="20">Dia 20</SelectItem>
                              <SelectItem value="25">Dia 25</SelectItem>
                              <SelectItem value="28">Dia 28</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="monthly-time" className="text-sm">Horário</Label>
                          <Select defaultValue={settings.automated.monthly.time}>
                            <SelectTrigger id="monthly-time">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="00:00">00:00</SelectItem>
                              <SelectItem value="01:00">01:00</SelectItem>
                              <SelectItem value="02:00">02:00</SelectItem>
                              <SelectItem value="03:00">03:00</SelectItem>
                              <SelectItem value="04:00">04:00</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="monthly-type" className="text-sm">Tipo</Label>
                          <Select defaultValue={settings.automated.monthly.type}>
                            <SelectTrigger id="monthly-type">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="archive">Arquivamento</SelectItem>
                              <SelectItem value="complete">Completo</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="monthly-retention" className="text-sm">Retenção (dias)</Label>
                          <Select defaultValue={settings.automated.monthly.retention.toString()}>
                            <SelectTrigger id="monthly-retention">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="90">90 dias</SelectItem>
                              <SelectItem value="180">180 dias</SelectItem>
                              <SelectItem value="365">365 dias</SelectItem>
                              <SelectItem value="730">730 dias</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Notificações</h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="notify-completion"
                        checked={settings.notifications.on_completion}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <Label htmlFor="notify-completion" className="text-sm">Notificar quando um backup for concluído</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="notify-failure"
                        checked={settings.notifications.on_failure}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <Label htmlFor="notify-failure" className="text-sm">Notificar quando um backup falhar</Label>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email-recipients" className="text-sm">Destinatários de Email</Label>
                      <Input 
                        id="email-recipients"
                        type="text" 
                        placeholder="Emails separados por vírgula" 
                        defaultValue={settings.notifications.recipients.join(", ")} 
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-4">
              <Button variant="outline">Cancelar</Button>
              <Button
                onClick={() => {
                  toast({
                    title: "Configurações salvas",
                    description: "As configurações de backup foram atualizadas com sucesso.",
                  });
                }}
              >
                Salvar Configurações
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
