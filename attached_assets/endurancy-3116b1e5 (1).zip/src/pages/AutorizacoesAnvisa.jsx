import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  ShieldCheck,
  UserPlus, 
  Search, 
  Filter, 
  FileText, 
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Eye,
  Download,
  Bell,
  MoreHorizontal,
  Plus,
  RefreshCw,
  FilePlus
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

// Dados mockados para demonstração
const autorizacoes = [
  {
    id: "aut001",
    numero_autorizacao: "25351.123456/2023-12",
    cliente: {
      id: "cli001",
      nome: "Ana Silva",
      email: "ana.silva@email.com"
    },
    data_emissao: "2023-05-15",
    data_validade: "2024-05-15",
    status: "valida",
    produtos_autorizados: [
      {
        nome: "Óleo CBD 10%",
        dosagem: "30ml",
        quantidade: "3 frascos",
        fabricante: "MediCannabis"
      }
    ],
    medico: {
      nome: "Dr. Carlos Santos",
      crm: "CRM-SP 123456",
      especialidade: "Neurologia"
    },
    condicao_medica: "Epilepsia refratária"
  },
  {
    id: "aut002",
    numero_autorizacao: "25351.654321/2023-34",
    cliente: {
      id: "cli002",
      nome: "Carlos Oliveira",
      email: "carlos.oliveira@email.com"
    },
    data_emissao: "2023-06-20",
    data_validade: "2023-12-20",
    status: "em_renovacao",
    produtos_autorizados: [
      {
        nome: "Óleo CBD 5%",
        dosagem: "30ml",
        quantidade: "2 frascos",
        fabricante: "CannaHealth"
      }
    ],
    medico: {
      nome: "Dra. Mariana Costa",
      crm: "CRM-RJ 789012",
      especialidade: "Psiquiatria"
    },
    condicao_medica: "Transtorno de Ansiedade"
  },
  {
    id: "aut003",
    numero_autorizacao: "25351.987654/2023-56",
    cliente: {
      id: "cli004",
      nome: "Roberto Almeida",
      email: "roberto.almeida@email.com"
    },
    data_emissao: "2023-07-05",
    data_validade: "2023-11-05",
    status: "expirada",
    produtos_autorizados: [
      {
        nome: "Extrato Full Spectrum",
        dosagem: "10ml",
        quantidade: "1 frasco",
        fabricante: "GreenLife"
      }
    ],
    medico: {
      nome: "Dr. Paulo Lima",
      crm: "CRM-PR 345678",
      especialidade: "Neurologia"
    },
    condicao_medica: "Dor neuropática crônica"
  },
  {
    id: "aut004",
    numero_autorizacao: "25351.456789/2023-78",
    cliente: {
      id: "cli005",
      nome: "Patricia Lima",
      email: "patricia.lima@email.com"
    },
    data_emissao: "2023-08-15",
    data_validade: "2024-08-15",
    status: "valida",
    produtos_autorizados: [
      {
        nome: "Óleo CBD 20%",
        dosagem: "30ml",
        quantidade: "3 frascos",
        fabricante: "MediCannabis"
      },
      {
        nome: "Cápsulas CBD 10mg",
        dosagem: "10mg",
        quantidade: "60 cápsulas",
        fabricante: "MediCannabis"
      }
    ],
    medico: {
      nome: "Dra. Ana Oliveira",
      crm: "CRM-RS 234567",
      especialidade: "Reumatologia"
    },
    condicao_medica: "Artrite reumatoide"
  }
];

export default function AutorizacoesAnvisa() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [filteredAutorizacoes, setFilteredAutorizacoes] = useState(autorizacoes);
  const [autorizacaoDetalhes, setAutorizacaoDetalhes] = useState(null);
  const [mostrarDetalhes, setMostrarDetalhes] = useState(false);
  const [mostrarRenovacao, setMostrarRenovacao] = useState(false);
  const [autorizacaoRenovar, setAutorizacaoRenovar] = useState(null);

  useEffect(() => {
    // Filtro das autorizações
    let filtered = autorizacoes;
    
    if (searchTerm.trim() !== "") {
      filtered = filtered.filter(autorizacao => 
        autorizacao.cliente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        autorizacao.numero_autorizacao.toLowerCase().includes(searchTerm.toLowerCase()) ||
        autorizacao.medico.nome.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (statusFilter !== "all") {
      filtered = filtered.filter(autorizacao => autorizacao.status === statusFilter);
    }
    
    setFilteredAutorizacoes(filtered);
  }, [searchTerm, statusFilter]);

  const verDetalhes = (autorizacao) => {
    setAutorizacaoDetalhes(autorizacao);
    setMostrarDetalhes(true);
  };

  const abrirRenovacao = (autorizacao) => {
    setAutorizacaoRenovar(autorizacao);
    setMostrarRenovacao(true);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "valida":
        return <Badge className="bg-green-100 text-green-800"><CheckCircle2 className="w-3 h-3 mr-1" />Válida</Badge>;
      case "em_renovacao":
        return <Badge className="bg-blue-100 text-blue-800"><RefreshCw className="w-3 h-3 mr-1" />Em renovação</Badge>;
      case "expirada":
        return <Badge className="bg-red-100 text-red-800"><AlertTriangle className="w-3 h-3 mr-1" />Expirada</Badge>;
      case "pendente":
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Pendente</Badge>;
      case "cancelada":
        return <Badge className="bg-gray-100 text-gray-800"><XCircle className="w-3 h-3 mr-1" />Cancelada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
  };

  // Verificar se uma autorização está próxima do vencimento (menos de 30 dias)
  const proximaDoVencimento = (dataValidade) => {
    const hoje = new Date();
    const validade = new Date(dataValidade);
    const diferencaDias = Math.ceil((validade - hoje) / (1000 * 60 * 60 * 24));
    return diferencaDias > 0 && diferencaDias <= 30;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Autorizações ANVISA</h1>
          <p className="text-gray-500 mt-1">
            Gerencie as autorizações da ANVISA para importação de produtos
          </p>
        </div>
        <Link to={createPageUrl("NovaAutorizacao")}>
          <Button className="gap-2">
            <FilePlus className="w-4 h-4" />
            Nova Autorização
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Autorizações Válidas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <div className="bg-green-100 p-3 rounded-full">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold">
                  {autorizacoes.filter(a => a.status === "valida").length}
                </p>
                <p className="text-sm text-gray-500">Total de autorizações ativas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Autorizações a Vencer</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <div className="bg-yellow-100 p-3 rounded-full">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold">
                  {autorizacoes.filter(a => a.status === "valida" && proximaDoVencimento(a.data_validade)).length}
                </p>
                <p className="text-sm text-gray-500">Vencem em menos de 30 dias</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Autorizações Expiradas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <div className="bg-red-100 p-3 rounded-full">
                <AlertTriangle className="w-6 h-6 text-red-600" />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold">
                  {autorizacoes.filter(a => a.status === "expirada").length}
                </p>
                <p className="text-sm text-gray-500">Precisam ser renovadas</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
        <div className="relative w-full md:w-72">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar autorizações..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex gap-2 items-center">
          <p className="text-sm text-gray-500 whitespace-nowrap">Status:</p>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Filtrar por status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="valida">Válidas</SelectItem>
              <SelectItem value="em_renovacao">Em renovação</SelectItem>
              <SelectItem value="expirada">Expiradas</SelectItem>
              <SelectItem value="pendente">Pendentes</SelectItem>
              <SelectItem value="cancelada">Canceladas</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Número da Autorização</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Data de Emissão</TableHead>
                <TableHead>Validade</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Produtos</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAutorizacoes.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    <div className="flex flex-col items-center justify-center text-gray-500">
                      <ShieldCheck className="w-12 h-12 text-gray-300 mb-3" />
                      <p className="text-lg font-medium">Nenhuma autorização encontrada</p>
                      <p className="text-sm">Tente ajustar os filtros ou cadastre uma nova autorização</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredAutorizacoes.map((autorizacao) => (
                  <TableRow key={autorizacao.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-primary" />
                        <span className="font-medium">{autorizacao.numero_autorizacao}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{autorizacao.cliente.nome}</div>
                      <div className="text-sm text-gray-500">{autorizacao.cliente.email}</div>
                    </TableCell>
                    <TableCell>{formatDate(autorizacao.data_emissao)}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span>{formatDate(autorizacao.data_validade)}</span>
                        {proximaDoVencimento(autorizacao.data_validade) && autorizacao.status === "valida" && (
                          <Badge variant="outline" className="mt-1 bg-yellow-50 text-yellow-600 border-yellow-200">
                            <Clock className="w-3 h-3 mr-1" />
                            Próxima do vencimento
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(autorizacao.status)}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-gray-50">
                        {autorizacao.produtos_autorizados.length} produto(s)
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Ações</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => verDetalhes(autorizacao)}>
                            <Eye className="w-4 h-4 mr-2" />
                            Ver detalhes
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Download className="w-4 h-4 mr-2" />
                            Baixar documento
                          </DropdownMenuItem>
                          {(autorizacao.status === "expirada" || proximaDoVencimento(autorizacao.data_validade)) && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => abrirRenovacao(autorizacao)}>
                                <RefreshCw className="w-4 h-4 mr-2" />
                                Iniciar renovação
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Modal de detalhes da autorização */}
      <Dialog open={mostrarDetalhes} onOpenChange={setMostrarDetalhes}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes da Autorização ANVISA</DialogTitle>
            <DialogDescription>
              Informações completas da autorização
            </DialogDescription>
          </DialogHeader>

          {autorizacaoDetalhes && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Informações da Autorização</h3>
                  <div className="space-y-2">
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500">Número:</span>
                      <span className="font-medium">{autorizacaoDetalhes.numero_autorizacao}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500">Data de Emissão:</span>
                      <span>{formatDate(autorizacaoDetalhes.data_emissao)}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500">Data de Validade:</span>
                      <span>{formatDate(autorizacaoDetalhes.data_validade)}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500">Status:</span>
                      <span>{getStatusBadge(autorizacaoDetalhes.status)}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Paciente</h3>
                  <div className="space-y-2">
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500">Nome:</span>
                      <span className="font-medium">{autorizacaoDetalhes.cliente.nome}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500">Email:</span>
                      <span>{autorizacaoDetalhes.cliente.email}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500">Condição Médica:</span>
                      <span>{autorizacaoDetalhes.condicao_medica}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-2">Médico Responsável</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex flex-col">
                    <span className="text-sm text-gray-500">Nome:</span>
                    <span className="font-medium">{autorizacaoDetalhes.medico.nome}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm text-gray-500">CRM:</span>
                    <span>{autorizacaoDetalhes.medico.crm}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm text-gray-500">Especialidade:</span>
                    <span>{autorizacaoDetalhes.medico.especialidade}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-2">Produtos Autorizados</h3>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Produto</TableHead>
                        <TableHead>Dosagem</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Fabricante</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {autorizacaoDetalhes.produtos_autorizados.map((produto, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{produto.nome}</TableCell>
                          <TableCell>{produto.dosagem}</TableCell>
                          <TableCell>{produto.quantidade}</TableCell>
                          <TableCell>{produto.fabricante}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              <div className="flex justify-between">
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Baixar Documento
                </Button>
                
                {(autorizacaoDetalhes.status === "expirada" || proximaDoVencimento(autorizacaoDetalhes.data_validade)) && (
                  <Button onClick={() => {
                    setMostrarDetalhes(false);
                    abrirRenovacao(autorizacaoDetalhes);
                  }}>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Iniciar Renovação
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Modal de renovação de autorização */}
      <Dialog open={mostrarRenovacao} onOpenChange={setMostrarRenovacao}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Renovar Autorização ANVISA</DialogTitle>
            <DialogDescription>
              Inicie o processo de renovação da autorização
            </DialogDescription>
          </DialogHeader>

          {autorizacaoRenovar && (
            <div className="space-y-4 py-2">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex items-start gap-3">
                  <div className="bg-blue-100 p-2 rounded-full">
                    <RefreshCw className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-blue-900">Renovação de autorização</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      Você está iniciando o processo de renovação para a autorização{" "}
                      <span className="font-medium">{autorizacaoRenovar.numero_autorizacao}</span> de{" "}
                      <span className="font-medium">{autorizacaoRenovar.cliente.nome}</span>.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Detalhes da autorização atual</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-500">Data de emissão:</span>
                    <p>{formatDate(autorizacaoRenovar.data_emissao)}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Data de validade:</span>
                    <p>{formatDate(autorizacaoRenovar.data_validade)}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Status:</span>
                    <p>{getStatusBadge(autorizacaoRenovar.status)}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Produtos:</span>
                    <p>{autorizacaoRenovar.produtos_autorizados.length} produto(s)</p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Próximos passos</h4>
                <div className="space-y-2">
                  <div className="flex gap-2 items-start">
                    <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-xs mt-0.5">1</div>
                    <p className="text-sm">Solicitar ao paciente a prescrição médica atualizada.</p>
                  </div>
                  <div className="flex gap-2 items-start">
                    <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-xs mt-0.5">2</div>
                    <p className="text-sm">Preencher o formulário de solicitação de renovação no portal da ANVISA.</p>
                  </div>
                  <div className="flex gap-2 items-start">
                    <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-xs mt-0.5">3</div>
                    <p className="text-sm">Anexar os documentos necessários (prescrição, laudo médico, etc).</p>
                  </div>
                  <div className="flex gap-2 items-start">
                    <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-xs mt-0.5">4</div>
                    <p className="text-sm">Submeter a solicitação e aguardar aprovação.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setMostrarRenovacao(false)}>
              Cancelar
            </Button>
            <Button onClick={() => {
              // Simular mudança de status - em uma implementação real, isso iniciaria o fluxo de renovação
              const updatedAutorizacoes = autorizacoes.map(a => {
                if (a.id === autorizacaoRenovar?.id) {
                  return { ...a, status: "em_renovacao" };
                }
                return a;
              });
              // Atualizar os estados
              setFilteredAutorizacoes(updatedAutorizacoes.filter(a => {
                if (statusFilter === "all") return true;
                return a.status === statusFilter;
              }));
              setMostrarRenovacao(false);
            }}>
              Iniciar Processo de Renovação
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}