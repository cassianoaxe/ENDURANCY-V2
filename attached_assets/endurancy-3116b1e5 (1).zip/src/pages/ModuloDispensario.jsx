
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { ModuloDispensario } from '@/api/entities';
import { toast } from '@/components/ui/use-toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  ShoppingBag,
  Package,
  FileText,
  CheckCircle2,
  Clock,
  CreditCard,
  CheckSquare,
  ArrowRight,
} from 'lucide-react';
import { format, addDays } from 'date-fns';
import OnboardingTutorial from '@/components/dispensario/OnboardingTutorial';

export default function ModuloDispensarioPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [module, setModule] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const currentUser = await User.me();
        setUser(currentUser);
        
        const modules = await ModuloDispensario.filter({ organization_id: currentUser.organization_id });
        
        if (modules && modules.length > 0) {
          setModule(modules[0]);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          title: 'Erro',
          description: 'Falha ao carregar dados. Por favor, tente novamente.',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);

  useEffect(() => {
    if (module?.is_active && !localStorage.getItem('dispensarioOnboardingComplete')) {
      setShowOnboarding(true);
    }
  }, [module]);

  const activateModule = async () => {
    try {
      setIsLoading(true);
      
      if (module) {
        await ModuloDispensario.update(module.id, {
          is_active: true,
          status: 'trial',
          subscription_start: new Date().toISOString(),
          subscription_end: addDays(new Date(), 15).toISOString()
        });
        
        setModule({
          ...module,
          is_active: true,
          status: 'trial',
          subscription_start: new Date().toISOString(),
          subscription_end: addDays(new Date(), 15).toISOString()
        });
      } else {
        const newModule = await ModuloDispensario.create({
          organization_id: user.organization_id,
          is_active: true,
          status: 'trial',
          subscription_start: new Date().toISOString(),
          subscription_end: addDays(new Date(), 15).toISOString(),
          pdv_settings: {
            nome_estabelecimento: 'Meu Dispensário',
            cnpj_impressao: '',
            endereco_impressao: '',
            observacoes_cupom: 'Obrigado pela preferência!'
          }
        });
        
        setModule(newModule);
      }
      
      toast({
        title: 'Sucesso!',
        description: 'Módulo Dispensário ativado com sucesso. Aproveite seu período de teste!',
      });
      
      setIsDialogOpen(false);
      
      setTimeout(() => {
        navigate(createPageUrl('DispensarioDashboard'));
      }, 1000);
      
    } catch (error) {
      console.error('Error activating module:', error);
      toast({
        title: 'Erro',
        description: 'Falha ao ativar o módulo. Por favor, tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleOnboardingComplete = () => {
    localStorage.setItem('dispensarioOnboardingComplete', 'true');
    setShowOnboarding(false);
  };

  const renderModuleStatus = () => {
    if (!module || !module.is_active) {
      return (
        <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-lg font-semibold text-gray-800">Módulo Dispensário não ativado</h2>
              <p className="text-gray-600 mt-1">
                Ative o módulo para transformar sua organização em um dispensário completo.
              </p>
            </div>
            <Button
              className="mt-4 lg:mt-0 bg-green-600 hover:bg-green-700"
              onClick={() => setIsDialogOpen(true)}
            >
              <ShoppingBag className="mr-2 h-4 w-4" />
              Ativar Módulo
            </Button>
          </div>
        </div>
      );
    }
    
    const isExpired = new Date(module.subscription_end) < new Date();
    
    return (
      <div className={`p-6 rounded-lg border mb-6 ${isExpired ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'}`}>
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="flex items-center">
              <h2 className="text-lg font-semibold text-gray-800">Módulo Dispensário</h2>
              <Badge className={isExpired ? 'ml-2 bg-red-500' : 'ml-2 bg-green-500'}>
                {isExpired ? 'Expirado' : module.status === 'trial' ? 'Teste' : 'Ativo'}
              </Badge>
            </div>
            <p className={`mt-1 ${isExpired ? 'text-red-600' : 'text-green-600'}`}>
              {isExpired 
                ? 'Sua assinatura expirou. Renove para continuar usando o módulo.' 
                : module.status === 'trial'
                  ? `Período de teste ativo até ${format(new Date(module.subscription_end), 'dd/MM/yyyy')}`
                  : `Assinatura ativa até ${format(new Date(module.subscription_end), 'dd/MM/yyyy')}`
              }
            </p>
          </div>
          {isExpired ? (
            <Button className="mt-4 lg:mt-0" onClick={() => setIsDialogOpen(true)}>
              <CreditCard className="mr-2 h-4 w-4" />
              Renovar Assinatura
            </Button>
          ) : (
            <Button className="mt-4 lg:mt-0" onClick={() => navigate(createPageUrl('DispensarioDashboard'))}>
              <ArrowRight className="mr-2 h-4 w-4" />
              Acessar Dispensário
            </Button>
          )}
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="flex flex-col items-center gap-2">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-green-200 border-t-green-600"></div>
          <p className="text-sm text-gray-500">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="container mx-auto py-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Módulo Dispensário</h1>
          <p className="text-gray-500 mt-1">
            Transforme sua organização em um dispensário completo com PDV, gestão de estoque e mais.
          </p>
        </div>
        
        {renderModuleStatus()}
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-xl">PDV</CardTitle>
                <ShoppingBag className="h-6 w-6 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Realize vendas no balcão com nosso sistema de PDV intuitivo.
                Emita cupons fiscais, controle seu caixa e gerencie devoluções.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-xl">Estoque</CardTitle>
                <Package className="h-6 w-6 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Controle completo de estoque com rastreamento de lotes, validades,
                movimentações, perdas e relatórios detalhados.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-xl">Receituário</CardTitle>
                <FileText className="h-6 w-6 text-purple-600" />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Gestão de receituários para medicamentos controlados,
                integração com SNGPC da ANVISA e validação de prescrições.
              </p>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="features" className="mb-10">
          <TabsList className="mb-6">
            <TabsTrigger value="features">Recursos</TabsTrigger>
            <TabsTrigger value="pricing">Preços</TabsTrigger>
            <TabsTrigger value="faq">Perguntas Frequentes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="features">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white shadow rounded-lg p-6">
                <div className="flex mb-4">
                  <CheckCircle2 className="h-6 w-6 text-green-500 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-lg text-gray-800">PDV Completo</h3>
                    <p className="text-gray-600">
                      Interface de vendas intuitiva, modo tela cheia, leitor de 
                      código de barras e impressão de cupom fiscal.
                    </p>
                  </div>
                </div>
                <div className="flex mb-4">
                  <CheckCircle2 className="h-6 w-6 text-green-500 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-lg text-gray-800">Controle de Caixa</h3>
                    <p className="text-gray-600">
                      Abertura e fechamento de caixa, sangrias, suprimentos e 
                      relatórios detalhados das operações.
                    </p>
                  </div>
                </div>
                <div className="flex">
                  <CheckCircle2 className="h-6 w-6 text-green-500 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-lg text-gray-800">Multi-pagamentos</h3>
                    <p className="text-gray-600">
                      Aceite pagamentos em dinheiro, cartão, PIX e mantenha 
                      o controle financeiro completo.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white shadow rounded-lg p-6">
                <div className="flex mb-4">
                  <CheckCircle2 className="h-6 w-6 text-green-500 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-lg text-gray-800">Gestão de Estoque</h3>
                    <p className="text-gray-600">
                      Controle de lotes, rastreabilidade, alertas de validade e 
                      estoque mínimo, inventário e balanços.
                    </p>
                  </div>
                </div>
                <div className="flex mb-4">
                  <CheckCircle2 className="h-6 w-6 text-green-500 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-lg text-gray-800">Receituário Digital</h3>
                    <p className="text-gray-600">
                      Gestão completa de receitas, validação e integração com 
                      o SNGPC da ANVISA.
                    </p>
                  </div>
                </div>
                <div className="flex">
                  <CheckCircle2 className="h-6 w-6 text-green-500 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-lg text-gray-800">Integração Total</h3>
                    <p className="text-gray-600">
                      Funciona integrado com módulos de produção, cadastro de pacientes
                      e prescrições médicas.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="pricing">
            <Card>
              <CardHeader>
                <CardTitle>Plano Dispensário</CardTitle>
                <CardDescription>
                  Transforme sua organização em um dispensário completo por uma mensalidade acessível.
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="flex flex-col lg:flex-row gap-6">
                  <div className="bg-white shadow-lg rounded-xl p-6 border border-green-100 flex-1">
                    <Badge className="bg-green-500 mb-4">Mais Popular</Badge>
                    <h2 className="text-2xl font-bold mb-2">Plano Mensal</h2>
                    <div className="flex items-end mb-6">
                      <span className="text-4xl font-bold">R$ 299</span>
                      <span className="text-gray-500 ml-1">/mês</span>
                    </div>
                    
                    <ul className="space-y-3 mb-8">
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Acesso completo ao PDV</span>
                      </li>
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Gestão de estoque e lotes</span>
                      </li>
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Receituário digital completo</span>
                      </li>
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Integração com SNGPC</span>
                      </li>
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Relatórios gerenciais</span>
                      </li>
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Suporte dedicado</span>
                      </li>
                    </ul>
                    
                    <Button className="w-full bg-green-600 hover:bg-green-700" onClick={() => setIsDialogOpen(true)}>
                      Ativar Agora
                    </Button>
                  </div>
                  
                  <div className="bg-white shadow-lg rounded-xl p-6 border border-blue-100 flex-1">
                    <Badge className="bg-blue-500 mb-4">Economia</Badge>
                    <h2 className="text-2xl font-bold mb-2">Plano Anual</h2>
                    <div className="flex items-end mb-6">
                      <span className="text-4xl font-bold">R$ 3.289</span>
                      <span className="text-gray-500 ml-1">/ano</span>
                    </div>
                    
                    <ul className="space-y-3 mb-8">
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Todos os recursos do plano mensal</span>
                      </li>
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Economia de 2 meses grátis</span>
                      </li>
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Prioridade no suporte</span>
                      </li>
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Acesso antecipado a novos recursos</span>
                      </li>
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Treinamento da equipe incluído</span>
                      </li>
                      <li className="flex items-start">
                        <CheckSquare className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span>Sem preocupação com renovações mensais</span>
                      </li>
                    </ul>
                    
                    <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={() => setIsDialogOpen(true)}>
                      Economize com Plano Anual
                    </Button>
                  </div>
                </div>
                
                <div className="mt-8 bg-gray-50 p-6 rounded-lg">
                  <h3 className="font-semibold text-gray-800 mb-2">Teste Grátis</h3>
                  <p className="text-gray-600">
                    Experimente o módulo Dispensário por 15 dias sem compromisso. 
                    Acesso completo a todos os recursos para você avaliar antes de assinar.
                  </p>
                  <Button className="mt-4" variant="outline" onClick={() => setIsDialogOpen(true)}>
                    <Clock className="mr-2 h-4 w-4" />
                    Iniciar Período de Teste
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="faq">
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-lg font-semibold mb-2">O que é o módulo Dispensário?</h3>
                <p className="text-gray-600">
                  O módulo Dispensário é uma solução completa que permite à sua organização
                  operar como um dispensário ou farmácia, com PDV para vendas no balcão,
                  gestão de estoque, controle de receituário e integração com o SNGPC da ANVISA.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-lg font-semibold mb-2">Posso emitir cupom fiscal?</h3>
                <p className="text-gray-600">
                  Sim, o módulo permite a emissão de cupons fiscais e notas fiscais
                  de acordo com a legislação vigente. É necessário configurar os dados fiscais
                  da sua organização nas configurações do módulo.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-lg font-semibold mb-2">Como funciona a integração com o SNGPC?</h3>
                <p className="text-gray-600">
                  O módulo registra automaticamente todas as dispensações de medicamentos controlados
                  e gera os arquivos XML no formato exigido pela ANVISA. Você pode revisar os dados
                  e realizar o envio diretamente pela plataforma.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-lg font-semibold mb-2">É possível ter múltiplos PDVs?</h3>
                <p className="text-gray-600">
                  Sim, o módulo suporta múltiplos pontos de venda operando simultaneamente,
                  com controle individual de caixa e operadores, mas mantendo o estoque centralizado.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-lg font-semibold mb-2">O módulo funciona em tablets ou dispositivos móveis?</h3>
                <p className="text-gray-600">
                  Sim, a interface do PDV é totalmente responsiva e pode ser utilizada em tablets
                  e outros dispositivos móveis, facilitando a mobilidade no atendimento.
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Ativar Módulo Dispensário</DialogTitle>
              <DialogDescription>
                Você está prestes a ativar o módulo Dispensário em sua organização.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-700 mb-2">Período de Avaliação</h4>
                <p className="text-sm text-blue-600">
                  Você terá acesso gratuito por 15 dias a todos os recursos do módulo Dispensário.
                  Após esse período, será necessário assinar um dos planos disponíveis para continuar utilizando.
                </p>
              </div>
              
              <div className="border-t border-b border-gray-200 py-4">
                <h4 className="font-medium mb-2">O que está incluso:</h4>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>PDV completo para dispensação</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>Gestão de estoque e controle de lotes</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>Receituário digital e integração SNGPC</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span>Relatórios e controles gerenciais</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button 
                onClick={activateModule} 
                disabled={isLoading}
                className="bg-green-600 hover:bg-green-700"
              >
                {isLoading ? 'Ativando...' : 'Ativar Agora'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <OnboardingTutorial 
          isOpen={showOnboarding}
          onClose={() => setShowOnboarding(false)}
          onComplete={handleOnboardingComplete}
        />
      </div>
    </>
  );
}
