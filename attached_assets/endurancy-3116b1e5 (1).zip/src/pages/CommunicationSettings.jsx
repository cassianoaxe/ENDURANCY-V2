import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { 
  Settings,
  Trash2,
  Save,
  Clock,
  Bell,
  Database
} from 'lucide-react';

export default function CommunicationSettings() {
  const [settings, setSettings] = useState({
    retentionPeriod: 30,
    autoDeleteOld: true,
    notifyNewMessages: true,
    notifyMentions: true,
    notifyTaskAssignments: true,
    soundEnabled: true,
    compressAttachments: true,
    maxAttachmentSize: 10,
  });

  const handleSave = async () => {
    try {
      // Save settings logic here
      console.log('Settings saved:', settings);
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Configurações de Comunicação</h1>
          <p className="text-gray-500">Gerencie as configurações de mensagens e notificações</p>
        </div>
        <Button onClick={handleSave}>
          <Save className="w-4 h-4 mr-2" />
          Salvar Alterações
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Retenção de Dados
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Período de Retenção (dias)</Label>
              <Input 
                type="number" 
                value={settings.retentionPeriod}
                onChange={(e) => setSettings({...settings, retentionPeriod: parseInt(e.target.value)})}
              />
              <p className="text-sm text-gray-500">
                Mensagens mais antigas que este período serão automaticamente excluídas
              </p>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label>Exclusão Automática</Label>
                <p className="text-sm text-gray-500">
                  Excluir automaticamente mensagens antigas
                </p>
              </div>
              <Switch 
                checked={settings.autoDeleteOld}
                onCheckedChange={(checked) => setSettings({...settings, autoDeleteOld: checked})}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Notificações
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Novas Mensagens</Label>
                <p className="text-sm text-gray-500">
                  Notificar sobre novas mensagens
                </p>
              </div>
              <Switch 
                checked={settings.notifyNewMessages}
                onCheckedChange={(checked) => setSettings({...settings, notifyNewMessages: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label>Menções</Label>
                <p className="text-sm text-gray-500">
                  Notificar quando for mencionado
                </p>
              </div>
              <Switch 
                checked={settings.notifyMentions}
                onCheckedChange={(checked) => setSettings({...settings, notifyMentions: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label>Atribuições de Tarefas</Label>
                <p className="text-sm text-gray-500">
                  Notificar sobre novas atribuições de tarefas
                </p>
              </div>
              <Switch 
                checked={settings.notifyTaskAssignments}
                onCheckedChange={(checked) => setSettings({...settings, notifyTaskAssignments: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label>Sons</Label>
                <p className="text-sm text-gray-500">
                  Ativar sons de notificação
                </p>
              </div>
              <Switch 
                checked={settings.soundEnabled}
                onCheckedChange={(checked) => setSettings({...settings, soundEnabled: checked})}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Configurações de Arquivos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Compressão de Anexos</Label>
                <p className="text-sm text-gray-500">
                  Comprimir arquivos anexados automaticamente
                </p>
              </div>
              <Switch 
                checked={settings.compressAttachments}
                onCheckedChange={(checked) => setSettings({...settings, compressAttachments: checked})}
              />
            </div>

            <div className="space-y-2">
              <Label>Tamanho Máximo de Anexo (MB)</Label>
              <Input 
                type="number" 
                value={settings.maxAttachmentSize}
                onChange={(e) => setSettings({...settings, maxAttachmentSize: parseInt(e.target.value)})}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}