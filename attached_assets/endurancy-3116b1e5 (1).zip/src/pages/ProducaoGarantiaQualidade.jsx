import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  FileText, 
  CheckCircle2, 
  Plus, 
  Filter, 
  Clock,
  AlertTriangle,
  Search,
  Eye,
  CheckCircle,
  XCircle,
  FileCheck
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ProducaoGarantiaQualidade() {
  const [activeTab, setActiveTab] = useState("liberacao");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isLoading, setIsLoading] = useState(true);
  const [liberacoes, setLiberacoes] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    setTimeout(() => {
      setLiberacoes(mockLiberacoes);
      setIsLoading(false);
    }, 800);
  };

  const filteredLiberacoes = liberacoes.filter(lib => {
    const matchesSearch = 
      lib.codigo.toLowerCase().includes(searchTerm.toLowerCase()) || 
      lib.produto.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lib.lote.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || lib.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case "pendente":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case "em_analise":
        return <Badge className="bg-blue-100 text-blue-800">Em Análise</Badge>;
      case "aprovado":
        return <Badge className="bg-green-100 text-green-800">Aprovado</Badge>;
      case "liberado":
        return <Badge className="bg-indigo-100 text-indigo-800">Liberado</Badge>;
      case "rejeitado":
        return <Badge className="bg-red-100 text-red-800">Rejeitado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Garantia da Qualidade</h1>
          <p className="text-muted-foreground">
            Gerenciamento da garantia da qualidade e liberação de lotes de produção
          </p>
        </div>
        <Link to={createPageUrl("ProducaoGarantiaLiberacao")}>
          <Button className="bg-green-600 hover:bg-green-700">
            <Plus className="w-4 h-4 mr-2" />
            Nova Liberação
          </Button>
        </Link>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="liberacao">Liberação de Lotes</TabsTrigger>
          <TabsTrigger value="desvios">Desvios de Qualidade</TabsTrigger>
          <TabsTrigger value="certificados">Certificados de Análise</TabsTrigger>
        </TabsList>

        <TabsContent value="liberacao" className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar por código, lote ou produto..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Status</SelectItem>
                <SelectItem value="pendente">Pendente</SelectItem>
                <SelectItem value="em_analise">Em Análise</SelectItem>
                <SelectItem value="aprovado">Aprovado</SelectItem>
                <SelectItem value="liberado">Liberado</SelectItem>
                <SelectItem value="rejeitado">Rejeitado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Código</TableHead>
                <TableHead>Lote</TableHead>
                <TableHead>Produto</TableHead>
                <TableHead>Data Solicitação</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center">
                    Carregando...
                  </TableCell>
                </TableRow>
              ) : filteredLiberacoes.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center">
                    Nenhuma liberação encontrada
                  </TableCell>
                </TableRow>
              ) : (
                filteredLiberacoes.map((lib) => (
                  <TableRow key={lib.id}>
                    <TableCell>{lib.codigo}</TableCell>
                    <TableCell>{lib.lote}</TableCell>
                    <TableCell>{lib.produto}</TableCell>
                    <TableCell>{lib.data_solicitacao}</TableCell>
                    <TableCell>{getStatusBadge(lib.status)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        {lib.status === 'pendente' && (
                          <Button variant="ghost" size="sm" className="text-green-600">
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TabsContent>

        <TabsContent value="desvios">
          <Card>
            <CardHeader>
              <CardTitle>Desvios de Qualidade</CardTitle>
              <CardDescription>
                Gerenciamento de desvios de qualidade identificados durante o processo produtivo
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to={createPageUrl("ProducaoDesviosQualidade")}>
                <Button>Ver Desvios de Qualidade</Button>
              </Link>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="certificados">
          <Card>
            <CardHeader>
              <CardTitle>Certificados de Análise</CardTitle>
              <CardDescription>
                Gerenciamento de certificados de análise emitidos para produtos acabados
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to={createPageUrl("ProducaoCertificados")}>
                <Button>Ver Certificados</Button>
              </Link>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

const mockLiberacoes = [
  {
    id: "1",
    codigo: "LIB-2023-001",
    lote: "LOTE-2023-045",
    produto: "Óleo CBD 10%",
    data_solicitacao: "15/07/2023",
    status: "liberado"
  },
  {
    id: "2",
    codigo: "LIB-2023-002",
    lote: "LOTE-2023-046",
    produto: "Óleo CBD 5%",
    data_solicitacao: "18/07/2023",
    status: "pendente"
  },
  {
    id: "3",
    codigo: "LIB-2023-003",
    lote: "LOTE-2023-047",
    produto: "Cápsulas CBD",
    data_solicitacao: "20/07/2023",
    status: "em_analise"
  }
];