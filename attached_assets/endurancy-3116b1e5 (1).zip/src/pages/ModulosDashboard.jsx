import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Leaf, Factory, Heart, Briefcase, Scale, 
  Glasses, ShoppingBag, Database, Settings 
} from 'lucide-react';

export default function ModulosDashboard() {
  const navigate = useNavigate();
  
  const modules = [
    {
      title: "Módulo Cultivo",
      description: "Gerenciamento completo do cultivo de plantas medicinais",
      icon: Leaf,
      color: "bg-green-100 text-green-800",
      route: "ModuloCultivo"
    },
    {
      title: "Módulo Produção",
      description: "Controle de produção e garantia de qualidade",
      icon: Factory,
      color: "bg-blue-100 text-blue-800",
      route: "ModuloProducao"
    },
    {
      title: "Módulo CRM",
      description: "Gestão de relacionamento com pacientes",
      icon: Heart,
      color: "bg-red-100 text-red-800",
      route: "ModuloCRM"
    },
    {
      title: "Módulo RH",
      description: "Administração de recursos humanos",
      icon: Briefcase,
      color: "bg-purple-100 text-purple-800",
      route: "ModuloRH"
    },
    {
      title: "Módulo Jurídico",
      description: "Controle de processos jurídicos e compliance",
      icon: Scale,
      color: "bg-indigo-100 text-indigo-800",
      route: "ModuloJuridico"
    },
    {
      title: "Módulo Transparência",
      description: "Portal de transparência para associações",
      icon: Glasses,
      color: "bg-amber-100 text-amber-800",
      route: "TransparencySettings"
    },
    {
      title: "Módulo Dispensário",
      description: "PDV completo com controle SNGPC para farmácias",
      icon: ShoppingBag,
      color: "bg-green-100 text-green-800",
      route: "AdminModuloDispensario",
      featured: true
    }
  ];

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Módulos da Plataforma</h1>
          <p className="text-gray-500">Gerencie e configure os módulos da plataforma Endurancy</p>
        </div>
        <Button 
          variant="outline" 
          onClick={() => navigate(createPageUrl("ModuleManagement"))}
        >
          <Settings className="mr-2 h-4 w-4" />
          Configurações Avançadas
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {modules.map((module) => (
          <Card 
            key={module.title} 
            className={`overflow-hidden ${module.featured ? 'border-green-200 bg-green-50/40' : ''}`}
          >
            {module.featured && (
              <div className="bg-green-600 text-white text-xs font-medium px-3 py-1 text-center">
                NOVO MÓDULO
              </div>
            )}
            <CardHeader className="pb-2">
              <div className="flex items-center space-x-4">
                <div className={`w-10 h-10 rounded-full ${module.color} flex items-center justify-center`}>
                  <module.icon className="w-5 h-5" />
                </div>
                <div>
                  <CardTitle>{module.title}</CardTitle>
                  <CardDescription>{module.description}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pb-2">
              <ul className="space-y-1 text-sm">
                <li className="flex items-center">
                  <span className="mr-2">•</span>
                  <span>Controle completo</span>
                </li>
                <li className="flex items-center">
                  <span className="mr-2">•</span>
                  <span>Estatísticas e relatórios</span>
                </li>
                <li className="flex items-center">
                  <span className="mr-2">•</span>
                  <span>Integração com outros módulos</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={() => navigate(createPageUrl(module.route))}
                className={`w-full ${module.featured ? 'bg-green-600 hover:bg-green-700' : ''}`}
              >
                Gerenciar Módulo
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}