
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Truck, 
  ArrowLeft, 
  Save, 
  MapPin, 
  Building2, 
  Phone, 
  Mail, 
  User, 
  Briefcase,
  ChevronRight,
  FileCheck,
  CreditCard,
  Star
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/components/ui/use-toast";
import ValidacaoFornecedor from '../components/fornecedores/ValidacaoFornecedor';

export default function ProducaoNovoFornecedor() {
  const navigate = useNavigate();
  
  const [currentTab, setCurrentTab] = useState("informacoes");
  const [showValidacaoDialog, setShowValidacaoDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [fornecedor, setFornecedor] = useState({
    nome: "",
    tipo: "distribuidor",
    cnpj: "",
    razao_social: "",
    site: "",
    endereco: {
      cep: "",
      logradouro: "",
      numero: "",
      complemento: "",
      bairro: "",
      cidade: "",
      estado: "",
      pais: "Brasil"
    },
    contatos: [
      { nome: "", cargo: "", email: "", telefone: "", principal: true }
    ],
    financeiro: {
      banco: "",
      agencia: "",
      conta: "",
      pix: "",
      condicoes_pagamento: "",
      prazo_pagamento: 30
    },
    categorias: [],
    certificacoes: [],
    status: "pendente"
  });
  
  const categoriaOptions = [
    "Extrato CBD", "Terpenos", "Insumos Farmacêuticos", "Óleo de Cânhamo", 
    "Óleo Base", "Excipientes", "Material de Embalagem", "Embalagens de Vidro", 
    "Conta-gotas", "Tampas", "Rótulos", "Etiquetas", "Material Gráfico",
    "Extratos Naturais", "Transporte Farmacêutico", "Transporte Refrigerado"
  ];
  
  const certificacaoOptions = [
    "ISO 9001", "ISO 14001", "GMP", "Anvisa", "FSSC 22000", "ISO 45001"
  ];
  
  const handleInputChange = (field, value) => {
    setFornecedor(prev => ({ ...prev, [field]: value }));
  };
  
  const handleEnderecoChange = (field, value) => {
    setFornecedor(prev => ({
      ...prev,
      endereco: {
        ...prev.endereco,
        [field]: value
      }
    }));
  };
  
  const handleFinanceiroChange = (field, value) => {
    setFornecedor(prev => ({
      ...prev,
      financeiro: {
        ...prev.financeiro,
        [field]: value
      }
    }));
  };
  
  const handleContatoChange = (index, field, value) => {
    const newContatos = [...fornecedor.contatos];
    newContatos[index] = { ...newContatos[index], [field]: value };
    setFornecedor(prev => ({ ...prev, contatos: newContatos }));
  };
  
  const handleAddContato = () => {
    setFornecedor(prev => ({
      ...prev,
      contatos: [...prev.contatos, { nome: "", cargo: "", email: "", telefone: "", principal: false }]
    }));
  };
  
  const handleRemoveContato = (index) => {
    const newContatos = [...fornecedor.contatos];
    newContatos.splice(index, 1);
    setFornecedor(prev => ({ ...prev, contatos: newContatos }));
  };
  
  const handleSetContatoPrincipal = (index) => {
    const newContatos = fornecedor.contatos.map((contato, i) => ({
      ...contato,
      principal: i === index
    }));
    setFornecedor(prev => ({ ...prev, contatos: newContatos }));
  };
  
  const handleCategoriaToggle = (categoria) => {
    const categorias = [...fornecedor.categorias];
    if (categorias.includes(categoria)) {
      setFornecedor(prev => ({
        ...prev,
        categorias: categorias.filter(c => c !== categoria)
      }));
    } else {
      setFornecedor(prev => ({
        ...prev,
        categorias: [...categorias, categoria]
      }));
    }
  };
  
  const handleCertificacaoToggle = (certificacao) => {
    const certificacoes = [...fornecedor.certificacoes];
    if (certificacoes.includes(certificacao)) {
      setFornecedor(prev => ({
        ...prev,
        certificacoes: certificacoes.filter(c => c !== certificacao)
      }));
    } else {
      setFornecedor(prev => ({
        ...prev,
        certificacoes: [...certificacoes, certificacao]
      }));
    }
  };
  
  const handleSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    
    try {
      setTimeout(() => {
        toast({
          title: "Fornecedor cadastrado",
          description: "O fornecedor foi cadastrado com sucesso.",
        });
        navigate(createPageUrl("ProducaoFornecedores"));
        setIsLoading(false);
      }, 1500);
      
    } catch (error) {
      console.error("Erro ao cadastrar fornecedor:", error);
      toast({
        title: "Erro ao cadastrar",
        description: "Ocorreu um erro ao cadastrar o fornecedor. Tente novamente.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };
  
  const handleSaveValidacao = (validatedFornecedor) => {
    setFornecedor(validatedFornecedor);
    setShowValidacaoDialog(false);
    
    toast({
      title: "Validação concluída",
      description: `Fornecedor ${validatedFornecedor.status === 'ativo' ? 'aprovado' : validatedFornecedor.status === 'inativo' ? 'reprovado' : 'em análise'}.`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to={createPageUrl("ProducaoFornecedores")} className="text-gray-500 hover:text-gray-900">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-2xl font-bold">Novo Fornecedor</h1>
        </div>
        
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => setShowValidacaoDialog(true)}>
            <FileCheck className="h-4 w-4 mr-2" />
            Iniciar Validação
          </Button>
          <Button onClick={handleSubmit} disabled={isLoading}>
            <Save className="h-4 w-4 mr-2" />
            Salvar Fornecedor
          </Button>
        </div>
      </div>
      
      <Card>
        <CardContent className="p-6">
          <Tabs value={currentTab} onValueChange={setCurrentTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="informacoes">Informações Básicas</TabsTrigger>
              <TabsTrigger value="endereco">Endereço</TabsTrigger>
              <TabsTrigger value="contatos">Contatos</TabsTrigger>
              <TabsTrigger value="categorias">Categorias</TabsTrigger>
              <TabsTrigger value="financeiro">Financeiro</TabsTrigger>
            </TabsList>
            
            <TabsContent value="informacoes" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome Fantasia</Label>
                  <Input 
                    id="nome" 
                    placeholder="Nome comercial do fornecedor"
                    value={fornecedor.nome}
                    onChange={(e) => handleInputChange('nome', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="razao_social">Razão Social</Label>
                  <Input 
                    id="razao_social" 
                    placeholder="Razão social completa"
                    value={fornecedor.razao_social}
                    onChange={(e) => handleInputChange('razao_social', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cnpj">CNPJ</Label>
                  <Input 
                    id="cnpj" 
                    placeholder="00.000.000/0000-00"
                    value={fornecedor.cnpj}
                    onChange={(e) => handleInputChange('cnpj', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="site">Site</Label>
                  <Input 
                    id="site" 
                    placeholder="www.fornecedor.com.br"
                    value={fornecedor.site}
                    onChange={(e) => handleInputChange('site', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tipo">Tipo de Fornecedor</Label>
                  <Select 
                    value={fornecedor.tipo} 
                    onValueChange={(value) => handleInputChange('tipo', value)}
                  >
                    <SelectTrigger id="tipo">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fabricante">Fabricante</SelectItem>
                      <SelectItem value="distribuidor">Distribuidor</SelectItem>
                      <SelectItem value="transporte">Transportadora</SelectItem>
                      <SelectItem value="prestador_servico">Prestador de Serviço</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    value={fornecedor.status} 
                    onValueChange={(value) => handleInputChange('status', value)}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                      <SelectItem value="pendente">Pendente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea 
                  id="observacoes" 
                  placeholder="Observações gerais sobre o fornecedor..."
                  value={fornecedor.observacoes || ""}
                  onChange={(e) => handleInputChange('observacoes', e.target.value)}
                />
              </div>
            </TabsContent>
            
            <TabsContent value="endereco" className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="cep">CEP</Label>
                  <Input 
                    id="cep" 
                    placeholder="00000-000"
                    value={fornecedor.endereco.cep}
                    onChange={(e) => handleEnderecoChange('cep', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="logradouro">Logradouro</Label>
                  <Input 
                    id="logradouro" 
                    placeholder="Rua, Avenida, etc."
                    value={fornecedor.endereco.logradouro}
                    onChange={(e) => handleEnderecoChange('logradouro', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="numero">Número</Label>
                  <Input 
                    id="numero" 
                    placeholder="123"
                    value={fornecedor.endereco.numero}
                    onChange={(e) => handleEnderecoChange('numero', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="complemento">Complemento</Label>
                  <Input 
                    id="complemento" 
                    placeholder="Sala, Andar, etc."
                    value={fornecedor.endereco.complemento}
                    onChange={(e) => handleEnderecoChange('complemento', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="bairro">Bairro</Label>
                  <Input 
                    id="bairro" 
                    placeholder="Nome do bairro"
                    value={fornecedor.endereco.bairro}
                    onChange={(e) => handleEnderecoChange('bairro', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cidade">Cidade</Label>
                  <Input 
                    id="cidade" 
                    placeholder="Nome da cidade"
                    value={fornecedor.endereco.cidade}
                    onChange={(e) => handleEnderecoChange('cidade', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="estado">Estado</Label>
                  <Select 
                    value={fornecedor.endereco.estado} 
                    onValueChange={(value) => handleEnderecoChange('estado', value)}
                  >
                    <SelectTrigger id="estado">
                      <SelectValue placeholder="UF" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="AC">AC</SelectItem>
                      <SelectItem value="AL">AL</SelectItem>
                      <SelectItem value="AP">AP</SelectItem>
                      <SelectItem value="AM">AM</SelectItem>
                      <SelectItem value="BA">BA</SelectItem>;
                      <SelectItem value="CE">CE</SelectItem>
                      <SelectItem value="DF">DF</SelectItem>
                      <SelectItem value="ES">ES</SelectItem>
                      <SelectItem value="GO">GO</SelectItem>
                      <SelectItem value="MA">MA</SelectItem>
                      <SelectItem value="MT">MT</SelectItem>
                      <SelectItem value="MS">MS</SelectItem>
                      <SelectItem value="MG">MG</SelectItem>
                      <SelectItem value="PA">PA</SelectItem>
                      <SelectItem value="PB">PB</SelectItem>
                      <SelectItem value="PR">PR</SelectItem>
                      <SelectItem value="PE">PE</SelectItem>
                      <SelectItem value="PI">PI</SelectItem>
                      <SelectItem value="RJ">RJ</SelectItem>
                      <SelectItem value="RN">RN</SelectItem>
                      <SelectItem value="RS">RS</SelectItem>
                      <SelectItem value="RO">RO</SelectItem>
                      <SelectItem value="RR">RR</SelectItem>
                      <SelectItem value="SC">SC</SelectItem>
                      <SelectItem value="SP">SP</SelectItem>
                      <SelectItem value="SE">SE</SelectItem>
                      <SelectItem value="TO">TO</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="pais">País</Label>
                  <Input 
                    id="pais" 
                    placeholder="País"
                    value={fornecedor.endereco.pais}
                    onChange={(e) => handleEnderecoChange('pais', e.target.value)}
                  />
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="contatos" className="space-y-6">
              {fornecedor.contatos.map((contato, index) => (
                <Card key={index} className={contato.principal ? "border-blue-200" : ""}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-base">
                        {contato.principal ? (
                          <Badge className="mr-2 bg-blue-100 text-blue-800">Principal</Badge>
                        ) : null}
                        Contato {index + 1}
                      </CardTitle>
                      <div className="flex gap-2">
                        {!contato.principal && (
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleSetContatoPrincipal(index)}
                          >
                            Definir como principal
                          </Button>
                        )}
                        {fornecedor.contatos.length > 1 && (
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => handleRemoveContato(index)}
                          >
                            Remover
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor={`contato-${index}-nome`}>Nome</Label>
                        <Input 
                          id={`contato-${index}-nome`} 
                          placeholder="Nome completo"
                          value={contato.nome}
                          onChange={(e) => handleContatoChange(index, 'nome', e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor={`contato-${index}-cargo`}>Cargo</Label>
                        <Input 
                          id={`contato-${index}-cargo`} 
                          placeholder="Cargo ou função"
                          value={contato.cargo}
                          onChange={(e) => handleContatoChange(index, 'cargo', e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor={`contato-${index}-email`}>Email</Label>
                        <Input 
                          id={`contato-${index}-email`} 
                          placeholder="email@empresa.com"
                          type="email"
                          value={contato.email}
                          onChange={(e) => handleContatoChange(index, 'email', e.target.value)}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor={`contato-${index}-telefone`}>Telefone</Label>
                        <Input 
                          id={`contato-${index}-telefone`} 
                          placeholder="(00) 00000-0000"
                          value={contato.telefone}
                          onChange={(e) => handleContatoChange(index, 'telefone', e.target.value)}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              <Button variant="outline" onClick={handleAddContato}>
                Adicionar Contato
              </Button>
            </TabsContent>
            
            <TabsContent value="categorias">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Categorias de Produtos</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {categoriaOptions.map((categoria, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`categoria-${index}`} 
                          checked={fornecedor.categorias.includes(categoria)}
                          onCheckedChange={() => handleCategoriaToggle(categoria)}
                        />
                        <label
                          htmlFor={`categoria-${index}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {categoria}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Certificações</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {certificacaoOptions.map((certificacao, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`certificacao-${index}`} 
                          checked={fornecedor.certificacoes.includes(certificacao)}
                          onCheckedChange={() => handleCertificacaoToggle(certificacao)}
                        />
                        <label
                          htmlFor={`certificacao-${index}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {certificacao}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="financeiro" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="banco">Banco</Label>
                  <Input 
                    id="banco" 
                    placeholder="Nome do banco"
                    value={fornecedor.financeiro.banco}
                    onChange={(e) => handleFinanceiroChange('banco', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="agencia">Agência</Label>
                  <Input 
                    id="agencia" 
                    placeholder="Número da agência"
                    value={fornecedor.financeiro.agencia}
                    onChange={(e) => handleFinanceiroChange('agencia', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="conta">Conta</Label>
                  <Input 
                    id="conta" 
                    placeholder="Número da conta"
                    value={fornecedor.financeiro.conta}
                    onChange={(e) => handleFinanceiroChange('conta', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="pix">Chave PIX</Label>
                  <Input 
                    id="pix" 
                    placeholder="Chave PIX"
                    value={fornecedor.financeiro.pix}
                    onChange={(e) => handleFinanceiroChange('pix', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="condicoes_pagamento">Condições de Pagamento</Label>
                  <Select 
                    value={fornecedor.financeiro.condicoes_pagamento} 
                    onValueChange={(value) => handleFinanceiroChange('condicoes_pagamento', value)}
                  >
                    <SelectTrigger id="condicoes_pagamento">
                      <SelectValue placeholder="Selecione a condição" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="a_vista">À Vista</SelectItem>
                      <SelectItem value="a_prazo">A Prazo</SelectItem>
                      <SelectItem value="antecipado">Pagamento Antecipado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="prazo_pagamento">Prazo de Pagamento (dias)</Label>
                  <Input 
                    id="prazo_pagamento" 
                    type="number"
                    placeholder="30"
                    value={fornecedor.financeiro.prazo_pagamento}
                    onChange={(e) => handleFinanceiroChange('prazo_pagamento', Number(e.target.value))}
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      <Dialog open={showValidacaoDialog} onOpenChange={setShowValidacaoDialog}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <ValidacaoFornecedor 
            fornecedor={fornecedor} 
            onSave={handleSaveValidacao} 
            onClose={() => setShowValidacaoDialog(false)} 
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
