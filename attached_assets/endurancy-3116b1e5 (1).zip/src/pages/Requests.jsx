import React, { useState, useEffect } from 'react';
import { Organization } from "@/api/entities";
import { ModuloDispensario } from "@/api/entities";
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "@/components/ui/use-toast";
import { 
  Search, 
  Building2, 
  Calendar, 
  Mail, 
  Clock, 
  CheckCircle, 
  XCircle, 
  ExternalLink, 
  Eye,
  ShoppingBag,
  Package,
  AlertTriangle
} from "lucide-react";
import { format } from 'date-fns';
import { Tab, Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Requests() {
  const navigate = useNavigate();
  const [requests, setRequests] = useState([]);
  const [moduleRequests, setModuleRequests] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("org");
  
  useEffect(() => {
    loadRequests();
  }, []);
  
  const loadRequests = async () => {
    try {
      setIsLoading(true);
      
      // Carregar solicitações de organização
      const orgs = await Organization.list("-created_date");
      // Apenas organizações pendentes
      const pendingOrgs = orgs.filter(org => org.status === "Pendente");
      setRequests(pendingOrgs);
      
      // Carregar solicitações de módulos (Dispensário)
      const modules = await ModuloDispensario.list();
      // Aqui criamos um objeto mais completo combinando dados do módulo e da organização
      const moduleRequestsData = await Promise.all(
        modules
          .filter(m => m.status === "pending_approval")
          .map(async (module) => {
            const org = orgs.find(o => o.id === module.organization_id) || { name: "Organização Desconhecida" };
            return {
              ...module,
              organization_name: org.name,
              organization_type: org.type || "Desconhecido",
              days_ago: getDaysInReview(module.created_date || new Date())
            };
          })
      );
      
      setModuleRequests(moduleRequestsData);
      
    } catch (error) {
      console.error("Error loading requests", error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar as solicitações.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };
  
  const getDaysInReview = (dateString) => {
    const created = new Date(dateString);
    const today = new Date();
    const diffTime = Math.abs(today - created);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };
  
  const handleApproveModule = async (moduleId) => {
    try {
      await ModuloDispensario.update(moduleId, {
        status: "active",
        is_active: true
      });
      
      toast({
        title: "Módulo Aprovado",
        description: "O módulo Dispensário foi aprovado com sucesso.",
      });
      
      loadRequests();
    } catch (error) {
      console.error("Error approving module", error);
      toast({
        title: "Erro",
        description: "Não foi possível aprovar o módulo.",
        variant: "destructive",
      });
    }
  };
  
  const handleRejectModule = async (moduleId) => {
    try {
      await ModuloDispensario.update(moduleId, {
        status: "rejected",
        is_active: false
      });
      
      toast({
        title: "Módulo Rejeitado",
        description: "O módulo Dispensário foi rejeitado.",
      });
      
      loadRequests();
    } catch (error) {
      console.error("Error rejecting module", error);
      toast({
        title: "Erro",
        description: "Não foi possível rejeitar o módulo.",
        variant: "destructive",
      });
    }
  };
  
  const filteredOrgs = requests.filter(req => 
    req.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.contact_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.contact_email?.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const filteredModules = moduleRequests.filter(req =>
    req.organization_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Solicitações</h1>
          <p className="text-gray-500 mt-1">
            Gerencie solicitações de organizações e módulos
          </p>
        </div>
      </div>
      
      <Card className="p-6 md:col-span-3">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex flex-col gap-1">
            <h2 className="text-xl font-bold">Resumo</h2>
            <p className="text-gray-500">
              {requests.length} solicitações de organizações e {moduleRequests.length} solicitações de módulos pendentes
            </p>
          </div>
          
          <div className="space-y-2 w-full md:w-64">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar solicitações..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>
      </Card>
      
      <Tabs defaultValue="org" onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="org" className="flex items-center">
            <Building2 className="mr-2 h-4 w-4" />
            Organizações <Badge className="ml-2 bg-blue-500">{requests.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="modules" className="flex items-center">
            <ShoppingBag className="mr-2 h-4 w-4" />
            Módulos <Badge className="ml-2 bg-green-500">{moduleRequests.length}</Badge>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="org">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredOrgs.map((request) => {
              const daysInReview = getDaysInReview(request.created_date);
              const urgencyLevel = daysInReview > 7 ? 'high' : daysInReview > 3 ? 'medium' : 'low';
              const urgencyProgress = {
                high: 80,
                medium: 50,
                low: 20
              };
              const urgencyColor = {
                high: "text-red-600",
                medium: "text-yellow-600",
                low: "text-green-600"
              };
              
              return (
                <Card key={request.id} className="overflow-hidden">
                  <div className="relative">
                    <div className={`h-1 absolute top-0 left-0 right-0 ${
                      urgencyLevel === 'high' ? 'bg-red-500' : 
                      urgencyLevel === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                    }`}></div>
                    
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-bold">{request.name}</h3>
                          <Badge className="mt-1 bg-purple-100 text-purple-800">
                            {request.type}
                          </Badge>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => navigate(`${createPageUrl("Request")}?id=${request.id}`)}
                        >
                          <Eye className="w-5 h-5" />
                        </Button>
                      </div>
                      
                      <div className="space-y-4">
                        <div className="flex items-start gap-3">
                          <Mail className="w-4 h-4 text-gray-400 mt-0.5" />
                          <div>
                            <p className="text-sm text-gray-500">Contato</p>
                            <p className="font-medium">{request.contact_name}</p>
                            <p className="text-sm">{request.contact_email}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-start gap-3">
                          <Calendar className="w-4 h-4 text-gray-400 mt-0.5" />
                          <div>
                            <p className="text-sm text-gray-500">Data da Solicitação</p>
                            <p className="font-medium">{formatDate(request.created_date)}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-6">
                        <div className="flex justify-between text-sm mb-1">
                          <div className="flex items-center gap-1">
                            <Clock className={`w-3 h-3 ${urgencyColor[urgencyLevel]}`} />
                            <span className={`font-medium ${urgencyColor[urgencyLevel]}`}>
                              {daysInReview} {daysInReview === 1 ? 'dia' : 'dias'} em análise
                            </span>
                          </div>
                          <span className="text-gray-500">
                            {urgencyLevel === 'high' ? 'Alta' : urgencyLevel === 'medium' ? 'Média' : 'Baixa'} prioridade
                          </span>
                        </div>
                        <Progress value={urgencyProgress[urgencyLevel]} className="h-1" />
                      </div>
                    </div>
                    
                    <div className="flex border-t">
                      <Button 
                        className="flex-1 rounded-none h-12 bg-red-600 hover:bg-red-700"
                        onClick={() => navigate(`${createPageUrl("Request")}?id=${request.id}&action=reject`)}
                      >
                        <XCircle className="w-4 h-4 mr-2" />
                        Rejeitar
                      </Button>
                      <div className="w-px bg-white"></div>
                      <Button 
                        className="flex-1 rounded-none h-12 bg-green-600 hover:bg-green-700"
                        onClick={() => navigate(`${createPageUrl("Request")}?id=${request.id}&action=approve`)}
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Aprovar
                      </Button>
                    </div>
                  </div>
                </Card>
              );
            })}
            
            {filteredOrgs.length === 0 && !isLoading && (
              <Card className="p-8 text-center md:col-span-3">
                <Building2 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <h3 className="text-lg font-medium text-gray-900">Nenhuma solicitação pendente</h3>
                <p className="text-gray-500 mt-1 max-w-md mx-auto">
                  {searchTerm 
                    ? `Não encontramos solicitações correspondentes a "${searchTerm}"`
                    : "Não há solicitações de organizações pendentes de revisão no momento."}
                </p>
                {searchTerm && (
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => setSearchTerm("")}
                  >
                    Limpar busca
                  </Button>
                )}
              </Card>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="modules">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredModules.map((module) => {
              const urgencyLevel = module.days_ago > 5 ? 'high' : module.days_ago > 2 ? 'medium' : 'low';
              const urgencyColor = {
                high: "text-red-600",
                medium: "text-yellow-600",
                low: "text-green-600"
              };
              
              return (
                <Card key={module.id} className="overflow-hidden">
                  <div className="relative">
                    <div className={`h-1 absolute top-0 left-0 right-0 ${
                      urgencyLevel === 'high' ? 'bg-red-500' : 
                      urgencyLevel === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                    }`}></div>
                    
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-bold">{module.organization_name}</h3>
                          <div className="flex space-x-2 mt-1">
                            <Badge className="bg-purple-100 text-purple-800">
                              {module.organization_type}
                            </Badge>
                            <Badge className="bg-green-100 text-green-800">
                              Módulo Dispensário
                            </Badge>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => navigate(createPageUrl("AdminModuloDispensario"))}
                        >
                          <Eye className="w-5 h-5" />
                        </Button>
                      </div>
                      
                      <div className="space-y-4">
                        <div className="flex items-start gap-3">
                          <Package className="w-4 h-4 text-gray-400 mt-0.5" />
                          <div>
                            <p className="text-sm text-gray-500">Tipo de Plano</p>
                            <p className="font-medium">Dispensário - R$ 299,00/mês</p>
                          </div>
                        </div>
                        
                        <div className="flex items-start gap-3">
                          <AlertTriangle className="w-4 h-4 text-gray-400 mt-0.5" />
                          <div>
                            <p className="text-sm text-gray-500">Status de Implantação</p>
                            <p className="font-medium">Aguardando Aprovação</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-6">
                        <div className="flex justify-between text-sm mb-1">
                          <div className="flex items-center gap-1">
                            <Clock className={`w-3 h-3 ${urgencyColor[urgencyLevel]}`} />
                            <span className={`font-medium ${urgencyColor[urgencyLevel]}`}>
                              {module.days_ago} {module.days_ago === 1 ? 'dia' : 'dias'} em análise
                            </span>
                          </div>
                          <span className="text-gray-500">
                            {urgencyLevel === 'high' ? 'Alta' : urgencyLevel === 'medium' ? 'Média' : 'Baixa'} prioridade
                          </span>
                        </div>
                        <Progress value={module.days_ago * 10} max={50} className="h-1" />
                      </div>
                    </div>
                    
                    <div className="flex border-t">
                      <Button 
                        className="flex-1 rounded-none h-12 bg-red-600 hover:bg-red-700"
                        onClick={() => handleRejectModule(module.id)}
                      >
                        <XCircle className="w-4 h-4 mr-2" />
                        Rejeitar
                      </Button>
                      <div className="w-px bg-white"></div>
                      <Button 
                        className="flex-1 rounded-none h-12 bg-green-600 hover:bg-green-700"
                        onClick={() => handleApproveModule(module.id)}
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Aprovar
                      </Button>
                    </div>
                  </div>
                </Card>
              );
            })}
            
            {filteredModules.length === 0 && !isLoading && (
              <Card className="p-8 text-center md:col-span-3">
                <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <h3 className="text-lg font-medium text-gray-900">Nenhuma solicitação de módulo pendente</h3>
                <p className="text-gray-500 mt-1 max-w-md mx-auto">
                  {searchTerm 
                    ? `Não encontramos solicitações correspondentes a "${searchTerm}"`
                    : "Não há solicitações de módulos pendentes de revisão no momento."}
                </p>
                {searchTerm && (
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => setSearchTerm("")}
                  >
                    Limpar busca
                  </Button>
                )}
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
      
      {isLoading && (
        <Card className="p-8 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto"></div>
          <p className="text-gray-500 mt-4">Carregando solicitações...</p>
        </Card>
      )}
    </div>
  );
}