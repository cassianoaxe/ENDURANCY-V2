import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Factory, 
  Package, 
  ArrowLeftRight, 
  ClipboardList, 
  Trash2, 
  Search, 
  FileText, 
  CheckSquare, 
  Play, 
  BookOpen, 
  GraduationCap, 
  CheckCircle, 
  AlertCircle,
  ArrowRight,
  Info,
  Clock,
  HelpCircle
} from "lucide-react";

export default function ProducaoOnboarding() {
  const [activeTab, setActiveTab] = useState("visaoGeral");
  const [progress, setProgress] = useState(0);
  
  useEffect(() => {
    // Simulando carregamento do progresso do usuário
    setProgress(35);
  }, []);

  const moduleCards = [
    {
      title: "Estoque",
      description: "Gerencie o inventário de matérias-primas e produtos acabados",
      icon: Package,
      path: "Estoque",
      completed: true
    },
    {
      title: "Movimentações",
      description: "Registre entradas, saídas e transferências no estoque",
      icon: ArrowLeftRight,
      path: "ProducaoMovimentacoes",
      completed: true
    },
    {
      title: "Ordens de Produção",
      description: "Crie e gerencie ordens para fabricação de produtos",
      icon: ClipboardList,
      path: "ProducaoOrdens",
      completed: false
    },
    {
      title: "Descartes",
      description: "Controle do descarte de materiais e produtos",
      icon: Trash2,
      path: "ProducaoDescartes",
      completed: false
    },
    {
      title: "Rastreabilidade",
      description: "Acompanhamento completo do ciclo de vida dos produtos",
      icon: Search,
      path: "ProducaoRastreabilidade",
      completed: false
    },
    {
      title: "Controle de Qualidade",
      description: "Realize testes e análises de qualidade",
      icon: FileText,
      path: "ProducaoQualidade",
      completed: false
    },
    {
      title: "Garantia da Qualidade",
      description: "Liberação e garantia de qualidade dos produtos",
      icon: CheckSquare,
      path: "ProducaoGarantiaQualidade",
      completed: false
    },
    {
      title: "Catálogo de Produtos",
      description: "Gerencie o catálogo de produtos da organização",
      icon: Package,
      path: "CatalogoProdutos",
      completed: false
    }
  ];

  const tutorialList = [
    {
      id: 1,
      title: "Introdução ao Módulo de Produção",
      duration: "5 min",
      description: "Visão geral sobre o funcionamento do módulo de produção",
      completed: true
    },
    {
      id: 2,
      title: "Gerenciamento de Estoque",
      duration: "8 min",
      description: "Como gerenciar o estoque de matérias-primas e produtos acabados",
      completed: true
    },
    {
      id: 3,
      title: "Movimentações de Estoque",
      duration: "10 min",
      description: "Fluxo completo de materiais desde recebimento até expedição",
      completed: true
    },
    {
      id: 4,
      title: "Criando Ordens de Produção",
      duration: "12 min",
      description: "Como criar, rastrear e concluir ordens de produção",
      completed: false
    },
    {
      id: 5,
      title: "Rastreabilidade na Produção",
      duration: "7 min",
      description: "Implementando rastreabilidade completa no processo produtivo",
      completed: false
    },
    {
      id: 6,
      title: "Controle e Garantia de Qualidade",
      duration: "15 min",
      description: "Boas práticas de fabricação e garantia de qualidade",
      completed: false
    }
  ];

  const shortcuts = [
    { icon: Factory, label: "Dashboard", path: "ProducaoDashboard" },
    { icon: ClipboardList, label: "Nova Ordem", path: "ProducaoNovaOrdem" },
    { icon: ArrowLeftRight, label: "Nova Movimentação", path: "NovaMovimentacaoEstoque" },
    { icon: Package, label: "Estoque", path: "Estoque" },
    { icon: Trash2, label: "Registrar Descarte", path: "ProducaoDescartes" }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Onboarding do Módulo de Produção</h1>
          <p className="text-gray-500 mt-1">Aprenda a utilizar as funcionalidades do sistema de produção</p>
        </div>
        <div className="flex flex-col items-end">
          <div className="flex items-center mb-2">
            <span className="text-sm font-medium mr-2">Progresso:</span>
            <span className="text-sm font-bold">{progress}%</span>
          </div>
          <Progress value={progress} className="w-40 h-2" />
        </div>
      </div>

      {/* Atalhos rápidos */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        {shortcuts.map((shortcut, index) => {
          const Icon = shortcut.icon;
          return (
            <Link 
              key={index}
              to={createPageUrl(shortcut.path)}
              className="flex flex-col items-center justify-center p-4 rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow border border-gray-100 text-center"
            >
              <Icon className="w-6 h-6 mb-2 text-green-600" />
              <span className="text-sm font-medium">{shortcut.label}</span>
            </Link>
          );
        })}
      </div>

      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 w-full max-w-md mb-4">
          <TabsTrigger value="visaoGeral">Visão Geral</TabsTrigger>
          <TabsTrigger value="modulos">Módulos</TabsTrigger>
          <TabsTrigger value="tutoriais">Tutoriais</TabsTrigger>
        </TabsList>

        <TabsContent value="visaoGeral" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Info className="w-5 h-5 mr-2 text-blue-500" />
                O que é o Módulo de Produção?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                O módulo de produção é responsável por gerenciar todo o ciclo produtivo, desde o recebimento de matérias-primas 
                até a expedição de produtos acabados, garantindo a rastreabilidade completa e o controle de qualidade.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="flex items-start">
                  <div className="bg-green-100 p-2 rounded-full mr-3">
                    <Package className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Gestão de Estoque</h3>
                    <p className="text-sm text-gray-600">Controle completo de matérias-primas e produtos acabados</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-3">
                    <ClipboardList className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Ordens de Produção</h3>
                    <p className="text-sm text-gray-600">Planejamento e execução de produções</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-purple-100 p-2 rounded-full mr-3">
                    <Search className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Rastreabilidade</h3>
                    <p className="text-sm text-gray-600">Histórico completo de cada lote produzido</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-amber-100 p-2 rounded-full mr-3">
                    <FileText className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Controle de Qualidade</h3>
                    <p className="text-sm text-gray-600">Garantia de conformidade com os padrões de qualidade</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 p-4 bg-blue-50 rounded-lg flex items-start">
                <AlertCircle className="w-5 h-5 text-blue-500 mr-2 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-700">Dica importante</h4>
                  <p className="text-sm text-blue-600">
                    Comece configurando o catálogo de produtos e os estoques de matérias-primas antes de criar suas primeiras ordens de produção. 
                    Isso garantirá que todo o fluxo funcione corretamente.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="w-5 h-5 mr-2 text-indigo-500" /> 
                Próximos passos recomendados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-4">
                <li className="flex items-center">
                  <div className="bg-green-100 text-green-700 rounded-full w-6 h-6 flex items-center justify-center mr-3">1</div>
                  <span className="line-through text-gray-500">Configurar o estoque de matérias-primas</span>
                  <CheckCircle className="ml-2 w-4 h-4 text-green-500" />
                </li>
                <li className="flex items-center">
                  <div className="bg-green-100 text-green-700 rounded-full w-6 h-6 flex items-center justify-center mr-3">2</div>
                  <span className="line-through text-gray-500">Registrar movimentações iniciais</span>
                  <CheckCircle className="ml-2 w-4 h-4 text-green-500" />
                </li>
                <li className="flex items-center">
                  <div className="bg-blue-100 text-blue-700 rounded-full w-6 h-6 flex items-center justify-center mr-3">3</div>
                  <span>Criar sua primeira ordem de produção</span>
                </li>
                <li className="flex items-center">
                  <div className="bg-gray-100 text-gray-700 rounded-full w-6 h-6 flex items-center justify-center mr-3">4</div>
                  <span className="text-gray-700">Configurar testes de controle de qualidade</span>
                </li>
              </ol>
              
              <div className="mt-4">
                <Link to={createPageUrl("ProducaoNovaOrdem")}>
                  <Button className="mt-2">
                    Criar Primeira Ordem de Produção 
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="modulos" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {moduleCards.map((module, index) => {
              const Icon = module.icon;
              return (
                <Card key={index} className={`border-l-4 ${module.completed ? 'border-l-green-500' : 'border-l-gray-300'}`}>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center">
                      <Icon className="w-5 h-5 mr-2 text-green-600" />
                      {module.title}
                      {module.completed && (
                        <Badge className="ml-2 bg-green-100 text-green-800 hover:bg-green-100">
                          <CheckCircle className="w-3 h-3 mr-1" /> Concluído
                        </Badge>
                      )}
                    </CardTitle>
                    <CardDescription>{module.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <Link to={createPageUrl(module.path)}>
                        <Button size="sm" variant={module.completed ? "outline" : "default"}>
                          {module.completed ? 'Acessar' : 'Iniciar'}
                          <ArrowRight className="ml-2 w-4 h-4" />
                        </Button>
                      </Link>
                      {!module.completed && (
                        <Link to={createPageUrl("OnboardingTutorialView")} className="text-sm text-blue-600 hover:underline flex items-center">
                          <HelpCircle className="w-3 h-3 mr-1" />
                          Ajuda
                        </Link>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="tutoriais" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tutorialList.map((tutorial) => (
              <Card key={tutorial.id} className={`border-l-4 ${tutorial.completed ? 'border-l-green-500' : 'border-l-blue-500'}`}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-base">{tutorial.title}</CardTitle>
                    <Badge 
                      variant="outline" 
                      className="bg-gray-100 text-gray-800 flex items-center gap-1"
                    >
                      <Clock className="w-3 h-3" />
                      {tutorial.duration}
                    </Badge>
                  </div>
                  <CardDescription>{tutorial.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <Button 
                      size="sm" 
                      variant={tutorial.completed ? "outline" : "default"}
                      onClick={() => {}}
                    >
                      {tutorial.completed ? 'Revisar Tutorial' : 'Iniciar Tutorial'}
                      {tutorial.completed ? <Play className="ml-2 w-3 h-3" /> : <BookOpen className="ml-2 w-3 h-3" />}
                    </Button>
                    {tutorial.completed && (
                      <span className="text-green-600 flex items-center text-sm">
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Concluído
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="flex justify-center mt-4">
            <Link to={createPageUrl("OnboardingTutorials")}>
              <Button variant="outline">
                Ver Todos os Tutoriais 
                <GraduationCap className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}