
import React, { useState, useEffect } from 'react';
import { 
  Save, 
  Plus, 
  Trash2, 
  XCircle,
  User,
  Users,
  Microscope,
  Building2,
  Mail,
  Phone,
  Calendar,
  AlertTriangle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate, useParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { mockGrupos } from './GruposPesquisa';

export default function EditarGrupoPesquisa() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [grupo, setGrupo] = useState(null);
  const [membros, setMembros] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadGrupo();
  }, [id]);

  const loadGrupo = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      const grupoMock = mockGrupos.find(g => g.id === id);
      if (grupoMock) {
        setGrupo(grupoMock);
        setMembros(grupoMock.membros);
      }
    } catch (error) {
      console.error("Erro ao carregar grupo:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const addMembro = () => {
    setMembros([...membros, { nome: '', funcao: '', email: '' }]);
  };

  const removeMembro = (index) => {
    const novosMembros = [...membros];
    novosMembros.splice(index, 1);
    setMembros(novosMembros);
  };

  const updateMembro = (index, field, value) => {
    const novosMembros = [...membros];
    novosMembros[index][field] = value;
    setMembros(novosMembros);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    navigate(createPageUrl("GruposPesquisa"));
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/3"></div>
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-[200px] bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!grupo) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="py-10">
            <div className="text-center space-y-3">
              <AlertTriangle className="w-10 h-10 text-yellow-500 mx-auto" />
              <h2 className="text-xl font-semibold">Grupo não encontrado</h2>
              <p className="text-gray-500">
                O grupo de pesquisa que você está tentando editar não foi encontrado.
              </p>
              <Button 
                onClick={() => navigate(createPageUrl("GruposPesquisa"))}
                className="mt-4"
              >
                Voltar para Grupos
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Editar Grupo de Pesquisa</h1>
          <p className="text-muted-foreground">Edite as informações do grupo de pesquisa</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => navigate(createPageUrl("GruposPesquisa"))}
          >
            <XCircle className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button 
            className="bg-green-600 hover:bg-green-700"
            onClick={handleSubmit}
          >
            <Save className="w-4 h-4 mr-2" />
            Salvar Alterações
          </Button>
        </div>
      </div>

      {/* Restante do conteúdo igual ao NovoGrupoPesquisa, mas com os campos preenchidos */}
    </div>
  );
}
