
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Users, 
  Search, 
  Filter, 
  PlusCircle, 
  Download, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Trash2, 
  Mail, 
  Phone, 
  FileText, 
  Calendar
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Dados simulados de pacientes
const mockPatients = [
  {
    id: "pat-001",
    nome: "Maria Silva",
    cpf: "123.456.789-00",
    data_nascimento: "1985-05-15",
    email: "maria.silva@email.com",
    telefone: "(11) 98765-4321",
    status: "ativo",
    condicoes: ["Dor crônica", "Ansiedade"],
    avatar: "MS",
    ultima_consulta: "2023-05-10",
    medico: "Dr. Carlos Santos",
    data_cadastro: "2022-08-15"
  },
  {
    id: "pat-002",
    nome: "João Pereira",
    cpf: "987.654.321-00",
    data_nascimento: "1970-12-20",
    email: "joao.pereira@email.com",
    telefone: "(11) 98765-1234",
    status: "ativo",
    condicoes: ["Epilepsia", "Insônia"],
    avatar: "JP",
    ultima_consulta: "2023-04-22",
    medico: "Dra. Ana Beatriz",
    data_cadastro: "2022-09-10"
  },
  {
    id: "pat-003",
    nome: "Ana Costa",
    cpf: "456.789.123-00",
    data_nascimento: "1990-03-25",
    email: "ana.costa@email.com",
    telefone: "(11) 98123-4567",
    status: "ativo",
    condicoes: ["Esclerose múltipla"],
    avatar: "AC",
    ultima_consulta: "2023-05-05",
    medico: "Dr. Paulo Menezes",
    data_cadastro: "2022-07-23"
  },
  {
    id: "pat-004",
    nome: "Roberto Alves",
    cpf: "789.123.456-00",
    data_nascimento: "1982-09-10",
    email: "roberto.alves@email.com",
    telefone: "(11) 95678-1234",
    status: "inativo",
    condicoes: ["Parkinson", "Ansiedade"],
    avatar: "RA",
    ultima_consulta: "2023-01-15",
    medico: "Dra. Márcia Oliveira",
    data_cadastro: "2022-05-18"
  },
  {
    id: "pat-005",
    nome: "Fernanda Lima",
    cpf: "321.654.987-00",
    data_nascimento: "1975-07-30",
    email: "fernanda.lima@email.com",
    telefone: "(11) 91234-5678",
    status: "ativo",
    condicoes: ["Fibromialgia", "Depressão"],
    avatar: "FL",
    ultima_consulta: "2023-04-30",
    medico: "Dr. João Paulo",
    data_cadastro: "2022-10-05"
  },
  {
    id: "pat-006",
    nome: "Paulo Rodrigues",
    cpf: "654.321.987-00",
    data_nascimento: "1988-11-12",
    email: "paulo.rodrigues@email.com",
    telefone: "(11) 98765-8765",
    status: "ativo",
    condicoes: ["Autismo"],
    avatar: "PR",
    ultima_consulta: "2023-05-18",
    medico: "Dra. Ana Beatriz",
    data_cadastro: "2023-01-20"
  }
];

export default function Patients() {
  const navigate = useNavigate();
  const [patients, setPatients] = useState([]);
  const [filteredPatients, setFilteredPatients] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');
  const [loading, setLoading] = useState(true);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [patientToDelete, setPatientToDelete] = useState(null);

  useEffect(() => {
    // Simulando carregamento de dados
    setTimeout(() => {
      setPatients(mockPatients);
      setFilteredPatients(mockPatients);
      setLoading(false);
    }, 500);
  }, []);

  useEffect(() => {
    let result = [...patients];
    
    // Aplicar filtro de status
    if (statusFilter !== 'todos') {
      result = result.filter(patient => patient.status === statusFilter);
    }
    
    // Aplicar termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(patient => 
        patient.nome.toLowerCase().includes(term) || 
        patient.cpf.includes(term) || 
        patient.email.toLowerCase().includes(term) ||
        patient.telefone.includes(term)
      );
    }
    
    setFilteredPatients(result);
  }, [patients, searchTerm, statusFilter]);

  const handleDelete = (patientId) => {
    // Implementação real substituiria por chamada à API
    setPatients(patients.filter(patient => patient.id !== patientId));
    setDeleteDialogOpen(false);
    setPatientToDelete(null);
  };

  const handleConfirmDelete = (patient) => {
    setPatientToDelete(patient);
    setDeleteDialogOpen(true);
  };

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    
    try {
      const date = new Date(dateString);
      return new Intl.DateTimeFormat('pt-BR').format(date);
    } catch (error) {
      console.error("Erro ao formatar data:", error);
      return "Data inválida";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Pacientes</h1>
          <p className="text-gray-500 mt-1">
            Gerencie os pacientes cadastrados na plataforma.
          </p>
        </div>
        
        <Link to={createPageUrl("NewPatient")}>
          <Button className="gap-2">
            <PlusCircle className="h-4 w-4" />
            Novo Paciente
          </Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row md:items-center gap-4 justify-between">
        <div className="relative w-full md:w-80">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar pacientes..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os status</SelectItem>
              <SelectItem value="ativo">Ativos</SelectItem>
              <SelectItem value="inativo">Inativos</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Exportar
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-8 flex justify-center">
              <div className="animate-pulse text-center">
                <div className="h-4 w-32 bg-gray-200 rounded mx-auto mb-4"></div>
                <div className="h-10 bg-gray-200 rounded mb-2 max-w-md mx-auto"></div>
                <div className="h-10 bg-gray-200 rounded mb-2 max-w-md mx-auto"></div>
                <div className="h-10 bg-gray-200 rounded mb-2 max-w-md mx-auto"></div>
              </div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12"></TableHead>
                  <TableHead>Nome</TableHead>
                  <TableHead>Contato</TableHead>
                  <TableHead>Condições</TableHead>
                  <TableHead>Última Consulta</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPatients.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-10 text-gray-500">
                      Nenhum paciente encontrado com os filtros atuais.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredPatients.map((patient) => (
                    <TableRow key={patient.id}>
                      <TableCell>
                        <Avatar className="h-9 w-9">
                          <AvatarFallback>{patient.avatar}</AvatarFallback>
                        </Avatar>
                      </TableCell>
                      <TableCell className="font-medium">
                        <div>{patient.nome}</div>
                        <div className="text-sm text-gray-500">{patient.cpf}</div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm">
                          <Mail className="h-3 w-3" />
                          <span>{patient.email}</span>
                        </div>
                        <div className="flex items-center gap-1 text-sm mt-1">
                          <Phone className="h-3 w-3" />
                          <span>{patient.telefone}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {patient.condicoes.map((condicao, index) => (
                          <Badge key={index} variant="outline" className="mr-1 mb-1">
                            {condicao}
                          </Badge>
                        ))}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm">
                          <Calendar className="h-3 w-3" />
                          <span>{formatDate(patient.ultima_consulta)}</span>
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {patient.medico}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          patient.status === 'ativo' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-gray-100 text-gray-800'
                        }>
                          {patient.status === 'ativo' ? 'Ativo' : 'Inativo'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Abrir menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Ações</DropdownMenuLabel>
                            <DropdownMenuItem 
                              className="cursor-pointer"
                              onClick={() => navigate(`${createPageUrl("PatientDetail")}?id=${patient.id}`)}
                            >
                              <Eye className="mr-2 h-4 w-4" />
                              Ver detalhes
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="cursor-pointer"
                              onClick={() => navigate(`${createPageUrl("EditPatient")}?id=${patient.id}`)}
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              className="cursor-pointer text-red-600"
                              onClick={() => handleConfirmDelete(patient)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Diálogo de confirmação para exclusão */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar exclusão</DialogTitle>
            <DialogDescription>
              Você tem certeza que deseja excluir o paciente {patientToDelete?.nome}? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => handleDelete(patientToDelete?.id)}
            >
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
