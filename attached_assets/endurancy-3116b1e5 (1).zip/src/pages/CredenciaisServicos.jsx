import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { CredencialServico } from '@/api/entities';
import { User } from '@/api/entities';
import { toast } from '@/components/ui/use-toast';
import {
  Lock,
  Eye,
  EyeOff,
  Plus,
  Trash2,
  Edit,
  Copy,
  Search,
  RefreshCw,
  Filter,
  ArrowDownUp,
  UserPlus,
  Shield,
  Key,
  Save,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Spinner } from '@/components/ui/spinner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function CredenciaisServicos() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [credenciais, setCredenciais] = useState([]);
  const [showDialog, setShowDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentCredencial, setCurrentCredencial] = useState(null);
  const [formData, setFormData] = useState({
    nome_servico: '',
    descricao: '',
    categoria: 'comunicacao',
    url: '',
    usuario: '',
    senha: '',
    api_key: '',
    api_secret: '',
    data_expiracao: '',
    acesso_compartilhado: [],
    notas: '',
    icone: 'key'
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [showPasswords, setShowPasswords] = useState({});
  const [showSecrets, setShowSecrets] = useState({});
  const [sortBy, setSortBy] = useState('nome_servico');
  const [sortDirection, setSortDirection] = useState('asc');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadCurrentUser();
    loadCredenciais();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error loading user", error);
      toast({
        title: "Erro de autenticação",
        description: "Você precisa estar logado para acessar esta página.",
        variant: "destructive",
      });
      navigate(createPageUrl("Access"));
    }
  };

  const loadCredenciais = async () => {
    setLoading(true);
    try {
      // In a real app, you would fetch from the database
      // const credenciaisData = await CredencialServico.list();
      
      // Using mock data for demonstration
      const mockCredenciais = [
        {
          id: '1',
          nome_servico: 'SendGrid Email API',
          descricao: 'API para envio de emails em massa',
          categoria: 'comunicacao',
          url: 'https://app.sendgrid.com',
          usuario: 'admin@endurancy.com',
          senha: '********',
          api_key: 'SG.xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
          api_secret: '',
          data_expiracao: '2024-12-31',
          acesso_compartilhado: ['user1', 'user2'],
          notas: 'Usado para envio de notificações e campanhas de email',
          icone: 'mail'
        },
        {
          id: '2',
          nome_servico: 'Zenvia WhatsApp API',
          descricao: 'Integração para envio de mensagens via WhatsApp',
          categoria: 'comunicacao',
          url: 'https://app.zenvia.com',
          usuario: 'endurancyapi',
          senha: '********',
          api_key: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
          api_secret: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
          data_expiracao: '2025-01-15',
          acesso_compartilhado: [],
          notas: 'Usado para lembretes de medicação',
          icone: 'message-square'
        },
        {
          id: '3',
          nome_servico: 'AWS S3',
          descricao: 'Armazenamento de arquivos na nuvem',
          categoria: 'tecnologia',
          url: 'https://console.aws.amazon.com',
          usuario: 'endurancy-admin',
          senha: '********',
          api_key: 'AKIAXXXXXXXXXXXXXXXX',
          api_secret: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
          data_expiracao: '',
          acesso_compartilhado: ['user3'],
          notas: 'Bucket principal: endurancy-documents',
          icone: 'cloud'
        },
        {
          id: '4',
          nome_servico: 'Google Analytics',
          descricao: 'Análise de dados do portal',
          categoria: 'marketing',
          url: 'https://analytics.google.com',
          usuario: 'endurancy@gmail.com',
          senha: '********',
          api_key: '',
          api_secret: '',
          data_expiracao: '',
          acesso_compartilhado: [],
          notas: 'ID da propriedade: UA-123456789-1',
          icone: 'bar-chart-2'
        },
        {
          id: '5',
          nome_servico: 'Stripe',
          descricao: 'Gateway de pagamento',
          categoria: 'financeiro',
          url: 'https://dashboard.stripe.com',
          usuario: 'admin@endurancy.com',
          senha: '********',
          api_key: 'pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
          api_secret: 'sk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
          data_expiracao: '',
          acesso_compartilhado: ['user4'],
          notas: 'Ambiente de produção',
          icone: 'credit-card'
        }
      ];
      
      setCredenciais(mockCredenciais);
      setLoading(false);
    } catch (error) {
      console.error("Error loading credenciais", error);
      toast({
        title: "Erro ao carregar credenciais",
        description: "Não foi possível carregar as credenciais de serviços.",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  const handleCreateNew = () => {
    setFormData({
      nome_servico: '',
      descricao: '',
      categoria: 'comunicacao',
      url: '',
      usuario: '',
      senha: '',
      api_key: '',
      api_secret: '',
      data_expiracao: '',
      acesso_compartilhado: [],
      notas: '',
      icone: 'key'
    });
    setIsEditing(false);
    setShowDialog(true);
  };

  const handleEdit = (credencial) => {
    setCurrentCredencial(credencial);
    setFormData({
      nome_servico: credencial.nome_servico,
      descricao: credencial.descricao,
      categoria: credencial.categoria,
      url: credencial.url,
      usuario: credencial.usuario,
      senha: credencial.senha,
      api_key: credencial.api_key,
      api_secret: credencial.api_secret,
      data_expiracao: credencial.data_expiracao,
      acesso_compartilhado: credencial.acesso_compartilhado,
      notas: credencial.notas,
      icone: credencial.icone
    });
    setIsEditing(true);
    setShowDialog(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir esta credencial? Esta ação não pode ser desfeita.')) {
      try {
        // In a real app, you would delete from the database
        // await CredencialServico.delete(id);
        
        // For demo, just remove from state
        setCredenciais(credenciais.filter(cred => cred.id !== id));
        
        toast({
          title: "Credencial excluída",
          description: "A credencial foi excluída com sucesso.",
        });
      } catch (error) {
        console.error("Error deleting credencial", error);
        toast({
          title: "Erro ao excluir",
          description: "Não foi possível excluir a credencial.",
          variant: "destructive",
        });
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    try {
      // Validate form
      if (!formData.nome_servico) {
        toast({
          title: "Campo obrigatório",
          description: "O nome do serviço é obrigatório.",
          variant: "destructive",
        });
        setSaving(false);
        return;
      }
      
      // In a real app, you would save to the database
      if (isEditing && currentCredencial) {
        // Update existing
        // await CredencialServico.update(currentCredencial.id, formData);
        
        // For demo, update in state
        const updatedCredenciais = credenciais.map(cred => 
          cred.id === currentCredencial.id ? { ...cred, ...formData } : cred
        );
        setCredenciais(updatedCredenciais);
        
        toast({
          title: "Credencial atualizada",
          description: "A credencial foi atualizada com sucesso.",
        });
      } else {
        // Create new
        // const newCredencial = await CredencialServico.create(formData);
        
        // For demo, add to state with mock ID
        const newCredencial = {
          id: Date.now().toString(),
          ...formData,
        };
        setCredenciais([...credenciais, newCredencial]);
        
        toast({
          title: "Credencial criada",
          description: "A nova credencial foi criada com sucesso.",
        });
      }
      
      setShowDialog(false);
    } catch (error) {
      console.error("Error saving credencial", error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar a credencial.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const togglePasswordVisibility = (id) => {
    setShowPasswords({
      ...showPasswords,
      [id]: !showPasswords[id]
    });
  };

  const toggleSecretVisibility = (id) => {
    setShowSecrets({
      ...showSecrets,
      [id]: !showSecrets[id]
    });
  };

  const copyToClipboard = (text, type) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copiado!",
        description: `${type} copiado para a área de transferência.`,
      });
    });
  };

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortDirection('asc');
    }
  };

  const filteredAndSortedCredenciais = credenciais
    .filter(cred => {
      const matchesSearch = cred.nome_servico.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           cred.descricao.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = filterCategory === 'all' || cred.categoria === filterCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortDirection === 'asc') {
        return a[sortBy] > b[sortBy] ? 1 : -1;
      } else {
        return a[sortBy] < b[sortBy] ? 1 : -1;
      }
    });

  // Get days until expiration
  const getDaysUntilExpiration = (expirationDate) => {
    if (!expirationDate) return null;
    
    const expiration = new Date(expirationDate);
    const today = new Date();
    const diffTime = expiration.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  // Get status badge based on expiration
  const getExpirationStatus = (expirationDate) => {
    if (!expirationDate) return null;
    
    const daysUntil = getDaysUntilExpiration(expirationDate);
    
    if (daysUntil < 0) {
      return <Badge variant="destructive">Expirado</Badge>;
    } else if (daysUntil < 30) {
      return <Badge variant="warning">Expira em {daysUntil} dias</Badge>;
    } else {
      return <Badge variant="outline">Válido</Badge>;
    }
  };

  // Get category badge
  const getCategoryBadge = (category) => {
    const categories = {
      'comunicacao': { label: 'Comunicação', color: 'bg-blue-100 text-blue-800' },
      'tecnologia': { label: 'Tecnologia', color: 'bg-purple-100 text-purple-800' },
      'marketing': { label: 'Marketing', color: 'bg-pink-100 text-pink-800' },
      'financeiro': { label: 'Financeiro', color: 'bg-green-100 text-green-800' },
      'operacional': { label: 'Operacional', color: 'bg-orange-100 text-orange-800' },
      'vendas': { label: 'Vendas', color: 'bg-indigo-100 text-indigo-800' },
      'outro': { label: 'Outro', color: 'bg-gray-100 text-gray-800' }
    };
    
    const categoryInfo = categories[category] || categories['outro'];
    
    return (
      <Badge className={categoryInfo.color}>
        {categoryInfo.label}
      </Badge>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Spinner size="large" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Credenciais de Serviços</h1>
          <p className="text-gray-500">Gerencie as credenciais de acesso a serviços e APIs</p>
        </div>
        <Button onClick={handleCreateNew} className="gap-2">
          <Plus className="w-4 h-4" />
          Nova Credencial
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row gap-4 justify-between">
            <div className="relative w-full md:w-72">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar credenciais..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-3">
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="gap-2 w-40">
                  <Filter className="w-4 h-4 text-gray-500" />
                  <SelectValue placeholder="Categoria" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as categorias</SelectItem>
                  <SelectItem value="comunicacao">Comunicação</SelectItem>
                  <SelectItem value="tecnologia">Tecnologia</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="financeiro">Financeiro</SelectItem>
                  <SelectItem value="operacional">Operacional</SelectItem>
                  <SelectItem value="vendas">Vendas</SelectItem>
                  <SelectItem value="outro">Outro</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" className="gap-2">
                <RefreshCw className="w-4 h-4" />
                Atualizar
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredAndSortedCredenciais.length === 0 ? (
            <div className="text-center py-10">
              <Lock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-gray-700">Nenhuma credencial encontrada</h3>
              <p className="text-gray-500">
                {searchQuery || filterCategory !== 'all'
                  ? "Nenhum resultado corresponde aos seus filtros."
                  : "Adicione suas primeiras credenciais para gerenciar seus serviços."
                }
              </p>
              {(searchQuery || filterCategory !== 'all') && (
                <Button variant="outline" className="mt-4" onClick={() => {
                  setSearchQuery('');
                  setFilterCategory('all');
                }}>
                  Limpar filtros
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead 
                      className="cursor-pointer"
                      onClick={() => handleSort('nome_servico')}
                    >
                      <div className="flex items-center gap-1">
                        Serviço
                        {sortBy === 'nome_servico' && (
                          <ArrowDownUp className="w-3 h-3 text-gray-500" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Credenciais</TableHead>
                    <TableHead
                      className="cursor-pointer"
                      onClick={() => handleSort('data_expiracao')}
                    >
                      <div className="flex items-center gap-1">
                        Expiração
                        {sortBy === 'data_expiracao' && (
                          <ArrowDownUp className="w-3 h-3 text-gray-500" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead>Acesso</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAndSortedCredenciais.map((credencial) => (
                    <TableRow key={credencial.id}>
                      <TableCell>
                        <div className="flex items-start gap-3">
                          <div className="bg-gray-100 p-2 rounded-md">
                            <Lock className="w-5 h-5 text-gray-600" />
                          </div>
                          <div>
                            <div className="font-medium">{credencial.nome_servico}</div>
                            <div className="text-sm text-gray-500 truncate max-w-md">{credencial.descricao}</div>
                            {credencial.url && (
                              <a 
                                href={credencial.url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-xs text-blue-600 hover:underline"
                              >
                                {credencial.url}
                              </a>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{getCategoryBadge(credencial.categoria)}</TableCell>
                      <TableCell>
                        <div className="space-y-2">
                          {credencial.usuario && (
                            <div className="text-sm">
                              <span className="text-gray-500">Usuário:</span> {credencial.usuario}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-4 w-4 p-0 ml-1"
                                onClick={() => copyToClipboard(credencial.usuario, 'Usuário')}
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                          )}
                          {credencial.senha && (
                            <div className="text-sm flex items-center">
                              <span className="text-gray-500">Senha:</span>
                              <span className="mx-1">
                                {showPasswords[credencial.id] ? credencial.senha : '••••••••'}
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-4 w-4 p-0 mr-1"
                                onClick={() => togglePasswordVisibility(credencial.id)}
                              >
                                {showPasswords[credencial.id] ? (
                                  <EyeOff className="h-3 w-3" />
                                ) : (
                                  <Eye className="h-3 w-3" />
                                )}
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-4 w-4 p-0"
                                onClick={() => copyToClipboard(credencial.senha, 'Senha')}
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                          )}
                          {credencial.api_key && (
                            <div className="text-sm flex items-center">
                              <span className="text-gray-500">API Key:</span>
                              <span className="mx-1">
                                {showSecrets[credencial.id] 
                                  ? credencial.api_key 
                                  : `${credencial.api_key.substring(0, 8)}...`}
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-4 w-4 p-0 mr-1"
                                onClick={() => toggleSecretVisibility(credencial.id)}
                              >
                                {showSecrets[credencial.id] ? (
                                  <EyeOff className="h-3 w-3" />
                                ) : (
                                  <Eye className="h-3 w-3" />
                                )}
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-4 w-4 p-0"
                                onClick={() => copyToClipboard(credencial.api_key, 'API Key')}
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {credencial.data_expiracao ? (
                          <div>
                            <div className="text-sm">{format(new Date(credencial.data_expiracao), 'dd/MM/yyyy')}</div>
                            <div className="mt-1">{getExpirationStatus(credencial.data_expiracao)}</div>
                          </div>
                        ) : (
                          <span className="text-gray-500 text-sm">Sem expiração</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {credencial.acesso_compartilhado && credencial.acesso_compartilhado.length > 0 ? (
                          <div className="flex items-center">
                            <div className="flex -space-x-2">
                              {credencial.acesso_compartilhado.slice(0, 3).map((userId, index) => (
                                <div 
                                  key={index} 
                                  className="w-7 h-7 rounded-full bg-blue-100 border-2 border-white flex items-center justify-center text-xs"
                                >
                                  {userId.charAt(0).toUpperCase()}
                                </div>
                              ))}
                            </div>
                            {credencial.acesso_compartilhado.length > 3 && (
                              <div className="ml-1 text-sm text-gray-500">
                                +{credencial.acesso_compartilhado.length - 3}
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="text-gray-500 text-sm">Acesso individual</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(credencial)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-500"
                            onClick={() => handleDelete(credencial.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Credential Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{isEditing ? 'Editar Credencial' : 'Nova Credencial'}</DialogTitle>
            <DialogDescription>
              {isEditing 
                ? 'Atualize as informações da credencial de serviço.' 
                : 'Adicione uma nova credencial de serviço ao sistema.'}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="nome_servico" className="text-right">
                  Nome do Serviço *
                </Label>
                <Input
                  id="nome_servico"
                  className="col-span-3"
                  value={formData.nome_servico}
                  onChange={(e) => setFormData({ ...formData, nome_servico: e.target.value })}
                  required
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="descricao" className="text-right">
                  Descrição
                </Label>
                <Textarea
                  id="descricao"
                  className="col-span-3"
                  value={formData.descricao}
                  onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                  rows={2}
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="categoria" className="text-right">
                  Categoria
                </Label>
                <Select 
                  value={formData.categoria} 
                  onValueChange={(value) => setFormData({ ...formData, categoria: value })}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Selecione a categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="comunicacao">Comunicação</SelectItem>
                    <SelectItem value="tecnologia">Tecnologia</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="financeiro">Financeiro</SelectItem>
                    <SelectItem value="operacional">Operacional</SelectItem>
                    <SelectItem value="vendas">Vendas</SelectItem>
                    <SelectItem value="outro">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="url" className="text-right">
                  URL
                </Label>
                <Input
                  id="url"
                  type="url"
                  className="col-span-3"
                  value={formData.url}
                  onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                  placeholder="https://exemplo.com"
                />
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="usuario" className="text-right">
                  Usuário
                </Label>
                <Input
                  id="usuario"
                  className="col-span-3"
                  value={formData.usuario}
                  onChange={(e) => setFormData({ ...formData, usuario: e.target.value })}
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="senha" className="text-right">
                  Senha
                </Label>
                <div className="col-span-3 relative">
                  <Input
                    id="senha"
                    type={showPasswords.edit ? "text" : "password"}
                    value={formData.senha}
                    onChange={(e) => setFormData({ ...formData, senha: e.target.value })}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6"
                    onClick={() => togglePasswordVisibility('edit')}
                  >
                    {showPasswords.edit ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="api_key" className="text-right">
                  API Key
                </Label>
                <Input
                  id="api_key"
                  className="col-span-3"
                  value={formData.api_key}
                  onChange={(e) => setFormData({ ...formData, api_key: e.target.value })}
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="api_secret" className="text-right">
                  API Secret
                </Label>
                <div className="col-span-3 relative">
                  <Input
                    id="api_secret"
                    type={showSecrets.edit ? "text" : "password"}
                    value={formData.api_secret}
                    onChange={(e) => setFormData({ ...formData, api_secret: e.target.value })}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6"
                    onClick={() => toggleSecretVisibility('edit')}
                  >
                    {showSecrets.edit ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="data_expiracao" className="text-right">
                  Data de Expiração
                </Label>
                <Input
                  id="data_expiracao"
                  type="date"
                  className="col-span-3"
                  value={formData.data_expiracao}
                  onChange={(e) => setFormData({ ...formData, data_expiracao: e.target.value })}
                />
              </div>
              
              <div className="grid grid-cols-4 items-start gap-4">
                <Label htmlFor="notas" className="text-right pt-2">
                  Notas
                </Label>
                <Textarea
                  id="notas"
                  className="col-span-3"
                  value={formData.notas}
                  onChange={(e) => setFormData({ ...formData, notas: e.target.value })}
                  rows={3}
                  placeholder="Informações adicionais sobre o serviço..."
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? (
                  <>
                    <Spinner size="small" className="mr-2" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    {isEditing ? 'Atualizar' : 'Salvar'}
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}