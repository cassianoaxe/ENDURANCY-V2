
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  FileText, 
  Search, 
  Filter, 
  Plus, 
  Calendar, 
  Download, 
  Upload, 
  Printer, 
  Tag, 
  Users, 
  MoreHorizontal, 
  FolderPlus, 
  Eye, 
  Edit, 
  Trash2, 
  Scale, 
  File, 
  Clock, 
  FileCheck, 
  FileLock2, 
  Lock, 
  AlertTriangle, 
  CheckCircle2, 
  FileText as FileTextIcon,
  Bookmark,
  Share,
  Building,
  User
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Dados simulados de documentos jurídicos
const mockDocumentos = [
  {
    id: "doc-001",
    titulo: "Contrato de Parceria Comercial - Distribuidora Medica Brasil",
    tipo: "contrato",
    categoria: "comercial",
    organizacao: "Distribuidora Medica Brasil",
    dataAssinatura: "2023-03-15",
    dataVencimento: "2025-03-15",
    status: "vigente",
    responsavel: "Dr. Carlos Mendes",
    valor: 125000.00,
    tags: ["distribuição", "comercial", "exclusividade"],
    confidencialidade: "alta",
    versao: "1.2",
    formato: "pdf",
    tamanho: "2.3 MB",
    ultimaAtualizacao: "2023-03-18",
    acessos: 12,
    observacoes: "Contrato com cláusula de exclusividade regional para distribuição de produtos derivados de cannabis no sudeste brasileiro.",
    alertas: [
      {
        tipo: "renovação",
        data: "2025-01-15",
        descricao: "Alerta para início do período de renegociação (60 dias antes do vencimento)"
      }
    ]
  },
  {
    id: "doc-002",
    titulo: "Termo de Confidencialidade - Fornecedores",
    tipo: "termo",
    categoria: "confidencialidade",
    organizacao: "Múltiplos",
    dataAssinatura: "2022-11-10",
    dataVencimento: "2027-11-10",
    status: "vigente",
    responsavel: "Dra. Maria Oliveira",
    valor: null,
    tags: ["confidencialidade", "fornecedores", "propriedade intelectual"],
    confidencialidade: "alta",
    versao: "2.0",
    formato: "pdf",
    tamanho: "1.5 MB",
    ultimaAtualizacao: "2023-02-05",
    acessos: 28,
    observacoes: "Termo padrão a ser assinado por todos os fornecedores com acesso a informações sensíveis sobre cultivo e produção.",
    alertas: []
  },
  {
    id: "doc-003",
    titulo: "Processo Administrativo ANVISA - Autorização Especial Simplificada",
    tipo: "processo",
    categoria: "regulatório",
    organizacao: "ANVISA",
    dataAssinatura: "2022-08-22",
    dataVencimento: "2024-08-22",
    status: "vigente",
    responsavel: "Dr. Carlos Mendes",
    valor: null,
    tags: ["anvisa", "autorização", "regulatório"],
    confidencialidade: "média",
    versao: "1.0",
    formato: "pdf",
    tamanho: "8.7 MB",
    ultimaAtualizacao: "2023-01-12",
    acessos: 35,
    observacoes: "Documentação completa do processo de Autorização Especial Simplificada para cultivo de cannabis com fins medicinais.",
    alertas: [
      {
        tipo: "renovação",
        data: "2024-05-22",
        descricao: "Início do processo de renovação (90 dias antes do vencimento)"
      }
    ]
  },
  {
    id: "doc-004",
    titulo: "Contrato de Prestação de Serviços - Consultoria Regulatória",
    tipo: "contrato",
    categoria: "serviços",
    organizacao: "RegCannabis Consultoria",
    dataAssinatura: "2023-02-01",
    dataVencimento: "2024-02-01",
    status: "vigente",
    responsavel: "Dra. Maria Oliveira",
    valor: 48000.00,
    tags: ["consultoria", "regulatório", "serviços"],
    confidencialidade: "média",
    versao: "1.0",
    formato: "pdf",
    tamanho: "1.2 MB",
    ultimaAtualizacao: "2023-02-01",
    acessos: 7,
    observacoes: "Contrato de prestação de serviços de consultoria para assuntos regulatórios e acompanhamento de processos junto à ANVISA.",
    alertas: [
      {
        tipo: "renovação",
        data: "2024-01-01",
        descricao: "Avaliar renovação (30 dias antes do vencimento)"
      }
    ]
  },
  {
    id: "doc-005",
    titulo: "Ata de Assembleia - Aprovação de Parceria Estratégica",
    tipo: "ata",
    categoria: "governança",
    organizacao: "Interna",
    dataAssinatura: "2023-04-10",
    dataVencimento: null,
    status: "vigente",
    responsavel: "Dr. João Silva",
    valor: null,
    tags: ["assembleia", "governança", "parceria"],
    confidencialidade: "alta",
    versao: "1.0",
    formato: "pdf",
    tamanho: "0.8 MB",
    ultimaAtualizacao: "2023-04-12",
    acessos: 15,
    observacoes: "Ata da assembleia que aprovou a parceria estratégica com laboratório internacional para desenvolvimento de novos produtos.",
    alertas: []
  },
  {
    id: "doc-006",
    titulo: "Processo Judicial - Importação de Sementes",
    tipo: "processo",
    categoria: "judicial",
    organizacao: "Justiça Federal",
    dataAssinatura: "2022-09-05",
    dataVencimento: null,
    status: "em andamento",
    responsavel: "Dr. Carlos Mendes",
    valor: null,
    tags: ["importação", "judicial", "sementes"],
    confidencialidade: "média",
    versao: "N/A",
    formato: "pdf",
    tamanho: "12.5 MB",
    ultimaAtualizacao: "2023-06-20",
    acessos: 42,
    observacoes: "Documentação completa do processo judicial para autorização de importação de sementes para fins de pesquisa e desenvolvimento.",
    alertas: [
      {
        tipo: "audiência",
        data: "2023-08-15",
        descricao: "Audiência de conciliação agendada"
      }
    ]
  },
  {
    id: "doc-007",
    titulo: "Política de Propriedade Intelectual",
    tipo: "política",
    categoria: "interno",
    organizacao: "Interna",
    dataAssinatura: "2022-05-10",
    dataVencimento: null,
    status: "vigente",
    responsavel: "Dra. Maria Oliveira",
    valor: null,
    tags: ["propriedade intelectual", "patentes", "interno"],
    confidencialidade: "média",
    versao: "2.1",
    formato: "pdf",
    tamanho: "1.8 MB",
    ultimaAtualizacao: "2023-01-15",
    acessos: 32,
    observacoes: "Política interna que estabelece diretrizes para proteção de propriedade intelectual e desenvolvimento de patentes.",
    alertas: [
      {
        tipo: "revisão",
        data: "2023-11-10",
        descricao: "Revisão bianual programada"
      }
    ]
  },
  {
    id: "doc-008",
    titulo: "Contrato de Transferência de Tecnologia - Técnicas de Extração",
    tipo: "contrato",
    categoria: "tecnologia",
    organizacao: "CannaExtract GmbH",
    dataAssinatura: "2023-01-20",
    dataVencimento: "2028-01-20",
    status: "vigente",
    responsavel: "Dr. João Silva",
    valor: 280000.00,
    tags: ["transferência", "tecnologia", "extração"],
    confidencialidade: "alta",
    versao: "1.0",
    formato: "pdf",
    tamanho: "3.2 MB",
    ultimaAtualizacao: "2023-01-25",
    acessos: 21,
    observacoes: "Contrato de transferência de tecnologia para técnicas avançadas de extração de canabinoides. Inclui treinamento e suporte técnico por 2 anos.",
    alertas: []
  }
];

export default function JuridicoDocumentos() {
  const [documentos, setDocumentos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDocumentos, setSelectedDocumentos] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterTipo, setFilterTipo] = useState("todos");
  const [filterCategoria, setFilterCategoria] = useState("todos");
  const [filterStatus, setFilterStatus] = useState("todos");
  const [currentTab, setCurrentTab] = useState("todos");
  const [sortBy, setSortBy] = useState("data");

  useEffect(() => {
    setTimeout(() => {
      setDocumentos(mockDocumentos);
      setIsLoading(false);
    }, 800);
  }, []);

  const filteredDocumentos = documentos.filter(doc => {
    const matchesSearch = searchQuery === "" || 
      doc.titulo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.observacoes.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesType = filterTipo === "todos" || doc.tipo === filterTipo;
    
    const matchesCategory = filterCategoria === "todos" || doc.categoria === filterCategoria;
    
    const matchesStatus = filterStatus === "todos" || doc.status === filterStatus;
    
    const matchesTab = currentTab === "todos" || 
      (currentTab === "alertas" && doc.alertas && doc.alertas.length > 0) ||
      (currentTab === "vencidos" && doc.dataVencimento && new Date(doc.dataVencimento) < new Date());
    
    return matchesSearch && matchesType && matchesCategory && matchesStatus && matchesTab;
  }).sort((a, b) => {
    if (sortBy === "data") {
      return new Date(b.dataAssinatura) - new Date(a.dataAssinatura);
    } else if (sortBy === "titulo") {
      return a.titulo.localeCompare(b.titulo);
    } else if (sortBy === "organizacao") {
      return a.organizacao.localeCompare(b.organizacao);
    }
    return 0;
  });

  const getTipoIcon = (tipo) => {
    switch (tipo) {
      case "contrato":
        return <FileCheck className="w-4 h-4 text-blue-500" />;
      case "termo":
        return <FileTextIcon className="w-4 h-4 text-purple-500" />;
      case "processo":
        return <Scale className="w-4 h-4 text-amber-500" />;
      case "ata":
        return <FileText className="w-4 h-4 text-green-500" />;
      case "política":
        return <FileLock2 className="w-4 h-4 text-red-500" />;
      default:
        return <File className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "vigente":
        return <Badge className="bg-green-100 text-green-800">Vigente</Badge>;
      case "em andamento":
        return <Badge className="bg-blue-100 text-blue-800">Em andamento</Badge>;
      case "vencido":
        return <Badge className="bg-red-100 text-red-800">Vencido</Badge>;
      case "pendente":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  const toggleDocumentoSelection = (id) => {
    if (selectedDocumentos.includes(id)) {
      setSelectedDocumentos(selectedDocumentos.filter(docId => docId !== id));
    } else {
      setSelectedDocumentos([...selectedDocumentos, id]);
    }
  };

  const selectAllDocumentos = () => {
    if (selectedDocumentos.length === filteredDocumentos.length) {
      setSelectedDocumentos([]);
    } else {
      setSelectedDocumentos(filteredDocumentos.map(doc => doc.id));
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('pt-BR', options);
  };

  const formatCurrency = (value) => {
    if (value === null || value === undefined) return "N/A";
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Documentos Jurídicos</h1>
          <p className="text-gray-500 mt-1">
            Gerencie todos os documentos jurídicos da organização
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Upload className="mr-2 h-4 w-4" />
            Importar
          </Button>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Novo Documento
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar documentos..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <Select value={filterTipo} onValueChange={setFilterTipo}>
          <SelectTrigger className="w-full md:w-40">
            <SelectValue placeholder="Tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os tipos</SelectItem>
            <SelectItem value="contrato">Contratos</SelectItem>
            <SelectItem value="termo">Termos</SelectItem>
            <SelectItem value="processo">Processos</SelectItem>
            <SelectItem value="ata">Atas</SelectItem>
            <SelectItem value="política">Políticas</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterCategoria} onValueChange={setFilterCategoria}>
          <SelectTrigger className="w-full md:w-44">
            <SelectValue placeholder="Categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todas as categorias</SelectItem>
            <SelectItem value="comercial">Comercial</SelectItem>
            <SelectItem value="confidencialidade">Confidencialidade</SelectItem>
            <SelectItem value="regulatório">Regulatório</SelectItem>
            <SelectItem value="serviços">Serviços</SelectItem>
            <SelectItem value="governança">Governança</SelectItem>
            <SelectItem value="judicial">Judicial</SelectItem>
            <SelectItem value="interno">Interno</SelectItem>
            <SelectItem value="tecnologia">Tecnologia</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full md:w-40">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os status</SelectItem>
            <SelectItem value="vigente">Vigente</SelectItem>
            <SelectItem value="em andamento">Em andamento</SelectItem>
            <SelectItem value="vencido">Vencido</SelectItem>
            <SelectItem value="pendente">Pendente</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs value={currentTab} onValueChange={setCurrentTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="todos">
            Todos
          </TabsTrigger>
          <TabsTrigger value="alertas" className="flex items-center gap-1">
            Alertas
            <Badge className="ml-1 bg-red-100 text-red-800">{documentos.filter(d => d.alertas && d.alertas.length > 0).length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="vencidos">
            Vencidos/A Vencer
          </TabsTrigger>
        </TabsList>

        <Card>
          <CardHeader className="pb-0">
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="select-all" 
                  checked={selectedDocumentos.length === filteredDocumentos.length && filteredDocumentos.length > 0}
                  onCheckedChange={selectAllDocumentos}
                />
                <Label htmlFor="select-all">Selecionar todos</Label>
                {selectedDocumentos.length > 0 && (
                  <Badge variant="outline" className="ml-2">
                    {selectedDocumentos.length} selecionados
                  </Badge>
                )}
              </div>
              
              <div className="flex flex-1 md:justify-end gap-2">
                {selectedDocumentos.length > 0 && (
                  <>
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share className="mr-2 h-4 w-4" />
                      Compartilhar
                    </Button>
                  </>
                )}
                
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Ordenar por" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="data">Data</SelectItem>
                    <SelectItem value="titulo">Título</SelectItem>
                    <SelectItem value="organizacao">Organização</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {filteredDocumentos.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <h3 className="text-lg font-medium text-gray-900">Nenhum documento encontrado</h3>
                <p className="text-gray-500 mt-1">
                  Não existem documentos que correspondam aos filtros aplicados.
                </p>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchQuery("");
                    setFilterTipo("todos");
                    setFilterCategoria("todos");
                    setFilterStatus("todos");
                    setCurrentTab("todos");
                  }}
                  className="mt-4"
                >
                  Limpar filtros
                </Button>
              </div>
            ) : (
              <div className="mt-4 space-y-4">
                {filteredDocumentos.map((doc) => (
                  <div 
                    key={doc.id}
                    className="flex gap-4 p-4 hover:bg-gray-50 transition-colors rounded-lg border"
                  >
                    <div className="flex items-start">
                      <Checkbox 
                        checked={selectedDocumentos.includes(doc.id)}
                        onCheckedChange={() => toggleDocumentoSelection(doc.id)}
                        className="mt-1"
                      />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mb-2">
                        <h3 className="font-medium text-gray-900 truncate">{doc.titulo}</h3>
                        <div className="flex items-center gap-2">
                          {getStatusBadge(doc.status)}
                          <Badge variant="outline" className="flex items-center gap-1.5">
                            <Calendar className="w-3 h-3" />
                            {formatDate(doc.dataAssinatura)}
                          </Badge>
                          {doc.dataVencimento && (
                            <Badge variant="outline" className={`flex items-center gap-1.5 ${
                              new Date(doc.dataVencimento) < new Date() ? "text-red-600 border-red-300" : ""
                            }`}>
                              <Clock className="w-3 h-3" />
                              Vence: {formatDate(doc.dataVencimento)}
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-2 mb-3">
                        <Badge className="bg-blue-100 text-blue-800 flex items-center gap-1.5">
                          {getTipoIcon(doc.tipo)}
                          <span className="capitalize">{doc.tipo}</span>
                        </Badge>
                        <Badge className="bg-purple-100 text-purple-800 capitalize">
                          {doc.categoria}
                        </Badge>
                        {doc.confidencialidade === "alta" && (
                          <Badge className="bg-red-100 text-red-800 flex items-center gap-1.5">
                            <Lock className="w-3 h-3" />
                            Confidencial
                          </Badge>
                        )}
                        {doc.valor && (
                          <Badge className="bg-green-100 text-green-800">
                            {formatCurrency(doc.valor)}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="text-gray-500 text-sm mb-3 line-clamp-2">
                        {doc.observacoes}
                      </div>
                      
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                        <div className="flex flex-wrap gap-1">
                          {doc.tags.map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs px-2 py-0.5">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                        
                        <div className="flex items-center text-gray-500 text-sm">
                          <div className="flex items-center mr-4">
                            <Building className="w-3.5 h-3.5 mr-1" />
                            <span>{doc.organizacao}</span>
                          </div>
                          <div className="flex items-center mr-4">
                            <User className="w-3.5 h-3.5 mr-1" />
                            <span>{doc.responsavel}</span>
                          </div>
                          <div className="flex items-center">
                            <Eye className="w-3.5 h-3.5 mr-1" />
                            <span>{doc.acessos} visitas</span>
                          </div>
                        </div>
                      </div>
                      
                      {doc.alertas && doc.alertas.length > 0 && (
                        <div className="mt-3 rounded-md bg-amber-50 border border-amber-200 p-2 text-sm">
                          <div className="flex items-center gap-1.5 text-amber-700 font-medium mb-1">
                            <AlertTriangle className="w-4 h-4" />
                            <span>Alertas</span>
                          </div>
                          <ul className="pl-6 list-disc text-amber-700">
                            {doc.alertas.map((alerta, index) => (
                              <li key={index} className="text-xs">
                                <strong>{alerta.tipo}</strong>: {alerta.descricao} ({formatDate(alerta.data)})
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                    
                    <div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="mr-2 h-4 w-4" />
                            <span>Visualizar</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Download className="mr-2 h-4 w-4" />
                            <span>Download</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            <span>Editar</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Share className="mr-2 h-4 w-4" />
                            <span>Compartilhar</span>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="mr-2 h-4 w-4" />
                            <span>Excluir</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </Tabs>
    </div>
  );
}
