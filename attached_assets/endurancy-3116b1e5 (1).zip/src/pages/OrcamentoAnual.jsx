import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Download,
  Upload,
  Edit,
  Trash2,
  Plus,
  Save,
  ChevronDown,
  ArrowUpDown,
  FileText,
  DollarSign,
  BarChart4,
  PieChart,
  Calendar,
  Filter,
  Check,
  X,
  Info,
  AlertCircle,
  FileSpreadsheet,
  Calculator
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from '@/components/ui/use-toast';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart as RechartsPieChart,
  Pie,
  Cell
} from 'recharts';

export default function OrcamentoAnual() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('planejamento');
  const [year, setYear] = useState(new Date().getFullYear());
  const [isEditing, setIsEditing] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const [dialogAction, setDialogAction] = useState('');
  const [compareActive, setCompareActive] = useState(false);
  const [compareYear, setCompareYear] = useState(year - 1);
  const [budgetData, setBudgetData] = useState(null);
  const [categoriesExpanded, setCategoriesExpanded] = useState({});
  const [editingCell, setEditingCell] = useState({ rowId: null, colId: null, value: '' });
  const [selectedMonths, setSelectedMonths] = useState([]);
  const [viewMode, setViewMode] = useState('monthly');

  // Dados simulados para o orçamento
  useEffect(() => {
    // Dados do orçamento simulados
    const data = {
      year: year,
      status: 'approved',
      created_by: 'admin@example.com',
      approved_by: 'finance_director@example.com',
      approval_date: '2023-12-15',
      total_revenue: 1200000,
      total_expenses: 980000,
      categories: [
        {
          id: 'revenue',
          name: 'Receitas',
          type: 'revenue',
          total: 1200000,
          subcategories: [
            {
              id: 'rev_sales',
              name: 'Vendas de Produtos',
              total: 850000,
              monthly: [70000, 71000, 72000, 70500, 71500, 70800, 69000, 71200, 72500, 69800, 70700, 71000]
            },
            {
              id: 'rev_services',
              name: 'Serviços',
              total: 350000,
              monthly: [28000, 29000, 29500, 30000, 29800, 29000, 28500, 29000, 29500, 29200, 29200, 29300]
            }
          ]
        },
        {
          id: 'operational',
          name: 'Despesas Operacionais',
          type: 'expense',
          total: 650000,
          subcategories: [
            {
              id: 'exp_payroll',
              name: 'Folha de Pagamento',
              total: 420000,
              monthly: [35000, 35000, 35000, 35000, 35000, 35000, 35000, 35000, 35000, 35000, 35000, 35000]
            },
            {
              id: 'exp_rent',
              name: 'Aluguel',
              total: 120000,
              monthly: [10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000]
            },
            {
              id: 'exp_utilities',
              name: 'Utilidades (Água, Luz, etc)',
              total: 60000,
              monthly: [5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000]
            },
            {
              id: 'exp_supplies',
              name: 'Materiais e Suprimentos',
              total: 50000,
              monthly: [4000, 4200, 4100, 4300, 4200, 4100, 4000, 4200, 4300, 4200, 4200, 4200]
            }
          ]
        },
        {
          id: 'administrative',
          name: 'Despesas Administrativas',
          type: 'expense',
          total: 180000,
          subcategories: [
            {
              id: 'exp_accounting',
              name: 'Contabilidade e Jurídico',
              total: 72000,
              monthly: [6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000, 6000]
            },
            {
              id: 'exp_marketing',
              name: 'Marketing e Publicidade',
              total: 60000,
              monthly: [5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000]
            },
            {
              id: 'exp_travel',
              name: 'Viagens e Representação',
              total: 48000,
              monthly: [4000, 4000, 4000, 4000, 4000, 4000, 4000, 4000, 4000, 4000, 4000, 4000]
            }
          ]
        },
        {
          id: 'financial',
          name: 'Despesas Financeiras',
          type: 'expense',
          total: 150000,
          subcategories: [
            {
              id: 'exp_interest',
              name: 'Juros e Empréstimos',
              total: 90000,
              monthly: [7500, 7500, 7500, 7500, 7500, 7500, 7500, 7500, 7500, 7500, 7500, 7500]
            },
            {
              id: 'exp_taxes',
              name: 'Impostos',
              total: 60000,
              monthly: [5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000]
            }
          ]
        }
      ]
    };

    setBudgetData(data);
    
    // Inicializa o estado de expansão das categorias
    const expandedState = {};
    data.categories.forEach(category => {
      expandedState[category.id] = false;
    });
    setCategoriesExpanded(expandedState);
    
  }, [year]);

  // Dados simulados para comparativos anuais
  const yearlyComparison = [
    { year: year - 2, revenue: 1000000, expenses: 850000, profit: 150000 },
    { year: year - 1, revenue: 1100000, expenses: 920000, profit: 180000 },
    { year: year, revenue: 1200000, expenses: 980000, profit: 220000 },
    { year: year + 1, revenue: 1300000, expenses: 1050000, profit: 250000, projected: true }
  ];

  // Dados simulados para comparativos mensais
  const monthlyComparison = [
    { month: 'Jan', prevYear: 95000, currentYear: 98000 },
    { month: 'Fev', prevYear: 100000, currentYear: 105000 },
    { month: 'Mar', prevYear: 90000, currentYear: 101000 },
    { month: 'Abr', prevYear: 100500, currentYear: 105500 },
    { month: 'Mai', prevYear: 98000, currentYear: 101500 },
    { month: 'Jun', prevYear: 99000, currentYear: 99800 },
    { month: 'Jul', prevYear: 95500, currentYear: 97500 },
    { month: 'Ago', prevYear: 96000, currentYear: 100200 },
    { month: 'Set', prevYear: 98000, currentYear: 102000 },
    { month: 'Out', prevYear: 97000, currentYear: 99000 },
    { month: 'Nov', prevYear: 99000, currentYear: 99900 },
    { month: 'Dez', prevYear: 98000, currentYear: 100300 }
  ];

  // Lista de meses para seleção
  const months = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  // Formatar números como moeda
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Obter dados para um período específico
  const getPeriodData = (data, period = 'total') => {
    if (period === 'total') return data;
    
    // Obter dados para um mês específico (0-11)
    if (typeof period === 'number' && period >= 0 && period <= 11) {
      const periodData = JSON.parse(JSON.stringify(data));
      periodData.total_revenue = 0;
      periodData.total_expenses = 0;

      periodData.categories.forEach(category => {
        category.total = 0;
        category.subcategories.forEach(subcat => {
          subcat.total = subcat.monthly[period];
          category.total += subcat.total;
        });
        
        if (category.type === 'revenue') {
          periodData.total_revenue += category.total;
        } else {
          periodData.total_expenses += category.total;
        }
      });

      return periodData;
    }
    
    return data;
  };

  // Calcular o progresso em relação ao orçamento
  const calculateProgress = (actual, budgeted) => {
    if (budgeted === 0) return 0;
    return (actual / budgeted) * 100;
  };

  // Cores para os gráficos
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

  // Funções para manipulação do orçamento
  const toggleCategoryExpand = (categoryId) => {
    setCategoriesExpanded({
      ...categoriesExpanded,
      [categoryId]: !categoriesExpanded[categoryId]
    });
  };

  const startCellEdit = (rowId, colId, value) => {
    if (!isEditing) return;
    setEditingCell({ rowId, colId, value: value || 0 });
  };

  const handleCellEdit = (e) => {
    setEditingCell({ ...editingCell, value: e.target.value });
  };

  const saveCellEdit = () => {
    // Aqui você implementaria a lógica para salvar os dados no backend
    toast({
      title: "Valor atualizado",
      description: "O valor do orçamento foi atualizado com sucesso.",
    });
    setEditingCell({ rowId: null, colId: null, value: '' });
  };

  const handleYearChange = (e) => {
    setYear(parseInt(e.target.value));
  };

  const toggleEdit = () => {
    if (isEditing) {
      // Aqui você implementaria a lógica para salvar os dados no backend
      toast({
        title: "Orçamento salvo",
        description: "Todas as alterações foram salvas com sucesso.",
      });
    }
    setIsEditing(!isEditing);
  };

  const handleExportPDF = () => {
    toast({
      title: "Exportando PDF",
      description: "O orçamento está sendo exportado para PDF.",
    });
  };

  const handleExportExcel = () => {
    toast({
      title: "Exportando Excel",
      description: "O orçamento está sendo exportado para Excel.",
    });
  };

  const handleMonthToggle = (monthIndex) => {
    if (selectedMonths.includes(monthIndex)) {
      setSelectedMonths(selectedMonths.filter(m => m !== monthIndex));
    } else {
      setSelectedMonths([...selectedMonths, monthIndex]);
    }
  };

  // Dados para o gráfico de distribuição de despesas
  const getExpenseDistributionData = () => {
    if (!budgetData) return [];
    
    return budgetData.categories
      .filter(category => category.type === 'expense')
      .map(category => ({
        name: category.name,
        value: category.total
      }));
  };

  // Calcular totais por tipo
  const calculateTotalsByType = (type) => {
    if (!budgetData) return 0;
    
    return budgetData.categories
      .filter(category => category.type === type)
      .reduce((total, category) => total + category.total, 0);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Orçamento Anual</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Planejamento e acompanhamento do orçamento
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Select value={year.toString()} onValueChange={(value) => setYear(parseInt(value))}>
            <SelectTrigger className="w-[100px]">
              <SelectValue placeholder="Ano" />
            </SelectTrigger>
            <SelectContent>
              {[year - 2, year - 1, year, year + 1].map((y) => (
                <SelectItem key={y} value={y.toString()}>
                  {y}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button variant="outline" size="icon" onClick={() => setCompareActive(!compareActive)}>
            {compareActive ? <Check className="h-4 w-4" /> : <ArrowUpDown className="h-4 w-4" />}
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <Download className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleExportPDF}>
                <FileText className="mr-2 h-4 w-4" />
                <span>Exportar PDF</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleExportExcel}>
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                <span>Exportar Excel</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="icon">
                <Upload className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Importar Orçamento</DialogTitle>
                <DialogDescription>
                  Selecione um arquivo Excel para importar dados do orçamento.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="file">Arquivo</Label>
                  <Input id="file" type="file" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="importYear">Ano</Label>
                  <Select defaultValue={year.toString()}>
                    <SelectTrigger id="importYear">
                      <SelectValue placeholder="Selecione o ano" />
                    </SelectTrigger>
                    <SelectContent>
                      {[year - 1, year, year + 1, year + 2].map((y) => (
                        <SelectItem key={y} value={y.toString()}>
                          {y}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline">Cancelar</Button>
                <Button>Importar</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          <Button 
            variant={isEditing ? "default" : "outline"} 
            onClick={toggleEdit}
          >
            {isEditing ? (
              <>
                <Save className="mr-2 h-4 w-4" />
                Salvar
              </>
            ) : (
              <>
                <Edit className="mr-2 h-4 w-4" />
                Editar
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Status do orçamento */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="text-sm font-medium text-muted-foreground">Receitas</div>
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                {formatCurrency(calculateTotalsByType('revenue'))}
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="text-sm font-medium text-muted-foreground">Despesas</div>
              <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                {formatCurrency(calculateTotalsByType('expense'))}
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="text-sm font-medium text-muted-foreground">Resultado</div>
              <div className="text-2xl font-bold">
                {formatCurrency(calculateTotalsByType('revenue') - calculateTotalsByType('expense'))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="planejamento">
            <Calculator className="mr-2 h-4 w-4" />
            Planejamento
          </TabsTrigger>
          <TabsTrigger value="analise">
            <BarChart4 className="mr-2 h-4 w-4" />
            Análise
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="planejamento" className="space-y-4">
          <div className="flex justify-between items-center">
            <div className="space-x-2">
              <Button
                variant={viewMode === 'monthly' ? 'default' : 'outline'}
                onClick={() => setViewMode('monthly')}
                size="sm"
              >
                Mensal
              </Button>
              <Button
                variant={viewMode === 'quarterly' ? 'default' : 'outline'}
                onClick={() => setViewMode('quarterly')}
                size="sm"
              >
                Trimestral
              </Button>
              <Button
                variant={viewMode === 'annual' ? 'default' : 'outline'}
                onClick={() => setViewMode('annual')}
                size="sm"
              >
                Anual
              </Button>
            </div>
            
            {viewMode === 'monthly' && (
              <div className="flex flex-wrap gap-1">
                {months.map((month, idx) => (
                  <Badge
                    key={idx}
                    variant={selectedMonths.includes(idx) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => handleMonthToggle(idx)}
                  >
                    {month.substring(0, 3)}
                  </Badge>
                ))}
              </div>
            )}
          </div>
          
          {budgetData && (
            <Card>
              <ScrollArea className="h-[600px]">
                <Table>
                  <TableHeader className="sticky top-0 bg-background">
                    <TableRow>
                      <TableHead className="w-[300px]">Categoria</TableHead>
                      {viewMode === 'monthly' && months.map((month, idx) => (
                        <TableHead key={idx} className="text-right" style={{display: selectedMonths.length > 0 && !selectedMonths.includes(idx) ? 'none' : ''}}>
                          {month.substring(0, 3)}
                        </TableHead>
                      ))}
                      {viewMode === 'quarterly' && ['T1', 'T2', 'T3', 'T4'].map((quarter, idx) => (
                        <TableHead key={idx} className="text-right">
                          {quarter}
                        </TableHead>
                      ))}
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {budgetData.categories.map((category) => (
                      <React.Fragment key={category.id}>
                        <TableRow className="font-medium">
                          <TableCell 
                            className="flex items-center cursor-pointer"
                            onClick={() => toggleCategoryExpand(category.id)}
                          >
                            <ChevronDown className={`mr-2 h-4 w-4 transition-transform ${categoriesExpanded[category.id] ? 'transform rotate-0' : 'transform -rotate-90'}`} />
                            {category.name}
                          </TableCell>
                          
                          {viewMode === 'monthly' && months.map((_, idx) => (
                            <TableCell key={idx} className="text-right" style={{display: selectedMonths.length > 0 && !selectedMonths.includes(idx) ? 'none' : ''}}>
                              {formatCurrency(category.subcategories.reduce((sum, sub) => sum + sub.monthly[idx], 0))}
                            </TableCell>
                          ))}
                          
                          {viewMode === 'quarterly' && [0, 1, 2, 3].map((quarter) => (
                            <TableCell key={quarter} className="text-right">
                              {formatCurrency(
                                category.subcategories.reduce((sum, sub) => {
                                  const start = quarter * 3;
                                  return sum + sub.monthly.slice(start, start + 3).reduce((a, b) => a + b, 0);
                                }, 0)
                              )}
                            </TableCell>
                          ))}
                          
                          <TableCell className="text-right font-bold">
                            {formatCurrency(category.total)}
                          </TableCell>
                        </TableRow>
                        
                        {categoriesExpanded[category.id] && category.subcategories.map((subcat) => (
                          <TableRow key={subcat.id} className="hover:bg-muted/50">
                            <TableCell className="pl-10">
                              {subcat.name}
                            </TableCell>
                            
                            {viewMode === 'monthly' && subcat.monthly.map((value, idx) => (
                              <TableCell key={idx} className="text-right" style={{display: selectedMonths.length > 0 && !selectedMonths.includes(idx) ? 'none' : ''}}>
                                {isEditing && editingCell.rowId === subcat.id && editingCell.colId === idx ? (
                                  <Input
                                    value={editingCell.value}
                                    onChange={handleCellEdit}
                                    onBlur={saveCellEdit}
                                    onKeyDown={(e) => e.key === 'Enter' && saveCellEdit()}
                                    className="w-[100px] ml-auto"
                                  />
                                ) : (
                                  <span 
                                    className={isEditing ? 'cursor-pointer hover:underline hover:text-primary' : ''}
                                    onClick={() => startCellEdit(subcat.id, idx, value)}
                                  >
                                    {formatCurrency(value)}
                                  </span>
                                )}
                              </TableCell>
                            ))}
                            
                            {viewMode === 'quarterly' && [0, 1, 2, 3].map((quarter) => (
                              <TableCell key={quarter} className="text-right">
                                {formatCurrency(
                                  subcat.monthly.slice(quarter * 3, quarter * 3 + 3).reduce((a, b) => a + b, 0)
                                )}
                              </TableCell>
                            ))}
                            
                            <TableCell className="text-right">
                              {formatCurrency(subcat.total)}
                            </TableCell>
                          </TableRow>
                        ))}
                      </React.Fragment>
                    ))}
                    
                    {/* Totals Row */}
                    <TableRow className="font-bold border-t">
                      <TableCell>TOTAL</TableCell>
                      
                      {viewMode === 'monthly' && months.map((_, idx) => (
                        <TableCell key={idx} className="text-right" style={{display: selectedMonths.length > 0 && !selectedMonths.includes(idx) ? 'none' : ''}}>
                          {formatCurrency(
                            budgetData.categories.reduce((sum, cat) => 
                              sum + cat.subcategories.reduce((catSum, sub) => catSum + sub.monthly[idx], 0), 0)
                          )}
                        </TableCell>
                      ))}
                      
                      {viewMode === 'quarterly' && [0, 1, 2, 3].map((quarter) => (
                        <TableCell key={quarter} className="text-right">
                          {formatCurrency(
                            budgetData.categories.reduce((sum, cat) => 
                              sum + cat.subcategories.reduce((catSum, sub) => {
                                const start = quarter * 3;
                                return catSum + sub.monthly.slice(start, start + 3).reduce((a, b) => a + b, 0);
                              }, 0), 0)
                          )}
                        </TableCell>
                      ))}
                      
                      <TableCell className="text-right">
                        {formatCurrency(budgetData.categories.reduce((sum, cat) => sum + cat.total, 0))}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </ScrollArea>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="analise" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Comparativo Anual */}
            <Card>
              <CardHeader>
                <CardTitle>Comparativo Anual</CardTitle>
                <CardDescription>Comparação entre receitas e despesas por ano</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={yearlyComparison}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="year" />
                      <YAxis 
                        tickFormatter={(value) => 
                          new Intl.NumberFormat('pt-BR', {
                            notation: 'compact',
                            compactDisplay: 'short',
                            currency: 'BRL'
                          }).format(value)
                        } 
                      />
                      <Tooltip formatter={(value) => [formatCurrency(value), ""]} />
                      <Legend />
                      <Bar dataKey="revenue" name="Receitas" fill="#4ade80" />
                      <Bar dataKey="expenses" name="Despesas" fill="#f87171" />
                      <Bar dataKey="profit" name="Resultado" fill="#60a5fa" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Distribuição de Despesas */}
            <Card>
              <CardHeader>
                <CardTitle>Distribuição de Despesas</CardTitle>
                <CardDescription>Divisão de despesas por categoria</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={getExpenseDistributionData()}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {getExpenseDistributionData().map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [formatCurrency(value), ""]} />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Comparativo Mensal */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Comparativo Mensal</CardTitle>
                <CardDescription>Comparação entre anos por mês</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={monthlyComparison}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis 
                        tickFormatter={(value) => 
                          new Intl.NumberFormat('pt-BR', {
                            notation: 'compact',
                            compactDisplay: 'short',
                            currency: 'BRL'
                          }).format(value)
                        } 
                      />
                      <Tooltip formatter={(value) => [formatCurrency(value), ""]} />
                      <Legend />
                      <Line type="monotone" dataKey="prevYear" name={`${year-1}`} stroke="#8884d8" activeDot={{ r: 8 }} />
                      <Line type="monotone" dataKey="currentYear" name={`${year}`} stroke="#82ca9d" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}