
import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Plus, 
  FileText, 
  Microscope, 
  Brain, 
  Search, 
  Filter,
  BarChart,
  Calendar,
  User,
  Book,
  Award,
  Edit,
  Trash2,
  ExternalLink,
  CheckCircle,
  XCircle
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

// Mock data for development
const mockGrupos = [
  {
    id: "1",
    nome: "Grupo de Pesquisa em Neurologia Clínica",
    area_atuacao: "Neurologia",
    descricao: "Pesquisa focada em tratamentos inovadores para epilepsia e doenças neurodegenerativas",
    status: "ativo",
    lider: {
      nome: "Dra. Maria Santos",
      email: "maria.santos@exemplo.com",
      telefone: "(11) 98765-4321",
      especialidade: "Neurologia"
    },
    membros: [
      {
        id: "m1",
        nome: "João Silva",
        funcao: "Pesquisador Sênior",
        email: "joao.silva@exemplo.com",
        pesquisas: 3,
        publicacoes: 12
      },
      {
        id: "m2",
        nome: "Ana Oliveira",
        funcao: "Pesquisador Júnior",
        email: "ana.oliveira@exemplo.com",
        pesquisas: 2,
        publicacoes: 5
      }
    ],
    pesquisas_ativas: 4,
    publicacoes: 23
  },
  {
    id: "2",
    nome: "Grupo de Estudos em Dor Crônica",
    area_atuacao: "Dor Crônica",
    descricao: "Investigação de novos protocolos para tratamento de dor crônica",
    status: "ativo",
    lider: {
      nome: "Dr. Carlos Mendes",
      email: "carlos.mendes@exemplo.com",
      telefone: "(11) 91234-5678",
      especialidade: "Anestesiologia"
    },
    membros: [
      {
        id: "m3",
        nome: "Patricia Lima",
        funcao: "Coordenadora de Pesquisa",
        email: "patricia.lima@exemplo.com",
        pesquisas: 4,
        publicacoes: 8
      }
    ],
    pesquisas_ativas: 3,
    publicacoes: 15
  },
  {
    id: "3",
    nome: "Núcleo de Pesquisa em Psiquiatria",
    area_atuacao: "Psiquiatria",
    descricao: "Estudos sobre tratamentos alternativos para transtornos de ansiedade e depressão",
    status: "inativo",
    lider: {
      nome: "Dr. Ricardo Almeida",
      email: "ricardo.almeida@exemplo.com",
      telefone: "(11) 97777-8888",
      especialidade: "Psiquiatria"
    },
    membros: [
      {
        id: "m4",
        nome: "Mariana Costa",
        funcao: "Pesquisadora Associada",
        email: "mariana.costa@exemplo.com",
        pesquisas: 1,
        publicacoes: 3
      }
    ],
    pesquisas_ativas: 0,
    publicacoes: 8
  }
];

export default function GruposPesquisa() {
  const [grupos, setGrupos] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [areaFilter, setAreaFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedGrupo, setSelectedGrupo] = useState(null);

  useEffect(() => {
    loadGrupos();
  }, []);

  const loadGrupos = async () => {
    setIsLoading(true);
    try {
      // Simular carregamento de dados
      await new Promise(resolve => setTimeout(resolve, 1000));
      setGrupos(mockGrupos);
    } catch (error) {
      console.error("Erro ao carregar grupos:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = (grupo) => {
    setSelectedGrupo(grupo);
    setShowDeleteDialog(true);
  };

  const confirmDelete = async () => {
    try {
      const newGrupos = grupos.filter(g => g.id !== selectedGrupo.id);
      setGrupos(newGrupos);
      setShowDeleteDialog(false);
    } catch (error) {
      console.error("Erro ao deletar grupo:", error);
    }
  };

  const filteredGrupos = grupos.filter(grupo => {
    const matchesSearch = grupo.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         grupo.area_atuacao.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesArea = areaFilter === 'all' || grupo.area_atuacao === areaFilter;
    const matchesStatus = statusFilter === 'all' || grupo.status === statusFilter;
    return matchesSearch && matchesArea && matchesStatus;
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold">Grupos de Pesquisa</h1>
          <p className="text-muted-foreground">Gerencie os grupos de pesquisa e seus membros</p>
        </div>
        <Link to={createPageUrl("NovoGrupoPesquisa")}>
          <Button className="bg-green-600 hover:bg-green-700">
            <Plus className="w-4 h-4 mr-2" />
            Novo Grupo
          </Button>
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar grupos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={areaFilter} onValueChange={setAreaFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Área de Atuação" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as Áreas</SelectItem>
            <SelectItem value="Neurologia">Neurologia</SelectItem>
            <SelectItem value="Psiquiatria">Psiquiatria</SelectItem>
            <SelectItem value="Dor Crônica">Dor Crônica</SelectItem>
            <SelectItem value="Oncologia">Oncologia</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Status</SelectItem>
            <SelectItem value="ativo">Ativo</SelectItem>
            <SelectItem value="inativo">Inativo</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          [...Array(3)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 rounded"></div>
                  <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          filteredGrupos.map((grupo) => (
            <Card key={grupo.id} className="overflow-hidden">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{grupo.nome}</CardTitle>
                    <CardDescription className="mt-1">{grupo.area_atuacao}</CardDescription>
                  </div>
                  <Badge variant={grupo.status === 'ativo' ? 'default' : 'secondary'}>
                    {grupo.status === 'ativo' ? 'Ativo' : 'Inativo'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  {grupo.descricao}
                </p>
                
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium">Líder:</span>
                    <span className="text-sm">{grupo.lider.nome}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium">Membros:</span>
                    <span className="text-sm">{grupo.membros.length}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Microscope className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium">Pesquisas Ativas:</span>
                    <span className="text-sm">{grupo.pesquisas_ativas}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Book className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium">Publicações:</span>
                    <span className="text-sm">{grupo.publicacoes}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 dark:bg-gray-800/50">
                <div className="flex justify-between items-center w-full">
                  <Link to={`${createPageUrl("GrupoPesquisa")}/${grupo.id}/membros`}>
                    <Button variant="ghost" size="sm">
                      <Users className="w-4 h-4 mr-2" />
                      Membros
                    </Button>
                  </Link>
                  <div className="flex gap-2">
                    <Link to={`${createPageUrl("EditarGrupoPesquisa")}/${grupo.id}`}>
                      <Button variant="ghost" size="sm">
                        <Edit className="w-4 h-4" />
                      </Button>
                    </Link>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleDelete(grupo)}
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))
        )}
      </div>

      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir o grupo de pesquisa "{selectedGrupo?.nome}"? 
              Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmDelete}>
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
