import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  ArrowLeft,
  Save,
  Upload,
  CalendarIcon,
  Building,
  User,
  Tag,
  FileText,
  DollarSign,
  CheckCircle,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";

export default function NovoLancamento() {
  const navigate = useNavigate();
  const [data, setData] = useState({
    tipo: "receita",
    descricao: "",
    valor: "",
    data: new Date(),
    categoria: "",
    subCategoria: "",
    pessoa: "",
    formaPagamento: "",
    centrosCusto: "",
    documentoNumero: "",
    documentoTipo: "recibo",
    observacoes: "",
    comprovante: null,
    status: "efetivado"
  });
  
  const handleCancel = () => {
    navigate(-1);
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validação básica
    if (!data.descricao || !data.valor || !data.categoria) {
      toast({
        title: "Dados incompletos",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Lançamento criado com sucesso",
      description: `${data.tipo === 'receita' ? 'Receita' : 'Despesa'} de R$ ${parseFloat(data.valor).toFixed(2)} registrada.`
    });
    
    navigate(createPageUrl("FinanceiroAssociacao"));
  };

  // Listas de dados para os selects
  const categorias = {
    receita: ["Anuidades", "Doações", "Eventos", "Serviços", "Financeiras", "Outras Receitas"],
    despesa: ["Pessoal", "Administrativo", "Ocupação", "Eventos", "Financeiras", "Utilidades", "Fornecedores", "Outras Despesas"]
  };
  
  const subCategorias = {
    "Anuidades": ["Regular", "Novos Associados", "Renovação"],
    "Doações": ["Pessoa Física", "Pessoa Jurídica", "Programada", "Esporádica"],
    "Eventos": ["Inscrição", "Patrocínio", "Venda de Produtos"],
    "Pessoal": ["Salários", "Benefícios", "FGTS", "INSS", "Serviços Temporários"],
    "Administrativo": ["Material de Escritório", "Serviços Contábeis", "Serviços Jurídicos", "Tecnologia"],
    "Ocupação": ["Aluguel", "Condomínio", "IPTU", "Manutenção", "Limpeza", "Segurança"],
    "Utilidades": ["Energia", "Água", "Internet", "Telefonia"]
  };
  
  const pessoas = ["Associação (Própria)", "Departamento Financeiro", "Associados", "Fornecedores", "Funcionários", "Doadores", "Outros"];
  
  const formasPagamento = ["Transferência", "Boleto", "Pix", "Cartão de Crédito", "Cartão de Débito", "Dinheiro"];
  
  const centrosCusto = ["Administrativo", "Eventos", "Projetos Sociais", "Marketing", "Operacional"];
  
  const tiposDocumento = ["Nota Fiscal", "Recibo", "Fatura", "Boleto", "Contrato", "Outro"];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" onClick={handleCancel} className="h-8 w-8 p-0">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">Novo Lançamento Financeiro</h1>
      </div>

      <form onSubmit={handleSubmit}>
        <Tabs defaultValue="info-basicas">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="info-basicas">Informações Básicas</TabsTrigger>
            <TabsTrigger value="info-detalhadas">Informações Detalhadas</TabsTrigger>
          </TabsList>
          
          <TabsContent value="info-basicas" className="space-y-6 mt-6">
            <Card className="border-t-4 border-t-blue-500">
              <CardHeader>
                <CardTitle>Informações do Lançamento</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="space-y-1 flex-1">
                    <Label>Tipo de Lançamento</Label>
                    <RadioGroup 
                      value={data.tipo} 
                      onValueChange={(value) => setData({...data, tipo: value, categoria: ""})}
                      className="flex gap-6 pt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="receita" id="receita" />
                        <Label 
                          htmlFor="receita" 
                          className={`font-medium cursor-pointer ${data.tipo === 'receita' ? 'text-green-600' : ''}`}
                        >
                          Receita
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="despesa" id="despesa" />
                        <Label 
                          htmlFor="despesa" 
                          className={`font-medium cursor-pointer ${data.tipo === 'despesa' ? 'text-red-600' : ''}`}
                        >
                          Despesa
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div className="space-y-1 flex-1">
                    <Label>Status</Label>
                    <RadioGroup 
                      value={data.status} 
                      onValueChange={(value) => setData({...data, status: value})}
                      className="flex gap-6 pt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="efetivado" id="efetivado" />
                        <Label 
                          htmlFor="efetivado" 
                          className={`font-medium cursor-pointer ${data.status === 'efetivado' ? 'text-blue-600' : ''}`}
                        >
                          Efetivado
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="previsto" id="previsto" />
                        <Label 
                          htmlFor="previsto" 
                          className={`font-medium cursor-pointer ${data.status === 'previsto' ? 'text-amber-600' : ''}`}
                        >
                          Previsto
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="descricao">Descrição <span className="text-red-500">*</span></Label>
                    <Input
                      id="descricao"
                      value={data.descricao}
                      onChange={(e) => setData({...data, descricao: e.target.value})}
                      placeholder="Descreva o lançamento"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="valor">Valor <span className="text-red-500">*</span></Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                        R$
                      </span>
                      <Input
                        id="valor"
                        type="number"
                        step="0.01"
                        value={data.valor}
                        onChange={(e) => setData({...data, valor: e.target.value})}
                        placeholder="0,00"
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Data do Lançamento <span className="text-red-500">*</span></Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {data.data ? format(data.data, "PPP", { locale: ptBR }) : "Selecione uma data"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={data.data}
                          onSelect={(date) => setData({...data, data: date})}
                          locale={ptBR}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="categoria">Categoria <span className="text-red-500">*</span></Label>
                    <Select 
                      value={data.categoria} 
                      onValueChange={(value) => setData({...data, categoria: value})}
                      required
                    >
                      <SelectTrigger id="categoria">
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categorias[data.tipo].map((cat) => (
                          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="formaPagamento">Forma de Pagamento/Recebimento</Label>
                    <Select 
                      value={data.formaPagamento} 
                      onValueChange={(value) => setData({...data, formaPagamento: value})}
                    >
                      <SelectTrigger id="formaPagamento">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {formasPagamento.map((fp) => (
                          <SelectItem key={fp} value={fp}>{fp}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="pessoa">Pessoa/Entidade</Label>
                    <Select 
                      value={data.pessoa} 
                      onValueChange={(value) => setData({...data, pessoa: value})}
                    >
                      <SelectTrigger id="pessoa">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {pessoas.map((p) => (
                          <SelectItem key={p} value={p}>{p}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="info-detalhadas" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Informações Detalhadas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="subCategoria">Subcategoria</Label>
                    <Select 
                      value={data.subCategoria} 
                      onValueChange={(value) => setData({...data, subCategoria: value})}
                      disabled={!subCategorias[data.categoria]}
                    >
                      <SelectTrigger id="subCategoria">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {data.categoria && subCategorias[data.categoria] 
                          ? subCategorias[data.categoria].map((sub) => (
                              <SelectItem key={sub} value={sub}>{sub}</SelectItem>
                            ))
                          : null
                        }
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="centrosCusto">Centro de Custo</Label>
                    <Select 
                      value={data.centrosCusto} 
                      onValueChange={(value) => setData({...data, centrosCusto: value})}
                    >
                      <SelectTrigger id="centrosCusto">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {centrosCusto.map((cc) => (
                          <SelectItem key={cc} value={cc}>{cc}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="documentoTipo">Tipo de Documento</Label>
                    <Select 
                      value={data.documentoTipo} 
                      onValueChange={(value) => setData({...data, documentoTipo: value})}
                    >
                      <SelectTrigger id="documentoTipo">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {tiposDocumento.map((td) => (
                          <SelectItem key={td} value={td}>{td}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="documentoNumero">Número do Documento</Label>
                    <Input
                      id="documentoNumero"
                      value={data.documentoNumero}
                      onChange={(e) => setData({...data, documentoNumero: e.target.value})}
                      placeholder="Ex: NF-123456"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea
                    id="observacoes"
                    value={data.observacoes}
                    onChange={(e) => setData({...data, observacoes: e.target.value})}
                    placeholder="Observações adicionais sobre o lançamento"
                    rows={3}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="comprovante">Anexar Comprovante</Label>
                  <div className="flex items-center gap-4">
                    <Button type="button" variant="outline">
                      <Upload className="mr-2 h-4 w-4" />
                      Selecionar arquivo
                    </Button>
                    <p className="text-sm text-gray-500">
                      {data.comprovante ? data.comprovante.name : "Nenhum arquivo selecionado"}
                    </p>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Formatos aceitos: PDF, JPG, PNG (máx. 5MB)
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <div className="flex justify-end gap-4 mt-6">
          <Button type="button" variant="outline" onClick={handleCancel}>
            <X className="mr-2 h-4 w-4" />
            Cancelar
          </Button>
          <Button type="submit">
            <Save className="mr-2 h-4 w-4" />
            Salvar Lançamento
          </Button>
        </div>
      </form>
    </div>
  );
}