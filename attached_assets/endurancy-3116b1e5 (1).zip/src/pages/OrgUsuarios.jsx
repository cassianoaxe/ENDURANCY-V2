import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea"; 
import { toast } from "@/components/ui/use-toast";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Users,
  UserPlus,
  Send,
  Building2,
  LayoutGrid,
  Plus,
  Mail,
  Search,
  Filter,
  MoreVertical,
  Edit,
  Trash,
  CheckCircle,
  XCircle
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function OrgUsuarios() {
  const [activeTab, setActiveTab] = useState("users");
  
  // Mock users data
  const [users, setUsers] = useState([
    { id: 1, name: "João Silva", email: "joao@exemplo.com", role: "admin", department: "TI", sector: "Desenvolvimento", status: "active" },
    { id: 2, name: "Maria Santos", email: "maria@exemplo.com", role: "user", department: "Marketing", sector: "Design", status: "active" },
    { id: 3, name: "Carlos Oliveira", email: "carlos@exemplo.com", role: "manager", department: "Vendas", sector: "Comercial", status: "active" },
    { id: 4, name: "Ana Pereira", email: "ana@exemplo.com", role: "user", department: "RH", sector: "Recrutamento", status: "active" },
  ]);
  
  const [filteredUsers, setFilteredUsers] = useState(users);
  
  // Mock invitations data
  const [invitations, setInvitations] = useState([
    { id: 1, email: "novo@exemplo.com", name: "Novo Usuário", department: "Vendas", sector: "Comercial", status: "pending", date: "2024-01-20" },
    { id: 2, email: "amanda@exemplo.com", name: "Amanda Silva", department: "Marketing", sector: "Social Media", status: "pending", date: "2024-01-25" },
  ]);
  
  // Mock departments data
  const [departments, setDepartments] = useState([
    { id: 1, name: "TI", description: "Tecnologia da Informação", sectors: ["Desenvolvimento", "Infraestrutura"] },
    { id: 2, name: "Marketing", description: "Marketing e Comunicação", sectors: ["Design", "Social Media"] },
    { id: 3, name: "Vendas", description: "Vendas e Comercial", sectors: ["Comercial", "Suporte ao Cliente"] },
    { id: 4, name: "RH", description: "Recursos Humanos", sectors: ["Recrutamento", "Treinamento"] },
  ]);
  
  // Mock sectors data
  const [sectors, setSectors] = useState([
    { id: 1, name: "Desenvolvimento", departmentId: 1, description: "Desenvolvimento de Software" },
    { id: 2, name: "Infraestrutura", departmentId: 1, description: "Infraestrutura de TI" },
    { id: 3, name: "Design", departmentId: 2, description: "Design Gráfico e UI/UX" },
    { id: 4, name: "Social Media", departmentId: 2, description: "Gestão de Redes Sociais" },
    { id: 5, name: "Comercial", departmentId: 3, description: "Vendas e Negociações" },
    { id: 6, name: "Suporte ao Cliente", departmentId: 3, description: "Atendimento e Suporte" },
    { id: 7, name: "Recrutamento", departmentId: 4, description: "Seleção e Contratação" },
    { id: 8, name: "Treinamento", departmentId: 4, description: "Capacitação e Desenvolvimento" },
  ]);

  // State for dialog controls and current user
  const [currentUser, setCurrentUser] = useState(null);
  const [showDeleteUserDialog, setShowDeleteUserDialog] = useState(false);
  const [showEditUserDialog, setShowEditUserDialog] = useState(false);
  const [showAddUserDialog, setShowAddUserDialog] = useState(false);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [showAddDepartmentDialog, setShowAddDepartmentDialog] = useState(false);
  const [showAddSectorDialog, setShowAddSectorDialog] = useState(false);

  // State for new user/invite form
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    role: "user",
    department: "",
    sector: "",
    status: "active"
  });

  // State for new invitation form
  const [newInvitation, setNewInvitation] = useState({
    name: "",
    email: "",
    department: "",
    sector: "",
    role: "user",
    message: ""
  });

  // State for search filters
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [roleFilter, setRoleFilter] = useState("all");

  // Form state for department/sector
  const [newDepartment, setNewDepartment] = useState({
    name: "",
    description: ""
  });

  const [newSector, setNewSector] = useState({
    name: "",
    description: "",
    departmentId: ""
  });

  // Filter users when search or filters change
  useEffect(() => {
    let filtered = [...users];
    
    // Apply search query filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(user => 
        user.name.toLowerCase().includes(query) || 
        user.email.toLowerCase().includes(query)
      );
    }
    
    // Apply department filter
    if (departmentFilter !== "all") {
      filtered = filtered.filter(user => user.department === departmentFilter);
    }
    
    // Apply role filter
    if (roleFilter !== "all") {
      filtered = filtered.filter(user => user.role === roleFilter);
    }
    
    setFilteredUsers(filtered);
  }, [users, searchQuery, departmentFilter, roleFilter]);

  // Handle form submissions
  const handleAddUser = () => {
    setNewUser({
      name: "",
      email: "",
      role: "user",
      department: "",
      sector: "",
      status: "active"
    });
    setShowAddUserDialog(true);
  };

  const handleSubmitAddUser = () => {
    // Validate form
    if (!newUser.name || !newUser.email || !newUser.department || !newUser.sector) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }

    // Add new user
    const newId = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
    const userToAdd = {
      ...newUser,
      id: newId
    };

    setUsers(prevUsers => [...prevUsers, userToAdd]);
    setShowAddUserDialog(false);
    
    toast({
      title: "Usuário adicionado",
      description: `O usuário ${newUser.name} foi adicionado com sucesso.`
    });
  };

  const handleInviteUser = () => {
    setNewInvitation({
      name: "",
      email: "",
      department: "",
      sector: "",
      role: "user",
      message: ""
    });
    setShowInviteDialog(true);
  };

  const handleSubmitInvite = () => {
    // Validate form
    if (!newInvitation.email || !newInvitation.department || !newInvitation.sector) {
      toast({
        title: "Erro",
        description: "Preencha pelo menos o email, departamento e setor.",
        variant: "destructive"
      });
      return;
    }

    // Add new invitation
    const newId = invitations.length > 0 ? Math.max(...invitations.map(i => i.id)) + 1 : 1;
    const invitationToAdd = {
      ...newInvitation,
      id: newId,
      status: "pending",
      date: new Date().toISOString().split('T')[0]
    };

    setInvitations(prevInvitations => [...prevInvitations, invitationToAdd]);
    setShowInviteDialog(false);
    
    toast({
      title: "Convite enviado",
      description: `O convite para ${newInvitation.email} foi enviado com sucesso.`
    });
  };

  const handleEditUser = (user) => {
    setCurrentUser(user);
    setNewUser({
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department,
      sector: user.sector,
      status: user.status
    });
    setShowEditUserDialog(true);
  };

  const handleSubmitEditUser = () => {
    if (!newUser.name || !newUser.email || !newUser.department || !newUser.sector) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }

    setUsers(prevUsers => 
      prevUsers.map(user => 
        user.id === currentUser.id ? { ...user, ...newUser } : user
      )
    );
    setShowEditUserDialog(false);
    setCurrentUser(null);
    
    toast({
      title: "Usuário atualizado",
      description: `As informações de ${newUser.name} foram atualizadas com sucesso.`
    });
  };

  const handleDeleteUser = (user) => {
    setCurrentUser(user);
    setShowDeleteUserDialog(true);
  };

  const confirmDeleteUser = () => {
    setUsers(prevUsers => prevUsers.filter(user => user.id !== currentUser.id));
    setShowDeleteUserDialog(false);
    
    toast({
      title: "Usuário removido",
      description: `O usuário ${currentUser.name} foi removido com sucesso.`
    });
    
    setCurrentUser(null);
  };

  const handleAddDepartment = () => {
    setNewDepartment({
      name: "",
      description: ""
    });
    setShowAddDepartmentDialog(true);
  };

  const handleSubmitAddDepartment = () => {
    if (!newDepartment.name) {
      toast({
        title: "Erro",
        description: "O nome do departamento é obrigatório.",
        variant: "destructive"
      });
      return;
    }

    const newId = departments.length > 0 ? Math.max(...departments.map(d => d.id)) + 1 : 1;
    const departmentToAdd = {
      ...newDepartment,
      id: newId,
      sectors: []
    };

    setDepartments(prevDepartments => [...prevDepartments, departmentToAdd]);
    setShowAddDepartmentDialog(false);
    
    toast({
      title: "Departamento adicionado",
      description: `O departamento ${newDepartment.name} foi adicionado com sucesso.`
    });
  };

  const handleAddSector = () => {
    setNewSector({
      name: "",
      description: "",
      departmentId: ""
    });
    setShowAddSectorDialog(true);
  };

  const handleSubmitAddSector = () => {
    if (!newSector.name || !newSector.departmentId) {
      toast({
        title: "Erro",
        description: "O nome do setor e o departamento são obrigatórios.",
        variant: "destructive"
      });
      return;
    }

    const newId = sectors.length > 0 ? Math.max(...sectors.map(s => s.id)) + 1 : 1;
    const sectorToAdd = {
      ...newSector,
      id: newId,
      departmentId: parseInt(newSector.departmentId, 10)
    };

    setSectors(prevSectors => [...prevSectors, sectorToAdd]);
    
    // Update the departments sectors array
    setDepartments(prevDepartments => 
      prevDepartments.map(dept => 
        dept.id === parseInt(newSector.departmentId, 10) 
          ? { ...dept, sectors: [...dept.sectors, newSector.name] } 
          : dept
      )
    );
    
    setShowAddSectorDialog(false);
    
    toast({
      title: "Setor adicionado",
      description: `O setor ${newSector.name} foi adicionado com sucesso.`
    });
  };

  const cancelInvitation = (id) => {
    setInvitations(prevInvitations => prevInvitations.filter(invitation => invitation.id !== id));
    
    toast({
      title: "Convite cancelado",
      description: "O convite foi cancelado com sucesso."
    });
  };

  // List rendering functions
  const renderUsersList = () => {
    if (filteredUsers.length === 0) {
      return (
        <div className="p-8 text-center">
          <p className="text-gray-500">Nenhum usuário encontrado com os filtros atuais.</p>
        </div>
      );
    }

    return (
      <div className="divide-y">
        {filteredUsers.map((user) => (
          <div key={user.id} className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-4">
              <div>
                <p className="font-medium">{user.name}</p>
                <p className="text-sm text-gray-500">{user.email}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">{user.department} - {user.sector}</span>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                user.role === 'admin' ? 'bg-blue-100 text-blue-800' :
                user.role === 'manager' ? 'bg-purple-100 text-purple-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {user.role === 'admin' ? 'Administrador' :
                 user.role === 'manager' ? 'Gerente' : 'Usuário'}
              </span>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Ações</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => handleEditUser(user)}>
                    <Edit className="mr-2 h-4 w-4" />
                    Editar
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleDeleteUser(user)} className="text-red-600">
                    <Trash className="mr-2 h-4 w-4" />
                    Remover
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderInvitationsList = () => {
    if (invitations.length === 0) {
      return (
        <div className="p-8 text-center">
          <p className="text-gray-500">Nenhum convite pendente.</p>
        </div>
      );
    }

    return (
      <div className="divide-y">
        {invitations.map((invitation) => (
          <div key={invitation.id} className="flex items-center justify-between p-4">
            <div>
              <p className="font-medium">{invitation.email}</p>
              <p className="text-sm text-gray-500">
                {invitation.name && `${invitation.name} • `}
                {invitation.department} - {invitation.sector}
              </p>
              <p className="text-xs text-gray-400">Enviado em: {invitation.date}</p>
            </div>
            <div className="flex items-center space-x-2">
              {invitation.status === 'pending' ? (
                <span className="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">
                  Pendente
                </span>
              ) : (
                <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                  Aceito
                </span>
              )}
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-red-600"
                onClick={() => cancelInvitation(invitation.id)}
              >
                <XCircle className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderDepartmentsList = () => {
    if (departments.length === 0) {
      return (
        <div className="p-8 text-center">
          <p className="text-gray-500">Nenhum departamento cadastrado.</p>
        </div>
      );
    }

    return (
      <div className="grid gap-4">
        {departments.map((department) => (
          <Card key={department.id}>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>{department.name}</CardTitle>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem>
                      <Edit className="mr-2 h-4 w-4" />
                      Editar
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-red-600">
                      <Trash className="mr-2 h-4 w-4" />
                      Remover
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500">{department.description}</p>
              <div className="mt-4">
                <h4 className="text-sm font-medium mb-2">Setores:</h4>
                <div className="flex flex-wrap gap-2">
                  {department.sectors.length > 0 ? (
                    department.sectors.map((sector, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 text-xs bg-gray-100 text-gray-800 rounded-full"
                      >
                        {sector}
                      </span>
                    ))
                  ) : (
                    <span className="text-sm text-gray-500">Nenhum setor cadastrado</span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  const renderSectorsList = () => {
    if (sectors.length === 0) {
      return (
        <div className="p-8 text-center">
          <p className="text-gray-500">Nenhum setor cadastrado.</p>
        </div>
      );
    }

    return (
      <div className="grid gap-4">
        {sectors.map((sector) => {
          const departmentName = departments.find(d => d.id === sector.departmentId)?.name || "Departamento desconhecido";
          
          return (
            <Card key={sector.id}>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>{sector.name}</CardTitle>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem>
                        <Edit className="mr-2 h-4 w-4" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-red-600">
                        <Trash className="mr-2 h-4 w-4" />
                        Remover
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500">{sector.description}</p>
                <p className="text-sm mt-2">
                  <span className="font-medium">Departamento:</span>{" "}
                  <span className="text-gray-700">{departmentName}</span>
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gerenciamento de Usuários</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            Gerencie os usuários da sua organização, departamentos, setores e permissões
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleInviteUser}>
            <Send className="mr-2 h-4 w-4" />
            Convidar Usuário
          </Button>
          <Button onClick={handleAddUser}>
            <UserPlus className="mr-2 h-4 w-4" />
            Adicionar Usuário
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="users">
            <Users className="h-4 w-4 mr-2" />
            Usuários
          </TabsTrigger>
          <TabsTrigger value="invitations">
            <Mail className="h-4 w-4 mr-2" />
            Convites
          </TabsTrigger>
          <TabsTrigger value="departments">
            <Building2 className="h-4 w-4 mr-2" />
            Departamentos
          </TabsTrigger>
          <TabsTrigger value="sectors">
            <LayoutGrid className="h-4 w-4 mr-2" />
            Setores
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <Input
                    placeholder="Buscar por nome ou email"
                    className="w-full"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Departamento" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os departamentos</SelectItem>
                      {departments.map(dept => (
                        <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={roleFilter} onValueChange={setRoleFilter}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Função" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas as funções</SelectItem>
                      <SelectItem value="admin">Administrador</SelectItem>
                      <SelectItem value="manager">Gerente</SelectItem>
                      <SelectItem value="user">Usuário</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Usuários ({filteredUsers.length})</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-md">
                {renderUsersList()}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="invitations">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Convites ({invitations.length})</CardTitle>
                <Button onClick={handleInviteUser}>
                  <Send className="mr-2 h-4 w-4" />
                  Convidar Usuário
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-md">
                {renderInvitationsList()}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="departments">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Departamentos</h3>
            <Button onClick={handleAddDepartment}>
              <Plus className="mr-2 h-4 w-4" />
              Novo Departamento
            </Button>
          </div>
          {renderDepartmentsList()}
        </TabsContent>

        <TabsContent value="sectors">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Setores</h3>
            <Button onClick={handleAddSector}>
              <Plus className="mr-2 h-4 w-4" />
              Novo Setor
            </Button>
          </div>
          {renderSectorsList()}
        </TabsContent>
      </Tabs>

      {/* Add User Dialog */}
      <Dialog open={showAddUserDialog} onOpenChange={setShowAddUserDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Adicionar Usuário</DialogTitle>
            <DialogDescription>
              Adicione um novo usuário à organização. O usuário terá acesso imediato ao sistema.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">
                Nome
              </Label>
              <Input
                id="name"
                value={newUser.name}
                onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={newUser.email}
                onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="role" className="text-right">
                Função
              </Label>
              <Select 
                value={newUser.role} 
                onValueChange={(value) => setNewUser({...newUser, role: value})}
              >
                <SelectTrigger id="role" className="col-span-3">
                  <SelectValue placeholder="Selecione uma função" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Administrador</SelectItem>
                  <SelectItem value="manager">Gerente</SelectItem>
                  <SelectItem value="user">Usuário</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="department" className="text-right">
                Departamento
              </Label>
              <Select 
                value={newUser.department} 
                onValueChange={(value) => setNewUser({...newUser, department: value})}
              >
                <SelectTrigger id="department" className="col-span-3">
                  <SelectValue placeholder="Selecione um departamento" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map(dept => (
                    <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="sector" className="text-right">
                Setor
              </Label>
              <Select 
                value={newUser.sector} 
                onValueChange={(value) => setNewUser({...newUser, sector: value})}
              >
                <SelectTrigger id="sector" className="col-span-3">
                  <SelectValue placeholder="Selecione um setor" />
                </SelectTrigger>
                <SelectContent>
                  {sectors
                    .filter(sector => !newUser.department || departments.find(d => d.name === newUser.department)?.sectors.includes(sector.name))
                    .map(sector => (
                      <SelectItem key={sector.id} value={sector.name}>{sector.name}</SelectItem>
                    ))
                  }
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddUserDialog(false)}>Cancelar</Button>
            <Button onClick={handleSubmitAddUser}>Adicionar Usuário</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={showEditUserDialog} onOpenChange={setShowEditUserDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Editar Usuário</DialogTitle>
            <DialogDescription>
              Atualize as informações do usuário.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-name" className="text-right">
                Nome
              </Label>
              <Input
                id="edit-name"
                value={newUser.name}
                onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-email" className="text-right">
                Email
              </Label>
              <Input
                id="edit-email"
                type="email"
                value={newUser.email}
                onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-role" className="text-right">
                Função
              </Label>
              <Select 
                value={newUser.role} 
                onValueChange={(value) => setNewUser({...newUser, role: value})}
              >
                <SelectTrigger id="edit-role" className="col-span-3">
                  <SelectValue placeholder="Selecione uma função" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Administrador</SelectItem>
                  <SelectItem value="manager">Gerente</SelectItem>
                  <SelectItem value="user">Usuário</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-department" className="text-right">
                Departamento
              </Label>
              <Select 
                value={newUser.department} 
                onValueChange={(value) => setNewUser({...newUser, department: value})}
              >
                <SelectTrigger id="edit-department" className="col-span-3">
                  <SelectValue placeholder="Selecione um departamento" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map(dept => (
                    <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-sector" className="text-right">
                Setor
              </Label>
              <Select 
                value={newUser.sector} 
                onValueChange={(value) => setNewUser({...newUser, sector: value})}
              >
                <SelectTrigger id="edit-sector" className="col-span-3">
                  <SelectValue placeholder="Selecione um setor" />
                </SelectTrigger>
                <SelectContent>
                  {sectors
                    .filter(sector => !newUser.department || departments.find(d => d.name === newUser.department)?.sectors.includes(sector.name))
                    .map(sector => (
                      <SelectItem key={sector.id} value={sector.name}>{sector.name}</SelectItem>
                    ))
                  }
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-status" className="text-right">
                Status
              </Label>
              <Select 
                value={newUser.status} 
                onValueChange={(value) => setNewUser({...newUser, status: value})}
              >
                <SelectTrigger id="edit-status" className="col-span-3">
                  <SelectValue placeholder="Selecione um status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Ativo</SelectItem>
                  <SelectItem value="inactive">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditUserDialog(false)}>Cancelar</Button>
            <Button onClick={handleSubmitEditUser}>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete User Confirmation Dialog */}
      <Dialog open={showDeleteUserDialog} onOpenChange={setShowDeleteUserDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Confirmar Remoção</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja remover o usuário {currentUser?.name}? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteUserDialog(false)}>Cancelar</Button>
            <Button variant="destructive" onClick={confirmDeleteUser}>Remover</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Invite User Dialog */}
      <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Convidar Usuário</DialogTitle>
            <DialogDescription>
              Envie um convite por email para um novo usuário se juntar à organização.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="invite-name" className="text-right">
                Nome
              </Label>
              <Input
                id="invite-name"
                value={newInvitation.name}
                onChange={(e) => setNewInvitation({...newInvitation, name: e.target.value})}
                className="col-span-3"
                placeholder="Opcional"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="invite-email" className="text-right">
                Email
              </Label>
              <Input
                id="invite-email"
                type="email"
                value={newInvitation.email}
                onChange={(e) => setNewInvitation({...newInvitation, email: e.target.value})}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="invite-role" className="text-right">
                Função
              </Label>
              <Select 
                value={newInvitation.role} 
                onValueChange={(value) => setNewInvitation({...newInvitation, role: value})}
              >
                <SelectTrigger id="invite-role" className="col-span-3">
                  <SelectValue placeholder="Selecione uma função" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Administrador</SelectItem>
                  <SelectItem value="manager">Gerente</SelectItem>
                  <SelectItem value="user">Usuário</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="invite-department" className="text-right">
                Departamento
              </Label>
              <Select 
                value={newInvitation.department} 
                onValueChange={(value) => setNewInvitation({...newInvitation, department: value})}
              >
                <SelectTrigger id="invite-department" className="col-span-3">
                  <SelectValue placeholder="Selecione um departamento" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map(dept => (
                    <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="invite-sector" className="text-right">
                Setor
              </Label>
              <Select 
                value={newInvitation.sector} 
                onValueChange={(value) => setNewInvitation({...newInvitation, sector: value})}
              >
                <SelectTrigger id="invite-sector" className="col-span-3">
                  <SelectValue placeholder="Selecione um setor" />
                </SelectTrigger>
                <SelectContent>
                  {sectors
                    .filter(sector => !newInvitation.department || departments.find(d => d.name === newInvitation.department)?.sectors.includes(sector.name))
                    .map(sector => (
                      <SelectItem key={sector.id} value={sector.name}>{sector.name}</SelectItem>
                    ))
                  }
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="invite-message" className="text-right">
                Mensagem
              </Label>
              <Textarea
                id="invite-message"
                value={newInvitation.message}
                onChange={(e) => setNewInvitation({...newInvitation, message: e.target.value})}
                className="col-span-3"
                placeholder="Mensagem opcional para incluir no convite"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowInviteDialog(false)}>Cancelar</Button>
            <Button onClick={handleSubmitInvite}>Enviar Convite</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Department Dialog */}
      <Dialog open={showAddDepartmentDialog} onOpenChange={setShowAddDepartmentDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Adicionar Departamento</DialogTitle>
            <DialogDescription>
              Crie um novo departamento na organização.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dept-name" className="text-right">
                Nome
              </Label>
              <Input
                id="dept-name"
                value={newDepartment.name}
                onChange={(e) => setNewDepartment({...newDepartment, name: e.target.value})}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dept-description" className="text-right">
                Descrição
              </Label>
              <Textarea
                id="dept-description"
                value={newDepartment.description}
                onChange={(e) => setNewDepartment({...newDepartment, description: e.target.value})}
                className="col-span-3"
                placeholder="Descrição do departamento"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDepartmentDialog(false)}>Cancelar</Button>
            <Button onClick={handleSubmitAddDepartment}>Adicionar Departamento</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Sector Dialog */}
      <Dialog open={showAddSectorDialog} onOpenChange={setShowAddSectorDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Adicionar Setor</DialogTitle>
            <DialogDescription>
              Crie um novo setor dentro de um departamento existente.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="sector-name" className="text-right">
                Nome
              </Label>
              <Input
                id="sector-name"
                value={newSector.name}
                onChange={(e) => setNewSector({...newSector, name: e.target.value})}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="sector-department" className="text-right">
                Departamento
              </Label>
              <Select 
                value={newSector.departmentId.toString()} 
                onValueChange={(value) => setNewSector({...newSector, departmentId: value})}
              >
                <SelectTrigger id="sector-department" className="col-span-3">
                  <SelectValue placeholder="Selecione um departamento" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map(dept => (
                    <SelectItem key={dept.id} value={dept.id.toString()}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="sector-description" className="text-right">
                Descrição
              </Label>
              <Textarea
                id="sector-description"
                value={newSector.description}
                onChange={(e) => setNewSector({...newSector, description: e.target.value})}
                className="col-span-3"
                placeholder="Descrição do setor"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddSectorDialog(false)}>Cancelar</Button>
            <Button onClick={handleSubmitAddSector}>Adicionar Setor</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}