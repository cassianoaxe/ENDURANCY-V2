import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  BadgePercent,
  Users,
  ChevronRight,
  Calendar,
  Mail,
  MessageSquare,
  Smartphone,
  Send,
  Megaphone,
  Target,
  Tags,
  Plus,
  Minus,
  ArrowRight,
  Check,
  X,
  Copy,
  Clock,
  Info,
  Edit,
  Filter,
  Eye,
  AlertTriangle,
  Zap,
  BarChart4,
  FileText,
  Download,
  Save
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function CrmNovaCampanha() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    type: "email",
    target_audience: "all_patients",
    status: "draft",
    scheduled_date: "",
    send_time: "",
    content: "",
    subject: "",
    sender_name: "",
    sender_email: "",
    targets: [],
    tags: [],
    custom_filters: [],
    test_emails: [],
    is_recurring: false,
    recurring_type: "weekly",
    recurring_day: "1",
    recurring_hour: "9:00",
    track_opens: true,
    track_clicks: true,
    has_unsubscribe_link: true
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showTestDialog, setShowTestDialog] = useState(false);
  const [testEmail, setTestEmail] = useState("");
  const [audienceCount, setAudienceCount] = useState(0);
  const [audiencePreview, setAudiencePreview] = useState([]);
  const [showSuccess, setShowSuccess] = useState(false);
  
  // Simular contagem de audiência com base no tipo de alvo selecionado
  useEffect(() => {
    switch(formData.target_audience) {
      case "all_patients":
        setAudienceCount(1250);
        setAudiencePreview([
          { id: 1, name: "João Silva", email: "joao.silva@exemplo.com" },
          { id: 2, name: "Maria Oliveira", email: "maria.oliveira@exemplo.com" },
          { id: 3, name: "Carlos Santos", email: "carlos.santos@exemplo.com" },
          { id: 4, name: "Ana Pereira", email: "ana.pereira@exemplo.com" },
          { id: 5, name: "Paulo Costa", email: "paulo.costa@exemplo.com" }
        ]);
        break;
      case "active_patients":
        setAudienceCount(980);
        setAudiencePreview([
          { id: 1, name: "João Silva", email: "joao.silva@exemplo.com" },
          { id: 2, name: "Maria Oliveira", email: "maria.oliveira@exemplo.com" },
          { id: 3, name: "Carlos Santos", email: "carlos.santos@exemplo.com" },
          { id: 4, name: "Ana Pereira", email: "ana.pereira@exemplo.com" },
          { id: 5, name: "Paulo Costa", email: "paulo.costa@exemplo.com" }
        ]);
        break;
      case "inactive_patients":
        setAudienceCount(270);
        setAudiencePreview([
          { id: 6, name: "Fernanda Lima", email: "fernanda.lima@exemplo.com" },
          { id: 7, name: "Ricardo Alves", email: "ricardo.alves@exemplo.com" },
          { id: 8, name: "Juliana Martins", email: "juliana.martins@exemplo.com" },
          { id: 9, name: "Marcelo Gomes", email: "marcelo.gomes@exemplo.com" },
          { id: 10, name: "Luciana Costa", email: "luciana.costa@exemplo.com" }
        ]);
        break;
      case "specific_tags":
        setAudienceCount(345);
        setAudiencePreview([
          { id: 11, name: "Roberto Mendes", email: "roberto.mendes@exemplo.com" },
          { id: 12, name: "Carla Ferreira", email: "carla.ferreira@exemplo.com" },
          { id: 13, name: "Eduardo Sousa", email: "eduardo.sousa@exemplo.com" },
          { id: 14, name: "Patrícia Moreira", email: "patricia.moreira@exemplo.com" },
          { id: 15, name: "Francisco Barbosa", email: "francisco.barbosa@exemplo.com" }
        ]);
        break;
      case "custom_filter":
        setAudienceCount(158);
        setAudiencePreview([
          { id: 16, name: "Carolina Castro", email: "carolina.castro@exemplo.com" },
          { id: 17, name: "Daniel Vieira", email: "daniel.vieira@exemplo.com" },
          { id: 18, name: "Vanessa Pinto", email: "vanessa.pinto@exemplo.com" },
          { id: 19, name: "Lucas Macedo", email: "lucas.macedo@exemplo.com" },
          { id: 20, name: "Beatriz Cardoso", email: "beatriz.cardoso@exemplo.com" }
        ]);
        break;
      default:
        setAudienceCount(0);
        setAudiencePreview([]);
    }
  }, [formData.target_audience, formData.tags, formData.custom_filters]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleCheckboxChange = (name, checked) => {
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const handleNext = () => {
    setCurrentStep(currentStep + 1);
  };

  const handleBack = () => {
    setCurrentStep(currentStep - 1);
  };

  const handleSaveAsDraft = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setShowSuccess(true);
      setTimeout(() => {
        navigate(createPageUrl("CrmCampanhas"));
      }, 2000);
    }, 1500);
  };

  const handleSchedule = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setShowSuccess(true);
      setTimeout(() => {
        navigate(createPageUrl("CrmCampanhas"));
      }, 2000);
    }, 1500);
  };

  const handleSendTest = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setShowTestDialog(false);
      // Mostrar alerta de sucesso temporário
      alert("E-mail de teste enviado com sucesso para: " + testEmail);
    }, 1500);
  };

  const renderStepIndicator = () => {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div className={`flex flex-col items-center ${currentStep >= 1 ? 'text-green-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 1 ? 'bg-green-100 border-green-600' : 'bg-gray-100 border-gray-300'} border-2`}>
              {currentStep > 1 ? <Check className="w-5 h-5" /> : <span>1</span>}
            </div>
            <span className="text-xs mt-1">Informações</span>
          </div>
          <div className={`flex-1 h-0.5 mx-2 ${currentStep >= 2 ? 'bg-green-600' : 'bg-gray-300'}`}></div>
          <div className={`flex flex-col items-center ${currentStep >= 2 ? 'text-green-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 2 ? 'bg-green-100 border-green-600' : 'bg-gray-100 border-gray-300'} border-2`}>
              {currentStep > 2 ? <Check className="w-5 h-5" /> : <span>2</span>}
            </div>
            <span className="text-xs mt-1">Público</span>
          </div>
          <div className={`flex-1 h-0.5 mx-2 ${currentStep >= 3 ? 'bg-green-600' : 'bg-gray-300'}`}></div>
          <div className={`flex flex-col items-center ${currentStep >= 3 ? 'text-green-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 3 ? 'bg-green-100 border-green-600' : 'bg-gray-100 border-gray-300'} border-2`}>
              {currentStep > 3 ? <Check className="w-5 h-5" /> : <span>3</span>}
            </div>
            <span className="text-xs mt-1">Conteúdo</span>
          </div>
          <div className={`flex-1 h-0.5 mx-2 ${currentStep >= 4 ? 'bg-green-600' : 'bg-gray-300'}`}></div>
          <div className={`flex flex-col items-center ${currentStep >= 4 ? 'text-green-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 4 ? 'bg-green-100 border-green-600' : 'bg-gray-100 border-gray-300'} border-2`}>
              <span>4</span>
            </div>
            <span className="text-xs mt-1">Programação</span>
          </div>
        </div>
      </div>
    )
  };

  const renderStep1 = () => {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 gap-6">
          <div className="space-y-2">
            <Label htmlFor="title">Título da Campanha<span className="text-red-500">*</span></Label>
            <Input 
              id="title" 
              name="title" 
              value={formData.title} 
              onChange={handleInputChange} 
              placeholder="Ex: Newsletter de Novembro 2023"
            />
            <p className="text-sm text-gray-500">O título é apenas para uso interno</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrição</Label>
            <Textarea 
              id="description" 
              name="description" 
              value={formData.description} 
              onChange={handleInputChange} 
              placeholder="Descreva brevemente o objetivo desta campanha..."
              className="min-h-[100px]"
            />
          </div>

          <div className="space-y-2">
            <Label>Tipo de Campanha<span className="text-red-500">*</span></Label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div 
                className={`border rounded-lg p-4 cursor-pointer transition-all ${formData.type === 'email' ? 'border-blue-500 bg-blue-50' : 'hover:border-gray-300'}`}
                onClick={() => handleSelectChange('type', 'email')}
              >
                <div className="flex items-center mb-2">
                  <Mail className="mr-2 h-5 w-5 text-blue-500" />
                  <h3 className="font-medium">E-mail</h3>
                </div>
                <p className="text-sm text-gray-500">Envie e-mails para sua lista de contatos</p>
              </div>

              <div 
                className={`border rounded-lg p-4 cursor-pointer transition-all ${formData.type === 'sms' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}
                onClick={() => handleSelectChange('type', 'sms')}
              >
                <div className="flex items-center mb-2">
                  <Smartphone className="mr-2 h-5 w-5 text-blue-500" />
                  <h3 className="font-medium">SMS</h3>
                </div>
                <p className="text-sm text-gray-500">Envie mensagens de texto para celulares</p>
              </div>

              <div 
                className={`border rounded-lg p-4 cursor-pointer transition-all ${formData.type === 'notification' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}
                onClick={() => handleSelectChange('type', 'notification')}
              >
                <div className="flex items-center mb-2">
                  <Megaphone className="mr-2 h-5 w-5 text-blue-500" />
                  <h3 className="font-medium">Notificação</h3>
                </div>
                <p className="text-sm text-gray-500">Notificações no aplicativo e push</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-4 pt-4">
          <Button variant="outline" onClick={() => navigate(createPageUrl("CrmCampanhas"))}>
            Cancelar
          </Button>
          <Button onClick={handleNext}>
            Próximo <ChevronRight className="ml-1 h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  };

  const renderStep2 = () => {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 gap-6">
          <div className="space-y-2">
            <Label>Público-alvo<span className="text-red-500">*</span></Label>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div 
                className={`border rounded-lg p-4 cursor-pointer transition-all ${formData.target_audience === 'all_patients' ? 'border-blue-500 bg-blue-50' : 'hover:border-gray-300'}`}
                onClick={() => handleSelectChange('target_audience', 'all_patients')}
              >
                <div className="flex items-center mb-2">
                  <Users className="mr-2 h-5 w-5 text-blue-500" />
                  <h3 className="font-medium">Todos os Pacientes</h3>
                </div>
                <p className="text-sm text-gray-500">Todos os pacientes registrados no sistema</p>
              </div>

              <div 
                className={`border rounded-lg p-4 cursor-pointer transition-all ${formData.target_audience === 'active_patients' ? 'border-blue-500 bg-blue-50' : 'hover:border-gray-300'}`}
                onClick={() => handleSelectChange('target_audience', 'active_patients')}
              >
                <div className="flex items-center mb-2">
                  <Check className="mr-2 h-5 w-5 text-blue-500" />
                  <h3 className="font-medium">Pacientes Ativos</h3>
                </div>
                <p className="text-sm text-gray-500">Pacientes com pedidos nos últimos 90 dias</p>
              </div>

              <div 
                className={`border rounded-lg p-4 cursor-pointer transition-all ${formData.target_audience === 'inactive_patients' ? 'border-blue-500 bg-blue-50' : 'hover:border-gray-300'}`}
                onClick={() => handleSelectChange('target_audience', 'inactive_patients')}
              >
                <div className="flex items-center mb-2">
                  <Clock className="mr-2 h-5 w-5 text-blue-500" />
                  <h3 className="font-medium">Pacientes Inativos</h3>
                </div>
                <p className="text-sm text-gray-500">Pacientes sem pedidos nos últimos 90 dias</p>
              </div>

              <div 
                className={`border rounded-lg p-4 cursor-pointer transition-all ${formData.target_audience === 'specific_tags' ? 'border-blue-500 bg-blue-50' : 'hover:border-gray-300'}`}
                onClick={() => handleSelectChange('target_audience', 'specific_tags')}
              >
                <div className="flex items-center mb-2">
                  <Tags className="mr-2 h-5 w-5 text-blue-500" />
                  <h3 className="font-medium">Tags Específicas</h3>
                </div>
                <p className="text-sm text-gray-500">Filtrar por tags como diagnóstico ou região</p>
              </div>

              <div 
                className={`border rounded-lg p-4 cursor-pointer transition-all ${formData.target_audience === 'custom_filter' ? 'border-blue-500 bg-blue-50' : 'hover:border-gray-300'}`}
                onClick={() => handleSelectChange('target_audience', 'custom_filter')}
              >
                <div className="flex items-center mb-2">
                  <Filter className="mr-2 h-5 w-5 text-blue-500" />
                  <h3 className="font-medium">Filtro Personalizado</h3>
                </div>
                <p className="text-sm text-gray-500">Crie regras específicas para filtrar pacientes</p>
              </div>
            </div>
          </div>

          {formData.target_audience === 'specific_tags' && (
            <div className="space-y-2">
              <Label htmlFor="tags">Selecionar Tags</Label>
              <div className="flex flex-wrap gap-2 p-3 border rounded-md min-h-[80px]">
                {['Epilepsia', 'Dor Crônica', 'Ansiedade', 'Insônia', 'São Paulo', 'Rio de Janeiro', 'Minas Gerais', 'Plano Premium'].map(tag => (
                  <div 
                    key={tag}
                    className="bg-gray-100 hover:bg-gray-200 cursor-pointer px-3 py-1 rounded-full text-sm flex items-center"
                    onClick={() => {
                      // Toggle tag selection
                      const newTags = formData.tags.includes(tag) 
                        ? formData.tags.filter(t => t !== tag)
                        : [...formData.tags, tag];
                      handleSelectChange('tags', newTags);
                    }}
                  >
                    {tag}
                    {formData.tags.includes(tag) ? (
                      <Check className="ml-1 h-3 w-3 text-green-500" />
                    ) : (
                      <Plus className="ml-1 h-3 w-3 text-gray-500" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {formData.target_audience === 'custom_filter' && (
            <div className="space-y-4">
              <Label>Filtros Personalizados</Label>
              <div className="border rounded-md p-4">
                <div className="mb-4">
                  <Button variant="outline" size="sm" className="mb-4">
                    <Plus className="h-4 w-4 mr-1" /> Adicionar Condição
                  </Button>
                </div>
                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-2 p-2 border rounded-md bg-gray-50">
                    <Select defaultValue="product">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Campo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="product">Produto Comprado</SelectItem>
                        <SelectItem value="last_purchase">Última Compra</SelectItem>
                        <SelectItem value="total_spent">Valor Total Gasto</SelectItem>
                        <SelectItem value="region">Região</SelectItem>
                        <SelectItem value="age">Idade</SelectItem>
                      </SelectContent>
                    </Select>

                    <Select defaultValue="contains">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Condição" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="contains">Contém</SelectItem>
                        <SelectItem value="not_contains">Não Contém</SelectItem>
                        <SelectItem value="equals">Igual a</SelectItem>
                        <SelectItem value="greater_than">Maior que</SelectItem>
                        <SelectItem value="less_than">Menor que</SelectItem>
                      </SelectContent>
                    </Select>

                    <Input defaultValue="Óleo CBD" className="flex-1" />

                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-red-500">
                      <X className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex items-center gap-2 p-2 border rounded-md bg-gray-50">
                    <Select defaultValue="last_purchase">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Campo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="product">Produto Comprado</SelectItem>
                        <SelectItem value="last_purchase">Última Compra</SelectItem>
                        <SelectItem value="total_spent">Valor Total Gasto</SelectItem>
                        <SelectItem value="region">Região</SelectItem>
                        <SelectItem value="age">Idade</SelectItem>
                      </SelectContent>
                    </Select>

                    <Select defaultValue="greater_than">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Condição" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="equals">Igual a</SelectItem>
                        <SelectItem value="not_equals">Diferente de</SelectItem>
                        <SelectItem value="greater_than">Maior que</SelectItem>
                        <SelectItem value="less_than">Menor que</SelectItem>
                        <SelectItem value="between">Entre</SelectItem>
                      </SelectContent>
                    </Select>

                    <Input defaultValue="90" className="flex-1" />
                    <span className="text-gray-500">dias atrás</span>

                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-red-500">
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="bg-gray-50 border rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <Users className="mr-2 h-5 w-5 text-blue-500" />
                <h3 className="font-medium">Prévia da Audiência</h3>
              </div>
              <Badge variant="outline" className="bg-blue-50">
                {audienceCount} destinatários
              </Badge>
            </div>
            
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>E-mail</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {audiencePreview.map(recipient => (
                    <TableRow key={recipient.id}>
                      <TableCell>{recipient.name}</TableCell>
                      <TableCell>{recipient.email}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="mt-2 text-center text-sm text-gray-500">
              Mostrando 5 de {audienceCount} destinatários
            </div>
          </div>
        </div>

        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={handleBack}>
            Voltar
          </Button>
          <Button onClick={handleNext}>
            Próximo <ChevronRight className="ml-1 h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  };

  const renderStep3 = () => {
    return (
      <div className="space-y-6">
        {formData.type === "email" && (
          <div className="grid grid-cols-1 gap-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="subject">Assunto do E-mail<span className="text-red-500">*</span></Label>
                <Input 
                  id="subject" 
                  name="subject" 
                  value={formData.subject} 
                  onChange={handleInputChange} 
                  placeholder="Digite o assunto do e-mail"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sender_name">Nome do Remetente<span className="text-red-500">*</span></Label>
                <Input 
                  id="sender_name" 
                  name="sender_name" 
                  value={formData.sender_name} 
                  onChange={handleInputChange} 
                  placeholder="Ex: Endurancy Associação"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">Conteúdo do E-mail<span className="text-red-500">*</span></Label>
              <div className="border rounded-lg overflow-hidden">
                <div className="bg-gray-50 p-2 border-b flex items-center gap-2 flex-wrap">
                  <Button variant="outline" size="sm">
                    <FileText className="h-4 w-4 mr-1" /> Modelos
                  </Button>
                  <Button variant="outline" size="sm">
                    Inserir Imagem
                  </Button>
                  <Button variant="outline" size="sm">
                    Incluir Botão
                  </Button>
                  <Button variant="outline" size="sm">
                    Personalizar
                  </Button>
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4 mr-1" /> Visualizar
                  </Button>
                </div>
                <Textarea 
                  id="content" 
                  name="content" 
                  value={formData.content} 
                  onChange={handleInputChange}
                  placeholder="Escreva o conteúdo do seu e-mail ou selecione um modelo..."
                  className="min-h-[300px] border-0 rounded-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="test_emails">E-mails para Teste</Label>
                  <Dialog open={showTestDialog} onOpenChange={setShowTestDialog}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="text-sm">
                        Enviar Teste
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Enviar E-mail de Teste</DialogTitle>
                        <DialogDescription>
                          Envie uma prévia do e-mail para verificar como ficará para seus destinatários.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label htmlFor="test_email">E-mail de Teste</Label>
                          <Input 
                            id="test_email" 
                            value={testEmail} 
                            onChange={(e) => setTestEmail(e.target.value)} 
                            placeholder="seu@email.com"
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setShowTestDialog(false)}>Cancelar</Button>
                        <Button onClick={handleSendTest} disabled={isSubmitting}>
                          {isSubmitting ? (
                            <>
                              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              Enviando...
                            </>
                          ) : (
                            <>Enviar</>
                          )}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
                <div className="flex flex-wrap gap-2 p-3 border rounded-md min-h-[60px]">
                  {formData.test_emails.map((email, index) => (
                    <div 
                      key={index}
                      className="bg-gray-100 px-3 py-1 rounded-full text-sm flex items-center"
                    >
                      {email}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 ml-1 text-gray-500"
                        onClick={() => {
                          const newEmails = [...formData.test_emails];
                          newEmails.splice(index, 1);
                          handleSelectChange('test_emails', newEmails);
                        }}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2 justify-between">
                  <Label>Opções de Rastreamento</Label>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="track_opens" 
                      checked={formData.track_opens}
                      onCheckedChange={(checked) => handleCheckboxChange('track_opens', checked)}
                    />
                    <Label htmlFor="track_opens">Rastrear aberturas de e-mail</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="track_clicks" 
                      checked={formData.track_clicks}
                      onCheckedChange={(checked) => handleCheckboxChange('track_clicks', checked)}
                    />
                    <Label htmlFor="track_clicks">Rastrear cliques nos links</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="has_unsubscribe_link" 
                      checked={formData.has_unsubscribe_link}
                      onCheckedChange={(checked) => handleCheckboxChange('has_unsubscribe_link', checked)}
                    />
                    <Label htmlFor="has_unsubscribe_link">Incluir link para cancelar inscrição</Label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {formData.type === "sms" && (
          <div className="grid grid-cols-1 gap-6">
            <div className="space-y-2">
              <Label htmlFor="sms_content">Conteúdo da Mensagem SMS<span className="text-red-500">*</span></Label>
              <Textarea 
                id="content" 
                name="content" 
                value={formData.content} 
                onChange={handleInputChange}
                placeholder="Digite o texto da sua mensagem SMS..."
                className="min-h-[120px]"
              />
              <div className="flex justify-between text-sm text-gray-500">
                <span>Caracteres: {formData.content.length}/160</span>
                <span>{Math.ceil(formData.content.length / 160)} mensagem(ns)</span>
              </div>
            </div>

            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Atenção</AlertTitle>
              <AlertDescription>
                Mensagens SMS têm limite de 160 caracteres. Mensagens mais longas serão divididas e cobradas como múltiplas mensagens.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {formData.type === "notification" && (
          <div className="grid grid-cols-1 gap-6">
            <div className="space-y-2">
              <Label htmlFor="notification_title">Título da Notificação<span className="text-red-500">*</span></Label>
              <Input 
                id="subject" 
                name="subject" 
                value={formData.subject} 
                onChange={handleInputChange} 
                placeholder="Digite o título da notificação"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notification_content">Conteúdo da Notificação<span className="text-red-500">*</span></Label>
              <Textarea 
                id="content" 
                name="content" 
                value={formData.content} 
                onChange={handleInputChange}
                placeholder="Digite o texto da sua notificação..."
                className="min-h-[80px]"
              />
              <div className="text-sm text-gray-500">
                <span>Caracteres: {formData.content.length}/240 (recomendado)</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Ação ao Clicar</Label>
              <RadioGroup defaultValue="none">
                <div className="flex items-start space-x-2 py-2">
                  <RadioGroupItem value="none" id="action-none" />
                  <Label htmlFor="action-none" className="font-normal">Nenhuma ação</Label>
                </div>
                <div className="flex items-start space-x-2 py-2">
                  <RadioGroupItem value="url" id="action-url" />
                  <div className="grid gap-1.5">
                    <Label htmlFor="action-url" className="font-normal">Abrir URL</Label>
                    <Input placeholder="https://..." disabled />
                  </div>
                </div>
                <div className="flex items-start space-x-2 py-2">
                  <RadioGroupItem value="screen" id="action-screen" />
                  <div className="grid gap-1.5">
                    <Label htmlFor="action-screen" className="font-normal">Abrir tela no aplicativo</Label>
                    <Select disabled>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecionar tela" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="home">Início</SelectItem>
                        <SelectItem value="products">Produtos</SelectItem>
                        <SelectItem value="orders">Meus Pedidos</SelectItem>
                        <SelectItem value="profile">Perfil</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </RadioGroup>
            </div>
          </div>
        )}

        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={handleBack}>
            Voltar
          </Button>
          <Button onClick={handleNext}>
            Próximo <ChevronRight className="ml-1 h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  };

  const renderStep4 = () => {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 gap-6">
          <div className="space-y-4">
            <Label>Quando enviar?</Label>
            <RadioGroup defaultValue="schedule">
              <div className="flex items-center space-x-2 py-2">
                <RadioGroupItem value="schedule" id="schedule" />
                <Label htmlFor="schedule" className="font-normal">Agendar para uma data específica</Label>
              </div>
              <div className="flex items-center space-x-2 py-2">
                <RadioGroupItem value="recurring" id="recurring" />
                <Label htmlFor="recurring" className="font-normal">Configurar envio recorrente</Label>
              </div>
              <div className="flex items-center space-x-2 py-2">
                <RadioGroupItem value="draft" id="draft" />
                <Label htmlFor="draft" className="font-normal">Salvar como rascunho (enviar depois)</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="scheduled_date">Data de Envio</Label>
              <Input 
                type="date" 
                id="scheduled_date" 
                name="scheduled_date" 
                value={formData.scheduled_date} 
                onChange={handleInputChange} 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="send_time">Horário de Envio</Label>
              <Input 
                type="time" 
                id="send_time" 
                name="send_time" 
                value={formData.send_time} 
                onChange={handleInputChange} 
              />
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg border">
            <div className="flex items-center space-x-2 mb-4">
              <Switch 
                id="is_recurring" 
                checked={formData.is_recurring}
                onCheckedChange={(checked) => handleCheckboxChange('is_recurring', checked)}
              />
              <Label htmlFor="is_recurring" className="font-medium">Configurar Recorrência</Label>
            </div>

            {formData.is_recurring && (
              <div className="space-y-4 pl-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="recurring_type">Frequência</Label>
                    <Select 
                      value={formData.recurring_type}
                      onValueChange={(value) => handleSelectChange('recurring_type', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecionar" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Diariamente</SelectItem>
                        <SelectItem value="weekly">Semanalmente</SelectItem>
                        <SelectItem value="monthly">Mensalmente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {formData.recurring_type === 'weekly' && (
                    <div className="space-y-2">
                      <Label htmlFor="recurring_day">Dia da Semana</Label>
                      <Select 
                        value={formData.recurring_day}
                        onValueChange={(value) => handleSelectChange('recurring_day', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecionar" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">Segunda-feira</SelectItem>
                          <SelectItem value="2">Terça-feira</SelectItem>
                          <SelectItem value="3">Quarta-feira</SelectItem>
                          <SelectItem value="4">Quinta-feira</SelectItem>
                          <SelectItem value="5">Sexta-feira</SelectItem>
                          <SelectItem value="6">Sábado</SelectItem>
                          <SelectItem value="0">Domingo</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {formData.recurring_type === 'monthly' && (
                    <div className="space-y-2">
                      <Label htmlFor="recurring_day">Dia do Mês</Label>
                      <Select 
                        value={formData.recurring_day}
                        onValueChange={(value) => handleSelectChange('recurring_day', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecionar" />
                        </SelectTrigger>
                        <SelectContent>
                          {[...Array(28)].map((_, i) => (
                            <SelectItem key={i} value={(i + 1).toString()}>{i + 1}</SelectItem>
                          ))}
                          <SelectItem value="last">Último dia</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="recurring_hour">Horário</Label>
                    <Input 
                      type="time" 
                      id="recurring_hour" 
                      name="recurring_hour" 
                      value={formData.recurring_hour} 
                      onChange={handleInputChange} 
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {formData.type === "email" && (
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Info className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-medium text-blue-700">Resumo do Envio</h4>
                  <div className="mt-2 space-y-1 text-blue-700">
                    <p><strong>Destinatários:</strong> {audienceCount} contatos</p>
                    <p><strong>Assunto:</strong> {formData.subject || "[Não definido]"}</p>
                    <p><strong>Tipo de Envio:</strong> {formData.is_recurring ? "Recorrente" : "Único"}</p>
                    {!formData.is_recurring && formData.scheduled_date && (
                      <p><strong>Data de Envio:</strong> {formData.scheduled_date} às {formData.send_time || "00:00"}</p>
                    )}
                    {formData.is_recurring && (
                      <p>
                        <strong>Recorrência:</strong> {" "}
                        {formData.recurring_type === "daily" ? "Diariamente" : 
                         formData.recurring_type === "weekly" ? "Semanalmente (às " + ["Segundas", "Terças", "Quartas", "Quintas", "Sextas", "Sábados", "Domingos"][parseInt(formData.recurring_day)] + ")" : 
                         "Mensalmente (dia " + formData.recurring_day + ")"} às {formData.recurring_hour}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={handleBack}>
            Voltar
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleSaveAsDraft} disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-gray-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Salvando...
                </>
              ) : (
                <>Salvar Rascunho</>
              )}
            </Button>
            <Button onClick={handleSchedule} disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Processando...
                </>
              ) : (
                <>Agendar Campanha</>
              )}
            </Button>
          </div>
        </div>

        {showSuccess && (
          <Alert className="bg-green-50 border-green-200 text-green-800">
            <Check className="h-4 w-4" />
            <AlertTitle>Sucesso!</AlertTitle>
            <AlertDescription>
              Sua campanha foi {formData.is_recurring ? "agendada" : "salva"} com sucesso. Redirecionando...
            </AlertDescription>
          </Alert>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between">
        <div>
          <h1 className="text-2xl font-bold">Nova Campanha</h1>
          <p className="text-gray-500 mt-1">
            Crie e agende uma nova campanha de marketing
          </p>
        </div>
      </div>

      <Card className="overflow-hidden">
        <CardContent className="p-6">
          {renderStepIndicator()}
          
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          {currentStep === 4 && renderStep4()}
        </CardContent>
      </Card>
    </div>
  );
}