import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import {
  PackageOpen,
  Box,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  User,
  Calendar,
  Package,
  BarChart,
  Clipboard,
  ClipboardCheck,
  AlertTriangle,
  Search,
  FilterX,
  Plus,
  Trash2,
  Save,
  PlayCircle,
  PauseCircle,
  StopCircle,
  RefreshCw,
  Printer,
  QrCode,
  Sticker,
  Scan,
  Barcode,
  PackageCheck,
  Eye
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ProducaoEmbalagem() {
  const [loading, setLoading] = useState(false);
  const [lotes, setLotes] = useState([]);
  const [loteAtivo, setLoteAtivo] = useState(null);
  const [tipoEmbalagem, setTipoEmbalagem] = useState('primaria'); // 'primaria' ou 'secundaria'
  const [equipamentoStatus, setEquipamentoStatus] = useState('desligado');
  const [quantidadeProcessada, setQuantidadeProcessada] = useState(0);
  const [quantidadeRejeitada, setQuantidadeRejeitada] = useState(0);
  const [emProcesso, setEmProcesso] = useState(false);
  const [statusImpressao, setStatusImpressao] = useState('pendente'); // 'pendente', 'impressao', 'concluido'
  const [checklistConcluido, setChecklistConcluido] = useState(false);
  const [lotesProntos, setLotesProntos] = useState([]);
  
  // Checklist de verificação
  const [checklist, setChecklist] = useState({
    verificacaoRotulos: false,
    verificacaoEmbalagens: false,
    verificacaoEquipamento: false,
    verificacaoLotes: false,
    verificacaoProcedimento: false,
    verificacaoMateriais: false
  });

  useEffect(() => {
    // Simulação de carregamento de dados
    setLoading(true);
    setTimeout(() => {
      const mockLotes = [
        {
          id: "LOT-CBD-072-ENV",
          produto: "Óleo CBD 5% 30ml",
          ordemProducao: "OP-2023-125",
          quantidadeTotal: 500,
          quantidadeProcessada: 0,
          unidade: "frascos",
          status: "pronto_para_embalagem",
          etapa: "primaria",
          dataProcesso: "07/08/2023",
          responsavel: "Maria Oliveira",
          materiais: [
            { nome: "Frascos envasados", quantidade: 500, lote: "LOT-CBD-072-ENV" },
            { nome: "Tampas conta-gotas", quantidade: 520, lote: "TAM-234" },
            { nome: "Lacres de segurança", quantidade: 520, lote: "LAC-456" },
            { nome: "Rótulos primários", quantidade: 520, lote: "ROT-123" }
          ]
        },
        {
          id: "LOT-CBD-073-ENV",
          produto: "Óleo CBD 10% 30ml",
          ordemProducao: "OP-2023-127",
          quantidadeTotal: 300,
          quantidadeProcessada: 0,
          unidade: "frascos",
          status: "pronto_para_embalagem",
          etapa: "primaria",
          dataProcesso: "09/08/2023",
          responsavel: "Pedro Mendes",
          materiais: [
            { nome: "Frascos envasados", quantidade: 300, lote: "LOT-CBD-073-ENV" },
            { nome: "Tampas conta-gotas", quantidade: 320, lote: "TAM-235" },
            { nome: "Lacres de segurança", quantidade: 320, lote: "LAC-457" },
            { nome: "Rótulos primários", quantidade: 320, lote: "ROT-124" }
          ]
        },
        {
          id: "LOT-CBD-071-ROT",
          produto: "Óleo CBD 2.5% 30ml",
          ordemProducao: "OP-2023-122",
          quantidadeTotal: 800,
          quantidadeProcessada: 0,
          unidade: "frascos",
          status: "pronto_para_embalagem",
          etapa: "secundaria",
          dataProcesso: "06/08/2023",
          responsavel: "Ana Costa",
          materiais: [
            { nome: "Frascos rotulados", quantidade: 800, lote: "LOT-CBD-071-ROT" },
            { nome: "Caixas individuais", quantidade: 820, lote: "CXI-789" },
            { nome: "Bulas", quantidade: 820, lote: "BUL-234" },
            { nome: "Etiquetas de rastreabilidade", quantidade: 820, lote: "ETQ-345" }
          ]
        }
      ];
      
      const filteredLotes = mockLotes.filter(lote => {
        if (tipoEmbalagem === 'primaria') {
          return lote.etapa === 'primaria';
        } else {
          return lote.etapa === 'secundaria';
        }
      });
      
      setLotes(filteredLotes);
      setLoading(false);
      
      // Lotes prontos para a próxima etapa (secundária)
      setLotesProntos([
        {
          id: "LOT-CBD-070-ROT",
          produto: "Óleo CBD 2.5% 30ml",
          ordemProducao: "OP-2023-120",
          quantidadeTotal: 500,
          status: "concluido",
          etapa: "primaria",
          dataProcesso: "05/08/2023",
          dataFinalizado: "06/08/2023",
          responsavel: "Maria Oliveira"
        }
      ]);
    }, 1000);
  }, [tipoEmbalagem]);

  const alternarTipoEmbalagem = (tipo) => {
    setTipoEmbalagem(tipo);
    setLoteAtivo(null);
    resetarChecklist();
    setQuantidadeProcessada(0);
    setQuantidadeRejeitada(0);
    setEquipamentoStatus('desligado');
    setEmProcesso(false);
    setStatusImpressao('pendente');
  };

  const selecionarLote = (lote) => {
    setLoteAtivo(lote);
    setEquipamentoStatus('ligado');
    resetarChecklist();
    setQuantidadeProcessada(0);
    setQuantidadeRejeitada(0);
    setEmProcesso(false);
    setStatusImpressao('pendente');
  };

  const resetarChecklist = () => {
    setChecklist({
      verificacaoRotulos: false,
      verificacaoEmbalagens: false,
      verificacaoEquipamento: false,
      verificacaoLotes: false,
      verificacaoProcedimento: false,
      verificacaoMateriais: false
    });
    setChecklistConcluido(false);
  };

  const atualizarChecklist = (item, valor) => {
    setChecklist(prev => {
      const novoChecklist = {
        ...prev,
        [item]: valor
      };
      // Verificar se todos os itens foram concluídos
      const todosConcluidos = Object.values(novoChecklist).every(Boolean);
      setChecklistConcluido(todosConcluidos);
      return novoChecklist;
    });
  };

  const imprimirRotulos = () => {
    if (!checklistConcluido) {
      alert("É necessário concluir o checklist antes de imprimir os rótulos.");
      return;
    }
    
    setStatusImpressao('impressao');
    
    // Simular impressão concluída após 3 segundos
    setTimeout(() => {
      setStatusImpressao('concluido');
      setEquipamentoStatus('pronto');
    }, 3000);
  };

  const iniciarProcesso = () => {
    if (statusImpressao !== 'concluido' && tipoEmbalagem === 'primaria') {
      alert("É necessário imprimir os rótulos antes de iniciar o processo.");
      return;
    }
    
    setEmProcesso(true);
    setEquipamentoStatus('processando');
    
    // Simular o processo de embalagem
    const intervalId = setInterval(() => {
      setQuantidadeProcessada(prev => {
        if (prev >= loteAtivo.quantidadeTotal) {
          clearInterval(intervalId);
          setEmProcesso(false);
          setEquipamentoStatus('concluido');
          return loteAtivo.quantidadeTotal;
        }
        
        // Incrementar quantidades
        const incremento = Math.ceil(loteAtivo.quantidadeTotal / 50); // Para simulação mais rápida
        
        // Simular rejeições ocasionais (cerca de 2%)
        if (Math.random() < 0.02) {
          setQuantidadeRejeitada(prevRej => prevRej + 1);
        }
        
        return Math.min(prev + incremento, loteAtivo.quantidadeTotal);
      });
    }, 1000);
  };

  const pausarProcesso = () => {
    setEmProcesso(false);
    setEquipamentoStatus('pausado');
  };

  const continuarProcesso = () => {
    setEmProcesso(true);
    setEquipamentoStatus('processando');
  };

  const finalizarProcesso = () => {
    setEmProcesso(false);
    setEquipamentoStatus('finalizado');
    setQuantidadeProcessada(loteAtivo.quantidadeTotal);
  };

  const reiniciarEquipamento = () => {
    setEquipamentoStatus('ligado');
    setEmProcesso(false);
    setQuantidadeProcessada(0);
    setQuantidadeRejeitada(0);
    resetarChecklist();
    setStatusImpressao('pendente');
  };

  const registrarLote = () => {
    alert("Lote de embalagem registrado com sucesso!");
    setLoteAtivo(null);
    setEquipamentoStatus('desligado');
    setEmProcesso(false);
    setQuantidadeProcessada(0);
    setQuantidadeRejeitada(0);
    resetarChecklist();
    setStatusImpressao('pendente');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Controle de Embalagem</h1>
          <p className="text-gray-500">Gerenciamento dos processos de embalagem primária e secundária</p>
        </div>
        <div className="flex gap-2">
          <Tabs value={tipoEmbalagem} onValueChange={alternarTipoEmbalagem}>
            <TabsList>
              <TabsTrigger value="primaria">Embalagem Primária</TabsTrigger>
              <TabsTrigger value="secundaria">Embalagem Secundária</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {!loteAtivo ? (
            <Card>
              <CardHeader>
                <CardTitle>Lotes Prontos para {tipoEmbalagem === 'primaria' ? 'Embalagem Primária' : 'Embalagem Secundária'}</CardTitle>
                <CardDescription>Selecione um lote para iniciar o processo</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <svg className="animate-spin h-8 w-8 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </div>
                ) : (
                  <>
                    {lotes.length === 0 ? (
                      <div className="text-center py-10">
                        <Box className="h-10 w-10 mx-auto text-gray-400 mb-3" />
                        <p className="text-gray-500">Nenhum lote disponível para {tipoEmbalagem === 'primaria' ? 'embalagem primária' : 'embalagem secundária'} no momento.</p>
                      </div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Lote</TableHead>
                            <TableHead>Produto</TableHead>
                            <TableHead>Ordem de Produção</TableHead>
                            <TableHead>Quantidade</TableHead>
                            <TableHead>Ação</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {lotes.map((lote) => (
                            <TableRow key={lote.id}>
                              <TableCell className="font-medium">{lote.id}</TableCell>
                              <TableCell>{lote.produto}</TableCell>
                              <TableCell>{lote.ordemProducao}</TableCell>
                              <TableCell>{lote.quantidadeTotal} {lote.unidade}</TableCell>
                              <TableCell>
                                <Button size="sm" onClick={() => selecionarLote(lote)}>
                                  Selecionar
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                    
                    {/* Mostrar lotes prontos para próxima etapa */}
                    {tipoEmbalagem === 'secundaria' && lotesProntos.length > 0 && (
                      <div className="mt-6 border-t pt-6">
                        <h3 className="text-sm font-medium mb-3">Lotes da Embalagem Primária Concluídos</h3>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Lote</TableHead>
                              <TableHead>Produto</TableHead>
                              <TableHead>Concluído em</TableHead>
                              <TableHead>Responsável</TableHead>
                              <TableHead>Ação</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {lotesProntos.map((lote) => (
                              <TableRow key={lote.id}>
                                <TableCell className="font-medium">{lote.id}</TableCell>
                                <TableCell>{lote.produto}</TableCell>
                                <TableCell>{lote.dataFinalizado}</TableCell>
                                <TableCell>{lote.responsavel}</TableCell>
                                <TableCell>
                                  <Button size="sm" variant="outline">
                                    <Eye className="h-4 w-4 mr-1" />
                                    Visualizar
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>{tipoEmbalagem === 'primaria' ? 'Embalagem Primária' : 'Embalagem Secundária'} - {loteAtivo.produto}</CardTitle>
                    <Badge>{loteAtivo.id}</Badge>
                  </div>
                  <CardDescription>
                    Ordem de Produção: {loteAtivo.ordemProducao} | Quantidade: {loteAtivo.quantidadeTotal} {loteAtivo.unidade}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Checklist de verificação */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-sm font-medium">Checklist de Verificação</h3>
                      <Badge variant={checklistConcluido ? 'default' : 'outline'} className={checklistConcluido ? 'bg-green-100 text-green-800' : ''}>
                        {checklistConcluido ? 'Concluído' : 'Pendente'}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="verificacaoRotulos" 
                          checked={checklist.verificacaoRotulos} 
                          onChange={(e) => atualizarChecklist('verificacaoRotulos', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso || statusImpressao === 'impressao'}
                        />
                        <label htmlFor="verificacaoRotulos" className="text-sm">
                          {tipoEmbalagem === 'primaria' ? 'Rótulos primários verificados' : 'Caixas e bulas verificadas'}
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="verificacaoEmbalagens" 
                          checked={checklist.verificacaoEmbalagens} 
                          onChange={(e) => atualizarChecklist('verificacaoEmbalagens', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso || statusImpressao === 'impressao'}
                        />
                        <label htmlFor="verificacaoEmbalagens" className="text-sm">
                          {tipoEmbalagem === 'primaria' ? 'Tampas e lacres verificados' : 'Etiquetas de rastreabilidade verificadas'}
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="verificacaoEquipamento" 
                          checked={checklist.verificacaoEquipamento} 
                          onChange={(e) => atualizarChecklist('verificacaoEquipamento', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso || statusImpressao === 'impressao'}
                        />
                        <label htmlFor="verificacaoEquipamento" className="text-sm">Equipamento verificado</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="verificacaoLotes" 
                          checked={checklist.verificacaoLotes} 
                          onChange={(e) => atualizarChecklist('verificacaoLotes', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso || statusImpressao === 'impressao'}
                        />
                        <label htmlFor="verificacaoLotes" className="text-sm">Lotes dos componentes verificados</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="verificacaoProcedimento" 
                          checked={checklist.verificacaoProcedimento} 
                          onChange={(e) => atualizarChecklist('verificacaoProcedimento', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso || statusImpressao === 'impressao'}
                        />
                        <label htmlFor="verificacaoProcedimento" className="text-sm">POP consultado</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="verificacaoMateriais" 
                          checked={checklist.verificacaoMateriais} 
                          onChange={(e) => atualizarChecklist('verificacaoMateriais', e.target.checked)}
                          className="rounded border-gray-300"
                          disabled={emProcesso || statusImpressao === 'impressao'}
                        />
                        <label htmlFor="verificacaoMateriais" className="text-sm">Materiais suficientes</label>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Impressão de rótulos/etiquetas */}
                  {tipoEmbalagem === 'primaria' && (
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="text-sm font-medium">Impressão de Rótulos</h3>
                        <Badge variant={statusImpressao === 'pendente' ? 'outline' : 'default'} className={
                          statusImpressao === 'impressao' ? 'bg-blue-100 text-blue-800' : 
                          statusImpressao === 'concluido' ? 'bg-green-100 text-green-800' : ''
                        }>
                          {statusImpressao === 'pendente' ? 'Pendente' : 
                           statusImpressao === 'impressao' ? 'Imprimindo...' : 'Concluído'}
                        </Badge>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <Printer className="w-5 h-5 text-gray-600" />
                            <span className="font-medium">Impressora de Rótulos #01</span>
                          </div>
                          <Button 
                            onClick={imprimirRotulos} 
                            disabled={!checklistConcluido || statusImpressao !== 'pendente' || emProcesso}
                          >
                            <Printer className="w-4 h-4 mr-2" />
                            Imprimir Rótulos
                          </Button>
                        </div>
                        
                        {statusImpressao === 'impressao' && (
                          <div className="mt-3">
                            <Progress value={45} className="h-2 mb-2" />
                            <p className="text-sm text-gray-500">Imprimindo rótulos... Por favor, aguarde.</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Progresso do processo */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-sm font-medium">Progresso do Processo</h3>
                      <div className="flex items-center gap-2">
                        <PackageOpen className="w-4 h-4 text-blue-500" />
                        <span className="text-sm font-medium">
                          {quantidadeProcessada} de {loteAtivo.quantidadeTotal} {loteAtivo.unidade}
                        </span>
                      </div>
                    </div>
                    
                    <Progress value={(quantidadeProcessada / loteAtivo.quantidadeTotal) * 100} className="h-2" />
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-1">
                        <AlertTriangle className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm">Rejeitados: {quantidadeRejeitada}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4 text-gray-500" />
                        <span className="text-sm">Rendimento: {quantidadeProcessada > 0 ? (((quantidadeProcessada - quantidadeRejeitada) / quantidadeProcessada) * 100).toFixed(1) : 0}%</span>
                      </div>
                    </div>
                    
                    <div className="flex justify-center gap-2 py-2">
                      {!emProcesso && equipamentoStatus !== 'concluido' && equipamentoStatus !== 'finalizado' && (
                        <Button 
                          onClick={iniciarProcesso} 
                          disabled={(tipoEmbalagem === 'primaria' && statusImpressao !== 'concluido') || equipamentoStatus === 'desligado'}
                        >
                          <PlayCircle className="w-4 h-4 mr-2" />
                          {equipamentoStatus === 'pausado' ? 'Continuar' : 'Iniciar Processo'}
                        </Button>
                      )}
                      
                      {emProcesso && (
                        <>
                          <Button variant="outline" onClick={pausarProcesso}>
                            <PauseCircle className="w-4 h-4 mr-2" />
                            Pausar
                          </Button>
                          <Button variant="outline" onClick={finalizarProcesso}>
                            <StopCircle className="w-4 h-4 mr-2" />
                            Finalizar
                          </Button>
                        </>
                      )}
                      
                      {equipamentoStatus === 'finalizado' && (
                        <Button onClick={registrarLote} className="bg-green-600 hover:bg-green-700">
                          <CheckCircle2 className="w-4 h-4 mr-2" />
                          Registrar Lote
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Materiais do lote */}
              <Card>
                <CardHeader>
                  <CardTitle>Materiais para {tipoEmbalagem === 'primaria' ? 'Embalagem Primária' : 'Embalagem Secundária'}</CardTitle>
                  <CardDescription>Materiais necessários para este processo</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Material</TableHead>
                        <TableHead>Lote</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loteAtivo.materiais.map((material, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{material.nome}</TableCell>
                          <TableCell>{material.lote}</TableCell>
                          <TableCell>{material.quantidade} un</TableCell>
                          <TableCell>
                            <Badge className="bg-green-100 text-green-800">Disponível</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Instruções de {tipoEmbalagem === 'primaria' ? 'Embalagem Primária' : 'Embalagem Secundária'}</CardTitle>
              <CardDescription>
                {tipoEmbalagem === 'primaria' 
                  ? 'Procedimento para rotulagem, fechamento e lacre dos frascos' 
                  : 'Procedimento para embalagem secundária e preparação final'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Badge className="mb-2">Procedimento</Badge>
                {tipoEmbalagem === 'primaria' ? (
                  <ol className="list-decimal list-inside space-y-2 text-sm">
                    <li>Verificar integridade dos frascos envasados</li>
                    <li>Verificar impressão e integridade dos rótulos</li>
                    <li>Aplicar conta-gotas e tampas nos frascos</li>
                    <li>Verificar vedação de cada frasco</li>
                    <li>Aplicar lacre de segurança</li>
                    <li>Aplicar rótulos com informações do lote</li>
                    <li>Realizar inspeção visual de cada unidade</li>
                    <li>Registrar amostragem e controles no sistema</li>
                  </ol>
                ) : (
                  <ol className="list-decimal list-inside space-y-2 text-sm">
                    <li>Verificar integridade das embalagens primárias</li>
                    <li>Inserir bula em cada caixa individual</li>
                    <li>Acondicionar frasco rotulado na caixa</li>
                    <li>Aplicar etiqueta com código de rastreabilidade</li>
                    <li>Fechar e selar caixa individual</li>
                    <li>Verificar impressão e informações</li>
                    <li>Agrupar em embalagens de transporte</li>
                    <li>Aplicar etiqueta de identificação do lote</li>
                  </ol>
                )}
              </div>

              <Separator />

              <div className="space-y-2">
                <Badge className="mb-2">Parâmetros de Controle</Badge>
                <div className="space-y-2 text-sm">
                  {tipoEmbalagem === 'primaria' ? (
                    <>
                      <p>• Verificar alinhamento dos rótulos</p>
                      <p>• Verificar estanqueidade das tampas</p>
                      <p>• Verificar integridade dos lacres</p>
                      <p>• Verificar informações impressas (lote, validade)</p>
                    </>
                  ) : (
                    <>
                      <p>• Verificar encaixe dos frascos nas caixas</p>
                      <p>• Verificar presença de bula em cada caixa</p>
                      <p>• Verificar fechamento das caixas</p>
                      <p>• Verificar etiquetas de rastreabilidade</p>
                    </>
                  )}
                </div>
              </div>

              <Separator />

              <div>
                <Badge className="mb-2">Controle de Qualidade</Badge>
                <div className="space-y-2 text-sm">
                  {tipoEmbalagem === 'primaria' ? (
                    <>
                      <p>• Inspecionar 100% dos frascos visualmente</p>
                      <p>• Verificar resistência dos lacres por amostragem</p>
                      <p>• Verificar vedação por amostragem</p>
                      <p>• Registrar rejeições e motivos</p>
                    </>
                  ) : (
                    <>
                      <p>• Inspecionar caixas por amostragem</p>
                      <p>• Verificar leitura dos códigos de rastreabilidade</p>
                      <p>• Verificar integridade das embalagens de transporte</p>
                      <p>• Verificar completude das informações</p>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Status do Equipamento</CardTitle>
              <CardDescription>
                {tipoEmbalagem === 'primaria' 
                  ? 'Máquina de Rotulagem e Lacre #02' 
                  : 'Máquina de Embalagem Secundária #01'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Velocidade</p>
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{emProcesso ? (tipoEmbalagem === 'primaria' ? '45' : '40') : '---'} un/min</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Produção Atual</p>
                  <div className="flex items-center">
                    <PackageOpen className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{emProcesso ? quantidadeProcessada : '---'} un</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Taxa de Rejeição</p>
                  <div className="flex items-center">
                    <AlertTriangle className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">
                      {quantidadeProcessada > 0 ? ((quantidadeRejeitada / quantidadeProcessada) * 100).toFixed(1) : '0.0'}%
                    </span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Status</p>
                  <div className="flex items-center mt-1">
                    {equipamentoStatus === 'desligado' && (
                      <Badge variant="outline">Desligado</Badge>
                    )}
                    {equipamentoStatus === 'ligado' && (
                      <Badge variant="outline">Ligado</Badge>
                    )}
                    {equipamentoStatus === 'pronto' && (
                      <Badge className="bg-yellow-100 text-yellow-800">Pronto</Badge>
                    )}
                    {equipamentoStatus === 'processando' && (
                      <Badge className="bg-blue-100 text-blue-800">Processando</Badge>
                    )}
                    {equipamentoStatus === 'pausado' && (
                      <Badge className="bg-orange-100 text-orange-800">Pausado</Badge>
                    )}
                    {equipamentoStatus === 'concluido' && (
                      <Badge className="bg-green-100 text-green-800">Concluído</Badge>
                    )}
                    {equipamentoStatus === 'finalizado' && (
                      <Badge className="bg-green-100 text-green-800">Finalizado</Badge>
                    )}
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Informações Adicionais</h3>
                <div className="text-sm">
                  <p>• Última calibração: {tipoEmbalagem === 'primaria' ? '18/07/2023' : '25/07/2023'}</p>
                  <p>• Próxima manutenção: {tipoEmbalagem === 'primaria' ? '18/10/2023' : '25/10/2023'}</p>
                  <p>• Operador responsável: {tipoEmbalagem === 'primaria' ? 'Pedro Mendes' : 'Ana Costa'}</p>
                  <p>• Status geral: Operacional</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}