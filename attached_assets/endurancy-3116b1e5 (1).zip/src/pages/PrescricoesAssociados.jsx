import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  FileText, 
  Search, 
  Filter, 
  PlusCircle, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Trash2, 
  Download, 
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Calendar,
  User,
  Stethoscope,
  Pill,
  Clock,
  FilePlus,
  Printer,
  Mail
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Dados simulados de prescrições
const mockPrescricoes = [
  {
    id: "presc-001",
    numero: "P23050001",
    data_emissao: "2023-05-10T14:30:00Z",
    data_validade: "2023-11-10T14:30:00Z",
    status: "ativa",
    associado: {
      id: "asc-001",
      nome: "Maria Silva",
      avatar: "MS"
    },
    medico: {
      nome: "Dr. Carlos Santos",
      crm: "CRM/SP 12345",
      especialidade: "Neurologista"
    },
    produtos: [
      { nome: "Óleo CBD 10% 30ml", posologia: "10 gotas, 2x ao dia" },
      { nome: "Pomada CBD para dores", posologia: "Aplicar na área afetada, 3x ao dia" }
    ],
    diagnostico: "Dor crônica e ansiedade",
    observacoes: "Paciente respondendo bem ao tratamento"
  },
  {
    id: "presc-002",
    numero: "P23050002",
    data_emissao: "2023-04-15T10:20:00Z",
    data_validade: "2023-10-15T10:20:00Z",
    status: "ativa",
    associado: {
      id: "asc-002",
      nome: "João Pereira",
      avatar: "JP"
    },
    medico: {
      nome: "Dra. Ana Beatriz",
      crm: "CRM/SP 54321",
      especialidade: "Neurologia"
    },
    produtos: [
      { nome: "Óleo CBD/THC 1:1 30ml", posologia: "5 gotas, 3x ao dia" }
    ],
    diagnostico: "Epilepsia",
    observacoes: "Reduzir frequência em caso de sonolência excessiva"
  },
  {
    id: "presc-003",
    numero: "P23050003",
    data_emissao: "2023-05-05T09:15:00Z",
    data_validade: "2023-11-05T09:15:00Z",
    status: "ativa",
    associado: {
      id: "asc-003",
      nome: "Ana Costa",
      avatar: "AC"
    },
    medico: {
      nome: "Dr. Paulo Menezes",
      crm: "CRM/SP 98765",
      especialidade: "Neurologia"
    },
    produtos: [
      { nome: "Óleo CBD 20% 30ml", posologia: "15 gotas, 2x ao dia" },
      { nome: "Spray Sublingual THC 5mg/dose", posologia: "2 borrifadas antes de dormir" }
    ],
    diagnostico: "Esclerose múltipla",
    observacoes: "Aumentar dosagem gradativamente"
  },
  {
    id: "presc-004",
    numero: "P23050004",
    data_emissao: "2023-01-10T14:20:00Z",
    data_validade: "2023-07-10T14:20:00Z",
    status: "expirada",
    associado: {
      id: "asc-004",
      nome: "Roberto Alves",
      avatar: "RA"
    },
    medico: {
      nome: "Dra. Márcia Oliveira",
      crm: "CRM/SP 45678",
      especialidade: "Psiquiatria"
    },
    produtos: [
      { nome: "Óleo CBD 5% 30ml", posologia: "5 gotas, 2x ao dia" }
    ],
    diagnostico: "Parkinson e Ansiedade",
    observacoes: "Paciente relatou melhora no tremor"
  },
  {
    id: "presc-005",
    numero: "P23050005",
    data_emissao: "2023-04-25T16:30:00Z",
    data_validade: "2023-10-25T16:30:00Z",
    status: "ativa",
    associado: {
      id: "asc-005",
      nome: "Fernanda Lima",
      avatar: "FL"
    },
    medico: {
      nome: "Dr. João Paulo",
      crm: "CRM/SP 56789",
      especialidade: "Reumatologia"
    },
    produtos: [
      { nome: "Cápsulas CBD 25mg", posologia: "1 cápsula, 2x ao dia" },
      { nome: "Pomada CBD/Arnica", posologia: "Aplicar nas articulações doloridas, 3x ao dia" }
    ],
    diagnostico: "Fibromialgia",
    observacoes: "Evitar uso concomitante com outros anti-inflamatórios"
  },
  {
    id: "presc-006",
    numero: "P23050006",
    data_emissao: "2023-05-18T15:40:00Z",
    data_validade: "2023-11-18T15:40:00Z",
    status: "ativa",
    associado: {
      id: "asc-006",
      nome: "Paulo Rodrigues",
      avatar: "PR"
    },
    medico: {
      nome: "Dra. Ana Beatriz",
      crm: "CRM/SP 54321",
      especialidade: "Neurologia"
    },
    produtos: [
      { nome: "Óleo CBD 15% 30ml", posologia: "10 gotas, 3x ao dia" }
    ],
    diagnostico: "Autismo",
    observacoes: "Avaliar resposta comportamental após 30 dias"
  }
];

export default function PrescricoesAssociados() {
  const navigate = useNavigate();
  const [prescricoes, setPrescricoes] = useState([]);
  const [filteredPrescricoes, setFilteredPrescricoes] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');
  const [medicoFilter, setMedicoFilter] = useState('todos');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("todos");
  const [detalheDialogOpen, setDetalheDialogOpen] = useState(false);
  const [prescricaoSelecionada, setPrescricaoSelecionada] = useState(null);

  useEffect(() => {
    // Simulando carregamento de dados
    setTimeout(() => {
      setPrescricoes(mockPrescricoes);
      setFilteredPrescricoes(mockPrescricoes);
      setLoading(false);
    }, 500);
  }, []);

  useEffect(() => {
    let result = [...prescricoes];
    
    // Aplicar filtro por tab
    if (activeTab !== "todos") {
      result = result.filter(presc => presc.status === activeTab);
    }
    
    // Aplicar filtro de status
    if (statusFilter !== 'todos') {
      result = result.filter(presc => presc.status === statusFilter);
    }
    
    // Aplicar filtro de médico
    if (medicoFilter !== 'todos') {
      result = result.filter(presc => presc.medico.nome === medicoFilter);
    }
    
    // Aplicar termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(presc => 
        presc.numero.toLowerCase().includes(term) || 
        presc.associado.nome.toLowerCase().includes(term) ||
        presc.medico.nome.toLowerCase().includes(term) ||
        presc.diagnostico.toLowerCase().includes(term)
      );
    }
    
    setFilteredPrescricoes(result);
  }, [prescricoes, searchTerm, statusFilter, medicoFilter, activeTab]);

  const getStatusBadge = (status) => {
    switch (status) {
      case 'ativa':
        return <Badge className="bg-green-100 text-green-800">Ativa</Badge>;
      case 'pendente':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'expirada':
        return <Badge className="bg-red-100 text-red-800">Expirada</Badge>;
      case 'cancelada':
        return <Badge className="bg-gray-100 text-gray-800">Cancelada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  const handleOpenDetalhe = (prescricao) => {
    setPrescricaoSelecionada(prescricao);
    setDetalheDialogOpen(true);
  };

  const renderDetalheDialog = () => {
    if (!prescricaoSelecionada) return null;
    
    return (
      <Dialog open={detalheDialogOpen} onOpenChange={setDetalheDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Detalhes da Prescrição #{prescricaoSelecionada.numero}</DialogTitle>
            <DialogDescription>
              Informações completas sobre a prescrição médica.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Avatar className="h-12 w-12 mr-4">
                  <AvatarFallback>{prescricaoSelecionada.associado.avatar}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-lg">{prescricaoSelecionada.associado.nome}</p>
                  <p className="text-sm text-gray-500">ID: {prescricaoSelecionada.associado.id}</p>
                </div>
              </div>
              {getStatusBadge(prescricaoSelecionada.status)}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center">
                    <Stethoscope className="mr-2 h-4 w-4 text-blue-500" />
                    <CardTitle className="text-base">Informações Médicas</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <dl className="space-y-2">
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Médico</dt>
                      <dd className="text-sm">{prescricaoSelecionada.medico.nome}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">CRM</dt>
                      <dd className="text-sm">{prescricaoSelecionada.medico.crm}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Especialidade</dt>
                      <dd className="text-sm">{prescricaoSelecionada.medico.especialidade}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Diagnóstico</dt>
                      <dd className="text-sm">{prescricaoSelecionada.diagnostico}</dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center">
                    <Calendar className="mr-2 h-4 w-4 text-green-500" />
                    <CardTitle className="text-base">Datas</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <dl className="space-y-2">
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Data de Emissão</dt>
                      <dd className="text-sm">{formatDate(prescricaoSelecionada.data_emissao)}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Validade</dt>
                      <dd className="text-sm">{formatDate(prescricaoSelecionada.data_validade)}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Duração</dt>
                      <dd className="text-sm">6 meses</dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center">
                  <Pill className="mr-2 h-4 w-4 text-purple-500" />
                  <CardTitle className="text-base">Produtos Prescritos</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {prescricaoSelecionada.produtos.map((produto, idx) => (
                    <div key={idx} className="border-b pb-4 last:border-b-0 last:pb-0">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">{produto.nome}</p>
                          <p className="text-sm text-gray-600">{produto.posologia}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {prescricaoSelecionada.observacoes && (
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center">
                    <FileText className="mr-2 h-4 w-4 text-gray-500" />
                    <CardTitle className="text-base">Observações</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">{prescricaoSelecionada.observacoes}</p>
                </CardContent>
              </Card>
            )}
          </div>
          
          <div className="flex justify-between items-center pt-4 border-t">
            <div className="flex">
              {prescricaoSelecionada.status === 'expirada' && (
                <Button variant="outline" className="mr-2">
                  <FilePlus className="w-4 h-4 mr-2" />
                  Solicitar Renovação
                </Button>
              )}
              <Button variant="outline">
                <Printer className="w-4 h-4 mr-2" />
                Imprimir
              </Button>
            </div>
            <Button onClick={() => setDetalheDialogOpen(false)}>
              Fechar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  // Extrair lista de médicos únicos
  const medicos = [
    ...new Set(prescricoes.map(presc => presc.medico.nome))
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Prescrições Médicas dos Associados</h1>
        <p className="text-gray-500 mt-1">
          Gerencie todas as prescrições médicas dos associados da sua organização.
        </p>
      </div>

      <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4 sm:justify-between">
        <div className="flex-1 max-w-md relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar por número, paciente ou médico..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4">
          <Select value={medicoFilter} onValueChange={setMedicoFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Médico" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os médicos</SelectItem>
              {medicos.map(medico => (
                <SelectItem key={medico} value={medico}>{medico}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os status</SelectItem>
              <SelectItem value="ativa">Ativa</SelectItem>
              <SelectItem value="pendente">Pendente</SelectItem>
              <SelectItem value="expirada">Expirada</SelectItem>
              <SelectItem value="cancelada">Cancelada</SelectItem>
            </SelectContent>
          </Select>
          
          <Button onClick={() => navigate(createPageUrl("NovaPrescricao"))}>
            <FilePlus className="w-4 h-4 mr-2" />
            Nova Prescrição
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="todos">Todas</TabsTrigger>
          <TabsTrigger value="ativa">Ativas</TabsTrigger>
          <TabsTrigger value="pendente">Pendentes</TabsTrigger>
          <TabsTrigger value="expirada">Expiradas</TabsTrigger>
        </TabsList>
        
        <TabsContent value={activeTab}>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Lista de Prescrições</CardTitle>
              <CardDescription>
                {filteredPrescricoes.length} prescrições encontradas
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <div className="animate-spin w-8 h-8 border-t-2 border-blue-500 border-r-2 rounded-full mx-auto mb-4"></div>
                  <p className="text-gray-500">Carregando prescrições...</p>
                </div>
              ) : filteredPrescricoes.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900">Nenhuma prescrição encontrada</h3>
                  <p className="text-gray-500 mt-2">
                    Não existem prescrições que correspondam aos critérios selecionados.
                  </p>
                  <Button variant="outline" className="mt-4" onClick={() => {
                    setSearchTerm('');
                    setStatusFilter('todos');
                    setMedicoFilter('todos');
                  }}>
                    Limpar filtros
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Número</TableHead>
                        <TableHead>Associado</TableHead>
                        <TableHead>Médico</TableHead>
                        <TableHead>Diagnóstico</TableHead>
                        <TableHead>Emissão</TableHead>
                        <TableHead>Validade</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPrescricoes.map((prescricao) => (
                        <TableRow key={prescricao.id} className="cursor-pointer hover:bg-gray-50" onClick={() => handleOpenDetalhe(prescricao)}>
                          <TableCell className="font-medium">{prescricao.numero}</TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Avatar className="h-7 w-7 mr-2">
                                <AvatarFallback>
                                  {prescricao.associado.avatar}
                                </AvatarFallback>
                              </Avatar>
                              <span>{prescricao.associado.nome}</span>
                            </div>
                          </TableCell>
                          <TableCell>{prescricao.medico.nome}</TableCell>
                          <TableCell>{prescricao.diagnostico}</TableCell>
                          <TableCell>{formatDate(prescricao.data_emissao)}</TableCell>
                          <TableCell>{formatDate(prescricao.data_validade)}</TableCell>
                          <TableCell>{getStatusBadge(prescricao.status)}</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon" onClick={(e) => {
                              e.stopPropagation();
                              handleOpenDetalhe(prescricao);
                            }}>
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {renderDetalheDialog()}
    </div>
  );
}