import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { ModuloDispensario } from '@/api/entities';
import { Check, CreditCard, Building2, FileText, Lock, Calendar } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { toast } from "@/components/ui/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function DispensarioAssinatura() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('credit_card');
  const [paymentInfo, setPaymentInfo] = useState({
    cardNumber: '',
    cardName: '',
    expiry: '',
    cvv: '',
    installments: '1'
  });
  
  const handlePaymentInfoChange = (e) => {
    const { name, value } = e.target;
    setPaymentInfo(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Simulando o processo de contratação
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Criar/ativar o módulo para a organização
      const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
      const orgId = userInfo.organization_id || 'org_example';
      
      // Criando o registro de módulo
      await ModuloDispensario.create({
        organization_id: orgId,
        is_active: true,
        subscription_start: new Date().toISOString(),
        subscription_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 dias
        status: 'active'
      });
      
      toast({
        title: "Assinatura ativada com sucesso!",
        description: "O módulo Dispensário está agora disponível para sua organização.",
      });
      
      // Redirecionar para o dashboard do módulo
      navigate(createPageUrl("DispensarioDashboard"));
    } catch (error) {
      console.error('Erro ao processar assinatura:', error);
      toast({
        variant: "destructive",
        title: "Erro ao processar pagamento",
        description: "Houve um problema ao processar sua assinatura. Por favor, tente novamente.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Assinatura do Módulo Dispensário</h1>
        <p className="text-gray-500">Complete o processo de assinatura para transformar sua organização em uma farmácia completa</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Informações de Pagamento</CardTitle>
              <CardDescription>Escolha seu método de pagamento preferido</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit}>
                <RadioGroup 
                  value={paymentMethod} 
                  onValueChange={setPaymentMethod}
                  className="mb-6"
                >
                  <div className="flex items-center space-x-2 border rounded-md p-3 mb-2">
                    <RadioGroupItem value="credit_card" id="credit_card" />
                    <Label htmlFor="credit_card" className="flex items-center">
                      <CreditCard className="mr-2 h-4 w-4" />
                      Cartão de Crédito
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2 border rounded-md p-3 mb-2">
                    <RadioGroupItem value="boleto" id="boleto" />
                    <Label htmlFor="boleto" className="flex items-center">
                      <FileText className="mr-2 h-4 w-4" />
                      Boleto Bancário
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <RadioGroupItem value="pix" id="pix" />
                    <Label htmlFor="pix" className="flex items-center">
                      <Building2 className="mr-2 h-4 w-4" />
                      PIX
                    </Label>
                  </div>
                </RadioGroup>
                
                {paymentMethod === 'credit_card' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="cardNumber">Número do Cartão</Label>
                        <Input
                          id="cardNumber"
                          name="cardNumber"
                          placeholder="0000 0000 0000 0000"
                          value={paymentInfo.cardNumber}
                          onChange={handlePaymentInfoChange}
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="cardName">Nome no Cartão</Label>
                        <Input
                          id="cardName"
                          name="cardName"
                          placeholder="Como aparece no cartão"
                          value={paymentInfo.cardName}
                          onChange={handlePaymentInfoChange}
                          required
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="expiry">Validade</Label>
                          <Input
                            id="expiry"
                            name="expiry"
                            placeholder="MM/AA"
                            value={paymentInfo.expiry}
                            onChange={handlePaymentInfoChange}
                            required
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="cvv">CVV</Label>
                          <Input
                            id="cvv"
                            name="cvv"
                            placeholder="123"
                            value={paymentInfo.cvv}
                            onChange={handlePaymentInfoChange}
                            required
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="installments">Parcelas</Label>
                        <Select 
                          value={paymentInfo.installments} 
                          onValueChange={(value) => setPaymentInfo(prev => ({...prev, installments: value}))}
                        >
                          <SelectTrigger id="installments">
                            <SelectValue placeholder="Selecione o número de parcelas" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1x de R$ 299,00 (sem juros)</SelectItem>
                            <SelectItem value="2">2x de R$ 149,50 (sem juros)</SelectItem>
                            <SelectItem value="3">3x de R$ 99,67 (sem juros)</SelectItem>
                            <SelectItem value="6">6x de R$ 49,83 (sem juros)</SelectItem>
                            <SelectItem value="12">12x de R$ 24,92 (sem juros)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                )}
                
                {paymentMethod === 'boleto' && (
                  <div className="p-4 bg-gray-50 rounded-md text-center">
                    <FileText className="mx-auto h-16 w-16 text-gray-400 mb-2" />
                    <p className="mb-2">O boleto será gerado após a confirmação</p>
                    <p className="text-sm text-gray-500">Processamento em até 3 dias úteis</p>
                  </div>
                )}
                
                {paymentMethod === 'pix' && (
                  <div className="p-4 bg-gray-50 rounded-md text-center">
                    <Building2 className="mx-auto h-16 w-16 text-gray-400 mb-2" />
                    <p className="mb-2">O QR Code PIX será exibido após a confirmação</p>
                    <p className="text-sm text-gray-500">Pagamento instantâneo</p>
                  </div>
                )}
                
                <div className="mt-6">
                  <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={isLoading}>
                    {isLoading ? "Processando..." : `Pagar R$ 299,00`}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Resumo da Compra</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Plano Dispensário</span>
                  <span>R$ 299,00</span>
                </div>
                
                <Separator />
                
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>R$ 299,00</span>
                </div>
                
                <div className="mt-6 space-y-2">
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="mr-2 h-4 w-4" />
                    <span>Cobrança mensal recorrente</span>
                  </div>
                  
                  <div className="flex items-center text-sm text-gray-500">
                    <Lock className="mr-2 h-4 w-4" />
                    <span>Pagamento seguro criptografado</span>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <div className="text-sm">
                <h3 className="font-medium mb-2">O que está incluído:</h3>
                <ul className="space-y-1">
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-green-500" />
                    PDV com Cupom Fiscal
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-green-500" />
                    Gestão de Estoque
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-green-500" />
                    Controle de Caixa
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-green-500" />
                    Integração SNGPC
                  </li>
                  <li className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-green-500" />
                    Suporte Prioritário
                  </li>
                </ul>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}