import React, { useState, useEffect } from 'react';
import { useSearchParams, Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardFooter,
  CardDescription
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  PlayCircle,
  FileText,
  MousePointerClick,
  ArrowLeft,
  ArrowRight,
  CheckCircle,
  Clock,
  BookOpen,
  ThumbsUp,
  ThumbsDown,
  Play,
  Pause,
  Volume2,
  VolumeX
} from 'lucide-react';

// Mock tutorial data
const tutorialData = {
  "intro-platform": {
    id: "intro-platform",
    title: "Introdução à Plataforma",
    description: "Conheça as funcionalidades básicas e navegação do sistema",
    moduleId: "getting-started",
    moduleName: "Começando",
    type: "video",
    duration: "5 min",
    videoUrl: "https://example.com/videos/intro.mp4",
    content: `
      <div class="space-y-6">
        <p>Esta introdução vai ajudar você a se familiarizar com a plataforma Endurancy. Aprenda a navegar pela interface e conheça as funcionalidades principais disponíveis para sua organização.</p>
        
        <h3 class="text-xl font-semibold">O que você vai aprender:</h3>
        <ul class="list-disc pl-6 space-y-2">
          <li>Como navegar pelo menu principal</li>
          <li>Entender o Dashboard e métricas principais</li>
          <li>Acessar configurações do seu perfil</li>
          <li>Conhecer os módulos disponíveis</li>
        </ul>
      </div>
    `,
    sections: [
      {
        id: "section-1",
        title: "Visão Geral da Interface",
        content: `
          <div class="space-y-4">
            <p>A interface da plataforma Endurancy foi projetada para ser intuitiva e eficiente. Conheça os elementos principais:</p>
            
            <ul class="list-disc pl-6 space-y-2">
              <li><strong>Menu Lateral:</strong> Navegação principal entre módulos</li>
              <li><strong>Cabeçalho:</strong> Acesso rápido a notificações, perfil e busca</li>
              <li><strong>Área de Conteúdo:</strong> Informações e funcionalidades do módulo selecionado</li>
              <li><strong>Rodapé:</strong> Links úteis e informações adicionais</li>
            </ul>
            
            <div class="my-6 p-4 bg-blue-50 rounded-lg">
              <p class="font-medium text-blue-800">Dica:</p>
              <p>Você pode minimizar o menu lateral clicando no ícone no topo para ter mais espaço de trabalho.</p>
            </div>
          </div>
        `
      },
      {
        id: "section-2",
        title: "Navegação Entre Módulos",
        content: `
          <div class="space-y-4">
            <p>A plataforma está organizada em módulos funcionais que atendem a diferentes necessidades:</p>
            
            <ul class="list-disc pl-6 space-y-3">
              <li>
                <strong>Dashboard:</strong> Visão geral com métricas e indicadores importantes
              </li>
              <li>
                <strong>Módulo Cultivo:</strong> Gerenciamento completo do processo de cultivo, desde o plantio até a colheita
              </li>
              <li>
                <strong>Módulo Produção:</strong> Controle do processo produtivo, garantia de qualidade e rastreabilidade
              </li>
              <li>
                <strong>Dispensário:</strong> Gerenciamento de estoque, vendas e controle de receituário
              </li>
              <li>
                <strong>Pacientes/Associados:</strong> Cadastro e gestão de relacionamento com clientes
              </li>
              <li>
                <strong>Financeiro:</strong> Controle financeiro, relatórios e gestão de pagamentos
              </li>
            </ul>
            
            <p class="mt-4">Cada módulo possui seu próprio conjunto de funções e ferramentas específicas que serão detalhadas em tutoriais dedicados.</p>
          </div>
        `
      },
      {
        id: "section-3",
        title: "Perfil e Configurações",
        content: `
          <div class="space-y-4">
            <p>Personalizar seu perfil e configurações melhora sua experiência na plataforma:</p>
            
            <h4 class="font-medium">Acessando seu perfil:</h4>
            <ol class="list-decimal pl-6 space-y-2">
              <li>Clique no seu avatar no canto superior direito</li>
              <li>Selecione "Meu Perfil" no menu dropdown</li>
              <li>Aqui você pode atualizar suas informações pessoais, preferências e configurações de notificação</li>
            </ol>
            
            <h4 class="font-medium mt-4">Configurações importantes:</h4>
            <ul class="list-disc pl-6 space-y-2">
              <li><strong>Modo Escuro:</strong> Alterne entre temas claro e escuro</li>
              <li><strong>Notificações:</strong> Configure quais alertas você deseja receber</li>
              <li><strong>Segurança:</strong> Gerencie sua senha e opções de autenticação</li>
            </ul>
            
            <div class="my-6 p-4 bg-amber-50 rounded-lg">
              <p class="font-medium text-amber-800">Importante:</p>
              <p>Mantenha seus dados de contato atualizados para receber notificações importantes do sistema.</p>
            </div>
          </div>
        `
      }
    ]
  },
  "cultivation-basic": {
    id: "cultivation-basic",
    title: "Fundamentos do Cultivo",
    description: "Aprenda a gerenciar plantas, lotes e processos de cultivo",
    moduleId: "cultivation",
    moduleName: "Módulo Cultivo",
    type: "text",
    duration: "8 min",
    content: `
      <div class="space-y-6">
        <p>Este tutorial apresenta os fundamentos do Módulo de Cultivo, onde você aprenderá a gerenciar plantas, lotes e acompanhar todo o processo de cultivo com eficiência e rastreabilidade.</p>
        
        <h3 class="text-xl font-semibold">O que você vai aprender:</h3>
        <ul class="list-disc pl-6 space-y-2">
          <li>Como cadastrar e rastrear plantas individuais</li>
          <li>Gestão de lotes de produção</li>
          <li>Registro e monitoramento das fases de cultivo</li>
          <li>Integração com controle de qualidade</li>
        </ul>
      </div>
    `,
    sections: [
      {
        id: "section-1",
        title: "Cadastro de Plantas",
        content: `
          <div class="space-y-4">
            <p>O registro detalhado de cada planta permite rastreabilidade completa e monitoramento preciso:</p>
            
            <h4 class="font-medium">Como cadastrar uma nova planta:</h4>
            <ol class="list-decimal pl-6 space-y-2">
              <li>Acesse o módulo Cultivo no menu principal</li>
              <li>Clique em "Plantas" e depois no botão "Nova Planta"</li>
              <li>Preencha todas as informações obrigatórias como strain, origem e fase inicial</li>
              <li>Atribua um identificador único ou deixe o sistema gerar automaticamente</li>
              <li>Associe a planta a um lote existente ou crie um novo</li>
              <li>Salve as informações</li>
            </ol>
            
            <div class="my-6 p-4 bg-blue-50 rounded-lg">
              <p class="font-medium text-blue-800">Dica:</p>
              <p>Utilize códigos QR para identificação rápida de plantas no ambiente de cultivo.</p>
            </div>
            
            <h4 class="font-medium mt-4">Informações importantes para registro:</h4>
            <ul class="list-disc pl-6 space-y-2">
              <li><strong>Strain/Variedade:</strong> Identificação genética da planta</li>
              <li><strong>Origem:</strong> Semente, clone ou planta-mãe</li>
              <li><strong>Data de plantio:</strong> Início do ciclo de vida</li>
              <li><strong>Localização:</strong> Área específica dentro da instalação</li>
            </ul>
          </div>
        `
      },
      {
        id: "section-2",
        title: "Gestão de Lotes",
        content: `
          <div class="space-y-4">
            <p>Os lotes permitem agrupar plantas com características semelhantes para facilitar o gerenciamento:</p>
            
            <h4 class="font-medium">Criando e gerenciando lotes:</h4>
            <ol class="list-decimal pl-6 space-y-2">
              <li>Acesse "Lotes" no menu do módulo Cultivo</li>
              <li>Clique em "Novo Lote" e defina as informações básicas</li>
              <li>Especifique a strain, origem e quantidade de plantas</li>
              <li>Defina a localização física do lote nas instalações</li>
              <li>Estabeleça datas previstas para mudanças de fase</li>
            </ol>
            
            <h4 class="font-medium mt-4">Acompanhamento de lotes:</h4>
            <ul class="list-disc pl-6 space-y-2">
              <li>Monitore métricas específicas como taxa de sobrevivência</li>
              <li>Registre todas as intervenções (nutrição, tratamentos)</li>
              <li>Acompanhe o desenvolvimento por fase</li>
              <li>Documente problemas e soluções aplicadas</li>
            </ul>
            
            <div class="my-6 p-4 bg-amber-50 rounded-lg">
              <p class="font-medium text-amber-800">Importante:</p>
              <p>A rastreabilidade completa dos lotes é essencial para conformidade regulatória e controle de qualidade.</p>
            </div>
          </div>
        `
      }
    ]
  },
  "quality-management": {
    id: "quality-management",
    title: "Gestão da Qualidade na Produção",
    description: "Aprenda a configurar e gerenciar processos de qualidade",
    moduleId: "production",
    moduleName: "Módulo Produção",
    type: "interactive",
    duration: "12 min",
    content: `
      <div class="space-y-6">
        <p>Este tutorial apresenta os conceitos fundamentais e práticas de Gestão da Qualidade no módulo de Produção, essenciais para garantir produtos seguros e conformes.</p>
        
        <h3 class="text-xl font-semibold">O que você vai aprender:</h3>
        <ul class="list-disc pl-6 space-y-2">
          <li>Configuração de protocolos de qualidade</li>
          <li>Realização de análises e testes</li>
          <li>Gestão de não-conformidades</li>
          <li>Liberação de lotes</li>
          <li>Documentação e rastreabilidade</li>
        </ul>
      </div>
    `,
    sections: [
      {
        id: "section-1",
        title: "Protocolos de Qualidade",
        content: `
          <div class="space-y-4">
            <p>Protocolos bem definidos são a base de um sistema de qualidade eficiente:</p>
            
            <h4 class="font-medium">Configurando protocolos:</h4>
            <ol class="list-decimal pl-6 space-y-2">
              <li>Acesse "Qualidade" no módulo de Produção</li>
              <li>Selecione "Protocolos" e "Novo Protocolo"</li>
              <li>Defina os parâmetros de teste obrigatórios</li>
              <li>Estabeleça limites de aceitação para cada parâmetro</li>
              <li>Configure a frequência de testes e amostragem</li>
              <li>Defina fluxos de aprovação e liberação</li>
            </ol>
            
            <div class="my-6 p-4 bg-blue-50 rounded-lg">
              <p class="font-medium text-blue-800">Dica:</p>
              <p>Crie protocolos específicos para diferentes tipos de produtos e matérias-primas.</p>
            </div>
          </div>
        `
      },
      {
        id: "section-2",
        title: "Análises e Testes",
        content: `
          <div class="space-y-4">
            <p>O registro adequado de testes e análises é crucial para a qualidade e conformidade:</p>
            
            <h4 class="font-medium">Realizando testes de qualidade:</h4>
            <ol class="list-decimal pl-6 space-y-2">
              <li>Acesse "Nova Análise" na seção de Qualidade</li>
              <li>Selecione o lote ou material a ser analisado</li>
              <li>Escolha o protocolo aplicável</li>
              <li>Registre a coleta de amostras e quantidade</li>
              <li>Insira os resultados para cada parâmetro</li>
              <li>Anexe documentação de suporte quando necessário</li>
              <li>Submetà para aprovação final</li>
            </ol>
            
            <h4 class="font-medium mt-4">Tipos de análises comuns:</h4>
            <ul class="list-disc pl-6 space-y-2">
              <li><strong>Microbiológicas:</strong> Detecção de contaminantes</li>
              <li><strong>Físico-químicas:</strong> Composição e estabilidade</li>
              <li><strong>Organolépticas:</strong> Características sensoriais</li>
              <li><strong>Potência:</strong> Teor de canabinoides</li>
            </ul>
            
            <div class="my-6 p-4 bg-amber-50 rounded-lg">
              <p class="font-medium text-amber-800">Importante:</p>
              <p>Mantenha os equipamentos de análise devidamente calibrados e registre os certificados de calibração no sistema.</p>
            </div>
          </div>
        `
      }
    ]
  }
};

export default function OnboardingTutorialView() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const tutorialId = searchParams.get("id");
  const [currentTutorial, setCurrentTutorial] = useState(null);
  const [currentSection, setCurrentSection] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  useEffect(() => {
    // Load tutorial data
    if (tutorialId && tutorialData[tutorialId]) {
      setCurrentTutorial(tutorialData[tutorialId]);
      // Check if this tutorial is already completed (would come from actual user data in real implementation)
      setIsCompleted(false);
      setCurrentSection(0);
      setProgress(0);
    } else {
      // Handle invalid tutorial ID
      console.error("Tutorial not found");
      // Could redirect to tutorials list
    }
  }, [tutorialId]);

  const handleNextSection = () => {
    if (currentTutorial && currentSection < currentTutorial.sections.length - 1) {
      setCurrentSection(currentSection + 1);
      // Calculate progress
      const newProgress = Math.round(((currentSection + 2) / (currentTutorial.sections.length + 1)) * 100);
      setProgress(newProgress);
    } else {
      // Last section - mark as completed
      setIsCompleted(true);
      setProgress(100);
    }
  };

  const handlePreviousSection = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1);
      // Calculate progress
      const newProgress = Math.round(((currentSection) / (currentTutorial.sections.length + 1)) * 100);
      setProgress(newProgress);
    }
  };

  const handleComplete = () => {
    // Mark tutorial as completed in user's progress
    console.log("Tutorial completed:", tutorialId);
    // In a real implementation, would send to backend
    
    // Navigate back to tutorials list
    navigate(createPageUrl("OnboardingTutorials"));
  };

  const handleFeedback = (positive) => {
    // Send feedback to backend
    console.log("Feedback submitted:", positive ? "positive" : "negative");
    setFeedbackSubmitted(true);
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'video':
        return <PlayCircle className="w-5 h-5 text-blue-500" />;
      case 'text':
        return <FileText className="w-5 h-5 text-emerald-500" />;
      case 'interactive':
        return <MousePointerClick className="w-5 h-5 text-amber-500" />;
      default:
        return <BookOpen className="w-5 h-5 text-gray-500" />;
    }
  };

  if (!currentTutorial) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 max-w-5xl">
      <div className="mb-6">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link to={createPageUrl("OnboardingTutorials")} className="hover:text-primary transition-colors">
            Tutoriais
          </Link>
          <span>/</span>
          <span>{currentTutorial.moduleName}</span>
          <span>/</span>
          <span className="text-gray-900">{currentTutorial.title}</span>
        </div>
        
        <div className="flex justify-between items-start">
          <div>
            <div className="flex items-center gap-3 mb-2">
              {getTypeIcon(currentTutorial.type)}
              <h1 className="text-2xl font-bold">{currentTutorial.title}</h1>
            </div>
            <p className="text-gray-500">{currentTutorial.description}</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {currentTutorial.duration}
            </Badge>
            {isCompleted && (
              <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                Concluído
              </Badge>
            )}
          </div>
        </div>
        
        <Progress value={progress} className="h-2 mt-4" />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>
                {currentTutorial.sections[currentSection]?.title || currentTutorial.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {currentTutorial.type === 'video' && (
                <div className="relative aspect-video bg-black/5 rounded-md mb-6 flex justify-center items-center">
                  {/* Placeholder for actual video player */}
                  <div className="text-center">
                    <div className="inline-flex justify-center items-center w-16 h-16 rounded-full bg-black/10 mb-4">
                      <Play className="w-8 h-8 text-primary" />
                    </div>
                    <p className="text-gray-500">Video player would be here</p>
                    
                    <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="bg-white/80"
                        onClick={() => setIsPlaying(!isPlaying)}
                      >
                        {isPlaying ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                        {isPlaying ? 'Pause' : 'Play'}
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="bg-white/80"
                        onClick={() => setIsMuted(!isMuted)}
                      >
                        {isMuted ? <VolumeX className="w-4 h-4 mr-2" /> : <Volume2 className="w-4 h-4 mr-2" />}
                        {isMuted ? 'Unmute' : 'Mute'}
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              
              {currentTutorial.type === 'interactive' && (
                <div className="p-4 mb-6 border rounded-md bg-amber-50 border-amber-200">
                  <p className="text-amber-800 flex items-center gap-2">
                    <MousePointerClick className="w-5 h-5" />
                    Este é um tutorial interativo. Siga as instruções e complete as tarefas para avançar.
                  </p>
                </div>
              )}
              
              <div 
                className="prose prose-blue max-w-none"
                dangerouslySetInnerHTML={{ 
                  __html: currentTutorial.sections[currentSection]?.content || currentTutorial.content 
                }}
              />
            </CardContent>
            <CardFooter className="flex justify-between pt-2 border-t">
              <Button
                variant="outline"
                onClick={handlePreviousSection}
                disabled={currentSection === 0}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Anterior
              </Button>
              
              {currentSection < currentTutorial.sections.length - 1 ? (
                <Button onClick={handleNextSection}>
                  Próximo
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button 
                  onClick={handleComplete}
                  disabled={isCompleted}
                  className={isCompleted ? "bg-green-600 hover:bg-green-700" : ""}
                >
                  {isCompleted ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Concluído
                    </>
                  ) : (
                    <>
                      Concluir Tutorial
                      <CheckCircle className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              )}
            </CardFooter>
          </Card>
          
          {isCompleted && !feedbackSubmitted && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-base">Este tutorial foi útil?</CardTitle>
                <CardDescription>Sua opinião nos ajuda a melhorar o conteúdo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <Button 
                    variant="outline" 
                    className="flex-1" 
                    onClick={() => handleFeedback(true)}
                  >
                    <ThumbsUp className="w-4 h-4 mr-2" />
                    Sim, foi útil
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1" 
                    onClick={() => handleFeedback(false)}
                  >
                    <ThumbsDown className="w-4 h-4 mr-2" />
                    Precisa melhorar
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
          
          {feedbackSubmitted && (
            <div className="mt-6 p-4 bg-green-50 rounded-md text-green-800 flex items-center gap-2">
              <CheckCircle className="w-5 h-5" />
              Obrigado pelo feedback! Ele nos ajuda a melhorar nossos tutoriais.
            </div>
          )}
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Conteúdo</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {currentTutorial.sections.map((section, index) => (
                  <Button
                    key={section.id}
                    variant={currentSection === index ? "default" : "ghost"}
                    className={`w-full justify-start ${index <= currentSection ? "text-primary" : "text-gray-700"}`}
                    onClick={() => setCurrentSection(index)}
                  >
                    {index <= currentSection && (
                      <span className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-2 text-xs">
                        {index + 1}
                      </span>
                    )}
                    {index > currentSection && (
                      <span className="w-5 h-5 rounded-full bg-gray-100 text-gray-500 flex items-center justify-center mr-2 text-xs">
                        {index + 1}
                      </span>
                    )}
                    <span className="truncate">{section.title}</span>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-base">Tutoriais Relacionados</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-4">
                {Object.values(tutorialData)
                  .filter(tutorial => tutorial.moduleId === currentTutorial.moduleId && tutorial.id !== currentTutorial.id)
                  .slice(0, 3)
                  .map(tutorial => (
                    <Link 
                      key={tutorial.id}
                      to={`${createPageUrl("OnboardingTutorialView")}?id=${tutorial.id}`}
                      className="block"
                    >
                      <div className="flex items-start gap-3 group">
                        <div className="mt-1">
                          {getTypeIcon(tutorial.type)}
                        </div>
                        <div>
                          <h3 className="font-medium group-hover:text-primary transition-colors">
                            {tutorial.title}
                          </h3>
                          <p className="text-sm text-gray-500">{tutorial.duration}</p>
                        </div>
                      </div>
                    </Link>
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}