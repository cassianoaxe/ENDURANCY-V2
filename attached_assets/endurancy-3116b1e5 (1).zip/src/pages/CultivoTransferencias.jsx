import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  ArrowLeftRight,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Truck,
  Box,
  FileText,
  AlertTriangle,
  Info,
  ExternalLink,
  Eye,
  Edit,
  Trash2,
  MoreHorizontal,
  ChevronRight,
  Download,
  Printer,
  Plus,
  Calendar,
  ArrowRight,
  ClipboardList,
  FileCheck,
  Map,
  Building,
  User
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Transfer } from "@/api/entities";
import { Inventory } from "@/api/entities";
import { format } from 'date-fns';

// Dados mockados para transferências
const mockTransfers = [
  {
    id: "tr1",
    transfer_id: "TR-2023-0035",
    type: "laboratório",
    status: "concluída",
    origin_location: "Cofre de Armazenamento A",
    destination_entity: "CannaLab Análises",
    destination_address: "Rua das Análises, 123, São Paulo, SP",
    destination_license: "LIC-12345",
    requested_date: "2023-07-10T14:30:00Z",
    requested_by: "João Silva",
    approved_date: "2023-07-11T09:15:00Z",
    approved_by: "Maria Souza",
    scheduled_date: "2023-07-15T10:00:00Z",
    completed_date: "2023-07-15T14:20:00Z",
    transport_method: "veículo próprio",
    transport_details: {
      vehicle_type: "Van",
      vehicle_plate: "ABC-1234",
      driver_name: "Carlos Pereira",
      driver_id: "123456789",
      estimated_arrival: "2023-07-15T12:00:00Z"
    },
    items: [
      {
        inventory_id: "INV-FL-0123",
        batch_id: "LOTE-2023-0142",
        strain: "Charlotte's Web",
        type: "flor",
        quantity: 500,
        unit: "g"
      }
    ],
    notes: "Envio para análise de cannabinoides e contaminantes."
  },
  {
    id: "tr2",
    transfer_id: "TR-2023-0036",
    type: "interna",
    status: "em trânsito",
    origin_location: "Sala de Secagem 2",
    destination_location: "Cofre de Armazenamento B",
    requested_date: "2023-07-20T15:45:00Z",
    requested_by: "Paulo Oliveira",
    approved_date: "2023-07-21T10:30:00Z",
    approved_by: "Maria Souza",
    scheduled_date: "2023-07-22T09:00:00Z",
    transport_method: "veículo próprio",
    transport_details: {
      vehicle_type: "Carro",
      vehicle_plate: "DEF-5678",
      driver_name: "Rafael Santos",
      driver_id: "987654321",
      estimated_arrival: "2023-07-22T10:00:00Z"
    },
    items: [
      {
        inventory_id: "INV-FL-0124",
        batch_id: "LOTE-2023-0143",
        strain: "CBD Skunk",
        type: "flor",
        quantity: 1000,
        unit: "g"
      },
      {
        inventory_id: "INV-FL-0125",
        batch_id: "LOTE-2023-0143",
        strain: "CBD Skunk",
        type: "flor",
        quantity: 800,
        unit: "g"
      }
    ],
    notes: "Transferência interna após finalização do processo de secagem."
  },
  {
    id: "tr3",
    transfer_id: "TR-2023-0037",
    type: "externa",
    status: "aprovada",
    origin_location: "Cofre de Armazenamento A",
    destination_entity: "PharmaCannabis Ltda.",
    destination_address: "Av. Paulista, 1000, São Paulo, SP",
    destination_license: "LIC-67890",
    requested_date: "2023-07-25T11:20:00Z",
    requested_by: "João Silva",
    approved_date: "2023-07-26T09:45:00Z",
    approved_by: "Maria Souza",
    scheduled_date: "2023-08-01T08:00:00Z",
    transport_method: "transportadora",
    transport_details: {
      company: "TransMed Logística",
      tracking_number: "TM123456789",
      estimated_arrival: "2023-08-01T14:00:00Z"
    },
    items: [
      {
        inventory_id: "INV-OL-0085",
        batch_id: "LOTE-2023-0140",
        strain: "Cannatonic",
        type: "óleo",
        quantity: 500,
        unit: "ml"
      }
    ],
    notes: "Envio para processamento adicional e formulação de produtos finais."
  },
  {
    id: "tr4",
    transfer_id: "TR-2023-0038",
    type: "descarte",
    status: "solicitada",
    origin_location: "Sala de Floração 1",
    destination_entity: "EcoDescarte Resíduos Controlados",
    destination_address: "Rodovia dos Bandeirantes, km 50, Jundiaí, SP",
    destination_license: "LIC-AMBIENTAL-345",
    requested_date: "2023-07-28T16:15:00Z",
    requested_by: "Carlos Mendes",
    items: [
      {
        batch_id: "LOTE-2023-0145",
        strain: "Harlequin",
        type: "planta",
        quantity: 5,
        unit: "unidades",
        notes: "Plantas com infestação severa de ácaros."
      }
    ],
    notes: "Descarte de plantas contaminadas seguindo protocolo ambiental."
  },
  {
    id: "tr5",
    transfer_id: "TR-2023-0039",
    type: "laboratório",
    status: "rejeitada",
    origin_location: "Cofre de Armazenamento B",
    destination_entity: "BioTest Cannabis",
    destination_address: "Av. das Américas, 500, Rio de Janeiro, RJ",
    destination_license: "LIC-RJ-789",
    requested_date: "2023-07-15T10:25:00Z",
    requested_by: "Paulo Oliveira",
    approved_date: null,
    rejection_reason: "Documentação incompleta para transporte interestadual.",
    items: [
      {
        inventory_id: "INV-EX-0042",
        batch_id: "LOTE-2023-0141",
        strain: "ACDC",
        type: "extrato",
        quantity: 200,
        unit: "ml"
      }
    ],
    notes: "Necessário reenviar com documentação completa da ANVISA."
  }
];

// Componente para filtros
const TransferFilters = ({ onFilterChange, activeFilters, setActiveFilters }) => {
  const handleFilterChange = (filterType, value) => {
    const newFilters = { ...activeFilters, [filterType]: value };
    setActiveFilters(newFilters);
    if (onFilterChange) onFilterChange(newFilters);
  };
  
  return (
    <div className="flex flex-col md:flex-row gap-3 mb-6">
      <div className="relative flex-grow">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Buscar transferências por ID, destino ou tipo..."
          className="pl-10"
          value={activeFilters.searchTerm}
          onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
        />
      </div>
      
      <div className="flex flex-col sm:flex-row gap-3">
        <Select 
          value={activeFilters.status} 
          onValueChange={(value) => handleFilterChange('status', value)}
        >
          <SelectTrigger className="w-full sm:w-40">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <SelectValue placeholder="Status" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos Status</SelectItem>
            <SelectItem value="solicitada">Solicitadas</SelectItem>
            <SelectItem value="aprovada">Aprovadas</SelectItem>
            <SelectItem value="em trânsito">Em Trânsito</SelectItem>
            <SelectItem value="concluída">Concluídas</SelectItem>
            <SelectItem value="rejeitada">Rejeitadas</SelectItem>
            <SelectItem value="cancelada">Canceladas</SelectItem>
          </SelectContent>
        </Select>
        
        <Select 
          value={activeFilters.type} 
          onValueChange={(value) => handleFilterChange('type', value)}
        >
          <SelectTrigger className="w-full sm:w-40">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4" />
              <SelectValue placeholder="Tipo" />
            </div>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos Tipos</SelectItem>
            <SelectItem value="interna">Interna</SelectItem>
            <SelectItem value="externa">Externa</SelectItem>
            <SelectItem value="laboratório">Laboratório</SelectItem>
            <SelectItem value="descarte">Descarte</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

// Componente para a tabela de transferências
const TransfersTable = ({ transfers, onViewTransfer, onApproveTransfer, onRejectTransfer, onDeleteTransfer }) => {
  const getStatusBadge = (status) => {
    const statusStyles = {
      'solicitada': 'bg-blue-100 text-blue-800',
      'aprovada': 'bg-green-100 text-green-800',
      'em trânsito': 'bg-amber-100 text-amber-800',
      'concluída': 'bg-purple-100 text-purple-800',
      'rejeitada': 'bg-red-100 text-red-800',
      'cancelada': 'bg-gray-100 text-gray-800'
    };
    
    const statusIcons = {
      'solicitada': <Clock className="w-3 h-3 mr-1" />,
      'aprovada': <CheckCircle2 className="w-3 h-3 mr-1" />,
      'em trânsito': <Truck className="w-3 h-3 mr-1" />,
      'concluída': <CheckCircle2 className="w-3 h-3 mr-1" />,
      'rejeitada': <XCircle className="w-3 h-3 mr-1" />,
      'cancelada': <XCircle className="w-3 h-3 mr-1" />
    };
    
    return (
      <Badge className={statusStyles[status] || 'bg-gray-100 text-gray-800'}>
        <div className="flex items-center">
          {statusIcons[status]}
          <span className="capitalize">{status}</span>
        </div>
      </Badge>
    );
  };
  
  const getTypeIcon = (type) => {
    switch (type) {
      case 'interna': return <ArrowLeftRight className="w-4 h-4 text-blue-500" />;
      case 'externa': return <ExternalLink className="w-4 h-4 text-purple-500" />;
      case 'laboratório': return <FileCheck className="w-4 h-4 text-green-500" />;
      case 'descarte': return <Trash2 className="w-4 h-4 text-red-500" />;
      default: return <Box className="w-4 h-4 text-gray-500" />;
    }
  };
  
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID / Tipo</TableHead>
            <TableHead>Origem</TableHead>
            <TableHead>Destino</TableHead>
            <TableHead>Datas</TableHead>
            <TableHead>Itens</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transfers.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="h-24 text-center">
                <div className="flex flex-col items-center justify-center text-gray-500">
                  <ArrowLeftRight className="h-10 w-10 mb-2 text-gray-400" />
                  <p>Nenhuma transferência encontrada</p>
                  <p className="text-sm">Crie uma nova transferência ou ajuste os filtros</p>
                </div>
              </TableCell>
            </TableRow>
          ) : (
            transfers.map((transfer) => (
              <TableRow key={transfer.id}>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {getTypeIcon(transfer.type)}
                    <div>
                      <div className="font-medium">{transfer.transfer_id}</div>
                      <div className="text-xs text-gray-500 capitalize">{transfer.type}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="text-sm">
                    <div className="font-medium">{transfer.origin_location}</div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="text-sm">
                    {transfer.destination_location ? (
                      <div className="font-medium">{transfer.destination_location}</div>
                    ) : (
                      <>
                        <div className="font-medium">{transfer.destination_entity}</div>
                        <div className="text-xs text-gray-500 truncate" title={transfer.destination_address}>
                          {transfer.destination_address?.substring(0, 25)}
                          {transfer.destination_address?.length > 25 ? '...' : ''}
                        </div>
                      </>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="space-y-1 text-xs">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-gray-400" />
                      <span>Solicitação: {new Date(transfer.requested_date).toLocaleDateString()}</span>
                    </div>
                    {transfer.scheduled_date && (
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-green-400" />
                        <span>Programada: {new Date(transfer.scheduled_date).toLocaleDateString()}</span>
                      </div>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="text-sm">
                    {transfer.items.length} {transfer.items.length === 1 ? 'item' : 'itens'}
                  </div>
                </TableCell>
                <TableCell>
                  {getStatusBadge(transfer.status)}
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Abrir menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Ações</DropdownMenuLabel>
                      <DropdownMenuItem onClick={() => onViewTransfer(transfer)}>
                        <Eye className="mr-2 h-4 w-4" />
                        <span>Ver Detalhes</span>
                      </DropdownMenuItem>
                      {transfer.status === 'solicitada' && (
                        <>
                          <DropdownMenuItem onClick={() => onApproveTransfer(transfer)}>
                            <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                            <span>Aprovar</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onRejectTransfer(transfer)}>
                            <XCircle className="mr-2 h-4 w-4 text-red-500" />
                            <span>Rejeitar</span>
                          </DropdownMenuItem>
                        </>
                      )}
                      {transfer.status === 'aprovada' && (
                        <DropdownMenuItem>
                          <Truck className="mr-2 h-4 w-4" />
                          <span>Iniciar Transporte</span>
                        </DropdownMenuItem>
                      )}
                      {transfer.status === 'em trânsito' && (
                        <DropdownMenuItem>
                          <CheckCircle2 className="mr-2 h-4 w-4" />
                          <span>Concluir Transferência</span>
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <FileText className="mr-2 h-4 w-4" />
                        <span>Gerar Documentos</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Printer className="mr-2 h-4 w-4" />
                        <span>Imprimir</span>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      {['solicitada', 'aprovada'].includes(transfer.status) && (
                        <DropdownMenuItem onClick={() => onDeleteTransfer(transfer)} className="text-red-600">
                          <Trash2 className="mr-2 h-4 w-4" />
                          <span>Cancelar Transferência</span>
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};

// Componente para detalhes da transferência
const TransferDetailDialog = ({ transfer, open, onOpenChange }) => {
  if (!transfer) return null;
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ClipboardList className="w-5 h-5" /> 
            Detalhes da Transferência {transfer.transfer_id}
          </DialogTitle>
          <DialogDescription>
            Informações detalhadas sobre a transferência
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
          <div>
            <h3 className="text-lg font-medium mb-3">Informações Gerais</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                <div className="flex items-center gap-2">
                  <span className="font-medium">Status</span>
                </div>
                <Badge className={
                  transfer.status === 'solicitada' ? 'bg-blue-100 text-blue-800' :
                  transfer.status === 'aprovada' ? 'bg-green-100 text-green-800' :
                  transfer.status === 'em trânsito' ? 'bg-amber-100 text-amber-800' :
                  transfer.status === 'concluída' ? 'bg-purple-100 text-purple-800' :
                  transfer.status === 'rejeitada' ? 'bg-red-100 text-red-800' : 
                  'bg-gray-100 text-gray-800'
                }>
                  <span className="capitalize">{transfer.status}</span>
                </Badge>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                <div className="flex items-center gap-2">
                  <span className="font-medium">Tipo</span>
                </div>
                <Badge variant="outline" className="capitalize">
                  {transfer.type}
                </Badge>
              </div>
              
              <div className="p-3 bg-gray-50 rounded-md">
                <div className="font-medium mb-2">Origem</div>
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-gray-500" />
                  <span>{transfer.origin_location}</span>
                </div>
              </div>
              
              <div className="p-3 bg-gray-50 rounded-md">
                <div className="font-medium mb-2">Destino</div>
                {transfer.destination_location ? (
                  <div className="flex items-center gap-2">
                    <Building className="w-4 h-4 text-gray-500" />
                    <span>{transfer.destination_location}</span>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-2 mb-1">
                      <Building className="w-4 h-4 text-gray-500" />
                      <span>{transfer.destination_entity}</span>
                    </div>
                    <div className="flex items-center gap-2 mb-1">
                      <Map className="w-4 h-4 text-gray-500" />
                      <span>{transfer.destination_address}</span>
                    </div>
                    {transfer.destination_license && (
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-gray-500" />
                        <span>Licença: {transfer.destination_license}</span>
                      </div>
                    )}
                  </>
                )}
              </div>
              
              {transfer.notes && (
                <div className="p-3 bg-gray-50 rounded-md">
                  <div className="font-medium mb-2">Observações</div>
                  <p className="text-sm">{transfer.notes}</p>
                </div>
              )}
              
              {transfer.rejection_reason && (
                <div className="p-3 bg-red-50 border border-red-100 rounded-md">
                  <div className="font-medium mb-2 text-red-800">Motivo da Rejeição</div>
                  <p className="text-sm text-red-700">{transfer.rejection_reason}</p>
                </div>
              )}
            </div>
            
            <h3 className="text-lg font-medium mt-6 mb-3">Datas</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <span>Solicitação</span>
                </div>
                <div className="text-sm">
                  <div>{new Date(transfer.requested_date).toLocaleDateString()}</div>
                  <div className="text-gray-500">{new Date(transfer.requested_date).toLocaleTimeString()}</div>
                </div>
              </div>
              
              {transfer.approved_date && (
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-green-500" />
                    <span>Aprovação</span>
                  </div>
                  <div className="text-sm">
                    <div>{new Date(transfer.approved_date).toLocaleDateString()}</div>
                    <div className="text-gray-500">{new Date(transfer.approved_date).toLocaleTimeString()}</div>
                  </div>
                </div>
              )}
              
              {transfer.scheduled_date && (
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-blue-500" />
                    <span>Programada</span>
                  </div>
                  <div className="text-sm">
                    <div>{new Date(transfer.scheduled_date).toLocaleDateString()}</div>
                    <div className="text-gray-500">{new Date(transfer.scheduled_date).toLocaleTimeString()}</div>
                  </div>
                </div>
              )}
              
              {transfer.completed_date && (
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-purple-500" />
                    <span>Conclusão</span>
                  </div>
                  <div className="text-sm">
                    <div>{new Date(transfer.completed_date).toLocaleDateString()}</div>
                    <div className="text-gray-500">{new Date(transfer.completed_date).toLocaleTimeString()}</div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-lg font-medium">Itens da Transferência</h3>
              <Badge className="bg-blue-100 text-blue-800">{transfer.items.length} {transfer.items.length === 1 ? 'item' : 'itens'}</Badge>
            </div>
            
            <div className="space-y-4">
              {transfer.items.map((item, index) => (
                <div key={index} className="p-3 bg-gray-50 rounded-md">
                  <div className="flex justify-between items-start mb-2">
                    <div className="font-medium">{item.strain}</div>
                    <Badge variant="outline" className="capitalize">{item.type}</Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <div className="text-gray-500">Lote</div>
                      <div>{item.batch_id}</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Inventário</div>
                      <div>{item.inventory_id || "N/A"}</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Quantidade</div>
                      <div className="font-medium">{item.quantity} {item.unit}</div>
                    </div>
                    {item.notes && (
                      <div className="col-span-2">
                        <div className="text-gray-500">Observações</div>
                        <div>{item.notes}</div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
            
            {transfer.transport_method && (
              <>
                <h3 className="text-lg font-medium mt-6 mb-3">Informações de Transporte</h3>
                <div className="p-4 bg-gray-50 rounded-md">
                  <div className="mb-3">
                    <div className="text-sm text-gray-500">Método de Transporte</div>
                    <div className="font-medium capitalize">{transfer.transport_method}</div>
                  </div>
                  
                  {transfer.transport_details && (
                    <div className="space-y-2">
                      {transfer.transport_details.vehicle_type && (
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <div className="text-gray-500">Veículo</div>
                            <div>{transfer.transport_details.vehicle_type}</div>
                          </div>
                          <div>
                            <div className="text-gray-500">Placa</div>
                            <div>{transfer.transport_details.vehicle_plate}</div>
                          </div>
                        </div>
                      )}
                      
                      {transfer.transport_details.driver_name && (
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <div className="text-gray-500">Motorista</div>
                            <div>{transfer.transport_details.driver_name}</div>
                          </div>
                          <div>
                            <div className="text-gray-500">Documento</div>
                            <div>{transfer.transport_details.driver_id}</div>
                          </div>
                        </div>
                      )}
                      
                      {transfer.transport_details.company && (
                        <div className="text-sm">
                          <div className="text-gray-500">Transportadora</div>
                          <div>{transfer.transport_details.company}</div>
                        </div>
                      )}
                      
                      {transfer.transport_details.tracking_number && (
                        <div className="text-sm">
                          <div className="text-gray-500">Número de Rastreamento</div>
                          <div>{transfer.transport_details.tracking_number}</div>
                        </div>
                      )}
                      
                      {transfer.transport_details.estimated_arrival && (
                        <div className="text-sm">
                          <div className="text-gray-500">Chegada Estimada</div>
                          <div>
                            {new Date(transfer.transport_details.estimated_arrival).toLocaleDateString()}{' '}
                            {new Date(transfer.transport_details.estimated_arrival).toLocaleTimeString()}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </>
            )}
            
            <h3 className="text-lg font-medium mt-6 mb-3">Responsáveis</h3>
            <div className="space-y-3">
              <div className="flex items-center p-3 bg-gray-50 rounded-md">
                <div className="flex items-center gap-2 flex-grow">
                  <User className="w-4 h-4 text-gray-500" />
                  <div>
                    <div className="text-sm text-gray-500">Solicitado por</div>
                    <div>{transfer.requested_by}</div>
                  </div>
                </div>
              </div>
              
              {transfer.approved_by && (
                <div className="flex items-center p-3 bg-gray-50 rounded-md">
                  <div className="flex items-center gap-2 flex-grow">
                    <User className="w-4 h-4 text-gray-500" />
                    <div>
                      <div className="text-sm text-gray-500">Aprovado por</div>
                      <div>{transfer.approved_by}</div>
                    </div>
                  </div>
                </div>
              )}
              
              {transfer.received_by && (
                <div className="flex items-center p-3 bg-gray-50 rounded-md">
                  <div className="flex items-center gap-2 flex-grow">
                    <User className="w-4 h-4 text-gray-500" />
                    <div>
                      <div className="text-sm text-gray-500">Recebido por</div>
                      <div>{transfer.received_by}</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="mt-6 space-y-4">
              <Button variant="default" className="w-full">
                <FileText className="w-4 h-4 mr-2" />
                Gerar Documentos
              </Button>
              
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Baixar
                </Button>
                <Button variant="outline">
                  <Printer className="w-4 h-4 mr-2" />
                  Imprimir
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

// Componente de diálogo de aprovação
const ApproveTransferDialog = ({ transfer, open, onOpenChange, onConfirm }) => {
  const [scheduledDate, setScheduledDate] = useState('');
  const [transportMethod, setTransportMethod] = useState('');
  
  if (!transfer) return null;
  
  const handleFormSubmit = (e) => {
    e.preventDefault();
    onConfirm(transfer, {
      scheduledDate,
      transportMethod
    });
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="text-green-600 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" /> 
            Aprovar Transferência
          </DialogTitle>
          <DialogDescription>
            Preencha as informações para aprovar a transferência {transfer.transfer_id}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleFormSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="scheduledDate">Data Programada</Label>
              <Input
                id="scheduledDate"
                type="datetime-local"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                required
              />
              <p className="text-xs text-gray-500">Data e hora para realização da transferência</p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="transportMethod">Método de Transporte</Label>
              <Select 
                value={transportMethod} 
                onValueChange={setTransportMethod}
                required
              >
                <SelectTrigger id="transportMethod">
                  <SelectValue placeholder="Selecione o método de transporte" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="veículo próprio">Veículo Próprio</SelectItem>
                  <SelectItem value="transportadora">Transportadora</SelectItem>
                  <SelectItem value="correios">Correios</SelectItem>
                  <SelectItem value="outro">Outro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="bg-amber-50 border border-amber-200 text-amber-800 p-3 rounded-md flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium">Atenção</p>
                <p>Ao aprovar esta transferência, você é responsável por garantir que toda a documentação necessária esteja em ordem e que o transporte seja realizado conforme as regulamentações aplicáveis.</p>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" type="button" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-green-600 hover:bg-green-700">
              Aprovar Transferência
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

// Componente de diálogo de rejeição
const RejectTransferDialog = ({ transfer, open, onOpenChange, onConfirm }) => {
  const [rejectionReason, setRejectionReason] = useState('');
  
  if (!transfer) return null;
  
  const handleFormSubmit = (e) => {
    e.preventDefault();
    onConfirm(transfer, rejectionReason);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="text-red-600 flex items-center gap-2">
            <XCircle className="w-5 h-5" /> 
            Rejeitar Transferência
          </DialogTitle>
          <DialogDescription>
            Informe o motivo para rejeitar a transferência {transfer.transfer_id}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleFormSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="rejectionReason">Motivo da Rejeição</Label>
              <Textarea
                id="rejectionReason"
                placeholder="Descreva o motivo para rejeitar esta transferência..."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="min-h-32"
                required
              />
            </div>
            
            <div className="bg-amber-50 border border-amber-200 text-amber-800 p-3 rounded-md flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium">Atenção</p>
                <p>A rejeição será comunicada ao solicitante. Um motivo claro ajudará a evitar problemas futuros.</p>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" type="button" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" type="submit">
              Rejeitar Transferência
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

// Componente de diálogo de confirmação de cancelamento/exclusão
const DeleteConfirmDialog = ({ transfer, open, onOpenChange, onConfirm }) => {
  if (!transfer) return null;
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="text-red-600 flex items-center gap-2">
            <Trash2 className="w-5 h-5" /> 
            Cancelar Transferência
          </DialogTitle>
          <DialogDescription>
            Tem certeza que deseja cancelar esta transferência? Esta ação não pode ser desfeita.
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <div className="bg-gray-50 p-4 rounded-md mb-4">
            <h3 className="font-medium mb-2">{transfer.transfer_id}</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <p className="text-gray-500">Tipo:</p>
                <p className="capitalize">{transfer.type}</p>
              </div>
              <div>
                <p className="text-gray-500">Status:</p>
                <p className="capitalize">{transfer.status}</p>
              </div>
              <div>
                <p className="text-gray-500">Destino:</p>
                <p>{transfer.destination_location || transfer.destination_entity}</p>
              </div>
              <div>
                <p className="text-gray-500">Itens:</p>
                <p>{transfer.items.length} {transfer.items.length === 1 ? 'item' : 'itens'}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-amber-50 border border-amber-200 text-amber-800 p-3 rounded-md flex items-start gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium">Atenção!</p>
              <p>Isso cancelará permanentemente a transferência e notificará todos os envolvidos.</p>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Voltar
          </Button>
          <Button variant="destructive" onClick={() => onConfirm(transfer)}>
            Sim, Cancelar Transferência
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// Componente principal da página
export default function CultivoTransferencias() {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [transfers, setTransfers] = useState([]);
  const [filteredTransfers, setFilteredTransfers] = useState([]);
  const [activeFilters, setActiveFilters] = useState({
    searchTerm: '',
    status: 'all',
    type: 'all'
  });
  const [activeTab, setActiveTab] = useState("todas");
  
  // Estados para diálogos
  const [selectedTransfer, setSelectedTransfer] = useState(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  
  useEffect(() => {
    loadTransfers();
  }, []);
  
  useEffect(() => {
    applyFilters();
  }, [transfers, activeFilters, activeTab]);
  
  const loadTransfers = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Em produção, carregaria dados reais
      // const loadedTransfers = await Transfer.list();
      // setTransfers(loadedTransfers);
      
      // Usando dados mockados para demonstração
      setTimeout(() => {
        setTransfers(mockTransfers);
        setIsLoading(false);
      }, 800);
      
    } catch (err) {
      console.error("Erro ao carregar transferências:", err);
      setError("Ocorreu um erro ao carregar as transferências.");
      setIsLoading(false);
    }
  };
  
  const applyFilters = () => {
    let filtered = [...transfers];
    
    // Filtrar por tab
    if (activeTab === "pendentes") {
      filtered = filtered.filter(transfer => transfer.status === "solicitada");
    } else if (activeTab === "ativas") {
      filtered = filtered.filter(transfer => ["aprovada", "em trânsito"].includes(transfer.status));
    } else if (activeTab === "concluidas") {
      filtered = filtered.filter(transfer => transfer.status === "concluída");
    }
    
    // Filtrar por termo de busca
    if (activeFilters.searchTerm) {
      const term = activeFilters.searchTerm.toLowerCase();
      filtered = filtered.filter(transfer => 
        transfer.transfer_id.toLowerCase().includes(term) ||
        (transfer.destination_entity && transfer.destination_entity.toLowerCase().includes(term)) ||
        transfer.type.toLowerCase().includes(term)
      );
    }
    
    // Filtrar por status
    if (activeFilters.status !== 'all') {
      filtered = filtered.filter(transfer => transfer.status === activeFilters.status);
    }
    
    // Filtrar por tipo
    if (activeFilters.type !== 'all') {
      filtered = filtered.filter(transfer => transfer.type === activeFilters.type);
    }
    
    setFilteredTransfers(filtered);
  };
  
  const handleViewTransfer = (transfer) => {
    setSelectedTransfer(transfer);
    setShowDetailDialog(true);
  };
  
  const handleApproveTransfer = (transfer) => {
    setSelectedTransfer(transfer);
    setShowApproveDialog(true);
  };
  
  const handleRejectTransfer = (transfer) => {
    setSelectedTransfer(transfer);
    setShowRejectDialog(true);
  };
  
  const handleDeleteTransfer = (transfer) => {
    setSelectedTransfer(transfer);
    setShowDeleteDialog(true);
  };
  
  const confirmApproveTransfer = async (transfer, formData) => {
    try {
      console.log("Aprovando transferência:", transfer.id, formData);
      
      // Em produção, atualizaria o status na API
      // await Transfer.update(transfer.id, { 
      //   status: 'aprovada',
      //   approved_by: 'Usuário Atual',
      //   approved_date: new Date().toISOString(),
      //   scheduled_date: formData.scheduledDate,
      //   transport_method: formData.transportMethod
      // });
      
      // Simulando atualização
      const updatedTransfers = transfers.map(t => {
        if (t.id === transfer.id) {
          return {
            ...t,
            status: 'aprovada',
            approved_by: 'Usuário Atual',
            approved_date: new Date().toISOString(),
            scheduled_date: formData.scheduledDate,
            transport_method: formData.transportMethod
          };
        }
        return t;
      });
      
      setTransfers(updatedTransfers);
      setShowApproveDialog(false);
      // Mostrar mensagem de sucesso
      alert(`Transferência ${transfer.transfer_id} aprovada com sucesso.`);
      
    } catch (err) {
      console.error("Erro ao aprovar transferência:", err);
      // Mostrar mensagem de erro
      alert(`Erro ao aprovar transferência: ${err.message}`);
    }
  };
  
  const confirmRejectTransfer = async (transfer, reason) => {
    try {
      console.log("Rejeitando transferência:", transfer.id, reason);
      
      // Em produção, atualizaria o status na API
      // await Transfer.update(transfer.id, { 
      //   status: 'rejeitada',
      //   rejection_reason: reason
      // });
      
      // Simulando atualização
      const updatedTransfers = transfers.map(t => {
        if (t.id === transfer.id) {
          return {
            ...t,
            status: 'rejeitada',
            rejection_reason: reason
          };
        }
        return t;
      });
      
      setTransfers(updatedTransfers);
      setShowRejectDialog(false);
      // Mostrar mensagem de sucesso
      alert(`Transferência ${transfer.transfer_id} rejeitada.`);
      
    } catch (err) {
      console.error("Erro ao rejeitar transferência:", err);
      // Mostrar mensagem de erro
      alert(`Erro ao rejeitar transferência: ${err.message}`);
    }
  };
  
  const confirmDeleteTransfer = async (transfer) => {
    try {
      // Em produção, excluiria ou cancelaria na API
      // await Transfer.update(transfer.id, { status: 'cancelada' });
      
      // Simulando exclusão
      const updatedTransfers = transfers.map(t => {
        if (t.id === transfer.id) {
          return {
            ...t,
            status: 'cancelada'
          };
        }
        return t;
      });
      
      setTransfers(updatedTransfers);
      setShowDeleteDialog(false);
      // Mostrar mensagem de sucesso
      alert(`Transferência ${transfer.transfer_id} cancelada.`);
      
    } catch (err) {
      console.error("Erro ao cancelar transferência:", err);
      // Mostrar mensagem de erro
      alert(`Erro ao cancelar transferência: ${err.message}`);
    }
  };
  
  const handleCreateTransfer = () => {
    window.location.href = createPageUrl("CultivoNovaTransferencia");
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Transferências</h1>
          <p className="text-gray-500 mt-1">
            Gerencie transferências de matéria vegetal entre locais, laboratórios e parceiros
          </p>
        </div>
        
        <Button onClick={handleCreateTransfer} className="gap-2">
          <Plus className="w-4 h-4" />
          Nova Transferência
        </Button>
      </div>
      
      <Tabs defaultValue="todas" onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="todas">Todas</TabsTrigger>
          <TabsTrigger value="pendentes">Pendentes</TabsTrigger>
          <TabsTrigger value="ativas">Em Andamento</TabsTrigger>
          <TabsTrigger value="concluidas">Concluídas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="todas" className="space-y-6">
          <TransferFilters 
            onFilterChange={applyFilters} 
            activeFilters={activeFilters}
            setActiveFilters={setActiveFilters}
          />
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
              <p className="ml-2">Carregando transferências...</p>
            </div>
          ) : error ? (
            <Card>
              <CardContent className="flex items-center justify-center text-red-500 p-8">
                <AlertTriangle className="w-8 h-8 mr-2" />
                <p>{error}</p>
              </CardContent>
            </Card>
          ) : (
            <TransfersTable 
              transfers={filteredTransfers}
              onViewTransfer={handleViewTransfer}
              onApproveTransfer={handleApproveTransfer}
              onRejectTransfer={handleRejectTransfer}
              onDeleteTransfer={handleDeleteTransfer}
            />
          )}
        </TabsContent>
        
        <TabsContent value="pendentes" className="space-y-6">
          <TransferFilters 
            onFilterChange={applyFilters} 
            activeFilters={activeFilters}
            setActiveFilters={setActiveFilters}
          />
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
              <p className="ml-2">Carregando transferências pendentes...</p>
            </div>
          ) : error ? (
            <Card>
              <CardContent className="flex items-center justify-center text-red-500 p-8">
                <AlertTriangle className="w-8 h-8 mr-2" />
                <p>{error}</p>
              </CardContent>
            </Card>
          ) : (
            <TransfersTable 
              transfers={filteredTransfers}
              onViewTransfer={handleViewTransfer}
              onApproveTransfer={handleApproveTransfer}
              onRejectTransfer={handleRejectTransfer}
              onDeleteTransfer={handleDeleteTransfer}
            />
          )}
        </TabsContent>
        
        <TabsContent value="ativas" className="space-y-6">
          <TransferFilters 
            onFilterChange={applyFilters} 
            activeFilters={activeFilters}
            setActiveFilters={setActiveFilters}
          />
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
              <p className="ml-2">Carregando transferências em andamento...</p>
            </div>
          ) : error ? (
            <Card>
              <CardContent className="flex items-center justify-center text-red-500 p-8">
                <AlertTriangle className="w-8 h-8 mr-2" />
                <p>{error}</p>
              </CardContent>
            </Card>
          ) : (
            <TransfersTable 
              transfers={filteredTransfers}
              onViewTransfer={handleViewTransfer}
              onApproveTransfer={handleApproveTransfer}
              onRejectTransfer={handleRejectTransfer}
              onDeleteTransfer={handleDeleteTransfer}
            />
          )}
        </TabsContent>
        
        <TabsContent value="concluidas" className="space-y-6">
          <TransferFilters 
            onFilterChange={applyFilters} 
            activeFilters={activeFilters}
            setActiveFilters={setActiveFilters}
          />
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-700"></div>
              <p className="ml-2">Carregando transferências concluídas...</p>
            </div>
          ) : error ? (
            <Card>
              <CardContent className="flex items-center justify-center text-red-500 p-8">
                <AlertTriangle className="w-8 h-8 mr-2" />
                <p>{error}</p>
              </CardContent>
            </Card>
          ) : (
            <TransfersTable 
              transfers={filteredTransfers}
              onViewTransfer={handleViewTransfer}
              onApproveTransfer={handleApproveTransfer}
              onRejectTransfer={handleRejectTransfer}
              onDeleteTransfer={handleDeleteTransfer}
            />
          )}
        </TabsContent>
      </Tabs>
      
      {/* Diálogos */}
      <TransferDetailDialog 
        transfer={selectedTransfer} 
        open={showDetailDialog} 
        onOpenChange={setShowDetailDialog} 
      />
      
      <ApproveTransferDialog 
        transfer={selectedTransfer}
        open={showApproveDialog}
        onOpenChange={setShowApproveDialog}
        onConfirm={confirmApproveTransfer}
      />
      
      <RejectTransferDialog 
        transfer={selectedTransfer}
        open={showRejectDialog}
        onOpenChange={setShowRejectDialog}
        onConfirm={confirmRejectTransfer}
      />
      
      <DeleteConfirmDialog 
        transfer={selectedTransfer}
        open={showDeleteDialog}
        onOpenChange={setShowDeleteDialog}
        onConfirm={confirmDeleteTransfer}
      />
    </div>
  );
}