
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Truck, 
  Search, 
  Plus, 
  Filter, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  FileText, 
  Download, 
  Building2, 
  ArrowUpDown, 
  MoreHorizontal,
  MapPin,
  Phone,
  Mail,
  User,
  Star,
  ShoppingCart,
  Package,
  Calendar
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import ValidacaoFornecedor from "@/components/fornecedores/ValidacaoFornecedor";

// Dados simulados para fornecedores
const mockSuppliers = [
  {
    id: "f001",
    nome: "CannabTech Distribuidora",
    tipo: "distribuidor",
    cnpj: "12.345.678/0001-90",
    endereco: "Av. Paulista, 1000, São Paulo, SP",
    contato_principal: "João Silva",
    email: "contato@cannabtech.com.br",
    telefone: "(11) 3456-7890",
    certificacoes: ["ISO 9001", "GMP"],
    avaliacao: 4.8,
    status: "ativo",
    data_cadastro: "2022-05-10",
    ultima_compra: "2023-06-20",
    categorias: ["Extrato CBD", "Terpenos", "Insumos Farmacêuticos"],
    total_compras: 12,
    valor_total_compras: 158500.00
  },
  {
    id: "f002",
    nome: "Insumos Farmacêuticos SA",
    tipo: "fabricante",
    cnpj: "98.765.432/0001-10",
    endereco: "Rua das Indústrias, 500, Campinas, SP",
    contato_principal: "Maria Oliveira",
    email: "comercial@insumosfarmaceuticos.com.br",
    telefone: "(19) 2345-6789",
    certificacoes: ["ISO 9001", "ISO 14001", "GMP"],
    avaliacao: 4.9,
    status: "ativo",
    data_cadastro: "2021-08-15",
    ultima_compra: "2023-06-15",
    categorias: ["Óleo Base", "Excipientes", "Material de Embalagem"],
    total_compras: 25,
    valor_total_compras: 287300.00
  },
  {
    id: "f003",
    nome: "Insumos Naturais Ltda",
    tipo: "distribuidor",
    cnpj: "87.654.321/0001-20",
    endereco: "Av. Brasil, 2500, Rio de Janeiro, RJ",
    contato_principal: "Carlos Santos",
    email: "vendas@insumosnaturais.com.br",
    telefone: "(21) 3456-7890",
    certificacoes: ["ISO 9001"],
    avaliacao: 4.2,
    status: "ativo",
    data_cadastro: "2022-01-20",
    ultima_compra: "2023-05-30",
    categorias: ["Óleo de Cânhamo", "Extratos Vegetais"],
    total_compras: 8,
    valor_total_compras: 92400.00
  },
  {
    id: "f004",
    nome: "GlassPack Embalagens",
    tipo: "fabricante",
    cnpj: "76.543.210/0001-30",
    endereco: "Rodovia dos Bandeirantes, km 25, Jundiaí, SP",
    contato_principal: "Ana Costa",
    email: "contato@glasspack.com.br",
    telefone: "(11) 4567-8901",
    certificacoes: ["ISO 9001", "ISO 14001"],
    avaliacao: 4.5,
    status: "ativo",
    data_cadastro: "2021-11-05",
    ultima_compra: "2023-06-25",
    categorias: ["Embalagens de Vidro", "Conta-gotas", "Tampas"],
    total_compras: 15,
    valor_total_compras: 120800.00
  },
  {
    id: "f005",
    nome: "LabelPrint Rótulos",
    tipo: "fabricante",
    cnpj: "65.432.109/0001-40",
    endereco: "Rua dos Gráficos, 150, São Paulo, SP",
    contato_principal: "Roberto Almeida",
    email: "comercial@labelprint.com.br",
    telefone: "(11) 5678-9012",
    certificacoes: ["ISO 9001"],
    avaliacao: 4.3,
    status: "ativo",
    data_cadastro: "2022-03-10",
    ultima_compra: "2023-06-10",
    categorias: ["Rótulos", "Etiquetas", "Material Gráfico"],
    total_compras: 10,
    valor_total_compras: 45600.00
  },
  {
    id: "f006",
    nome: "TerpTech Extratos",
    tipo: "fabricante",
    cnpj: "54.321.098/0001-50",
    endereco: "Av. das Indústrias, 800, Ribeirão Preto, SP",
    contato_principal: "Juliana Ferreira",
    email: "contato@terptech.com.br",
    telefone: "(16) 6789-0123",
    certificacoes: ["GMP", "ISO 9001"],
    avaliacao: 4.7,
    status: "inativo",
    data_cadastro: "2021-09-15",
    ultima_compra: "2023-01-20",
    categorias: ["Terpenos", "Extratos Naturais"],
    total_compras: 5,
    valor_total_compras: 68900.00
  },
  {
    id: "f007",
    nome: "LogiPharma Transportes",
    tipo: "transporte",
    cnpj: "43.210.987/0001-60",
    endereco: "Av. dos Transportadores, 300, Guarulhos, SP",
    contato_principal: "Fernando Gomes",
    email: "operacional@logipharma.com.br",
    telefone: "(11) 7890-1234",
    certificacoes: ["ISO 9001", "Anvisa"],
    avaliacao: 4.6,
    status: "ativo",
    data_cadastro: "2022-02-28",
    ultima_compra: "2023-06-28",
    categorias: ["Transporte Farmacêutico", "Transporte Refrigerado"],
    total_compras: 22,
    valor_total_compras: 89700.00
  }
];

// Dados simulados para pedidos de compra
const mockPurchaseOrders = [
  {
    id: "pc001",
    numero: "PC-2023-001",
    fornecedor_id: "f001",
    fornecedor_nome: "CannabTech Distribuidora",
    data_emissao: "2023-06-20",
    data_entrega_prevista: "2023-07-10",
    status: "entregue",
    valor_total: 25600.00,
    itens: [
      { material_id: "mp001", nome: "Extrato CBD Isolado", quantidade: 5, unidade: "kg", valor_unitario: 5000.00 },
      { material_id: "mp006", nome: "Terpenos Naturais", quantidade: 1.2, unidade: "L", valor_unitario: 500.00 }
    ]
  },
  {
    id: "pc002",
    numero: "PC-2023-002",
    fornecedor_id: "f002",
    fornecedor_nome: "Insumos Farmacêuticos SA",
    data_emissao: "2023-06-15",
    data_entrega_prevista: "2023-07-05",
    status: "entregue",
    valor_total: 32000.00,
    itens: [
      { material_id: "mp002", nome: "Óleo MCT", quantidade: 200, unidade: "L", valor_unitario: 160.00 }
    ]
  },
  {
    id: "pc003",
    numero: "PC-2023-003",
    fornecedor_id: "f003",
    fornecedor_nome: "Insumos Naturais Ltda",
    data_emissao: "2023-05-30",
    data_entrega_prevista: "2023-06-20",
    status: "entregue",
    valor_total: 18600.00,
    itens: [
      { material_id: "mp003", nome: "Óleo Semente de Cânhamo", quantidade: 20, unidade: "L", valor_unitario: 930.00 }
    ]
  },
  {
    id: "pc004",
    numero: "PC-2023-004",
    fornecedor_id: "f004",
    fornecedor_nome: "GlassPack Embalagens",
    data_emissao: "2023-06-25",
    data_entrega_prevista: "2023-07-15",
    status: "em_transito",
    valor_total: 21350.00,
    itens: [
      { material_id: "mp004", nome: "Embalagens Vidro Âmbar 30ml", quantidade: 2000, unidade: "un", valor_unitario: 8.50 },
      { material_id: "mp005", nome: "Conta-gotas", quantidade: 2000, unidade: "un", valor_unitario: 2.00 }
    ]
  },
  {
    id: "pc005",
    numero: "PC-2023-005",
    fornecedor_id: "f001",
    fornecedor_nome: "CannabTech Distribuidora",
    data_emissao: "2023-07-01",
    data_entrega_prevista: "2023-07-21",
    status: "aprovado",
    valor_total: 32500.00,
    itens: [
      { material_id: "mp001", nome: "Extrato CBD Isolado", quantidade: 6.5, unidade: "kg", valor_unitario: 5000.00 }
    ]
  }
];

// Dados simulados para avaliações de fornecedores
const mockEvaluations = [
  {
    id: "ev001",
    fornecedor_id: "f001",
    data_avaliacao: "2023-06-25",
    avaliador: "Amanda Ribeiro",
    criterios: [
      { nome: "Qualidade", nota: 5, peso: 0.3 },
      { nome: "Prazo de Entrega", nota: 4, peso: 0.25 },
      { nome: "Preço", nota: 5, peso: 0.2 },
      { nome: "Atendimento", nota: 5, peso: 0.15 },
      { nome: "Documentação", nota: 5, peso: 0.1 }
    ],
    nota_final: 4.8,
    observacoes: "Excelente fornecedor de extratos CBD. Produtos de alta qualidade e entregas conforme programado."
  },
  {
    id: "ev002",
    fornecedor_id: "f002",
    data_avaliacao: "2023-06-20",
    avaliador: "Ricardo Santos",
    criterios: [
      { nome: "Qualidade", nota: 5, peso: 0.3 },
      { nome: "Prazo de Entrega", nota: 5, peso: 0.25 },
      { nome: "Preço", nota: 4, peso: 0.2 },
      { nome: "Atendimento", nota: 5, peso: 0.15 },
      { nome: "Documentação", nota: 5, peso: 0.1 }
    ],
    nota_final: 4.9,
    observacoes: "Fornecedor totalmente conforme com as BPF. Documentação perfeita e atendimento excepcional."
  },
  {
    id: "ev003",
    fornecedor_id: "f003",
    data_avaliacao: "2023-06-05",
    avaliador: "Amanda Ribeiro",
    criterios: [
      { nome: "Qualidade", nota: 4, peso: 0.3 },
      { nome: "Prazo de Entrega", nota: 4, peso: 0.25 },
      { nome: "Preço", nota: 5, peso: 0.2 },
      { nome: "Atendimento", nota: 4, peso: 0.15 },
      { nome: "Documentação", nota: 4, peso: 0.1 }
    ],
    nota_final: 4.2,
    observacoes: "Bom fornecedor, mas com algumas inconsistências na documentação. Qualidade satisfatória, mas pode melhorar."
  }
];

export default function ProducaoFornecedores() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [tipoFilter, setTipoFilter] = useState("todos");
  const [activeTab, setActiveTab] = useState("fornecedores");
  const [showEvaluationDialog, setShowEvaluationDialog] = useState(false);
  const [showValidacaoDialog, setShowValidacaoDialog] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // Filtering
  const filteredSuppliers = mockSuppliers.filter(supplier => {
    const matchesSearch = supplier.nome.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          supplier.contato_principal.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          supplier.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          supplier.cnpj.includes(searchTerm);
                          
    const matchesStatus = statusFilter === "todos" || supplier.status === statusFilter;
    const matchesTipo = tipoFilter === "todos" || supplier.tipo === tipoFilter;
    
    return matchesSearch && matchesStatus && matchesTipo;
  });

  const handleViewSupplier = (supplier) => {
    setSelectedSupplier(supplier);
  };
  
  const handleStartValidation = (supplier) => {
    setSelectedSupplier(supplier);
    setShowValidacaoDialog(true);
  };
  
  const handleAddSupplier = () => {
    window.location.href = createPageUrl("ProducaoNovoFornecedor");
  };
  
  const getStatusBadge = (status) => {
    switch(status) {
      case "ativo":
        return <Badge className="bg-green-100 text-green-800">Ativo</Badge>;
      case "inativo":
        return <Badge className="bg-red-100 text-red-800">Inativo</Badge>;
      case "pendente":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };
  
  const getPurchaseOrderStatusBadge = (status) => {
    switch(status) {
      case "rascunho":
        return <Badge className="bg-gray-100 text-gray-800">Rascunho</Badge>;
      case "emitido":
        return <Badge className="bg-blue-100 text-blue-800">Emitido</Badge>;
      case "aprovado":
        return <Badge className="bg-purple-100 text-purple-800">Aprovado</Badge>;
      case "em_transito":
        return <Badge className="bg-yellow-100 text-yellow-800">Em Trânsito</Badge>;
      case "entregue":
        return <Badge className="bg-green-100 text-green-800">Entregue</Badge>;
      case "cancelado":
        return <Badge className="bg-red-100 text-red-800">Cancelado</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Truck className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Fornecedores</h1>
            <p className="text-gray-500">Gestão de fornecedores e compras</p>
          </div>
        </div>
        
        <Button onClick={handleAddSupplier}>
          <Plus className="mr-2 h-4 w-4" />
          Novo Fornecedor
        </Button>
      </div>
      
      <div>
        <Tabs defaultValue="fornecedores" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="fornecedores">Fornecedores</TabsTrigger>
            <TabsTrigger value="pedidos">Pedidos de Compra</TabsTrigger>
            <TabsTrigger value="avaliacoes">Avaliações</TabsTrigger>
          </TabsList>
          
          <TabsContent value="fornecedores" className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1 relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Buscar fornecedores..."
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex gap-4">
                <Select
                  value={statusFilter}
                  onValueChange={setStatusFilter}
                >
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os Status</SelectItem>
                    <SelectItem value="ativo">Ativos</SelectItem>
                    <SelectItem value="inativo">Inativos</SelectItem>
                    <SelectItem value="pendente">Pendentes</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select
                  value={tipoFilter}
                  onValueChange={setTipoFilter}
                >
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os Tipos</SelectItem>
                    <SelectItem value="fabricante">Fabricantes</SelectItem>
                    <SelectItem value="distribuidor">Distribuidores</SelectItem>
                    <SelectItem value="transporte">Transportadoras</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fornecedor</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Contato</TableHead>
                      <TableHead>Avaliação</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Última Compra</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredSuppliers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="h-24 text-center">
                          Nenhum fornecedor encontrado com os filtros atuais
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredSuppliers.map(supplier => (
                        <TableRow key={supplier.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarFallback className="bg-blue-100 text-blue-800">
                                  {supplier.nome.substring(0, 2).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">{supplier.nome}</div>
                                <div className="text-sm text-gray-500">{supplier.cnpj}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {supplier.tipo === 'fabricante' ? 'Fabricante' : 
                               supplier.tipo === 'distribuidor' ? 'Distribuidor' : 
                               supplier.tipo === 'transporte' ? 'Transportadora' : supplier.tipo}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <div>{supplier.contato_principal}</div>
                              <div className="text-gray-500">{supplier.email}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
                              <span>{supplier.avaliacao.toFixed(1)}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {getStatusBadge(supplier.status)}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1 text-sm">
                              <Calendar className="h-3.5 w-3.5 text-gray-500" />
                              {supplier.ultima_compra}
                            </div>
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Abrir menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                <DropdownMenuItem onClick={() => handleViewSupplier(supplier)}>
                                  Ver detalhes
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleStartValidation(supplier)}>
                                  Validar fornecedor
                                </DropdownMenuItem>
                                <DropdownMenuItem>Editar fornecedor</DropdownMenuItem>
                                <DropdownMenuItem>Novo pedido</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className={supplier.status === 'ativo' ? 'text-red-600' : 'text-green-600'}>
                                  {supplier.status === 'ativo' ? 'Desativar fornecedor' : 'Ativar fornecedor'}
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="pedidos" className="space-y-4">
            <div className="flex justify-between items-center mb-6">
              <div className="flex gap-4">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Buscar pedidos..."
                    className="pl-9 w-[300px]"
                  />
                </div>
                <Select defaultValue="todos">
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os Status</SelectItem>
                    <SelectItem value="rascunho">Rascunho</SelectItem>
                    <SelectItem value="emitido">Emitido</SelectItem>
                    <SelectItem value="aprovado">Aprovado</SelectItem>
                    <SelectItem value="em_transito">Em Trânsito</SelectItem>
                    <SelectItem value="entregue">Entregue</SelectItem>
                    <SelectItem value="cancelado">Cancelado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Novo Pedido
              </Button>
            </div>
            
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Número</TableHead>
                      <TableHead>Fornecedor</TableHead>
                      <TableHead>Data Emissão</TableHead>
                      <TableHead>Entrega Prevista</TableHead>
                      <TableHead>Valor Total</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockPurchaseOrders.map(order => (
                      <TableRow key={order.id}>
                        <TableCell>
                          <div className="font-medium">{order.numero}</div>
                        </TableCell>
                        <TableCell>{order.fornecedor_nome}</TableCell>
                        <TableCell>{order.data_emissao}</TableCell>
                        <TableCell>{order.data_entrega_prevista}</TableCell>
                        <TableCell>R$ {order.valor_total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</TableCell>
                        <TableCell>
                          {getPurchaseOrderStatusBadge(order.status)}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Abrir menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Ações</DropdownMenuLabel>
                              <DropdownMenuItem>Ver detalhes</DropdownMenuItem>
                              <DropdownMenuItem>Editar pedido</DropdownMenuItem>
                              <DropdownMenuItem>
                                <Download className="h-4 w-4 mr-2" />
                                Exportar PDF
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-red-600">
                                Cancelar pedido
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="avaliacoes" className="space-y-4">
            <div className="flex justify-between items-center mb-6">
              <div className="flex gap-4">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Buscar avaliações..."
                    className="pl-9 w-[300px]"
                  />
                </div>
                <Select defaultValue="todos">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Classificação" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todas as Classificações</SelectItem>
                    <SelectItem value="excelente">Excelente (4.5+)</SelectItem>
                    <SelectItem value="bom">Bom (3.5-4.4)</SelectItem>
                    <SelectItem value="regular">Regular (2.5-3.4)</SelectItem>
                    <SelectItem value="ruim">Ruim (abaixo de 2.5)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova Avaliação
              </Button>
            </div>
            
            <div className="grid grid-cols-1 gap-6">
              {mockEvaluations.map(evaluation => {
                const supplier = mockSuppliers.find(s => s.id === evaluation.fornecedor_id);
                return (
                  <Card key={evaluation.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between">
                        <div>
                          <div className="font-medium text-gray-500 text-sm mb-1">Fornecedor</div>
                          <CardTitle>{supplier?.nome}</CardTitle>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-gray-500 text-sm mb-1">Nota Final</div>
                          <div className="flex items-center justify-end">
                            <div className="flex items-center">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star 
                                  key={star}
                                  className={`h-5 w-5 ${
                                    star <= Math.round(evaluation.nota_final)
                                      ? 'text-yellow-500 fill-yellow-500'
                                      : 'text-gray-300'
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="ml-2 font-bold text-lg">{evaluation.nota_final.toFixed(1)}</span>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <div className="font-medium mb-2">Critérios Avaliados</div>
                          <div className="space-y-3">
                            {evaluation.criterios.map((criterio, index) => (
                              <div key={index} className="flex justify-between items-center">
                                <div className="text-sm">
                                  <span>{criterio.nome}</span>
                                  <span className="text-gray-500 ml-2">(Peso: {criterio.peso * 100}%)</span>
                                </div>
                                <div className="flex items-center">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star 
                                      key={star}
                                      className={`h-4 w-4 ${
                                        star <= criterio.nota
                                          ? 'text-yellow-500 fill-yellow-500'
                                          : 'text-gray-300'
                                      }`}
                                    />
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <div className="font-medium mb-2">Informações da Avaliação</div>
                          <div className="text-sm space-y-2">
                            <div>
                              <span className="text-gray-500">Data da avaliação:</span> {evaluation.data_avaliacao}
                            </div>
                            <div>
                              <span className="text-gray-500">Avaliador:</span> {evaluation.avaliador}
                            </div>
                            <div className="mt-4">
                              <div className="text-gray-500 mb-1">Observações:</div>
                              <p className="text-gray-700">{evaluation.observacoes}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex justify-end mt-6">
                        <Button variant="outline" size="sm" className="mr-2">
                          <FileText className="h-4 w-4 mr-2" />
                          Ver Detalhes
                        </Button>
                        <Button size="sm">
                          <Plus className="h-4 w-4 mr-2" />
                          Nova Avaliação
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Dialog para detalhes do fornecedor */}
      {selectedSupplier && (
        <Dialog open={!!selectedSupplier && !showValidacaoDialog} onOpenChange={() => selectedSupplier && !showValidacaoDialog ? setSelectedSupplier(null) : null}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle className="text-xl">{selectedSupplier.nome}</DialogTitle>
              <DialogDescription>
                <Badge className="mt-1">
                  {selectedSupplier.tipo === 'fabricante' ? 'Fabricante' : 
                   selectedSupplier.tipo === 'distribuidor' ? 'Distribuidor' : 
                   selectedSupplier.tipo === 'transporte' ? 'Transportadora' : selectedSupplier.tipo}
                </Badge>
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="col-span-2 space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Informações Gerais</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">CNPJ</p>
                      <p className="font-medium">{selectedSupplier.cnpj}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Status</p>
                      <p>{getStatusBadge(selectedSupplier.status)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Data de Cadastro</p>
                      <p className="font-medium">{selectedSupplier.data_cadastro}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Última Compra</p>
                      <p className="font-medium">{selectedSupplier.ultima_compra}</p>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-2">Contato</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-gray-500" />
                      <p>{selectedSupplier.contato_principal}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-gray-500" />
                      <p>{selectedSupplier.email}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-gray-500" />
                      <p>{selectedSupplier.telefone}</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <MapPin className="h-4 w-4 text-gray-500 mt-0.5" />
                      <p>{selectedSupplier.endereco}</p>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-2">Categorias de Produtos</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedSupplier.categorias.map((categoria, index) => (
                      <Badge key={index} variant="outline">{categoria}</Badge>
                    ))}
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-medium mb-2">Certificações</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedSupplier.certificacoes.map((cert, index) => (
                      <Badge key={index} className="bg-green-100 text-green-800">{cert}</Badge>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="space-y-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Resumo de Compras</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-500">Total de Pedidos</span>
                        <span className="font-medium">{selectedSupplier.total_compras}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-500">Valor Total</span>
                        <span className="font-medium">R$ {selectedSupplier.valor_total_compras.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-500">Avaliação</span>
                        <div className="flex items-center">
                          <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
                          <span className="font-medium">{selectedSupplier.avaliacao.toFixed(1)}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Ações Rápidas</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button className="w-full justify-start" size="sm">
                      <ShoppingCart className="mr-2 h-4 w-4" />
                      Novo Pedido
                    </Button>
                    <Button className="w-full justify-start" variant="outline" size="sm">
                      <Star className="mr-2 h-4 w-4" />
                      Avaliar Fornecedor
                    </Button>
                    <Button className="w-full justify-start" variant="outline" size="sm">
                      <FileText className="mr-2 h-4 w-4" />
                      Ver Documentos
                    </Button>
                    <Button className="w-full justify-start" variant="outline" size="sm">
                      <Package className="mr-2 h-4 w-4" />
                      Ver Catálogo
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedSupplier(null)}>
                Fechar
              </Button>
              <Button>
                Editar Fornecedor
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Dialog para validação de fornecedor */}
      {selectedSupplier && (
        <Dialog open={showValidacaoDialog} onOpenChange={setShowValidacaoDialog}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <ValidacaoFornecedor 
              fornecedor={selectedSupplier} 
              onSave={(updatedSupplier) => {
                setSelectedSupplier(updatedSupplier);
                setShowValidacaoDialog(false);
                toast({
                  title: "Validação concluída",
                  description: `O fornecedor foi ${updatedSupplier.status === 'ativo' ? 'aprovado' : updatedSupplier.status === 'inativo' ? 'reprovado' : 'mantido em análise'}.`,
                });
              }} 
              onClose={() => setShowValidacaoDialog(false)} 
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
