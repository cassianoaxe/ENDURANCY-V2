
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  LayoutDashboard, Video, Users, ClipboardList, Brain, DollarSign, 
  Settings, LogOut, Menu, X, Bell, Search, Filter, 
  Calendar, Download, Upload, ArrowUp, ArrowDown, FileText, Printer,
  BarChart2, CreditCard, Wallet, PieChart, TrendingUp, ArrowUpRight,
  Check, CalendarRange, ChevronDown, ChevronUp, 
  Eye, ChevronLeft, ChevronRight
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Spinner } from "@/components/ui/spinner";
import DoctorLayout from '../components/DoctorLayout';

export default function DoctorFinancial() {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [selectedYear, setSelectedYear] = useState('2024');
  const [selectedMonth, setSelectedMonth] = useState('3'); // March
  const [transactions, setTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  const [financialSummary, setFinancialSummary] = useState({
    totalEarnings: 0,
    pendingPayments: 0,
    completedConsultations: 0,
    averageTicket: 0,
    monthlyGrowth: 0,
    yearlyGrowth: 0
  });

  useEffect(() => {
    const timer = setTimeout(() => {
      setTransactions([
        {
          id: 'TRX001',
          patientName: 'Maria Oliveira',
          type: 'Consulta',
          date: '2024-03-15',
          amount: 380.00,
          status: 'completed',
          paymentMethod: 'credit_card'
        },
        {
          id: 'TRX002',
          patientName: 'João Santos',
          type: 'Consulta',
          date: '2024-03-14',
          amount: 380.00,
          status: 'pending',
          paymentMethod: 'pix'
        },
        {
          id: 'TRX003',
          patientName: 'Ana Silva',
          type: 'Consulta de Retorno',
          date: '2024-03-13',
          amount: 280.00,
          status: 'completed',
          paymentMethod: 'credit_card'
        },
        {
          id: 'TRX004',
          patientName: 'Carlos Mendes',
          type: 'Consulta',
          date: '2024-03-12',
          amount: 380.00,
          status: 'completed',
          paymentMethod: 'pix'
        },
        {
          id: 'TRX005',
          patientName: 'Paulo Sousa',
          type: 'Consulta',
          date: '2024-03-11',
          amount: 380.00,
          status: 'failed',
          paymentMethod: 'credit_card'
        }
      ]);
      
      setFinancialSummary({
        totalEarnings: 15780.50,
        pendingPayments: 2450.00,
        completedConsultations: 42,
        averageTicket: 375.70,
        monthlyGrowth: 12.5,
        yearlyGrowth: 25.8
      });
      
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800">Concluído</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'failed':
        return <Badge className="bg-red-100 text-red-800">Falha</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentTransactions = transactions.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(transactions.length / itemsPerPage);

  const changePage = (direction) => {
    if (direction === 'prev' && currentPage > 1) {
      setCurrentPage(currentPage - 1);
    } else if (direction === 'next' && currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="flex flex-col items-center">
          <Spinner className="h-10 w-10 text-pink-500" />
          <p className="mt-4 text-gray-500">Carregando dados financeiros...</p>
        </div>
      </div>
    );
  }

  return (
    <DoctorLayout>
      <div className="min-h-screen bg-gray-50">
        <div className="py-6 px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Financeiro</h1>
            <p className="mt-1 text-sm text-gray-500">
              Gerencie seus ganhos, transações e consulte seu histórico financeiro
            </p>
          </div>

          <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center space-x-2">
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Selecionar período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="day">Diário</SelectItem>
                  <SelectItem value="week">Semanal</SelectItem>
                  <SelectItem value="month">Mensal</SelectItem>
                  <SelectItem value="quarter">Trimestral</SelectItem>
                  <SelectItem value="year">Anual</SelectItem>
                </SelectContent>
              </Select>

              {selectedPeriod === 'month' && (
                <>
                  <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue placeholder="Mês" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">Janeiro</SelectItem>
                      <SelectItem value="2">Fevereiro</SelectItem>
                      <SelectItem value="3">Março</SelectItem>
                      <SelectItem value="4">Abril</SelectItem>
                      <SelectItem value="5">Maio</SelectItem>
                      <SelectItem value="6">Junho</SelectItem>
                      <SelectItem value="7">Julho</SelectItem>
                      <SelectItem value="8">Agosto</SelectItem>
                      <SelectItem value="9">Setembro</SelectItem>
                      <SelectItem value="10">Outubro</SelectItem>
                      <SelectItem value="11">Novembro</SelectItem>
                      <SelectItem value="12">Dezembro</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select value={selectedYear} onValueChange={setSelectedYear}>
                    <SelectTrigger className="w-[100px]">
                      <SelectValue placeholder="Ano" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2022">2022</SelectItem>
                      <SelectItem value="2023">2023</SelectItem>
                      <SelectItem value="2024">2024</SelectItem>
                    </SelectContent>
                  </Select>
                </>
              )}
            </div>

            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="flex items-center">
                <Filter className="mr-2 h-4 w-4" />
                Filtrar
              </Button>
              <Button variant="outline" size="sm" className="flex items-center">
                <Download className="mr-2 h-4 w-4" />
                Exportar
              </Button>
              <Button variant="outline" size="sm" className="flex items-center">
                <Printer className="mr-2 h-4 w-4" />
                Imprimir
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-6">
            <Card className="flex flex-col">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Total de Ganhos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-2xl font-bold">{formatCurrency(financialSummary.totalEarnings)}</p>
                    <div className="flex items-center mt-1 text-sm text-green-600">
                      <ArrowUp className="h-4 w-4 mr-1" />
                      <span>{financialSummary.monthlyGrowth}% este mês</span>
                    </div>
                  </div>
                  <div className="p-2 bg-pink-50 rounded-md">
                    <Wallet className="h-6 w-6 text-pink-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="flex flex-col">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Pagamentos Pendentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-2xl font-bold">{formatCurrency(financialSummary.pendingPayments)}</p>
                    <p className="mt-1 text-sm text-gray-500">de {transactions.filter(t => t.status === 'pending').length} consultas</p>
                  </div>
                  <div className="p-2 bg-yellow-50 rounded-md">
                    <Calendar className="h-6 w-6 text-yellow-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="flex flex-col">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Consultas Realizadas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-2xl font-bold">{financialSummary.completedConsultations}</p>
                    <p className="mt-1 text-sm text-gray-500">Ticket médio: {formatCurrency(financialSummary.averageTicket)}</p>
                  </div>
                  <div className="p-2 bg-purple-50 rounded-md">
                    <Video className="h-6 w-6 text-purple-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="flex flex-col">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-500">Projeção Anual</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-2xl font-bold">{formatCurrency(financialSummary.totalEarnings * 12)}</p>
                    <div className="flex items-center mt-1 text-sm text-green-600">
                      <ArrowUpRight className="h-4 w-4 mr-1" />
                      <span>{financialSummary.yearlyGrowth}% vs. ano anterior</span>
                    </div>
                  </div>
                  <div className="p-2 bg-blue-50 rounded-md">
                    <BarChart2 className="h-6 w-6 text-blue-500" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid w-full grid-cols-3 md:w-auto md:inline-flex">
              <TabsTrigger value="overview">Visão Geral</TabsTrigger>
              <TabsTrigger value="transactions">Transações</TabsTrigger>
              <TabsTrigger value="reports">Relatórios</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4 mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Ganhos Recentes</CardTitle>
                  <CardDescription>Histórico de ganhos nos últimos 7 dias</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center text-gray-500">
                    Gráfico de ganhos recentes será exibido aqui
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="transactions" className="space-y-4 mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Transações Recentes</CardTitle>
                  <CardDescription>Histórico completo de transações</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Paciente</TableHead>
                          <TableHead>Tipo</TableHead>
                          <TableHead>Data</TableHead>
                          <TableHead>Valor</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {currentTransactions.map((transaction) => (
                          <TableRow key={transaction.id}>
                            <TableCell className="font-medium">{transaction.id}</TableCell>
                            <TableCell>{transaction.patientName}</TableCell>
                            <TableCell>{transaction.type}</TableCell>
                            <TableCell>{formatDate(transaction.date)}</TableCell>
                            <TableCell>{formatCurrency(transaction.amount)}</TableCell>
                            <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  <div className="flex items-center justify-between mt-4">
                    <div className="text-sm text-gray-500">
                      Mostrando {indexOfFirstItem + 1} a {Math.min(indexOfLastItem, transactions.length)} de {transactions.length} transações
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => changePage('prev')}
                        disabled={currentPage === 1}
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => changePage('next')}
                        disabled={currentPage === totalPages}
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reports" className="space-y-4 mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Relatórios Financeiros</CardTitle>
                  <CardDescription>Acesse e gere relatórios detalhados</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card className="hover:shadow-md cursor-pointer transition-shadow">
                      <CardContent className="p-4 flex items-center">
                        <FileText className="h-8 w-8 text-pink-500 mr-4" />
                        <div>
                          <h3 className="font-medium">Demonstrativo Mensal</h3>
                          <p className="text-sm text-gray-500">Relatório mensal de ganhos e transações</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="hover:shadow-md cursor-pointer transition-shadow">
                      <CardContent className="p-4 flex items-center">
                        <CreditCard className="h-8 w-8 text-pink-500 mr-4" />
                        <div>
                          <h3 className="font-medium">Declaração Anual</h3>
                          <p className="text-sm text-gray-500">Relatório anual para imposto de renda</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="hover:shadow-md cursor-pointer transition-shadow">
                      <CardContent className="p-4 flex items-center">
                        <BarChart2 className="h-8 w-8 text-pink-500 mr-4" />
                        <div>
                          <h3 className="font-medium">Análise de Ganhos</h3>
                          <p className="text-sm text-gray-500">Análise detalhada de ganhos por período</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="hover:shadow-md cursor-pointer transition-shadow">
                      <CardContent className="p-4 flex items-center">
                        <PieChart className="h-8 w-8 text-pink-500 mr-4" />
                        <div>
                          <h3 className="font-medium">Relatório por Paciente</h3>
                          <p className="text-sm text-gray-500">Detalhamento de ganhos por paciente</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </DoctorLayout>
  );
}
