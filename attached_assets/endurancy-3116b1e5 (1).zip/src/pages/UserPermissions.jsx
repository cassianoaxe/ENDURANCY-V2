import React, { useState } from "react";
import {
  Users,
  ShieldCheck,
  Building2,
  Plus,
  Copy,
  Trash,
  Edit,
  Save,
  Search,
  CheckCircle,
  XCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { Checkbox } from "@/components/ui/checkbox";

export default function UserPermissions() {
  const [activeTab, setActiveTab] = useState("usuarios");
  const [searchTerm, setSearchTerm] = useState("");
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);
  const [showDepartmentDialog, setShowDepartmentDialog] = useState(false);

  // Mock data
  const permissionTemplates = [
    { id: 1, name: "Administrador", description: "Acesso total ao sistema" },
    { id: 2, name: "Gerente", description: "Acesso gerencial limitado" },
    { id: 3, name: "Operador", description: "Acesso básico operacional" }
  ];

  const departments = [
    { id: 1, name: "Administrativo", activeUsers: 12 },
    { id: 2, name: "Financeiro", activeUsers: 8 },
    { id: 3, name: "Produção", activeUsers: 15 }
  ];

  const users = [
    { id: 1, name: "João Silva", email: "joao@email.com", department: "Administrativo", role: "Administrador", status: "active" },
    { id: 2, name: "Maria Santos", email: "maria@email.com", department: "Financeiro", role: "Gerente", status: "active" },
    { id: 3, name: "Pedro Costa", email: "pedro@email.com", department: "Produção", role: "Operador", status: "inactive" }
  ];

  // Available permissions for modules
  const modulePermissions = {
    dashboard: ["view", "edit"],
    users: ["view", "create", "edit", "delete"],
    reports: ["view", "create", "export"],
    settings: ["view", "edit"],
    financial: ["view", "create", "approve", "export"],
    production: ["view", "create", "edit", "delete"],
    inventory: ["view", "create", "edit", "delete"]
  };

  const handleSaveTemplate = () => {
    toast({
      title: "Template salvo",
      description: "O template de permissões foi salvo com sucesso."
    });
    setShowTemplateDialog(false);
  };

  const handleSaveDepartment = () => {
    toast({
      title: "Departamento salvo",
      description: "O departamento foi salvo com sucesso."
    });
    setShowDepartmentDialog(false);
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gerenciamento de Permissões</h1>
          <p className="text-gray-500">Gerencie permissões de usuários, departamentos e templates</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="usuarios" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            <span>Usuários</span>
          </TabsTrigger>
          <TabsTrigger value="departamentos" className="flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            <span>Departamentos</span>
          </TabsTrigger>
          <TabsTrigger value="templates" className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4" />
            <span>Templates</span>
          </TabsTrigger>
        </TabsList>

        {/* Aba de Usuários */}
        <TabsContent value="usuarios">
          <Card>
            <CardHeader>
              <CardTitle>Usuários</CardTitle>
              <CardDescription>
                Gerencie as permissões individuais dos usuários
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between mb-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Buscar usuários..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-64"
                  />
                  <Button variant="outline">
                    <Search className="w-4 h-4 mr-2" />
                    Buscar
                  </Button>
                </div>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Novo Usuário
                </Button>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Departamento</TableHead>
                    <TableHead>Perfil</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.department}</TableCell>
                      <TableCell>{user.role}</TableCell>
                      <TableCell>
                        <Badge variant={user.status === 'active' ? 'default' : 'secondary'}>
                          {user.status === 'active' ? 'Ativo' : 'Inativo'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600">
                            <Trash className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Aba de Departamentos */}
        <TabsContent value="departamentos">
          <Card>
            <CardHeader>
              <CardTitle>Departamentos</CardTitle>
              <CardDescription>
                Gerencie permissões por departamento
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between mb-4">
                <Input
                  placeholder="Buscar departamentos..."
                  className="w-64"
                />
                <Button onClick={() => setShowDepartmentDialog(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Novo Departamento
                </Button>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Departamento</TableHead>
                    <TableHead>Usuários Ativos</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {departments.map((dept) => (
                    <TableRow key={dept.id}>
                      <TableCell>{dept.name}</TableCell>
                      <TableCell>{dept.activeUsers} usuários</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Copy className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600">
                            <Trash className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Aba de Templates */}
        <TabsContent value="templates">
          <Card>
            <CardHeader>
              <CardTitle>Templates de Permissão</CardTitle>
              <CardDescription>
                Crie e gerencie templates de permissão pré-definidos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between mb-4">
                <Input
                  placeholder="Buscar templates..."
                  className="w-64"
                />
                <Button onClick={() => setShowTemplateDialog(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Novo Template
                </Button>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {permissionTemplates.map((template) => (
                    <TableRow key={template.id}>
                      <TableCell>{template.name}</TableCell>
                      <TableCell>{template.description}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Copy className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600">
                            <Trash className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialog para criar/editar template de permissão */}
      <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Template de Permissão</DialogTitle>
            <DialogDescription>
              Crie ou edite um template de permissão
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="templateName">Nome do Template</Label>
                <Input id="templateName" placeholder="Ex: Administrador" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="templateDescription">Descrição</Label>
                <Input id="templateDescription" placeholder="Descreva o template..." />
              </div>
            </div>

            <div className="space-y-4">
              <Label>Permissões por Módulo</Label>
              {Object.entries(modulePermissions).map(([module, permissions]) => (
                <div key={module} className="border p-4 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-lg capitalize">{module}</Label>
                    <Switch />
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {permissions.map((permission) => (
                      <div key={permission} className="flex items-center space-x-2">
                        <Checkbox id={`${module}-${permission}`} />
                        <Label htmlFor={`${module}-${permission}`} className="capitalize">
                          {permission}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTemplateDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveTemplate}>
              Salvar Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog para criar/editar departamento */}
      <Dialog open={showDepartmentDialog} onOpenChange={setShowDepartmentDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Departamento</DialogTitle>
            <DialogDescription>
              Crie ou edite um departamento
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="departmentName">Nome do Departamento</Label>
              <Input id="departmentName" placeholder="Ex: Administrativo" />
            </div>

            <div className="space-y-2">
              <Label>Template de Permissão Base</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um template" />
                </SelectTrigger>
                <SelectContent>
                  {permissionTemplates.map((template) => (
                    <SelectItem key={template.id} value={template.id.toString()}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Permissões Adicionais</Label>
              <div className="border p-4 rounded-lg space-y-2">
                {Object.entries(modulePermissions).map(([module, permissions]) => (
                  <div key={module} className="space-y-2">
                    <Label className="capitalize">{module}</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {permissions.map((permission) => (
                        <div key={permission} className="flex items-center space-x-2">
                          <Checkbox id={`dept-${module}-${permission}`} />
                          <Label htmlFor={`dept-${module}-${permission}`} className="capitalize">
                            {permission}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDepartmentDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveDepartment}>
              Salvar Departamento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}