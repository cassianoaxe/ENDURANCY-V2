
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { toast } from "@/components/ui/use-toast";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  FileText,
  Search,
  Upload,
  Download,
  Eye,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Calendar,
  Filter,
  RefreshCw,
  Printer,
  XCircle,
  Edit,
  Trash2,
  Plus
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function GerenciarReceituario() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [receitas, setReceitas] = useState([]);
  const [filteredReceitas, setFilteredReceitas] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [showNovaReceita, setShowNovaReceita] = useState(false);
  const [showDetalhes, setShowDetalhes] = useState(false);
  const [receitaSelecionada, setReceitaSelecionada] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [novaReceita, setNovaReceita] = useState({
    tipo_receita: 'simples',
    data_receita: format(new Date(), 'yyyy-MM-dd'),
    medico: {
      nome: '',
      crm: '',
      uf_crm: ''
    },
    paciente: {
      nome: '',
      documento: '',
      endereco: ''
    },
    produtos: []
  });

  useEffect(() => {
    const loadData = () => {
      try {
        const userType = localStorage.getItem('mockUserType');
        if (!userType) {
          console.log("User not authenticated, redirecting to login");
          navigate(createPageUrl("Access"));
          return;
        }

        const mockReceitas = [
          {
            id: "1",
            numero_controle: "REC001/2024",
            data_receita: new Date().toISOString(),
            tipo_receita: "especial",
            medico: {
              nome: "Dr. João Silva",
              crm: "12345-SP"
            },
            paciente: {
              nome: "Maria Oliveira",
              documento: "123.456.789-00"
            },
            produtos: [
              {
                produto_id: "1",
                nome_produto: "Canabidiol 100mg/ml",
                quantidade: 1,
                posologia: "1 gota, 3x ao dia"
              }
            ],
            status: "pendente"
          },
          // ... other prescriptions
        ];

        setReceitas(mockReceitas);
        setFilteredReceitas(mockReceitas);
        setIsLoading(false);
      } catch (error) {
        console.error("Erro ao carregar receituário:", error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar os dados do receituário.",
          variant: "destructive",
        });
      }
    };

    loadData();
  }, [navigate]);

  useEffect(() => {
    let result = [...receitas];
    
    if (searchTerm) {
      result = result.filter(receita => 
        receita.paciente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        receita.numero_controle.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (statusFilter !== 'all') {
      result = result.filter(receita => receita.status === statusFilter);
    }
    
    if (dateFilter !== 'all') {
      const today = new Date();
      const thirtyDaysAgo = new Date(today.setDate(today.getDate() - 30));
      
      switch (dateFilter) {
        case 'today':
          result = result.filter(receita => 
            new Date(receita.data_receita).toDateString() === new Date().toDateString()
          );
          break;
        case 'week':
          const weekAgo = new Date(today.setDate(today.getDate() - 7));
          result = result.filter(receita => 
            new Date(receita.data_receita) >= weekAgo
          );
          break;
        case 'month':
          result = result.filter(receita => 
            new Date(receita.data_receita) >= thirtyDaysAgo
          );
          break;
      }
    }
    
    setFilteredReceitas(result);
  }, [receitas, searchTerm, statusFilter, dateFilter]);

  const handleSubmitReceita = async () => {
    try {
      setProcessing(true);
      
      const receita = {
        ...novaReceita,
        id: `RC${Date.now()}`,
        organization_id: "mock-org",
        farmaceutico_id: "mock-user",
        data_dispensacao: new Date().toISOString(),
        status: "pendente",
        numero_controle: `RC${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`
      };
      
      const updatedReceitas = [...receitas, receita];
      setReceitas(updatedReceitas);
      setFilteredReceitas(updatedReceitas);
      
      toast({
        title: "Receita registrada",
        description: "A receita foi registrada com sucesso.",
      });
      
      setShowNovaReceita(false);
      setNovaReceita({
        tipo_receita: 'simples',
        data_receita: format(new Date(), 'yyyy-MM-dd'),
        medico: { nome: '', crm: '', uf_crm: '' },
        paciente: { nome: '', documento: '', endereco: '' },
        produtos: []
      });
      
    } catch (error) {
      console.error("Erro ao registrar receita:", error);
      toast({
        title: "Erro",
        description: "Não foi possível registrar a receita.",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      pendente: { label: 'Pendente SNGPC', className: 'bg-yellow-100 text-yellow-800' },
      enviado: { label: 'Enviado SNGPC', className: 'bg-green-100 text-green-800' },
      erro: { label: 'Erro SNGPC', className: 'bg-red-100 text-red-800' }
    };
    
    return (
      <Badge className={statusConfig[status].className}>
        {statusConfig[status].label}
      </Badge>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Gerenciamento de Receituário</h1>
          <p className="text-gray-500">Controle e registro de receitas médicas</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setShowNovaReceita(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Nova Receita
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filtros e Busca</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>Buscar</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Buscar por paciente, médico..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            
            <div>
              <Label>Status SNGPC</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="pendente">Pendente</SelectItem>
                  <SelectItem value="enviado">Enviado</SelectItem>
                  <SelectItem value="erro">Erro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Data</Label>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  <SelectItem value="today">Hoje</SelectItem>
                  <SelectItem value="week">Última semana</SelectItem>
                  <SelectItem value="month">Últimos 30 dias</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <ScrollArea className="h-[600px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Nº Controle</TableHead>
                  <TableHead>Paciente</TableHead>
                  <TableHead>Médico</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">
                      <div className="flex justify-center items-center py-4">
                        <RefreshCw className="w-6 h-6 animate-spin text-gray-400" />
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredReceitas.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-4">
                      Nenhuma receita encontrada
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredReceitas.map((receita) => (
                    <TableRow key={receita.id}>
                      <TableCell>
                        {format(new Date(receita.data_receita), 'dd/MM/yyyy')}
                      </TableCell>
                      <TableCell>{receita.numero_controle}</TableCell>
                      <TableCell>{receita.paciente.nome}</TableCell>
                      <TableCell>
                        {receita.medico.nome}
                        <div className="text-xs text-gray-500">
                          CRM: {receita.medico.crm}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {receita.tipo_receita.replace('_', ' ').toUpperCase()}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(receita.status)}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setReceitaSelecionada(receita);
                              setShowDetalhes(true);
                            }}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                          >
                            <Printer className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      <Dialog open={showNovaReceita} onOpenChange={setShowNovaReceita}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Nova Receita</DialogTitle>
            <DialogDescription>
              Registre uma nova receita no sistema
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Tipo de Receita</Label>
                <Select
                  value={novaReceita.tipo_receita}
                  onValueChange={(value) => setNovaReceita(prev => ({ ...prev, tipo_receita: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="simples">Simples</SelectItem>
                    <SelectItem value="especial">Especial</SelectItem>
                    <SelectItem value="antimicrobiano">Antimicrobiano</SelectItem>
                    <SelectItem value="especial_retencao">Especial c/ Retenção</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Data da Receita</Label>
                <Input
                  type="date"
                  value={novaReceita.data_receita}
                  onChange={(e) => setNovaReceita(prev => ({ ...prev, data_receita: e.target.value }))}
                />
              </div>
            </div>
            
            <Separator />
            
            <div>
              <h3 className="font-medium mb-4">Dados do Médico</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2">
                  <Label>Nome do Médico</Label>
                  <Input
                    value={novaReceita.medico.nome}
                    onChange={(e) => setNovaReceita(prev => ({
                      ...prev,
                      medico: { ...prev.medico, nome: e.target.value }
                    }))}
                  />
                </div>
                <div>
                  <Label>CRM</Label>
                  <Input
                    value={novaReceita.medico.crm}
                    onChange={(e) => setNovaReceita(prev => ({
                      ...prev,
                      medico: { ...prev.medico, crm: e.target.value }
                    }))}
                  />
                </div>
              </div>
            </div>
            
            <Separator />
            
            <div>
              <h3 className="font-medium mb-4">Dados do Paciente</h3>
              <div className="grid gap-4">
                <div>
                  <Label>Nome do Paciente</Label>
                  <Input
                    value={novaReceita.paciente.nome}
                    onChange={(e) => setNovaReceita(prev => ({
                      ...prev,
                      paciente: { ...prev.paciente, nome: e.target.value }
                    }))}
                  />
                </div>
                <div>
                  <Label>Documento (CPF)</Label>
                  <Input
                    value={novaReceita.paciente.documento}
                    onChange={(e) => setNovaReceita(prev => ({
                      ...prev,
                      paciente: { ...prev.paciente, documento: e.target.value }
                    }))}
                  />
                </div>
                <div>
                  <Label>Endereço</Label>
                  <Input
                    value={novaReceita.paciente.endereco}
                    onChange={(e) => setNovaReceita(prev => ({
                      ...prev,
                      paciente: { ...prev.paciente, endereco: e.target.value }
                    }))}
                  />
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNovaReceita(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSubmitReceita} disabled={processing}>
              {processing ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Processando...
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Registrar Receita
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showDetalhes} onOpenChange={setShowDetalhes}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Detalhes da Receita</DialogTitle>
          </DialogHeader>
          
          {receitaSelecionada && (
            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Informações Gerais</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-gray-500">Nº Controle:</span>
                    <p>{receitaSelecionada.numero_controle}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Data:</span>
                    <p>{format(new Date(receitaSelecionada.data_receita), 'dd/MM/yyyy')}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Tipo:</span>
                    <p>{receitaSelecionada.tipo_receita.replace('_', ' ').toUpperCase()}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Status SNGPC:</span>
                    <p>{receitaSelecionada.status.toUpperCase()}</p>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-medium mb-2">Médico</h3>
                <div className="space-y-1 text-sm">
                  <p>{receitaSelecionada.medico.nome}</p>
                  <p className="text-gray-500">
                    CRM: {receitaSelecionada.medico.crm}
                  </p>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-medium mb-2">Paciente</h3>
                <div className="space-y-1 text-sm">
                  <p>{receitaSelecionada.paciente.nome}</p>
                  <p className="text-gray-500">Doc: {receitaSelecionada.paciente.documento}</p>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-medium mb-2">Produtos</h3>
                <div className="space-y-2">
                  {receitaSelecionada.produtos.map((produto, index) => (
                    <div key={index} className="text-sm">
                      <p className="font-medium">{produto.nome_produto}</p>
                      <p className="text-gray-500">
                        Quantidade: {produto.quantidade} | Posologia: {produto.posologia}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDetalhes(false)}>
              Fechar
            </Button>
            <Button>
              <Printer className="w-4 h-4 mr-2" />
              Imprimir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
