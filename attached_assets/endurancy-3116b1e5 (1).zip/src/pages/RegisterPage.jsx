import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Building2, User as UserIcon, Eye, EyeOff, Mail, Key, Phone, ArrowLeft, ClipboardCheck, Landmark, UserRound } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

export default function RegisterPage() {
  const navigate = useNavigate();
  const [registerType, setRegisterType] = useState("organization");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    organizationType: "Empresa",
    agreeTerms: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const validateForm = () => {
    // Email validation
    if (!formData.email.includes('@') || !formData.email.includes('.')) {
      setError("Por favor, insira um email válido");
      return false;
    }

    // Password validation (minimum 6 characters)
    if (formData.password.length < 6) {
      setError("A senha deve ter pelo menos 6 caracteres");
      return false;
    }

    // Password confirmation
    if (formData.password !== formData.confirmPassword) {
      setError("As senhas não coincidem");
      return false;
    }

    // Terms agreement
    if (!formData.agreeTerms) {
      setError("Você deve concordar com os termos e condições");
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    try {
      // In a real app, you would register with your backend here
      // For demo purposes, we'll simulate a successful registration
      
      setTimeout(() => {
        // Show success toast
        toast({
          title: "Registro realizado com sucesso",
          description: registerType === "organization" 
            ? "Sua solicitação de organização foi enviada e está em análise." 
            : "Sua conta foi criada. Você será redirecionado para o login.",
        });
        
        // Redirect to appropriate page
        setTimeout(() => {
          navigate(createPageUrl("Access"));
        }, 2000);
        
        setIsLoading(false);
      }, 1500);
      
    } catch (error) {
      console.error("Registration error:", error);
      setError("Erro ao registrar. Por favor, tente novamente.");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gradient-to-b from-gray-50 to-gray-100 py-10 px-4">
      <Link to={createPageUrl("Index")} className="absolute top-8 left-8 flex items-center gap-2">
        <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
          <span className="text-green-600 font-bold">E</span>
        </div>
        <span className="font-semibold text-xl">Endurancy</span>
      </Link>
      
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Junte-se à Endurancy</h1>
          <p className="text-gray-500 mt-2">Crie sua conta para começar</p>
        </div>

        <Tabs defaultValue={registerType} onValueChange={setRegisterType} className="w-full">
          <TabsList className="grid grid-cols-2 mb-8">
            <TabsTrigger value="organization" className="flex flex-col items-center py-3 gap-1">
              <Building2 className="w-5 h-5" />
              <span>Organização</span>
            </TabsTrigger>
            <TabsTrigger value="patient" className="flex flex-col items-center py-3 gap-1">
              <UserIcon className="w-5 h-5" />
              <span>Paciente</span>
            </TabsTrigger>
          </TabsList>

          <Card>
            <CardHeader>
              <CardTitle>
                {registerType === "organization" ? "Registrar Organização" : "Registrar como Paciente"}
              </CardTitle>
              <CardDescription>
                {registerType === "organization" 
                  ? "Complete o formulário abaixo para solicitar a criação da sua organização." 
                  : "Complete o formulário abaixo para criar sua conta de paciente."}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                {error && (
                  <div className="bg-red-50 text-red-600 p-3 rounded-md text-sm">
                    {error}
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="name">
                    {registerType === "organization" ? "Nome da Organização" : "Nome Completo"}
                  </Label>
                  <div className="relative">
                    {registerType === "organization" ? (
                      <Landmark className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    ) : (
                      <UserRound className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    )}
                    <Input
                      id="name"
                      name="name"
                      placeholder={registerType === "organization" ? "Cannabis Brasil Ltda" : "João da Silva"}
                      className="pl-10"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                
                {registerType === "organization" && (
                  <div className="space-y-2">
                    <Label htmlFor="organizationType">Tipo de Organização</Label>
                    <Select
                      value={formData.organizationType}
                      onValueChange={(value) => handleSelectChange("organizationType", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo de organização" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Empresa">Empresa</SelectItem>
                        <SelectItem value="Associação">Associação</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder={registerType === "organization" 
                        ? "contato@cannabisbrasil.com.br" 
                        : "joao.silva@gmail.com"
                      }
                      className="pl-10"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefone</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="phone"
                      name="phone"
                      placeholder="(11) 99999-9999"
                      className="pl-10"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Senha</Label>
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      className="pl-10 pr-10"
                      value={formData.password}
                      onChange={handleChange}
                      required
                    />
                    <button 
                      type="button"
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-gray-500">A senha deve ter pelo menos 6 caracteres</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirmar Senha</Label>
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      className="pl-10 pr-10"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      required
                    />
                    <button 
                      type="button"
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
                
                <div className="flex items-start space-x-2 pt-2">
                  <Checkbox 
                    id="agreeTerms"
                    name="agreeTerms"
                    checked={formData.agreeTerms}
                    onCheckedChange={(checked) => 
                      setFormData({...formData, agreeTerms: checked})
                    }
                  />
                  <label 
                    htmlFor="agreeTerms" 
                    className="text-sm leading-tight"
                  >
                    Concordo com os{' '}
                    <a href="#" className="text-blue-600 hover:underline">
                      Termos de Serviço
                    </a>{' '}
                    e{' '}
                    <a href="#" className="text-blue-600 hover:underline">
                      Política de Privacidade
                    </a>
                  </label>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full mt-2"
                  disabled={isLoading}
                >
                  {isLoading ? "Processando..." : "Criar conta"}
                </Button>
              </form>
            </CardContent>
            
            <CardFooter className="flex flex-col space-y-4 border-t pt-4">
              <div className="text-center text-sm text-gray-500">
                Já tem uma conta?{' '}
                <Link to={createPageUrl("Access")} className="text-blue-600 hover:underline font-medium">
                  Faça login
                </Link>
              </div>
            </CardFooter>
          </Card>
        </Tabs>

        <div className="text-center mt-6">
          {registerType === "organization" && (
            <div className="p-4 bg-blue-50 rounded-lg text-sm text-blue-700">
              <ClipboardCheck className="w-5 h-5 mx-auto mb-2" />
              <p>Após o registro, sua solicitação será analisada pela nossa equipe.</p>
              <p className="mt-1">O processo de aprovação geralmente leva até 2 dias úteis.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}