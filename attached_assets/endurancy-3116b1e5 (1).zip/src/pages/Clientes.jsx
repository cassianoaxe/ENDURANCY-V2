import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  Users, 
  UserPlus, 
  Search, 
  Filter, 
  FileText, 
  Calendar,
  ShoppingBag,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileCheck,
  Eye,
  MapPin,
  Mail,
  Phone,
  Edit,
  Download,
  UserCog,
  ShieldCheck,
  MoreHorizontal
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Dados mockados para demonstração
const clientes = [
  {
    id: "cli001",
    nome_completo: "Ana Silva",
    email: "ana.silva@email.com",
    telefone: "(11) 98765-4321",
    cidade: "São Paulo",
    estado: "SP",
    status: "ativo",
    data_cadastro: "2023-05-15",
    tem_autorizacao_anvisa: true,
    validade_autorizacao: "2024-05-15",
    status_autorizacao: "valida",
    total_pedidos: 8,
    valor_total: 2840.50
  },
  {
    id: "cli002",
    nome_completo: "Carlos Oliveira",
    email: "carlos.oliveira@email.com",
    telefone: "(21) 99876-5432",
    cidade: "Rio de Janeiro",
    estado: "RJ",
    status: "ativo",
    data_cadastro: "2023-06-20",
    tem_autorizacao_anvisa: true,
    validade_autorizacao: "2023-12-20",
    status_autorizacao: "em_renovacao",
    total_pedidos: 5,
    valor_total: 1560.75
  },
  {
    id: "cli003",
    nome_completo: "Mariana Santos",
    email: "mariana.santos@email.com",
    telefone: "(31) 98888-7777",
    cidade: "Belo Horizonte",
    estado: "MG",
    status: "inativo",
    data_cadastro: "2023-04-10",
    tem_autorizacao_anvisa: false,
    validade_autorizacao: null,
    status_autorizacao: null,
    total_pedidos: 2,
    valor_total: 680.20
  },
  {
    id: "cli004",
    nome_completo: "Roberto Almeida",
    email: "roberto.almeida@email.com",
    telefone: "(41) 99999-8888",
    cidade: "Curitiba",
    estado: "PR",
    status: "ativo",
    data_cadastro: "2023-07-05",
    tem_autorizacao_anvisa: true,
    validade_autorizacao: "2023-11-05",
    status_autorizacao: "expirada",
    total_pedidos: 3,
    valor_total: 1240.30
  },
  {
    id: "cli005",
    nome_completo: "Patricia Lima",
    email: "patricia.lima@email.com",
    telefone: "(51) 98765-4321",
    cidade: "Porto Alegre",
    estado: "RS",
    status: "ativo",
    data_cadastro: "2023-08-15",
    tem_autorizacao_anvisa: true,
    validade_autorizacao: "2024-08-15",
    status_autorizacao: "valida",
    total_pedidos: 6,
    valor_total: 2150.80
  }
];

export default function Clientes() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [autorizacaoFilter, setAutorizacaoFilter] = useState("all");
  const [filteredClientes, setFilteredClientes] = useState(clientes);
  const [clienteDetalhes, setClienteDetalhes] = useState(null);
  const [mostrarDetalhes, setMostrarDetalhes] = useState(false);

  useEffect(() => {
    let filtered = clientes;
    
    if (searchTerm.trim() !== "") {
      filtered = filtered.filter(cliente => 
        cliente.nome_completo.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cliente.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cliente.telefone.includes(searchTerm)
      );
    }
    
    if (statusFilter !== "all") {
      filtered = filtered.filter(cliente => cliente.status === statusFilter);
    }
    
    if (autorizacaoFilter !== "all") {
      if (autorizacaoFilter === "com_autorizacao") {
        filtered = filtered.filter(cliente => cliente.tem_autorizacao_anvisa);
      } else if (autorizacaoFilter === "sem_autorizacao") {
        filtered = filtered.filter(cliente => !cliente.tem_autorizacao_anvisa);
      } else if (autorizacaoFilter === "expirada") {
        filtered = filtered.filter(cliente => 
          cliente.tem_autorizacao_anvisa && cliente.status_autorizacao === "expirada"
        );
      }
    }
    
    setFilteredClientes(filtered);
  }, [searchTerm, statusFilter, autorizacaoFilter]);

  const verDetalhes = (cliente) => {
    setClienteDetalhes(cliente);
    setMostrarDetalhes(true);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "ativo":
        return <Badge className="bg-green-100 text-green-800"><CheckCircle2 className="w-3 h-3 mr-1" />Ativo</Badge>;
      case "inativo":
        return <Badge className="bg-gray-100 text-gray-800"><XCircle className="w-3 h-3 mr-1" />Inativo</Badge>;
      case "bloqueado":
        return <Badge className="bg-red-100 text-red-800"><AlertTriangle className="w-3 h-3 mr-1" />Bloqueado</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getAutorizacaoBadge = (cliente) => {
    if (!cliente.tem_autorizacao_anvisa) {
      return <Badge variant="outline" className="bg-gray-100 text-gray-800">Sem autorização</Badge>;
    }
    
    switch (cliente.status_autorizacao) {
      case "valida":
        return <Badge className="bg-green-100 text-green-800"><ShieldCheck className="w-3 h-3 mr-1" />Válida</Badge>;
      case "expirada":
        return <Badge className="bg-red-100 text-red-800"><AlertTriangle className="w-3 h-3 mr-1" />Expirada</Badge>;
      case "em_renovacao":
        return <Badge className="bg-blue-100 text-blue-800"><Clock className="w-3 h-3 mr-1" />Em renovação</Badge>;
      default:
        return <Badge>{cliente.status_autorizacao}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Clientes</h1>
          <p className="text-gray-500 mt-1">
            Gerencie seus clientes e autorizações ANVISA
          </p>
        </div>
        <Link to={createPageUrl("NovoCliente")}>
          <Button className="gap-2">
            <UserPlus className="w-4 h-4" />
            Novo Cliente
          </Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
        <div className="relative w-full md:w-72">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar clientes..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex gap-2 items-center">
          <p className="text-sm text-gray-500 whitespace-nowrap">Status:</p>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Filtrar por status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="ativo">Ativos</SelectItem>
              <SelectItem value="inativo">Inativos</SelectItem>
              <SelectItem value="bloqueado">Bloqueados</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-2 items-center">
          <p className="text-sm text-gray-500 whitespace-nowrap">Autorização:</p>
          <Select value={autorizacaoFilter} onValueChange={setAutorizacaoFilter}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Filtrar por autorização" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              <SelectItem value="com_autorizacao">Com autorização</SelectItem>
              <SelectItem value="sem_autorizacao">Sem autorização</SelectItem>
              <SelectItem value="expirada">Autorização expirada</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cliente</TableHead>
                <TableHead>Contato</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Autorização ANVISA</TableHead>
                <TableHead>Pedidos</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredClientes.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    <div className="flex flex-col items-center justify-center text-gray-500">
                      <Users className="w-12 h-12 text-gray-300 mb-3" />
                      <p className="text-lg font-medium">Nenhum cliente encontrado</p>
                      <p className="text-sm">Tente ajustar os filtros ou cadastre um novo cliente</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredClientes.map((cliente) => (
                  <TableRow key={cliente.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback className="bg-primary/10 text-primary">
                            {cliente.nome_completo.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{cliente.nome_completo}</p>
                          <div className="flex items-center text-gray-500 text-sm gap-1">
                            <MapPin className="w-3 h-3" />
                            <span>{cliente.cidade}, {cliente.estado}</span>
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div className="flex items-center gap-1">
                          <Mail className="w-3 h-3 text-gray-500" />
                          <span>{cliente.email}</span>
                        </div>
                        <div className="flex items-center gap-1 mt-1">
                          <Phone className="w-3 h-3 text-gray-500" />
                          <span>{cliente.telefone}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(cliente.status)}
                    </TableCell>
                    <TableCell>
                      {getAutorizacaoBadge(cliente)}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="font-medium">{cliente.total_pedidos} pedidos</span>
                        <span className="text-sm text-gray-500">
                          R$ {cliente.valor_total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Ações</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => verDetalhes(cliente)}>
                            <Eye className="w-4 h-4 mr-2" />
                            Ver detalhes
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="w-4 h-4 mr-2" />
                            Editar cliente
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <FileText className="w-4 h-4 mr-2" />
                            Ver documentos
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <ShieldCheck className="w-4 h-4 mr-2" />
                            Autorizações ANVISA
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <ShoppingBag className="w-4 h-4 mr-2" />
                            Ver pedidos
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Modal de detalhes do cliente */}
      <Dialog open={mostrarDetalhes} onOpenChange={setMostrarDetalhes}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Cliente</DialogTitle>
            <DialogDescription>
              Informações completas do cliente e suas autorizações
            </DialogDescription>
          </DialogHeader>

          {clienteDetalhes && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Informações Pessoais</h3>
                  <div className="mt-2 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Nome:</span>
                      <span className="font-medium">{clienteDetalhes.nome_completo}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Email:</span>
                      <span>{clienteDetalhes.email}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Telefone:</span>
                      <span>{clienteDetalhes.telefone}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Localização:</span>
                      <span>{clienteDetalhes.cidade}, {clienteDetalhes.estado}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Status:</span>
                      <span>{getStatusBadge(clienteDetalhes.status)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Data de cadastro:</span>
                      <span>{new Date(clienteDetalhes.data_cadastro).toLocaleDateString('pt-BR')}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-500">Histórico de Compras</h3>
                  <div className="mt-2 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Total de pedidos:</span>
                      <span className="font-medium">{clienteDetalhes.total_pedidos}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Valor total:</span>
                      <span className="font-medium">
                        R$ {clienteDetalhes.valor_total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Autorização ANVISA</h3>
                  <div className="mt-2 p-3 border rounded-lg">
                    {clienteDetalhes.tem_autorizacao_anvisa ? (
                      <>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm text-gray-500">Status:</span>
                          <span>{getAutorizacaoBadge(clienteDetalhes)}</span>
                        </div>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm text-gray-500">Validade:</span>
                          <span>{new Date(clienteDetalhes.validade_autorizacao).toLocaleDateString('pt-BR')}</span>
                        </div>
                        <Button size="sm" className="mt-2 w-full">
                          <Eye className="w-4 h-4 mr-2" />
                          Ver detalhes da autorização
                        </Button>
                      </>
                    ) : (
                      <div className="text-center py-3">
                        <AlertTriangle className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                        <p className="text-sm font-medium">Cliente sem autorização ANVISA</p>
                        <Button size="sm" variant="outline" className="mt-3">
                          <Plus className="w-3 h-3 mr-1" />
                          Adicionar autorização
                        </Button>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-500">Ações Rápidas</h3>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <Button variant="outline" size="sm">
                      <Edit className="w-3 h-3 mr-1" />
                      Editar
                    </Button>
                    <Button variant="outline" size="sm">
                      <FileText className="w-3 h-3 mr-1" />
                      Documentos
                    </Button>
                    <Button variant="outline" size="sm">
                      <ShoppingBag className="w-3 h-3 mr-1" />
                      Pedidos
                    </Button>
                    <Button variant="outline" size="sm">
                      <FileCheck className="w-3 h-3 mr-1" />
                      Prescrições
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setMostrarDetalhes(false)}>
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}