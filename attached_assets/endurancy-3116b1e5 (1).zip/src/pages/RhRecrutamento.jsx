
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";
import { 
  UserPlus, 
  Search, 
  Filter, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Check, 
  Users, 
  Briefcase, 
  FileText, 
  Edit, 
  Trash, 
  Plus, 
  MoreHorizontal, 
  Tag, 
  Building, 
  MapPin, 
  ClipboardCheck, 
  Paperclip,
  Mail,
  Phone,
  Linkedin,
  GraduationCap
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Dados simulados de vagas
const mockVagas = [
  {
    id: "vaga-001",
    titulo: "Farmacêutico(a) Responsável Técnico",
    departamento: "Produção",
    tipo: "CLT",
    status: "aberta",
    localidade: "São Paulo, SP",
    dataPublicacao: "2023-06-15",
    dataEncerramento: "2023-07-30",
    salario: "R$ 6.500,00 - R$ 8.200,00",
    requisitos: [
      "Graduação em Farmácia",
      "Registro ativo no CRF",
      "Experiência mínima de 3 anos na indústria farmacêutica",
      "Conhecimento em boas práticas de fabricação"
    ],
    descricao: "Atuar como responsável técnico nos processos de produção de medicamentos à base de cannabis, garantindo o cumprimento das normas regulatórias e padrões de qualidade.",
    beneficios: ["Plano de saúde", "Vale refeição", "Vale transporte", "Participação nos lucros"],
    candidatos: 28,
    priority: "alta"
  },
  {
    id: "vaga-002",
    titulo: "Analista de Controle de Qualidade",
    departamento: "Qualidade",
    tipo: "CLT",
    status: "aberta",
    localidade: "São Paulo, SP",
    dataPublicacao: "2023-06-20",
    dataEncerramento: "2023-07-20",
    salario: "R$ 4.800,00 - R$ 5.500,00",
    requisitos: [
      "Graduação em Farmácia, Química ou áreas afins",
      "Experiência em análises físico-químicas",
      "Conhecimento em HPLC e técnicas cromatográficas",
      "Familiaridade com sistemas de gestão da qualidade"
    ],
    descricao: "Realizar análises físico-químicas de matérias-primas e produtos acabados, garantindo o cumprimento dos requisitos de qualidade.",
    beneficios: ["Plano de saúde", "Vale refeição", "Vale transporte"],
    candidatos: 19,
    prioridade: "média"
  },
  {
    id: "vaga-003",
    titulo: "Especialista em Cultivo de Cannabis",
    departamento: "Cultivo",
    tipo: "CLT",
    status: "aberta",
    localidade: "Interior de SP",
    dataPublicacao: "2023-06-10",
    dataEncerramento: "2023-07-15",
    salario: "R$ 7.000,00 - R$ 9.000,00",
    requisitos: [
      "Graduação em Agronomia, Biologia ou áreas correlatas",
      "Experiência comprovada em cultivo de cannabis medicinal",
      "Conhecimento de técnicas hidropônicas e sistemas de iluminação",
      "Familiaridade com regulamentações sanitárias"
    ],
    descricao: "Gerenciar o cultivo de plantas de cannabis medicinal, garantindo qualidade e produtividade através do controle de parâmetros ambientais e nutricionais.",
    beneficios: ["Plano de saúde", "Vale refeição", "Auxílio moradia", "Participação nos lucros"],
    candidatos: 12,
    prioridade: "alta"
  },
  {
    id: "vaga-004",
    titulo: "Representante Comercial",
    departamento: "Comercial",
    tipo: "Autônomo",
    status: "aberta",
    localidade: "Todo o Brasil",
    dataPublicacao: "2023-06-25",
    dataEncerramento: "2023-08-01",
    salario: "Comissionado",
    requisitos: [
      "Experiência em vendas no setor farmacêutico",
      "Boa comunicação e habilidade de negociação",
      "Carteira de clientes no setor médico é um diferencial",
      "Disponibilidade para viagens"
    ],
    descricao: "Atuar na prospecção e manutenção de clientes, apresentando produtos de cannabis medicinal para médicos e clínicas especializadas.",
    beneficios: ["Altas comissões", "Flexibilidade de horário", "Treinamentos especializados"],
    candidatos: 45,
    prioridade: "média"
  },
  {
    id: "vaga-005",
    titulo: "Assistente de Pesquisa",
    departamento: "P&D",
    tipo: "Estágio",
    status: "aberta",
    localidade: "São Paulo, SP",
    dataPublicacao: "2023-07-01",
    dataEncerramento: "2023-07-25",
    salario: "R$ 1.800,00",
    requisitos: [
      "Estudante de Farmácia, Bioquímica ou áreas afins",
      "Conhecimento em técnicas laboratoriais básicas",
      "Boa capacidade analítica",
      "Interesse em pesquisa com canabinoides"
    ],
    descricao: "Auxiliar na condução de experimentos e análises relacionados ao desenvolvimento de novos produtos à base de cannabis.",
    beneficios: ["Bolsa auxílio", "Vale refeição", "Vale transporte", "Possibilidade de efetivação"],
    candidatos: 32,
    prioridade: "baixa"
  },
  {
    id: "vaga-006",
    titulo: "Auxiliar Administrativo",
    departamento: "Administrativo",
    tipo: "CLT",
    status: "encerrada",
    localidade: "São Paulo, SP",
    dataPublicacao: "2023-05-10",
    dataEncerramento: "2023-06-15",
    salario: "R$ 2.500,00",
    requisitos: [
      "Ensino médio completo",
      "Experiência com rotinas administrativas",
      "Conhecimento em pacote Office",
      "Boa comunicação"
    ],
    descricao: "Realizar atividades administrativas, como controle de documentos, atendimento telefônico e suporte às diversas áreas da empresa.",
    beneficios: ["Plano de saúde", "Vale refeição", "Vale transporte"],
    candidatos: 87,
    prioridade: "baixa"
  }
];

// Dados simulados de candidatos
const mockCandidatos = [
  {
    id: "cand-001",
    nome: "Ana Carolina Silva",
    vaga_id: "vaga-001",
    vaga_titulo: "Farmacêutico(a) Responsável Técnico",
    email: "ana.silva@email.com",
    telefone: "(11) 98765-4321",
    status: "entrevista",
    ultima_atualizacao: "2023-07-10",
    curriculo_url: "#",
    linkedin: "linkedin.com/in/anasilva",
    experiencia: "5 anos como Farmacêutica RT em indústria farmacêutica",
    formacao: "Farmácia - USP, Especialização em Gestão da Qualidade",
    pretensao_salarial: "R$ 8.000,00",
    notas: "Excelente candidata, com experiência relevante e boa comunicação.",
    etapa_atual: "Entrevista técnica",
    proxima_etapa: "Entrevista com diretoria",
    data_entrevista: "2023-07-15"
  },
  {
    id: "cand-002",
    nome: "Roberto Almeida",
    vaga_id: "vaga-001",
    vaga_titulo: "Farmacêutico(a) Responsável Técnico",
    email: "roberto.almeida@email.com",
    telefone: "(11) 97654-3210",
    status: "triagem",
    ultima_atualizacao: "2023-07-08",
    curriculo_url: "#",
    linkedin: "linkedin.com/in/robertoalmeida",
    experiencia: "4 anos como Farmacêutico em farmácia de manipulação",
    formacao: "Farmácia - UNICAMP",
    pretensao_salarial: "R$ 7.500,00",
    notas: "Perfil interessante, mas falta experiência em indústria.",
    etapa_atual: "Análise de currículo",
    proxima_etapa: "Entrevista inicial",
    data_entrevista: null
  },
  {
    id: "cand-003",
    nome: "Fernanda Costa",
    vaga_id: "vaga-001",
    vaga_titulo: "Farmacêutico(a) Responsável Técnico",
    email: "fernanda.costa@email.com",
    telefone: "(11) 96543-2109",
    status: "aprovado",
    ultima_atualizacao: "2023-07-12",
    curriculo_url: "#",
    linkedin: "linkedin.com/in/fernandacosta",
    experiencia: "7 anos como Farmacêutica RT em indústria de fitoterápicos",
    formacao: "Farmácia - UFRJ, MBA em Gestão Industrial",
    pretensao_salarial: "R$ 8.500,00",
    notas: "Candidata aprovada. Experiência excelente e conhecimento técnico elevado.",
    etapa_atual: "Aprovada",
    proxima_etapa: "Contratação",
    data_entrevista: "2023-07-05"
  },
  {
    id: "cand-004",
    nome: "Carlos Mendes",
    vaga_id: "vaga-001",
    vaga_titulo: "Farmacêutico(a) Responsável Técnico",
    email: "carlos.mendes@email.com",
    telefone: "(11) 95432-1098",
    status: "rejeitado",
    ultima_atualizacao: "2023-07-05",
    curriculo_url: "#",
    linkedin: "linkedin.com/in/carlosmendes",
    experiencia: "3 anos como Farmacêutico em drogaria",
    formacao: "Farmácia - UNIFESP",
    pretensao_salarial: "R$ 9.000,00",
    notas: "Rejeitado por falta de experiência relevante e pretensão salarial acima do orçamento.",
    etapa_atual: "Rejeitado",
    proxima_etapa: null,
    data_entrevista: "2023-07-03"
  },
  {
    id: "cand-005",
    nome: "Juliana Ferreira",
    vaga_id: "vaga-003",
    vaga_titulo: "Especialista em Cultivo de Cannabis",
    email: "juliana.ferreira@email.com",
    telefone: "(11) 94321-0987",
    status: "entrevista",
    ultima_atualizacao: "2023-07-11",
    curriculo_url: "#",
    linkedin: "linkedin.com/in/julianaferreira",
    experiencia: "5 anos em cultivo de plantas medicinais, 2 anos com cannabis medicinal no exterior",
    formacao: "Agronomia - ESALQ/USP, Especialização em Plantas Medicinais",
    pretensao_salarial: "R$ 8.800,00",
    notas: "Excelente candidata com experiência internacional relevante.",
    etapa_atual: "Entrevista técnica",
    proxima_etapa: "Entrevista com diretoria",
    data_entrevista: "2023-07-16"
  },
  {
    id: "cand-006",
    nome: "Lucas Oliveira",
    vaga_id: "vaga-002",
    vaga_titulo: "Analista de Controle de Qualidade",
    email: "lucas.oliveira@email.com",
    telefone: "(11) 93210-9876",
    status: "triagem",
    ultima_atualizacao: "2023-07-09",
    curriculo_url: "#",
    linkedin: "linkedin.com/in/lucasoliveira",
    experiencia: "2 anos como Analista de Qualidade Jr em indústria farmacêutica",
    formacao: "Química - UNESP",
    pretensao_salarial: "R$ 5.000,00",
    notas: "Bom potencial, mas pouca experiência.",
    etapa_atual: "Análise de currículo",
    proxima_etapa: "Entrevista inicial",
    data_entrevista: null
  }
];

export default function RhRecrutamento() {
  const [vagas, setVagas] = useState([]);
  const [candidatos, setCandidatos] = useState([]);
  const [filterStatus, setFilterStatus] = useState("aberta");
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("vagas");
  const [selectedVaga, setSelectedVaga] = useState(null);
  const [selectedCandidato, setSelectedCandidato] = useState(null);
  const [showVagaDialog, setShowVagaDialog] = useState(false);
  const [showCandidatoDialog, setShowCandidatoDialog] = useState(false);

  useEffect(() => {
    // Simulação de carregamento de dados
    setTimeout(() => {
      setVagas(mockVagas);
      setCandidatos(mockCandidatos);
      setIsLoading(false);
    }, 800);
  }, []);

  // Filtro de vagas
  const filteredVagas = vagas.filter(vaga => {
    if (filterStatus !== "todas" && vaga.status !== filterStatus) return false;
    
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      return (
        vaga.titulo.toLowerCase().includes(searchLower) ||
        vaga.departamento.toLowerCase().includes(searchLower) ||
        vaga.localidade.toLowerCase().includes(searchLower)
      );
    }
    
    return true;
  });

  // Filtro de candidatos
  const filteredCandidatos = candidatos.filter(candidato => {
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      return (
        candidato.nome.toLowerCase().includes(searchLower) ||
        candidato.vaga_titulo.toLowerCase().includes(searchLower) ||
        candidato.status.toLowerCase().includes(searchLower)
      );
    }
    
    return true;
  });

  // Contadores para o dashboard
  const vagasAbertas = vagas.filter(v => v.status === "aberta").length;
  const totalCandidatos = candidatos.length;
  const candidatosEmEntrevista = candidatos.filter(c => c.status === "entrevista").length;
  const candidatosAprovados = candidatos.filter(c => c.status === "aprovado").length;

  // Formatar data
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "aberta":
        return <Badge className="bg-green-100 text-green-800">Aberta</Badge>;
      case "encerrada":
        return <Badge className="bg-gray-100 text-gray-800">Encerrada</Badge>;
      case "triagem":
        return <Badge className="bg-blue-100 text-blue-800">Triagem</Badge>;
      case "entrevista":
        return <Badge className="bg-yellow-100 text-yellow-800">Entrevista</Badge>;
      case "aprovado":
        return <Badge className="bg-emerald-100 text-emerald-800">Aprovado</Badge>;
      case "rejeitado":
        return <Badge className="bg-red-100 text-red-800">Rejeitado</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  const getPriorityBadge = (priority) => {
    switch (priority) {
      case "alta":
        return <Badge className="bg-red-100 text-red-800">Alta Prioridade</Badge>;
      case "média":
        return <Badge className="bg-yellow-100 text-yellow-800">Média Prioridade</Badge>;
      case "baixa":
        return <Badge className="bg-blue-100 text-blue-800">Baixa Prioridade</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Recrutamento e Seleção</h1>
          <p className="text-gray-500 mt-1">
            Gerenciamento de vagas e candidatos
          </p>
        </div>
        
        <Button className="bg-green-600 hover:bg-green-700" onClick={() => setShowVagaDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Vaga
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Vagas Abertas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">{vagasAbertas}</div>
              <Briefcase className="h-4 w-4 text-gray-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Total de Candidatos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">{totalCandidatos}</div>
              <Users className="h-4 w-4 text-gray-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Em Processo de Entrevista</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">{candidatosEmEntrevista}</div>
              <ClipboardCheck className="h-4 w-4 text-gray-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-500">Aprovados Aguardando Contratação</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-end">
              <div className="text-2xl font-bold">{candidatosAprovados}</div>
              <CheckCircle2 className="h-4 w-4 text-gray-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-3 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar vagas ou candidatos..."
            className="pl-9"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2 w-full sm:w-auto">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full sm:w-40">
              <div className="flex items-center">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Status" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas</SelectItem>
              <SelectItem value="aberta">Abertas</SelectItem>
              <SelectItem value="encerrada">Encerradas</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="gap-2" onClick={() => { setSearchTerm(""); setFilterStatus("aberta"); }}>
            <XCircle className="h-4 w-4" />
            Limpar
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="vagas" className="w-full" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="vagas">Vagas</TabsTrigger>
          <TabsTrigger value="candidatos">Candidatos</TabsTrigger>
        </TabsList>
        
        <TabsContent value="vagas" className="mt-6">
          {isLoading ? (
            <div className="flex justify-center items-center py-32">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
            </div>
          ) : filteredVagas.length === 0 ? (
            <div className="text-center py-16">
              <Briefcase className="h-16 w-16 text-gray-300 mx-auto" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">Nenhuma vaga encontrada</h3>
              <p className="mt-2 text-gray-500">
                {filterStatus !== "todas" 
                  ? `Não há vagas com o status "${filterStatus}" no momento.` 
                  : "Não foram encontradas vagas com os filtros atuais."}
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {filteredVagas.map((vaga) => (
                <Card key={vaga.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <CardTitle>{vaga.titulo}</CardTitle>
                        <div className="flex flex-wrap gap-2">
                          {getStatusBadge(vaga.status)}
                          <Badge variant="outline">{vaga.tipo}</Badge>
                          <Badge variant="outline">{vaga.departamento}</Badge>
                          {getPriorityBadge(vaga.prioridade)}
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => {setSelectedVaga(vaga); setShowVagaDialog(true);}}>
                            <Edit className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                          {vaga.status === "aberta" && (
                            <DropdownMenuItem>
                              <XCircle className="mr-2 h-4 w-4" />
                              Encerrar vaga
                            </DropdownMenuItem>
                          )}
                          {vaga.status === "encerrada" && (
                            <DropdownMenuItem>
                              <CheckCircle2 className="mr-2 h-4 w-4" />
                              Reabrir vaga
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem>
                            <Mail className="mr-2 h-4 w-4" />
                            Enviar para candidatos
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <UserPlus className="mr-2 h-4 w-4" />
                            Adicionar candidato
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600">
                            <Trash className="mr-2 h-4 w-4" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="space-y-4">
                      <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-gray-500">
                        <div className="flex items-center">
                          <MapPin className="mr-1 h-4 w-4" />
                          {vaga.localidade}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="mr-1 h-4 w-4" />
                          Publicada em {formatDate(vaga.dataPublicacao)}
                        </div>
                        {vaga.dataEncerramento && (
                          <div className="flex items-center">
                            <Clock className="mr-1 h-4 w-4" />
                            Encerra em {formatDate(vaga.dataEncerramento)}
                          </div>
                        )}
                        <div className="flex items-center">
                          <Users className="mr-1 h-4 w-4" />
                          {vaga.candidatos} candidatos
                        </div>
                      </div>
                      
                      <p className="text-gray-700">{vaga.descricao}</p>
                      
                      <div>
                        <p className="font-medium mb-2">Requisitos:</p>
                        <ul className="list-disc pl-5 space-y-1 text-gray-700">
                          {vaga.requisitos.map((req, index) => (
                            <li key={index}>{req}</li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Tag className="h-4 w-4 text-gray-500" />
                        <span className="font-medium">Salário:</span>
                        <span>{vaga.salario}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between border-t bg-gray-50 p-4">
                    <div>
                      <Badge variant="outline" className="mr-2">
                        {vaga.beneficios.length} benefícios
                      </Badge>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          setActiveTab("candidatos");
                          setSearchTerm(vaga.titulo);
                        }}
                      >
                        <Users className="mr-2 h-4 w-4" />
                        Ver Candidatos
                      </Button>
                      <Button>
                        <UserPlus className="mr-2 h-4 w-4" />
                        Adicionar Candidato
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="candidatos" className="mt-6">
          {isLoading ? (
            <div className="flex justify-center items-center py-32">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
            </div>
          ) : filteredCandidatos.length === 0 ? (
            <div className="text-center py-16">
              <Users className="h-16 w-16 text-gray-300 mx-auto" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">Nenhum candidato encontrado</h3>
              <p className="mt-2 text-gray-500">
                Não foram encontrados candidatos com os filtros atuais.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {filteredCandidatos.map((candidato) => (
                <Card key={candidato.id} className="overflow-hidden">
                  <div className="flex flex-col md:flex-row">
                    <div className="flex flex-col justify-between p-6 flex-1">
                      <div>
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-lg font-semibold">{candidato.nome}</h3>
                            <p className="text-gray-600">{candidato.vaga_titulo}</p>
                          </div>
                          {getStatusBadge(candidato.status)}
                        </div>
                        
                        <div className="mt-4 space-y-2">
                          <p className="flex items-center text-sm">
                            <Mail className="mr-2 h-4 w-4 text-gray-500" />
                            {candidato.email}
                          </p>
                          <p className="flex items-center text-sm">
                            <Briefcase className="mr-2 h-4 w-4 text-gray-500" />
                            {candidato.experiencia}
                          </p>
                          <p className="flex items-center text-sm">
                            <FileText className="mr-2 h-4 w-4 text-gray-500" />
                            {candidato.formacao}
                          </p>
                        </div>
                      </div>
                      
                      <div className="mt-6 flex items-end justify-between">
                        <div className="text-sm text-gray-500">
                          Última atualização: {formatDate(candidato.ultima_atualizacao)}
                        </div>
                        <div>
                          <Button variant="outline" className="mr-2" onClick={() => window.open(candidato.curriculo_url, '_blank')}>
                            <Paperclip className="mr-2 h-4 w-4" />
                            Currículo
                          </Button>
                          <Button onClick={() => {setSelectedCandidato(candidato); setShowCandidatoDialog(true);}}>
                            Ver Detalhes
                          </Button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="md:w-64 p-6 bg-gray-50 border-t md:border-t-0 md:border-l">
                      <h4 className="font-medium mb-4">Status do Processo</h4>
                      
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Etapa atual</p>
                          <p className="font-medium">{candidato.etapa_atual}</p>
                        </div>
                        
                        {candidato.proxima_etapa && (
                          <div>
                            <p className="text-sm text-gray-500 mb-1">Próxima etapa</p>
                            <p className="font-medium">{candidato.proxima_etapa}</p>
                          </div>
                        )}
                        
                        {candidato.data_entrevista && (
                          <div>
                            <p className="text-sm text-gray-500 mb-1">Data da entrevista</p>
                            <p className="font-medium">{formatDate(candidato.data_entrevista)}</p>
                          </div>
                        )}
                        
                        <Separator />
                        
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Pretensão salarial</p>
                          <p className="font-medium">{candidato.pretensao_salarial}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Dialog de Detalhes da Vaga */}
      <Dialog open={showVagaDialog} onOpenChange={setShowVagaDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{selectedVaga ? "Editar Vaga" : "Nova Vaga"}</DialogTitle>
            <DialogDescription>
              {selectedVaga 
                ? "Altere as informações da vaga conforme necessário." 
                : "Preencha as informações para criar uma nova vaga."}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 max-h-[60vh] overflow-y-auto py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="titulo">Título da Vaga</Label>
                <Input id="titulo" defaultValue={selectedVaga?.titulo || ""} />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="departamento">Departamento</Label>
                <Select defaultValue={selectedVaga?.departamento || ""}>
                  <SelectTrigger id="departamento">
                    <SelectValue placeholder="Selecione um departamento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Produção">Produção</SelectItem>
                    <SelectItem value="Qualidade">Qualidade</SelectItem>
                    <SelectItem value="Cultivo">Cultivo</SelectItem>
                    <SelectItem value="Comercial">Comercial</SelectItem>
                    <SelectItem value="P&D">P&D</SelectItem>
                    <SelectItem value="Administrativo">Administrativo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Mais campos do formulário... */}
            </div>
            
            {/* Formulário simplificado para manter o exemplo conciso */}
            <div className="space-y-2">
              <Label htmlFor="descricao">Descrição</Label>
              <Input id="descricao" defaultValue={selectedVaga?.descricao || ""} />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowVagaDialog(false)}>Cancelar</Button>
            <Button>{selectedVaga ? "Salvar Alterações" : "Criar Vaga"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog de Detalhes do Candidato */}
      <Dialog open={showCandidatoDialog} onOpenChange={setShowCandidatoDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Candidato</DialogTitle>
            <DialogDescription>
              Informações detalhadas e progresso do candidato.
            </DialogDescription>
          </DialogHeader>
          
          {selectedCandidato && (
            <div className="space-y-6 max-h-[60vh] overflow-y-auto py-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-semibold">{selectedCandidato.nome}</h3>
                  <p className="text-gray-600">{selectedCandidato.vaga_titulo}</p>
                </div>
                {getStatusBadge(selectedCandidato.status)}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Informações de Contato</h4>
                    <div className="space-y-2">
                      <p className="flex items-center text-sm">
                        <Mail className="mr-2 h-4 w-4 text-gray-500" />
                        {selectedCandidato.email}
                      </p>
                      <p className="flex items-center text-sm">
                        <Phone className="mr-2 h-4 w-4 text-gray-500" />
                        {selectedCandidato.telefone}
                      </p>
                      {selectedCandidato.linkedin && (
                        <p className="flex items-center text-sm">
                          <Linkedin className="mr-2 h-4 w-4 text-gray-500" />
                          {selectedCandidato.linkedin}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Formação e Experiência</h4>
                    <div className="space-y-2">
                      <p className="flex items-center text-sm">
                        <GraduationCap className="mr-2 h-4 w-4 text-gray-500" />
                        {selectedCandidato.formacao}
                      </p>
                      <p className="flex items-center text-sm">
                        <Briefcase className="mr-2 h-4 w-4 text-gray-500" />
                        {selectedCandidato.experiencia}
                      </p>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Notas</h4>
                    <p className="text-sm text-gray-700">{selectedCandidato.notas}</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Status do Processo</h4>
                    <div className="space-y-2">
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Etapa atual</p>
                        <p className="font-medium">{selectedCandidato.etapa_atual}</p>
                      </div>
                      
                      {selectedCandidato.proxima_etapa && (
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Próxima etapa</p>
                          <p className="font-medium">{selectedCandidato.proxima_etapa}</p>
                        </div>
                      )}
                      
                      {selectedCandidato.data_entrevista && (
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Data da entrevista</p>
                          <p className="font-medium">{formatDate(selectedCandidato.data_entrevista)}</p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Informações Adicionais</h4>
                    <div className="space-y-2">
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Pretensão salarial</p>
                        <p className="font-medium">{selectedCandidato.pretensao_salarial}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Última atualização</p>
                        <p className="font-medium">{formatDate(selectedCandidato.ultima_atualizacao)}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-4">
                    <Button className="w-full" variant="outline" onClick={() => window.open(selectedCandidato.curriculo_url, '_blank')}>
                      <Paperclip className="mr-2 h-4 w-4" />
                      Ver Currículo
                    </Button>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h4 className="font-medium mb-4">Atualizar Status</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
                  <Button variant="outline" className="justify-start">
                    <ClipboardCheck className="mr-2 h-4 w-4" />
                    Agendar Entrevista
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <CheckCircle2 className="mr-2 h-4 w-4 text-green-600" />
                    Aprovar
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <XCircle className="mr-2 h-4 w-4 text-red-600" />
                    Rejeitar
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Mail className="mr-2 h-4 w-4" />
                    Enviar Email
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCandidatoDialog(false)}>Fechar</Button>
            <Button>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
