import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import {
  Beaker,
  Thermometer,
  Clock,
  Timer,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  FileText,
  User,
  Calendar,
  Scale,
  BarChart,
  Clipboard,
  ClipboardCheck,
  AlertTriangle,
  Search,
  FilterX,
  Plus,
  Trash2,
  Save,
  PlayCircle,
  PauseCircle,
  StopCircle,
  RefreshCw,
  Gauge,
  Droplets,
  Microscope
} from "lucide-react";

export default function ProducaoExtracao() {
  const [loading, setLoading] = useState(false);
  const [ordensProducao, setOrdensProducao] = useState([]);
  const [loteAtivo, setLoteAtivo] = useState(null);
  const [temperatura, setTemperatura] = useState(40);
  const [pressao, setPressao] = useState(150);
  const [tempoRestante, setTempoRestante] = useState(0);
  const [emProcesso, setEmProcesso] = useState(false);
  const [estadoEquipamento, setEstadoEquipamento] = useState('standby');
  const [checklistConcluido, setChecklistConcluido] = useState(false);

  // Checklist de verificação
  const [checklist, setChecklist] = useState({
    limpezaEquipamento: false,
    calibracaoBalanca: false,
    verificacaoMateriaPrima: false,
    verificacaoSolventes: false,
    verificacaoProcedimento: false,
    verificacaoSeguranca: false
  });

  useEffect(() => {
    // Simulação de carregamento de dados
    setLoading(true);
    setTimeout(() => {
      setOrdensProducao([
        {
          id: "OP-2023-125",
          produto: "Extrato CBD Full Spectrum",
          lote: "LOT-EXT-072",
          quantidade: 5000,
          unidade: "gramas",
          status: "pendente",
          materiasPrimas: [
            { nome: "Biomassa Cannabis Sativa", quantidade: "25kg", lote: "BIO-456" },
            { nome: "Etanol 96%", quantidade: "100L", lote: "ETN-789" }
          ],
          parametros: {
            temperatura: "40-45°C",
            pressao: "150-160 bar",
            tempo: "120 min"
          }
        },
        {
          id: "OP-2023-126",
          produto: "Extrato CBD Isolado",
          lote: "LOT-EXT-073",
          quantidade: 3000,
          unidade: "gramas",
          status: "pendente",
          materiasPrimas: [
            { nome: "Biomassa Cannabis Sativa", quantidade: "15kg", lote: "BIO-457" },
            { nome: "Etanol 96%", quantidade: "60L", lote: "ETN-790" }
          ],
          parametros: {
            temperatura: "40-45°C",
            pressao: "150-160 bar",
            tempo: "120 min"
          }
        }
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const iniciarProcesso = (ordem) => {
    setLoteAtivo(ordem);
    setEstadoEquipamento('preparando');
    
    // Simular preparação do equipamento
    setTimeout(() => {
      setEstadoEquipamento('pronto');
    }, 2000);
  };

  const atualizarChecklist = (item, valor) => {
    setChecklist(prev => {
      const novoChecklist = {
        ...prev,
        [item]: valor
      };
      const todosConcluidos = Object.values(novoChecklist).every(Boolean);
      setChecklistConcluido(todosConcluidos);
      return novoChecklist;
    });
  };

  const iniciarExtracao = () => {
    if (!checklistConcluido) {
      alert("É necessário concluir o checklist antes de iniciar a extração.");
      return;
    }
    
    setEmProcesso(true);
    setEstadoEquipamento('processando');
    setTempoRestante(120); // 120 minutos de processo

    // Simular contagem regressiva
    const interval = setInterval(() => {
      setTempoRestante(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setEmProcesso(false);
          setEstadoEquipamento('concluido');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const pausarExtracao = () => {
    setEmProcesso(false);
    setEstadoEquipamento('pausado');
  };

  const continuarExtracao = () => {
    setEmProcesso(true);
    setEstadoEquipamento('processando');
  };

  const finalizarExtracao = () => {
    setEmProcesso(false);
    setEstadoEquipamento('concluido');
    setTempoRestante(0);
  };

  const reiniciarEquipamento = () => {
    setEstadoEquipamento('standby');
    setLoteAtivo(null);
    setTemperatura(40);
    setPressao(150);
    setTempoRestante(0);
    setChecklist({
      limpezaEquipamento: false,
      calibracaoBalanca: false,
      verificacaoMateriaPrima: false,
      verificacaoSolventes: false,
      verificacaoProcedimento: false,
      verificacaoSeguranca: false
    });
    setChecklistConcluido(false);
  };

  const registrarResultados = () => {
    alert("Resultados registrados com sucesso!");
    reiniciarEquipamento();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Controle de Extração</h1>
          <p className="text-gray-500">Gerenciamento do processo de extração de ativos</p>
        </div>
        <div className="flex gap-2">
          <Badge variant={emProcesso ? 'secondary' : 'outline'} className="text-sm py-1 px-3">
            {estadoEquipamento === 'standby' ? 'Em Espera' : 
             estadoEquipamento === 'preparando' ? 'Preparando' :
             estadoEquipamento === 'pronto' ? 'Pronto' :
             estadoEquipamento === 'processando' ? 'Processando' :
             estadoEquipamento === 'pausado' ? 'Pausado' :
             'Concluído'}
          </Badge>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={reiniciarEquipamento}
            disabled={['standby', 'preparando'].includes(estadoEquipamento)}
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Reiniciar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {!loteAtivo ? (
            <Card>
              <CardHeader>
                <CardTitle>Ordens de Produção - Extração</CardTitle>
                <CardDescription>Selecione uma ordem de produção para iniciar o processo de extração</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <svg className="animate-spin h-8 w-8 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>OP</TableHead>
                        <TableHead>Produto</TableHead>
                        <TableHead>Lote</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Ação</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {ordensProducao.map((ordem) => (
                        <TableRow key={ordem.id}>
                          <TableCell className="font-medium">{ordem.id}</TableCell>
                          <TableCell>{ordem.produto}</TableCell>
                          <TableCell>{ordem.lote}</TableCell>
                          <TableCell>{ordem.quantidade} {ordem.unidade}</TableCell>
                          <TableCell>
                            <Button size="sm" onClick={() => iniciarProcesso(ordem)}>
                              Iniciar
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Processo de Extração - {loteAtivo.produto}</CardTitle>
                    <Badge>{loteAtivo.lote}</Badge>
                  </div>
                  <CardDescription>
                    Ordem de Produção: {loteAtivo.id} | Quantidade: {loteAtivo.quantidade} {loteAtivo.unidade}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Checklist de Verificação */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-sm font-medium">Checklist de Verificação</h3>
                      <Badge variant={checklistConcluido ? 'default' : 'outline'} className={checklistConcluido ? 'bg-green-100 text-green-800' : ''}>
                        {checklistConcluido ? 'Concluído' : 'Pendente'}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {Object.entries({
                        limpezaEquipamento: 'Limpeza do equipamento realizada',
                        calibracaoBalanca: 'Calibração da balança verificada',
                        verificacaoMateriaPrima: 'Matéria-prima verificada',
                        verificacaoSolventes: 'Solventes verificados',
                        verificacaoProcedimento: 'POP consultado',
                        verificacaoSeguranca: 'Equipamentos de segurança verificados'
                      }).map(([key, label]) => (
                        <div key={key} className="flex items-center space-x-2">
                          <input 
                            type="checkbox" 
                            id={key} 
                            checked={checklist[key]} 
                            onChange={(e) => atualizarChecklist(key, e.target.checked)}
                            className="rounded border-gray-300"
                            disabled={emProcesso}
                          />
                          <label htmlFor={key} className="text-sm">{label}</label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Parâmetros do Processo */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Parâmetros do Processo</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <label className="text-sm">Temperatura</label>
                          <span className="text-sm font-medium">{temperatura}°C</span>
                        </div>
                        <Slider
                          value={[temperatura]}
                          min={30}
                          max={60}
                          step={1}
                          onValueChange={(value) => setTemperatura(value[0])}
                          disabled={emProcesso}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <label className="text-sm">Pressão</label>
                          <span className="text-sm font-medium">{pressao} bar</span>
                        </div>
                        <Slider
                          value={[pressao]}
                          min={100}
                          max={200}
                          step={5}
                          onValueChange={(value) => setPressao(value[0])}
                          disabled={emProcesso}
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Progresso da Extração */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-sm font-medium">Progresso da Extração</h3>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-gray-500" />
                        <span className="text-sm font-medium">{tempoRestante} min restantes</span>
                      </div>
                    </div>
                    
                    <Progress value={((120 - tempoRestante) / 120) * 100} className="h-2" />
                    
                    <div className="flex justify-center gap-2">
                      {estadoEquipamento === 'pronto' && (
                        <Button 
                          onClick={iniciarExtracao}
                          disabled={!checklistConcluido}
                        >
                          <PlayCircle className="w-4 h-4 mr-2" />
                          Iniciar Extração
                        </Button>
                      )}
                      
                      {emProcesso && (
                        <>
                          <Button variant="outline" onClick={pausarExtracao}>
                            <PauseCircle className="w-4 h-4 mr-2" />
                            Pausar
                          </Button>
                          <Button variant="outline" onClick={finalizarExtracao}>
                            <StopCircle className="w-4 h-4 mr-2" />
                            Finalizar
                          </Button>
                        </>
                      )}
                      
                      {estadoEquipamento === 'pausado' && (
                        <Button onClick={continuarExtracao}>
                          <PlayCircle className="w-4 h-4 mr-2" />
                          Continuar
                        </Button>
                      )}
                      
                      {estadoEquipamento === 'concluido' && (
                        <Button onClick={registrarResultados} className="bg-green-600 hover:bg-green-700">
                          <CheckCircle2 className="w-4 h-4 mr-2" />
                          Registrar Resultados
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Materiais da Extração */}
              <Card>
                <CardHeader>
                  <CardTitle>Materiais para Extração</CardTitle>
                  <CardDescription>Materiais necessários para este processo</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Material</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Lote</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loteAtivo.materiasPrimas.map((material, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{material.nome}</TableCell>
                          <TableCell>{material.quantidade}</TableCell>
                          <TableCell>{material.lote}</TableCell>
                          <TableCell>
                            <Badge className="bg-green-100 text-green-800">Disponível</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Instruções de Extração</CardTitle>
              <CardDescription>Procedimento padrão para extração de ativos</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Badge className="mb-2">Procedimento</Badge>
                <ol className="list-decimal list-inside space-y-2 text-sm">
                  <li>Verificar limpeza do equipamento</li>
                  <li>Calibrar balança e sensores</li>
                  <li>Pesar matéria-prima conforme especificação</li>
                  <li>Carregar material no extrator</li>
                  <li>Ajustar parâmetros de temperatura e pressão</li>
                  <li>Iniciar ciclo de extração</li>
                  <li>Monitorar parâmetros durante o processo</li>
                  <li>Coletar extrato ao final do processo</li>
                  <li>Realizar análises de controle</li>
                </ol>
              </div>

              <Separator />

              <div className="space-y-2">
                <Badge className="mb-2">Parâmetros Críticos</Badge>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium">Temperatura:</p>
                    <p>40-45°C (±2°C)</p>
                  </div>
                  <div>
                    <p className="font-medium">Pressão:</p>
                    <p>150-160 bar</p>
                  </div>
                  <div>
                    <p className="font-medium">Tempo:</p>
                    <p>120 minutos</p>
                  </div>
                  <div>
                    <p className="font-medium">Fluxo:</p>
                    <p>40-50 L/h</p>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <Badge className="mb-2">Controle de Qualidade</Badge>
                <div className="space-y-2 text-sm">
                  <p>• Verificar aspecto visual do extrato</p>
                  <p>• Medir concentração de ativos</p>
                  <p>• Verificar ausência de solventes residuais</p>
                  <p>• Registrar rendimento da extração</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Status do Equipamento</CardTitle>
              <CardDescription>Extrator #01</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Temperatura</p>
                  <div className="flex items-center">
                    <Thermometer className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{emProcesso ? temperatura : '---'}°C</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Pressão</p>
                  <div className="flex items-center">
                    <Gauge className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{emProcesso ? pressao : '---'} bar</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Ciclo</p>
                  <div className="flex items-center">
                    <Timer className="w-4 h-4 text-blue-500 mr-2" />
                    <span className="text-xl font-bold">{emProcesso ? `${Math.floor((120 - tempoRestante) / 120 * 100)}%` : '---'}</span>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-500">Status</p>
                  <div className="flex items-center mt-1">
                    {estadoEquipamento === 'standby' && (
                      <Badge variant="outline">Em Espera</Badge>
                    )}
                    {estadoEquipamento === 'preparando' && (
                      <Badge variant="outline">Preparando</Badge>
                    )}
                    {estadoEquipamento === 'pronto' && (
                      <Badge className="bg-yellow-100 text-yellow-800">Pronto</Badge>
                    )}
                    {estadoEquipamento === 'processando' && (
                      <Badge className="bg-blue-100 text-blue-800">Processando</Badge>
                    )}
                    {estadoEquipamento === 'pausado' && (
                      <Badge className="bg-orange-100 text-orange-800">Pausado</Badge>
                    )}
                    {estadoEquipamento === 'concluido' && (
                      <Badge className="bg-green-100 text-green-800">Concluído</Badge>
                    )}
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Manutenção</h3>
                <div className="text-sm">
                  <p>• Última calibração: 15/07/2023</p>
                  <p>• Próxima manutenção: 15/10/2023</p>
                  <p>• Status geral: Operacional</p>
                  <p>• Horas de operação: 2.450h</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}