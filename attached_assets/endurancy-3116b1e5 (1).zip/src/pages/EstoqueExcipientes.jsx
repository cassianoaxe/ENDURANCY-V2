import React, { useState, useEffect } from 'react';
import EstoqueBaseView from '../components/estoque/EstoqueBaseView';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function EstoqueExcipientes() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [tipoFilter, setTipoFilter] = useState("all");

  useEffect(() => {
    const loadData = async () => {
      const mockData = [
        {
          id: "1",
          codigo: "EXC-MCT-001",
          nome: "Óleo MCT",
          lote: "L202301",
          quantidade_atual: 25000,
          quantidade_minima: 10000,
          unidade_medida: "ml",
          status: "disponivel",
          data_validade: "2024-12-31"
        },
        {
          id: "2",
          codigo: "EXC-COCO-001",
          nome: "Óleo de Coco",
          lote: "L202302",
          quantidade_atual: 15000,
          quantidade_minima: 8000,
          unidade_medida: "ml",
          status: "em_analise",
          data_validade: "2024-10-15"
        }
      ];
      
      setData(mockData);
      setLoading(false);
    };

    setTimeout(loadData, 1000);
  }, []);

  const customFilters = (
    <Select value={tipoFilter} onValueChange={setTipoFilter}>
      <SelectTrigger className="w-40">
        <SelectValue placeholder="Tipo" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">Todos Tipos</SelectItem>
        <SelectItem value="oleo">Óleos</SelectItem>
        <SelectItem value="aditivo">Aditivos</SelectItem>
        <SelectItem value="conservante">Conservantes</SelectItem>
      </SelectContent>
    </Select>
  );

  return (
    <EstoqueBaseView
      title="Estoque de Excipientes"
      description="Gestão de estoque de excipientes e veículos"
      tipoEstoque="materia_prima_excipiente"
      data={data}
      loading={loading}
      onAddItem={() => console.log("Adicionar item")}
      onEditItem={(item) => console.log("Editar item", item)}
      onViewDetails={(item) => console.log("Ver detalhes", item)}
      customFilters={customFilters}
    />
  );
}