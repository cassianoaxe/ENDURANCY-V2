import React, { useState } from "react";
import {
  Building2,
  Briefcase,
  Users,
  Plus,
  FileText,
  Edit,
  Trash,
  Save,
  Search,
  Check,
  X,
  UserPlus,
  Upload,
  Download,
  HelpCircle,
  Info,
  ChevronDown,
  ChevronRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { createPageUrl } from "@/utils";

export default function OrgEstrutura() {
  const [activeTab, setActiveTab] = useState("setores");
  const [searchTerm, setSearchTerm] = useState("");
  const [showSetorDialog, setShowSetorDialog] = useState(false);
  const [showDepartmentDialog, setShowDepartmentDialog] = useState(false);
  const [showColaboradorDialog, setShowColaboradorDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [currentSetor, setCurrentSetor] = useState(null);
  const [currentDepartment, setCurrentDepartment] = useState(null);

  // Mock data
  const [setores, setSetores] = useState([
    { id: 1, nome: "Administrativo", descricao: "Setor administrativo", diretor: "Carlos Mendes", totalDepartamentos: 3, totalColaboradores: 12, cor: "#4f46e5" },
    { id: 2, nome: "Produção", descricao: "Setor de produção", diretor: "Ana Silva", totalDepartamentos: 4, totalColaboradores: 25, cor: "#16a34a" },
    { id: 3, nome: "Comercial", descricao: "Setor comercial e vendas", diretor: "Roberto Santos", totalDepartamentos: 2, totalColaboradores: 8, cor: "#ea580c" }
  ]);

  // Available modules
  const [availableModules, setAvailableModules] = useState([
    { id: "cultivo", name: "Cultivo", icon: "Leaf" },
    { id: "producao", name: "Produção", icon: "Factory" },
    { id: "dispensario", name: "Dispensário", icon: "ShoppingBag" },
    { id: "financeiro", name: "Financeiro", icon: "DollarSign" },
    { id: "rh", name: "Recursos Humanos", icon: "Users" },
    { id: "juridico", name: "Jurídico", icon: "Scale" },
    { id: "social", name: "Assistência Social", icon: "Heart" },
    { id: "marketing", name: "Marketing", icon: "TrendingUp" },
    { id: "compras", name: "Compras", icon: "ShoppingCart" },
    { id: "expedicao", name: "Expedição", icon: "Truck" },
    { id: "qualidade", name: "Controle de Qualidade", icon: "CheckSquare" },
    { id: "estoque", name: "Estoque", icon: "Package" }
  ]);

  // Update department state with modules
  const [departamentos, setDepartamentos] = useState([
    { id: 1, nome: "Recursos Humanos", setorId: 1, setorNome: "Administrativo", gerente: "Maria Souza", totalColaboradores: 4, cor: "#6366f1", modulos: ["rh", "financeiro"] },
    { id: 2, nome: "Financeiro", setorId: 1, setorNome: "Administrativo", gerente: "João Almeida", totalColaboradores: 5, cor: "#8b5cf6", modulos: ["financeiro"] },
    { id: 3, nome: "Jurídico", setorId: 1, setorNome: "Administrativo", gerente: "Juliana Costa", totalColaboradores: 3, cor: "#ec4899", modulos: ["juridico"] },
    { id: 4, nome: "Extração", setorId: 2, setorNome: "Produção", gerente: "Paulo Oliveira", totalColaboradores: 8, cor: "#10b981", modulos: ["producao", "qualidade"] },
    { id: 5, nome: "Envase", setorId: 2, setorNome: "Produção", gerente: "Carla Lima", totalColaboradores: 6, cor: "#14b8a6", modulos: ["producao"] },
    { id: 6, nome: "Controle de Qualidade", setorId: 2, setorNome: "Produção", gerente: "Ricardo Ferreira", totalColaboradores: 7, cor: "#06b6d4", modulos: ["qualidade"] },
    { id: 7, nome: "Vendas", setorId: 3, setorNome: "Comercial", gerente: "Fernanda Dias", totalColaboradores: 5, cor: "#f97316", modulos: ["dispensario"] },
    { id: 8, nome: "Marketing", setorId: 3, setorNome: "Comercial", gerente: "Eduardo Gomes", totalColaboradores: 3, cor: "#f59e0b", modulos: ["marketing"] }
  ]);

  const [colaboradores, setColaboradores] = useState([
    { id: 1, nome: "Ana Carolina Silva", email: "ana.silva@empresa.com", cargo: "Analista de RH", departamentoId: 1, departamentoNome: "Recursos Humanos", setorId: 1, setorNome: "Administrativo", status: "ativo", dataAdmissao: "2021-03-15" },
    { id: 2, nome: "Bruno Oliveira", email: "bruno.oliveira@empresa.com", cargo: "Contador", departamentoId: 2, departamentoNome: "Financeiro", setorId: 1, setorNome: "Administrativo", status: "ativo", dataAdmissao: "2020-07-10" },
    { id: 3, nome: "Carla Mendes", email: "carla.mendes@empresa.com", cargo: "Advogada", departamentoId: 3, departamentoNome: "Jurídico", setorId: 1, setorNome: "Administrativo", status: "ativo", dataAdmissao: "2022-01-20" },
    { id: 4, nome: "Daniel Santos", email: "daniel.santos@empresa.com", cargo: "Técnico de Extração", departamentoId: 4, departamentoNome: "Extração", setorId: 2, setorNome: "Produção", status: "ativo", dataAdmissao: "2021-05-03" },
    { id: 5, nome: "Elisa Ferreira", email: "elisa.ferreira@empresa.com", cargo: "Operadora de Envase", departamentoId: 5, departamentoNome: "Envase", setorId: 2, setorNome: "Produção", status: "ativo", dataAdmissao: "2022-08-15" }
  ]);

  // Department module selection state
  const [selectedModules, setSelectedModules] = useState([]);

  const handleModuleToggle = (moduleId) => {
    setSelectedModules(prev => 
      prev.includes(moduleId) 
        ? prev.filter(id => id !== moduleId) 
        : [...prev, moduleId]
    );
  };

  const handleOpenSetorDialog = (setor = null) => {
    setCurrentSetor(setor);
    setShowSetorDialog(true);
  };

  const handleOpenDepartmentDialog = (department = null) => {
    setCurrentDepartment(department);
    setSelectedModules(department?.modulos || []);
    setShowDepartmentDialog(true);
  };

  const handleOpenColaboradorDialog = (colaborador = null) => {
    // Implementar quando necessário
    setShowColaboradorDialog(true);
  };

  const handleSaveSetor = () => {
    toast({
      title: currentSetor ? "Setor atualizado" : "Setor criado",
      description: `O setor foi ${currentSetor ? "atualizado" : "criado"} com sucesso.`
    });
    setShowSetorDialog(false);
  };

  const handleSaveDepartment = () => {
    toast({
      title: currentDepartment ? "Departamento atualizado" : "Departamento criado",
      description: `O departamento foi ${currentDepartment ? "atualizado" : "criado"} com sucesso.`
    });
    setShowDepartmentDialog(false);
  };

  const handleSaveColaborador = () => {
    toast({
      title: "Colaborador salvo",
      description: "O colaborador foi salvo com sucesso."
    });
    setShowColaboradorDialog(false);
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Estrutura Organizacional</h1>
          <p className="text-gray-500">Gerencie setores, departamentos e colaboradores</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="setores" className="flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            <span>Setores</span>
          </TabsTrigger>
          <TabsTrigger value="departamentos" className="flex items-center gap-2">
            <Briefcase className="w-4 h-4" />
            <span>Departamentos</span>
          </TabsTrigger>
          <TabsTrigger value="colaboradores" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            <span>Colaboradores</span>
          </TabsTrigger>
        </TabsList>

        {/* Aba de Setores */}
        <TabsContent value="setores">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Setores</CardTitle>
                <CardDescription>Gerencie os setores da sua organização</CardDescription>
              </div>
              <Button onClick={() => handleOpenSetorDialog()}>
                <Plus className="w-4 h-4 mr-2" />
                Novo Setor
              </Button>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-4">
                <Input
                  placeholder="Buscar setores..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-sm"
                />
                <Button variant="outline" size="icon">
                  <Search className="h-4 w-4" />
                </Button>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Diretor</TableHead>
                    <TableHead>Departamentos</TableHead>
                    <TableHead>Colaboradores</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {setores.map((setor) => (
                    <TableRow key={setor.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: setor.cor }} />
                          <span className="font-medium">{setor.nome}</span>
                        </div>
                      </TableCell>
                      <TableCell>{setor.diretor}</TableCell>
                      <TableCell>{setor.totalDepartamentos}</TableCell>
                      <TableCell>{setor.totalColaboradores}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleOpenSetorDialog(setor)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Aba de Departamentos */}
        <TabsContent value="departamentos">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Departamentos</CardTitle>
                <CardDescription>Gerencie os departamentos por setor</CardDescription>
              </div>
              <Button onClick={() => handleOpenDepartmentDialog()}>
                <Plus className="w-4 h-4 mr-2" />
                Novo Departamento
              </Button>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-4">
                <Input
                  placeholder="Buscar departamentos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-sm"
                />
                <Select>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filtrar por setor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os setores</SelectItem>
                    {setores.map((setor) => (
                      <SelectItem key={setor.id} value={setor.id.toString()}>
                        {setor.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon">
                  <Search className="h-4 w-4" />
                </Button>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Setor</TableHead>
                    <TableHead>Gerente</TableHead>
                    <TableHead>Colaboradores</TableHead>
                    <TableHead>Módulos</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {departamentos.map((departamento) => (
                    <TableRow key={departamento.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: departamento.cor }} />
                          <span className="font-medium">{departamento.nome}</span>
                        </div>
                      </TableCell>
                      <TableCell>{departamento.setorNome}</TableCell>
                      <TableCell>{departamento.gerente}</TableCell>
                      <TableCell>{departamento.totalColaboradores}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {departamento.modulos.map((modulo) => (
                            <Badge key={modulo} variant="outline" className="text-xs">
                              {availableModules.find(m => m.id === modulo)?.name || modulo}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleOpenDepartmentDialog(departamento)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Aba de Colaboradores */}
        <TabsContent value="colaboradores">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Colaboradores</CardTitle>
                <CardDescription>Gerencie os colaboradores da sua organização</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setShowImportDialog(true)}>
                  <Upload className="w-4 h-4 mr-2" />
                  Importar
                </Button>
                <Button onClick={() => handleOpenColaboradorDialog()}>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Novo Colaborador
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-4 flex-wrap">
                <Input
                  placeholder="Buscar colaboradores..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-sm"
                />
                <Select>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filtrar por setor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os setores</SelectItem>
                    {setores.map((setor) => (
                      <SelectItem key={setor.id} value={setor.id.toString()}>
                        {setor.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filtrar por departamento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os departamentos</SelectItem>
                    {departamentos.map((departamento) => (
                      <SelectItem key={departamento.id} value={departamento.id.toString()}>
                        {departamento.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon">
                  <Search className="h-4 w-4" />
                </Button>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Cargo</TableHead>
                    <TableHead>Departamento</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {colaboradores.map((colaborador) => (
                    <TableRow key={colaborador.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback>{colaborador.nome.split(' ').map(n => n[0]).join('').substring(0, 2)}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{colaborador.nome}</span>
                        </div>
                      </TableCell>
                      <TableCell>{colaborador.cargo}</TableCell>
                      <TableCell>{colaborador.departamentoNome}</TableCell>
                      <TableCell>{colaborador.email}</TableCell>
                      <TableCell>
                        <Badge variant={colaborador.status === 'ativo' ? 'default' : 'secondary'}>
                          {colaborador.status === 'ativo' ? 'Ativo' : 'Inativo'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleOpenColaboradorDialog(colaborador)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <ChevronDown className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Check className="w-4 h-4 mr-2" />
                                <span>Ativar</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <X className="w-4 h-4 mr-2" />
                                <span>Desativar</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Trash className="w-4 h-4 mr-2" />
                                <span>Remover</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Diálogo de Setor */}
      <Dialog open={showSetorDialog} onOpenChange={setShowSetorDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{currentSetor ? "Editar Setor" : "Novo Setor"}</DialogTitle>
            <DialogDescription>
              {currentSetor ? "Edite as informações do setor" : "Preencha as informações para criar um novo setor"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="nome-setor">Nome do Setor</Label>
              <Input
                id="nome-setor"
                placeholder="Ex: Administrativo"
                defaultValue={currentSetor?.nome || ""}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="descricao-setor">Descrição</Label>
              <Input
                id="descricao-setor"
                placeholder="Ex: Setor responsável pela administração"
                defaultValue={currentSetor?.descricao || ""}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="diretor-setor">Diretor Responsável</Label>
              <Input
                id="diretor-setor"
                placeholder="Ex: João Silva"
                defaultValue={currentSetor?.diretor || ""}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cor-setor">Cor do Setor</Label>
              <div className="flex gap-2">
                <Input
                  id="cor-setor"
                  type="color"
                  className="w-12 h-10 p-1"
                  defaultValue={currentSetor?.cor || "#4f46e5"}
                />
                <Input
                  placeholder="Código da cor (hex)"
                  className="flex-1"
                  defaultValue={currentSetor?.cor || "#4f46e5"}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSetorDialog(false)}>Cancelar</Button>
            <Button onClick={handleSaveSetor}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de Departamento */}
      <Dialog open={showDepartmentDialog} onOpenChange={setShowDepartmentDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{currentDepartment ? "Editar Departamento" : "Novo Departamento"}</DialogTitle>
            <DialogDescription>
              {currentDepartment ? "Edite as informações do departamento" : "Preencha as informações para criar um novo departamento"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="nome-departamento">Nome do Departamento</Label>
              <Input
                id="nome-departamento"
                placeholder="Ex: Recursos Humanos"
                defaultValue={currentDepartment?.nome || ""}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="setor-departamento">Setor</Label>
              <Select defaultValue={currentDepartment?.setorId?.toString() || ""}>
                <SelectTrigger id="setor-departamento">
                  <SelectValue placeholder="Selecione o setor" />
                </SelectTrigger>
                <SelectContent>
                  {setores.map((setor) => (
                    <SelectItem key={setor.id} value={setor.id.toString()}>
                      {setor.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="gerente-departamento">Gerente Responsável</Label>
              <Select defaultValue={currentDepartment?.gerente || ""}>
                <SelectTrigger id="gerente-departamento">
                  <SelectValue placeholder="Selecione o gerente" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Maria Souza">Maria Souza</SelectItem>
                  <SelectItem value="João Almeida">João Almeida</SelectItem>
                  <SelectItem value="Paulo Oliveira">Paulo Oliveira</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="cor-departamento">Cor do Departamento</Label>
              <div className="flex gap-2">
                <Input
                  id="cor-departamento"
                  type="color"
                  className="w-12 h-10 p-1"
                  defaultValue={currentDepartment?.cor || "#6366f1"}
                />
                <Input
                  placeholder="Código da cor (hex)"
                  className="flex-1"
                  defaultValue={currentDepartment?.cor || "#6366f1"}
                />
              </div>
            </div>

            {/* New section for module access */}
            <div className="space-y-2">
              <Label>Acesso aos Módulos</Label>
              <div className="border rounded-md p-4">
                <div className="text-sm text-gray-500 mb-3">
                  Selecione os módulos que este departamento poderá acessar:
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {availableModules.map((module) => (
                    <div key={module.id} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`module-${module.id}`}
                        checked={selectedModules.includes(module.id)}
                        onCheckedChange={() => handleModuleToggle(module.id)}
                      />
                      <Label htmlFor={`module-${module.id}`} className="font-normal">
                        {module.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDepartmentDialog(false)}>Cancelar</Button>
            <Button onClick={handleSaveDepartment}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de Colaborador */}
      <Dialog open={showColaboradorDialog} onOpenChange={setShowColaboradorDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Novo Colaborador</DialogTitle>
            <DialogDescription>
              Preencha as informações para cadastrar um novo colaborador
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="nome-colaborador">Nome Completo</Label>
              <Input
                id="nome-colaborador"
                placeholder="Ex: Maria da Silva"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email-colaborador">Email</Label>
              <Input
                id="email-colaborador"
                type="email"
                placeholder="Ex: maria.silva@empresa.com"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="setor-colaborador">Setor</Label>
                <Select>
                  <SelectTrigger id="setor-colaborador">
                    <SelectValue placeholder="Selecione o setor" />
                  </SelectTrigger>
                  <SelectContent>
                    {setores.map((setor) => (
                      <SelectItem key={setor.id} value={setor.id.toString()}>
                        {setor.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="departamento-colaborador">Departamento</Label>
                <Select>
                  <SelectTrigger id="departamento-colaborador">
                    <SelectValue placeholder="Selecione o departamento" />
                  </SelectTrigger>
                  <SelectContent>
                    {departamentos.map((departamento) => (
                      <SelectItem key={departamento.id} value={departamento.id.toString()}>
                        {departamento.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="cargo-colaborador">Cargo</Label>
              <Input
                id="cargo-colaborador"
                placeholder="Ex: Analista de Recursos Humanos"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch id="status-colaborador" defaultChecked />
              <Label htmlFor="status-colaborador">Colaborador ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowColaboradorDialog(false)}>Cancelar</Button>
            <Button onClick={handleSaveColaborador}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de Importação */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Importar Colaboradores</DialogTitle>
            <DialogDescription>
              Importe uma lista de colaboradores a partir de um arquivo CSV
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="border-2 border-dashed rounded-md p-6 text-center">
              <Upload className="h-8 w-8 mx-auto text-gray-400" />
              <p className="mt-2 text-sm text-gray-500">
                Arraste e solte seu arquivo CSV aqui ou clique para selecionar
              </p>
              <Input 
                type="file" 
                className="mt-4 mx-auto max-w-xs"
                accept=".csv"
              />
            </div>
            <div className="bg-muted/50 rounded-md p-3">
              <div className="flex items-center gap-2 text-sm">
                <HelpCircle className="h-4 w-4 text-muted-foreground" />
                <p className="text-muted-foreground">
                  O arquivo CSV deve conter as colunas: Nome, Email, Cargo, Departamento, Setor
                </p>
              </div>
              <Button variant="link" className="text-xs text-blue-600 p-0 h-auto mt-1">
                Baixar modelo de planilha
              </Button>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowImportDialog(false)}>Cancelar</Button>
            <Button>Importar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}